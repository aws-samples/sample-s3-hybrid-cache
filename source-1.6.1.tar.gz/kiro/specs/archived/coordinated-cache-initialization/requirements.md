# Requirements Document: Coordinated Cache Initialization

## Introduction

The S3 Proxy currently has separate initialization and validation systems for write cache management and overall cache size tracking. While this separation is architecturally correct (write cache requires separate capacity limits), the current implementation creates redundant directory scanning, inconsistent startup messages, and potential validation discrepancies. This specification coordinates the initialization process while preserving the intentional separation of concerns.

Key improvements:
- Single coordinated scan of cache metadata during startup
- Clear, sequential startup messages that explain the purpose of each validation phase
- Cross-validation between subsystems to detect inconsistencies
- Shared validation utilities to eliminate duplicate logic
- Improved performance through elimination of redundant directory traversal

## Glossary

- **Cache Initialization**: The startup process that validates existing cache state and prepares subsystems
- **Write Cache Manager**: Component responsible for write cache capacity tracking and eviction (separate from read cache)
- **Cache Size Tracker**: Component responsible for overall cache size validation and drift correction across instances
- **Coordinated Scan**: Single directory traversal that provides data to multiple cache subsystems
- **Subsystem Consistency**: Agreement between different cache management components on shared data
- **Validation Phase**: Distinct step in initialization with specific purpose and logging
- **Cross-Validation**: Verification that multiple subsystems agree on overlapping data
- **Metadata Scan Results**: Structured data from directory scan used by multiple subsystems

## Requirements

### Requirement 1: Coordinated Directory Scanning

**User Story:** As a system operator, I want cache initialization to scan directories once and share results, so that startup is faster and more efficient.

#### Acceptance Criteria

1. WHEN cache initialization begins, THEN the system SHALL attempt recovery from checkpoint and delta log before scanning directories
2. WHEN recovery succeeds, THEN the system SHALL initialize subsystems with recovered data and skip directory scanning
3. WHEN recovery fails, THEN the system SHALL perform a single coordinated scan and create initial checkpoint
4. WHEN scanning is required, THEN the system SHALL collect metadata for both write cache tracking and size validation
5. WHEN scan fails, THEN the system SHALL log the error and continue with empty results rather than failing initialization

### Requirement 2: Sequential Initialization Phases

**User Story:** As a system operator, I want clear visibility into initialization progress, so that I can understand what the system is doing during startup.

#### Acceptance Criteria

1. WHEN cache initialization starts, THEN the system SHALL log the beginning of initialization with phase indicators
2. WHEN each phase begins, THEN the system SHALL log the phase number, total phases, and phase description
3. WHEN each phase completes, THEN the system SHALL log completion with relevant metrics
4. WHEN initialization completes, THEN the system SHALL log total initialization time and summary statistics
5. WHEN a phase fails, THEN the system SHALL log the failure with phase context and continue with remaining phases where possible

### Requirement 3: Subsystem-Specific Logging

**User Story:** As a system operator, I want startup messages to clearly indicate which subsystem is being initialized, so that I can distinguish between different validation purposes.

#### Acceptance Criteria

1. WHEN write cache manager initializes, THEN the system SHALL log messages prefixed with "Write cache capacity tracking"
2. WHEN cache size tracker initializes, THEN the system SHALL log messages prefixed with "Cache size validation"
3. WHEN logging capacity information, THEN the system SHALL include both absolute values and percentages
4. WHEN write cache is disabled, THEN the system SHALL log "Write cache: disabled" and skip write cache initialization
5. WHEN logging scan results, THEN the system SHALL distinguish between total objects and write-cached objects

### Requirement 4: Cross-Validation Between Subsystems

**User Story:** As a system operator, I want validation that cache subsystems agree on shared data, so that inconsistencies are detected early.

#### Acceptance Criteria

1. WHEN both write cache and size tracker are enabled, THEN the system SHALL compare write cache size calculations between subsystems
2. WHEN write cache size discrepancy exceeds 5%, THEN the system SHALL log a warning with the difference
3. WHEN write cache size discrepancy exceeds 20%, THEN the system SHALL log an error and suggest running validation
4. WHEN cross-validation passes, THEN the system SHALL log successful consistency check at debug level
5. WHEN cross-validation is performed, THEN the system SHALL include the validation in the initialization summary

### Requirement 5: Shared Validation Utilities

**User Story:** As a developer, I want common validation logic to be shared between subsystems, so that validation behavior is consistent and maintainable.

#### Acceptance Criteria

1. WHEN validating metadata files, THEN both subsystems SHALL use the same validation logic
2. WHEN scanning directories, THEN both subsystems SHALL use the same file filtering and error handling
3. WHEN calculating compressed sizes, THEN both subsystems SHALL use the same calculation method
4. WHEN handling corrupted metadata, THEN both subsystems SHALL use the same recovery strategy
5. WHEN validation utilities are updated, THEN changes SHALL automatically apply to both subsystems

### Requirement 6: Performance Optimization

**User Story:** As a system operator, I want cache initialization to be as fast as possible, so that proxy startup time is minimized.

#### Acceptance Criteria

1. WHEN initializing cache, THEN the system SHALL perform at most one traversal of the objects directory
2. WHEN processing metadata files, THEN the system SHALL parse each file at most once during initialization
3. WHEN write cache is disabled, THEN the system SHALL not perform write-cache-specific processing
4. WHEN initialization completes, THEN the system SHALL log the total time taken for performance monitoring
5. WHEN large cache directories are scanned, THEN the system SHALL process files in parallel where safe

### Requirement 7: Error Handling and Recovery

**User Story:** As a system operator, I want cache initialization to handle errors gracefully, so that the proxy can start even with some cache corruption.

#### Acceptance Criteria

1. WHEN metadata file parsing fails, THEN the system SHALL log the error and continue with remaining files
2. WHEN directory access fails, THEN the system SHALL log the error and initialize with empty state
3. WHEN subsystem initialization fails, THEN the system SHALL log the failure and continue with other subsystems
4. WHEN cross-validation fails, THEN the system SHALL log the discrepancy but not fail initialization
5. WHEN initialization encounters errors, THEN the system SHALL include error counts in the completion summary



### Requirement 9: Configuration Integration

**User Story:** As a system operator, I want initialization behavior to respect configuration settings, so that I can tune initialization for my environment.

#### Acceptance Criteria

1. WHEN write_cache_enabled is false, THEN the system SHALL skip write cache initialization but still perform size tracking
2. WHEN actively_remove_cached_data is configured, THEN the system SHALL pass this setting to both subsystems
3. WHEN validation_enabled is false, THEN the system SHALL skip size tracker validation tasks
4. WHEN cache directories are configured, THEN the system SHALL use the configured paths for all subsystems
5. WHEN initialization logging level is configured, THEN the system SHALL respect the logging configuration

### Requirement 10: Multi-Instance Coordination

**User Story:** As a system operator running multiple proxy instances, I want coordinated initialization to work correctly with shared cache volumes, so that instances don't interfere with each other.

#### Acceptance Criteria

1. WHEN multiple instances initialize simultaneously, THEN each instance SHALL acquire appropriate locks before scanning
2. WHEN shared cache validation runs, THEN only one instance SHALL perform validation at a time
3. WHEN initialization completes, THEN each instance SHALL have consistent view of cache state
4. WHEN file locking fails, THEN the system SHALL retry with exponential backoff
5. WHEN distributed locks are used, THEN the system SHALL release locks properly on initialization completion or failure
