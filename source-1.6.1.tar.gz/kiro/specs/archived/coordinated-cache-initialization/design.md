# Design Document: Coordinated Cache Initialization

## Overview

This design coordinates the cache initialization process to eliminate redundant directory scanning, provide clear startup messaging, and ensure consistency between cache subsystems while preserving the intentional architectural separation between write cache management and overall cache size tracking.

Key design principles:
- **Single Scan Coordination**: One directory traversal provides data to all subsystems
- **Preserve Separation**: WriteCacheManager and CacheSizeTracker remain architecturally separate
- **Clear Progress Indication**: Sequential phases with explicit logging and progress indicators
- **Cross-Validation**: Verify consistency between subsystems without tight coupling
- **Shared Utilities**: Common validation logic without architectural unification
- **Performance Optimization**: Minimize filesystem operations and parsing overhead

## Architecture

### Current State Problems

1. **Redundant Scanning**: Both WriteCacheManager and CacheSizeTracker scan objects/ directory independently
2. **Confusing Messages**: Startup logs don't clearly indicate which subsystem is initializing
3. **No Cross-Validation**: Subsystems may have inconsistent views of cache state
4. **Duplicate Logic**: Similar validation code exists in both subsystems
5. **Unclear Sequencing**: Initialization phases happen in unclear order

### Proposed Architecture

```
Cache Initialization Coordinator
├── Phase 1: Directory Setup
│   ├── Create cache directories
│   ├── Validate permissions
│   └── Clean temporary files
├── Phase 2: Recovery Attempt
│   ├── Try checkpoint + delta log recovery
│   ├── If successful → Skip to Phase 4
│   └── If failed → Continue to Phase 3
├── Phase 3: Fallback Metadata Scan (Only if recovery failed)
│   ├── Single objects/ directory traversal
│   ├── Parse metadata files once
│   ├── Categorize by write_cached flag
│   ├── Generate ObjectsScanResults
│   └── Create initial checkpoint
├── Phase 4: Subsystem Initialization
│   ├── WriteCacheManager (if enabled)
│   │   ├── Initialize from recovered/scanned data
│   │   ├── Calculate capacity usage
│   │   └── Log capacity tracking status
│   └── CacheSizeTracker
│       ├── Initialize from recovered/scanned data
│       ├── Setup validation tasks
│       └── Log size validation status
├── Phase 5: Cross-Validation (Optional)
│   ├── Compare write cache sizes (if both available)
│   ├── Validate consistency
│   └── Log validation results
└── Phase 6: Background Tasks
    ├── Start checkpoint tasks
    ├── Start validation tasks (scheduled, not immediate)
    └── Start flush coordinators
```

## Components and Interfaces

### CacheInitializationCoordinator

New component that orchestrates the initialization process:

```rust
pub struct CacheInitializationCoordinator {
    cache_dir: PathBuf,
    write_cache_enabled: bool,
    config: CacheConfig,
}

impl CacheInitializationCoordinator {
    /// Coordinate full cache initialization process
    pub async fn initialize(
        &self,
        write_cache_manager: Option<&mut WriteCacheManager>,
        size_tracker: &mut Option<Arc<CacheSizeTracker>>,
    ) -> Result<InitializationSummary>;
    
    /// Perform coordinated metadata scan
    async fn scan_cache_metadata(&self) -> Result<ObjectsScanResults>;
    
    /// Initialize subsystems from scan results
    async fn initialize_subsystems(
        &self,
        scan_results: &ObjectsScanResults,
        write_cache_manager: Option<&mut WriteCacheManager>,
        size_tracker: &mut Option<Arc<CacheSizeTracker>>,
    ) -> Result<SubsystemResults>;
    
    /// Perform cross-validation between subsystems
    async fn cross_validate_subsystems(
        &self,
        write_cache_manager: Option<&WriteCacheManager>,
        size_tracker: Option<&Arc<CacheSizeTracker>>,
    ) -> Result<ValidationResults>;
}
```

### ObjectsScanResults

Structured results from coordinated directory scan:

```rust
pub struct ObjectsScanResults {
    /// Total objects found in cache
    pub total_objects: u64,
    /// Total compressed size of all objects
    pub total_size: u64,
    /// Objects marked as write-cached
    pub write_cached_objects: u64,
    /// Compressed size of write-cached objects
    pub write_cached_size: u64,
    /// Objects marked as read-cached (or unmarked)
    pub read_cached_objects: u64,
    /// Compressed size of read-cached objects
    pub read_cached_size: u64,
    /// Metadata entries for detailed processing
    pub metadata_entries: Vec<CacheMetadataEntry>,
    /// Scan duration for performance monitoring
    pub scan_duration: Duration,
    /// Errors encountered during scan
    pub scan_errors: Vec<ScanError>,
}

impl ObjectsScanResults {
    /// Calculate write cache usage percentage
    pub fn write_cache_percentage(&self) -> f64 {
        if self.total_size == 0 { 0.0 } else {
            (self.write_cached_size as f64 / self.total_size as f64) * 100.0
        }
    }
    
    /// Format size in human-readable format
    pub fn format_total_size(&self) -> String;
    pub fn format_write_cached_size(&self) -> String;
}
```

### CacheValidator (Shared Utilities)

New module with shared validation logic:

```rust
pub struct CacheValidator {
    cache_dir: PathBuf,
}

impl CacheValidator {
    /// Validate metadata file consistency
    pub async fn validate_metadata_file(&self, path: &Path) -> Result<ValidationResult>;
    
    /// Parse metadata with error recovery
    pub async fn parse_metadata_safe(&self, path: &Path) -> Result<Option<CacheMetadata>>;
    
    /// Calculate compressed size from ranges
    pub fn calculate_compressed_size(&self, ranges: &[RangeMetadata]) -> u64;
    
    /// Scan directory with parallel processing
    pub async fn scan_directory_parallel(&self, dir: &Path) -> Result<Vec<PathBuf>>;
    
    /// Filter metadata files by criteria
    pub fn filter_by_write_cached(&self, entries: &[CacheMetadataEntry]) -> Vec<&CacheMetadataEntry>;
}
```

### InitializationSummary

Results and metrics from initialization:

```rust
pub struct InitializationSummary {
    /// Total initialization duration
    pub total_duration: Duration,
    /// Results from each phase
    pub phase_results: Vec<PhaseResult>,
    /// Scan results summary
    pub scan_summary: ObjectsScanResults,
    /// Subsystem initialization results
    pub subsystem_results: SubsystemResults,
    /// Cross-validation results
    pub validation_results: Option<ValidationResults>,
    /// Total errors encountered
    pub total_errors: u32,
    /// Warnings generated
    pub total_warnings: u32,
}

pub struct PhaseResult {
    pub phase_name: String,
    pub duration: Duration,
    pub success: bool,
    pub error_message: Option<String>,
}

pub struct SubsystemResults {
    pub write_cache_initialized: bool,
    pub write_cache_usage: u64,
    pub size_tracker_initialized: bool,
    pub size_tracker_usage: u64,
}

pub struct ValidationResults {
    pub write_cache_consistent: bool,
    pub size_discrepancy_percent: f64,
    pub validation_warnings: Vec<String>,
}
```

## Data Models

### Enhanced Metadata Processing

The coordinated scan processes metadata once and categorizes it:

```rust
pub struct CacheMetadataEntry {
    pub file_path: PathBuf,
    pub cache_key: String,
    pub metadata: CacheMetadata,
    pub compressed_size: u64,
    pub is_write_cached: bool,
    pub parse_errors: Vec<String>,
}

impl CacheMetadataEntry {
    /// Create from file path with error handling
    pub async fn from_file(path: PathBuf, validator: &CacheValidator) -> Result<Option<Self>>;
    
    /// Check if entry is valid for processing
    pub fn is_valid(&self) -> bool;
    
    /// Get categorization for subsystem routing
    pub fn get_category(&self) -> CacheCategory;
}

pub enum CacheCategory {
    WriteCached,
    ReadCached,
    Invalid,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Recovery-first initialization

*For any* cache initialization, the system SHALL attempt recovery from checkpoint and delta log before performing directory scanning, and SHALL only scan when recovery fails.

**Validates: Requirements 1.1, 1.3, 6.1**

### Property 2: Scan result distribution

*For any* coordinated scan, both WriteCacheManager and CacheSizeTracker SHALL receive the same scan results data when both are enabled.

**Validates: Requirements 1.2, 1.3**

### Property 3: Write cache disabled behavior

*For any* initialization where write cache is disabled, the system SHALL still perform metadata scanning for size tracking purposes but skip write cache initialization.

**Validates: Requirements 1.4, 9.1**

### Property 4: Error resilience during scanning

*For any* scan failure or metadata parsing error, the system SHALL log the error and continue initialization with partial results rather than failing completely.

**Validates: Requirements 1.5, 7.1, 7.2**

### Property 5: Sequential phase logging

*For any* initialization phase, the system SHALL log phase start with number and description, and phase completion with relevant metrics.

**Validates: Requirements 2.2, 2.3**

### Property 6: Subsystem-specific message prefixes

*For any* write cache manager log message, it SHALL be prefixed with "Write cache capacity tracking", and for any size tracker message, it SHALL be prefixed with "Cache size validation".

**Validates: Requirements 3.1, 3.2**

### Property 7: Capacity information completeness

*For any* capacity logging, the message SHALL include both absolute values (bytes) and percentage values for clarity.

**Validates: Requirements 3.3**

### Property 8: Cross-validation threshold behavior

*For any* write cache size discrepancy between subsystems, the system SHALL log a warning if discrepancy exceeds 5% and an error if it exceeds 20%.

**Validates: Requirements 4.2, 4.3**

### Property 9: Shared validation consistency

*For any* metadata validation operation, both WriteCacheManager and CacheSizeTracker SHALL use identical validation logic and produce consistent results.

**Validates: Requirements 5.1, 5.2, 5.3, 5.4**

### Property 10: Single file parsing optimization

*For any* metadata file during initialization, the system SHALL parse the file at most once and share the parsed results between subsystems.

**Validates: Requirements 6.2**

### Property 11: Graceful error continuation

*For any* subsystem initialization failure, the system SHALL log the failure and continue initializing other subsystems rather than aborting the entire process.

**Validates: Requirements 7.3**



### Property 13: Configuration respect

*For any* configuration setting (write_cache_enabled, actively_remove_cached_data, validation_enabled), the system SHALL pass the setting to appropriate subsystems and respect the configured behavior.

**Validates: Requirements 9.1, 9.2, 9.3**

### Property 14: Multi-instance lock coordination

*For any* multi-instance deployment, initialization SHALL acquire appropriate locks before scanning and release them properly on completion or failure.

**Validates: Requirements 10.1, 10.5**

### Property 15: Consistent cache state view

*For any* completed initialization across multiple instances, all instances SHALL have a consistent view of the cache state.

**Validates: Requirements 10.3**

## Implementation Strategy

### Phase 1: Shared Utilities

Create `src/cache_validator.rs` with shared validation logic:
- Metadata parsing with error recovery
- Directory scanning with parallel processing
- Size calculation utilities
- File filtering and categorization

### Phase 2: Scan Coordination

Implement `ObjectsScanResults` and coordinated scanning:
- Single directory traversal
- Metadata categorization by write_cached flag
- Error collection and reporting
- Performance metrics collection

### Phase 3: Initialization Coordinator

Create `CacheInitializationCoordinator`:
- Sequential phase execution
- Progress logging with clear indicators
- Subsystem initialization from shared scan results
- Error handling and recovery

### Phase 4: Cross-Validation

Implement consistency checking:
- Compare write cache sizes between subsystems
- Threshold-based warning and error logging
- Validation result reporting

### Phase 5: Integration

Update `CacheManager::initialize()`:
- Replace separate initialization with coordinated approach
- Add initialization summary logging

## Error Handling

### Scan Errors
- **Corrupted metadata**: Log error, skip file, continue scan
- **Permission denied**: Log error, skip directory, continue with accessible areas
- **Disk full**: Log error, continue with read-only operations

### Subsystem Errors
- **WriteCacheManager failure**: Log error, disable write caching, continue
- **CacheSizeTracker failure**: Log error, disable size tracking, continue
- **Cross-validation failure**: Log discrepancy, continue operation

### Recovery Strategies
- **Partial scan results**: Initialize subsystems with available data
- **Missing metadata**: Use directory scan as fallback
- **Lock acquisition failure**: Retry with exponential backoff, timeout after 30s

## Performance Considerations

### Optimization Techniques
- **Parallel file processing**: Process metadata files concurrently where safe
- **Lazy parsing**: Only parse metadata needed for enabled subsystems
- **Memory efficiency**: Stream large directory scans rather than loading all into memory
- **Early termination**: Stop processing if critical errors make continuation pointless

### Performance Metrics
- **Scan duration**: Time to traverse and process objects directory
- **Parse duration**: Time to parse all metadata files
- **Initialization duration**: Total time from start to completion
- **Memory usage**: Peak memory during initialization

## Testing Strategy

### Unit Tests
- Shared validation utilities with various metadata formats
- Scan result categorization and filtering
- Error handling for corrupted files and directories
- Cross-validation threshold calculations

### Property-Based Tests

Using `quickcheck` framework with minimum 100 iterations per property.

**Property 1: Single directory scan coordination**
```rust
#[quickcheck]
fn prop_single_directory_scan(metadata_files: Vec<String>) -> TestResult {
    // Verify exactly one directory traversal occurs during initialization
}
```

**Property 8: Cross-validation threshold behavior**
```rust
#[quickcheck]
fn prop_cross_validation_thresholds(
    write_cache_size: u64, 
    tracker_size: u64
) -> TestResult {
    // Verify warning/error thresholds are correctly applied
}
```

**Property 9: Shared validation consistency**
```rust
#[quickcheck]
fn prop_shared_validation_consistency(metadata: CacheMetadata) -> TestResult {
    // Verify both subsystems produce identical validation results
}
```

### Integration Tests
- Full initialization with various cache states
- Multi-instance coordination with shared volumes
- Configuration-driven behavior testing

### Performance Tests
- Large cache directory scanning (10k+ objects)
- Concurrent initialization across multiple instances
- Memory usage during initialization
- Initialization time regression testing

## Configuration

### New Configuration Options

```yaml
cache:
  # Existing options remain unchanged
  
  # New initialization options
  initialization:
    parallel_scan: true              # Enable parallel metadata processing
    scan_timeout: "30s"              # Timeout for directory scanning
    cross_validation: true           # Enable subsystem cross-validation
    validation_threshold_warn: 5.0   # Warning threshold for discrepancies (%)
    validation_threshold_error: 20.0 # Error threshold for discrepancies (%)
    progress_logging: true           # Enable detailed progress logging
```



## Migration Strategy

### Deployment Steps
1. **Deploy with feature flag**: New initialization behind `coordinated_init` flag
2. **Gradual rollout**: Enable on subset of instances for testing
3. **Monitor metrics**: Compare initialization times and error rates
4. **Full deployment**: Enable by default after validation
5. **Cleanup**: Remove old initialization code after stable period

### Rollback Plan
- Feature flag allows instant rollback to old initialization
- No cache data format changes required
- Existing functionality remains unchanged
- Monitoring alerts on initialization failures

This design provides coordinated cache initialization while preserving architectural separation.