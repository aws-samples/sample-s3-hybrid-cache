# Requirements Document: Unified Range Storage for Write Cache

## Introduction

The current system uses two different storage formats: write cache stores complete objects in `write_cache/` directory, while GET cache uses the new range storage architecture with separate metadata and binary files. This inconsistency prevents write-cached objects from serving range requests efficiently and requires data copying during TTL transitions. This feature unifies all cached data (write cache, multipart uploads, and GET cache) to use the same range storage architecture, enabling range request support for PUT-cached objects and eliminating transition overhead.

## Glossary

- **Write Cache**: Cache for objects stored during PUT operations, using PUT_TTL for expiration
- **Range Storage Architecture**: New storage format with lightweight metadata files (`.meta`) and separate binary range files (`.bin`)
- **PUT_TTL**: Time-to-live for write-cached objects (shorter than GET_TTL to avoid caching write-once objects)
- **GET_TTL**: Time-to-live for read-cached objects (longer, optimized for repeated reads)
- **TTL Transition**: Converting a write-cached object to use GET_TTL when first accessed via GET request
- **Multipart Upload**: S3 operation where large objects are uploaded in multiple parts
- **Upload State**: Status of a multipart upload (InProgress, Complete, or Bypassed)
- **Capacity-Aware Caching**: Bypassing cache for uploads that would exceed write cache capacity limits

## Requirements

### Requirement 1: Write Cache as Range Storage

**User Story:** As a cache system, I want to store PUT-cached objects using range storage format, so that they can serve range requests without fetching from S3.

#### Acceptance Criteria

1. WHEN storing a PUT request body, THEN the Cache System SHALL store it as range 0 to content_length-1 using the range storage architecture
2. WHEN storing a PUT-cached object, THEN the Cache System SHALL create a metadata file in `objects/` directory
3. WHEN storing a PUT-cached object, THEN the Cache System SHALL create a binary range file in `ranges/` directory
4. THE Cache System SHALL use PUT_TTL for write-cached object expiration
5. THE Cache System SHALL mark write-cached objects with upload_state = Complete in metadata
6. THE Cache System SHALL NOT store PUT-cached objects in RAM cache (disk only)

### Requirement 2: Range Request Support for Write Cache

**User Story:** As a client, I want to request byte ranges from PUT-cached objects, so that I can efficiently access partial content without full object retrieval.

#### Acceptance Criteria

1. WHEN a GET request with Range header targets a PUT-cached object, THEN the Cache System SHALL serve the requested range from cache
2. WHEN serving a range from write cache, THEN the Cache System SHALL not fetch the entire object from S3
3. WHEN a range request is served from write cache, THEN the Cache System SHALL return correct Content-Range headers
4. THE Cache System SHALL support multiple range requests from the same PUT-cached object
5. WHEN serving the first GET request (full or range) from write cache, THEN the Cache System SHALL transition the object to GET_TTL

### Requirement 3: Selective TTL Transition on Access

**User Story:** As a cache system, I want to transition write-cached objects to GET_TTL only when accessed via GET, so that unread write-cached objects expire quickly.

#### Acceptance Criteria

1. WHEN a GET request accesses a write-cached object (upload_state = Complete, using PUT_TTL), THEN the Cache System SHALL transition it to GET_TTL
2. WHEN transitioning from PUT_TTL to GET_TTL, THEN the Cache System SHALL only update the metadata file
3. WHEN transitioning TTL, THEN the Cache System SHALL not copy or move range binary files
4. WHEN a write-cached object is never accessed via GET, THEN the Cache System SHALL let it expire using PUT_TTL
5. THE Cache System SHALL complete TTL transitions in under 10 milliseconds

### Requirement 4: Multipart Upload Initiation

**User Story:** As a cache system, I want to track multipart uploads, so that I can cache parts as they arrive.

#### Acceptance Criteria

1. WHEN receiving CreateMultipartUpload request, THEN the Cache System SHALL create metadata with upload_state = InProgress
2. WHEN initiating multipart upload, THEN the Cache System SHALL invalidate any existing cached data for that key
3. WHEN initiating multipart upload, THEN the Cache System SHALL initialize an empty parts list in metadata
4. THE Cache System SHALL set cumulative_size to 0 for new multipart uploads
5. THE Cache System SHALL not check total capacity at initiation (total size unknown until completion)

### Requirement 5: Multipart Part Storage

**User Story:** As a cache system, I want to store multipart parts as they arrive, so that completed uploads can serve range requests.

#### Acceptance Criteria

1. WHEN receiving an UploadPart request, THEN the Cache System SHALL store the part info (number, size, etag, data) in metadata
2. WHEN storing a part, THEN the Cache System SHALL increment cumulative_size by the part size
3. WHEN storing a part, THEN the Cache System SHALL support out-of-order part arrivals
4. THE Cache System SHALL store parts temporarily in metadata until CompleteMultipartUpload
5. THE Cache System SHALL not calculate byte positions until CompleteMultipartUpload (positions depend on all part sizes)

### Requirement 6: Capacity-Aware Multipart Caching

**User Story:** As a cache system, I want to bypass caching for oversized multipart uploads, so that cache capacity limits are respected.

#### Acceptance Criteria

1. WHEN a part would cause cumulative_size to exceed write cache capacity, THEN the Cache System SHALL mark upload as Bypassed
2. WHEN marking upload as Bypassed, THEN the Cache System SHALL invalidate any already-cached parts for that upload
3. WHEN upload is marked Bypassed, THEN the Cache System SHALL not cache subsequent parts
4. THE Cache System SHALL check capacity incrementally as each part arrives
5. THE Cache System SHALL log when uploads are bypassed due to capacity constraints

### Requirement 7: Multipart Upload Completion

**User Story:** As a cache system, I want to assemble multipart parts into ranges on completion, so that the object can serve range requests.

#### Acceptance Criteria

1. WHEN receiving CompleteMultipartUpload request, THEN the Cache System SHALL sort parts by part number
2. WHEN completing multipart upload, THEN the Cache System SHALL calculate byte positions from part sizes
3. WHEN completing multipart upload, THEN the Cache System SHALL store each part as a range at its calculated position
4. WHEN completing multipart upload, THEN the Cache System SHALL update upload_state to Complete
5. WHEN completing multipart upload, THEN the Cache System SHALL clear temporary part data from metadata and set expires_at using PUT_TTL

### Requirement 7a: Incomplete Upload Cleanup

**User Story:** As a cache system, I want to clean up incomplete multipart uploads, so that abandoned uploads don't consume cache space indefinitely.

#### Acceptance Criteria

1. WHEN a multipart upload remains in InProgress state for more than 1 hour, THEN the Cache System SHALL remove it from cache
2. WHEN cleaning up incomplete uploads, THEN the Cache System SHALL delete the metadata file and any cached part data
3. THE Cache System SHALL check for incomplete uploads during periodic cache maintenance
4. THE Cache System SHALL log cleanup of incomplete uploads for monitoring
5. THE Cache System SHALL use a configurable timeout for incomplete upload cleanup (default: 1 hour)

### Requirement 8: Conflict Handling

**User Story:** As a cache system, I want to invalidate cached data when new uploads start, so that cache remains consistent with S3.

#### Acceptance Criteria

1. WHEN receiving PutObject request, THEN the Cache System SHALL invalidate any existing cached data for that key
2. WHEN receiving CreateMultipartUpload request, THEN the Cache System SHALL invalidate any existing cached data for that key
3. WHEN invalidating on conflict, THEN the Cache System SHALL delete metadata and all associated range files
4. THE Cache System SHALL handle conflicts for both in-progress and completed uploads
5. THE Cache System SHALL log conflict invalidations for monitoring

### Requirement 9: Metadata Structure Updates

**User Story:** As a cache system, I want metadata to track upload state and parts, so that multipart uploads can be managed correctly.

#### Acceptance Criteria

1. THE Cache System SHALL add upload_state field to metadata (InProgress, Complete, Bypassed)
2. THE Cache System SHALL add cumulative_size field to track running total of cached part sizes
3. THE Cache System SHALL add parts list to metadata for storing temporary part information
4. THE Cache System SHALL include part_number, size, etag, and data in each PartInfo entry
5. THE Cache System SHALL clear parts list after CompleteMultipartUpload (data moved to range files)

### Requirement 10: Range Request Correctness

**User Story:** As a client, I want range requests to return correct data, so that partial content retrieval works reliably.

#### Acceptance Criteria

1. WHEN serving a range from write cache, THEN the Cache System SHALL return exactly the requested byte range
2. WHEN serving a range, THEN the Cache System SHALL set Content-Range header with correct start, end, and total size
3. WHEN serving a range, THEN the Cache System SHALL set Content-Length header to range size
4. WHEN serving a range, THEN the Cache System SHALL set status code 206 Partial Content
5. THE Cache System SHALL validate range boundaries before serving

### Requirement 11: Performance Requirements

**User Story:** As a system operator, I want write cache operations to remain fast, so that PUT performance is not degraded.

#### Acceptance Criteria

1. THE Cache System SHALL complete PUT caching in under 50 milliseconds for objects under 10MB
2. THE Cache System SHALL complete TTL transitions in under 10 milliseconds
3. THE Cache System SHALL complete multipart part storage in under 20 milliseconds per part
4. THE Cache System SHALL not introduce more than 5% overhead compared to old write cache format
5. THE Cache System SHALL maintain sub-10ms metadata parsing for objects with up to 100 parts

### Requirement 12: Testing Requirements

**User Story:** As a developer, I want comprehensive tests for unified range storage, so that correctness is verified.

#### Acceptance Criteria

1. THE Cache System SHALL include unit tests for write cache as range storage
2. THE Cache System SHALL include tests for range requests from write cache
3. THE Cache System SHALL include tests for TTL transitions without data copying
4. THE Cache System SHALL include tests for multipart uploads with out-of-order parts
5. THE Cache System SHALL include tests for capacity-aware bypass logic
6. THE Cache System SHALL include tests for conflict invalidation
7. THE Cache System SHALL include integration tests for complete multipart upload flows
8. THE Cache System SHALL include tests for incomplete upload cleanup after timeout

