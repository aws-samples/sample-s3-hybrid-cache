# Implementation Plan: Unified Range Storage for Write Cache

- [x] 1. Add UploadState enum and update ObjectMetadata
  - Create `UploadState` enum with variants: Complete, InProgress, Bypassed
  - Add `upload_state: UploadState` field to `ObjectMetadata` in `src/disk_cache.rs`
  - Add `cumulative_size: u64` field to track running total of cached part sizes
  - Add `parts: Vec<PartInfo>` field for temporary part storage
  - Create `PartInfo` struct with fields: part_number, size, etag, data
  - Update serialization/deserialization
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 2. Update write cache storage to use range format
  - Modify `store_write_cache_entry()` in `src/cache.rs` to use `store_full_object_as_range()`
  - Store PUT body as range 0 to content_length-1
  - Set `upload_state = Complete` in metadata
  - Use PUT_TTL for expiration
  - Remove old write_cache directory logic
  - Ensure PUT-cached objects are NOT stored in RAM cache
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

- [ ]* 2.1 Write property test for write cache range storage
  - **Property 1: Write Cache Range Storage**
  - **Validates: Requirements 1.1, 1.2, 1.3**

- [x] 3. Implement range request support for write cache
  - Update `get_cached_response()` to serve ranges from PUT-cached objects
  - Verify range requests don't fetch from S3
  - Set correct Content-Range headers
  - Return 206 Partial Content status
  - _Requirements: 2.1, 2.2, 2.3, 2.4_

- [ ]* 3.1 Write property test for range requests from write cache
  - **Property 2: Range Request from Write Cache**
  - **Validates: Requirements 2.1, 2.2**

- [x] 4. Simplify TTL transition logic
  - Update `transition_to_get_ttl()` to only update metadata
  - Remove data copying logic
  - Update expires_at timestamp to use GET_TTL
  - Verify no range files are copied or moved
  - Trigger transition on first GET request (full or range)
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [ ]* 4.1 Write property test for TTL transition without copying
  - **Property 3: TTL Transition Without Copying**
  - **Validates: Requirements 3.2, 3.3**

- [x] 5. Implement multipart upload initiation
  - Create `initiate_multipart_upload()` method in `src/cache.rs`
  - Invalidate any existing cached data for the key
  - Create metadata with `upload_state = InProgress`
  - Initialize empty parts list and cumulative_size = 0
  - Set 1-hour expiration for incomplete uploads
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

- [x] 6. Implement multipart part storage
  - Create `store_multipart_part()` method in `src/cache.rs`
  - Store part info (number, size, etag, data) in metadata
  - Increment cumulative_size by part size
  - Support out-of-order part arrivals
  - Store parts temporarily in metadata (not as ranges yet)
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 7. Implement capacity-aware caching for multipart
  - Check if cumulative_size + new_part_size exceeds write cache capacity
  - Mark upload as Bypassed if capacity exceeded
  - Invalidate already-cached parts when marking as Bypassed
  - Skip caching subsequent parts for Bypassed uploads
  - Log capacity bypass events
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5_

- [ ]* 7.1 Write property test for capacity bypass
  - **Property 5: Capacity Bypass**
  - **Validates: Requirements 6.1, 6.2, 6.3**

- [x] 8. Implement multipart upload completion
  - Create `complete_multipart_upload()` method in `src/cache.rs`
  - Sort parts by part number
  - Calculate byte positions from part sizes
  - Store each part as a range at calculated position
  - Update upload_state to Complete
  - Clear temporary part data from metadata
  - Set expires_at using PUT_TTL
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [ ]* 8.1 Write property test for multipart part order independence
  - **Property 4: Multipart Part Order Independence**
  - **Validates: Requirements 5.3, 7.1, 7.2**

- [x] 9. Implement conflict invalidation
  - Update PutObject handler to invalidate existing cache before storing
  - Update CreateMultipartUpload handler to invalidate existing cache
  - Delete metadata and all associated range files
  - Handle both in-progress and completed uploads
  - Log conflict invalidations
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [ ]* 9.1 Write property test for conflict invalidation
  - **Property 6: Conflict Invalidation**
  - **Validates: Requirements 8.1, 8.2, 8.3**

- [x] 10. Implement incomplete upload cleanup
  - Create `cleanup_incomplete_uploads()` method in `src/cache.rs`
  - Scan for uploads with upload_state = InProgress
  - Check if created_at is older than 1 hour
  - Invalidate metadata and cached parts for old incomplete uploads
  - Log cleanup operations
  - Call from periodic cache maintenance
  - _Requirements: 7a.1, 7a.2, 7a.3, 7a.4, 7a.5_

- [ ]* 10.1 Write property test for incomplete upload cleanup
  - **Property 7: Incomplete Upload Cleanup**
  - **Validates: Requirements 7a.1, 7a.2**

- [x] 11. Add helper method for write cache capacity
  - Create `get_write_cache_capacity()` method
  - Calculate from total cache size and write_cache_percent
  - Use in capacity checking logic
  - _Requirements: 6.1_

- [x] 12. Update HTTP proxy handlers
  - Update PUT request handler to use new write cache storage
  - Update CreateMultipartUpload handler to call initiate method
  - Update UploadPart handler to call store_multipart_part method
  - Update CompleteMultipartUpload handler to call complete method
  - Ensure conflict invalidation is triggered
  - _Requirements: 1.1, 4.1, 5.1, 7.1, 8.1_

- [x] 13. Add unit tests for write cache
  - Test PUT storage creates correct metadata and range files
  - Test upload_state is set to Complete
  - Test PUT_TTL is used for expiration
  - Test PUT-cached objects are not in RAM cache
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

- [ ]* 14. Add integration tests for multipart uploads
  - Test complete multipart flow with 10 parts
  - Test out-of-order part arrivals
  - Test capacity bypass for large uploads
  - Test incomplete upload cleanup after timeout
  - Test conflict invalidation scenarios
  - _Requirements: 5.3, 6.1, 7.1, 7a.1, 8.1_

- [x] 15. Update documentation
  - Update `docs/CACHING.md` with unified range storage information
  - Document multipart upload caching behavior
  - Document capacity-aware bypass logic
  - Document incomplete upload cleanup
  - Remove references to old write_cache directory
  - _Requirements: Documentation_

- [x] 16. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ]* 17. Performance testing
  - Measure PUT caching performance (target: <50ms for 10MB)
  - Measure TTL transition performance (target: <10ms)
  - Measure multipart part storage (target: <20ms per part)
  - Verify no more than 5% overhead vs old format
  - Verify sub-10ms metadata parsing for 100 parts
  - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5_

- [x] 18. Final checkpoint - Verify all requirements met
  - Ensure all tests pass, ask the user if questions arise.

