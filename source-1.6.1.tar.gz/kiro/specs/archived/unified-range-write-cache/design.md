# Design Document: Unified Range Storage for Write Cache

## Overview

This design unifies all cached data (write cache, multipart uploads, and GET cache) to use the same range storage architecture. Currently, write cache stores complete objects in a separate `write_cache/` directory, preventing range request support and requiring data copying during TTL transitions. By storing all data as ranges, we enable range requests from PUT-cached objects, eliminate transition overhead, and simplify the codebase with a single storage format.

## Architecture

### Current Architecture (Before)

```
Write Cache (PUT):
  write_cache/{key}.cache  → Full object body
  write_cache/{key}.meta   → Metadata
  
GET Cache:
  objects/{key}.meta       → Lightweight metadata + range index
  ranges/{key}_0-N.bin     → Range data

Problem: Two different formats, no range support for PUT cache
```

### New Architecture (After)

```
Unified Storage:
  objects/{key}.meta       → Metadata (upload_state, TTL, range index)
  ranges/{key}_0-N.bin     → Range data (from PUT, GET, or multipart)

Benefits: Single format, range support everywhere, no copying
```

### Storage Flow Comparison

**Before:**
```
PUT → write_cache/{key}.cache (full object)
GET (first time) → Copy to ranges/{key}_0-N.bin
GET (range) → Serve from ranges/
```

**After:**
```
PUT → ranges/{key}_0-N.bin (as range)
GET (any) → Serve from ranges/ (already there)
TTL transition → Update metadata only (no copying)
```

## Components and Interfaces

### 1. Write Cache Storage (Updated)

```rust
impl CacheManager {
    /// Store PUT request body as range
    pub async fn store_write_cache_entry(
        &self,
        cache_key: &str,
        response_body: &[u8],
        headers: HashMap<String, String>,
        metadata: CacheMetadata,
    ) -> Result<()> {
        let content_length = response_body.len() as u64;
        
        // Create object metadata
        let object_metadata = ObjectMetadata {
            etag: metadata.etag.clone(),
            last_modified: metadata.last_modified.clone(),
            content_length,
            content_type: headers.get("content-type").cloned(),
            version_id: metadata.version_id.clone(),
            upload_state: UploadState::Complete,  // NEW: Mark as complete PUT
            cumulative_size: content_length,
            parts: Vec::new(),
        };
        
        // Store as range 0 to content_length-1
        let mut disk_cache = self.disk_cache_manager.lock().await;
        disk_cache.store_full_object_as_range(
            cache_key,
            response_body,
            object_metadata,
        ).await?;
        
        // Set PUT_TTL expiration
        let now = SystemTime::now();
        disk_cache.update_metadata_expiration(
            cache_key,
            now + self.put_ttl,
        ).await?;
        
        info!("Stored PUT-cached object as range: {} ({} bytes)", cache_key, content_length);
        Ok(())
    }
}
```

### 2. TTL Transition (Simplified)

```rust
impl CacheManager {
    /// Transition from PUT_TTL to GET_TTL (metadata-only update)
    pub async fn transition_to_get_ttl(&self, cache_key: &str) -> Result<()> {
        let mut disk_cache = self.disk_cache_manager.lock().await;
        
        // Check if this is a PUT-cached object
        if let Some(mut metadata) = disk_cache.get_metadata(cache_key).await? {
            // Check if using PUT_TTL (expires soon)
            let now = SystemTime::now();
            let time_until_expiry = metadata.expires_at.duration_since(now).unwrap_or_default();
            
            // If expires within PUT_TTL window, transition to GET_TTL
            if time_until_expiry < self.put_ttl {
                metadata.expires_at = now + self.get_ttl;
                disk_cache.update_metadata(cache_key, metadata).await?;
                debug!("Transitioned {} from PUT_TTL to GET_TTL", cache_key);
            }
        }
        
        Ok(())
    }
}
```

### 3. Multipart Upload Management

```rust
/// Upload state for multipart tracking
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum UploadState {
    Complete,      // Regular PUT or completed multipart
    InProgress,    // Multipart upload in progress
    Bypassed,      // Upload too large, not caching
}

/// Part information stored temporarily during upload
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PartInfo {
    pub part_number: u32,
    pub size: u64,
    pub etag: String,
    pub data: Vec<u8>,  // Temporary storage until CompleteMultipartUpload
}

impl CacheManager {
    /// Initiate multipart upload
    pub async fn initiate_multipart_upload(
        &self,
        path: &str,
        version_id: Option<&str>,
    ) -> Result<()> {
        let cache_key = if let Some(version) = version_id {
            Self::generate_versioned_cache_key(path, version)
        } else {
            Self::generate_cache_key(path)
        };
        
        let mut disk_cache = self.disk_cache_manager.lock().await;
        
        // Invalidate any existing cached data
        disk_cache.invalidate(&cache_key).await?;
        
        // Create metadata for in-progress upload
        let metadata = ObjectMetadata {
            upload_state: UploadState::InProgress,
            cumulative_size: 0,
            parts: Vec::new(),
            created_at: SystemTime::now(),
            expires_at: SystemTime::now() + Duration::from_secs(3600), // 1 hour for incomplete
            ..Default::default()
        };
        
        disk_cache.create_metadata(&cache_key, metadata).await?;
        info!("Initiated multipart upload for: {}", cache_key);
        Ok(())
    }
    
    /// Store multipart part
    pub async fn store_multipart_part(
        &self,
        path: &str,
        part_number: u32,
        version_id: Option<&str>,
        part_data: &[u8],
        metadata: CacheMetadata,
    ) -> Result<()> {
        let cache_key = if let Some(version) = version_id {
            Self::generate_versioned_cache_key(path, version)
        } else {
            Self::generate_cache_key(path)
        };
        
        let mut disk_cache = self.disk_cache_manager.lock().await;
        
        // Get current metadata
        let mut obj_metadata = match disk_cache.get_metadata(&cache_key).await? {
            Some(meta) if meta.upload_state == UploadState::InProgress => meta,
            Some(meta) if meta.upload_state == UploadState::Bypassed => {
                debug!("Upload {} is bypassed, skipping part {}", cache_key, part_number);
                return Ok(());
            }
            _ => {
                warn!("No in-progress upload found for {}", cache_key);
                return Ok(());
            }
        };
        
        // Check capacity
        let part_size = part_data.len() as u64;
        let new_cumulative = obj_metadata.cumulative_size + part_size;
        
        if new_cumulative > self.get_write_cache_capacity() {
            // Bypass this upload
            warn!("Upload {} exceeds capacity ({} bytes), bypassing", cache_key, new_cumulative);
            obj_metadata.upload_state = UploadState::Bypassed;
            obj_metadata.parts.clear();  // Drop cached parts
            disk_cache.update_metadata(&cache_key, obj_metadata).await?;
            return Ok(());
        }
        
        // Store part info
        let part_info = PartInfo {
            part_number,
            size: part_size,
            etag: metadata.etag.clone(),
            data: part_data.to_vec(),
        };
        
        obj_metadata.parts.push(part_info);
        obj_metadata.cumulative_size = new_cumulative;
        disk_cache.update_metadata(&cache_key, obj_metadata).await?;
        
        debug!("Stored part {} for {} ({} bytes, cumulative: {})", 
               part_number, cache_key, part_size, new_cumulative);
        Ok(())
    }
    
    /// Complete multipart upload
    pub async fn complete_multipart_upload(
        &self,
        path: &str,
        version_id: Option<&str>,
    ) -> Result<()> {
        let cache_key = if let Some(version) = version_id {
            Self::generate_versioned_cache_key(path, version)
        } else {
            Self::generate_cache_key(path)
        };
        
        let mut disk_cache = self.disk_cache_manager.lock().await;
        
        let mut metadata = match disk_cache.get_metadata(&cache_key).await? {
            Some(meta) if meta.upload_state == UploadState::InProgress => meta,
            _ => {
                debug!("No in-progress upload to complete for {}", cache_key);
                return Ok(());
            }
        };
        
        // Sort parts by part number
        metadata.parts.sort_by_key(|p| p.part_number);
        
        // Calculate byte positions and store each part as a range
        let mut current_position = 0u64;
        for part in &metadata.parts {
            let start = current_position;
            let end = start + part.size - 1;
            
            // Store this part as a range
            disk_cache.store_range(
                &cache_key,
                start,
                end,
                &part.data,
                metadata.clone(),
            ).await?;
            
            current_position += part.size;
        }
        
        // Update metadata
        metadata.upload_state = UploadState::Complete;
        metadata.content_length = current_position;
        metadata.expires_at = SystemTime::now() + self.put_ttl;
        metadata.parts.clear();  // Clear temporary part data
        
        disk_cache.update_metadata(&cache_key, metadata).await?;
        
        info!("Completed multipart upload for {} ({} bytes)", cache_key, current_position);
        Ok(())
    }
    
    /// Clean up incomplete uploads older than timeout
    pub async fn cleanup_incomplete_uploads(&self) -> Result<u64> {
        let mut disk_cache = self.disk_cache_manager.lock().await;
        let now = SystemTime::now();
        let timeout = Duration::from_secs(3600); // 1 hour
        let mut cleaned = 0u64;
        
        // Scan for incomplete uploads
        let entries = disk_cache.list_all_metadata().await?;
        
        for (cache_key, metadata) in entries {
            if metadata.upload_state == UploadState::InProgress {
                if let Ok(age) = now.duration_since(metadata.created_at) {
                    if age > timeout {
                        disk_cache.invalidate(&cache_key).await?;
                        cleaned += 1;
                        info!("Cleaned up incomplete upload: {} (age: {:?})", cache_key, age);
                    }
                }
            }
        }
        
        if cleaned > 0 {
            info!("Cleaned up {} incomplete uploads", cleaned);
        }
        
        Ok(cleaned)
    }
}
```

## Data Models

### Updated ObjectMetadata

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub content_type: Option<String>,
    pub version_id: Option<String>,
    pub created_at: SystemTime,
    pub expires_at: SystemTime,
    
    // NEW: Upload state tracking
    pub upload_state: UploadState,
    
    // NEW: Multipart upload tracking
    pub cumulative_size: u64,
    pub parts: Vec<PartInfo>,
}
```

### Metadata File Example

```json
{
  "etag": "abc123",
  "last_modified": "2024-01-15T10:30:00Z",
  "content_length": 15728640,
  "content_type": "application/octet-stream",
  "version_id": null,
  "created_at": "2024-01-15T10:30:00Z",
  "expires_at": "2024-01-15T11:30:00Z",
  "upload_state": "Complete",
  "cumulative_size": 15728640,
  "parts": [],
  "ranges": [
    {
      "start": 0,
      "end": 15728639,
      "file_path": "bucket_object_0-15728639.bin",
      "compression_algorithm": "Lz4",
      "compressed_size": 8000000,
      "uncompressed_size": 15728640
    }
  ]
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Write Cache Range Storage

*For any* PUT request body, it SHALL be stored as range 0 to content_length-1 in the range storage architecture.

**Validates: Requirements 1.1, 1.2, 1.3**

### Property 2: Range Request from Write Cache

*For any* GET request with Range header targeting a PUT-cached object, the requested range SHALL be served from cache without fetching from S3.

**Validates: Requirements 2.1, 2.2**

### Property 3: TTL Transition Without Copying

*For any* TTL transition from PUT_TTL to GET_TTL, only the metadata file SHALL be modified, and no range binary files SHALL be copied or moved.

**Validates: Requirements 3.2, 3.3**

### Property 4: Multipart Part Order Independence

*For any* multipart upload, parts SHALL be stored correctly regardless of arrival order, with byte positions calculated on completion.

**Validates: Requirements 5.3, 7.1, 7.2**

### Property 5: Capacity Bypass

*For any* multipart upload where cumulative_size exceeds write cache capacity, the upload SHALL be marked as Bypassed and no further parts SHALL be cached.

**Validates: Requirements 6.1, 6.2, 6.3**

### Property 6: Conflict Invalidation

*For any* new PutObject or CreateMultipartUpload to an existing cache key, all existing cached data for that key SHALL be invalidated.

**Validates: Requirements 8.1, 8.2, 8.3**

### Property 7: Incomplete Upload Cleanup

*For any* multipart upload in InProgress state for more than 1 hour, it SHALL be removed from cache during maintenance.

**Validates: Requirements 7a.1, 7a.2**

### Property 8: PUT Cache Disk Only

*For any* PUT-cached object, it SHALL NOT be stored in RAM cache, only in disk cache.

**Validates: Requirements 1.6**

## Error Handling

### Multipart Upload Errors

- **Part storage failure**: Log error, mark upload as Bypassed
- **Capacity exceeded**: Mark as Bypassed, clean up cached parts
- **Completion failure**: Leave in InProgress state, cleanup after timeout

### TTL Transition Errors

- **Metadata update failure**: Log error, retry on next access
- **Metadata missing**: Treat as cache miss, fetch from S3

### Conflict Handling

- **Invalidation failure**: Log error, continue with new upload
- **Partial cleanup**: Best effort, orphaned files cleaned by maintenance

## Testing Strategy

### Unit Tests

1. **Write Cache as Range**: Test PUT storage creates correct metadata and range files
2. **Range Requests**: Test GET with Range header from PUT-cached objects
3. **TTL Transition**: Test metadata-only updates without file copying
4. **Multipart Out-of-Order**: Test parts arriving in random order
5. **Capacity Bypass**: Test uploads exceeding capacity are bypassed
6. **Conflict Invalidation**: Test new uploads invalidate existing cache

### Property-Based Tests

Using `quickcheck` with minimum 100 iterations:

1. **Property 1: Write Cache Range Storage**
   - Generate random PUT bodies
   - Verify stored as range 0-N
   - **Feature: unified-range-write-cache, Property 1: Write Cache Range Storage**

2. **Property 2: Range Request from Write Cache**
   - Generate random range requests
   - Verify served from cache without S3 fetch
   - **Feature: unified-range-write-cache, Property 2: Range Request from Write Cache**

3. **Property 4: Multipart Part Order Independence**
   - Generate random part orderings
   - Verify correct assembly regardless of order
   - **Feature: unified-range-write-cache, Property 4: Multipart Part Order Independence**

### Integration Tests

1. **Complete Multipart Flow**: Test full upload with 10 parts
2. **Incomplete Upload Cleanup**: Test timeout-based cleanup
3. **Capacity Management**: Test large upload bypass
4. **Conflict Scenarios**: Test overlapping uploads

## Performance Impact

### Expected Improvements

- ✅ **Range requests from PUT cache**: No S3 fetch needed
- ✅ **TTL transition**: 10ms vs 100ms+ (no copying)
- ✅ **Unified code paths**: Reduced complexity

### Neutral

- ≈ **Storage overhead**: Similar (metadata slightly larger)
- ≈ **Write performance**: Similar (same compression)

### Monitoring

- Track TTL transitions per second
- Track multipart uploads bypassed due to capacity
- Track incomplete upload cleanups

## Implementation Notes

### Phase 1: Write Cache as Ranges (2-3 hours)

1. Update `store_write_cache_entry()` to use `store_full_object_as_range()`
2. Add `upload_state` field to metadata
3. Test range requests from write cache

### Phase 2: TTL Transitions (1-2 hours)

1. Update `transition_to_get_ttl()` to only update metadata
2. Remove data copying logic
3. Test transition performance

### Phase 3: Multipart Support (5-7 hours)

1. Add `PartInfo` struct and multipart methods
2. Implement capacity checking
3. Implement completion assembly
4. Add incomplete upload cleanup
5. Test complete flows

## Migration Strategy

**No backward compatibility needed** - cache can be cleared on upgrade:

1. Stop proxy instances
2. Clear cache directory
3. Deploy new version
4. Restart instances

Cache will rebuild naturally as requests arrive.

