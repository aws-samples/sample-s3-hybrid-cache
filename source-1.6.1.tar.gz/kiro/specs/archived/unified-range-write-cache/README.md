# Unified Range Storage for Write Cache

## Overview

Unifies all cached data (write cache, multipart uploads, and GET cache) to use the same range storage architecture. Enables range request support for PUT-cached objects, eliminates TTL transition overhead, and simplifies the codebase with a single storage format.

## Problem Statement

Currently, the system uses two different storage formats:

- **Write cache**: Stores complete objects in `write_cache/` directory
- **GET cache**: Uses range storage with metadata in `objects/` and data in `ranges/`

This causes:
- ❌ PUT-cached objects cannot serve range requests
- ❌ TTL transitions require copying entire objects
- ❌ Two code paths for storage and retrieval
- ❌ Multipart uploads need special handling

## Solution

Store ALL cached data as ranges using the unified range storage architecture:

```
Before:
  write_cache/{key}.cache  → Full object
  objects/{key}.meta       → Metadata + range index
  ranges/{key}_0-N.bin     → Range data

After:
  objects/{key}.meta       → Metadata (upload_state, TTL, range index)
  ranges/{key}_0-N.bin     → ALL data (PUT, GET, multipart)
```

## Key Features

### ✅ Range Requests from Write Cache
PUT-cached objects can immediately serve range requests without fetching from S3.

### ✅ Zero-Copy TTL Transitions
Transitioning from PUT_TTL to GET_TTL only updates metadata (10ms vs 100ms+).

### ✅ Multipart as Single Object
Multipart parts stored as ranges within one logical object, automatically assembled on completion.

### ✅ Capacity-Aware Caching
Large multipart uploads that exceed capacity are automatically bypassed.

### ✅ Incomplete Upload Cleanup
Abandoned multipart uploads are cleaned up after 1 hour timeout.

### ✅ Conflict Handling
New uploads automatically invalidate existing cached data for the same key.

## Files

- `requirements.md` - 12 requirements with 60+ acceptance criteria
- `design.md` - Detailed design with 8 correctness properties
- `tasks.md` - 18 implementation tasks (8-12 hours estimated)

## Status

**Phase**: Requirements and Design Complete ✅

Ready for implementation in 3 phases:
1. **Phase 1**: Write cache as ranges (2-3 hours)
2. **Phase 2**: TTL transitions (1-2 hours)
3. **Phase 3**: Multipart support (5-7 hours)

## Benefits

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Range requests from PUT cache | ❌ Not supported | ✅ Supported | New capability |
| TTL transition time | ~100ms (copy) | ~10ms (metadata) | 10x faster |
| Code paths | 2 (write/read) | 1 (unified) | 50% reduction |
| Multipart support | Complex | Unified | Simplified |

## Related Specs

- `range-storage-redesign` - New range storage architecture (completed)
- `cache-key-simplification` - Simplified cache keys (completed)
- `distributed-eviction-lock` - Multi-instance coordination (ready)

