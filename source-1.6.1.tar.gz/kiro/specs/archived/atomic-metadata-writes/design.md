# Design Document: Atomic Metadata Writes

## Overview

This design addresses critical metadata consistency issues in the S3 proxy's shared cache system. The current system suffers from concurrent write failures that result in orphaned range files (range files exist but have no metadata entries), leading to cache misses and "Range file missing" errors.

The solution implements a hybrid approach combining immediate metadata updates with write-ahead journaling for resilience, enhanced stale lock detection, comprehensive validation, and background recovery mechanisms.

## Architecture

### Current System Issues

Analysis of production data reveals:
- **131 range files** exist for a 1GB object
- **Only 92 ranges** recorded in metadata 
- **30% failure rate** in concurrent metadata updates
- **Orphaned ranges** cause cache misses despite data being available

### Proposed Architecture

```mermaid
graph TB
    subgraph "Concurrent Range Writers"
        W1[Writer 1<br/>Range 0-8MB]
        W2[Writer 2<br/>Range 8-16MB]
        W3[Writer 3<br/>Range 16-24MB]
    end
    
    subgraph "Co-located Metadata & Journal Files"
        subgraph "objects/bucket/XX/YYY/"
            MF[object.meta<br/>Main Metadata]
            ML[object.meta.lock<br/>Enhanced Lock]
            J1[object.journal.instance1<br/>Journal Instance 1]
            J2[object.journal.instance2<br/>Journal Instance 2]
            J3[object.journal.instance3<br/>Journal Instance 3]
        end
    end
    
    subgraph "Background Processes"
        SC[Stale Lock Cleaner]
        JC[Journal Consolidator<br/>Processes All Journals]
        OR[Orphaned Range Recovery]
        
        SC --> ML
        JC --> MF
        JC --> J1
        JC --> J2
        JC --> J3
        OR --> MF
    end
    
    W1 --> ML
    W2 --> ML
    W3 --> ML
    
    W1 --> J1
    W2 --> J2
    W3 --> J3
    
    MF --> R[Range Readers<br/>Immediate Availability]
```

## Components and Interfaces

### 1. Enhanced Metadata Lock Manager

**Purpose**: Coordinate concurrent access with robust stale lock detection

**Key Features**:
- Process existence validation
- Lock age-based timeout detection
- Atomic lock breaking with consistency validation
- Exponential backoff with jitter

**Interface**:
```rust
pub struct MetadataLockManager {
    cache_dir: PathBuf,
    lock_timeout: Duration,
    max_retries: u32,
}

impl MetadataLockManager {
    pub async fn acquire_lock(&self, cache_key: &str) -> Result<MetadataLock>;
    pub async fn break_stale_lock(&self, lock_path: &Path) -> Result<bool>;
    pub async fn validate_lock_holder(&self, lock_path: &Path) -> Result<bool>;
}
```

### 2. Hybrid Metadata Writer

**Purpose**: Provide immediate availability with journaling backup

**Key Features**:
- Immediate metadata file updates for fast availability
- Concurrent journal writes for resilience
- Fallback to journal-only under high contention
- Atomic visibility control (metadata before range file rename)

**Interface**:
```rust
pub struct HybridMetadataWriter {
    lock_manager: Arc<MetadataLockManager>,
    journal_manager: Arc<JournalManager>,
    consolidation_trigger: Arc<ConsolidationTrigger>,
}

impl HybridMetadataWriter {
    pub async fn write_range_metadata(&mut self, 
        cache_key: &str, 
        range_spec: RangeSpec,
        write_mode: WriteMode
    ) -> Result<()>;
    
    // Full objects use optimized write mode (immediate-only unless high contention)
    pub async fn write_full_object_metadata(&mut self,
        cache_key: &str,
        object_metadata: ObjectMetadata,
    ) -> Result<()> {
        // Optimization: Full objects rarely need journaling since they don't have
        // the concurrent partial write issues that journals are designed to solve
        let write_mode = if self.is_high_contention(cache_key) {
            WriteMode::Hybrid  // Fall back to journaling under extreme contention
        } else {
            WriteMode::Immediate  // Default: immediate-only for better performance
        };
        
        let range_spec = RangeSpec {
            start: 0,
            end: object_metadata.content_length.saturating_sub(1),
            // ... other fields
        };
        self.write_range_metadata(cache_key, range_spec, write_mode).await
    }
    
    fn is_high_contention(&self, cache_key: &str) -> bool;
}

pub enum WriteMode {
    Immediate,      // Update metadata file immediately (no journal)
    JournalOnly,    // Journal-only under high contention
    Hybrid,         // Both immediate + journal (default for range operations)
}
```

### 3. Journal Manager

**Purpose**: Handle write-ahead journaling for metadata resilience

**Key Features**:
- Per-instance journal files co-located with metadata files
- Atomic journal entry writes using append operations
- Integration with multipart upload cleanup
- Validation of range file existence before consolidation

**Interface**:
```rust
pub struct JournalManager {
    cache_dir: PathBuf,
    instance_id: String,
    cleanup_integration: Arc<MultipartCleanupIntegration>,
}

impl JournalManager {
    pub async fn append_range_entry(&self, cache_key: &str, entry: JournalEntry) -> Result<()>;
    pub async fn get_pending_entries(&self, cache_key: &str) -> Result<Vec<JournalEntry>>;
    pub async fn find_all_journal_files(&self, cache_key: &str) -> Result<Vec<PathBuf>>;
    pub async fn remove_entries(&self, cache_key: &str, entries: &[JournalEntry]) -> Result<()>;
    pub async fn cleanup_for_multipart(&self, cache_key: &str) -> Result<()>;
    
    // Journal file path: cache_dir/objects/journals/{bucket}/{sanitized_object_key}.journal.{instance_id}
    fn get_journal_path(&self, cache_key: &str) -> PathBuf;
}

#[derive(Serialize, Deserialize)]
pub struct JournalEntry {
    pub timestamp: SystemTime,
    pub cache_key: String,
    pub range_spec: RangeSpec,
    pub operation: JournalOperation,
    pub range_file_path: String,
}

pub enum JournalOperation {
    Add,
    Update,
    Remove,
}
```

### 4. Journal Consolidator

**Purpose**: Background consolidation of journal entries into metadata

**Key Features**:
- Configurable consolidation intervals (default: 30 seconds)
- Threshold-based immediate consolidation
- Range file existence validation
- Conflict resolution between metadata and journal
- Discovery of all journal files co-located with metadata

**Interface**:
```rust
pub struct JournalConsolidator {
    journal_manager: Arc<JournalManager>,
    metadata_writer: Arc<HybridMetadataWriter>,
    config: ConsolidationConfig,
}

impl JournalConsolidator {
    pub async fn consolidate_object(&self, cache_key: &str) -> Result<ConsolidationResult>;
    pub async fn discover_pending_cache_keys(&self) -> Result<Vec<String>>;
    pub async fn discover_pending_for_bucket(&self, bucket: &str) -> Result<Vec<String>>;
    pub async fn validate_journal_entries(&self, entries: &[JournalEntry]) -> Vec<JournalEntry>;
    pub async fn resolve_conflicts(&self, metadata: &NewCacheMetadata, journal: &[JournalEntry]) -> Result<NewCacheMetadata>;
}

pub struct ConsolidationConfig {
    pub interval: Duration,
    pub size_threshold: u64,
    pub immediate_triggers: Vec<ConsolidationTrigger>,
}
```

### 5. Orphaned Range Recovery

**Purpose**: Detect and recover orphaned range files

**Key Features**:
- Background scanning for orphaned ranges
- Metadata rebuilding from valid range files
- Cleanup of invalid/corrupted ranges
- Priority-based recovery (access frequency)

**Interface**:
```rust
pub struct OrphanedRangeRecovery {
    cache_dir: PathBuf,
    metadata_writer: Arc<HybridMetadataWriter>,
    metrics: Arc<RecoveryMetrics>,
}

impl OrphanedRangeRecovery {
    pub async fn scan_for_orphans(&self, cache_key: &str) -> Result<Vec<OrphanedRange>>;
    pub async fn recover_orphan(&self, orphan: &OrphanedRange) -> Result<RecoveryResult>;
    pub async fn cleanup_invalid_orphan(&self, orphan: &OrphanedRange) -> Result<u64>;
}

pub struct OrphanedRange {
    pub cache_key: String,
    pub range_file_path: PathBuf,
    pub range_spec: Option<RangeSpec>,
    pub validation_status: ValidationStatus,
}

pub enum RecoveryResult {
    Recovered(RangeSpec),
    Cleaned(u64), // bytes freed
    Failed(String),
}
```

### 6. Metadata Validator

**Purpose**: Comprehensive metadata integrity validation

**Key Features**:
- JSON structure validation
- Range overlap detection
- Size consistency verification
- Timestamp validation

**Interface**:
```rust
pub struct MetadataValidator {
    cache_dir: PathBuf,
}

impl MetadataValidator {
    pub async fn validate_metadata(&self, metadata: &NewCacheMetadata) -> Result<ValidationResult>;
    pub async fn validate_ranges(&self, ranges: &[RangeSpec]) -> Result<RangeValidationResult>;
    pub async fn validate_consistency(&self, cache_key: &str) -> Result<ConsistencyResult>;
}

pub struct ValidationResult {
    pub is_valid: bool,
    pub errors: Vec<ValidationError>,
    pub warnings: Vec<ValidationWarning>,
}
```

## Data Models

### Enhanced Range Specification

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RangeSpec {
    pub start: u64,
    pub end: u64,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
    pub created_at: SystemTime,
    pub last_accessed: SystemTime,
    pub access_count: u64,
    pub expires_at: SystemTime,
    pub compression_algorithm: CompressionAlgorithm,
    pub checksum: Option<String>, // For integrity validation
}
```

### Full Object Handling

The system treats full objects uniformly as ranges, eliminating special casing:

- **Full Object Storage**: A complete object is stored as a single range from `0` to `content_length - 1`
- **Empty Objects**: Objects with zero content length have no ranges (empty ranges array in metadata)
- **Consistent Model**: All cached data is stored as ranges, whether from range requests or full object requests
- **Optimized Journaling**: Full objects use immediate-only writes by default, avoiding journal overhead since concurrent partial writes are rare for full objects
- **Recovery Compatibility**: Orphaned range recovery works identically for full objects and partial ranges

**Example**:
- 1MB object → Range: `start: 0, end: 1048575` (1048576 bytes total)
- Empty object → No ranges in metadata
- 500-byte range request → Range: `start: 500, end: 999` (500 bytes)

**Write Mode Optimization**:
- **Range Operations**: Use `Hybrid` mode by default (immediate + journal) to handle concurrent writes
- **Full Object Operations**: Use `Immediate` mode by default (no journal) for better performance
- **High Contention Fallback**: Both can fall back to journaling under extreme lock contention

This unified approach ensures that:
- Any range request can be served from a cached full object
- Full objects and ranges use identical storage and recovery mechanisms
- Journal consolidation handles full objects and ranges uniformly when journals are created
- Full objects avoid journaling overhead in the common case
- No special cases in metadata validation or orphaned range recovery

### Journal Entry Format

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JournalEntry {
    pub timestamp: SystemTime,
    pub instance_id: String,
    pub cache_key: String,
    pub range_spec: RangeSpec,
    pub operation: JournalOperation,
    pub range_file_path: String,
    pub metadata_version: u64, // For conflict resolution
}
```

### Lock File Format

```rust
#[derive(Debug, Serialize, Deserialize)]
pub struct LockFileContent {
    pub process_id: u32,
    pub instance_id: String,
    pub acquired_at: SystemTime,
    pub operation: String,
    pub cache_key: String,
}
```

### Journal File Storage Structure

Journal files are organized in a dedicated bucket-based directory structure for efficient discovery:

```
/mnt/efs/cache/
├── objects/
│   ├── journals/                                  # Journal directory
│   │   └── egummett-testing-source-1/            # Per-bucket journals
│   │       ├── bigfiles%2F1GB.journal.ip-172-31-34-221_24900
│   │       ├── bigfiles%2F1GB.journal.ip-172-31-45-123_25100
│   │       └── bigfiles%2F1GB.journal.ip-172-31-67-234_26200
│   └── egummett-testing-source-1/9c/5cf/         # Sharded metadata
│       ├── bigfiles%2F1GB.meta                   # Main metadata file
│       └── bigfiles%2F1GB.meta.lock              # Lock file
└── ranges/
    └── egummett-testing-source-1/9c/5cf/         # Sharded range files
        ├── bigfiles%2F1GB_0-8388607.bin
        └── bigfiles%2F1GB_8388608-16777215.bin
```

**Benefits of Journal Directory Structure**:
- **Efficient Discovery**: Consolidator scans `objects/journals/{bucket}/` directories to find pending entries
- **Bucket-scoped Operations**: Can process journals for specific buckets or all buckets
- **Scalable Organization**: Avoids thousands of journal files in a single directory
- **Easy Cleanup**: Simple to find and remove journal files during multipart upload cleanup
- **Clear Separation**: Journals are separate from metadata but logically organized by bucket

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Concurrent Write Consistency
*For any* set of concurrent range writes to the same object, all successfully written range files SHALL have corresponding metadata entries
**Validates: Requirements 1.1, 1.2**

### Property 2: Atomic Visibility
*For any* range write operation, the metadata entry SHALL be committed before the range file becomes visible (renamed from .tmp to .bin)
**Validates: Requirements 1.2**

### Property 3: Cleanup on Failure
*For any* failed metadata write operation, temporary range files SHALL be cleaned up to prevent orphaned files
**Validates: Requirements 1.3, 1.4**

### Property 4: Stale Lock Detection
*For any* metadata lock older than the configured timeout with a non-existent process, the lock SHALL be detected as stale and broken
**Validates: Requirements 2.1, 2.2**

### Property 5: Lock Breaking Coordination
*For any* stale lock detected by multiple instances simultaneously, only one instance SHALL successfully break the lock and proceed
**Validates: Requirements 2.5**

### Property 6: Hybrid Write Consistency
*For any* range write using hybrid mode, both the main metadata file and journal SHALL contain the range entry
**Validates: Requirements 3.1**

### Property 7: Immediate Availability
*For any* successfully written range, subsequent reads SHALL find the range in the main metadata file without checking journals
**Validates: Requirements 3.2**

### Property 8: Journal Consolidation Completeness
*For any* journal consolidation operation, all valid journal entries SHALL be merged into the main metadata file
**Validates: Requirements 4.2, 3.4**

### Property 9: Multipart Journal Cleanup
*For any* multipart upload cleanup due to timeout, all related journal entries SHALL be removed
**Validates: Requirements 5.1, 5.4**

### Property 10: Journal Validation
*For any* journal entry referencing a non-existent range file, the entry SHALL be removed during consolidation
**Validates: Requirements 5.2, 5.3**

### Property 11: Background Recovery Non-Blocking
*For any* background recovery operation, concurrent cache operations on other objects SHALL not be blocked
**Validates: Requirements 6.2**

### Property 12: Recovery Prioritization
*For any* multiple objects requiring recovery, objects with higher access frequency SHALL be recovered first
**Validates: Requirements 6.5**

### Property 13: Metadata Integrity Validation
*For any* metadata file read, JSON structure and required fields SHALL be validated
**Validates: Requirements 7.1**

### Property 14: Range Overlap Detection
*For any* metadata containing overlapping ranges, the overlap SHALL be detected and flagged as invalid
**Validates: Requirements 7.2**

### Property 15: Orphaned Range Detection
*For any* range file without a corresponding metadata entry, the orphan SHALL be detected during scanning
**Validates: Requirements 8.1**

### Property 16: Orphaned Range Recovery
*For any* valid orphaned range file, metadata entries SHALL be rebuilt to restore cache accessibility
**Validates: Requirements 8.2, 8.4**

### Property 17: Metrics Collection
*For any* metadata operation (corruption detection, recovery, lock timeout), corresponding metrics SHALL be updated
**Validates: Requirements 9.2, 9.3, 9.4, 9.5**

### Property 18: Startup Validation Coordination
*For any* multiple instances starting within seconds, only the first instance SHALL perform comprehensive validation
**Validates: Requirements 10.1**

### Property 19: Validation Freshness
*For any* validation completed within 23 hours, new instances SHALL skip validation and proceed immediately
**Validates: Requirements 10.3**

### Property 20: Validation Recovery
*For any* failed or incomplete validation, the next instance to acquire the lock SHALL restart validation
**Validates: Requirements 10.5**

### Property 21: Full Object Range Consistency
*For any* full object with content length N, the stored range SHALL span from 0 to N-1, and empty objects SHALL have no ranges
**Validates: Requirements 1.1, 1.2** (full objects follow same consistency rules as ranges)

## Configuration

### Atomic Metadata Writes Configuration

The atomic metadata writes system requires several configurable parameters with sensible defaults:

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AtomicMetadataConfig {
    /// Lock timeout for metadata operations (default: 30 seconds)
    #[serde(default = "default_lock_timeout")]
    pub lock_timeout: Duration,
    
    /// Maximum lock acquisition retries (default: 5)
    #[serde(default = "default_max_retries")]
    pub max_retries: u32,
    
    /// Journal consolidation interval (default: 30 seconds)
    #[serde(default = "default_consolidation_interval")]
    pub consolidation_interval: Duration,
    
    /// Journal file size threshold for immediate consolidation (default: 1MB)
    #[serde(default = "default_journal_size_threshold")]
    pub journal_size_threshold: u64,
    
    /// Metadata validation frequency during startup (default: 23 hours)
    #[serde(default = "default_validation_freshness")]
    pub validation_freshness: Duration,
    
    /// Background recovery enabled (default: true)
    #[serde(default = "default_recovery_enabled")]
    pub recovery_enabled: bool,
    
    /// Recovery prioritization based on access frequency (default: true)
    #[serde(default = "default_recovery_prioritization")]
    pub recovery_prioritization: bool,
}

impl Default for AtomicMetadataConfig {
    fn default() -> Self {
        Self {
            lock_timeout: default_lock_timeout(),
            max_retries: default_max_retries(),
            consolidation_interval: default_consolidation_interval(),
            journal_size_threshold: default_journal_size_threshold(),
            validation_freshness: default_validation_freshness(),
            recovery_enabled: default_recovery_enabled(),
            recovery_prioritization: default_recovery_prioritization(),
        }
    }
}

// Default value functions
fn default_lock_timeout() -> Duration { Duration::from_secs(30) }
fn default_max_retries() -> u32 { 5 }
fn default_consolidation_interval() -> Duration { Duration::from_secs(30) }
fn default_journal_size_threshold() -> u64 { 1_048_576 } // 1MB
fn default_validation_freshness() -> Duration { Duration::from_secs(23 * 3600) } // 23 hours
fn default_recovery_enabled() -> bool { true }
fn default_recovery_prioritization() -> bool { true }
```

### Configuration Integration

The configuration integrates with the existing proxy configuration system:

```yaml
# config.yaml
cache:
  cache_dir: "/mnt/efs/cache"
  # ... existing cache config
  
  # Atomic metadata writes configuration (all optional with defaults)
  atomic_metadata:
    lock_timeout: "30s"              # Optional: defaults to 30s
    max_retries: 5                   # Optional: defaults to 5
    consolidation_interval: "30s"    # Optional: defaults to 30s
    journal_size_threshold: 1048576  # Optional: defaults to 1MB
    validation_freshness: "23h"      # Optional: defaults to 23 hours
    recovery_enabled: true           # Optional: defaults to true
    recovery_prioritization: true    # Optional: defaults to true
```

### Default Behavior

- **Missing Configuration Section**: If `atomic_metadata` section is missing entirely, all defaults are applied
- **Partial Configuration**: If only some fields are specified, defaults are applied for missing fields
- **Invalid Values**: Invalid values are logged as warnings and defaults are used
- **Backward Compatibility**: Existing configurations without atomic metadata settings continue to work

### Configuration Validation

```rust
impl AtomicMetadataConfig {
    pub fn validate(&self) -> Result<(), ConfigError> {
        if self.lock_timeout.as_secs() == 0 {
            return Err(ConfigError::InvalidValue("lock_timeout must be > 0".to_string()));
        }
        if self.max_retries == 0 {
            return Err(ConfigError::InvalidValue("max_retries must be > 0".to_string()));
        }
        if self.consolidation_interval.as_secs() == 0 {
            return Err(ConfigError::InvalidValue("consolidation_interval must be > 0".to_string()));
        }
        if self.journal_size_threshold == 0 {
            return Err(ConfigError::InvalidValue("journal_size_threshold must be > 0".to_string()));
        }
        Ok(())
    }
    
    pub fn apply_defaults_and_validate(&mut self) -> Result<(), ConfigError> {
        // Ensure all fields have valid values, applying defaults if needed
        if self.lock_timeout.as_secs() == 0 {
            warn!("Invalid lock_timeout, using default: 30s");
            self.lock_timeout = default_lock_timeout();
        }
        if self.max_retries == 0 {
            warn!("Invalid max_retries, using default: 5");
            self.max_retries = default_max_retries();
        }
        // ... similar for other fields
        
        self.validate()
    }
}

## Error Handling
- **Timeout**: Implement exponential backoff with jitter (100ms to 5s)
- **Stale Lock**: Validate process existence and break if stale
- **Corrupted Lock**: Remove corrupted lock files and retry
- **Max Retries**: Fall back to journal-only mode after max retries

### Metadata Write Failures
- **Disk Full**: Clean up temporary files and return error
- **Permission Denied**: Log error and fall back to journal-only
- **Corruption**: Validate and attempt recovery before retry
- **Partial Write**: Use atomic write-then-rename to prevent corruption

### Journal Operation Failures
- **Journal Write Failure**: Continue with immediate metadata update only
- **Consolidation Failure**: Leave journal entries for retry, log error
- **Journal Corruption**: Skip corrupted entries, log for investigation
- **Cleanup Failure**: Log error but continue with main operation

### Recovery Operation Failures
- **Orphan Recovery Failure**: Log error and continue serving from S3
- **Validation Failure**: Mark metadata as corrupted, initiate recovery
- **Background Process Crash**: Restart with exponential backoff
- **Resource Exhaustion**: Throttle recovery operations

## Testing Strategy

### Unit Testing
- **Lock Manager**: Test stale lock detection, process validation, atomic breaking
- **Journal Manager**: Test entry writing, cleanup integration, corruption handling
- **Metadata Validator**: Test JSON validation, range overlap detection, consistency checks
- **Recovery Manager**: Test orphan detection, metadata rebuilding, cleanup operations

### Property-Based Testing
- **Concurrent Operations**: Generate random concurrent write patterns, verify consistency
- **Lock Coordination**: Test multiple instances with various timing scenarios
- **Journal Consolidation**: Generate random journal entries, verify correct merging
- **Recovery Scenarios**: Generate corrupted metadata, verify recovery correctness
- **Configuration**: Test with various timeout and threshold configurations

### Integration Testing
- **Multi-Instance Coordination**: Test startup validation with multiple instances
- **Multipart Upload Integration**: Test journal cleanup during upload timeouts
- **Background Process Coordination**: Test interaction between consolidation and recovery
- **Performance Under Load**: Test behavior under high concurrent write load

### Property Test Configuration
- **Minimum 100 iterations** per property test
- **Tag format**: `Feature: atomic-metadata-writes, Property N: [property description]`
- **Test data generation**: Smart generators for cache keys, range specifications, timing scenarios
- **Failure injection**: Simulate disk failures, process crashes, network timeouts

Each property test validates universal correctness properties across all valid inputs, while unit tests focus on specific examples and edge cases. Together, they provide comprehensive coverage of the atomic metadata write system.