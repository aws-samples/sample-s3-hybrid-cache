# Implementation Plan: Atomic Metadata Writes

## Overview

This implementation plan addresses the critical concurrent write issues causing orphaned range files in the S3 proxy's shared cache system. The solution implements a hybrid metadata system with enhanced lock management, write-ahead journaling, and comprehensive recovery mechanisms.

## Tasks

- [x] 1. Implement Enhanced Metadata Lock Manager
  - Create MetadataLockManager with stale lock detection
  - Implement process existence validation using system calls
  - Add atomic lock breaking with consistency validation
  - Implement exponential backoff with jitter for lock acquisition
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

- [x] 1.1 Write property test for stale lock detection
  - **Property 4: Stale Lock Detection**
  - **Validates: Requirements 2.1, 2.2**

- [x] 1.2 Write property test for lock breaking coordination
  - **Property 5: Lock Breaking Coordination**
  - **Validates: Requirements 2.5**

- [x] 2. Create Journal Management System
  - Implement JournalManager with per-instance journal files
  - Create JournalEntry data structures with serialization
  - Add atomic journal entry append operations
  - Implement journal cleanup integration with multipart uploads
  - _Requirements: 3.1, 5.1, 5.4_

- [x] 2.1 Write property test for journal entry validation
  - **Property 10: Journal Validation**
  - **Validates: Requirements 5.2, 5.3**

- [x] 2.2 Write property test for multipart journal cleanup
  - **Property 9: Multipart Journal Cleanup**
  - **Validates: Requirements 5.1, 5.4**

- [x] 3. Implement Hybrid Metadata Writer
  - Create HybridMetadataWriter combining immediate updates with journaling
  - Implement WriteMode enum (Immediate, JournalOnly, Hybrid)
  - Add fallback logic for high lock contention scenarios
  - Ensure atomic visibility (metadata before range file rename)
  - _Requirements: 1.2, 3.1, 3.2, 3.3_

- [x] 3.1 Write property test for concurrent write consistency
  - **Property 1: Concurrent Write Consistency**
  - **Validates: Requirements 1.1, 1.2**

- [x] 3.2 Write property test for atomic visibility
  - **Property 2: Atomic Visibility**
  - **Validates: Requirements 1.2**

- [x] 3.3 Write property test for hybrid write consistency
  - **Property 6: Hybrid Write Consistency**
  - **Validates: Requirements 3.1**

- [x] 4. Build Journal Consolidation System
  - Implement JournalConsolidator with configurable intervals
  - Add threshold-based immediate consolidation triggers
  - Create conflict resolution between metadata and journal entries
  - Implement range file existence validation before consolidation
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

- [x] 4.1 Write property test for journal consolidation completeness
  - **Property 8: Journal Consolidation Completeness**
  - **Validates: Requirements 4.2, 3.4**

- [x] 5. Create Metadata Validation System
  - Implement MetadataValidator with comprehensive integrity checks
  - Add JSON structure validation and required field verification
  - Implement range overlap detection and size consistency validation
  - Add timestamp validation and reasonableness checks
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 5.1 Write property test for metadata integrity validation
  - **Property 13: Metadata Integrity Validation**
  - **Validates: Requirements 7.1**

- [x] 5.2 Write property test for range overlap detection
  - **Property 14: Range Overlap Detection**
  - **Validates: Requirements 7.2**

- [x] 6. Implement Orphaned Range Recovery
  - Create OrphanedRangeRecovery with background scanning
  - Implement metadata rebuilding from valid orphaned ranges
  - Add cleanup of invalid/corrupted orphaned ranges
  - Implement priority-based recovery using access frequency
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 6.1 Write property test for orphaned range detection
  - **Property 15: Orphaned Range Detection**
  - **Validates: Requirements 8.1**

- [x] 6.2 Write property test for orphaned range recovery
  - **Property 16: Orphaned Range Recovery**
  - **Validates: Requirements 8.2, 8.4**

- [x] 7. Checkpoint - Core Components Integration
  - Ensure all core components work together correctly
  - Verify lock manager integrates with hybrid writer
  - Test journal manager with consolidation system
  - Validate metadata validator with recovery system
  - Ask the user if questions arise

- [x] 8. Add Error Handling and Cleanup
  - Implement cleanup on metadata write failures
  - Add proper error handling for lock acquisition failures
  - Ensure temporary files are cleaned up on all failure paths
  - Add graceful degradation for journal operation failures
  - _Requirements: 1.3, 1.4_

- [x] 8.1 Write property test for cleanup on failure
  - **Property 3: Cleanup on Failure**
  - **Validates: Requirements 1.3, 1.4**

- [x] 9. Implement Background Recovery System
  - Create background recovery that doesn't block other operations
  - Implement recovery prioritization based on access patterns
  - Add recovery failure handling with fallback to S3
  - Ensure recovery operations are non-blocking for other cache operations
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5_

- [x] 9.1 Write property test for background recovery non-blocking
  - **Property 11: Background Recovery Non-Blocking**
  - **Validates: Requirements 6.2**

- [x] 9.2 Write property test for recovery prioritization
  - **Property 12: Recovery Prioritization**
  - **Validates: Requirements 6.5**

- [x] 10. Add Metrics and Monitoring
  - Implement comprehensive metrics collection for all operations
  - Add corruption detection counters and recovery success tracking
  - Implement lock contention and timeout frequency monitoring
  - Create detailed diagnostic logging for troubleshooting
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 10.1 Write property test for metrics collection
  - **Property 17: Metrics Collection**
  - **Validates: Requirements 9.2, 9.3, 9.4, 9.5**
  - **PBT Status: PASSED** - All 6 property functions validate comprehensive metrics collection for atomic metadata operations

- [x] 11. Integrate with Startup Validation
  - Enhance existing cache initialization with metadata consistency validation
  - Implement coordinated startup validation using existing distributed locking
  - Add validation freshness checking (23-hour validity)
  - Ensure validation recovery from failed/incomplete validation
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [x] 11.1 Write property test for startup validation coordination
  - **Property 18: Startup Validation Coordination**
  - **Validates: Requirements 10.1**
  - **PBT Status: PASSED** - Core property test validates coordinated startup validation with distributed locking

- [x] 11.2 Write property test for validation freshness
  - **Property 19: Validation Freshness**
  - **Validates: Requirements 10.3**
  - **PBT Status: PASSED** - All 4 property functions validate 23-hour validation freshness detection and scheduling

- [x] 11.3 Write property test for validation recovery
  - **Property 20: Validation Recovery**
  - **Validates: Requirements 10.5**
  - **PBT Status: PASSED** - Property test validates recovery from failed/incomplete validation with coordination

- [x] 11.4 Write property test for full object range consistency
  - **Property 21: Full Object Range Consistency**
  - **Validates: Requirements 1.1, 1.2**
  - **PBT Status: PASSED** - Property test validates full object range consistency across different sizes and compression

- [-] 12. Update Existing Cache Operations
  - Modify existing store_range method to use HybridMetadataWriter
  - Update cache read operations to work with enhanced validation
  - Integrate orphaned range recovery with existing cache scanning
  - Ensure backward compatibility with existing cache data
  - _Requirements: 1.1, 1.5, 3.2_

- [x] 12.1 Write property test for immediate availability
  - **Property 7: Immediate Availability**
  - **Validates: Requirements 3.2**

- [x] 13. Add Configuration Support
  - Add AtomicMetadataConfig struct with comprehensive Default implementation
  - Implement configuration validation with automatic fallback to defaults
  - Add YAML configuration integration with existing config system
  - Ensure backward compatibility (missing config sections use defaults)
  - Add robust error handling that applies defaults for invalid values
  - _Requirements: 4.4, 9.1_

- [x] 14. Final Integration and Testing
  - Integrate all components with existing disk cache system
  - Run comprehensive integration tests with multiple instances
  - Test multipart upload timeout scenarios with journal cleanup
  - Verify performance under high concurrent write load
  - _Requirements: All requirements_

- [x] 14.1 Write integration tests for multi-instance scenarios
  - Test concurrent writes from multiple proxy instances
  - Verify journal cleanup during multipart upload timeouts
  - Test startup validation coordination with multiple instances

- [x] 15. Final Checkpoint - System Validation
  - Ensure all tests pass and system works end-to-end
  - Verify that orphaned range issues are resolved
  - Test recovery from existing orphaned ranges in production data
  - Validate that cache effectiveness is maintained
  - Ask the user if questions arise

## Notes

- Each task references specific requirements for traceability
- Property tests validate universal correctness properties with minimum 100 iterations
- Integration tests verify multi-instance coordination
- The implementation maintains backward compatibility with existing cache data
- Focus on resolving the 30% concurrent write failure rate observed in production
- All tests are required to ensure comprehensive validation from the start