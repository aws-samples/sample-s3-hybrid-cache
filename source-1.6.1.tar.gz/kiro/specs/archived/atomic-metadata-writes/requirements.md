# Requirements Document

## Introduction

The S3 proxy's shared cache system currently suffers from critical metadata consistency issues despite having file locking mechanisms in place. While the system uses fs2 file locking for individual metadata operations, there are gaps in recovery validation and consistency checking that allow corrupted metadata to persist. This leads to cache misses, incorrect eviction decisions, and potential data integrity issues.

Current problems identified from production logs:
- Metadata files get corrupted and deleted, leaving orphaned range files
- Recovery mechanisms don't rebuild metadata from existing range files
- No validation that metadata accurately reflects stored range data
- Inconsistent state after metadata corruption recovery
- Missing transactional semantics for complex metadata operations

The system already has:
- fs2 file locking for metadata writes (.meta.lock files)
- Atomic write-then-rename operations for metadata updates
- Distributed locking for cache initialization
- Timeout-based stale lock cleanup

## Glossary

- **Proxy**: The S3 proxy server instance
- **Shared Cache**: Cache directory accessible by multiple proxy instances
- **Metadata File**: .meta file containing object and range information
- **Range File**: .bin file containing actual cached data for a byte range
- **Metadata Consistency**: Metadata accurately reflects the actual cached range files
- **Orphaned Range**: Range file that exists but has no metadata reference
- **Recovery Validation**: Process of rebuilding metadata from actual stored range files
- **Range Metadata**: Information about cached byte ranges for an object
- **Object Metadata**: Information about the complete cached object
- **Metadata Corruption**: Metadata file containing invalid data or missing references to existing ranges
- **fs2 Locking**: File locking mechanism already used by the system via fs2 crate

## Requirements

### Requirement 1: Robust Concurrent Range Write Coordination

**User Story:** As a proxy instance, I want concurrent range writes to be properly coordinated, so that all range files have corresponding metadata entries and no orphaned ranges are created.

#### Acceptance Criteria

1. WHEN multiple instances write different ranges of the same object concurrently THEN all range files SHALL have corresponding metadata entries
2. WHEN a range file write completes THEN the metadata entry SHALL be atomically committed before the range file becomes visible
3. WHEN metadata write fails after range file creation THEN the range file SHALL be cleaned up to prevent orphaned ranges
4. WHEN lock acquisition fails or times out THEN the range write operation SHALL fail cleanly without creating orphaned files
5. WHEN detecting orphaned range files THEN the Proxy SHALL either add them to metadata or remove them to maintain consistency

### Requirement 2: Stale Lock Detection and Recovery

**User Story:** As a proxy instance, I want to detect and recover from stale metadata locks, so that concurrent operations don't get permanently blocked by crashed processes.

#### Acceptance Criteria

1. WHEN acquiring a metadata lock THEN the Proxy SHALL check if existing locks are stale based on file modification time and process existence
2. WHEN a lock is older than the configured timeout and the process no longer exists THEN the Proxy SHALL break the stale lock
3. WHEN breaking a stale lock THEN the Proxy SHALL validate metadata consistency before proceeding with operations
4. WHEN lock files exist but are empty or corrupted THEN the Proxy SHALL remove them and proceed with lock acquisition
5. WHEN multiple instances detect the same stale lock THEN only one instance SHALL successfully break it and proceed

### Requirement 3: Hybrid Immediate + Journal Metadata Updates

**User Story:** As a proxy instance, I want newly cached ranges to be immediately available for reads while still using journaling to reduce lock contention, so that cache effectiveness is not compromised by delayed metadata availability.

#### Acceptance Criteria

1. WHEN writing a new range THEN the Proxy SHALL immediately update the main metadata file AND append to a journal for redundancy
2. WHEN reading metadata THEN the Proxy SHALL serve from the main metadata file without needing to check journal entries for immediate availability
3. WHEN lock contention is high THEN the Proxy SHALL fall back to journal-only writes and trigger immediate consolidation
4. WHEN journal consolidation runs THEN it SHALL verify consistency between main metadata and journal entries, resolving any conflicts
5. WHEN consolidation detects missing ranges in main metadata THEN it SHALL add them from journal entries to recover from partial failures

### Requirement 4: Journal-Based Metadata Consolidation

**User Story:** As a proxy instance, I want journal entries to be efficiently consolidated into metadata files, so that the system maintains good read performance while supporting high write concurrency.

#### Acceptance Criteria

1. WHEN consolidating journal entries THEN the Proxy SHALL acquire an exclusive lock only on the main metadata file, not on journal files
2. WHEN consolidation runs THEN the Proxy SHALL process all pending journal entries for an object in a single metadata update
3. WHEN consolidation fails THEN the Proxy SHALL leave journal entries intact for retry and log the failure
4. WHEN consolidation frequency is configurable THEN the Proxy SHALL respect the configured interval (default: every 30 seconds)
5. WHEN journal files grow beyond a threshold THEN the Proxy SHALL trigger immediate consolidation to prevent performance degradation

### Requirement 5: Journal Cleanup Integration with Upload Timeouts

**User Story:** As a proxy instance, I want journal entries to be cleaned up when multipart uploads timeout, so that journal consolidation doesn't try to reference deleted parts.

#### Acceptance Criteria

1. WHEN incomplete multipart uploads are cleaned up due to TTL expiration THEN the Proxy SHALL also remove any journal entries referencing the deleted parts
2. WHEN journal consolidation runs THEN it SHALL verify that referenced range files exist before adding entries to metadata
3. WHEN journal entries reference non-existent range files THEN the Proxy SHALL remove the invalid journal entries and log the cleanup
4. WHEN multipart upload cleanup completes THEN the Proxy SHALL scan for and remove any orphaned journal entries for that cache key
5. WHEN journal cleanup fails THEN the Proxy SHALL log the error but continue with the multipart upload cleanup to prevent blocking

### Requirement 6: Background Metadata Recovery

**User Story:** As a proxy instance, I want metadata recovery to happen in the background, so that client requests are not blocked during recovery operations.

#### Acceptance Criteria

1. WHEN metadata corruption is detected THEN the Proxy SHALL continue serving requests from S3 while scheduling background recovery
2. WHEN background recovery is running THEN the Proxy SHALL not block cache reads or writes for other objects
3. WHEN recovery completes successfully THEN the Proxy SHALL resume serving from cache for recovered objects
4. WHEN recovery fails THEN the Proxy SHALL log the failure and continue serving from S3 without retrying
5. WHEN multiple objects need recovery THEN the Proxy SHALL prioritize recovery based on access frequency and recency

### Requirement 7: Metadata Integrity Verification

**User Story:** As a proxy instance, I want to verify metadata file integrity, so that corruption is detected before it causes cache misses.

#### Acceptance Criteria

1. WHEN reading metadata files THEN the Proxy SHALL verify JSON structure and required field presence
2. WHEN metadata contains range specifications THEN the Proxy SHALL verify ranges don't overlap and have valid byte positions
3. WHEN metadata contains size information THEN the Proxy SHALL verify it matches the sum of range sizes
4. WHEN metadata contains timestamps THEN the Proxy SHALL verify they are reasonable and consistent
5. WHEN integrity verification fails THEN the Proxy SHALL mark the metadata as corrupted and initiate recovery

### Requirement 8: Orphaned Range File Management

**User Story:** As a proxy instance, I want to properly handle orphaned range files, so that disk space is not wasted and cache operations remain efficient.

#### Acceptance Criteria

1. WHEN scanning cache directories THEN the Proxy SHALL identify range files without corresponding metadata entries
2. WHEN orphaned range files are found THEN the Proxy SHALL attempt to rebuild metadata entries for valid ranges
3. WHEN range files cannot be validated THEN the Proxy SHALL remove them to free disk space
4. WHEN rebuilding metadata from orphaned ranges THEN the Proxy SHALL verify range file integrity and consistency
5. WHEN orphaned range cleanup completes THEN the Proxy SHALL update cache size tracking to reflect freed space

### Requirement 9: Configuration and Monitoring

**User Story:** As a system operator, I want configurable metadata consistency settings and monitoring, so that I can tune behavior for my environment and track cache health.

#### Acceptance Criteria

1. WHEN configuring the proxy THEN the Proxy SHALL accept settings for metadata validation frequency and recovery behavior
2. WHEN metadata operations occur THEN the Proxy SHALL expose metrics for corruption detection, recovery success, and lock contention
3. WHEN metadata corruption is detected THEN the Proxy SHALL increment corruption counters and log detailed diagnostic information
4. WHEN recovery operations complete THEN the Proxy SHALL record recovery duration and success rates
5. WHEN lock timeouts occur THEN the Proxy SHALL track timeout frequency and duration for performance monitoring

### Requirement 10: Integrated Startup Metadata Consistency Validation

**User Story:** As a proxy instance, I want metadata consistency validation integrated into the existing cache initialization process, so that corrupted metadata is detected during the existing startup validation phases.

#### Acceptance Criteria

1. WHEN cache initialization Phase 2 (metadata scan) runs THEN the Proxy SHALL also perform metadata consistency validation on scanned files
2. WHEN metadata consistency validation detects corruption THEN the Proxy SHALL attempt recovery before proceeding to Phase 3 (subsystem initialization)
3. WHEN metadata consistency validation was completed within the last 23 hours THEN the Proxy SHALL skip consistency validation but still perform the existing size validation
4. WHEN multiple instances start simultaneously THEN metadata consistency validation SHALL use the existing distributed locking from cache initialization
5. WHEN metadata consistency validation completes THEN the Proxy SHALL include consistency results in the existing initialization summary