# Design: LZ4 Frame Integrity & Cache Correctness

## Overview

Three cache correctness changes:
1. Replace LZ4 block format with frame format + content checksum in `compression.rs`
2. Add cache invalidation after signed DELETE in `http_proxy.rs`
3. Bypass cache for `?versionId=` requests in `http_proxy.rs`, remove dead code

Breaking change: existing cache must be flushed on upgrade.

## 1. LZ4 Frame Format Migration

### compression.rs Changes

Replace all `compress_prepend_size` / `decompress_size_prepended` calls with frame-based equivalents.

Compression (all paths that produce compressed output):
```rust
use lz4_flex::frame::{FrameEncoder, FrameInfo, BlockMode};
use std::io::Write;

fn compress_frame(data: &[u8]) -> Result<Vec<u8>> {
    let mut frame_info = FrameInfo::new();
    frame_info.content_checksum = true;
    frame_info.block_mode = BlockMode::Independent;

    let mut output = Vec::new();
    let mut encoder = FrameEncoder::with_frame_info(frame_info, &mut output);
    encoder.write_all(data)?;
    encoder.finish()?;
    Ok(output)
}
```

Decompression (all paths that read cached data):
```rust
use lz4_flex::frame::FrameDecoder;
use std::io::Read;

fn decompress_frame(compressed: &[u8]) -> Result<Vec<u8>> {
    let mut decoder = FrameDecoder::new(compressed);
    let mut decompressed = Vec::new();
    decoder.read_to_end(&mut decompressed)?;
    Ok(decompressed)
}
```

The `FrameDecoder::read_to_end` verifies the content checksum automatically. On failure it returns an `io::Error` which maps to `ProxyError::CompressionError`.

### Checksum Failure: Auto-Delete Corrupt Entry

When decompression fails due to checksum mismatch, the caller (disk_cache.rs or range_handler.rs) should invalidate the corrupt cache entry before falling back to S3. This uses the existing `invalidate_cache_entry` / `invalidate_cache_hierarchy` path. The request then proceeds as a cache miss — fetches from S3 and re-caches the fresh data.

### Non-Compressible Data Handling

Currently, content-aware compression stores non-compressible formats (JPEG, PNG, etc.) as raw bytes with `CompressionAlgorithm::None`. After this change:

- Non-compressible data is wrapped in LZ4 frame format with uncompressed blocks
- `CompressionAlgorithm::Lz4` is recorded in metadata (the frame is LZ4 format even though blocks are uncompressed)
- The frame decoder handles uncompressed blocks transparently

This means `compress_content_aware_with_metadata` changes: when content-aware detection says "don't compress", instead of returning raw data with `Algorithm::None`, it wraps in a frame with uncompressed blocks and returns `Algorithm::Lz4`.

When compression is globally disabled (`compression.enabled: false`), data is still wrapped in frame format for integrity, recorded as `Algorithm::Lz4`.

Remove the `CompressionAlgorithm::None` variant entirely. All cached data uses frame format. All callers that previously matched on `None` or produced `None` must be updated.

### Methods to Modify in CompressionHandler

- `compress_data()` — replace `compress_prepend_size` with `compress_frame`
- `compress_with_algorithm()` — same replacement for `Lz4` arm
- `decompress_data()` — replace `decompress_size_prepended` with `decompress_frame`
- `decompress_with_algorithm()` — delegates to `decompress_data`, no change needed
- `decompress_data_with_fallback()` — replace `decompress_size_prepended` with `decompress_frame`
- `compress_content_aware_with_metadata()` — when content-aware says skip, use frame with uncompressed blocks instead of raw passthrough
- `compress_data_content_aware()` — same: wrap in frame even when skipping compression
- `compress_data_content_aware_with_fallback()` — same pattern

The `< 4 bytes` guard in `decompress_data` and `decompress_data_with_fallback` can be removed — the frame decoder handles empty/small inputs.

### Imports Change

Remove:
```rust
use lz4_flex::{compress_prepend_size, decompress_size_prepended};
```

Add:
```rust
use lz4_flex::frame::{FrameEncoder, FrameDecoder, FrameInfo, BlockMode};
use std::io::{Write, Read};
```

## 2. Signed DELETE Cache Invalidation

### http_proxy.rs — handle_other_request()

In the SigV4 branch, after the AbortMultipartUpload check and before the generic `forward_signed_request` fallthrough, add a DELETE-specific block:

```rust
// After AbortMultipartUpload check...

// Signed DELETE of regular object — invalidate cache after successful S3 response
if method == Method::DELETE {
    let path = uri.path().to_string();
    let response = Self::forward_signed_request(req, host, s3_client, proxy_referer).await?;
    if response.status().is_success() {
        let cache_key = CacheManager::generate_cache_key(&path);
        if let Err(e) = cache_manager
            .invalidate_cache_unified_for_operation(&cache_key, "DELETE")
            .await
        {
            warn!(
                "Failed to invalidate cache after signed DELETE: cache_key={}, error={}",
                cache_key, e
            );
        }
    }
    return Ok(response);
}

// Existing generic fallthrough:
debug!("Detected AWS SigV4 signed {} request, forwarding without modification", method);
return Self::forward_signed_request(req, host, s3_client, proxy_referer).await;
```

This mirrors the existing unsigned DELETE invalidation pattern in the same function.

## 3. Simplify versionId Handling

### http_proxy.rs — handle_get_head_request()

Replace the ~90-line `versionId` block (lines ~1168-1260) with a simple bypass:

```rust
if query_params.contains_key("versionId") {
    debug!(
        "Versioned request detected, bypassing cache: cache_key={}",
        cache_key
    );

    if let Some(metrics_mgr) = metrics_manager.clone() {
        tokio::spawn(async move {
            let mgr = metrics_mgr.read().await;
            mgr.record_cache_bypass("versioned_request").await;
        });
    }

    return Self::forward_get_head_to_s3_without_caching(
        method,
        uri,
        host,
        header_map,
        s3_client,
        Some("GetObject (versioned)"),
        proxy_referer,
    )
    .await;
}
```

### cache.rs — Remove get_cached_version_id()

Delete the `get_cached_version_id()` method (~lines 2082-2105). It becomes dead code after the versionId bypass change.

### http_proxy.rs — should_bypass_cache()

The existing comment on line 821 says `versionId alone does NOT trigger bypass (Requirement 9.7)`. Update this comment to reflect the new behavior, or remove it since versionId bypass now happens earlier in the flow (before `should_bypass_cache` is called).

### Test Updates

- `tests/versioned_request_bypass_test.rs` — Update metric reason strings from `versioned_request_mismatch` / `versioned_request_no_cache` to single `versioned_request`
- `src/http_proxy.rs` test `test_should_not_bypass_cache_version_id_only` — Remove or update since versionId bypass now happens at a different level

## 4. Remove --compression-enabled CLI Flag

### config.rs

- Remove the `Arg::new("compression-enabled")` block (~lines 1684-1689)
- Remove the `matches.get_flag("compression-enabled")` block (~lines 2064-2066)
- Retain `COMPRESSION_ENABLED` env var handling (~lines 1888-1890)
- Retain `compression.enabled` in `CompressionConfig` struct

## Files to Modify

1. `src/compression.rs` — Frame format migration (core change)
2. `src/http_proxy.rs` — Signed DELETE invalidation, versionId bypass simplification
3. `src/cache.rs` — Remove `get_cached_version_id()`
4. `src/config.rs` — Remove `--compression-enabled` CLI flag
5. `tests/versioned_request_bypass_test.rs` — Update metric reason strings
6. `Cargo.toml` — No change needed (lz4_flex 0.11 already supports frame format)
7. `Cargo.toml` — Bump version to v1.3.0
8. `CHANGELOG.md` — Document breaking change, cache flush requirement

## Testing

- Unit test: Frame compress → decompress round-trip produces identical data
- Unit test: Frame with uncompressed blocks round-trips correctly
- Unit test: Corrupted frame data returns `ProxyError::CompressionError`
- Unit test: Content checksum mismatch detected on decompression
- Unit test: Signed DELETE triggers cache invalidation on success
- Unit test: Signed DELETE with non-success status does NOT invalidate
- Unit test: versionId requests bypass cache entirely
- Unit test: Non-versioned requests unaffected by versionId change
- Existing compression tests updated for frame format
