# Tasks: LZ4 Frame Integrity & Cache Correctness

## Tasks

- [x] 1. Migrate compression.rs to LZ4 frame format
  - [x] 1.1 Replace `compress_prepend_size` with frame encoder using `FrameInfo { content_checksum: true, block_mode: Independent }` in `compress_data()`
    - _Requirements: 1.1, 1.5_
  - [x] 1.2 Replace `decompress_size_prepended` with `FrameDecoder::read_to_end` in `decompress_data()`, remove the `< 4 bytes` guard
    - _Requirements: 1.2, 3.1, 3.2_
  - [x] 1.3 Update `compress_with_algorithm()` Lz4 arm to use frame encoder
    - _Requirements: 1.1, 1.5_
  - [x] 1.4 Update `decompress_data_with_fallback()` to use frame decoder, remove the `< 4 bytes` guard
    - _Requirements: 1.2, 3.1_
  - [x] 1.5 Replace `use lz4_flex::{compress_prepend_size, decompress_size_prepended}` with `use lz4_flex::frame::{FrameEncoder, FrameDecoder, FrameInfo, BlockMode}` and `use std::io::{Write, Read}`
    - _Requirements: 1.1, 1.2_

- [x] 2. Handle non-compressible data with frame format
  - [x] 2.1 Update `compress_content_aware_with_metadata()`: when content-aware detection says skip compression, wrap data in frame with uncompressed blocks and return `CompressionAlgorithm::Lz4` instead of raw data with `CompressionAlgorithm::None`
    - _Requirements: 1.3, 1.4, 2.2_
  - [x] 2.2 Update `compress_data_content_aware()`: same pattern — wrap in frame even when skipping compression
    - _Requirements: 1.3, 1.4_
  - [x] 2.3 Update `compress_data_content_aware_with_fallback()`: same pattern
    - _Requirements: 1.3, 1.4_
  - [x] 2.4 When compression is globally disabled (`compression_enabled: false`), wrap data in frame format with uncompressed blocks for integrity checksum, record as `CompressionAlgorithm::Lz4`
    - _Requirements: 1.3, 1.4, 2.4_
  - [x] 2.5 Remove `CompressionAlgorithm::None` variant from the enum and update all callers that produce or match on `None`
    - _Requirements: 2.5_

- [x] 3. Update compression tests
  - [x] 3.1 Update `test_compression_round_trip` for frame format
    - _Requirements: 1.1, 1.2_
  - [x] 3.2 Update `test_compression_with_fallback` for frame format
    - _Requirements: 1.1_
  - [x] 3.3 Update `test_small_data_passthrough` — small data now gets frame-wrapped too
    - _Requirements: 1.3, 1.4_
  - [x] 3.4 Update `test_content_aware_compression` — non-compressible data now returns `Lz4` algorithm with frame wrapper
    - _Requirements: 2.2_
  - [x] 3.5 Update `test_content_aware_compression_with_paths` — same
    - _Requirements: 2.2_
  - [x] 3.6 Add test: corrupted frame data returns `ProxyError::CompressionError`
    - _Requirements: 3.1, 3.2_
  - [x] 3.7 Add test: corrupt cache entry is auto-deleted on checksum failure
    - _Requirements: 3.4_
  - [x] 3.8 Add test: frame with uncompressed blocks round-trips correctly
    - _Requirements: 1.3, 1.4_
  - [x] 3.9 Update `test_algorithm_based_decompression` for frame format
    - _Requirements: 1.2_
  - [x] 3.10 Update `test_compression_with_metadata` and `test_compression_with_metadata_skip_jpg` for new non-compressible behavior
    - _Requirements: 2.2_

- [x] 4. Fix signed DELETE cache invalidation
  - [x] 4.1 In `handle_other_request()` SigV4 branch, after the AbortMultipartUpload DELETE check, add a block that intercepts `Method::DELETE`, calls `forward_signed_request`, and on success calls `invalidate_cache_unified_for_operation(&cache_key, "DELETE")`
    - _Requirements: 5.1, 5.2, 5.3_
  - [x] 4.2 Preserve existing AbortMultipartUpload routing (requests with `uploadId` still go to PUT handler)
    - _Requirements: 5.4_
  - [x] 4.3 Add unit test: signed DELETE with success status triggers cache invalidation
    - _Requirements: 5.1_
  - [x] 4.4 Add unit test: signed DELETE with non-success status does NOT invalidate cache
    - _Requirements: 5.1_

- [x] 5. Simplify versionId handling
  - [x] 5.1 Replace the ~90-line versionId block in `handle_get_head_request()` with a simple `query_params.contains_key("versionId")` check that calls `forward_get_head_to_s3_without_caching` and records a `versioned_request` bypass metric
    - _Requirements: 6.1, 6.2, 6.3_
  - [x] 5.2 Remove `get_cached_version_id()` method from `cache.rs`
    - _Requirements: 6.4_
  - [x] 5.3 Update or remove the comment on line 821 of `http_proxy.rs` about versionId not triggering bypass
    - _Requirements: 6.1_
  - [x] 5.4 Update `tests/versioned_request_bypass_test.rs` — change metric reason strings from `versioned_request_mismatch` / `versioned_request_no_cache` to `versioned_request`
    - _Requirements: 6.3_
  - [x] 5.5 Update or remove `test_should_not_bypass_cache_version_id_only` in `http_proxy.rs` tests
    - _Requirements: 6.1, 6.5_

- [x] 6. Remove --compression-enabled CLI flag
  - [x] 6.1 Remove `Arg::new("compression-enabled")` block from CLI arg definitions in `config.rs`
    - _Requirements: 7.1_
  - [x] 6.2 Remove `matches.get_flag("compression-enabled")` block from `apply_cli_overrides` in `config.rs`
    - _Requirements: 7.1_
  - [x] 6.3 Verify `COMPRESSION_ENABLED` env var and `compression.enabled` config option still work
    - _Requirements: 7.2, 7.3, 7.4_

- [x] 7. Documentation
  - [x] 7.1 Update CHANGELOG.md and bump version to v1.3.0 in Cargo.toml: document LZ4 frame format migration as breaking change, cache flush requirement, signed DELETE fix, versionId simplification, CLI flag removal
    - _Requirements: 4.3_
  - [x] 7.2 Update docs/COMPRESSION.md if it references block format internals
    - _Requirements: 1.1_
  - [x] 7.3 Update docs/CACHING.md if it references versionId cache behavior
    - _Requirements: 6.1_
