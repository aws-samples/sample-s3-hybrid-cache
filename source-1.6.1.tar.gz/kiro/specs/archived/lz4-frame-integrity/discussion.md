# LZ4 Frame Format for Cache Integrity

## Problem Statement

The proxy currently uses LZ4 block format (`compress_prepend_size` / `decompress_size_prepended`) which provides no integrity verification. If cached `.bin` files are corrupted in a way that:
- Still decompresses to the expected size
- Produces syntactically valid LZ4 output

...the proxy serves incorrect data without detection.

Current validation is size-based only:
1. Decompressed size vs stored `uncompressed_size`
2. Decompressed size vs expected range size (end - start + 1)

## Proposed Solution

Switch from LZ4 block format to LZ4 frame format with content checksum enabled.

### LZ4 Frame Format Features

The frame format (defined in lz4_Frame_format.md) provides:

| Feature | Block Format | Frame Format |
|---------|--------------|--------------|
| Size prefix | 4 bytes | In header |
| Block checksum | No | Optional (xxHash-32) |
| Content checksum | No | Optional (xxHash-32) |
| Header checksum | No | Yes (1 byte) |
| Uncompressed blocks | No | Yes (highest bit flag) |
| Streaming support | No | Yes |

### Content Checksum

The content checksum is xxHash-32 computed over the original (uncompressed) data with seed 0. It's appended after the EndMark (4 bytes). This validates:
- All blocks decoded correctly
- Encoding/decoding produced no distortion
- Data transmitted in correct order without error

### xxHash-32 Performance

xxHash-32 operates at RAM speed limits (~9.7 GB/s on modern CPUs). For comparison:
- LZ4 decompression: 2.7-5.9 GB/s
- Disk read (NVMe): 3-7 GB/s
- EFS throughput: 0.1-1 GB/s

The checksum computation is faster than both decompression and I/O, so overhead is minimal.

## Implementation with lz4_flex

The `lz4_flex` crate (v0.11) supports frame format via `frame::FrameEncoder` and `frame::FrameDecoder`.

### Current Code (Block Format)

```rust
use lz4_flex::{compress_prepend_size, decompress_size_prepended};

// Compression
let compressed = compress_prepend_size(data);

// Decompression
let decompressed = decompress_size_prepended(&compressed)?;
```

### Proposed Code (Frame Format)

```rust
use lz4_flex::frame::{FrameEncoder, FrameDecoder, FrameInfo, BlockMode};
use std::io::{Write, Read};

// Compression with content checksum
fn compress_with_checksum(data: &[u8]) -> Vec<u8> {
    let mut frame_info = FrameInfo::new();
    frame_info.content_checksum = true;  // Enable xxHash-32 content checksum
    frame_info.block_mode = BlockMode::Independent;  // No block linking
    
    let mut output = Vec::new();
    let mut encoder = FrameEncoder::with_frame_info(frame_info, &mut output);
    encoder.write_all(data).unwrap();
    encoder.finish().unwrap();
    output
}

// Decompression with checksum verification
fn decompress_with_checksum(compressed: &[u8]) -> Result<Vec<u8>> {
    let mut decoder = FrameDecoder::new(compressed.as_ref());
    let mut decompressed = Vec::new();
    decoder.read_to_end(&mut decompressed)?;  // Verifies checksum on completion
    Ok(decompressed)
}
```

## Handling Non-Compressible Data

### The Challenge

Currently, content-aware compression skips already-compressed formats (JPEG, PNG, MP4, etc.) to avoid wasting CPU. These files are stored uncompressed with `CompressionAlgorithm::None`.

For integrity verification to cover all cached data, non-compressible data must also go through the frame format.

### Frame Format Uncompressed Blocks

The LZ4 frame format supports uncompressed blocks natively:
- Block size field has highest bit set (1) to indicate uncompressed
- Data is stored as-is, no compression overhead
- Content checksum still computed over original data

### Overhead Analysis

For a 1 MB uncompressed block stored in frame format:

| Component | Size |
|-----------|------|
| Magic number | 4 bytes |
| Frame descriptor | 3-15 bytes |
| Block size field | 4 bytes |
| Data | 1,048,576 bytes |
| EndMark | 4 bytes |
| Content checksum | 4 bytes |
| **Total overhead** | **~20 bytes** |

Overhead: 0.002% - negligible.

### Performance for Uncompressed Data

When storing uncompressed:
- No LZ4 compression CPU cost
- xxHash-32 computation: ~0.1ms per MB (at 9.7 GB/s)
- Memory copy for framing: ~0.3ms per MB

Total overhead for 8 MB range: ~3ms - acceptable.

## Implementation Approach

All cached data uses frame format regardless of compressibility:
- Compressible data: Frame with LZ4-compressed blocks
- Non-compressible data: Frame with uncompressed blocks

Benefits:
- Uniform handling, simpler code
- All data has integrity verification
- Single code path for read/write

This is a breaking change - caches are flushed on upgrade.

## Performance Impact Summary

| Operation | Current (Block) | Proposed (Frame) | Delta |
|-----------|-----------------|------------------|-------|
| Compress 8MB compressible | ~23ms | ~24ms | +1ms |
| Compress 8MB non-compressible | 0ms (skip) | ~3ms | +3ms |
| Decompress 8MB | ~3ms | ~4ms | +1ms |
| Storage overhead | 4 bytes | ~20 bytes | +16 bytes |

The performance impact is minimal:
- Compression: +1-3ms per 8MB range
- Decompression: +1ms per 8MB range (checksum verification)
- Storage: +16 bytes per range (~0.0002%)

## Risks and Mitigations

### Risk: Frame Format Bugs in lz4_flex

The frame format implementation in lz4_flex is less battle-tested than block format.

Mitigation:
- lz4_flex frame format is fuzz-tested (`cargo +nightly fuzz run fuzz_roundtrip_frame`)
- Add integration tests comparing frame output with reference lz4 implementation
- Monitor for decompression errors in production

### Risk: Performance Regression

Frame format adds overhead that could impact high-throughput scenarios.

Mitigation:
- Benchmark before deployment
- The overhead (~1-3ms per 8MB) is small compared to network latency
- Can be disabled via config if issues arise

## Deduplication Considerations

LZ4 compression is not compatible with storage-level deduplication (ZFS, Btrfs, NetApp, etc.) because:
- Compressed output is non-deterministic (varies by implementation, buffer boundaries)
- Back-references within the 64KB window mean identical data compresses differently based on context
- No fixed block alignment with storage dedupe boundaries

For dedupe environments, set `compression.enabled: false`. The proxy stores data uncompressed (wrapped in frame format for integrity checksum only). Storage-level dedupe can then work effectively, and the storage layer can apply its own compression after dedupe.

## Signed DELETE Cache Invalidation Gap

### Problem

The unsigned DELETE path in `handle_other_request` correctly invalidates the cache after a successful S3 response. However, the signed (AWS SigV4) DELETE path has a gap:

In the SigV4 branch of `handle_other_request`, only two specific patterns are intercepted:
- `AbortMultipartUpload` DELETE (has `uploadId` in query) → routed to PUT handler, which handles invalidation
- All other signed requests → `forward_signed_request`, which returns the S3 response with no cache invalidation

A signed DELETE of a regular object (the normal AWS CLI `aws s3 rm` path) falls into the second case. The object is deleted from S3, but the proxy's cache retains the stale entry. Subsequent GET requests serve deleted data from cache until TTL expiry or eviction.

### Why This Matters for Integrity

The LZ4 frame checksum protects against silent bit corruption, but serving data for a deleted object is a different class of correctness problem. The data is "intact" but should not exist. Combined with the frame format migration, this is a good time to close this gap since both changes touch cache consistency.

### Current Behavior

```
Client → DELETE /bucket/object (signed) → Proxy → S3 (returns 204)
                                           ↓
                                    Response returned to client
                                    Cache NOT invalidated ← bug
                                           ↓
Client → GET /bucket/object → Proxy → serves stale cached data
```

### Fix

After `forward_signed_request` returns for a DELETE method with a success status, call `invalidate_cache_unified_for_operation(&cache_key, "DELETE")` — the same pattern used in the unsigned path.

```rust
if method == Method::DELETE {
    let response = Self::forward_signed_request(req, host, s3_client).await?;
    if response.status().is_success() {
        let cache_key = CacheManager::generate_cache_key(path);
        if let Err(e) = cache_manager
            .invalidate_cache_unified_for_operation(&cache_key, "DELETE")
            .await
        {
            warn!("Failed to invalidate cache after signed DELETE: cache_key={}, error={}", cache_key, e);
        }
    }
    return Ok(response);
}
```

This needs to be inserted in the SigV4 branch of `handle_other_request`, after the AbortMultipartUpload check but before the generic signed request forwarding.

### Multi-Instance Consideration

On shared cache (EFS/NFS), the disk invalidation propagates to all instances since they share the filesystem. However, RAM cache entries on other instances remain until TTL expiry. This is an existing limitation of the architecture, not specific to this fix.

## Cleanup Tasks

Remove the `--compression-enabled` CLI flag as part of this change. The flag only enables compression (doesn't disable), making it redundant with the config file and environment variable options. Compression is enabled by default and can be disabled via:
- Config: `compression.enabled: false`
- Environment: `COMPRESSION_ENABLED=false`

## Conclusion

Switching to LZ4 frame format with content checksum provides:
- Integrity verification for all cached data
- Detection of silent corruption before serving to clients
- Minimal performance overhead (~1-3ms per 8MB)
- Native support for uncompressed blocks

The implementation is straightforward using lz4_flex's frame module.


## Simplify versionId Handling

### Current Behavior

When a GET request includes `?versionId=`, the proxy:
1. Generates cache key from path only (no versionId in key)
2. Calls `get_cached_version_id()` to read the cached `x-amz-version-id` response header
3. Compares requested versionId against cached version
4. On match: serves from cache. On mismatch/missing: bypasses cache, forwards to S3, does not cache response.

The only scenario where the cache is hit is when the requested versionId happens to match the current version already cached from a previous unversioned GET. This is a narrow optimization with significant code complexity.

### Proposed Change

Bypass cache entirely for any request with `?versionId=` in the query string. No cache read, no cache write. Forward transparently to S3.

### Implementation

Add `versionId` to `should_bypass_cache()` in `http_proxy.rs` — single place for all bypass logic. Remove the ~100 lines of version-match/mismatch branching in the GET handler. Remove `get_cached_version_id()` from `cache.rs` (becomes dead code).

### Rationale

- Versioned GETs are rare in typical workloads
- The version-match path only hits when requesting the current version by explicit ID (unusual — clients that want the current version just omit versionId)
- Simplifies the GET handler, reduces branching, removes a disk metadata read on every versioned request
- No behavior change for unversioned requests (the common case)
