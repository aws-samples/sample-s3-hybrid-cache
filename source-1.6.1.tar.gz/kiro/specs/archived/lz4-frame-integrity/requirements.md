# Requirements: LZ4 Frame Integrity & Cache Correctness

## Introduction

This spec covers three related cache correctness improvements:

1. Switch from LZ4 block format to LZ4 frame format with content checksum for integrity verification of all cached data
2. Fix signed DELETE requests not invalidating cache entries
3. Simplify versionId handling by bypassing cache entirely for versioned requests

All three changes improve cache correctness. The frame format migration is a breaking change requiring cache flush on upgrade.

## Glossary

- **LZ4 Block Format**: Current compression format using `compress_prepend_size` / `decompress_size_prepended` with no integrity verification
- **LZ4 Frame Format**: Structured format with magic number, frame descriptor, block checksums, and content checksum (xxHash-32)
- **Content Checksum**: xxHash-32 hash of the original uncompressed data, appended to the frame, verified on decompression
- **Uncompressed Block**: Frame format block with highest bit set in size field, storing data as-is with no compression overhead
- **Signed Request**: HTTP request with AWS SigV4 Authorization header
- **versionId**: S3 query parameter requesting a specific object version

## Requirements

### Requirement 1: LZ4 Frame Format Migration

**User Story:** As a proxy operator, I want cached data to be integrity-verified on read, so that silent corruption is detected before serving incorrect data to clients.

#### Acceptance Criteria

1. WHEN compressing data for cache storage, THE Proxy SHALL use LZ4 frame format with content checksum enabled (xxHash-32)
2. WHEN decompressing cached data, THE Proxy SHALL verify the content checksum and return an error if verification fails
3. WHEN content-aware compression determines data is non-compressible, THE Proxy SHALL store it in frame format with uncompressed blocks (not raw bytes)
4. ALL cached `.bin` files SHALL use frame format regardless of whether data is compressed or uncompressed
5. THE Proxy SHALL use `BlockMode::Independent` (no block linking) for frame encoding

### Requirement 2: Compression Algorithm Metadata

**User Story:** As a developer, I want the compression algorithm stored in cache metadata to accurately reflect the new format, so that decompression uses the correct code path.

#### Acceptance Criteria

1. WHEN storing compressed data, THE Proxy SHALL record `CompressionAlgorithm::Lz4` in cache metadata
2. WHEN storing non-compressible data in frame format with uncompressed blocks, THE Proxy SHALL record `CompressionAlgorithm::Lz4` (the frame wrapper is LZ4 format regardless of whether blocks are compressed)
3. WHEN decompressing, THE Proxy SHALL use the frame decoder for all `CompressionAlgorithm::Lz4` entries
4. WHEN compression is globally disabled, THE Proxy SHALL still wrap data in frame format with uncompressed blocks and record `CompressionAlgorithm::Lz4`
5. THE Proxy SHALL remove the `CompressionAlgorithm::None` variant — all cached data uses frame format

### Requirement 3: Checksum Failure Handling

**User Story:** As a proxy operator, I want corrupted cache entries to be detected and handled gracefully, so that clients never receive corrupt data.

#### Acceptance Criteria

1. WHEN a content checksum verification fails during decompression, THE Proxy SHALL return a `ProxyError::CompressionError` with a descriptive message
2. WHEN a checksum failure occurs, THE Proxy SHALL log at ERROR level with the cache key and error details
3. WHEN a checksum failure occurs on a cache read, THE Proxy SHALL forward the request to S3 (cache miss fallback behavior)
4. THE Proxy SHALL automatically delete cache entries that fail checksum verification

### Requirement 4: Cache Format Breaking Change

**User Story:** As a proxy operator, I want a clean transition to the new format, so that old-format cache entries don't cause errors.

#### Acceptance Criteria

1. THE Proxy SHALL NOT attempt to read old block-format `.bin` files with the new frame decoder
2. WHEN upgrading, the operator SHALL flush the cache directory before starting the new version
3. THE Proxy SHALL document the cache flush requirement in CHANGELOG

### Requirement 5: Signed DELETE Cache Invalidation

**User Story:** As a client using AWS CLI, I want `aws s3 rm` (signed DELETE) to invalidate the proxy cache, so that subsequent GET requests don't serve deleted data.

#### Acceptance Criteria

1. WHEN a signed (SigV4) DELETE request for a regular object (no `uploadId` in query) receives a success response from S3, THE Proxy SHALL invalidate all cache layers for that object
2. THE Proxy SHALL use `invalidate_cache_unified_for_operation` with operation "DELETE" for signed DELETE invalidation
3. WHEN cache invalidation fails after a signed DELETE, THE Proxy SHALL log at WARN level and still return the successful S3 response to the client
4. THE Proxy SHALL NOT modify the existing AbortMultipartUpload DELETE handling (requests with `uploadId` continue routing to PUT handler)

### Requirement 6: Simplify versionId Handling

**User Story:** As a developer, I want simpler versionId handling that avoids unnecessary cache metadata reads, so that the GET handler is easier to maintain.

#### Acceptance Criteria

1. WHEN a GET or HEAD request contains `?versionId=` in the query string, THE Proxy SHALL bypass the cache entirely (no cache read, no cache write)
2. THE Proxy SHALL forward versioned requests transparently to S3
3. THE Proxy SHALL record a cache bypass metric with reason "versioned_request" for versioned requests
4. THE Proxy SHALL remove the `get_cached_version_id()` method from `cache.rs` (dead code after this change)
5. THE Proxy SHALL NOT change behavior for unversioned requests (the common case)

### Requirement 7: Remove --compression-enabled CLI Flag

**User Story:** As a developer, I want to remove the redundant CLI flag, so that compression configuration has a single source of truth.

#### Acceptance Criteria

1. THE Proxy SHALL remove the `--compression-enabled` CLI argument from `config.rs`
2. THE Proxy SHALL retain the `COMPRESSION_ENABLED` environment variable
3. THE Proxy SHALL retain the `compression.enabled` config file option
4. Compression SHALL remain enabled by default
