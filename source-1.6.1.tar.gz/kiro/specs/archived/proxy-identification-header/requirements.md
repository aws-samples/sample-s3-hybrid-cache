# Requirements Document

## Introduction

This feature adds proxy identification headers to requests forwarded to S3, enabling the proxy team to track usage and debug issues. The Referer header is used because it appears in S3 Server Access Logs (SAL), providing visibility into proxy-forwarded requests. The implementation must not break AWS SigV4 signature validation, which means only unsigned headers can be added.

**Note:** The Referer header is captured in S3 Server Access Logs, making it ideal for tracking proxy usage. Alternative headers like Via are not captured in SAL.

## Glossary

- **Proxy**: The S3 caching proxy that forwards requests to Amazon S3
- **Referer_Header**: HTTP header typically used to indicate the referring page, repurposed here for proxy identification since it appears in S3 Server Access Logs
- **SAL**: S3 Server Access Logs, which capture the Referer header value
- **Unsigned_Header**: HTTP headers not included in the AWS SigV4 SignedHeaders list, which can be added without invalidating the signature
- **SigV4**: AWS Signature Version 4, the authentication protocol used for AWS API requests
- **Instance_ID**: The hostname of the proxy instance, used to identify which proxy handled a request

## Requirements

### Requirement 1: Referer Header Addition

**User Story:** As a proxy operator, I want to track which requests pass through the proxy and which instance handled them in S3 Server Access Logs, so that I can monitor usage and debug issues.

#### Acceptance Criteria

1. WHEN forwarding a request to S3, THE Proxy SHALL add a Referer header in the format `s3-hybrid-cache/{version} ({hostname})`
2. THE Proxy SHALL include the proxy version number from Cargo.toml
3. THE Proxy SHALL include the system hostname to identify the specific proxy instance
4. WHEN a request already contains a Referer header, THE Proxy SHALL preserve the original value and NOT add proxy identification

### Requirement 2: Configuration

**User Story:** As a system administrator, I want to enable or disable proxy identification headers, so that I can control what information is exposed in S3 Server Access Logs.

#### Acceptance Criteria

1. THE Proxy SHALL provide a configuration option `server.add_referer_header` to enable/disable Referer header addition
2. WHEN `server.add_referer_header` is not specified, THE Proxy SHALL default to `true` (enabled)
3. WHEN `server.add_referer_header` is `false`, THE Proxy SHALL NOT add Referer headers
4. THE Proxy SHALL validate the configuration at startup

### Requirement 3: SigV4 Compatibility

**User Story:** As a developer, I want the proxy to add identification headers without breaking AWS authentication, so that requests continue to work correctly.

#### Acceptance Criteria

1. THE Proxy SHALL only add headers that are not included in the SigV4 SignedHeaders list
2. WHEN adding the Referer header, THE Proxy SHALL NOT modify any signed headers
3. THE Proxy SHALL preserve all original request headers when adding the Referer header
4. IF the Referer header is included in SignedHeaders, THE Proxy SHALL NOT modify it

### Requirement 4: Logging

**User Story:** As an operations engineer, I want to see when proxy identification headers are added, so that I can verify the feature is working.

#### Acceptance Criteria

1. WHEN proxy identification is enabled, THE Proxy SHALL log at DEBUG level when adding Referer headers
2. WHEN proxy identification is disabled via configuration, THE Proxy SHALL log at INFO level once at startup
3. IF adding a Referer header fails for any reason, THE Proxy SHALL log at WARN level and continue processing the request
