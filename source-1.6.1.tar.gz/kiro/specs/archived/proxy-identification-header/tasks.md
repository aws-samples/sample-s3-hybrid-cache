# Tasks: Proxy Identification Header

## Tasks

- [x] 1. Add configuration
  - [x] 1.1 Add `add_referer_header: bool` field to `ServerConfig` in `src/config.rs` with `#[serde(default)]` defaulting to `true`
    - _Requirements: 2.1, 2.2, 2.4_
  - [x] 1.2 Add `add_referer_header: true` to `config/config.example.yaml` under `server:` with comment
    - _Requirements: 2.1_
  - [x] 1.3 Add unit test for config parsing (enabled, disabled, default)
    - _Requirements: 2.2, 2.3_

- [x] 2. Build and store Referer string at startup
  - [x] 2.1 Add `proxy_referer: Option<String>` field to `HttpProxy`
    - _Requirements: 1.1, 1.2, 1.3_
  - [x] 2.2 Initialize in `HttpProxy::new()` — build `s3-hybrid-cache/{version} ({hostname})` when enabled, `None` when disabled
    - _Requirements: 1.2, 1.3, 2.3_
  - [x] 2.3 Log at INFO level once at startup when disabled
    - _Requirements: 4.2_

- [x] 3. Inject Referer in GET/HEAD/DELETE forwarding path
  - [x] 3.1 Add helper `fn maybe_add_referer(headers: &mut HashMap<String, String>, proxy_referer: &Option<String>, auth_header: Option<&str>)`
    - Check: proxy_referer is Some, `referer` not already in headers, `referer` not in SignedHeaders
    - _Requirements: 1.1, 1.4, 3.1, 3.2, 3.3, 3.4_
  - [x] 3.2 Call `maybe_add_referer` before `build_s3_request_context` in `forward_get_head_to_s3_and_cache`
    - _Requirements: 1.1_
  - [x] 3.3 Call `maybe_add_referer` before `build_s3_request_context` in `forward_get_head_to_s3_without_caching`
    - _Requirements: 1.1_
  - [x] 3.4 Call `maybe_add_referer` before `build_s3_request_context` in `forward_conditional_request_to_s3`
    - _Requirements: 1.1_
  - [x] 3.5 Call `maybe_add_referer` before `build_s3_request_context` in `forward_range_request_to_s3`
    - _Requirements: 1.1_
  - [x] 3.6 Call `maybe_add_referer` before `build_s3_request_context` in `forward_signed_range_request`
    - _Requirements: 1.1_

- [x] 4. Inject Referer in signed PUT forwarding path
  - [x] 4.1 In `signed_request_proxy.rs` `forward_signed_request`, inject Referer into raw request headers before sending
    - Check same conditions as 3.1
    - _Requirements: 1.1, 3.1, 3.2_
  - [x] 4.2 In `signed_put_handler.rs` `forward_raw_request_to_s3`, inject Referer into raw request headers
    - _Requirements: 1.1, 3.1_

- [x] 5. Thread proxy_referer through call chain
  - [x] 5.1 Pass `proxy_referer` from `HttpProxy` through `handle_request` → `handle_get_head_request` → forwarding functions
    - _Requirements: 1.1_
  - [x] 5.2 Pass `proxy_referer` to `SignedPutHandler` and `signed_request_proxy` forwarding paths
    - _Requirements: 1.1_

- [x] 6. Unit tests
  - [x] 6.1 Test `maybe_add_referer` adds header when conditions met
    - _Requirements: 1.1, 1.2, 1.3_
  - [x] 6.2 Test `maybe_add_referer` skips when Referer already present
    - _Requirements: 1.4_
  - [x] 6.3 Test `maybe_add_referer` skips when `referer` is in SignedHeaders
    - _Requirements: 3.1, 3.4_
  - [x] 6.4 Test `maybe_add_referer` skips when proxy_referer is None (disabled)
    - _Requirements: 2.3_
  - [x] 6.5 Test header format matches `s3-hybrid-cache/{version} ({hostname})`
    - _Requirements: 1.2, 1.3_

- [x] 7. Documentation
  - [x] 7.1 Add `add_referer_header` to `docs/CONFIGURATION.md` under Server Configuration
    - _Requirements: 2.1_
  - [x] 7.2 Update CHANGELOG.md
