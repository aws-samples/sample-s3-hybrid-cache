# Design: Proxy Identification Header

## Overview

Add a `Referer` header to requests forwarded to S3 for tracking in S3 Server Access Logs. The header identifies the proxy version and instance hostname. Only added when the header is unsigned and not already present.

## Implementation

### Header Format

```
Referer: s3-hybrid-cache/1.2.7 (ip-172-31-34-221.us-west-2.compute.internal)
```

### Where to Add

The header is injected in the S3 request forwarding path, after SigV4 analysis but before the request is sent. Two code paths forward requests to S3:

1. `s3_client.rs` — `forward_request()` for GET/HEAD/DELETE
2. `signed_request_proxy.rs` — `forward_signed_request()` for signed PUT and raw forwarding

Both paths construct an `S3RequestContext` with headers. The Referer header is added to the headers map before forwarding.

### SigV4 Safety

Parse the `Authorization` header's `SignedHeaders` field (already done by `parse_signed_headers()` in `signed_request_proxy.rs`). If `referer` is in the signed headers list, skip injection. If the request has no `Authorization` header (unsigned), always safe to add.

### Configuration

Add `add_referer_header: bool` to `ServerConfig` with `#[serde(default = "default_true")]`. Check this flag once at request handling time.

### Hostname Caching

Call `gethostname()` once at startup and store in `HttpProxy`. Don't call it per-request.

## Component Changes

### config.rs

Add to `ServerConfig`:
```rust
#[serde(default = "default_add_referer_header")]
pub add_referer_header: bool,
```

### http_proxy.rs

Add `proxy_referer: Option<String>` field to `HttpProxy`, initialized in `new()`:
```rust
let proxy_referer = if config.server.add_referer_header {
    let hostname = gethostname::gethostname().to_string_lossy().to_string();
    Some(format!("s3-hybrid-cache/{} ({})", env!("CARGO_PKG_VERSION"), hostname))
} else {
    None
};
```

### s3_client.rs — build_s3_request_context()

The `build_s3_request_context` function takes a `headers: HashMap<String, String>`. The caller (http_proxy.rs) adds the Referer header to this map before calling, if:
- `proxy_referer` is `Some`
- `referer` key not already in headers
- `referer` not in SignedHeaders (checked via existing `parse_signed_headers`)

### signed_request_proxy.rs

Same pattern — before forwarding, check and inject Referer into the raw request headers.

## Files to Modify

1. `src/config.rs` — Add `add_referer_header` field to `ServerConfig`
2. `src/http_proxy.rs` — Store `proxy_referer` string, inject into headers before S3 forwarding
3. `src/signed_request_proxy.rs` — Inject Referer into signed request forwarding path
4. `config/config.example.yaml` — Add `add_referer_header` option
5. `docs/CONFIGURATION.md` — Document the setting

## Testing

- Unit test: Referer header added when not present and not signed
- Unit test: Referer header NOT added when already present
- Unit test: Referer header NOT added when `referer` is in SignedHeaders
- Unit test: Referer header NOT added when config disabled
- Unit test: Header format matches expected pattern
