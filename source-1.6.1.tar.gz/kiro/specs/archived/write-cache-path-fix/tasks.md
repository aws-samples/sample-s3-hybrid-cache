# Implementation Plan

- [x] 1. Implement cache key sanitization function
  - Add `sanitize_cache_key()` helper function to `src/signed_put_handler.rs`
  - Function should strip all leading `/` characters from cache keys
  - Add documentation explaining the PathBuf::join() behavior
  - _Requirements: 2.1, 2.3_

- [ ]* 1.1 Write property test for leading slash removal
  - **Property 2: Leading slash removal**
  - **Validates: Requirements 2.1**

- [ ]* 1.2 Write property test for sanitization idempotence
  - **Property 8: Sanitization idempotence**
  - **Validates: Requirements 2.1**

- [x] 2. Update cache path construction in handle_with_caching
  - Apply `sanitize_cache_key()` before constructing cache paths
  - Update both regular PUT and multipart upload code paths
  - Verify paths are constructed correctly
  - _Requirements: 2.1, 2.2, 2.4_

- [ ]* 2.1 Write property test for cache path containment
  - **Property 1: Cache path containment**
  - **Validates: Requirements 2.2**

- [ ]* 2.2 Write property test for directory structure preservation
  - **Property 3: Directory structure preservation**
  - **Validates: Requirements 2.4**

- [x] 3. Implement graceful cache failure handling
  - Wrap `CacheWriter::new()` calls in match expressions
  - On error, log warning with cache key and error details
  - Record cache write failure metric
  - Continue with proxy-only mode (no caching)
  - _Requirements: 1.1, 1.2, 1.4, 3.2, 3.3_

- [ ]* 3.1 Write property test for upload success independence
  - **Property 4: Upload success independence from caching**
  - **Validates: Requirements 1.1, 1.3**

- [ ]* 3.2 Write property test for cache failure logging
  - **Property 5: Cache failure logging**
  - **Validates: Requirements 1.2, 3.2**

- [ ]* 3.3 Write property test for cache failure metrics
  - **Property 6: Cache failure metrics**
  - **Validates: Requirements 1.4**

- [ ]* 3.4 Write property test for fallback logging
  - **Property 7: Fallback logging**
  - **Validates: Requirements 3.3**

- [x] 4. Add cache write failure metric
  - Add `cache_write_failures_total` counter to metrics module
  - Increment counter when cache writer creation fails
  - Include metric in metrics endpoint output
  - _Requirements: 1.4_

- [x] 5. Implement asynchronous cache write task spawner
  - Create `spawn_cache_write_task()` function in `src/signed_put_handler.rs`
  - Function should accept cache key, body data, S3 result channel, cache, and metrics
  - Use `tokio::spawn` to run cache operations in background
  - Handle cache writer creation, writing, and commit/discard logic
  - Include graceful error handling: log warnings on cache failures, record metrics
  - _Requirements: 4.3, 4.4, 4.5, 1.2, 1.4_

- [ ]* 5.1 Write property test for client response independence
  - **Property 9: Client response independence from cache timing**
  - **Validates: Requirements 4.1, 4.2**

- [ ]* 5.2 Write property test for background cache commit
  - **Property 10: Background cache commit on S3 success**
  - **Validates: Requirements 4.4**

- [ ]* 5.3 Write property test for background cache discard
  - **Property 11: Background cache discard on S3 failure**
  - **Validates: Requirements 4.5**

- [ ]* 5.4 Write property test for async cache failure logging
  - **Property 12: Async cache failure logging**
  - **Validates: Requirements 4.5**

- [x] 6. Refactor handle_with_caching to use async caching
  - Read request body into `Bytes` before forwarding to S3
  - Ensure body is read exactly once to preserve AWS SigV4 signatures
  - Use `Bytes::clone()` for cheap reference-counted copies to S3 and cache
  - Create `tokio::sync::oneshot` channel for S3 result communication
  - Spawn background cache task with sanitized cache key, body data, and result receiver
  - Forward request to S3 immediately without waiting for cache
  - Send S3 result through channel to background task
  - Return S3 response to client immediately
  - _Requirements: 4.1, 4.2, 4.3, 1.1, 1.3_

- [x] 7. Add error handling for channel communication
  - Handle case where S3 result channel is closed unexpectedly
  - Log warnings when background task cannot receive S3 result
  - Ensure cache is discarded if channel communication fails
  - _Requirements: 4.5_

- [x] 8. Update handle_with_streaming_capacity_check for async caching
  - Apply same async caching pattern to streaming capacity check path
  - Ensure consistency across all PUT handling code paths
  - Use sanitized cache keys and background tasks
  - _Requirements: 2.1, 2.2, 4.1, 4.2, 4.3_

- [ ]* 9. Write integration test for cache path construction
  - Test with real S3-style cache keys (starting with `/`)
  - Verify cache files are created in correct locations within cache directory
  - Verify directory structure matches expected layout
  - _Requirements: 2.1, 2.2, 2.4_

- [ ]* 10. Write integration test for cache failure fallback
  - Configure cache directory to read-only location
  - Perform PUT request
  - Verify upload succeeds despite cache failure
  - Verify warning is logged
  - Verify no cache files created outside cache directory
  - _Requirements: 1.1, 1.2, 1.3, 3.2, 3.3_

- [ ]* 11. Write integration test for multipart upload with cache failure
  - Test multipart upload with cache write failures
  - Verify all parts upload successfully
  - Verify completion succeeds
  - Verify metrics are recorded
  - _Requirements: 1.1, 1.3, 1.4_

- [ ]* 12. Write integration test for async cache write timing
  - Perform PUT request with large body
  - Measure time to receive client response
  - Verify response arrives before cache write completes
  - Verify cache is eventually populated
  - _Requirements: 4.1, 4.2, 4.3, 4.4_

- [ ]* 13. Write integration test for async cache commit on S3 success
  - Perform PUT request
  - Verify client receives S3 success response immediately
  - Wait for background task completion
  - Verify cached data is available for subsequent GET
  - _Requirements: 4.2, 4.4_

- [ ]* 14. Write integration test for async cache discard on S3 failure
  - Perform PUT request that will fail at S3
  - Verify client receives S3 error response immediately
  - Wait for background task completion
  - Verify no cached data is available for subsequent GET
  - _Requirements: 4.2, 4.5_

- [x] 15. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
