# Write Cache Path Fix - Issue Summary

## Problem

When a regular PUT request succeeds (S3 returns 200), the proxy commits the data to the write cache directory (`tmp/cache/write_cache/`) but does NOT move it to the regular range cache. This causes:

1. **GET requests miss the cached data** - `get_cached_response()` only checks RAM and disk cache (objects/ranges), not write_cache
2. **Wasted disk space** - Write cache files remain until PUT_TTL expires, invisible to GET requests
3. **Unnecessary S3 fetches** - Subsequent GETs fetch from S3 even though data is cached locally

## Current Behavior

```
PUT /bucket/file.zip
  ↓
Write to: tmp/cache/write_cache/bucket/file.zip
  ↓
S3 returns 200
  ↓
Commit to write cache ✓
  ↓
[BUG] File stays in write_cache/
  ↓
GET /bucket/file.zip
  ↓
Cache miss (write_cache not checked)
  ↓
Fetch from S3 ❌
```

## Expected Behavior (Like MPU)

```
PUT /bucket/file.zip
  ↓
Write to: tmp/cache/write_cache/bucket/file.zip
  ↓
S3 returns 200
  ↓
Move to: tmp/cache/ranges/{cache_key}_0-{size}.bin
Create: tmp/cache/objects/{cache_key}.meta
  ↓
GET /bucket/file.zip
  ↓
Cache hit ✓
```

## Solution

After S3 returns 200 in `spawn_cache_write_task`, move the write cache file to the regular range cache:

1. Read the committed write cache file
2. Store as range: `cache_manager.store_range(cache_key, 0, size, data)`
3. Delete the write cache file
4. This makes the data available for GET requests

## Files to Modify

- `src/signed_put_handler.rs`: Update `spawn_cache_write_task()` to move data after S3 success
- Possibly `src/cache.rs`: Add helper method to transition write cache to range cache

## Related

This is similar to how multipart uploads work - parts are stored temporarily during upload, then moved to the regular cache after `CompleteMultipartUpload` succeeds.
