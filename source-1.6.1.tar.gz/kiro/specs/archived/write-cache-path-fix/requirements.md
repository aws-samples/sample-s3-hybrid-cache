# Requirements Document

## Introduction

The S3 Proxy write cache currently has three critical issues:
1. Cache paths are constructed incorrectly when the cache key starts with `/`, causing writes to absolute paths outside the cache directory
2. Cache write failures block the entire upload instead of falling back to proxying without caching
3. Cache writes are synchronous, forcing clients to wait for cache operations before receiving S3 responses

These issues prevent multipart uploads from completing, add unnecessary latency to uploads, and violate the proxy's transparent forwarder principle.

## Glossary

- **Cache Key**: The S3 object path used as an identifier, typically in the format `/bucket-name/object-key`
- **Write Cache**: Temporary storage for PUT request data before it's confirmed by S3
- **Cache Directory**: The configured root directory for all cache storage (e.g., `/var/cache/s3-proxy`)
- **Transparent Forwarder**: The proxy's core principle that it should never block S3 operations - it only adds caching as an optimization
- **PathBuf::join()**: Rust's path joining method that replaces the entire path when given an absolute path argument

## Requirements

### Requirement 1

**User Story:** As a user uploading files through the proxy, I want my uploads to succeed even if caching fails, so that the proxy doesn't block my S3 operations.

#### Acceptance Criteria

1. WHEN a cache write fails for any reason THEN the system SHALL continue forwarding the request to S3 without caching
2. WHEN a cache write fails THEN the system SHALL log the failure at WARN level with the specific error
3. WHEN a cache write fails THEN the system SHALL return the S3 response to the client unchanged
4. WHEN a cache write fails THEN the system SHALL record a cache write failure metric

### Requirement 2

**User Story:** As a system administrator, I want cache files to be stored within the configured cache directory, so that I can manage disk space and permissions correctly.

#### Acceptance Criteria

1. WHEN constructing a cache path with a cache key starting with `/` THEN the system SHALL strip the leading `/` before joining paths
2. WHEN constructing a cache path THEN the system SHALL ensure the final path is within the cache directory
3. WHEN constructing a cache path THEN the system SHALL handle cache keys with multiple leading slashes
4. WHEN constructing a cache path THEN the system SHALL preserve the directory structure of the cache key within the cache directory

### Requirement 3

**User Story:** As a developer, I want clear error messages when cache operations fail, so that I can diagnose and fix issues quickly.

#### Acceptance Criteria

1. WHEN a cache directory creation fails THEN the system SHALL log the attempted path and the OS error
2. WHEN a cache write fails THEN the system SHALL include the cache key and error details in the log message
3. WHEN falling back from caching to proxying THEN the system SHALL log the reason for the fallback

### Requirement 4

**User Story:** As a user uploading files through the proxy, I want the fastest possible upload times, so that my applications perform optimally.

#### Acceptance Criteria

1. WHEN a PUT request is received THEN the system SHALL forward the request to S3 without waiting for cache write completion
2. WHEN the S3 response is received THEN the system SHALL return it to the client immediately without waiting for cache operations
3. WHEN cache writes are in progress THEN the system SHALL handle them asynchronously in background tasks
4. WHEN a background cache write completes successfully THEN the system SHALL commit the cached data for future reads
5. WHEN a background cache write fails THEN the system SHALL discard the cached data and log the failure
