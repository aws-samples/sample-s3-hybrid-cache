# Design Document

## Overview

This design addresses three critical issues in the write cache implementation:

1. **Path Construction Bug**: The `PathBuf::join()` method replaces the entire path when given an absolute path, causing cache files to be written outside the cache directory
2. **Error Handling Bug**: Cache write failures propagate as errors to the client, blocking uploads instead of falling back to transparent proxying
3. **Synchronous Caching Latency**: Cache writes block the client response, adding unnecessary latency to uploads

The fix involves sanitizing cache keys before path construction, implementing graceful degradation when caching fails, and making cache writes asynchronous to eliminate client-visible latency.

## Architecture

### Current Flow (Buggy)

```
Client PUT → SignedPutHandler
  ↓
  Check capacity
  ↓
  Create CacheWriter with path: cache_dir.join("write_cache").join("/bucket/key")
  ↓
  PathBuf::join() sees absolute path → replaces entire path → "/bucket/key"
  ↓
  Try to create directory "/bucket" → FAIL (Read-only file system)
  ↓
  Return error to client → Upload blocked ❌
```

### Fixed Flow (Synchronous - Intermediate)

```
Client PUT → SignedPutHandler
  ↓
  Check capacity
  ↓
  Sanitize cache key: "/bucket/key" → "bucket/key"
  ↓
  Create CacheWriter with path: cache_dir.join("write_cache").join("bucket/key")
  ↓
  Result: "/var/cache/s3-proxy/write_cache/bucket/key" ✓
  ↓
  If cache write fails:
    ↓
    Log warning
    ↓
    Continue proxying to S3 without caching
    ↓
    Return S3 response to client → Upload succeeds ✓
```

### Optimized Flow (Asynchronous - Final)

```
Client PUT → SignedPutHandler
  ↓
  Read body into memory (preserves SigV4 signature)
  ↓
  Spawn background task:
    ↓
    Sanitize cache key
    ↓
    Create CacheWriter
    ↓
    Write to cache
    ↓
    Wait for S3 result
    ↓
    If S3 success: commit cache
    ↓
    If S3 failure: discard cache
  ↓
  Forward request to S3 immediately (don't wait for cache)
  ↓
  Receive S3 response
  ↓
  Return to client immediately ✓ (cache still writing in background)
```

**Key Benefits**:
- Client doesn't wait for cache writes
- Upload latency reduced significantly
- Better alignment with "transparent forwarder" principle
- Cache failures don't impact upload latency
- SigV4 signatures still preserved (body read once)

## Components and Interfaces

### 1. Cache Key Sanitization

**Location**: `src/signed_put_handler.rs`

**Function**: `sanitize_cache_key(cache_key: &str) -> String`

```rust
/// Sanitize a cache key for safe path construction
///
/// Removes leading slashes to prevent PathBuf::join() from treating
/// the key as an absolute path, which would replace the cache directory.
///
/// # Arguments
///
/// * `cache_key` - The raw cache key (e.g., "/bucket/object")
///
/// # Returns
///
/// A sanitized cache key safe for path joining (e.g., "bucket/object")
///
/// # Examples
///
/// ```
/// assert_eq!(sanitize_cache_key("/bucket/key"), "bucket/key");
/// assert_eq!(sanitize_cache_key("///bucket/key"), "bucket/key");
/// assert_eq!(sanitize_cache_key("bucket/key"), "bucket/key");
/// ```
fn sanitize_cache_key(cache_key: &str) -> String {
    cache_key.trim_start_matches('/').to_string()
}
```

### 2. Graceful Cache Failure Handling

**Location**: `src/signed_put_handler.rs` - `handle_with_caching()` method

**Current Behavior**:
```rust
let mut cache_writer = CacheWriter::new(...).await?;  // ❌ Propagates error
```

**Fixed Behavior**:
```rust
let mut cache_writer = match CacheWriter::new(...).await {
    Ok(writer) => Some(writer),
    Err(e) => {
        warn!("Failed to create cache writer for {}: {}. Falling back to proxy-only mode.", cache_key, e);
        // Record metric
        if let Some(metrics) = &self.metrics_manager {
            metrics.read().await.record_cache_write_failure().await;
        }
        None  // Continue without caching
    }
};
```

### 3. Asynchronous Cache Write Handler

**Location**: `src/signed_put_handler.rs` - New background task

**Purpose**: Handle cache writes asynchronously without blocking client responses

**Implementation**:

```rust
/// Spawn a background task to handle cache writing
///
/// This function spawns a tokio task that:
/// 1. Creates a cache writer
/// 2. Writes the body data to cache
/// 3. Waits for the S3 result
/// 4. Commits or discards based on S3 success/failure
///
/// # Arguments
///
/// * `cache_key` - Sanitized cache key
/// * `body_data` - The request body data (already read)
/// * `s3_result_rx` - Channel receiver for S3 operation result
/// * `cache` - Arc reference to cache manager
/// * `metrics` - Arc reference to metrics manager
fn spawn_cache_write_task(
    cache_key: String,
    body_data: Bytes,
    s3_result_rx: tokio::sync::oneshot::Receiver<Result<Response<Body>>>,
    cache: Arc<RwLock<Cache>>,
    metrics: Option<Arc<RwLock<MetricsManager>>>,
) {
    tokio::spawn(async move {
        // Create cache writer
        let mut cache_writer = match CacheWriter::new(...).await {
            Ok(writer) => writer,
            Err(e) => {
                warn!("Background cache write failed to create writer for {}: {}", cache_key, e);
                if let Some(m) = metrics {
                    m.read().await.record_cache_write_failure().await;
                }
                return;
            }
        };
        
        // Write body to cache
        if let Err(e) = cache_writer.write_all(&body_data).await {
            warn!("Background cache write failed for {}: {}", cache_key, e);
            cache_writer.discard().await;
            return;
        }
        
        // Wait for S3 result
        match s3_result_rx.await {
            Ok(Ok(_response)) => {
                // S3 success - commit cache
                if let Err(e) = cache_writer.commit().await {
                    warn!("Failed to commit cache for {}: {}", cache_key, e);
                }
            }
            Ok(Err(_)) | Err(_) => {
                // S3 failure or channel error - discard cache
                cache_writer.discard().await;
            }
        }
    });
}
```

### 4. Request Flow Coordination

**Channel-Based Communication**:
- Use `tokio::sync::oneshot` channel to communicate S3 result to background task
- Main request handler sends S3 result through channel
- Background task waits for result before committing/discarding cache

**Body Handling**:
- Read body once into `Bytes` (preserves SigV4 signature)
- Clone `Bytes` for S3 request (cheap, reference-counted)
- Pass `Bytes` to background cache task

## Data Models

No new data models required. Existing structures remain unchanged:

- `CacheWriter`: Existing implementation is correct
- `ObjectMetadata`: No changes needed
- `SignedPutHandler`: Add helper method for sanitization

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Cache path containment

*For any* cache key and cache directory, the constructed cache path should always be a descendant of the cache directory, never an absolute path outside it.

**Validates: Requirements 2.2**

### Property 2: Leading slash removal

*For any* cache key starting with one or more `/` characters, the sanitization function should remove all leading slashes.

**Validates: Requirements 2.1**

### Property 3: Directory structure preservation

*For any* cache key with directory separators, the sanitized key should preserve the relative directory structure within the cache directory.

**Validates: Requirements 2.4**

### Property 4: Upload success independence from caching

*For any* PUT request where S3 returns success, the client should receive a success response regardless of whether cache writer creation succeeded or failed.

**Validates: Requirements 1.1, 1.3**

### Property 5: Cache failure logging

*For any* cache write failure, the system should log a warning message containing both the cache key and error details.

**Validates: Requirements 1.2, 3.2**

### Property 6: Cache failure metrics

*For any* cache write failure, the system should increment the cache write failure metric counter.

**Validates: Requirements 1.4**

### Property 7: Fallback logging

*For any* transition from caching mode to proxy-only mode, the system should log the reason for the fallback.

**Validates: Requirements 3.3**

### Property 8: Sanitization idempotence

*For any* cache key, applying sanitization multiple times should produce the same result as applying it once.

**Validates: Requirements 2.1**

### Property 9: Client response independence from cache timing

*For any* PUT request where S3 returns a response, the client should receive that response without waiting for cache write completion.

**Validates: Requirements 4.1, 4.2**

### Property 10: Background cache commit on S3 success

*For any* PUT request where S3 returns success and cache write succeeds, the cached data should eventually be committed and available for future reads.

**Validates: Requirements 4.4**

### Property 11: Background cache discard on S3 failure

*For any* PUT request where S3 returns failure, any cached data should be discarded and not available for future reads.

**Validates: Requirements 4.5**

### Property 12: Async cache failure logging

*For any* background cache write failure, the system should log the failure without affecting the client response.

**Validates: Requirements 4.5**

## Error Handling

### Cache Writer Creation Failures

**Causes**:
- Directory creation fails (permissions, read-only filesystem, disk full)
- Temporary file creation fails

**Handling**:
1. Log warning with cache key and error details (Requirement 3.2)
2. Record cache write failure metric (Requirement 1.4)
3. Continue with proxy-only mode (Requirement 1.1)
4. Return S3 response to client (Requirement 1.3)

### Mid-Stream Cache Write Failures

**Causes**:
- Disk full during write
- I/O errors
- Capacity exceeded

**Handling**:
1. Call `cache_writer.discard()` to clean up temporary files
2. Log warning (Requirement 3.2)
3. Continue streaming to S3
4. Return S3 response to client

### Path Construction Validation

**Validation**:
- After sanitization, verify the path doesn't contain `..` components
- Verify the final path starts with the cache directory
- Log any suspicious patterns

## Testing Strategy

### Unit Tests

1. **Cache Key Sanitization**:
   - Test single leading slash removal
   - Test multiple leading slashes
   - Test keys without leading slashes
   - Test empty strings
   - Test keys with only slashes

2. **Path Construction**:
   - Verify sanitized keys produce correct paths
   - Verify paths are within cache directory
   - Test with various cache directory configurations

3. **Error Handling**:
   - Mock CacheWriter creation failure
   - Verify fallback to proxy-only mode
   - Verify S3 response is returned
   - Verify metrics are recorded

### Property-Based Tests

Property-based tests will use the `quickcheck` framework to generate random inputs and verify correctness properties hold across all cases.

**Test Configuration**:
- Minimum 100 iterations per property test
- Use custom generators for cache keys (with/without leading slashes, various lengths, special characters)

**Property Test 1: Cache Path Containment**
```rust
#[quickcheck]
fn prop_cache_path_always_within_cache_dir(cache_key: String) -> bool {
    let cache_dir = PathBuf::from("/var/cache/s3-proxy");
    let sanitized = sanitize_cache_key(&cache_key);
    let final_path = cache_dir.join("write_cache").join(&sanitized);
    
    // Property: final path must start with cache_dir
    final_path.starts_with(&cache_dir)
}
```

**Property Test 2: Sanitization Idempotence**
```rust
#[quickcheck]
fn prop_sanitization_idempotent(cache_key: String) -> bool {
    let once = sanitize_cache_key(&cache_key);
    let twice = sanitize_cache_key(&once);
    
    // Property: sanitizing twice = sanitizing once
    once == twice
}
```

**Property Test 3: No Absolute Paths After Sanitization**
```rust
#[quickcheck]
fn prop_sanitized_keys_not_absolute(cache_key: String) -> bool {
    let sanitized = sanitize_cache_key(&cache_key);
    
    // Property: sanitized keys should never start with /
    !sanitized.starts_with('/')
}
```

### Integration Tests

1. **End-to-End Upload with Cache Failure**:
   - Configure cache directory to read-only location
   - Perform PUT request
   - Verify upload succeeds
   - Verify warning is logged
   - Verify no cache files created

2. **Multipart Upload with Cache Failure**:
   - Test multipart upload with cache write failures
   - Verify all parts upload successfully
   - Verify completion succeeds

3. **Path Construction Verification**:
   - Test with real cache keys from S3
   - Verify cache files are created in correct locations
   - Verify directory structure matches S3 structure

4. **Async Cache Write Timing**:
   - Perform PUT request with large body
   - Measure time to receive client response
   - Verify response arrives before cache write completes
   - Verify cache is eventually populated

5. **Async Cache Commit on S3 Success**:
   - Perform PUT request
   - Verify client receives S3 success response immediately
   - Wait for background task completion
   - Verify cached data is available for subsequent GET

6. **Async Cache Discard on S3 Failure**:
   - Perform PUT request that will fail at S3 (e.g., invalid credentials)
   - Verify client receives S3 error response immediately
   - Wait for background task completion
   - Verify no cached data is available for subsequent GET

### Edge Cases

1. Cache key is empty string
2. Cache key is only slashes (`/`, `//`, `///`)
3. Cache key contains `..` components
4. Cache directory doesn't exist (should be created)
5. Cache directory is read-only
6. Disk full during cache write

**Note**: Very long cache keys are already handled by the existing SHA256 hashing mechanism in the codebase, so no additional handling is needed for path length limits.

## Implementation Notes

### Rust PathBuf Behavior

The root cause of the bug is Rust's `PathBuf::join()` behavior:

```rust
let base = PathBuf::from("/var/cache");
let absolute = "/bucket/key";
let result = base.join(absolute);
// result = "/bucket/key" (NOT "/var/cache/bucket/key")
```

This is documented behavior but easy to miss. The fix is to strip leading slashes before joining.

### Backward Compatibility

This fix is backward compatible:
- Existing cache entries remain valid
- No cache invalidation needed
- Cache keys without leading slashes work as before

### Performance Impact

**Synchronous Fixes**: Minimal overhead
- `trim_start_matches('/')` is O(n) where n is the number of leading slashes (typically 1)
- No additional allocations beyond the sanitized string
- Fallback path (proxy-only) is actually faster than caching

**Asynchronous Caching**: Significant improvement
- Client response time reduced by cache write duration (can be seconds for large files)
- Upload latency no longer includes cache write time
- Background tasks use separate tokio threads, no blocking
- Memory overhead: one `Bytes` clone per request (reference-counted, cheap)
- One additional tokio task per PUT request (minimal overhead)

### Metrics

Add new metric: `cache_write_failures_total`
- Counter incremented when cache writer creation fails
- Helps operators identify cache configuration issues
