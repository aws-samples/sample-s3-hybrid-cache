# Design Document: AWS Chunked Decoding for Write Cache

## Overview

The S3 proxy's write cache currently stores the raw `aws-chunked` encoded body instead of the actual file content. This causes cached objects to have incorrect sizes and corrupted content. This design introduces an aws-chunked decoder that extracts the actual data from chunked uploads before caching, while preserving the raw body for S3 forwarding to maintain signature integrity.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         SignedPutHandler                                 │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌──────────────┐     ┌─────────────────────┐     ┌──────────────────┐  │
│  │   Request    │────▶│  Chunked Detector   │────▶│  Body Processor  │  │
│  │   Headers    │     │  (check headers)    │     │                  │  │
│  └──────────────┘     └─────────────────────┘     └────────┬─────────┘  │
│                                                             │            │
│                              ┌───────────────────────────────┤            │
│                              │                               │            │
│                              ▼                               ▼            │
│                    ┌─────────────────┐            ┌─────────────────┐    │
│                    │   Raw Body      │            │  Decoded Body   │    │
│                    │   (for S3)      │            │  (for cache)    │    │
│                    └────────┬────────┘            └────────┬────────┘    │
│                             │                              │             │
│                             ▼                              ▼             │
│                    ┌─────────────────┐            ┌─────────────────┐    │
│                    │  Forward to S3  │            │  Store in Cache │    │
│                    │  (unchanged)    │            │  (decoded data) │    │
│                    └─────────────────┘            └─────────────────┘    │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### New Module: `aws_chunked_decoder`

Location: `src/aws_chunked_decoder.rs`

```rust
/// AWS Chunked Encoding Decoder
/// 
/// Decodes aws-chunked encoded bodies used by AWS CLI for SigV4 streaming uploads.
/// The format is: `chunk-size;chunk-signature=sig\r\n data\r\n ... 0;chunk-signature=sig\r\n\r\n`

/// Check if a request uses aws-chunked encoding
pub fn is_aws_chunked(headers: &HashMap<String, String>) -> bool;

/// Get the decoded content length from headers
pub fn get_decoded_content_length(headers: &HashMap<String, String>) -> Option<u64>;

/// Decode aws-chunked body to extract actual data
pub fn decode_aws_chunked(body: &[u8]) -> Result<Vec<u8>, AwsChunkedError>;

/// Encode data as aws-chunked format (for testing round-trips)
pub fn encode_aws_chunked(data: &[u8], chunk_size: usize) -> Vec<u8>;

/// Error type for aws-chunked decoding
pub enum AwsChunkedError {
    InvalidChunkHeader(String),
    InvalidChunkSize(String),
    UnexpectedEof,
    LengthMismatch { expected: u64, actual: u64 },
}
```

### Modified Component: `SignedPutHandler`

Location: `src/signed_put_handler.rs`

Changes to `handle_with_caching` and `handle_with_streaming_capacity_check`:

1. After reading body bytes, check if aws-chunked encoding is used
2. If aws-chunked, decode the body for caching while keeping raw body for S3
3. Use decoded content length for capacity checking
4. Pass decoded body to `spawn_cache_write_task`

```rust
// In handle_with_caching:
let body_bytes = collected.to_bytes();

// Check for aws-chunked encoding
let (body_for_cache, decoded_length) = if aws_chunked_decoder::is_aws_chunked(&request_headers) {
    match aws_chunked_decoder::decode_aws_chunked(&body_bytes) {
        Ok(decoded) => {
            let len = decoded.len() as u64;
            // Validate against x-amz-decoded-content-length if present
            if let Some(expected) = aws_chunked_decoder::get_decoded_content_length(&request_headers) {
                if len != expected {
                    warn!("Decoded length mismatch: expected={}, actual={}", expected, len);
                    // Skip caching but continue with S3 upload
                    (None, None)
                } else {
                    (Some(Bytes::from(decoded)), Some(len))
                }
            } else {
                (Some(Bytes::from(decoded)), Some(len))
            }
        }
        Err(e) => {
            warn!("Failed to decode aws-chunked body: {}", e);
            // Skip caching but continue with S3 upload
            (None, None)
        }
    }
} else {
    // Non-chunked: use body as-is
    (Some(body_bytes.clone()), content_length)
};

// Forward raw body_bytes to S3 (unchanged)
// Pass body_for_cache to spawn_cache_write_task
```

## Data Models

### AWS Chunked Format

```
chunk-size;chunk-signature=signature\r\n
chunk-data\r\n
chunk-size;chunk-signature=signature\r\n
chunk-data\r\n
...
0;chunk-signature=signature\r\n
\r\n
```

Where:
- `chunk-size` is hexadecimal
- `chunk-signature` is the SigV4 signature for the chunk
- `chunk-data` is the raw data bytes
- Final chunk has size 0

Example for 710 bytes with 64KB chunks:
```
2c6;chunk-signature=abc123...\r\n
[710 bytes of data]\r\n
0;chunk-signature=def456...\r\n
\r\n
```

Total overhead: ~51 bytes (matches observed 761 - 710 = 51)

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Round-trip consistency
*For any* byte sequence, encoding it as aws-chunked and then decoding should produce the original byte sequence.
**Validates: Requirements 1.4, 6.1, 6.2**

### Property 2: Detection consistency
*For any* request headers, aws-chunked encoding is detected if and only if the headers contain `content-encoding: aws-chunked` OR `x-amz-content-sha256: STREAMING-AWS4-HMAC-SHA256-PAYLOAD`.
**Validates: Requirements 1.1, 1.2**

### Property 3: Capacity uses decoded length
*For any* aws-chunked PUT request with `x-amz-decoded-content-length` header, capacity checking uses the decoded length value, not the raw body length.
**Validates: Requirements 1.3**

### Property 4: Raw body preservation for S3
*For any* PUT request, the bytes forwarded to S3 are identical to the original request body bytes.
**Validates: Requirements 2.1, 2.2**

### Property 5: Decoded body caching
*For any* successful aws-chunked PUT request, the cached body equals the decoded content (not the raw chunked body).
**Validates: Requirements 2.3**

### Property 6: Non-chunked passthrough
*For any* PUT request without aws-chunked encoding indicators, the cached body equals the original request body.
**Validates: Requirements 3.1, 3.3**

### Property 7: Error isolation
*For any* PUT request where aws-chunked decoding fails, the request is still forwarded to S3 successfully.
**Validates: Requirements 4.2**

### Property 8: End-to-end content integrity
*For any* file uploaded via aws-chunked encoding, a subsequent GET request returns content identical to the original file.
**Validates: Requirements 5.1, 5.2, 5.3**

## Error Handling

| Error Condition | Handling | Requirement |
|-----------------|----------|-------------|
| Invalid chunk header format | Log warning, skip caching, forward to S3 | 4.1, 4.2 |
| Invalid chunk size (non-hex) | Log warning, skip caching, forward to S3 | 4.1, 4.2 |
| Unexpected EOF in chunk data | Log warning, skip caching, forward to S3 | 4.1, 4.2 |
| Decoded length mismatch | Log warning, skip caching, forward to S3 | 1.5, 4.3 |
| Missing terminator | Log warning, skip caching, forward to S3 | 4.1, 4.2 |

All errors result in:
1. Warning log with details
2. Cache bypass metric increment
3. Successful S3 forwarding (raw body unchanged)

## Testing Strategy

### Dual Testing Approach

Both unit tests and property-based tests are required:
- Unit tests verify specific examples and edge cases
- Property tests verify universal properties across all inputs

### Property-Based Testing

Use `quickcheck` library (already in project dependencies) for property-based tests.

Each property test must:
- Run minimum 100 iterations
- Be tagged with format: `**Feature: aws-chunked-decoding, Property {number}: {property_text}**`
- Reference the correctness property from this design document

### Test Cases

1. **Round-trip property test**: Generate random byte sequences, encode, decode, verify equality
2. **Detection property test**: Generate random header combinations, verify detection logic
3. **Decoding correctness**: Generate valid aws-chunked bodies, verify decoded output
4. **Error handling**: Generate malformed inputs, verify graceful handling
5. **Integration test**: Upload file via aws-chunked, retrieve via GET, verify content match

### Unit Tests

- Empty body encoding/decoding
- Single chunk encoding/decoding
- Multiple chunk encoding/decoding
- Maximum chunk size handling
- Various signature formats
