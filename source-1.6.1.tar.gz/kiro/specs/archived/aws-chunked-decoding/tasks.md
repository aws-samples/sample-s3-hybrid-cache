# Implementation Plan

- [-] 1. Create aws_chunked_decoder module
  - [x] 1.1 Create `src/aws_chunked_decoder.rs` with module structure
    - Define `AwsChunkedError` enum with variants: `InvalidChunkHeader`, `InvalidChunkSize`, `UnexpectedEof`, `LengthMismatch`
    - Implement `Display` and `Error` traits for `AwsChunkedError`
    - Add module to `src/lib.rs`
    - _Requirements: 4.1, 4.3_

  - [x] 1.2 Implement `is_aws_chunked()` detection function
    - Check for `content-encoding` header containing `aws-chunked`
    - Check for `x-amz-content-sha256` header equal to `STREAMING-AWS4-HMAC-SHA256-PAYLOAD`
    - Return true if either condition is met
    - _Requirements: 1.1, 1.2_

  - [ ]* 1.3 Write property test for detection consistency
    - **Property 2: Detection consistency**
    - **Validates: Requirements 1.1, 1.2**

  - [x] 1.4 Implement `get_decoded_content_length()` function
    - Extract `x-amz-decoded-content-length` header value
    - Parse as u64, return None if missing or invalid
    - _Requirements: 1.3_

  - [x] 1.5 Implement `decode_aws_chunked()` function
    - Parse chunk header format: `chunk-size;chunk-signature=sig\r\n`
    - Extract hex chunk size, skip signature
    - Read chunk data bytes
    - Skip trailing `\r\n` after each chunk
    - Handle final `0;chunk-signature=sig\r\n\r\n` terminator
    - Return concatenated data bytes
    - _Requirements: 1.4_

  - [ ]* 1.6 Write property test for decoded body caching
    - **Property 5: Decoded body caching**
    - **Validates: Requirements 2.3**

  - [x] 1.7 Implement `encode_aws_chunked()` function for testing
    - Split data into chunks of specified size
    - Format each chunk with placeholder signature
    - Add final zero-length chunk with terminator
    - _Requirements: 6.1_

  - [ ]* 1.8 Write property test for round-trip consistency
    - **Property 1: Round-trip consistency**
    - **Validates: Requirements 1.4, 6.1, 6.2**

- [x] 2. Checkpoint - Ensure decoder tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Integrate decoder into SignedPutHandler
  - [x] 3.1 Modify `handle_with_caching()` to detect and decode aws-chunked
    - After reading body bytes, call `is_aws_chunked()` on request headers
    - If aws-chunked, call `decode_aws_chunked()` to get decoded body
    - Validate decoded length against `x-amz-decoded-content-length` if present
    - Keep raw body for S3 forwarding, use decoded body for caching
    - On decode error, log warning and skip caching (still forward to S3)
    - _Requirements: 1.1, 1.2, 1.4, 1.5, 2.1, 2.3, 4.1, 4.2_

  - [ ]* 3.2 Write property test for raw body preservation
    - **Property 4: Raw body preservation for S3**
    - **Validates: Requirements 2.1, 2.2**

  - [x] 3.3 Modify `handle_with_streaming_capacity_check()` for aws-chunked
    - Use decoded content length for capacity checking
    - Apply same decode logic as `handle_with_caching()`
    - _Requirements: 1.3, 2.3_

  - [ ]* 3.4 Write property test for capacity uses decoded length
    - **Property 3: Capacity uses decoded length**
    - **Validates: Requirements 1.3**

  - [x] 3.5 Update `spawn_cache_write_task()` signature
    - Accept optional decoded body separate from raw body
    - Use decoded body for cache storage when provided
    - _Requirements: 2.3_

  - [ ]* 3.6 Write property test for non-chunked passthrough
    - **Property 6: Non-chunked passthrough**
    - **Validates: Requirements 3.1, 3.3**

  - [ ]* 3.7 Write property test for error isolation
    - **Property 7: Error isolation**
    - **Validates: Requirements 4.2**

- [x] 4. Checkpoint - Ensure integration tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Add metrics and logging
  - [x] 5.1 Add cache bypass metric for decode failures
    - Increment `put_cache_bypass` counter when decoding fails
    - Add reason tag: `aws_chunked_decode_error`
    - _Requirements: 4.4_

  - [x] 5.2 Add debug logging for aws-chunked detection and decoding
    - Log when aws-chunked encoding is detected
    - Log decoded vs raw body sizes
    - Log decode errors with details
    - _Requirements: 1.1, 4.1_

- [x] 6. Create integration test
  - [ ]* 6.1 Write property test for end-to-end content integrity
    - **Property 8: End-to-end content integrity**
    - **Validates: Requirements 5.1, 5.2, 5.3**

- [x] 7. Final Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
  - update documentation
  - tidy up repository

