# Requirements Document

## Introduction

The S3 proxy's write cache incorrectly stores the raw `aws-chunked` encoded body instead of the actual file content when caching PUT requests. AWS CLI uses `aws-chunked` encoding with chunk signatures for SigV4 uploads, which adds metadata overhead to the body. This causes cached objects to have incorrect sizes (e.g., 761 bytes cached vs 710 bytes actual) and corrupted content that cannot be served correctly on subsequent GET requests.

The proxy must decode the `aws-chunked` encoding before caching while still forwarding the raw encoded body to S3 to preserve signature integrity.

## Glossary

- **aws-chunked encoding**: AWS-specific chunked transfer encoding that includes chunk signatures for SigV4 authentication. Format: `chunk-size;chunk-signature=signature\r\n data\r\n ... 0;chunk-signature=signature\r\n\r\n`
- **x-amz-decoded-content-length**: HTTP header sent by AWS CLI indicating the actual content length before aws-chunked encoding
- **x-amz-content-sha256**: HTTP header containing either the content hash or `STREAMING-AWS4-HMAC-SHA256-PAYLOAD` for chunked uploads
- **SignedPutHandler**: The proxy component that handles caching of AWS SigV4 signed PUT requests
- **Write Cache**: Cache storage for PUT request bodies to enable subsequent GET requests to be served from cache

## Requirements

### Requirement 1

**User Story:** As a proxy operator, I want PUT requests using aws-chunked encoding to be cached correctly, so that subsequent GET requests return the correct file content and size.

#### Acceptance Criteria

1. WHEN a PUT request contains `content-encoding: aws-chunked` header THEN the SignedPutHandler SHALL decode the chunked body before caching
2. WHEN a PUT request contains `x-amz-content-sha256: STREAMING-AWS4-HMAC-SHA256-PAYLOAD` header THEN the SignedPutHandler SHALL detect aws-chunked encoding
3. WHEN a PUT request contains `x-amz-decoded-content-length` header THEN the SignedPutHandler SHALL use this value for capacity checking
4. WHEN decoding aws-chunked body THEN the SignedPutHandler SHALL extract only the data portions, excluding chunk headers and signatures
5. WHEN the decoded content length does not match `x-amz-decoded-content-length` THEN the SignedPutHandler SHALL log a warning and skip caching

### Requirement 2

**User Story:** As a proxy operator, I want the raw aws-chunked body to be forwarded to S3 unchanged, so that AWS SigV4 signatures remain valid.

#### Acceptance Criteria

1. WHEN forwarding a PUT request to S3 THEN the SignedPutHandler SHALL send the original raw body bytes unchanged
2. WHEN the PUT request uses aws-chunked encoding THEN the SignedPutHandler SHALL preserve all chunk headers and signatures in the forwarded request
3. WHEN S3 returns success THEN the SignedPutHandler SHALL cache the decoded body, not the raw chunked body

### Requirement 3

**User Story:** As a proxy operator, I want non-chunked PUT requests to continue working unchanged, so that existing functionality is preserved.

#### Acceptance Criteria

1. WHEN a PUT request does not contain aws-chunked encoding indicators THEN the SignedPutHandler SHALL cache the body as-is
2. WHEN a PUT request uses standard chunked transfer encoding (not aws-chunked) THEN the SignedPutHandler SHALL cache the body as-is
3. WHEN a PUT request has a fixed Content-Length without chunked encoding THEN the SignedPutHandler SHALL cache the body as-is

### Requirement 4

**User Story:** As a proxy operator, I want aws-chunked decoding errors to be handled gracefully, so that uploads still succeed even if caching fails.

#### Acceptance Criteria

1. IF aws-chunked decoding fails THEN the SignedPutHandler SHALL log the error and skip caching
2. IF aws-chunked decoding fails THEN the SignedPutHandler SHALL still forward the request to S3 successfully
3. IF aws-chunked decoding produces invalid data THEN the SignedPutHandler SHALL skip caching and log a warning
4. WHEN decoding fails THEN the SignedPutHandler SHALL record a cache bypass metric

### Requirement 5

**User Story:** As a proxy operator, I want to verify that cached content matches the original file, so that I can trust the cache integrity.

#### Acceptance Criteria

1. WHEN a file is uploaded via aws-chunked encoding and then retrieved THEN the GET response SHALL return the exact original file content
2. WHEN a file is uploaded via aws-chunked encoding THEN the cached Content-Length SHALL match the original file size
3. WHEN a file is uploaded via aws-chunked encoding THEN the cached ETag SHALL match the S3 response ETag

### Requirement 6

**User Story:** As a developer, I want a pretty printer for aws-chunked encoding, so that I can test the decoder with round-trip verification.

#### Acceptance Criteria

1. WHEN encoding data as aws-chunked format THEN the encoder SHALL produce valid aws-chunked output with placeholder signatures
2. WHEN decoding then encoding data THEN the round-trip SHALL preserve the original data content
3. WHEN encoding data THEN the encoder SHALL use the same chunk size boundaries as the original encoding where possible
