# Design Document: Signed Range Request Handling

## Overview

This design addresses the problem where AWS CLI signs GET requests with AWS Signature Version 4 (SigV4) and includes the Range header in the SignedHeaders list. When the proxy attempts to modify the Range header to fetch only missing cache portions, it invalidates the signature, causing S3 to return 403 Forbidden errors.

The solution implements a detection mechanism that identifies signed range requests only when cache gaps exist, then forwards the entire original range to S3 while selectively caching only the missing portions during streaming. This preserves signature validity while optimizing cache storage and enabling subsequent requests to be served entirely from cache.

## Architecture

### High-Level Flow

```
Client Request (Signed Range)
    ↓
Check Cache Coverage
    ↓
┌─────────────────────────────┐
│ Fully Cached?               │
│ Yes → Serve from cache      │──→ Response to Client
│ No  → Continue              │
└─────────────────────────────┘
    ↓
Parse Authorization Header
    ↓
┌─────────────────────────────┐
│ Range in SignedHeaders?     │
│ No  → Standard logic        │──→ Fetch missing ranges only
│ Yes → Signed range handling │
└─────────────────────────────┘
    ↓
Forward Entire Range to S3
    ↓
Stream Response to Client
    ↓
Selectively Cache Missing Portions
    ↓
Update Metadata
```

### Key Design Decisions

1. **Lazy Signature Detection**: Only parse the Authorization header when cache gaps exist, avoiding overhead for cache hits
2. **Preserve Original Request**: Forward the entire signed request unchanged to maintain signature validity
3. **Selective Caching**: Cache only missing byte ranges during streaming to avoid redundant storage
4. **Metadata-Driven**: Use existing range metadata to determine what needs caching
5. **Non-Blocking**: Cache writes happen asynchronously and don't block client response streaming

## Components and Interfaces

### 1. Signature Detection Module

**Location**: `src/signed_request_proxy.rs` (extend existing module)

**New Function**:
```rust
/// Check if the Range header is included in AWS SigV4 SignedHeaders
///
/// This function parses the Authorization header to determine if the Range
/// header was included in the signature calculation. If so, modifying the
/// Range header would invalidate the signature.
///
/// # Arguments
/// * `headers` - Request headers including Authorization
///
/// # Returns
/// * `true` if Range is in SignedHeaders, `false` otherwise
///
/// # Example Authorization Header
/// ```
/// AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/s3/aws4_request, #gitleaks:allow
/// SignedHeaders=host;range;x-amz-content-sha256;x-amz-date,
/// Signature=...
/// ```
pub fn is_range_signed(headers: &HashMap<String, String>) -> bool {
    // Get Authorization header (case-insensitive)
    let auth = headers.get("authorization")
        .or_else(|| headers.get("Authorization"));
    
    if let Some(auth_value) = auth {
        // Check if this is AWS SigV4
        if !auth_value.contains("AWS4-HMAC-SHA256") {
            return false;
        }
        
        // Find SignedHeaders parameter
        if let Some(signed_headers_start) = auth_value.find("SignedHeaders=") {
            let after_param = &auth_value[signed_headers_start + 14..]; // Skip "SignedHeaders="
            
            // Extract until comma or end of string
            let signed_headers_end = after_param.find(',')
                .or_else(|| after_param.find(' '))
                .unwrap_or(after_param.len());
            
            let signed_headers = &after_param[..signed_headers_end];
            
            // Check if "range" is in the semicolon-separated list
            return signed_headers.split(';').any(|h| h == "range");
        }
    }
    
    false
}
```

### 2. Range Request Handler Modifications

**Location**: `src/http_proxy.rs`

**Modified Function**: `handle_range_request`

**Changes**:
```rust
// After finding cache overlap and determining missing ranges exist:
if !overlap.missing_ranges.is_empty() {
    // Check if this is a signed range request (Requirement 1.2, 1.3)
    let range_is_signed = crate::signed_request_proxy::is_range_signed(&client_headers);
    
    if range_is_signed {
        debug!(
            "Signed range request detected with cache gaps: cache_key={}, range={}, missing_ranges={}",
            cache_key, range_header, overlap.missing_ranges.len()
        );
        
        // Forward entire range to S3 with selective caching (Requirement 2.1, 2.2, 2.3)
        return Self::forward_signed_range_request(
            method,
            uri,
            host,
            client_headers,
            cache_key,
            range_spec,
            overlap,
            cache_manager,
            range_handler,
            s3_client,
            config,
        ).await;
    } else {
        // Standard logic: fetch only missing ranges (Requirement 1.4)
        // ... existing fetch_missing_ranges logic ...
    }
}
```

### 3. Signed Range Request Forwarder

**Location**: `src/http_proxy.rs`

**New Function**:
```rust
/// Forward a signed range request to S3 with selective caching
///
/// This function handles range requests where the Range header is included
/// in the AWS SigV4 signature. It forwards the entire original range to S3
/// (preserving the signature) while selectively caching only the missing
/// portions during streaming.
///
/// # Arguments
/// * `method` - HTTP method (GET)
/// * `uri` - Request URI
/// * `host` - S3 host
/// * `client_headers` - Original request headers (including Authorization)
/// * `cache_key` - Cache key for the object
/// * `range_spec` - Parsed range specification
/// * `overlap` - Cache overlap analysis (cached and missing ranges)
/// * `cache_manager` - Cache manager instance
/// * `range_handler` - Range handler instance
/// * `s3_client` - S3 client instance
/// * `config` - Proxy configuration
///
/// # Returns
/// HTTP response with streamed body
async fn forward_signed_range_request(
    method: Method,
    uri: hyper::Uri,
    host: String,
    client_headers: HashMap<String, String>,
    cache_key: String,
    range_spec: RangeSpec,
    overlap: CacheOverlap,
    cache_manager: Arc<CacheManager>,
    range_handler: Arc<RangeHandler>,
    s3_client: Arc<S3Client>,
    config: Arc<Config>,
) -> std::result::Result<Response<BoxBody<Bytes, hyper::Error>>, Infallible> {
    // Build S3 request context with original headers (Requirement 2.2)
    let context = build_s3_request_context(
        method,
        uri,
        client_headers,
        None,
        host,
    );
    
    // Forward request to S3
    match s3_client.forward_request(context).await {
        Ok(s3_response) => {
            if s3_response.status == StatusCode::PARTIAL_CONTENT {
                // Extract ETag and headers for caching
                let etag = s3_response.headers.get("etag")
                    .map(|v| v.to_string());
                
                // Create selective cache writer (Requirement 3.1, 3.2, 3.3)
                let selective_writer = SelectiveCacheWriter::new(
                    cache_key.clone(),
                    range_spec.clone(),
                    overlap.missing_ranges.clone(),
                    etag,
                    range_handler.get_disk_cache_manager(),
                    config.cache.get_ttl,
                );
                
                // Stream response to client while selectively caching (Requirement 2.4)
                // CRITICAL: This is true streaming - data flows from S3 -> Client immediately
                // The SelectiveTeeStream writes to cache asynchronously without blocking the stream
                // This prevents connection timeouts and provides good user experience
                let body_stream = s3_response.body.unwrap();
                let tee_stream = SelectiveTeeStream::new(
                    body_stream,
                    selective_writer,
                    range_spec.start, // Starting byte offset
                );
                
                // Build response with streaming body
                // The client receives data as soon as it arrives from S3
                let mut response = Response::new(
                    BoxBody::new(StreamBody::new(tee_stream))
                );
                *response.status_mut() = StatusCode::PARTIAL_CONTENT;
                
                // Copy headers from S3 response
                for (key, value) in s3_response.headers {
                    if let Ok(header_name) = key.parse::<hyper::header::HeaderName>() {
                        if let Ok(header_value) = value.parse::<hyper::header::HeaderValue>() {
                            response.headers_mut().insert(header_name, header_value);
                        }
                    }
                }
                
                Ok(response)
            } else {
                // Unexpected status, forward as-is
                Self::build_response_from_s3(s3_response)
            }
        }
        Err(e) => {
            error!("Failed to forward signed range request to S3: {}", e);
            Self::error_response(StatusCode::BAD_GATEWAY, "Failed to fetch from S3")
        }
    }
}
```

### 4. Selective Cache Writer

**Location**: `src/cache_writer.rs` (new struct)

**New Struct**:
```rust
/// Selective cache writer for signed range requests
///
/// This writer caches only specific byte ranges from a streaming response,
/// skipping ranges that are already cached. It tracks the current byte offset
/// in the stream and writes data only when the offset falls within a missing range.
pub struct SelectiveCacheWriter {
    cache_key: String,
    requested_range: RangeSpec,
    missing_ranges: Vec<RangeSpec>,
    current_offset: u64,
    etag: Option<String>,
    disk_cache: Arc<tokio::sync::Mutex<DiskCacheManager>>,
    ttl: Duration,
    active_writer: Option<(RangeSpec, File, PathBuf)>, // (range, file, temp_path)
}

impl SelectiveCacheWriter {
    /// Create a new selective cache writer
    pub fn new(
        cache_key: String,
        requested_range: RangeSpec,
        missing_ranges: Vec<RangeSpec>,
        etag: Option<String>,
        disk_cache: Arc<tokio::sync::Mutex<DiskCacheManager>>,
        ttl: Duration,
    ) -> Self {
        Self {
            cache_key,
            requested_range,
            missing_ranges,
            current_offset: requested_range.start,
            etag,
            disk_cache,
            ttl,
            active_writer: None,
        }
    }
    
    /// Write a chunk of data, caching only if offset is in a missing range
    ///
    /// # Arguments
    /// * `chunk` - Data chunk from S3 response
    ///
    /// # Returns
    /// Result indicating success or failure
    pub async fn write_chunk(&mut self, chunk: &[u8]) -> Result<()> {
        let chunk_start = self.current_offset;
        let chunk_end = chunk_start + chunk.len() as u64 - 1;
        
        // Find which missing ranges this chunk overlaps
        for missing_range in &self.missing_ranges {
            // Check if chunk overlaps with this missing range
            if chunk_start <= missing_range.end && chunk_end >= missing_range.start {
                // Calculate the portion of the chunk that falls in this range
                let overlap_start = chunk_start.max(missing_range.start);
                let overlap_end = chunk_end.min(missing_range.end);
                
                let chunk_offset = (overlap_start - chunk_start) as usize;
                let overlap_len = (overlap_end - overlap_start + 1) as usize;
                
                // Write this portion to cache
                self.write_to_cache(
                    missing_range,
                    &chunk[chunk_offset..chunk_offset + overlap_len],
                    overlap_start,
                ).await?;
            }
        }
        
        // Update current offset
        self.current_offset += chunk.len() as u64;
        
        Ok(())
    }
    
    /// Write data to cache for a specific range
    async fn write_to_cache(
        &mut self,
        range: &RangeSpec,
        data: &[u8],
        offset: u64,
    ) -> Result<()> {
        // Implementation details for writing to disk cache
        // This will use DiskCacheManager to write range files
        // Similar to existing cache_writer.rs logic but for ranges
        
        // ... implementation ...
        
        Ok(())
    }
    
    /// Finalize caching and update metadata
    pub async fn finalize(mut self) -> Result<()> {
        // Close any active writers
        if let Some((range, file, temp_path)) = self.active_writer.take() {
            drop(file);
            
            // Commit the range file
            let mut disk_cache = self.disk_cache.lock().await;
            disk_cache.commit_range_file(
                &self.cache_key,
                &range,
                &temp_path,
                self.etag.as_deref(),
                self.ttl,
            ).await?;
        }
        
        // Update metadata to reflect newly cached ranges (Requirement 4.1, 4.2)
        let mut disk_cache = self.disk_cache.lock().await;
        for missing_range in &self.missing_ranges {
            disk_cache.update_range_metadata(
                &self.cache_key,
                missing_range,
                self.etag.as_deref(),
            ).await?;
        }
        
        Ok(())
    }
}
```

### 5. Selective Tee Stream

**Location**: `src/tee_stream.rs` (extend existing)

**New Struct**:
```rust
/// Stream wrapper that selectively caches data while streaming to client
///
/// This is similar to TeeStream but uses SelectiveCacheWriter to cache
/// only specific byte ranges instead of all data.
pub struct SelectiveTeeStream {
    inner: Pin<Box<dyn Stream<Item = Result<Bytes, hyper::Error>> + Send>>,
    cache_writer: SelectiveCacheWriter,
    finalized: bool,
}

impl SelectiveTeeStream {
    pub fn new(
        stream: impl Stream<Item = Result<Bytes, hyper::Error>> + Send + 'static,
        cache_writer: SelectiveCacheWriter,
        start_offset: u64,
    ) -> Self {
        Self {
            inner: Box::pin(stream),
            cache_writer,
            finalized: false,
        }
    }
}

impl Stream for SelectiveTeeStream {
    type Item = Result<Bytes, hyper::Error>;
    
    fn poll_next(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
    ) -> Poll<Option<Self::Item>> {
        match self.inner.as_mut().poll_next(cx) {
            Poll::Ready(Some(Ok(chunk))) => {
                // CRITICAL: Return chunk to client immediately (Requirement 2.4)
                // Cache write happens asynchronously and does NOT block the client stream
                // This ensures:
                // 1. No connection timeouts (data flows continuously)
                // 2. Low latency (client gets data as soon as S3 sends it)
                // 3. Cache failures don't impact client experience
                
                let cache_writer = &mut self.cache_writer;
                let chunk_clone = chunk.clone();
                
                // Spawn async task for cache write (non-blocking)
                tokio::spawn(async move {
                    if let Err(e) = cache_writer.write_chunk(&chunk_clone).await {
                        warn!("Failed to write chunk to cache: {}", e);
                    }
                });
                
                // Return chunk immediately to client
                Poll::Ready(Some(Ok(chunk)))
            }
            Poll::Ready(Some(Err(e))) => {
                Poll::Ready(Some(Err(e)))
            }
            Poll::Ready(None) => {
                // Stream ended, finalize caching
                if !self.finalized {
                    self.finalized = true;
                    let cache_writer = std::mem::replace(
                        &mut self.cache_writer,
                        // Placeholder - actual implementation would handle this better
                        SelectiveCacheWriter::new(
                            String::new(),
                            RangeSpec { start: 0, end: 0 },
                            Vec::new(),
                            None,
                            Arc::new(tokio::sync::Mutex::new(/* ... */)),
                            Duration::from_secs(0),
                        ),
                    );
                    
                    tokio::spawn(async move {
                        if let Err(e) = cache_writer.finalize().await {
                            warn!("Failed to finalize selective cache: {}", e);
                        }
                    });
                }
                Poll::Ready(None)
            }
            Poll::Pending => Poll::Pending,
        }
    }
}
```

## Data Models

### CacheOverlap (Existing)

```rust
pub struct CacheOverlap {
    pub cached_ranges: Vec<CachedRange>,
    pub missing_ranges: Vec<RangeSpec>,
    pub can_serve_from_cache: bool,
}
```

### SelectiveCacheState (New)

```rust
/// State tracking for selective caching
struct SelectiveCacheState {
    /// Current byte offset in the stream
    current_offset: u64,
    /// Ranges that need to be cached
    missing_ranges: Vec<RangeSpec>,
    /// Currently active range being written
    active_range: Option<RangeSpec>,
    /// Temporary file for current range
    temp_file: Option<File>,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*


### Property Reflection

After analyzing all acceptance criteria, I identified several redundant properties that can be eliminated or combined:

**Redundancies Eliminated:**
- Requirements 6.2, 7.4, 7.5 are covered by the selective caching property (3.2/3.3)
- Requirements 6.3 is covered by the cache hit property (5.1)
- Requirements 6.5 is covered by the signature preservation property (2.2)
- Requirements 8.2, 8.3 are covered by the error handling property (3.5)
- Requirements 8.5 is covered by the metadata error property (4.3)

**Properties Combined:**
- Requirements 3.2 and 3.3 combined into one selective caching correctness property
- Requirements 4.1 and 4.2 combined into one metadata update property

This reduces the property set from 40+ potential properties to 20 unique, non-redundant properties that provide comprehensive validation coverage.

### Correctness Properties

Property 1: Signature detection only on cache miss
*For any* range request that can be fully served from cache, the signature detection function should not be called
**Validates: Requirements 1.1**

Property 2: Signature detection on cache gaps
*For any* range request with cache gaps, if an Authorization header is present, the signature detection function should be called
**Validates: Requirements 1.2**

Property 3: Signed range identification
*For any* Authorization header where SignedHeaders contains "range", the is_range_signed function should return true
**Validates: Requirements 1.3**

Property 4: Unsigned range handling
*For any* Authorization header where SignedHeaders does not contain "range", or when no Authorization header exists, the proxy should use standard range logic (fetch_missing_ranges)
**Validates: Requirements 1.4, 1.5**

Property 5: Original range preservation
*For any* signed range request with cache gaps, the Range header sent to S3 should be identical to the Range header received from the client
**Validates: Requirements 2.1**

Property 6: Header preservation
*For any* signed range request, all headers (especially Authorization) forwarded to S3 should be identical to those received from the client
**Validates: Requirements 2.2, 6.5**

Property 7: No separate range fetching
*For any* signed range request with cache gaps, the fetch_missing_ranges function should not be called
**Validates: Requirements 2.3**

Property 7.5: Immediate streaming to client
*For any* signed range request response from S3, the first byte should reach the client before the full response is received from S3 (streaming, not buffering)
**Validates: Requirements 2.4**

Property 8: Signature validity
*For any* signed range request where headers are preserved, S3 should return 200 or 206 status (not 403 Forbidden)
**Validates: Requirements 2.5**

Property 9: Selective caching correctness
*For any* byte in a signed range response stream, that byte should be written to cache if and only if its offset falls within a missing range
**Validates: Requirements 3.1, 3.2, 3.3, 6.2, 7.4, 7.5**

Property 10: Metadata update completeness
*For any* selective caching operation that completes successfully, the object metadata should include entries for all newly cached ranges while preserving all existing cached range entries
**Validates: Requirements 3.4, 4.1, 4.2**

Property 11: Error resilience
*For any* selective caching operation where cache writes fail, the client response stream should continue without interruption
**Validates: Requirements 3.5, 8.2, 8.3**

Property 12: Metadata error handling
*For any* metadata update operation that fails, the error should be logged and the client request should complete successfully
**Validates: Requirements 4.3, 8.5**

Property 13: Range merging
*For any* two cached ranges that are adjacent (range1.end + 1 == range2.start) or overlapping, the metadata should store them as a single merged range
**Validates: Requirements 4.5**

Property 14: Subsequent cache hits
*For any* signed range request that has been fully cached, subsequent identical requests should be served entirely from cache without forwarding to S3
**Validates: Requirements 5.1, 5.2, 6.3**

Property 15: Cache response correctness
*For any* range request served from cache, the response should have status 206 Partial Content and include correct Content-Range headers
**Validates: Requirements 5.3**

Property 16: Cache assembly
*For any* range request where metadata indicates full cache coverage, the proxy should be able to assemble the complete response from cached range files
**Validates: Requirements 5.4**

Property 17: Cache data integrity (Round-trip)
*For any* range data cached from S3, reading that data back from cache should produce bytes identical to the original S3 response
**Validates: Requirements 5.5**

Property 18: Missing range calculation
*For any* requested range and set of cached ranges, the calculated missing ranges should equal the set difference (requested - cached)
**Validates: Requirements 7.1, 7.2**

Property 19: Byte offset tracking
*For any* streaming response, the current byte offset should always equal the starting offset plus the number of bytes processed
**Validates: Requirements 7.3**

Property 20: Error forwarding
*For any* S3 error response (4xx or 5xx), the proxy should forward the error to the client without caching any data
**Validates: Requirements 8.4**

Property 21: Non-blocking cache writes
*For any* selective caching operation, cache write latency should not increase client response latency by more than 10%
**Validates: Requirements 9.4**

Property 22: Signature detection failure handling
*For any* request where signature detection fails (malformed Authorization header), the proxy should forward the request without modification
**Validates: Requirements 8.1**

## Error Handling

### Error Scenarios and Responses

1. **Malformed Authorization Header**
   - Detection: Parsing fails or format is invalid
   - Response: Default to standard range logic, log warning
   - Impact: No signature preservation, but request still succeeds

2. **Signature Detection Failure**
   - Detection: Exception during is_range_signed()
   - Response: Default to standard range logic, log error
   - Impact: May attempt to modify signed request, could cause 403

3. **Selective Cache Write Failure**
   - Detection: I/O error during cache write
   - Response: Log error, continue streaming to client
   - Impact: Cache miss on subsequent requests, no client impact

4. **Metadata Update Failure**
   - Detection: File system error during metadata write
   - Response: Log error, complete client request
   - Impact: Cached data exists but not discoverable, will be re-cached

5. **S3 Error Response**
   - Detection: 4xx or 5xx status from S3
   - Response: Forward error to client, no caching
   - Impact: Client sees S3 error, no cache pollution

6. **Stream Interruption**
   - Detection: Connection closed during streaming
   - Response: Clean up partial cache writes, return error to client
   - Impact: Partial data may be cached, will be cleaned up on next request

### Error Recovery Strategies

1. **Graceful Degradation**: Cache failures never block client responses
2. **Fail-Safe Defaults**: Unknown states default to standard (non-signed) logic
3. **Cleanup on Failure**: Partial writes are cleaned up to prevent corruption
4. **Retry Avoidance**: No automatic retries to prevent cascading failures
5. **Comprehensive Logging**: All errors logged with context for debugging

## Testing Strategy

### Unit Testing

**Signature Detection Tests**:
- Test is_range_signed() with various Authorization header formats
- Test with range in SignedHeaders (should return true)
- Test with range not in SignedHeaders (should return false)
- Test with malformed Authorization headers (should return false)
- Test with missing Authorization header (should return false)
- Test case-insensitive header names

**Missing Range Calculation Tests**:
- Test calculating missing ranges with no cache
- Test calculating missing ranges with partial cache
- Test calculating missing ranges with full cache
- Test with overlapping cached ranges
- Test with adjacent cached ranges
- Test with gaps in cached ranges

**Selective Cache Writer Tests**:
- Test writing chunks that fall entirely in missing ranges
- Test writing chunks that fall entirely in cached ranges
- Test writing chunks that span missing and cached ranges
- Test byte offset tracking across multiple chunks
- Test finalization and metadata updates

### Property-Based Testing

The property-based tests will use the `quickcheck` framework to generate random inputs and verify the correctness properties defined above.

**Test Configuration**:
- Minimum 100 iterations per property test
- Random seed logging for reproducibility
- Shrinking enabled for minimal failing examples

**Property Test 1: Signature Detection Optimization**
```rust
#[quickcheck]
fn prop_signature_detection_only_on_cache_miss(
    range: RangeSpec,
    cached_ranges: Vec<RangeSpec>,
) -> bool {
    // Feature: signed-range-requests, Property 1: Signature detection only on cache miss
    // If range is fully covered by cached_ranges, signature detection should not be called
    // Implementation: Track whether is_range_signed was called
}
```
**Validates: Requirements 1.1**

**Property Test 2: Signed Range Identification**
```rust
#[quickcheck]
fn prop_signed_range_identification(auth_header: String, has_range: bool) -> bool {
    // Feature: signed-range-requests, Property 3: Signed range identification
    // For any Authorization header where SignedHeaders contains "range",
    // is_range_signed should return true
}
```
**Validates: Requirements 1.3**

**Property Test 3: Header Preservation**
```rust
#[quickcheck]
fn prop_header_preservation(
    headers: HashMap<String, String>,
    range: RangeSpec,
) -> bool {
    // Feature: signed-range-requests, Property 6: Header preservation
    // For any signed range request, headers forwarded to S3 should be identical
    // to headers received from client
}
```
**Validates: Requirements 2.2**

**Property Test 3.5: Immediate Streaming**
```rust
#[quickcheck]
fn prop_immediate_streaming(response_size: usize) -> bool {
    // Feature: signed-range-requests, Property 7.5: Immediate streaming to client
    // For any S3 response, the first byte should reach the client before
    // the full response is received from S3 (true streaming, not buffering)
    // Test by measuring time to first byte vs time to last byte
}
```
**Validates: Requirements 2.4**

**Property Test 4: Selective Caching Correctness**
```rust
#[quickcheck]
fn prop_selective_caching_correctness(
    stream_data: Vec<u8>,
    missing_ranges: Vec<RangeSpec>,
    cached_ranges: Vec<RangeSpec>,
    start_offset: u64,
) -> bool {
    // Feature: signed-range-requests, Property 9: Selective caching correctness
    // For any byte in the stream, it should be cached iff its offset falls in a missing range
}
```
**Validates: Requirements 3.1, 3.2, 3.3**

**Property Test 5: Metadata Update Completeness**
```rust
#[quickcheck]
fn prop_metadata_update_completeness(
    existing_ranges: Vec<RangeSpec>,
    new_ranges: Vec<RangeSpec>,
) -> bool {
    // Feature: signed-range-requests, Property 10: Metadata update completeness
    // After caching new ranges, metadata should include both existing and new ranges
}
```
**Validates: Requirements 3.4, 4.1, 4.2**

**Property Test 6: Range Merging**
```rust
#[quickcheck]
fn prop_range_merging(ranges: Vec<RangeSpec>) -> bool {
    // Feature: signed-range-requests, Property 13: Range merging
    // Adjacent or overlapping ranges should be merged in metadata
}
```
**Validates: Requirements 4.5**

**Property Test 7: Cache Data Integrity (Round-trip)**
```rust
#[quickcheck]
fn prop_cache_data_integrity(
    data: Vec<u8>,
    range: RangeSpec,
) -> bool {
    // Feature: signed-range-requests, Property 17: Cache data integrity
    // Data cached from S3 should be byte-identical when read back
}
```
**Validates: Requirements 5.5**

**Property Test 8: Missing Range Calculation**
```rust
#[quickcheck]
fn prop_missing_range_calculation(
    requested: RangeSpec,
    cached: Vec<RangeSpec>,
) -> bool {
    // Feature: signed-range-requests, Property 18: Missing range calculation
    // Calculated missing ranges should equal set difference (requested - cached)
}
```
**Validates: Requirements 7.1, 7.2**

**Property Test 9: Byte Offset Tracking**
```rust
#[quickcheck]
fn prop_byte_offset_tracking(
    chunks: Vec<Vec<u8>>,
    start_offset: u64,
) -> bool {
    // Feature: signed-range-requests, Property 19: Byte offset tracking
    // Current offset should always equal start offset plus bytes processed
}
```
**Validates: Requirements 7.3**

### Integration Testing

**End-to-End Signed Range Request Test**:
1. Create a test object in S3
2. Make a signed range request with AWS CLI
3. Verify response is correct (206 status, correct data)
4. Verify missing ranges are cached
5. Make identical signed range request
6. Verify response is served from cache (no S3 request)
7. Verify cached data matches original S3 data

**Partial Cache Hit Test**:
1. Cache some ranges for an object
2. Make a signed range request that partially overlaps cached ranges
3. Verify entire range is forwarded to S3
4. Verify only missing portions are cached
5. Verify subsequent request is fully served from cache

**Error Handling Test**:
1. Make a signed range request with cache write failures
2. Verify client receives correct response despite cache failures
3. Verify errors are logged appropriately

### Performance Testing

**Throughput Test**:
- Measure response time for signed range requests with selective caching
- Compare to response time without caching
- Verify overhead is less than 10%

**Cache Efficiency Test**:
- Measure cache hit rate after selective caching
- Verify subsequent requests are served from cache
- Measure reduction in S3 requests

## Implementation Notes

### Phase 1: Signature Detection
1. Implement is_range_signed() in signed_request_proxy.rs
2. Add unit tests for signature detection
3. Integrate detection into handle_range_request()

### Phase 2: Request Forwarding
1. Implement forward_signed_range_request() in http_proxy.rs
2. Ensure all headers are preserved
3. Add integration tests for forwarding

### Phase 3: Selective Caching
1. Implement SelectiveCacheWriter in cache_writer.rs
2. Implement SelectiveTeeStream in tee_stream.rs
3. Add unit tests for selective caching logic

### Phase 4: Metadata Updates
1. Implement metadata update logic in DiskCacheManager
2. Implement range merging logic
3. Add tests for metadata operations

### Phase 5: Integration and Testing
1. End-to-end integration tests
2. Property-based tests
3. Performance testing
4. Documentation updates

### Dependencies

- Existing: `signed_request_proxy.rs` (extend)
- Existing: `http_proxy.rs` (modify)
- Existing: `range_handler.rs` (use)
- Existing: `disk_cache.rs` (extend)
- New: Selective caching components in `cache_writer.rs` and `tee_stream.rs`

### Backward Compatibility

This feature is fully backward compatible:
- Non-signed requests continue to use existing logic
- Unsigned range requests continue to use fetch_missing_ranges
- No changes to cache file formats
- No changes to configuration

### Performance Considerations

1. **Signature Detection Overhead**: Minimal - only parses Authorization header when cache gaps exist
2. **Selective Caching Overhead**: Small - requires tracking byte offsets and checking ranges
3. **Memory Usage**: Similar to existing TeeStream - no additional buffering
4. **Disk I/O**: Reduced - only writes missing ranges instead of full ranges
5. **Streaming Performance**: True streaming with no buffering - data flows S3 → Client immediately
   - Cache writes are asynchronous and non-blocking
   - Prevents connection timeouts on large files
   - Client receives first byte as soon as S3 sends it
   - Cache write failures don't impact client response time

### Security Considerations

1. **Signature Preservation**: Critical - any modification invalidates signature
2. **Header Handling**: Must preserve all headers exactly, including case
3. **Error Information**: Avoid leaking sensitive information in error logs
4. **Cache Poisoning**: Selective caching doesn't introduce new attack vectors

## Monitoring and Observability

### Metrics

1. **signed_range_requests_total**: Counter of signed range requests detected
2. **signed_range_cache_hits_total**: Counter of signed range requests served from cache
3. **signed_range_cache_misses_total**: Counter of signed range requests forwarded to S3
4. **selective_cache_bytes_written**: Histogram of bytes written during selective caching
5. **selective_cache_write_errors_total**: Counter of cache write failures

### Logging

1. **Detection**: Log when signed range request is detected
2. **Forwarding**: Log when forwarding entire range to S3
3. **Caching**: Log byte ranges being selectively cached
4. **Cache Hits**: Log when subsequent request is served from cache
5. **Errors**: Log all errors with context (cache key, range, error details)

### Debugging

1. **Trace Logging**: Enable detailed logging of byte offset tracking
2. **Cache Inspection**: Tools to inspect cached ranges and metadata
3. **Request Replay**: Ability to replay signed requests for debugging
4. **Metrics Dashboard**: Grafana dashboard for monitoring signed range request handling
