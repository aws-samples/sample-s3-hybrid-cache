# Implementation Plan: Signed Range Request Handling

## Overview

This implementation plan breaks down the signed range request handling feature into discrete, incremental tasks. Each task builds on previous work and includes specific code changes, testing requirements, and validation steps.

## Task List

- [x] 1. Implement signature detection function
  - Add `is_range_signed()` function to `src/signed_request_proxy.rs`
  - Parse Authorization header to extract SignedHeaders parameter
  - Check if "range" is in the semicolon-separated SignedHeaders list
  - Handle case-insensitive header names ("authorization" and "Authorization")
  - Return false for malformed headers or non-SigV4 signatures
  - _Requirements: 1.2, 1.3, 1.4, 1.5_

- [x] 1.1 Write property test for signature detection
  - **Property 3: Signed range identification**
  - **Validates: Requirements 1.3**
  - Generate random Authorization headers with and without "range" in SignedHeaders
  - Verify is_range_signed() returns correct boolean for each case
  - Test malformed headers return false
  - Test missing headers return false
  - _Requirements: 1.3, 1.4, 1.5_

- [x] 1.2 Write unit tests for signature detection edge cases
  - Test with uppercase "Authorization" header
  - Test with lowercase "authorization" header
  - Test with SignedHeaders at end of string (no comma after)
  - Test with SignedHeaders in middle of string (comma after)
  - Test with "range" as first, middle, and last item in SignedHeaders
  - Test with headers containing "range" as substring (e.g., "x-range") - should not match
  - _Requirements: 1.3_

- [x] 2. Integrate signature detection into range request handling
  - Modify `handle_range_request()` in `src/http_proxy.rs`
  - After finding cache overlap, check if missing_ranges is non-empty
  - If missing ranges exist, call `is_range_signed(&client_headers)`
  - If signed, call new `forward_signed_range_request()` function
  - If not signed, use existing `fetch_missing_ranges()` logic
  - Add debug logging for signed range detection
  - _Requirements: 1.1, 1.2, 1.3, 1.4_

- [x] 2.1 Write property test for signature detection optimization
  - **Property 1: Signature detection only on cache miss**
  - **Validates: Requirements 1.1**
  - Generate random range requests with full cache coverage
  - Verify is_range_signed() is never called for cache hits
  - Track function calls using mock or spy pattern
  - _Requirements: 1.1_

- [x] 2.2 Write property test for standard logic fallback
  - **Property 4: Unsigned range handling**
  - **Validates: Requirements 1.4, 1.5**
  - Generate range requests without Authorization header
  - Generate range requests with Authorization but no "range" in SignedHeaders
  - Verify fetch_missing_ranges() is called (standard logic)
  - Verify forward_signed_range_request() is NOT called
  - _Requirements: 1.4, 1.5_

- [x] 3. Implement signed range request forwarder
  - Add `forward_signed_range_request()` function to `src/http_proxy.rs`
  - Build S3 request context with original headers (preserve all headers)
  - Forward request to S3 using s3_client.forward_request()
  - Handle 206 Partial Content response
  - Extract ETag and headers from S3 response
  - Return error response for unexpected status codes
  - Add logging for forwarding decision
  - _Requirements: 2.1, 2.2, 2.3, 2.5_

- [x] 3.1 Write property test for header preservation
  - **Property 6: Header preservation**
  - **Validates: Requirements 2.2**
  - Generate random request headers including Authorization
  - Forward signed range request
  - Verify all headers sent to S3 match original headers exactly
  - Verify Authorization header is unchanged
  - _Requirements: 2.2_

- [x] 3.2 Write property test for no separate range fetching
  - **Property 7: No separate range fetching**
  - **Validates: Requirements 2.3**
  - Generate signed range requests with cache gaps
  - Verify fetch_missing_ranges() is never called
  - Verify forward_signed_range_request() is called instead
  - _Requirements: 2.3_

- [x] 4. Implement selective cache writer
  - Create `SelectiveCacheWriter` struct in `src/cache_writer.rs`
  - Add fields: cache_key, requested_range, missing_ranges, current_offset, etag, disk_cache, ttl
  - Implement `new()` constructor
  - Implement `write_chunk()` method to selectively cache data
  - Calculate which missing ranges each chunk overlaps
  - Write only overlapping portions to cache
  - Track current byte offset as chunks are processed
  - _Requirements: 3.1, 3.2, 3.3, 7.3_

- [x] 4.1 Implement cache file writing in SelectiveCacheWriter
  - Add `write_to_cache()` private method
  - Create temporary file for each missing range
  - Write data chunks to appropriate range files
  - Track active writer (range, file handle, temp path)
  - Handle switching between ranges as stream progresses
  - _Requirements: 3.3_

- [x] 4.2 Implement finalization in SelectiveCacheWriter
  - Add `finalize()` method
  - Close all active file handles
  - Commit temporary files to final locations
  - Update metadata for newly cached ranges
  - Call disk_cache.commit_range_file() for each range
  - Call disk_cache.update_range_metadata() to record ranges
  - _Requirements: 3.4, 4.1, 4.2_

- [x] 4.3 Write property test for selective caching correctness
  - **Property 9: Selective caching correctness**
  - **Validates: Requirements 3.1, 3.2, 3.3**
  - Generate random stream data with known byte offsets
  - Generate random missing and cached ranges
  - Process stream through SelectiveCacheWriter
  - Verify only bytes in missing ranges are written to cache
  - Verify bytes in cached ranges are skipped
  - _Requirements: 3.1, 3.2, 3.3_

- [x] 4.4 Write property test for byte offset tracking
  - **Property 19: Byte offset tracking**
  - **Validates: Requirements 7.3**
  - Generate random chunks of varying sizes
  - Process through SelectiveCacheWriter
  - Verify current_offset equals start_offset + total_bytes_processed
  - Verify offset is correct after each chunk
  - _Requirements: 7.3_

- [x] 4.5 Write property test for metadata update completeness
  - **Property 10: Metadata update completeness**
  - **Validates: Requirements 3.4, 4.1, 4.2**
  - Generate existing cached ranges
  - Cache new ranges via SelectiveCacheWriter
  - Verify metadata includes both existing and new ranges
  - Verify no existing ranges are lost
  - _Requirements: 3.4, 4.1, 4.2_

- [x] 5. Implement selective tee stream
  - Create `SelectiveTeeStream` struct in `src/tee_stream.rs`
  - Add fields: inner stream, cache_writer, finalized flag
  - Implement `new()` constructor
  - Implement `Stream` trait with `poll_next()` method
  - Return chunks to client immediately (non-blocking)
  - Spawn async task for cache writes (don't block stream)
  - Handle stream completion and finalize caching
  - _Requirements: 2.4, 3.2, 3.3, 3.5_

- [x] 5.1 Write property test for immediate streaming
  - **Property 7.5: Immediate streaming to client**
  - **Validates: Requirements 2.4**
  - Generate mock S3 response stream
  - Measure time to first byte reaching client
  - Measure time to last byte from S3
  - Verify first byte reaches client before last byte from S3
  - Verify no buffering occurs
  - _Requirements: 2.4_

- [x] 5.2 Write property test for error resilience
  - **Property 11: Error resilience**
  - **Validates: Requirements 3.5**
  - Simulate cache write failures during streaming
  - Verify client stream continues without interruption
  - Verify all chunks reach client despite cache errors
  - Verify errors are logged but don't propagate to client
  - _Requirements: 3.5_

- [x] 6. Wire up selective caching in forward_signed_range_request
  - Create SelectiveCacheWriter with missing ranges
  - Create SelectiveTeeStream wrapping S3 response body
  - Build HTTP response with streaming body
  - Copy headers from S3 response to client response
  - Set status to 206 Partial Content
  - Return response with streaming body
  - _Requirements: 2.4, 3.1, 3.2, 3.3_

- [x] 7. Implement range merging in metadata updates
  - Extend DiskCacheManager in `src/disk_cache.rs`
  - Add logic to detect adjacent ranges (range1.end + 1 == range2.start)
  - Add logic to detect overlapping ranges
  - Merge adjacent/overlapping ranges into single metadata entry
  - Update `update_range_metadata()` to perform merging
  - _Requirements: 4.5_

- [x] 7.1 Write property test for range merging
  - **Property 13: Range merging**
  - **Validates: Requirements 4.5**
  - Generate random sets of ranges including adjacent and overlapping
  - Update metadata with these ranges
  - Verify adjacent ranges are merged (e.g., [0-99] + [100-199] = [0-199])
  - Verify overlapping ranges are merged
  - Verify non-adjacent ranges remain separate
  - _Requirements: 4.5_

- [x] 8. Implement missing range calculation
  - Add helper function to calculate set difference (requested - cached)
  - Input: requested RangeSpec, cached Vec<RangeSpec>
  - Output: Vec<RangeSpec> of missing ranges
  - Handle overlapping cached ranges
  - Handle gaps in cached ranges
  - Handle partial overlaps
  - _Requirements: 7.1, 7.2_

- [x] 8.1 Write property test for missing range calculation
  - **Property 18: Missing range calculation**
  - **Validates: Requirements 7.1, 7.2**
  - Generate random requested range
  - Generate random set of cached ranges
  - Calculate missing ranges
  - Verify missing ranges equal set difference (requested - cached)
  - Verify no overlap between missing ranges and cached ranges
  - Verify union of missing and cached ranges covers requested range
  - _Requirements: 7.1, 7.2_

- [x] 9. Add error handling for signature detection failures
  - Wrap is_range_signed() call in try-catch
  - On error, log warning and default to standard logic
  - Add error handling for malformed Authorization headers
  - Ensure errors don't crash the proxy
  - _Requirements: 8.1_

- [x] 9.1 Write property test for signature detection failure handling
  - **Property 22: Signature detection failure handling**
  - **Validates: Requirements 8.1**
  - Generate malformed Authorization headers
  - Verify proxy forwards request without modification
  - Verify no panic or crash occurs
  - Verify standard logic is used as fallback
  - _Requirements: 8.1_

- [x] 10. Add error handling for cache write failures
  - Wrap cache write operations in try-catch
  - Log errors but continue streaming to client
  - Ensure cache failures don't block client response
  - Clean up partial cache files on failure
  - _Requirements: 3.5, 8.2, 8.3_

- [x] 11. Add error handling for metadata update failures
  - Wrap metadata update operations in try-catch
  - Log errors but complete client request
  - Don't retry failed metadata updates
  - Ensure client request succeeds even if metadata fails
  - _Requirements: 4.3, 8.5_

- [x] 11.1 Write property test for metadata error handling
  - **Property 12: Metadata error handling**
  - **Validates: Requirements 4.3**
  - Simulate metadata update failures
  - Verify errors are logged
  - Verify client request completes successfully
  - Verify no retries occur
  - _Requirements: 4.3_

- [x] 12. Add error handling for S3 errors
  - Check S3 response status codes
  - Forward 4xx and 5xx errors to client without caching
  - Log S3 errors with context
  - Clean up any partial cache writes
  - _Requirements: 8.4_

- [x] 12.1 Write property test for error forwarding
  - **Property 20: Error forwarding**
  - **Validates: Requirements 8.4**
  - Generate S3 error responses (4xx, 5xx)
  - Verify errors are forwarded to client
  - Verify no data is cached
  - Verify partial cache writes are cleaned up
  - _Requirements: 8.4_

- [x] 13. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 14. Add integration test for end-to-end signed range request
  - Create test object in mock S3
  - Generate signed range request with AWS SigV4
  - Verify response is 206 Partial Content
  - Verify response data is correct
  - Verify missing ranges are cached
  - Make identical signed range request
  - Verify second request is served from cache (no S3 call)
  - Verify cached data matches original S3 data
  - _Requirements: 5.1, 5.2, 5.5_

- [x] 14.1 Write property test for subsequent cache hits
  - **Property 14: Subsequent cache hits**
  - **Validates: Requirements 5.1, 5.2**
  - Generate signed range request
  - Process and cache missing ranges
  - Make identical request
  - Verify served entirely from cache
  - Verify no S3 request is made
  - _Requirements: 5.1, 5.2_

- [x] 14.2 Write property test for cache response correctness
  - **Property 15: Cache response correctness**
  - **Validates: Requirements 5.3**
  - Generate range request served from cache
  - Verify response status is 206 Partial Content
  - Verify Content-Range header is correct
  - Verify Content-Length header is correct
  - _Requirements: 5.3_

- [x] 14.3 Write property test for cache assembly
  - **Property 16: Cache assembly**
  - **Validates: Requirements 5.4**
  - Generate range request with full cache coverage
  - Verify proxy assembles response from cached range files
  - Verify no S3 request is made
  - Verify response is complete and correct
  - _Requirements: 5.4_

- [x] 14.4 Write property test for cache data integrity (round-trip)
  - **Property 17: Cache data integrity**
  - **Validates: Requirements 5.5**
  - Generate random data and cache it
  - Read data back from cache
  - Verify cached data is byte-identical to original
  - Test with various data sizes and patterns
  - _Requirements: 5.5_

- [x] 15. Add integration test for partial cache hits
  - Cache some ranges for an object
  - Make signed range request that partially overlaps cached ranges
  - Verify entire range is forwarded to S3
  - Verify only missing portions are cached
  - Make identical request again
  - Verify fully served from cache
  - _Requirements: 6.1, 6.2, 6.3_

- [x] 16. Add integration test for error scenarios
  - Test with malformed Authorization header
  - Test with cache write failures
  - Test with metadata update failures
  - Test with S3 errors
  - Verify client requests succeed despite errors
  - Verify errors are logged appropriately
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 17. Add logging for signed range request handling
  - Log when signed range request is detected
  - Log when forwarding entire range to S3
  - Log byte ranges being selectively cached
  - Log when subsequent request is served from cache
  - Log all errors with context (cache key, range, error details)
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [x] 18. Add metrics for signed range requests
  - Add counter: signed_range_requests_total
  - Add counter: signed_range_cache_hits_total
  - Add counter: signed_range_cache_misses_total
  - Add histogram: selective_cache_bytes_written
  - Add counter: selective_cache_write_errors_total
  - _Requirements: 10.1, 10.2, 10.3_

- [x] 19. Add performance test for streaming overhead
  - **Property 21: Non-blocking cache writes**
  - **Validates: Requirements 9.4**
  - Measure response time with selective caching enabled
  - Measure response time with caching disabled
  - Verify overhead is less than 10%
  - Verify cache write latency doesn't increase client response latency
  - _Requirements: 9.4_

- [x] 20. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 21. Update documentation
  - Update README.md with signed range request handling
  - Document is_range_signed() function
  - Document SelectiveCacheWriter usage
  - Document SelectiveTeeStream usage
  - Add examples of signed range requests
  - Document metrics and logging
