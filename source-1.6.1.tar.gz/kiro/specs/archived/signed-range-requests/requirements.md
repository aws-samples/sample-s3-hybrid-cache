# Requirements Document: Signed Range Request Handling

## Introduction

When AWS CLI signs GET requests with AWS Signature Version 4 (SigV4), it includes the Range header in the SignedHeaders list. The proxy cannot modify the Range header to fetch missing cache portions without invalidating the signature, causing 403 Forbidden errors from S3. This requirement addresses handling signed range requests by forwarding the entire original range to S3 while selectively caching only the missing portions.

## Glossary

- **Signed Range Request**: An HTTP GET request with a Range header that is included in the AWS SigV4 signature's SignedHeaders list
- **SignedHeaders**: The list of HTTP headers included in the AWS SigV4 signature calculation, found in the Authorization header
- **Range Header**: HTTP header specifying byte ranges to retrieve (e.g., "bytes=0-1023")
- **Cache Gap**: A portion of a requested range that is not present in the cache
- **Selective Caching**: Caching only specific byte ranges from a response while streaming the full response to the client
- **Signature Preservation**: Forwarding a request to S3 without modifications that would invalidate the AWS SigV4 signature
- **Cache Overlap**: The intersection between a requested range and ranges already cached
- **Missing Ranges**: Byte ranges within a requested range that are not present in the cache

## Requirements

### Requirement 1: Signed Range Detection

**User Story:** As a proxy system, I want to detect when a Range header is included in the request signature only when needed, so that I can handle it appropriately without breaking authentication while minimizing overhead.

#### Acceptance Criteria

1. WHEN a range request has full cache coverage, THEN the Proxy SHALL serve from cache without checking if the range is signed
2. WHEN a range request has cache gaps, THEN the Proxy SHALL check if the request contains an Authorization header with AWS SigV4 signature
3. WHEN cache gaps exist and SignedHeaders includes "range", THEN the Proxy SHALL mark the request as a signed range request
4. WHEN cache gaps exist and SignedHeaders does not include "range", THEN the Proxy SHALL handle the request using standard range logic (fetch missing ranges)
5. WHEN the Authorization header is malformed or absent, THEN the Proxy SHALL handle the request using standard range logic

### Requirement 2: Signed Range Request Forwarding

**User Story:** As a proxy system, I want to forward signed range requests without modification, so that the AWS SigV4 signature remains valid and S3 accepts the request.

#### Acceptance Criteria

1. WHEN a signed range request has cache gaps, THEN the Proxy SHALL forward the entire original Range header to S3
2. WHEN forwarding a signed range request, THEN the Proxy SHALL preserve all request headers exactly as received
3. WHEN forwarding a signed range request, THEN the Proxy SHALL not attempt to fetch missing ranges separately
4. WHEN S3 responds to a signed range request, THEN the Proxy SHALL stream the response to the client
5. WHEN the signature is preserved, THEN S3 SHALL return 200 or 206 status (not 403 Forbidden)

### Requirement 3: Selective Caching During Streaming

**User Story:** As a proxy system, I want to cache only the missing portions of a signed range request response, so that subsequent requests can be served from cache without redundant storage.

#### Acceptance Criteria

1. WHEN streaming a signed range request response, THEN the Proxy SHALL identify which byte ranges are not already cached
2. WHEN a byte range is already cached, THEN the Proxy SHALL skip caching that portion of the response
3. WHEN a byte range is not cached, THEN the Proxy SHALL write that portion to the cache
4. WHEN caching completes, THEN the Proxy SHALL update metadata to reflect newly cached ranges
5. WHEN selective caching fails, THEN the Proxy SHALL continue streaming to the client without caching

### Requirement 4: Cache Metadata Updates

**User Story:** As a proxy system, I want to update cache metadata after selectively caching ranges, so that future requests can identify what is cached.

#### Acceptance Criteria

1. WHEN new ranges are cached, THEN the Proxy SHALL update the object metadata to include the new range entries
2. WHEN updating metadata, THEN the Proxy SHALL preserve existing cached range information
3. WHEN metadata updates fail, THEN the Proxy SHALL log the error but not fail the client request
4. WHEN multiple ranges are cached, THEN the Proxy SHALL record each range separately in metadata
5. WHEN ranges are adjacent or overlapping, THEN the Proxy SHALL merge them in metadata

### Requirement 5: Subsequent Request Optimization

**User Story:** As a user, I want subsequent identical signed range requests to be served from cache, so that I don't incur S3 costs and latency for already-cached data.

#### Acceptance Criteria

1. WHEN a signed range request is received for fully cached ranges, THEN the Proxy SHALL serve the response entirely from cache
2. WHEN serving from cache, THEN the Proxy SHALL not forward the request to S3
3. WHEN serving from cache, THEN the Proxy SHALL return a 206 Partial Content response with correct Content-Range headers
4. WHEN cache metadata indicates full coverage, THEN the Proxy SHALL assemble the response from cached range files
5. WHEN assembled from cache, THEN the response SHALL be byte-identical to the original S3 response

### Requirement 6: Partial Cache Hit Handling

**User Story:** As a proxy system, I want to handle signed range requests with partial cache hits efficiently, so that I minimize S3 requests while maximizing cache utilization.

#### Acceptance Criteria

1. WHEN a signed range request has partial cache coverage, THEN the Proxy SHALL forward the entire range to S3
2. WHEN S3 responds, THEN the Proxy SHALL cache only the portions not already cached
3. WHEN caching completes, THEN subsequent requests for the same range SHALL be fully served from cache
4. WHEN partial cache hits occur, THEN the Proxy SHALL log the cache hit ratio
5. WHEN forwarding is required, THEN the Proxy SHALL preserve the original signature

### Requirement 7: Range Calculation and Tracking

**User Story:** As a proxy system, I want to accurately calculate which byte ranges are missing from cache, so that I cache only what is needed.

#### Acceptance Criteria

1. WHEN analyzing a range request, THEN the Proxy SHALL calculate the set difference between requested ranges and cached ranges
2. WHEN calculating missing ranges, THEN the Proxy SHALL account for all cached range files for the object
3. WHEN streaming response data, THEN the Proxy SHALL track the current byte offset in the response
4. WHEN a byte offset falls within a missing range, THEN the Proxy SHALL write that byte to cache
5. WHEN a byte offset falls within a cached range, THEN the Proxy SHALL skip writing that byte to cache

### Requirement 8: Error Handling

**User Story:** As a proxy system, I want to handle errors in signed range request processing gracefully, so that client requests succeed even when caching fails.

#### Acceptance Criteria

1. WHEN signature detection fails, THEN the Proxy SHALL forward the request without modification
2. WHEN selective caching fails, THEN the Proxy SHALL continue streaming the response to the client
3. WHEN cache writes fail, THEN the Proxy SHALL log the error and complete the client request
4. WHEN S3 returns an error, THEN the Proxy SHALL forward the error response to the client without caching
5. WHEN metadata updates fail, THEN the Proxy SHALL log the error but not retry

### Requirement 9: Performance Optimization

**User Story:** As a user, I want signed range request handling to have minimal performance overhead, so that response times remain fast.

#### Acceptance Criteria

1. WHEN streaming a signed range response, THEN the Proxy SHALL use buffered I/O for cache writes
2. WHEN calculating missing ranges, THEN the Proxy SHALL complete the calculation in O(n log n) time where n is the number of cached ranges
3. WHEN selective caching is active, THEN the streaming throughput SHALL not decrease by more than 10%
4. WHEN cache writes are slow, THEN the Proxy SHALL not block the client response stream
5. WHEN processing completes, THEN the Proxy SHALL release all resources promptly

### Requirement 10: Monitoring and Observability

**User Story:** As a system operator, I want visibility into signed range request handling, so that I can monitor effectiveness and troubleshoot issues.

#### Acceptance Criteria

1. WHEN a signed range request is detected, THEN the Proxy SHALL log the detection with request details
2. WHEN forwarding a signed range request, THEN the Proxy SHALL log the reason for forwarding
3. WHEN selective caching occurs, THEN the Proxy SHALL log the byte ranges being cached
4. WHEN a subsequent request is served from cache, THEN the Proxy SHALL log the cache hit
5. WHEN errors occur, THEN the Proxy SHALL log detailed error information including the request path and range
