# Requirements Document

## Introduction

Fix critical cache coherency issues in the S3 proxy that can lead to serving stale data. These issues occur when full objects are cached alongside partial ranges, and when range requests don't validate ETags against current object versions. The fixes ensure that clients always receive consistent, up-to-date data by properly managing cache invalidation and ETag validation.

This spec also includes cleanup of remaining documentation references to completed features (self-signed HTTPS mode, selective caching TODOs, and conditional header handling).

## Glossary

- **Proxy**: The S3 proxy server that caches responses between clients and S3
- **S3**: Amazon S3 backend storage service  
- **ETag**: Entity tag uniquely identifying a specific version of an object
- **Range Request**: HTTP request for a specific byte range of an object
- **Full Object**: Complete object cached without range restrictions
- **Partial Range**: Cached subset of bytes from an object
- **Cache Invalidation**: Removing stale data from the proxy's cache
- **Cache Coherency**: Ensuring cached data matches the current state in S3

## Requirements

### Requirement 1: Full Object Range Replacement

**User Story:** As a client, I want the proxy to serve consistent data when a full object is cached, so that I don't receive stale partial ranges that conflict with the current object version.

#### Acceptance Criteria

1.1. WHEN a full object is successfully cached THEN the Proxy SHALL invalidate all existing partial ranges for that object

1.2. WHEN a full object cache operation completes THEN the Proxy SHALL ensure only the full object metadata exists in the cache directory structure

1.3. WHEN a range request is made for an object with a cached full object THEN the Proxy SHALL serve the range from the full object cache and not from any stale partial ranges

1.4. WHEN cache cleanup occurs during full object caching THEN the Proxy SHALL remove all range files and range metadata for the affected object

1.5. WHEN multiple concurrent requests cache different ranges and a full object THEN the Proxy SHALL ensure the full object takes precedence and partial ranges are invalidated

### Requirement 2: ETag Validation in Range Requests

**User Story:** As a client, I want range requests to validate ETags against cached object metadata, so that I receive current data and not stale ranges from a previous version of the object.

#### Acceptance Criteria

2.1. WHEN a range request finds cached ranges THEN the Proxy SHALL validate the cached range ETag against the cached object metadata ETag before serving from cache

2.2. WHEN cached range ETags do not match the cached object metadata ETag THEN the Proxy SHALL invalidate all cached ranges for that object and forward the request to S3

2.3. WHEN ETag validation fails for cached ranges THEN the Proxy SHALL log the ETag mismatch and the cache invalidation action

2.4. WHEN no cached object metadata exists for ranges THEN the Proxy SHALL invalidate the orphaned ranges and forward the request to S3

2.5. WHEN ETag validation succeeds for cached ranges THEN the Proxy SHALL serve the cached ranges without additional S3 requests

### Requirement 3: Cache Metadata Consistency

**User Story:** As a system administrator, I want cache metadata to accurately reflect the current state of cached objects, so that cache operations are reliable and debuggable.

#### Acceptance Criteria

3.1. WHEN cache invalidation occurs THEN the Proxy SHALL update all relevant metadata files to reflect the current cache state

3.2. WHEN range files are removed during cleanup THEN the Proxy SHALL update the object metadata to remove references to the deleted ranges

3.3. WHEN ETag mismatches are detected THEN the Proxy SHALL update cache metadata to reflect the new object version

3.4. WHEN cache operations complete THEN the Proxy SHALL ensure metadata consistency between range files and object metadata

3.5. WHEN concurrent cache operations occur THEN the Proxy SHALL use appropriate locking to prevent metadata corruption

### Requirement 4: Error Handling and Recovery

**User Story:** As a client, I want the proxy to handle cache coherency errors gracefully, so that I receive correct data even when cache inconsistencies are detected.

#### Acceptance Criteria

4.1. WHEN ETag validation fails due to network errors THEN the Proxy SHALL retry the validation request up to 3 times before falling back to serving cached data

4.2. WHEN cache cleanup operations fail THEN the Proxy SHALL log the error and continue serving requests while attempting cleanup in the background

4.3. WHEN metadata corruption is detected THEN the Proxy SHALL invalidate the affected cache entries and fetch fresh data from S3

4.4. WHEN concurrent access conflicts occur during cache operations THEN the Proxy SHALL use file locking to ensure data integrity

4.5. WHEN cache directory operations fail THEN the Proxy SHALL fall back to serving requests directly from S3 without caching

### Requirement 5: Documentation Cleanup

**User Story:** As a developer, I want documentation to accurately reflect the current system capabilities, so that I can understand and maintain the codebase effectively.

#### Acceptance Criteria

5.1. WHEN documentation references self-signed HTTPS mode THEN the System SHALL update the documentation to reflect passthrough-only mode

5.2. WHEN code contains TODO comments about completed features THEN the System SHALL remove or update the comments to reflect current implementation

5.3. WHEN configuration examples reference removed features THEN the System SHALL update the examples to show only supported options

5.4. WHEN API documentation describes conditional header handling THEN the System SHALL ensure it accurately reflects the always-forward approach

5.5. WHEN developer guides reference selective caching TODOs THEN the System SHALL update them to reflect the completed SelectiveCacheWriter implementation