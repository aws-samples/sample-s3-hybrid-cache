# Cache Coherency Fixes Design

## Overview

This design addresses critical cache coherency issues in the S3 proxy that can lead to serving stale data. The primary issues are: (1) when full objects are cached, existing partial ranges aren't cleaned up, potentially serving stale partial data; and (2) range requests don't validate ETags against cached object metadata, potentially serving ranges from previous object versions.

The solution implements proper cache invalidation during full object caching and ETag validation for range requests using only cached metadata (maintaining the transparent forwarder principle). Additionally, this design includes cleanup of documentation references to completed features.

## Architecture

### Current Cache Structure

The proxy uses a two-tier cache system:
- **objects/**: Contains lightweight metadata files (.meta) with object information including ETag
- **ranges/**: Contains actual cached data (.bin files) for specific byte ranges

### Problem Areas

1. **Full Object Range Replacement**: When a full object is cached, existing partial ranges remain in the cache, potentially serving stale data
2. **ETag Validation**: Range requests don't validate cached range ETags against cached object metadata ETags
3. **Orphaned Ranges**: Range files can exist without corresponding object metadata

## Components and Interfaces

### 1. Cache Manager (cache.rs)

**Enhanced Methods**:

```rust
impl CacheManager {
    /// Invalidate all ranges for an object when caching full object
    pub async fn invalidate_ranges_for_full_object(
        &self,
        cache_key: &str,
        new_etag: &str
    ) -> Result<()>;
    
    /// Validate range ETag against object metadata ETag
    pub async fn validate_range_etag(
        &self,
        cache_key: &str,
        range_etag: &str
    ) -> Result<bool>;
    
    /// Clean up orphaned ranges without object metadata
    pub async fn cleanup_orphaned_ranges(
        &self,
        cache_key: &str
    ) -> Result<()>;
}
```

### 2. Disk Cache (disk_cache.rs)

**Enhanced Methods**:

```rust
impl DiskCache {
    /// Remove all range files for a specific object
    pub async fn remove_all_ranges(
        &self,
        cache_key: &str
    ) -> Result<()>;
    
    /// Get object metadata ETag for validation
    pub async fn get_object_etag(
        &self,
        cache_key: &str
    ) -> Result<Option<String>>;
    
    /// Update object metadata after range cleanup
    pub async fn update_object_metadata_after_cleanup(
        &self,
        cache_key: &str,
        remaining_ranges: Vec<RangeSpec>
    ) -> Result<()>;
}
```

### 3. HTTP Proxy (http_proxy.rs)

**Enhanced Logic**:

```rust
impl HttpProxy {
    /// Enhanced range request handling with ETag validation
    async fn handle_range_request_with_validation(
        &self,
        cache_key: &str,
        range_spec: &RangeSpec
    ) -> Result<CacheResponse>;
    
    /// Enhanced full object caching with range cleanup
    async fn cache_full_object_with_cleanup(
        &self,
        cache_key: &str,
        response_data: Bytes,
        etag: &str
    ) -> Result<()>;
}
```

## Data Models

### Enhanced Cache Metadata

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub content_type: String,
    pub cached_ranges: Vec<RangeSpec>,
    pub is_full_object: bool,  // New field
    pub cache_timestamp: SystemTime,
    pub ttl: Duration,
}

#[derive(Debug, Clone)]
pub struct RangeValidationResult {
    pub is_valid: bool,
    pub cached_etag: Option<String>,
    pub object_etag: Option<String>,
    pub action_taken: ValidationAction,
}

#[derive(Debug, Clone)]
pub enum ValidationAction {
    ServedFromCache,
    InvalidatedAndForwarded,
    OrphanedRangesRemoved,
    NoActionNeeded,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property Reflection

After reviewing all properties identified in the prework, several can be consolidated to eliminate redundancy:

- Properties 1.1, 1.2, 1.4 all relate to full object caching cleanup and can be combined into a comprehensive property
- Properties 2.1, 2.2, 2.5 all relate to ETag validation behavior and can be combined
- Properties 3.1, 3.2, 3.3, 3.4 all relate to metadata consistency and can be combined
- Property 4.1 is invalid (proxy doesn't make network requests) and will be removed

### Correctness Properties

**Property 1: Full object caching invalidates all ranges**
*For any* object with existing cached ranges, when a full object is successfully cached, all existing partial ranges should be invalidated and only full object metadata should remain in the cache directory structure
**Validates: Requirements 1.1, 1.2, 1.4**

**Property 2: Concurrent full object caching takes precedence**
*For any* object with concurrent range and full object caching operations, the full object should take precedence and all partial ranges should be invalidated upon completion
**Validates: Requirements 1.5**

**Property 3: Range requests serve from full object when available**
*For any* range request on an object with both cached full object and cached partial ranges, the range should be served from the full object cache, not from partial ranges
**Validates: Requirements 1.3**

**Property 4: ETag validation controls range serving**
*For any* range request with cached ranges, if cached range ETag matches cached object metadata ETag, ranges should be served from cache; if ETags don't match, ranges should be invalidated and request forwarded to S3
**Validates: Requirements 2.1, 2.2, 2.5**

**Property 5: ETag validation logging**
*For any* ETag validation failure, the system should log both the ETag mismatch and the cache invalidation action taken
**Validates: Requirements 2.3**

**Property 6: Orphaned range cleanup**
*For any* cached ranges without corresponding object metadata, the orphaned ranges should be invalidated and the request forwarded to S3
**Validates: Requirements 2.4**

**Property 7: Metadata consistency after operations**
*For any* cache operation (invalidation, cleanup, ETag updates), all relevant metadata files should be updated to accurately reflect the current cache state and maintain consistency between range files and object metadata
**Validates: Requirements 3.1, 3.2, 3.3, 3.4**

**Property 8: Concurrent operation safety**
*For any* concurrent cache operations on the same object, appropriate file locking should prevent metadata corruption and ensure data integrity
**Validates: Requirements 3.5, 4.4**

**Property 9: Error handling and fallback**
*For any* cache operation failure (cleanup, metadata corruption, directory operations), the system should log errors appropriately and either continue serving with fallback behavior or invalidate affected entries
**Validates: Requirements 4.2, 4.3, 4.5**

## Error Handling

### Cache Operation Failures

1. **Metadata Corruption Detection**:
   - Detect corrupted .meta files during read operations
   - Invalidate affected cache entries
   - Log corruption events with cache key and error details

2. **Range File Cleanup Failures**:
   - Log cleanup errors with specific file paths
   - Continue serving requests while attempting background cleanup
   - Retry cleanup operations with exponential backoff

3. **Directory Operation Failures**:
   - Detect filesystem errors during cache operations
   - Fall back to direct S3 forwarding without caching
   - Log fallback events for monitoring

### Concurrent Access Handling

1. **File Locking Strategy**:
   - Use `.lock` files for metadata operations
   - Implement timeout-based lock acquisition
   - Handle lock acquisition failures gracefully

2. **Race Condition Prevention**:
   - Atomic metadata updates using temporary files
   - Consistent ordering of lock acquisition
   - Proper cleanup of temporary files on failure

## Testing Strategy

### Unit Testing

Unit tests will cover specific scenarios and edge cases:

- Metadata file corruption detection and recovery
- File locking behavior under concurrent access
- Error handling during cleanup operations
- ETag validation with various mismatch scenarios

### Property-Based Testing

Property-based tests will verify universal behaviors using the `quickcheck` library with a minimum of 100 iterations per test:

- **Full Object Range Invalidation**: Generate random objects with random existing ranges, cache full objects, verify all ranges are invalidated
- **ETag Validation Behavior**: Generate random cache states with matching/mismatching ETags, verify correct serving/invalidation behavior
- **Metadata Consistency**: Generate random cache operations, verify metadata remains consistent with actual cached data
- **Concurrent Operation Safety**: Generate concurrent cache operations, verify no corruption occurs and final state is consistent

Each property-based test will be tagged with comments explicitly referencing the correctness property from this design document using the format: `**Feature: cache-coherency-fixes, Property {number}: {property_text}**`

### Integration Testing

Integration tests will validate end-to-end behavior:

- Full object caching with existing ranges in realistic scenarios
- Range requests with ETag validation using actual cache files
- Concurrent access patterns with multiple proxy instances
- Error recovery scenarios with simulated filesystem issues

## Implementation Plan

### Phase 1: Core Cache Coherency

1. **Enhanced Cache Manager Methods**:
   - Implement `invalidate_ranges_for_full_object()`
   - Implement `validate_range_etag()`
   - Implement `cleanup_orphaned_ranges()`

2. **Enhanced Disk Cache Methods**:
   - Implement `remove_all_ranges()`
   - Implement `get_object_etag()`
   - Implement `update_object_metadata_after_cleanup()`

3. **HTTP Proxy Integration**:
   - Integrate ETag validation into range request handling
   - Integrate range cleanup into full object caching
   - Add comprehensive logging for cache coherency operations

### Phase 2: Error Handling and Robustness

1. **Metadata Corruption Detection**:
   - Add validation during metadata file reads
   - Implement recovery procedures for corrupted metadata
   - Add monitoring and alerting for corruption events

2. **Concurrent Access Safety**:
   - Enhance file locking mechanisms
   - Add timeout handling for lock acquisition
   - Implement proper cleanup of lock files

3. **Fallback Mechanisms**:
   - Add fallback to direct S3 forwarding on cache failures
   - Implement background retry mechanisms for failed operations
   - Add comprehensive error logging and metrics

### Phase 3: Documentation Cleanup

1. **Configuration Documentation**:
   - Update all references to self-signed HTTPS mode
   - Remove outdated configuration examples
   - Update environment variable documentation

2. **Code Comments**:
   - Remove TODO comments about completed features
   - Update comments to reflect current implementation
   - Add documentation for new cache coherency features

3. **Developer Documentation**:
   - Update API documentation for conditional header handling
   - Document new cache coherency behaviors
   - Update troubleshooting guides

### Backward Compatibility

The implementation maintains full backward compatibility:

- Existing cache files remain valid and usable
- No changes to external APIs or configuration
- Graceful handling of existing inconsistent cache states
- Automatic cleanup of inconsistencies during normal operation

### Performance Considerations

1. **ETag Validation Overhead**:
   - Validation uses only cached metadata (no network requests)
   - Minimal performance impact on range request serving
   - Caching of validation results within request lifecycle

2. **Range Cleanup Efficiency**:
   - Batch operations for multiple range file deletions
   - Background cleanup to avoid blocking request serving
   - Efficient directory traversal for orphaned range detection

3. **Concurrent Access Optimization**:
   - Fine-grained locking to minimize contention
   - Read-write lock separation where appropriate
   - Lock-free operations for read-only cache access

## Monitoring and Observability

### New Metrics

1. **Cache Coherency Metrics**:
   - `cache_etag_validations_total` - Total ETag validations performed
   - `cache_etag_mismatches_total` - Total ETag mismatches detected
   - `cache_range_invalidations_total` - Total range invalidations due to ETag mismatches
   - `cache_orphaned_ranges_cleaned_total` - Total orphaned ranges cleaned up

2. **Error Metrics**:
   - `cache_metadata_corruption_total` - Total metadata corruption events
   - `cache_cleanup_failures_total` - Total cleanup operation failures
   - `cache_lock_timeouts_total` - Total lock acquisition timeouts

### Enhanced Logging

1. **Cache Coherency Events**:
   - ETag validation results with cache keys and ETags
   - Range invalidation events with affected ranges
   - Full object caching with cleanup details

2. **Error Events**:
   - Metadata corruption detection with file paths
   - Cleanup failures with error details and retry information
   - Lock acquisition failures with timeout details

3. **Performance Events**:
   - Cache operation timing for monitoring performance impact
   - Concurrent access patterns for optimization insights
   - Fallback activation events for reliability monitoring