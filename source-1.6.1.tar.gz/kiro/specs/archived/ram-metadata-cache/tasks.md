# Implementation Tasks: RAM Metadata Cache & Unified Cache Architecture

## Overview

Implementation tasks for RAM Metadata Cache and unified cache architecture. Cache will be wiped before deployment - no migration needed.

## Phase 1: Extend NewCacheMetadata

- [x] 1.1 Add HEAD fields to NewCacheMetadata
  - **File**: `src/cache_types.rs`
  - Add `head_expires_at: Option<SystemTime>`, `head_last_accessed: Option<SystemTime>`, `head_access_count: u64` with `#[serde(default)]`
  - Add helper methods: `is_head_expired()`, `refresh_head_ttl()`, `record_head_access()`
  - _Requirements: 2.2, 3.1_

## Phase 2: Create MetadataCache Module

- [x] 2.1 Create MetadataCache implementation
  - **File**: `src/metadata_cache.rs` (new)
  - Create `MetadataCacheConfig`, `MetadataCacheEntry`, `MetadataCache`, `MetadataCacheMetrics` structs
  - Implement `get()`, `put()`, `invalidate()`, `is_stale()` methods
  - Implement `get_or_load()` with per-key locking to prevent concurrent disk reads
  - Implement LRU eviction (simple LRU, not TinyLFU - all entries similar size)
  - Implement stale file handle recovery with retry logic
  - Add to `src/lib.rs` exports
  - _Requirements: 1.1-1.8, 5.1-5.4, 6.1-6.4_

## Phase 3: Extend AccessTracker

- [x] 3.1 Add HEAD access recording to AccessTracker
  - **File**: `src/access_tracker.rs`
  - Add `record_head_access()` method with format `bucket/key:HEAD`
  - Update `parse_log_entry()` to handle HEAD entries (entries without range info)
  - Update consolidation logic to handle HEAD access records
  - _Requirements: 4.1-4.3_

## Phase 4: Update CacheManager

- [x] 4.1 Integrate MetadataCache into CacheManager
  - **File**: `src/cache.rs`
  - Add `metadata_cache: Arc<MetadataCache>` field to `CacheManager`
  - Initialize `MetadataCache` in `CacheManager::new()`
  - _Requirements: 1.1, 1.2_

- [x] 4.2 Update HEAD request handling to use MetadataCache
  - **File**: `src/cache.rs`
  - Update `get_head_cache_entry_unified()` to check MetadataCache first, then disk
  - Update `store_head_cache_entry_unified()` to update HEAD fields in `NewCacheMetadata` and store in MetadataCache
  - Use `metadata_cache.get_or_load()` for disk reads with per-key locking
  - _Requirements: 1.2-1.4, 2.1, 3.2-3.3_

- [x] 4.3 Update GET/range handling to use MetadataCache
  - **File**: `src/cache.rs`
  - Update range lookup methods to use `metadata_cache.get_or_load()` for metadata
  - Update range storage methods to invalidate/update MetadataCache
  - _Requirements: 1.2-1.4, 5.1-5.3_

- [x] 4.4 Update invalidation to handle independent HEAD/GET TTLs
  - **File**: `src/cache.rs`
  - Ensure HEAD expiry doesn't delete `.meta` file (ranges may still be valid)
  - Ensure range expiry doesn't affect HEAD validity
  - Update `invalidate_head_cache_entry_unified()` to use MetadataCache
  - _Requirements: 2.4-2.5, 3.4-3.5_

## Phase 5: Rename objects/ to metadata/ (All Source Files)

- [x] 5.1 Update access_tracker.rs
  - **File**: `src/access_tracker.rs`
  - Change `get_metadata_path()` to use `metadata/` instead of `objects/`
  - _Requirements: 8.1-8.2_

- [x] 5.2 Update disk_cache.rs
  - **File**: `src/disk_cache.rs`
  - Change metadata paths from `objects/` to `metadata/`
  - Rename `traverse_and_cleanup_objects()` to `traverse_and_cleanup_metadata()`
  - Remove `head_cache` from subdirs list
  - _Requirements: 8.1-8.2_
  - **DONE**: Already uses `metadata/` directory. No changes needed.

- [x] 5.3 Update cache.rs
  - **File**: `src/cache.rs`
  - Change `get_new_metadata_file_path()` to use `metadata/` instead of `objects/`
  - Update eviction and cleanup methods
  - _Requirements: 8.1-8.2_
  - **DONE**: Delegates to disk_cache.rs which already uses `metadata/`.

- [x] 5.4 Update permissions.rs
  - **File**: `src/permissions.rs`
  - Change subdirs list: remove `head_cache`, change `objects` to `metadata`
  - Update tests
  - _Requirements: 8.1-8.2_
  - **DONE**: Already uses `metadata` in subdirs list.

- [x] 5.5 Update cache_initialization_coordinator.rs
  - **File**: `src/cache_initialization_coordinator.rs`
  - Change subdirs list: remove `head_cache`, change `objects` to `metadata`
  - Update directory references and log messages
  - _Requirements: 8.1-8.2_
  - **DONE**: Already uses `metadata/` directory.

- [x] 5.6 Update cache_size_tracker.rs
  - **File**: `src/cache_size_tracker.rs`
  - Change directory scanning from `objects/` to `metadata/`
  - Remove `scan_head_cache_file()` method
  - Remove `head_cache_expired` and `head_cache_errors` fields from `ScanMetadata`
  - _Requirements: 8.1-8.2_
  - **DONE**: No `objects/` references. `head_cache` removal is Phase 6 (tasks 6.3/6.4).

- [x] 5.7 Update journal files
  - **Files**: `src/journal_manager.rs`, `src/journal_consolidator.rs`
  - Change `objects/_journals` to `metadata/_journals`
  - _Requirements: 8.1-8.2_
  - **DONE**: Already uses `metadata/_journals`.

- [x] 5.8 Update remaining source files
  - **Files**: `src/hybrid_metadata_writer.rs`, `src/orphaned_range_recovery.rs`, `src/write_cache_manager.rs`, `src/cache_validator.rs`, `src/signed_put_handler.rs`
  - Change `objects/` to `metadata/` in path construction
  - _Requirements: 8.1-8.2_
  - **DONE**: `signed_put_handler.rs` updated to use `metadata_dir`. Other files had no `objects/` references.

## Phase 6: Remove Legacy Code

- [x] 6.1 Remove legacy HEAD cache structs from cache.rs
  - **File**: `src/cache.rs`
  - Remove: `HeadCacheEntry`, `HeadRamCacheEntry`, `HeadAccessTracker`, `HeadAccessStats`, `HeadPendingUpdate`
  - Remove legacy HEAD cache methods that are replaced by MetadataCache
  - Update `BatchFlushCoordinator` to remove HEAD-specific flush handling
  - _Requirements: 7.1-7.4_
  - **DONE**: Removed `HeadRamCacheEntry`, `HeadAccessStats`, `HeadPendingUpdate`, `HeadAccessTracker` structs. Kept `HeadCacheEntry` as return type for backward compatibility with `http_proxy.rs`. Updated `invalidate_head_cache_entry_unified()` to remove legacy RAM cache calls.

- [x] 6.2 Remove legacy HEAD cache from ram_cache.rs
  - **File**: `src/ram_cache.rs`
  - Remove `head_entries: HashMap<String, HeadRamCacheEntry>` field
  - Remove `head_access_tracker` field
  - Remove `get_head()`, `put_head()`, `remove_head()` methods
  - Remove `calculate_head_entry_size()` and `validate_head_entry()` methods
  - Remove HEAD-related tests
  - _Requirements: 7.3, 7.5_
  - **DONE**: Removed all HEAD-related fields, methods, and tests from `RamCache` and `ThreadSafeRamCache`. Deleted test files: `head_ram_cache_integration_test.rs`, `head_ram_cache_ttl_expiration_test.rs`, `head_cache_performance_test.rs`. Updated `ttl_override_test.rs` to use unified cache.

- [x] 6.3 Remove head_cache directory creation
  - **File**: `src/disk_cache.rs`
  - Remove `head_cache` from subdirs list in `initialize_cache_directories()`
  - _Requirements: 7.5_
  - **DONE**: Verified `disk_cache.rs` does not reference `head_cache` in subdirs list. Only creates: `metadata`, `ranges`, `locks`, and optionally `mpus_in_progress`.

- [x] 6.4 Clean up cache_size_tracker.rs HEAD references
  - **File**: `src/cache_size_tracker.rs`
  - Remove HEAD cache scanning logic (`scan_head_cache_file()` method)
  - Remove `head_cache_dir` scanning in validation
  - Remove `head_cache_expired` and `head_cache_errors` fields from `ValidationMetadata`
  - Update tests that reference HEAD cache fields
  - _Requirements: 7.5_
  - **DONE**: Removed `scan_head_cache_file()` method, removed `head_cache_expired` and `head_cache_errors` fields from `ValidationMetadata` and `ScanFileResult`, updated `write_validation_metadata()` signature, updated tests in `cache_size_tracker.rs` and `cache_size_tracking_integration_test.rs`.

## Phase 7: Configuration

- [x] 7.1 Add MetadataCacheConfig to config.rs
  - **File**: `src/config.rs`
  - Add `MetadataCacheConfig` struct with: `enabled`, `refresh_interval`, `max_entries`, `stale_handle_max_retries`
  - Add `metadata_cache` field to `CacheConfig`
  - Implement `Default` for `MetadataCacheConfig`
  - _Requirements: 1.5-1.6, 6.4_

- [x] 7.2 Update config example files
  - **File**: `config/config.example.yaml`
  - Add `metadata_cache` section with documented defaults
  - _Requirements: 1.5-1.6_

- [x] 7.3 Wire configuration into CacheManager
  - **File**: `src/cache.rs`
  - Pass `MetadataCacheConfig` from config to `MetadataCache::new()`
  - _Requirements: 1.5-1.6_

## Phase 8: Testing

- [x] 8.1 Update existing tests for directory rename
  - **Files**: `tests/temp_file_cleanup_test.rs`, `tests/put_then_get_integration_test.rs`, `tests/unified_storage_consistency_property_test.rs`, `tests/hash_distribution_test.rs`, `tests/disk_cache_test.rs`, `tests/multi_instance_atomic_metadata_writes_integration_test.rs`
  - Change `objects/` to `metadata/` in test paths
  - Remove `head_cache` directory references
  - _Requirements: 7.6, 8.1-8.2_
  - **DONE**: Updated `temp_file_cleanup_test.rs`, `coordinated_cache_initialization_integration_test.rs`, `coordinated_cache_initialization_property_test.rs`, `cache_validation_cleanup_test.rs`, `cache_size_tracking_performance_test.rs`, `real_world_cache_test.rs`.

- [x] 8.2 Update permissions.rs tests
  - **File**: `src/permissions.rs`
  - Update tests to use `metadata/` instead of `objects/`
  - Remove `head_cache` from expected directories
  - _Requirements: 7.6, 8.1-8.2_
  - **DONE**: Verified `permissions.rs` tests already use `metadata/` and do not reference `head_cache`. Tests verify `metadata`, `ranges`, `locks`, and optionally `mpus_in_progress` directories.

- [x] 8.3 Add unified cache integration test
  - **File**: `tests/unified_cache_test.rs` (new)
  - Single test covering: HEAD/GET share `.meta`, independent TTLs, proper invalidation
  - Test MetadataCache integration with CacheManager
  - _Requirements: 2.4-2.5, 3.1-3.4_
  - **DONE**: Created `tests/unified_cache_test.rs` with 5 tests covering: unified HEAD/GET storage, independent TTLs, HEAD invalidation preserving ranges, MetadataCache integration, and no head_cache directory creation.

## Phase 9: Documentation

- [x] 9.1 Update steering structure.md
  - **File**: `.kiro/steering/structure.md`
  - Change `objects/` to `metadata/` in cache directory structure
  - Remove `head_cache/` directory reference
  - _Requirements: 9.1_
  - **DONE**: Already uses `metadata/` directory and includes `metadata_cache.rs` in module list. No `head_cache/` references.

- [x] 9.2 Update CACHING.md
  - **File**: `docs/CACHING.md`
  - Replace "HEAD RAM Cache" section with "RAM Metadata Cache"
  - Update directory structure documentation (change `objects/` to `metadata/`)
  - Document unified HEAD/GET metadata storage
  - Remove references to separate `head_cache/` directory
  - _Requirements: 9.2_
  - **DONE**: Replaced "HEAD RAM Cache" section with "RAM Metadata Cache" section. Updated all directory structure references from `objects/` to `metadata/`. Removed all `head_cache/` directory references. Updated metrics and troubleshooting sections to remove HEAD cache-specific fields.

- [x] 9.3 Update DEVELOPER.md
  - **File**: `docs/DEVELOPER.md`
  - Replace "HEAD RAM Cache Architecture" section with "RAM Metadata Cache Architecture"
  - Document `MetadataCache` component
  - Update directory structure references
  - _Requirements: 9.3_
  - **DONE**: Replaced "HEAD RAM Cache Architecture" (section 8) with "RAM Metadata Cache Architecture". Updated module organization to include `metadata_cache.rs`. Updated directory structure from `objects/` to `metadata/`. Updated RAM-Disk Cache Coherency section. Updated HEAD Cache Performance Optimizations to Metadata Cache Performance Optimizations. Updated HEAD RAM Cache Implementation status section.

- [x] 9.4 Update ARCHITECTURE.md
  - **File**: `docs/ARCHITECTURE.md`
  - Add `metadata_cache.rs` to module organization
  - Update cache architecture description
  - _Requirements: 9.4_
  - **DONE**: `metadata_cache.rs` already in module organization. Updated directory structure from `objects/` to `metadata/` in hash-based sharding section.

## Phase 10: Version and Release

- [x] 10.1 Increment version to 0.5.0
  - **Files**: `Cargo.toml`, `CHANGELOG.md`
  - Update version from 0.4.0 to 0.5.0
  - Add CHANGELOG entry documenting:
    - RAM Metadata Cache for reduced disk I/O
    - Unified HEAD/GET metadata storage
    - Directory rename: `objects/` → `metadata/`
    - Removed legacy `head_cache/` directory
    - Removed legacy structs: `HeadCacheEntry`, `HeadRamCacheEntry`, `HeadAccessTracker`
  - _Requirements: 10.1-10.2_
  - **DONE**: Updated `Cargo.toml` version to 0.5.0. Added comprehensive CHANGELOG entry for v0.5.0 documenting all changes.

## Task Dependencies

```
Phase 1 → Phase 2 → Phase 3 → Phase 4 → Phase 5 → Phase 6 → Phase 7 → Phase 8 → Phase 9 → Phase 10
```

Note: Phase 4 (CacheManager integration) should be done before Phase 5 (directory rename) and Phase 6 (legacy removal) to ensure the new MetadataCache is working before removing old code.

## Estimated Effort

| Phase | Description | Hours |
|-------|-------------|-------|
| 1 | NewCacheMetadata fields | 2 |
| 2 | MetadataCache module | 8 |
| 3 | AccessTracker HEAD support | 2 |
| 4 | CacheManager integration | 6 |
| 5 | Directory rename (all files) | 4 |
| 6 | Legacy code removal | 4 |
| 7 | Configuration | 2 |
| 8 | Testing | 4 |
| 9 | Documentation | 2 |
| 10 | Version/Release | 1 |
| **Total** | | **35** |

## Risk Mitigation

1. **No migration needed** - cache will be wiped before deployment
2. **Backward compatible fields** - new fields use `#[serde(default)]`
3. **Incremental testing** - each phase has tests before proceeding
4. **Git commits per phase** - easy rollback if issues found
