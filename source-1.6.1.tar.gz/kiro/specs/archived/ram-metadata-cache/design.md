# Design Document: RAM Metadata Cache & Unified Cache Architecture

## Overview

This design implements:
1. A RAM-based metadata cache to reduce disk I/O during all requests
2. Unified metadata storage - HEAD and GET share the same `NewCacheMetadata` file
3. Removal of `head_cache/` directory and legacy `CacheMetadata` struct
4. Stale file handle recovery with retry logic

## Architecture

### Current State

```
cache/
├── objects/           # GET metadata (.meta files)
├── ranges/            # GET range data (.bin files)
├── head_cache/        # HEAD metadata (SEPARATE - to be removed)
├── access_tracking/   # GET access logs
└── ...
```

### Target State

```
cache/
├── metadata/          # Unified metadata (.meta files) - HEAD + GET (renamed from objects/)
├── ranges/            # Range data (.bin files)
├── access_tracking/   # Unified access logs (HEAD + GET)
└── ...
```

### Key Changes

1. **Remove `head_cache/` directory** - HEAD metadata stored in `metadata/` with GET metadata
2. **Rename `objects/` to `metadata/`** - Clearer naming that reflects contents (metadata, not objects)
3. **Unified `NewCacheMetadata`** - Add `head_expires_at` and `head_access_count` fields
4. **Unified access tracking** - Both HEAD and GET use same `AccessTracker`
5. **Independent TTLs** - HEAD and GET have separate expiration times in same file

## Unified Metadata Model

### Extended NewCacheMetadata

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NewCacheMetadata {
    pub cache_key: String,
    pub object_metadata: ObjectMetadata,  // Shared between HEAD and GET
    pub ranges: Vec<RangeSpec>,           // GET-specific (range data locations)
    pub created_at: SystemTime,
    pub expires_at: SystemTime,           // GET cache expiration (for ranges)
    pub compression_info: CompressionInfo,
    
    // NEW: HEAD-specific fields (access tracking only)
    #[serde(default)]
    pub head_expires_at: Option<SystemTime>,  // HEAD cache expiration
    #[serde(default)]
    pub head_last_accessed: Option<SystemTime>,
    #[serde(default)]
    pub head_access_count: u64,
}

// ObjectMetadata is SHARED between HEAD and GET
pub struct ObjectMetadata {
    pub etag: String,                           // Shared
    pub last_modified: String,                  // Shared
    pub content_length: u64,                    // Shared
    pub content_type: Option<String>,           // Shared
    pub response_headers: HashMap<String, String>, // Shared (all S3 headers)
    // ... other existing fields
}
```

**Key insight**: `object_metadata` is the single source of truth for object properties. HEAD and GET both read from and write to the same record. The only HEAD-specific fields are for TTL and access tracking.


### Request Flows

#### HEAD Request Flow

The HEAD request has a two-tier caching system with different TTLs:

1. **RAM MetadataCache** - refresh interval (default: 5s) - controls when to re-read from disk
2. **Disk .meta file** - `head_expires_at` (default: 1 minute) - controls when to re-fetch from S3

```
┌─────────────────────────────────────────────────────────────────┐
│                     HEAD Request Flow                            │
├─────────────────────────────────────────────────────────────────┤
│  1. Check RAM MetadataCache                                     │
│     - If HIT and loaded_at < refresh_interval (5s):             │
│       → Check head_expires_at in cached metadata                │
│       → If not expired: return headers (RAM HIT)                │
│       → If expired: go to step 3 (S3 fetch)                     │
│     - If MISS or stale (loaded_at >= 5s): go to step 2          │
│                                                                 │
│  2. Read .meta from disk (metadata/ directory)                  │
│     - Update RAM cache with disk contents                       │
│     - Check head_expires_at in .meta file                       │
│       → If not expired: return headers (DISK HIT)               │
│       → If expired: go to step 3 (S3 fetch)                     │
│                                                                 │
│  3. Fetch from S3 (cache miss or HEAD expired)                  │
│     - Forward HEAD request to S3                                │
│     - Update .meta file: set head_expires_at = now + head_ttl   │
│     - Update RAM cache                                          │
│     - Return headers (S3 FETCH)                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Example timeline:**
- T=0s: HEAD request → RAM miss → Disk miss → S3 fetch, cache in RAM + disk
- T=2s: HEAD request → RAM hit (2s < 5s refresh), head not expired → return from RAM
- T=6s: HEAD request → RAM stale (6s > 5s) → re-read disk → head not expired → return from disk, update RAM
- T=65s: HEAD request → RAM stale → re-read disk → head expired (65s > 60s) → S3 fetch, update both

#### GET/Range Request Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                     GET Range Request Flow                       │
├─────────────────────────────────────────────────────────────────┤
│  1. Check MetadataCache for NewCacheMetadata                    │
│  2. If HIT: check if requested range exists and not expired     │
│     - If valid range: serve from range file                     │
│     - If no range: fetch from S3, cache as new range            │
│  3. If MISS: read .meta from disk (metadata/) or fetch from S3  │
│  4. Update range access_count, last_accessed                    │
│  5. Serve response                                              │
└─────────────────────────────────────────────────────────────────┘
```

### TTL Independence

| Cache Layer | TTL Field | Default | Purpose |
|-------------|-----------|---------|---------|
| RAM MetadataCache | `refresh_interval` | 5s | How often to re-read from disk |
| HEAD (disk) | `head_expires_at` | 1 minute | When to re-fetch HEAD from S3 |
| GET range (disk) | `RangeSpec.expires_at` | ~10 years | When to re-fetch range from S3 |

**Key insight**: HEAD expiry doesn't delete the `.meta` file - it just means HEAD needs revalidation from S3. Ranges can still be valid and served from cache.

### Access Tracking

Both HEAD and GET access recorded in same `AccessTracker` system:

```rust
// Access log format extended to include request type
// Format: bucket/key:start-end:type
// Examples:
//   bucket/key:0-8388607:GET     # Range access
//   bucket/key:HEAD              # HEAD access

impl AccessTracker {
    pub async fn record_head_access(&self, cache_key: &str) -> Result<()> {
        let entry = format!("{}:HEAD", cache_key);
        self.write_to_current_bucket(&entry).await
    }
    
    pub async fn record_range_access(&self, cache_key: &str, start: u64, end: u64) -> Result<()> {
        let entry = format!("{}:{}-{}:GET", cache_key, start, end);
        self.write_to_current_bucket(&entry).await
    }
}
```

### Eviction Behavior

| Scenario | Action | Effect |
|----------|--------|--------|
| HEAD TTL expires | Nothing to evict | HEAD needs revalidation on next request, ranges unaffected |
| Range TTL expires | Remove range from `ranges` list, delete `.bin` file | That range needs re-fetch, other ranges unaffected |
| Low HEAD access | Nothing to evict (HEAD is just fields in `.meta`) | No action needed |
| Low range access | Evict specific ranges | Delete `.bin` files, update `ranges` list |
| No valid ranges AND HEAD expired | Delete `.meta` file | Full cache miss |

**Key insight**: HEAD data is just a few fields in the `.meta` file - there's no separate storage to evict. The `.meta` file is only deleted when there are no valid ranges AND HEAD is expired.

## MetadataCache Implementation

### Structure

```rust
pub struct MetadataCacheEntry {
    pub metadata: NewCacheMetadata,
    pub loaded_at: Instant,
    pub disk_mtime: Option<SystemTime>,
    pub last_accessed: Instant,
}

pub struct MetadataCache {
    entries: RwLock<HashMap<String, MetadataCacheEntry>>,
    lru_order: RwLock<VecDeque<String>>,
    config: MetadataCacheConfig,
    pending_reads: RwLock<HashMap<String, Arc<tokio::sync::Mutex<()>>>>,
    metrics: MetadataCacheMetrics,
}

pub struct MetadataCacheMetrics {
    pub hits: AtomicU64,
    pub misses: AtomicU64,
    pub stale_refreshes: AtomicU64,
    pub evictions: AtomicU64,
    pub stale_handle_errors: AtomicU64,
}
```

### Core Interface

```rust
impl MetadataCache {
    /// Get metadata from cache (for both HEAD and GET)
    pub async fn get(&self, cache_key: &str) -> Option<NewCacheMetadata>;
    
    /// Store metadata in cache
    pub async fn put(&self, cache_key: &str, metadata: NewCacheMetadata);
    
    /// Invalidate cache entry
    pub async fn invalidate(&self, cache_key: &str);
    
    /// Get or load with per-key locking
    pub async fn get_or_load<F, Fut>(&self, cache_key: &str, loader: F) -> Result<NewCacheMetadata>;
    
    /// Update HEAD-specific fields without full reload
    pub async fn update_head_access(&self, cache_key: &str, head_ttl: Duration);
    
    /// Update range access without full reload
    pub async fn update_range_access(&self, cache_key: &str, range_start: u64, range_end: u64);
}
```


## Migration Strategy

### Phase 1: Add HEAD Fields to NewCacheMetadata

Add new fields with `#[serde(default)]` for forward compatibility:
- `head_expires_at: Option<SystemTime>`
- `head_last_accessed: Option<SystemTime>`
- `head_access_count: u64`

Existing `.meta` files will deserialize with `None`/`0` defaults.

### Phase 2: Update HEAD Request Handling

1. HEAD requests read from `metadata/` directory instead of `head_cache/`
2. If `head_expires_at` is `None` or expired, treat as cache miss
3. On HEAD cache hit, update `head_access_count` and `head_last_accessed`
4. On HEAD cache store, set `head_expires_at = now + head_ttl`

### Phase 3: Rename objects/ to metadata/

1. Update all path construction functions to use `metadata/` instead of `objects/`
2. Update `get_metadata_path()` in `access_tracker.rs`
3. Update `disk_cache.rs` metadata path functions
4. Update `permissions.rs` subdirs list
5. Update `cache_initialization_coordinator.rs` directory references
6. Update `cache_size_tracker.rs` directory scanning

### Phase 4: Remove Legacy Code

1. Remove `HeadCacheEntry` struct
2. Remove `HeadRamCacheEntry` struct
3. Remove `HeadAccessTracker` (use unified `AccessTracker`)
4. Remove `CacheMetadata` struct
5. Remove `head_cache/` directory creation from initialization code

**Note**: No migration or cleanup needed - cache folder will be wiped before deployment.

### Phase 5: Update Documentation

1. Update `.kiro/steering/structure.md` - cache directory structure
2. Update `docs/CACHING.md` - **Replace** "HEAD RAM Cache" section with "RAM Metadata Cache"
3. Update `docs/DEVELOPER.md` - **Replace** "HEAD RAM Cache Architecture" with "RAM Metadata Cache Architecture"
4. Update `docs/ARCHITECTURE.md` - module organization
5. Remove all references to `head_cache/` directory
6. Update all references from `objects/` to `metadata/`
7. Remove all references to separate HEAD RAM cache (now unified in MetadataCache)

## Stale File Handle Recovery

```rust
impl MetadataCache {
    async fn read_with_stale_handle_retry<F, Fut>(
        &self,
        cache_key: &str,
        operation: F,
    ) -> Result<NewCacheMetadata>
    where
        F: Fn() -> Fut,
        Fut: Future<Output = Result<NewCacheMetadata>>,
    {
        let mut attempts = 0;
        loop {
            match operation().await {
                Ok(result) => return Ok(result),
                Err(e) if is_stale_file_handle(&e) => {
                    attempts += 1;
                    self.metrics.stale_handle_errors.fetch_add(1, Ordering::Relaxed);
                    
                    if attempts >= self.config.stale_handle_max_retries {
                        self.invalidate(cache_key).await;
                        tracing::error!(
                            cache_key = %cache_key,
                            attempts = attempts,
                            "Stale file handle persisted after retries"
                        );
                        return Err(e);
                    }
                    
                    tracing::warn!(
                        cache_key = %cache_key,
                        attempt = attempts,
                        "Stale file handle error, retrying"
                    );
                    
                    tokio::time::sleep(Duration::from_millis(10 * attempts as u64)).await;
                }
                Err(e) => return Err(e),
            }
        }
    }
}

fn is_stale_file_handle(error: &ProxyError) -> bool {
    if let Some(io_err) = error.source().and_then(|e| e.downcast_ref::<std::io::Error>()) {
        return io_err.raw_os_error() == Some(116)  // ESTALE on Linux
            || io_err.kind() == std::io::ErrorKind::NotFound;
    }
    false
}
```

## Configuration

```yaml
cache:
  metadata_cache:
    enabled: true
    refresh_interval: "5s"      # How often RAM cache re-reads from disk
    max_entries: 10000
    stale_handle_max_retries: 3
  head_ttl: "60s"               # How long HEAD is valid before S3 re-fetch (existing config)
```

## Correctness Properties

### Property 1: Cache Hit Returns Valid Metadata
*For any* cache key with a non-stale entry, `get()` returns the stored metadata.
**Validates: Requirements 1.1, 1.3**

### Property 2: Staleness Respects Refresh Interval
*For any* entry where `loaded_at.elapsed() >= refresh_interval`, `get()` returns `None`.
**Validates: Requirements 1.5, 4.3**

### Property 3: HEAD/GET TTL Independence
*For any* object, HEAD expiry does not affect range validity, and range expiry does not affect HEAD validity.
**Validates: Requirements 7.1, 7.4**

### Property 4: Capacity Limit Enforced
*For any* sequence of `put()` operations, `entries.len() <= max_entries`.
**Validates: Requirements 1.6, 6.1**

### Property 5: Concurrent Read Prevention
*For any* cache key being loaded, only one disk read occurs regardless of concurrent requests.
**Validates: Requirements 4.2**

### Property 6: Stale Handle Retry
*For any* ESTALE error, retry up to `max_retries` times before failing.
**Validates: Requirements 5.1, 5.2**

## Testing Strategy

**Principles:**
- Minimal tests, maximum coverage
- Property tests for comprehensive input coverage (avoid many unit tests)
- One integration test covering the unified cache flow
- No duplicate coverage between unit and integration tests

**MetadataCache Unit Tests (4 tests total):**
1. Basic operations (get/put/invalidate in one test)
2. LRU eviction at capacity
3. Staleness/refresh behavior
4. Concurrent `get_or_load()` single-read guarantee

**Integration Test (1 test):**
- Single test covering: HEAD/GET share `.meta`, independent TTLs, proper invalidation

**What NOT to test:**
- Implementation details (internal data structures)
- Behavior already covered by existing tests
- Edge cases that property tests will cover

## Legacy Code Removal

### Structs to Remove

| Struct | Location | Replacement |
|--------|----------|-------------|
| `CacheMetadata` | `cache_types.rs` | `ObjectMetadata` in `NewCacheMetadata` |
| `HeadCacheEntry` | `cache.rs` | `NewCacheMetadata` with HEAD fields |
| `HeadRamCacheEntry` | `cache.rs` | `MetadataCacheEntry` |
| `HeadAccessTracker` | `cache.rs` | Unified `AccessTracker` |
| `RamCacheEntry` | `cache.rs` | `RamDataEntry` (data only) |

### Directories to Remove

| Directory | Replacement |
|-----------|-------------|
| `head_cache/` | `metadata/` (unified) |

### Directories to Rename

| Old Name | New Name | Reason |
|----------|----------|--------|
| `objects/` | `metadata/` | Clearer naming - contains metadata, not objects |

### Files Requiring objects/ → metadata/ Update

| File | Changes Required |
|------|------------------|
| `src/access_tracker.rs` | `get_metadata_path()` function |
| `src/disk_cache.rs` | Metadata path construction, method names |
| `src/permissions.rs` | Subdirs list |
| `src/cache_initialization_coordinator.rs` | Directory references |
| `src/cache_size_tracker.rs` | Directory scanning, remove HEAD metrics |
| `src/journal_manager.rs` | `_journals` path references |
| `src/journal_consolidator.rs` | `_journals` path references |
| `src/hybrid_metadata_writer.rs` | `get_metadata_file_path()` |
| `src/orphaned_range_recovery.rs` | Metadata path construction |
| `src/write_cache_manager.rs` | `collect_eviction_candidates()` path |
| `src/cache_validator.rs` | `get_metadata_file_path()` |
| `src/signed_put_handler.rs` | Metadata path construction |
| `src/cache.rs` | Multiple path functions and comments |
| `.kiro/steering/structure.md` | Cache directory structure docs |
| `docs/CACHING.md` | Cache directory structure docs |
| `docs/DEVELOPER.md` | Implementation details |
| `docs/ARCHITECTURE.md` | Module organization |
| `tests/temp_file_cleanup_test.rs` | Test path references |
| `tests/put_then_get_integration_test.rs` | Test path references |
| `tests/unified_storage_consistency_property_test.rs` | Test path references |
| `tests/hash_distribution_test.rs` | Test path references |
| `tests/disk_cache_test.rs` | Test path references |
| `tests/multi_instance_atomic_metadata_writes_integration_test.rs` | Journal paths |

## Memory Usage Estimate

| Component | Size per Entry | 10,000 Entries |
|-----------|---------------|----------------|
| NewCacheMetadata | ~1-2 KB | ~10-20 MB |
| Entry overhead | ~100 bytes | ~1 MB |
| HashMap overhead | ~50 bytes | ~0.5 MB |
| **Total** | ~1.5-2.5 KB | **~15-25 MB** |

## Eviction Policy Clarification

The system has three caches with different eviction policies:

| Cache | Contents | Eviction Policy | Rationale |
|-------|----------|-----------------|-----------|
| **MetadataCache** (new) | `NewCacheMetadata` objects | LRU only | All entries are similar size (~1-2KB), TinyLFU complexity not needed |
| **RAM Data Cache** | Range data (actual bytes) | Same as disk cache config | Entries vary greatly in size, benefits from TinyLFU scan resistance |
| **Disk Cache** | Range data + metadata files | Configurable (LRU/TinyLFU) | User-configured via `eviction_algorithm` |

**Key points:**
- `MetadataCache` always uses simple LRU - no configuration option
- RAM data cache and disk cache share the same `eviction_algorithm` config setting
- This ensures consistent eviction behavior between RAM and disk tiers for range data