# Requirements Document: RAM Metadata Cache & Unified Cache Architecture

## Introduction

This document outlines the requirements for implementing a RAM Metadata Cache and unifying the cache architecture. The feature aims to:
1. Reduce disk I/O by caching `NewCacheMetadata` in RAM
2. Unify HEAD and GET metadata storage (remove `head_cache/` directory)
3. Remove legacy `CacheMetadata`, `HeadCacheEntry`, and related structs
4. Handle stale file handle errors gracefully

## Current State

- **GET cache**: Uses `NewCacheMetadata` in `objects/` + range files in `ranges/`
- **HEAD cache**: Uses separate `HeadCacheEntry` in `head_cache/` directory
- **RAM cache**: Uses legacy `RamCacheEntry` with `CacheMetadata`
- **Access tracking**: Separate `AccessTracker` (GET) and `HeadAccessTracker` (HEAD)

## Target State

- **Unified metadata**: Both HEAD and GET use `NewCacheMetadata` in `metadata/` (renamed from `objects/`)
- **No `head_cache/`**: HEAD metadata stored in same file as GET metadata
- **RAM metadata cache**: New `MetadataCache` for `NewCacheMetadata` objects
- **Unified access tracking**: Single `AccessTracker` for both HEAD and GET
- **Clearer naming**: `objects/` directory renamed to `metadata/` for clarity

## Glossary

- **System**: The S3 Proxy application
- **NewCacheMetadata**: Unified metadata format for both HEAD and GET cache
- **MetadataCache**: New RAM cache for `NewCacheMetadata` objects
- **CacheMetadata**: Legacy metadata format (to be removed)
- **HeadCacheEntry**: Legacy HEAD cache format (to be removed)

## Requirements

### Requirement 1: RAM Metadata Cache

**User Story:** As a system operator, I want to reduce disk I/O operations, so that the S3 Proxy performs better under high load.

#### Acceptance Criteria

1. THE System SHALL implement a RAM-based metadata cache to store `NewCacheMetadata` objects
2. WHEN processing any request (HEAD or GET), THE System SHALL first check the RAM metadata cache
3. WHILE metadata exists in RAM cache and is not stale, THE System SHALL use the RAM-cached version
4. WHEN metadata is not present or stale, THE System SHALL read from disk and update the RAM cache
5. THE System SHALL support configurable refresh intervals (default: 5s)
6. THE System SHALL limit maximum entries (default: 10000)
7. THE System SHALL implement LRU eviction policy (simple, since all metadata entries are similar size)
8. THE System SHALL use a separate eviction policy from the RAM data cache (which uses the disk cache eviction setting)


### Requirement 2: Unified HEAD/GET Metadata Storage

**User Story:** As a developer, I want HEAD and GET to share the same metadata file, so that the codebase is simpler and storage is not duplicated.

#### Acceptance Criteria

1. THE System SHALL store HEAD metadata in `NewCacheMetadata` files in `metadata/` directory
2. THE System SHALL add `head_expires_at`, `head_last_accessed`, and `head_access_count` fields to `NewCacheMetadata`
3. THE System SHALL remove the `head_cache/` directory creation from initialization code
4. WHEN HEAD TTL expires, THE System SHALL NOT delete the metadata file (ranges may still be valid)
5. WHEN range TTL expires, THE System SHALL NOT affect HEAD validity

### Requirement 3: Independent TTL Tracking

**User Story:** As a system architect, I want HEAD and GET to have independent TTLs, so that their different freshness requirements are preserved.

#### Acceptance Criteria

1. THE System SHALL track HEAD expiration separately via `head_expires_at` field
2. THE System SHALL track range expiration separately via `RangeSpec.expires_at` field
3. WHEN a HEAD request is served, THE System SHALL check `head_expires_at` for validity
4. WHEN a GET request is served, THE System SHALL check the relevant `RangeSpec.expires_at` for validity
5. THE System SHALL support different TTL configurations for HEAD (`head_ttl`) and GET (`get_ttl`)

### Requirement 4: Unified Access Tracking

**User Story:** As a developer, I want a single access tracking system, so that the codebase is simpler.

#### Acceptance Criteria

1. THE System SHALL extend `AccessTracker` to support both HEAD and GET access
2. THE System SHALL record HEAD access with format `bucket/key:HEAD`
3. THE System SHALL record range access with format `bucket/key:start-end:GET`
4. THE System SHALL remove `HeadAccessTracker` after migration
5. THE System SHALL preserve access-based eviction decisions for both HEAD and GET

### Requirement 5: Cache Consistency

**User Story:** As a developer, I want to ensure cache consistency, so that clients receive up-to-date metadata.

#### Acceptance Criteria

1. WHEN new metadata is written to disk, THE System SHALL invalidate the RAM cache entry
2. WHILE metadata is being read from disk, THE System SHALL prevent concurrent reads (per-key locking)
3. WHEN a cache entry expires (staleness), THE System SHALL re-read from disk on next access
4. FOR shared storage, THE System SHALL check disk mtime no more frequently than refresh interval

### Requirement 6: Stale File Handle Recovery

**User Story:** As a system operator, I want to handle stale file handle errors, so that the system remains stable.

#### Acceptance Criteria

1. IF a stale file handle error (ESTALE) occurs, THEN THE System SHALL retry the operation
2. IF error persists after retries, THEN THE System SHALL invalidate cache and return error
3. THE System SHALL log stale file handle occurrences
4. THE System SHALL support configurable retry count (default: 3)

### Requirement 7: Legacy Code Removal

**User Story:** As a developer, I want legacy cache code removed, so that the codebase is cleaner.

#### Acceptance Criteria

1. THE System SHALL remove `CacheMetadata` struct
2. THE System SHALL remove `HeadCacheEntry` struct
3. THE System SHALL remove `HeadRamCacheEntry` struct
4. THE System SHALL remove `HeadAccessTracker`
5. THE System SHALL remove `head_cache/` directory creation from initialization
6. THE System SHALL update all tests to use unified format

### Requirement 8: Directory Rename (objects/ → metadata/)

**User Story:** As a developer, I want the `objects/` directory renamed to `metadata/`, so that the directory name accurately reflects its contents. Note the code will not need to do this rename - the cache will be wiped when this version of code (0.5) is deployed.

#### Acceptance Criteria

1. THE System SHALL rename the `objects/` directory to `metadata/` in all source code
2. THE System SHALL update all path construction functions to use `metadata/` instead of `objects/`
3. THE System SHALL update all documentation to reference `metadata/` directory
4. THE System SHALL update steering files to reference `metadata/` directory
5. THE System SHALL update all test files that reference `objects/` directory

### Requirement 9: Documentation Updates

**User Story:** As a developer, I want all documentation updated to reflect the new architecture, so that documentation remains accurate.

#### Acceptance Criteria

1. THE System SHALL update `.kiro/steering/structure.md` with new cache directory structure
2. THE System SHALL update `docs/CACHING.md` with unified HEAD/GET architecture
3. THE System SHALL update `docs/DEVELOPER.md` with new implementation details
4. THE System SHALL update `docs/ARCHITECTURE.md` with updated module organization
5. THE System SHALL remove references to `head_cache/` directory from all documentation
6. THE System SHALL document the new `MetadataCache` component

### Requirement 10: Version Increment

**User Story:** As a release manager, I want the version incremented to reflect this significant architectural change.

#### Acceptance Criteria

1. THE System SHALL increment version from 0.4.0 to 0.5.0 in Cargo.toml
2. THE System SHALL update CHANGELOG.md with release notes for 0.5.0