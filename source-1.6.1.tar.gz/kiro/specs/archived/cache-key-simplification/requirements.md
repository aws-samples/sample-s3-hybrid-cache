# Requirements Document: Cache Key Simplification

## Introduction

The current cache key format includes the S3 endpoint hostname (e.g., `s3.amazonaws.com:bucket/object.jpg`). Since S3 bucket names are globally unique across all AWS regions and endpoints, the hostname is redundant. Removing it simplifies cache keys, reduces filename length, and enables cache portability across different S3 endpoints.

## Glossary

- **Cache Key**: A unique identifier for a cached object, used to generate filesystem paths
- **S3 Endpoint**: The hostname used to access S3 (e.g., s3.amazonaws.com, s3.us-east-1.amazonaws.com)
- **Bucket Name**: A globally unique identifier for an S3 bucket across all AWS regions
- **Object Path**: The full path to an object within a bucket (e.g., bucket/path/to/object.jpg)
- **Cache System**: The S3 proxy's caching layer that stores S3 object data locally

## Requirements

### Requirement 1: Remove Hostname from Cache Keys

**User Story:** As a cache system, I want to generate cache keys without the endpoint hostname, so that cache keys are simpler and more portable.

#### Acceptance Criteria

1. WHEN the Cache System generates a cache key for a full object, THEN the Cache System SHALL use the format `{path}` without the hostname
2. WHEN the Cache System generates a cache key for a versioned object, THEN the Cache System SHALL use the format `{path}:version:{version_id}` without the hostname
3. WHEN the Cache System generates a cache key for a range request, THEN the Cache System SHALL use the format `{path}:range:{start}-{end}` without the hostname
4. THE Cache System SHALL NOT include the S3 endpoint hostname in any cache key format
5. THE Cache System SHALL maintain backward compatibility by treating old cache keys as invalid (cache miss)

### Requirement 2: Simplified Cache Key Formats

**User Story:** As a developer, I want clear and consistent cache key formats, so that I can understand and debug cache behavior.

#### Acceptance Criteria

1. THE Cache System SHALL use the following cache key formats:
   - Full objects: `{path}`
   - Versioned objects: `{path}:version:{version_id}`
   - Range requests: `{path}:range:{start}-{end}`
   - Versioned ranges: `{path}:version:{version_id}:range:{start}-{end}`
2. WHEN the Cache System parses a cache key, THEN the Cache System SHALL extract the path without expecting a hostname prefix
3. THE Cache System SHALL document all cache key formats in the design document
4. THE Cache System SHALL use consistent delimiters (`:`) for all cache key components
5. THE Cache System SHALL ensure cache keys remain unique across all object types

### Requirement 3: Cache Key Sanitization Updates

**User Story:** As a cache system, I want to sanitize cache keys efficiently, so that filesystem operations remain fast and reliable.

#### Acceptance Criteria

1. WHEN the Cache System sanitizes a cache key, THEN the Cache System SHALL apply the same character replacement rules as before
2. WHEN a cache key exceeds 200 characters, THEN the Cache System SHALL use SHA-256 hashing as before
3. THE Cache System SHALL reduce the average cache key length by removing the hostname prefix
4. WHEN the Cache System generates file paths, THEN the Cache System SHALL use the simplified cache key
5. THE Cache System SHALL maintain support for S3 object keys up to 1024 characters

### Requirement 4: Documentation Updates

**User Story:** As a developer, I want clear documentation of cache key formats, so that I can understand and work with the cache system.

#### Acceptance Criteria

1. THE Cache System SHALL document the new cache key format in all relevant documentation
2. THE Cache System SHALL provide examples of cache key formats for all object types
3. THE Cache System SHALL update code comments to reflect new cache key format
4. THE Cache System SHALL update design documents with new cache key structure
5. THE Cache System SHALL ensure all documentation is consistent with the implementation

### Requirement 5: Cache Portability

**User Story:** As a system operator, I want cache entries to work across different S3 endpoints, so that I can switch regions or endpoints without losing cache.

#### Acceptance Criteria

1. WHEN the Cache System caches an object from any S3 endpoint, THEN the Cache System SHALL use the same cache key regardless of endpoint
2. WHEN a client switches from s3.amazonaws.com to s3.us-east-1.amazonaws.com, THEN the Cache System SHALL serve the same cached object
3. THE Cache System SHALL enable cache sharing across proxy instances using different S3 endpoints
4. WHEN the Cache System looks up a cache entry, THEN the Cache System SHALL NOT consider the endpoint hostname
5. THE Cache System SHALL maintain cache consistency across endpoint changes

### Requirement 6: Update Cache Key Generation Functions

**User Story:** As a developer, I want updated cache key generation functions, so that I can generate simplified cache keys correctly.

#### Acceptance Criteria

1. WHEN the Cache System calls `generate_cache_key()`, THEN the Cache System SHALL accept only `path` parameter (no `host` parameter)
2. WHEN the Cache System calls `generate_versioned_cache_key()`, THEN the Cache System SHALL accept `path` and `version_id` parameters (no `host` parameter)
3. WHEN the Cache System calls `generate_range_cache_key()`, THEN the Cache System SHALL accept `path`, `start`, and `end` parameters (no `host` parameter)
4. THE Cache System SHALL update all cache key generation functions to remove the `host` parameter
5. THE Cache System SHALL update all call sites to use the new function signatures

### Requirement 7: Cache Key Parsing Updates

**User Story:** As a cache system, I want to parse cache keys correctly, so that I can extract object information without expecting a hostname.

#### Acceptance Criteria

1. WHEN the Cache System parses a cache key for TTL lookup, THEN the Cache System SHALL extract the path without expecting a hostname prefix
2. WHEN the Cache System extracts a path from a cache key, THEN the Cache System SHALL handle the simplified format
3. WHEN the Cache System checks if a cache key belongs to an object, THEN the Cache System SHALL compare paths without hostnames
4. THE Cache System SHALL update all cache key parsing logic to handle the new format
5. THE Cache System SHALL handle cache keys with version IDs, part numbers, and range specifications correctly

### Requirement 8: Cache Cleanup

**User Story:** As a developer, I want to ensure cache cleanup works correctly, so that the cache system remains healthy.

#### Acceptance Criteria

1. WHEN the Cache System performs cache cleanup, THEN the Cache System SHALL correctly identify cache entries using the new format
2. WHEN the Cache System evicts cache entries, THEN the Cache System SHALL properly delete all associated files
3. THE Cache System SHALL maintain cache size limits correctly with the new format
4. THE Cache System SHALL log cache cleanup operations appropriately
5. THE Cache System SHALL continue operating normally during cache cleanup

### Requirement 9: Testing and Validation

**User Story:** As a developer, I want comprehensive tests for the new cache key format, so that I can ensure correctness.

#### Acceptance Criteria

1. THE Cache System SHALL include unit tests for all cache key generation functions
2. THE Cache System SHALL include tests for cache key parsing with the new format
3. THE Cache System SHALL include tests for cache key sanitization with shorter keys
4. THE Cache System SHALL include tests for cache portability across endpoints
5. THE Cache System SHALL include integration tests with real S3 requests

### Requirement 10: Performance Impact

**User Story:** As a system operator, I want to understand performance impacts, so that I can plan for the change.

#### Acceptance Criteria

1. THE Cache System SHALL measure the reduction in average cache key length
2. THE Cache System SHALL measure the reduction in sanitized filename length
3. THE Cache System SHALL verify that cache operations maintain the same performance
4. THE Cache System SHALL verify that SHA-256 hashing is needed less frequently (shorter keys)
5. THE Cache System SHALL document any performance improvements from shorter cache keys
