# Implementation Plan: Cache Key Simplification

- [x] 1. Update cache key generation functions
  - Remove `host` parameter from `generate_cache_key()`
  - Remove `host` parameter from `generate_versioned_cache_key()`
  - Remove `host` parameter from `generate_range_cache_key()`
  - Remove `host` parameter from `generate_versioned_range_cache_key()`
  - Remove `host` parameter from `generate_part_cache_key()`
  - Remove `host` parameter from `generate_versioned_part_cache_key()`
  - Update function implementations to use only `path` parameter
  - _Requirements: 1.1, 1.2, 1.3, 6.1, 6.2, 6.3, 6.4_

- [ ]* 1.1 Write property test for cache key uniqueness
  - **Property 1: Cache Key Uniqueness**
  - **Validates: Requirements 2.5**

- [ ]* 1.2 Write property test for cache key format consistency
  - **Property 2: Cache Key Format Consistency**
  - **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 2.1**

- [x] 2. Update cache key generation call sites
  - Update all calls in `http_proxy.rs` to remove `host` argument
  - Update all calls in `range_handler.rs` to remove `host` argument
  - Update all calls in `cache.rs` to remove `host` argument
  - Update any other call sites throughout the codebase
  - Ensure compilation succeeds after updates
  - _Requirements: 6.5_

- [x] 2.1 Fix failing tests due to cache key format changes
  - Fix `test_current_version_cache_invalidation` in `tests/versioning_multipart_test.rs`
  - Fix `test_coordinated_cache_cleanup` in `tests/shared_cache_coordination_test.rs`
  - Update test cache keys to use new format (path-only, no host prefix)
  - Verify all existing tests pass with new cache key format
  - _Requirements: 9.1, 9.2_

- [x] 2.2 Clean up dead code discovered during refactoring
  - Review `validate_cached_entry_against_s3()` function - appears unused, verify and remove if dead code
  - Search for other functions that may have become unused after cache key changes
  - Remove or document any dead code found
  - Ensure no regressions from cleanup

- [x] 3. Update cache key parsing functions
  - Update `parse_cache_key_for_ttl()` to handle new format (return only path, not tuple)
  - Update `extract_path_from_cache_key()` to handle new format
  - Update `cache_key_belongs_to_object()` to remove `host` parameter
  - Update `is_part_cache_key_for_object()` to remove `host` parameter
  - Update any other parsing functions
  - _Requirements: 2.2, 7.1, 7.2, 7.3, 7.4_

- [ ]* 3.1 Write property test for path extraction correctness
  - **Property 3: Path Extraction Correctness**
  - **Validates: Requirements 2.2, 7.2**

- [x] 4. Update cache key comparison and matching
  - Update all functions that compare cache keys to objects
  - Remove `host` parameter from comparison functions
  - Update cache invalidation logic to work with new format
  - Update cache statistics collection to work with new format
  - _Requirements: 7.3, 7.4_

- [x] 4.1 Fix cache key sanitization collision vulnerability
  - Replace custom sanitization with URL/percent encoding to prevent collisions
  - Current issue: keys like `file_colon_name.txt` and `file:name.txt` produce same filename
  - Implement collision-free sanitization using `percent_encoding` crate
  - Update `sanitize_cache_key_new()` in `src/cache.rs` to use percent encoding
  - Update `sanitize_cache_key_new()` in `src/disk_cache.rs` to use percent encoding
  - Update `extract_cache_key_from_filename()` to decode percent-encoded keys
  - Add dependency: `percent-encoding = "2.3"` to `Cargo.toml`
  - Maintain SHA-256 hashing for keys exceeding 200 characters
  - _Requirements: 3.1, 3.4, 2.5 (cache key uniqueness)_

- [ ]* 4.1.1 Write property test for sanitization collision prevention
  - **Property: No Sanitization Collisions**
  - Generate pairs of different cache keys and verify they produce different filenames
  - Test edge cases: keys with literal `_colon_`, `_slash_`, etc.
  - Verify round-trip: sanitize then extract produces original key
  - **Validates: Requirements 2.5, 3.1, 3.4**

- [x] 5. Verify cache cleanup works with new format
  - Test cache entry identification with new format
  - Test cache eviction with new format
  - Verify all associated files are deleted correctly
  - Test cache size calculation with new format
  - _Requirements: 8.1, 8.2, 8.3, 8.4_

- [ ]* 5.1 Write property test for cache cleanup correctness
  - **Property 5: Cache Cleanup Correctness**
  - **Validates: Requirements 8.1, 8.2, 8.3**

- [ ] 6. Update cache key sanitization
  - Verify sanitization works correctly with new format
  - Test that shorter keys reduce SHA-256 hashing frequency
  - Ensure file path generation works with new format
  - Update any sanitization-related logic
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [ ]* 6.1 Write property test for cache key length reduction
  - **Property 6: Cache Key Length Reduction**
  - **Validates: Requirements 3.3, 10.1**

- [ ]* 6.2 Write property test for sanitization consistency
  - **Property 7: Sanitization Consistency**
  - **Validates: Requirements 3.1, 3.4**

- [x] 7. Update TTL override configuration parsing
  - Update TTL override path matching to work without hostname
  - Update configuration examples in code comments
  - Test TTL overrides work correctly with new format
  - _Requirements: 7.1, 7.4_

- [x] 8. Update cache statistics and metrics
  - Update cache entry counting to work with new format
  - Update cache size calculation to work with new format
  - Verify metrics collection works correctly
  - Add metric for old cache key encounters (if desired)
  - _Requirements: 7.4_

- [x] 9. Update logging and debugging
  - Update log messages to reflect new cache key format
  - Update debug output to show simplified keys
  - Verify log readability improvements
  - Ensure all cache-related logs use new format
  - _Requirements: 8.4_

- [x] 10. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 11. Update documentation
  - Update `.kiro/specs/s3-proxy/design.md` with new cache key formats
  - Update `docs/CACHING.md` with new cache key examples
  - Update code comments with new cache key examples
  - Ensure all documentation is consistent
  - _Requirements: 2.3, 4.1, 4.2, 4.3, 4.4, 4.5_

- [ ]* 12. Write integration tests
  - Test cache operations with new cache key format
  - Test cross-endpoint cache portability
  - Test cache eviction with new format
  - Test all cache types (full objects, ranges, versions)
  - _Requirements: 5.1, 5.2, 5.3, 9.5_

- [ ]* 12.1 Write property test for cache portability
  - **Property 4: Cache Portability**
  - **Validates: Requirements 5.1, 5.2, 5.4**

- [ ]* 13. Performance testing
  - Measure average cache key length reduction
  - Measure reduction in SHA-256 hashing frequency
  - Verify no performance regression in cache operations
  - Document performance improvements
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [x] 14. Final checkpoint - Verify all requirements met
  - Ensure all tests pass, ask the user if questions arise.
