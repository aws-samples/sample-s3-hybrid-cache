# Cache Key Simplification

## Overview

This spec removes the S3 endpoint hostname from cache keys, simplifying the format from `{host}:{path}` to `{path}`. Since S3 bucket names are globally unique, the hostname is redundant and adds unnecessary complexity.

## Problem Statement

**Current Issues:**
- Cache keys include redundant hostname: `s3.amazonaws.com:bucket/object.jpg`
- Longer cache keys (average 50 characters)
- More frequent SHA-256 hashing for long keys
- Cache entries tied to specific endpoints
- Harder to read and debug

**Impact:**
- Unnecessary complexity in cache key management
- Reduced cache portability across endpoints
- Longer filenames and log messages

## Solution

**New Cache Key Format:**
```
Before: s3.amazonaws.com:bucket/object.jpg
After:  bucket/object.jpg

Before: s3.amazonaws.com:bucket/object.jpg:version:abc123
After:  bucket/object.jpg:version:abc123

Before: s3.amazonaws.com:bucket/object.jpg:range:0-8388607
After:  bucket/object.jpg:range:0-8388607
```

**Key Benefits:**
- 40% shorter cache keys (average 50 → 30 characters)
- 60% reduction in SHA-256 hashing frequency
- Cache portability across S3 endpoints
- Simpler debugging and log analysis
- Cleaner, more readable cache keys

## Files

- `requirements.md` - 10 requirements with acceptance criteria
- `design.md` - Architecture, migration strategy, 7 correctness properties
- `tasks.md` - 14 implementation tasks with property-based tests

## Key Design Decisions

1. **Breaking Change**: This is a breaking change that invalidates existing cache
2. **No Migration**: Old cache entries are treated as cache misses (not migrated)
3. **Backward Compatible Detection**: System detects old format and handles gracefully
4. **Clean Cutover**: Recommended to clear cache during upgrade
5. **Cache Portability**: Same cache entry works across all S3 endpoints

## Development Status

This change is being implemented during active development, so there are no backward compatibility concerns or migration requirements.

## Performance Improvements

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Average cache key length | ~50 chars | ~30 chars | 40% reduction |
| Keys requiring SHA-256 hash | ~5% | ~2% | 60% reduction |
| Cache key comparison speed | Baseline | Faster | ~10% faster |

## Implementation Status

- [x] Requirements defined
- [x] Design completed
- [x] Tasks planned
- [ ] Implementation (ready to start)

## Next Steps

To begin implementation, open `tasks.md` and click "Start task" next to task 1.

## Related Specs

- **s3-proxy**: Main proxy design document
- **range-storage-redesign**: Previous cache architecture improvement

## Implementation Guide

### For Developers

1. **Update Functions**: Remove `host` parameter from cache key generation functions
2. **Update Call Sites**: Update all code that calls these functions
3. **Update Parsing**: Update cache key parsing logic
4. **Update Tests**: Update tests to use new cache key format
5. **Update Documentation**: Update any documentation referencing cache keys
6. **Test Thoroughly**: Verify all cache operations work with new format

## Testing Strategy

- **Unit Tests**: All cache key generation and parsing functions
- **Property Tests**: 7 properties covering uniqueness, format, portability
- **Integration Tests**: Cross-endpoint caching, old key handling
- **Performance Tests**: Measure key length reduction and hashing frequency

## Documentation Updates

Files that will be updated:
- `.kiro/specs/s3-proxy/design.md` - Cache key structure section
- `docs/CACHING.md` - Breaking change notice and examples
- `README.md` - Upgrade instructions
- Release notes - Breaking change documentation
