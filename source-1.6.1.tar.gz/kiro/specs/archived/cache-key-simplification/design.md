# Design Document: Cache Key Simplification

## Overview

This design removes the S3 endpoint hostname from cache keys, simplifying the cache key format from `{host}:{path}` to `{path}`. Since S3 bucket names are globally unique, the hostname is redundant and adds unnecessary complexity. This change reduces cache key length, simplifies debugging, and enables cache portability across different S3 endpoints.

## Architecture

### Current Cache Key Format (Before)

```
Full objects:        s3.amazonaws.com:bucket/object.jpg
Versioned objects:   s3.amazonaws.com:bucket/object.jpg:version:abc123
Range requests:      s3.amazonaws.com:bucket/object.jpg:range:0-8388607
Versioned ranges:    s3.amazonaws.com:bucket/object.jpg:version:abc123:range:0-8388607
```

### New Cache Key Format (After)

```
Full objects:        bucket/object.jpg
Versioned objects:   bucket/object.jpg:version:abc123
Range requests:      bucket/object.jpg:range:0-8388607
Versioned ranges:    bucket/object.jpg:version:abc123:range:0-8388607
```

### Key Benefits

1. **Shorter Keys**: Average reduction of 15-20 characters per cache key
2. **Simpler Debugging**: Easier to read and understand cache keys
3. **Cache Portability**: Same cache entry works across s3.amazonaws.com, s3.us-east-1.amazonaws.com, etc.
4. **Less Hashing**: Fewer keys exceed 200 character threshold requiring SHA-256 hashing
5. **Cleaner Logs**: More readable cache-related log messages

## Components and Interfaces

### 1. Cache Key Generation Functions

**Before:**
```rust
pub fn generate_cache_key(host: &str, path: &str) -> String {
    format!("{}:{}", host, path)
}

pub fn generate_versioned_cache_key(host: &str, path: &str, version_id: &str) -> String {
    format!("{}:{}:version:{}", host, path, version_id)
}

pub fn generate_range_cache_key(host: &str, path: &str, start: u64, end: u64) -> String {
    format!("{}:{}:range:{}-{}", host, path, start, end)
}
```

**After:**
```rust
pub fn generate_cache_key(path: &str) -> String {
    path.to_string()
}

pub fn generate_versioned_cache_key(path: &str, version_id: &str) -> String {
    format!("{}:version:{}", path, version_id)
}

pub fn generate_range_cache_key(path: &str, start: u64, end: u64) -> String {
    format!("{}:range:{}-{}", path, start, end)
}
```

### 2. Cache Key Parsing

**Before:**
```rust
fn parse_cache_key_for_ttl(&self, cache_key: &str) -> (String, String) {
    // Cache key format: "host:path" or "host:path:version:..." 
    if let Some(colon_pos) = cache_key.find(':') {
        let host = &cache_key[..colon_pos];
        let path = &cache_key[colon_pos + 1..];
        // Extract path before any additional components
        let path_end = path.find(':').unwrap_or(path.len());
        (host.to_string(), path[..path_end].to_string())
    } else {
        ("".to_string(), cache_key.to_string())
    }
}
```

**After:**
```rust
fn parse_cache_key_for_ttl(&self, cache_key: &str) -> String {
    // Cache key format: "path" or "path:version:..." or "path:range:..."
    // Extract path before any additional components
    if let Some(colon_pos) = cache_key.find(':') {
        cache_key[..colon_pos].to_string()
    } else {
        cache_key.to_string()
    }
}
```

### 3. Cache Key Comparison

**Before:**
```rust
fn cache_key_belongs_to_object(&self, cache_key: &str, host: &str, path: &str, version_id: Option<&str>) -> bool {
    let parts: Vec<&str> = cache_key.split(':').collect();
    if parts.len() < 2 {
        return false;
    }
    
    // Check host and path match
    if parts[0] != host || parts[1] != path {
        return false;
    }
    
    // Check version if specified
    // ...
}
```

**After:**
```rust
fn cache_key_belongs_to_object(&self, cache_key: &str, path: &str, version_id: Option<&str>) -> bool {
    // Extract path from cache key (before any :version: or :range: suffix)
    let cache_path = if let Some(colon_pos) = cache_key.find(':') {
        &cache_key[..colon_pos]
    } else {
        cache_key
    };
    
    // Check path matches
    if cache_path != path {
        return false;
    }
    
    // Check version if specified
    // ...
}
```

## Data Models

### Cache Key Structure

**New Format:**
```
{path}                              # Full object
{path}:version:{version_id}         # Versioned object
{path}:range:{start}-{end}          # Range request
{path}:version:{version_id}:range:{start}-{end}  # Versioned range
```

**Components:**
- `{path}`: Full S3 path including bucket (e.g., `my-bucket/path/to/object.jpg`)
- `{version_id}`: S3 version ID (e.g., `abc123def456`)
- `{start}`, `{end}`: Byte range boundaries (e.g., `0-8388607`)

**Delimiters:**
- `:` separates cache key components
- `-` separates range start and end

### Path Extraction

The path is always the first component before any `:` delimiter:

```rust
fn extract_path(cache_key: &str) -> &str {
    cache_key.split(':').next().unwrap_or(cache_key)
}
```

## Implementation Strategy

### Direct Implementation

Since the system is still in development, we can implement the new cache key format directly without backward compatibility concerns:

1. **Update Functions**: Change all cache key generation functions to remove `host` parameter
2. **Update Call Sites**: Update all code that calls these functions
3. **Update Parsing**: Update cache key parsing to work with new format
4. **Test Thoroughly**: Ensure all cache operations work correctly
5. **Update Documentation**: Reflect new format in all documentation

### No Migration Needed

- No existing production cache to worry about
- Can implement cleanly without compatibility layers
- Simpler code without old format detection
- Faster implementation timeline

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Cache Key Uniqueness

*For any* two different S3 objects (different paths or versions), the generated cache keys SHALL be different.

**Validates: Requirements 2.5**

### Property 2: Cache Key Format Consistency

*For any* cache key generated by the system, it SHALL follow one of the documented formats without including a hostname.

**Validates: Requirements 1.1, 1.2, 1.3, 1.4, 2.1**

### Property 3: Path Extraction Correctness

*For any* cache key, extracting the path SHALL return the correct S3 object path without hostname prefix.

**Validates: Requirements 2.2, 7.2**

### Property 4: Cache Portability

*For any* S3 object accessed through different endpoints, the cache key SHALL be identical.

**Validates: Requirements 5.1, 5.2, 5.4**

### Property 5: Cache Cleanup Correctness

*For any* cache entry with the new format, cache cleanup operations SHALL correctly identify and remove all associated files.

**Validates: Requirements 8.1, 8.2, 8.3**

### Property 6: Cache Key Length Reduction

*For any* cache key, the new format SHALL be shorter than the old format by at least the length of the hostname plus one character (for the colon).

**Validates: Requirements 3.3, 10.1**

### Property 7: Sanitization Consistency

*For any* cache key, the sanitization process SHALL produce the same result regardless of which endpoint was used to access the object.

**Validates: Requirements 3.1, 3.4**

## Error Handling

### Old Cache Key Detection

- **Detection**: Check if first component contains dots and looks like hostname
- **Action**: Log debug message, treat as cache miss
- **No Error**: System continues normally

### Cache Key Parsing Errors

- **Invalid Format**: Log warning, treat as cache miss
- **Missing Components**: Use defaults where appropriate
- **Malformed Keys**: Sanitize and continue

### Migration Issues

- **Mixed Cache**: Old and new entries coexist temporarily
- **Gradual Cleanup**: Old entries removed during normal eviction
- **No Data Loss**: All data remains in S3, cache is just invalidated

## Testing Strategy

### Unit Tests

1. **Cache Key Generation**: Test all generation functions with various inputs
2. **Path Extraction**: Test extracting paths from all cache key formats
3. **Old Key Detection**: Test identifying old vs new format keys
4. **Sanitization**: Test that shorter keys reduce hashing frequency
5. **Parsing**: Test parsing cache keys for TTL lookup and object matching

### Property-Based Tests

Using `quickcheck` with minimum 100 iterations:

1. **Property 1: Cache Key Uniqueness**
   - Generate random S3 paths and versions
   - Verify all cache keys are unique
   - **Feature: cache-key-simplification, Property 1: Cache Key Uniqueness**

2. **Property 2: Cache Key Format Consistency**
   - Generate random cache keys
   - Verify all match documented formats
   - Verify none contain hostnames
   - **Feature: cache-key-simplification, Property 2: Cache Key Format Consistency**

3. **Property 3: Path Extraction Correctness**
   - Generate random cache keys
   - Extract paths
   - Verify paths match original input
   - **Feature: cache-key-simplification, Property 3: Path Extraction Correctness**

4. **Property 4: Cache Portability**
   - Generate same object with different endpoints
   - Verify cache keys are identical
   - **Feature: cache-key-simplification, Property 4: Cache Portability**

5. **Property 6: Cache Key Length Reduction**
   - Generate cache keys with old and new format
   - Verify new format is always shorter
   - **Feature: cache-key-simplification, Property 6: Cache Key Length Reduction**

### Integration Tests

1. **Cross-Endpoint Caching**: Cache object via one endpoint, retrieve via another
2. **Old Key Handling**: Verify old cache entries are treated as cache misses
3. **Cache Operations**: Verify all cache operations work with new format
4. **Eviction**: Verify cache eviction works correctly with new keys

## Performance Impact

### Expected Improvements

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Average cache key length | ~50 chars | ~30 chars | 40% reduction |
| Keys requiring SHA-256 hash | ~5% | ~2% | 60% reduction |
| Cache key comparison speed | Baseline | Faster | ~10% faster |
| Log readability | Baseline | Better | Subjective |

### Measurements

- **Cache Key Length**: Measure average length before and after
- **Hashing Frequency**: Count how often SHA-256 is used
- **Performance**: Verify no regression in cache operations

## Implementation Notes

### Phase 1: Update Cache Key Generation

1. Remove `host` parameter from all cache key generation functions
2. Update function signatures
3. Update all call sites in http_proxy.rs, range_handler.rs, etc.
4. Add unit tests for new functions

### Phase 2: Update Cache Key Parsing

1. Update `parse_cache_key_for_ttl()` to handle new format
2. Update `extract_path_from_cache_key()` to handle new format
3. Update `cache_key_belongs_to_object()` to remove host parameter
4. Add unit tests for parsing functions

### Phase 3: Add Backward Compatibility

1. Implement `is_old_cache_key_format()` detection
2. Update `get_cached_response()` to handle old keys
3. Add logging for old key encounters
4. Add tests for old key detection

### Phase 4: Update Documentation

1. Update design.md with new cache key formats
2. Update CACHING.md with breaking change notice
3. Add migration guide to release notes
4. Update code comments

### Phase 5: Testing

1. Run all unit tests
2. Run property-based tests
3. Run integration tests
4. Perform manual testing with different endpoints

## Documentation Updates

### Files to Update

1. **`.kiro/specs/s3-proxy/design.md`**:
   - Update "Cache Key Structure" section
   - Remove hostname from all cache key examples
   - Add note about breaking change

2. **`docs/CACHING.md`**:
   - Update cache key examples
   - Add "Breaking Changes" section
   - Document upgrade process

3. **`README.md`**:
   - Add note about cache invalidation on upgrade
   - Update any cache key examples

4. **Release Notes**:
   - Document breaking change
   - Provide upgrade instructions
   - Explain cache invalidation

## Security Considerations

### No Security Impact

- Cache keys are internal identifiers, not exposed to clients
- Removing hostname doesn't affect security boundaries
- Sanitization rules remain the same
- File permissions unchanged

### Path Traversal

- Existing sanitization prevents path traversal
- No new attack vectors introduced
- SHA-256 hashing still used for long keys

## Future Enhancements

1. **Cache Key Versioning**: Add version marker to cache keys for future migrations
2. **Automatic Migration**: Tool to migrate old cache entries to new format
3. **Cache Key Compression**: Further optimize cache key storage
4. **Metrics**: Track cache key length distribution
