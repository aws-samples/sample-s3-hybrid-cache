# Journal-Based Size Tracking - Tasks

## Core Implementation

### Task 1: Add SizeState to JournalConsolidator
- [x] 1.1 Create `SizeState` struct in `journal_consolidator.rs`
- [x] 1.2 Add `size_state: Arc<RwLock<SizeState>>` field to `JournalConsolidator`
- [x] 1.3 Add `size_state_path: PathBuf` field for persistence location
- [x] 1.4 Implement `load_size_state()` for startup recovery
- [x] 1.5 Implement `persist_size_state()` with atomic write
- [x] 1.6 Add `get_current_size()` and `get_write_cache_size()` methods

### Task 2: Implement Size Delta Calculation
- [x] 2.1 Create `calculate_size_delta()` function
- [x] 2.2 Handle Add operation (+compressed_size)
- [x] 2.3 Handle Remove operation (-compressed_size)
- [x] 2.4 Track write cache size separately (detect write cache paths)
- [x] 2.5 Unit tests for size delta calculation

### Task 3: Integrate Size Tracking into Consolidation Cycle
- [x] 3.1 Modify `consolidate_object()` to return size delta for each processed entry
- [x] 3.2 Create `run_consolidation_cycle()` method that wraps the current main.rs logic
- [x] 3.3 Accumulate size deltas across all processed keys
- [x] 3.4 Update `SizeState` after processing all keys
- [x] 3.5 Persist size state after each cycle
- [x] 3.6 Create `ConsolidationCycleResult` struct
- [x] 3.7 Add `initialize()` method for startup size state loading

### Task 4: Change Consolidation Interval to 5 Seconds
- [x] 4.1 Update `ConsolidationConfig::default()` interval to 5s
- [x] 4.2 Update config parsing to accept new default
- [x] 4.3 Add `consolidation_interval` to YAML config schema (already exists in SharedStorageConfig)
- [x] 4.4 Update documentation for new interval

### Task 5: Add Eviction Triggering
- [x] 5.1 Add `cache_manager: Mutex<Option<Weak<CacheManager>>>` field to JournalConsolidator
- [x] 5.2 Implement `set_cache_manager()` method
- [x] 5.3 Add `max_cache_size` to `ConsolidationConfig` (passed from CacheConfig)
- [x] 5.4 Implement `maybe_trigger_eviction()` method
- [x] 5.5 Call eviction check at end of `run_consolidation_cycle()` (only if size changed)
- [x] 5.6 Update size state immediately with bytes_freed
- [x] 5.7 Persist size state after eviction
- [x] 5.8 **BUG FIX**: Change `perform_eviction_with_lock()` to return `total_bytes_freed` instead of `total_ranges_evicted`
- [x] 5.9 **REMOVE**: Delete `size_tracker.update_size()` call from `batch_evict_ranges()` (consolidator handles size updates)

### Task 5b: Modify Background Task in main.rs
- [x] 5b.1 Replace manual consolidation loop with `consolidator.run_consolidation_cycle()` call
- [x] 5b.2 Remove the `cleanup_consolidated_entries()` call (moved into run_consolidation_cycle)
- [x] 5b.3 Update logging to use ConsolidationCycleResult fields

## Dashboard and Metrics

### Task 6: Update Dashboard to Read from Consolidator
- [x] 6.1 Modify `get_cache_stats()` to get size from consolidator
- [x] 6.2 Add `last_consolidation` timestamp to dashboard stats
- [x] 6.3 Add `write_cache` field to `CacheStatsResponse` struct (separate from disk_cache)
- [x] 6.4 Populate write_cache with size_bytes, size_human, max_size from consolidator
- [x] 6.5 Update dashboard HTML/JS to display write cache next to object cache (if applicable)
- [x] 6.6 Verify dashboard displays correct values

### Task 7: Update Metrics to Read from Consolidator
- [x] 7.1 Modify metrics collection to get size from consolidator
- [x] 7.2 Add `consolidation_count` metric
- [x] 7.3 Add `last_consolidation_timestamp` metric
- [x] 7.4 Verify OTLP export includes new metrics

## Remove Old System

### Task 8: Remove Shared Storage Conditional Code
- [x] 8.1 Remove `shared_storage.enabled` from `SharedStorageConfig`
- [x] 8.2 Remove `if !self.shared_storage.enabled` checks in `cache.rs`
- [x] 8.3 Remove `if !shared_storage_config.enabled` checks in `CacheManager::create_configured_disk_cache_manager()`
- [x] 8.4 Remove mode switching in `HybridMetadataWriter` (always use journal mode)
- [x] 8.5 Remove `perform_eviction_with_lock` vs direct eviction branching
- [x] 8.6 Update `config.rs` to remove `enabled` field from `SharedStorageConfig`
- [x] 8.7 Update `config.example.yaml` to remove `shared_storage.enabled`

### Task 9: Remove SizeDeltaBuffer
- [x] 9.1 Remove `SizeDeltaBuffer` struct from `cache_size_tracker.rs` (N/A - never implemented)
- [x] 9.2 Remove `FlushResult` and `FlushGuard` structs (N/A - never implemented for size tracking)
- [x] 9.3 Remove `delta_buffer` field from `CacheSizeTracker` (N/A - never implemented)
- [x] 9.4 Remove `delta_flush_task` background task (N/A - never implemented)
- [x] 9.5 Remove delta file path methods (`delta_file_path()`) (N/A - only exists in test helper)
- [x] 9.6 Remove `flush_delta_buffer()` and `force_flush()` methods (N/A - never implemented for size tracking)

### Task 10: Remove update_size() Calls
- [x] 10.1 Remove `update_size()` method from `CacheSizeTracker`
- [x] 10.2 Remove `update_write_cache_size()` method
- [x] 10.3 Remove `update_size_sync()` method
- [x] 10.4 Remove callers in `cache.rs`:
  - `batch_evict_ranges()` - line 5081 (already removed in Task 5.9)
  - `update_write_cache_size()` method and callers removed
- [x] 10.5 Remove callers in `disk_cache.rs`:
  - `store_range_to_disk()` - line 1132
  - `store_range_to_disk_direct()` - line 1434
  - `delete_cache_entry()` - line 3291
  - `batch_delete_ranges()` - line 5417
- [x] 10.6 Remove callers in `cache_initialization_coordinator.rs`:
  - `initialize()` - line 1423 (size reconciliation during init)
- [x] 10.7 Remove `record_delta()` and `record_write_delta()` calls from delta buffer
  - N/A - these methods were never implemented (from archived buffered-logging spec)
- [x] 10.8 Update tests that use `update_size()` to use new API or remove them
  - Updated cache_size_tracker.rs unit tests
  - Updated cache_size_tracking_integration_test.rs
  - Updated cache_size_tracking_performance_test.rs
  - Updated cache_size_metrics_test.rs
  - Note: Some test files have config field issues that are part of Task 16.3

### Task 11: Remove Checkpoint Background Task
- [x] 11.1 Remove `checkpoint_task` field from `CacheSizeTracker`
- [x] 11.2 Remove `write_checkpoint()` method
- [x] 11.3 Remove `read_checkpoint()` method
- [x] 11.4 Remove `start_checkpoint_scheduler()` method
- [x] 11.5 Remove `checkpoint_scheduler()` method
- [x] 11.6 Remove eviction trigger from checkpoint (moved to consolidator)
- [x] 11.7 Remove checkpoint.json file handling
- [x] 11.8 Remove checkpoint.lock file handling
- [x] 11.9 Update `shutdown()` to not write checkpoint (consolidator handles final persist)

### Task 12: Simplify CacheSizeTracker
- [x] 12.1 Remove `current_size` and `write_cache_size` atomic fields
- [x] 12.2 Add `consolidator: Arc<JournalConsolidator>` reference
- [x] 12.3 Delegate `get_size()` to consolidator
- [x] 12.4 Delegate `get_write_cache_size()` to consolidator
- [x] 12.5 Keep validation scan logic unchanged
- [x] 12.6 Update `recover()` method to not read checkpoint (consolidator handles)
- [x] 12.7 Remove `Checkpoint` struct (replaced by SizeState in consolidator)

### Task 13: Update CacheManager
- [x] 13.1 Remove direct size tracker updates in cache write paths
- [x] 13.2 Update `get_cache_size()` to use consolidator
- [x] 13.3 Update `get_write_cache_size()` to use consolidator
- [x] 13.4 Wire consolidator to cache manager for eviction (call `set_cache_manager()`)
- [x] 13.5 Pass `max_cache_size` to ConsolidationConfig in `create_configured_disk_cache_manager()`
- [x] 13.6 Call `consolidator.initialize()` during cache manager initialization

## Testing

### Task 14: Integration Tests
- [x] 14.1 Test full consolidation cycle with size tracking
- [x] 14.2 Test eviction triggered by consolidator
- [x] 14.3 Test crash recovery (restart with existing size_state.json)
- [x] 14.4 Test validation scan corrects drift
- [x] 14.5 Test graceful shutdown persists size state

### Task 15: Property-Based Tests
- [x] 15.1 **Property 1**: Size consistency - tracked size equals sum of range files
- [x] 15.2 **Property 2**: Eviction triggering - eviction within 5s when over capacity
- [x] 15.3 **Property 3**: Multi-instance consistency - all instances see same size
- [x] 15.4 **Property 4**: Crash recovery - size recovers within validation threshold
- [x] 15.5 **Property 5**: No double counting - entries counted exactly once

## Cleanup

### Task 16: Code Cleanup
- [x] 16.1 Remove unused imports in `cache_size_tracker.rs`
- [x] 16.2 Remove dead code paths related to delta buffer and shared_storage checks
- [x] 16.3 Remove unused config fields (`size_tracking_flush_interval`, `size_tracking_buffer_size`)
- [x] 16.4 Clean up test files that test removed functionality
- [x] 16.5 Run `cargo clippy --release` and fix any new warnings
- [x] 16.6 Run `cargo fmt` to ensure consistent formatting

### Task 16b: Shutdown Handling
- [x] 16b.1 Add `shutdown()` method to JournalConsolidator
- [x] 16b.2 Run final consolidation cycle on shutdown
- [x] 16b.3 Persist final size state before exit
- [x] 16b.4 Update `src/shutdown.rs` to call consolidator shutdown
- [x] 16b.5 Remove size tracker shutdown from `src/shutdown.rs` (or simplify it)

### Task 17: Repository Cleanup
- [x] 17.1 Delete old delta files from `tmp/cache/size_tracking/delta-*.log` (local dev)
- [x] 17.2 Update `.gitignore` if any new generated files need ignoring
- [x] 17.3 Remove any obsolete test fixtures related to delta buffer

### Task 18: Documentation Updates
- [x] 18.1 Update `docs/CACHING.md` with new size tracking architecture
- [x] 18.2 Update `docs/CONFIGURATION.md` with new/removed config options (including shared_storage.enabled removal)
- [x] 18.3 Update `docs/ARCHITECTURE.md` with component changes
- [x] 18.4 Add migration notes to `CHANGELOG.md`
- [x] 18.5 Update `config/config.example.yaml` with new consolidation_interval setting
- [x] 18.6 Update `.kiro/steering/structure.md` to reflect new file layout
