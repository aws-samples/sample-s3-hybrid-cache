# Journal-Based Size Tracking - Design

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Proxy Instance                               │
│                                                                      │
│  ┌──────────────┐     ┌──────────────────────────────────────────┐  │
│  │ Cache Write  │────▶│           JournalManager                 │  │
│  │ (Add range)  │     │  - Appends entry to {instance}.journal   │  │
│  └──────────────┘     │  - Entry contains compressed_size        │  │
│                       └──────────────────────────────────────────┘  │
│                                        │                             │
│                                        ▼                             │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                   JournalConsolidator                         │   │
│  │  (runs every 5s)                                              │   │
│  │                                                               │   │
│  │  1. Discover pending cache keys from all instance journals    │   │
│  │  2. For each key: consolidate entries → .meta file            │   │
│  │  3. Calculate size delta from Add/Remove operations           │   │
│  │  4. Update SizeState (total_size, write_cache_size)           │   │
│  │  5. Persist to size_state.json                                │   │
│  │  6. If over capacity → trigger eviction                       │   │
│  │  7. Clean up processed journal entries                        │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                        │                             │
│                    ┌───────────────────┼───────────────────┐        │
│                    ▼                   ▼                   ▼        │
│            ┌─────────────┐    ┌──────────────┐    ┌─────────────┐   │
│            │  Dashboard  │    │   Metrics    │    │  Eviction   │   │
│            │  (port 8081)│    │  (port 9090) │    │  (if needed)│   │
│            └─────────────┘    └──────────────┘    └─────────────┘   │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

Shared Storage (NFS/EFS):
┌─────────────────────────────────────────────────────────────────────┐
│  metadata/_journals/                                                 │
│    ├── instance1.journal     (per-instance journal entries)         │
│    ├── instance2.journal                                            │
│    └── ...                                                          │
│                                                                      │
│  size_tracking/                                                      │
│    ├── size_state.json       (current size, updated every 5s)       │
│    └── validation.json       (last validation results)              │
│                                                                      │
│  metadata/{bucket}/{hash}/   (.meta files)                          │
│  ranges/{bucket}/{hash}/     (.bin files)                           │
└─────────────────────────────────────────────────────────────────────┘
```

## Background Task Location

The consolidation background task currently lives in `main.rs` (lines 256-310). This task will be modified to:
1. Call `consolidator.run_consolidation_cycle()` instead of the current manual loop
2. The `run_consolidation_cycle()` method handles size tracking and eviction internally

This keeps the task spawning in main.rs but moves all logic into JournalConsolidator.

## Data Structures

### SizeState (new)

Replaces the checkpoint.json with a simpler structure focused on size tracking.

```rust
/// Persistent size state - source of truth for cache size
/// File: size_tracking/size_state.json
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SizeState {
    /// Total cache size in bytes (read cache + write cache)
    pub total_size: u64,
    
    /// Write cache size in bytes (subset of total_size)
    /// Tracked separately for dashboard display
    /// Write cache = mpus_in_progress/ directory contents
    pub write_cache_size: u64,
    
    /// Timestamp of last consolidation
    #[serde(with = "systemtime_serde")]
    pub last_consolidation: SystemTime,
    
    /// Number of consolidation cycles completed
    pub consolidation_count: u64,
    
    /// Instance ID that last updated this state
    pub last_updated_by: String,
}
```

Note: Write cache size tracks cached PUT operations (write-through caching). This is a subset of total_size and has its own capacity limit (percentage of total cache) to prevent writes from flooding the read cache.

### ConsolidationConfig (modified)

```rust
#[derive(Debug, Clone)]
pub struct ConsolidationConfig {
    /// How often to run consolidation (default: 5 seconds)
    pub interval: Duration,
    
    /// Size threshold in bytes to trigger immediate consolidation
    pub size_threshold: u64,
    
    /// Entry count threshold to trigger immediate consolidation  
    pub entry_count_threshold: usize,
    
    /// Maximum number of cache keys to process per consolidation run
    pub max_keys_per_run: usize,
    
    /// Maximum cache size in bytes (for eviction triggering)
    /// Passed from CacheConfig.max_cache_size during initialization
    pub max_cache_size: u64,
}

impl Default for ConsolidationConfig {
    fn default() -> Self {
        Self {
            interval: Duration::from_secs(5),  // Changed from 30s
            size_threshold: 1024 * 1024,
            entry_count_threshold: 100,
            max_keys_per_run: 50,
            max_cache_size: 0,  // Must be set from CacheConfig during initialization
        }
    }
}
```

Note: `max_cache_size` is passed from `CacheConfig.max_cache_size` when creating the consolidator in `CacheManager::create_configured_disk_cache_manager()`.

### ConsolidationCycleResult (new)

```rust
/// Result of a complete consolidation cycle
#[derive(Debug, Clone)]
pub struct ConsolidationCycleResult {
    /// Number of cache keys processed
    pub keys_processed: usize,
    
    /// Total journal entries consolidated
    pub entries_consolidated: usize,
    
    /// Net size change from this cycle (can be negative)
    pub size_delta: i64,
    
    /// Duration of the consolidation cycle
    pub cycle_duration: Duration,
    
    /// Whether eviction was triggered
    pub eviction_triggered: bool,
    
    /// Bytes freed by eviction (0 if not triggered)
    pub bytes_evicted: u64,
    
    /// Current total cache size after this cycle
    pub current_size: u64,
}
```

## Component Changes

### JournalConsolidator (modified)

Add size tracking responsibility:

```rust
pub struct JournalConsolidator {
    cache_dir: PathBuf,
    journal_manager: Arc<JournalManager>,
    lock_manager: Arc<MetadataLockManager>,
    config: ConsolidationConfig,
    
    // NEW: Size state (in-memory, persisted to disk)
    size_state: Arc<RwLock<SizeState>>,
    
    // NEW: Path to size state file
    size_state_path: PathBuf,
    
    // NEW: Reference to cache manager for eviction
    cache_manager: Mutex<Option<Weak<CacheManager>>>,
}
```

New methods:

```rust
impl JournalConsolidator {
    /// Run a complete consolidation cycle
    /// Called every 5 seconds by background task
    pub async fn run_consolidation_cycle(&self) -> Result<ConsolidationCycleResult>;
    
    /// Get current cache size (non-blocking read)
    pub fn get_current_size(&self) -> u64;
    
    /// Get current write cache size (non-blocking read)
    pub fn get_write_cache_size(&self) -> u64;
    
    /// Get size state for metrics/dashboard
    pub async fn get_size_state(&self) -> SizeState;
    
    /// Persist size state to disk
    async fn persist_size_state(&self) -> Result<()>;
    
    /// Load size state from disk (called on startup)
    async fn load_size_state(&self) -> Result<SizeState>;
    
    /// Check if eviction needed and trigger it
    async fn maybe_trigger_eviction(&self) -> Result<EvictionResult>;
    
    /// Set cache manager reference (called during initialization)
    pub fn set_cache_manager(&self, cache_manager: Weak<CacheManager>);
}
```

### CacheSizeTracker (simplified)

Remove delta buffer, keep validation:

```rust
pub struct CacheSizeTracker {
    config: CacheSizeConfig,
    cache_dir: PathBuf,
    actively_remove_cached_data: bool,
    
    // REMOVED: current_size, write_cache_size (moved to consolidator)
    // REMOVED: delta_buffer (no longer needed)
    // REMOVED: checkpoint_task (consolidator handles)
    // REMOVED: delta_flush_task (no longer needed)
    
    // KEEP: Validation-related fields
    validation_path: PathBuf,
    validation_lock_path: PathBuf,
    validation_task: Mutex<Option<JoinHandle<()>>>,
    
    // KEEP: Reference to cache manager for expiration during validation
    cache_manager: Mutex<Option<Weak<CacheManager>>>,
    
    // NEW: Reference to consolidator for size updates
    consolidator: Arc<JournalConsolidator>,
}
```

Simplified interface:

```rust
impl CacheSizeTracker {
    /// Get current size (delegates to consolidator)
    pub fn get_size(&self) -> u64 {
        self.consolidator.get_current_size()
    }
    
    /// Get write cache size (delegates to consolidator)
    pub fn get_write_cache_size(&self) -> u64 {
        self.consolidator.get_write_cache_size()
    }
    
    // REMOVED: update_size() - journal handles this
    // REMOVED: update_write_cache_size() - journal handles this
    // REMOVED: flush_delta_buffer() - no longer needed
    
    // KEEP: Validation methods
    pub async fn run_validation_scan(&self) -> Result<ValidationMetadata>;
    pub fn start_validation_scheduler(&self);
}
```

### CacheManager (modified)

Remove direct size tracking calls:

```rust
impl CacheManager {
    // REMOVED: Calls to size_tracker.update_size() in cache write paths
    // Journal entries already contain size info
    
    // MODIFIED: Get size from consolidator instead of size_tracker
    pub fn get_cache_size(&self) -> u64 {
        if let Some(consolidator) = self.journal_consolidator.try_read().ok()?.as_ref() {
            consolidator.get_current_size()
        } else {
            0
        }
    }
    
    // MODIFIED: enforce_disk_cache_limits no longer called from checkpoint
    // Consolidator triggers it directly
}
```

### Dashboard (modified)

Update size source and add write cache display:

```rust
// In dashboard stats endpoint (get_cache_stats)
let cache_size = if let Some(consolidator) = cache_manager.get_consolidator() {
    let state = consolidator.get_size_state().await;
    
    // Total disk cache and write cache sizes
    let total_cache_size = state.total_size;
    let write_cache_size = state.write_cache_size;
    
    // ... populate CacheStatsResponse
} else {
    // fallback
};

// Add write_cache field to CacheStatsResponse
pub struct CacheStatsResponse {
    pub timestamp: SystemTime,
    pub hostname: String,
    pub version: String,
    pub ram_cache: CacheStats,
    pub metadata_cache: MetadataCacheStats,
    pub disk_cache: CacheStats,        // Total disk cache (read + write)
    pub write_cache: WriteCacheStats,  // NEW: Write cache (PUT operations)
    pub overall: OverallStats,
}

/// Write cache statistics (cached PUT operations)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WriteCacheStats {
    pub size_bytes: u64,
    pub size_human: String,
    pub max_size_bytes: u64,    // Write cache limit (% of total cache)
    pub max_size_human: String,
    pub utilization_percent: f32,
}
```

Note: Write cache is for caching PUT operations (write-through caching). It has a separate capacity limit (configurable percentage of total cache, default 10%) to prevent writes from flooding the read cache. The dashboard should show:
- `disk_cache` - Total disk cache size and utilization
- `write_cache` - Write cache size, limit, and utilization (subset of disk_cache)

### Metrics (modified)

Update metric source:

```rust
// In metrics collection
if let Some(consolidator) = self.consolidator.as_ref() {
    let state = consolidator.get_size_state().await;
    
    self.record_gauge("cache_size_bytes", state.total_size as f64);
    self.record_gauge("cache_write_size_bytes", state.write_cache_size as f64);
    self.record_gauge("consolidation_count", state.consolidation_count as f64);
}
```

## Consolidation Cycle Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    run_consolidation_cycle()                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 1. Discover pending cache keys from all instance journals        │
│    - Read all *.journal files in metadata/_journals/             │
│    - Extract unique cache_key values                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. For each cache key (up to max_keys_per_run):                  │
│    a. Acquire metadata lock                                      │
│    b. Read all journal entries for this key                      │
│    c. Validate entries (check range files exist)                 │
│    d. Calculate size delta:                                      │
│       - Add operation: +compressed_size                          │
│       - Remove operation: -compressed_size                       │
│    e. Apply entries to .meta file                                │
│    f. Track consolidated entries for cleanup                     │
│    g. Release lock                                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. Update size state atomically                                  │
│    - total_size += size_delta                                    │
│    - write_cache_size += write_cache_delta                       │
│    - last_consolidation = now()                                  │
│    - consolidation_count += 1                                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. Persist size state to size_state.json                         │
│    - Atomic write (temp file + rename)                           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 5. Check if eviction needed (only if size changed)                  │
│    - If total_size > max_cache_size:                             │
│      - Acquire eviction lock (if shared_storage enabled)         │
│      - Call cache_manager.enforce_disk_cache_limits()            │
│      - Update size_state with bytes freed                        │
│      - Release eviction lock                                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 6. Clean up consolidated entries from journals                   │
│    - Remove processed entries from instance journal files        │
│    - Delete empty journal files                                  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 7. Return ConsolidationCycleResult                               │
└─────────────────────────────────────────────────────────────────┘
```

## Size Delta Calculation

Size delta is calculated from journal entries during consolidation. The `RangeSpec` struct already contains `compressed_size` which is the actual size of the `.bin` file on disk.

```rust
fn calculate_size_delta(entries: &[JournalEntry]) -> (i64, i64) {
    let mut size_delta: i64 = 0;
    let mut write_cache_delta: i64 = 0;
    
    for entry in entries {
        // Use compressed_size from RangeSpec - this is the actual .bin file size
        let entry_size = entry.range_spec.compressed_size as i64;
        
        // Write cache entries are marked with is_write_cached in object_metadata
        // Check if this is a write-cached entry (PUT operation)
        let is_write_cache = entry.object_metadata
            .as_ref()
            .map(|m| m.is_write_cached)
            .unwrap_or(false);
        
        match entry.operation {
            JournalOperation::Add => {
                size_delta += entry_size;
                if is_write_cache {
                    write_cache_delta += entry_size;
                }
            }
            JournalOperation::Remove => {
                size_delta -= entry_size;
                if is_write_cache {
                    write_cache_delta -= entry_size;
                }
            }
            JournalOperation::Update => {
                // Update doesn't change size (same range, possibly different content)
                // If size changes, it should be Remove + Add
            }
            JournalOperation::TtlRefresh | JournalOperation::AccessUpdate => {
                // No size change
            }
        }
    }
    
    (size_delta, write_cache_delta)
}
```

Note: Write cache entries are identified by the `is_write_cached` flag in `ObjectMetadata`, which is set when a PUT operation is cached.

## File Format: size_state.json

```json
{
  "total_size": 5368709120,
  "write_cache_size": 268435456,
  "last_consolidation": "2026-01-26T15:30:00.000Z",
  "consolidation_count": 12345,
  "last_updated_by": "proxy1.example.com:12345"
}
```

## Drift Prevention

The journal-based approach reduces drift compared to the delta buffer system:

### Why Delta Buffer Drifts

1. **Lost deltas on crash** - RAM buffer not flushed
2. **Race conditions** - checkpoint reads while instance writes
3. **Eviction not atomic** - files deleted but size not updated
4. **Two sources of truth** - delta files vs actual disk state

### How Journal-Based Tracking Prevents Drift

1. **Single source of truth** - size derived from consolidated journal entries
2. **Validation on consolidation** - only count entries where range file exists
3. **Eviction updates size atomically** - consolidator owns both size state and eviction trigger
4. **No RAM buffer to lose** - journal entries persisted immediately

### Remaining Drift Sources

1. **Orphaned range files** - range file exists but never journaled (crash during write)
   - Handled by: validation scan counts actual files, corrects size

2. **Multi-instance eviction** - another instance evicts files, this instance's size state is stale
   - Handled by: size state is shared file, all instances read same value
   - Eviction holds distributed lock, updates shared size state

### Eviction and Size Tracking

**Current behavior (to be changed)**: `batch_evict_ranges()` calls `size_tracker.update_size()` to decrement size after deleting files. This creates a race condition where the delta buffer might not be flushed before crash.

**New behavior**: 
1. `batch_evict_ranges()` does NOT update size tracker (remove the `size_tracker.update_size()` call)
2. Eviction is triggered by consolidator at end of consolidation cycle
3. Consolidator updates `SizeState.total_size` immediately after eviction returns
4. Size state is persisted atomically

This ensures size tracking is always consistent with the consolidator's view of the cache.

### Eviction Size Update

Eviction only runs at the end of a consolidation cycle, triggered by the consolidator. The consolidator updates size state immediately after eviction:

```rust
async fn maybe_trigger_eviction(&self) -> Result<EvictionResult> {
    let current_size = self.size_state.read().await.total_size;
    
    if current_size <= self.config.max_cache_size {
        return Ok(EvictionResult::not_needed());
    }
    
    // Eviction returns bytes actually freed
    // NOTE: Current code has a bug - returns range count instead of bytes
    // This needs to be fixed as part of Task 5
    let bytes_freed = cache_manager.enforce_disk_cache_limits().await?;
    
    // Update size state immediately
    {
        let mut state = self.size_state.write().await;
        state.total_size = state.total_size.saturating_sub(bytes_freed);
    }
    
    // Persist updated state
    self.persist_size_state().await?;
    
    Ok(EvictionResult { triggered: true, bytes_freed })
}
```

**Bug Fix Required**: The current `perform_eviction_with_lock()` method returns `total_ranges_evicted` (count) instead of `total_bytes_freed`. This needs to be fixed to return actual bytes freed for accurate size tracking.



Since this is a breaking change requiring fresh cache directories:

1. Stop all proxy instances
2. Clear cache directory (`rm -rf /path/to/cache/*`)
3. Deploy new version
4. Start proxy instances

Old delta files and checkpoint.json are not migrated - the system starts fresh with `size_state.json`.

## Testing Strategy

### Unit Tests

- `SizeState` serialization/deserialization
- Size delta calculation from journal entries
- Eviction triggering logic

### Integration Tests

- Consolidation cycle with size tracking
- Multi-instance size coordination
- Dashboard/metrics show correct size
- Eviction triggered when over capacity

### Property-Based Tests

- Size delta calculation is commutative (order doesn't matter for final size)
- Size never goes negative
- Consolidation is idempotent (running twice doesn't double-count)

## Rollback Plan

If issues are discovered, revert to previous version and clear cache directory. No in-place rollback supported.

## Startup Initialization

On proxy startup, the consolidator must initialize size state:

```rust
impl JournalConsolidator {
    pub async fn initialize(&self) -> Result<()> {
        // 1. Try to load existing size_state.json
        match self.load_size_state().await {
            Ok(state) => {
                info!(
                    "Loaded size state: total_size={}, last_consolidation={:?}",
                    state.total_size, state.last_consolidation
                );
                *self.size_state.write().await = state;
            }
            Err(_) => {
                // 2. No size state file - this is a fresh install or first run after migration
                // Schedule immediate validation scan to calculate actual size
                info!("No size state found, will calculate from filesystem on first validation");
                // Size starts at 0, validation will correct it
            }
        }
        Ok(())
    }
}
```

The initialization happens in `CacheManager::create_configured_disk_cache_manager()` after creating the consolidator.

## Background Task Modification

The existing background task in `main.rs` (lines 256-310) will be simplified:

```rust
// Current code (to be replaced):
let _journal_consolidation_task = tokio::spawn(async move {
    let mut interval = tokio::time::interval(consolidation_interval);
    loop {
        interval.tick().await;
        // ... manual consolidation loop ...
    }
});

// New code:
let _journal_consolidation_task = tokio::spawn(async move {
    let mut interval = tokio::time::interval(consolidation_interval);
    loop {
        interval.tick().await;
        match consolidator.run_consolidation_cycle().await {
            Ok(result) => {
                if result.entries_consolidated > 0 || result.eviction_triggered {
                    info!(
                        "Consolidation cycle: entries={}, size_delta={:+}, evicted={}, current_size={}",
                        result.entries_consolidated,
                        result.size_delta,
                        result.bytes_evicted,
                        result.current_size
                    );
                }
            }
            Err(e) => {
                warn!("Consolidation cycle failed: {}", e);
            }
        }
    }
});
```

## Correctness Properties

### Property 1: Size Consistency

For any sequence of Add/Remove operations, the tracked size equals the sum of all range file sizes on disk.

**Validates:** Requirements 1.1, 1.2, 4.1

### Property 2: Eviction Triggering

If total_size > max_cache_size after consolidation, eviction is triggered within one consolidation cycle (5s).

**Validates:** Requirements 2.1, 2.2

### Property 3: Multi-Instance Consistency

All instances reading size_state.json see the same total_size value (eventual consistency within 5s).

**Validates:** Requirements 7.4, 7.5

### Property 4: Crash Recovery

After a crash and restart, size_state recovers to within validation threshold of actual disk usage.

**Validates:** Requirements 1.4, 4.4

### Property 5: No Double Counting

A journal entry is counted toward size exactly once, even if consolidation is interrupted and retried.

**Validates:** Requirements 1.1, 5.1
