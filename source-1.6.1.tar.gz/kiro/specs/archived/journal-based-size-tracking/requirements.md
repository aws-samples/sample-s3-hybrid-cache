# Journal-Based Size Tracking

## Overview

Consolidate cache size tracking into the journal consolidation system, eliminating the separate delta buffer mechanism. The journal consolidator becomes the single source of truth for cache size, triggering eviction when capacity is exceeded.

---

## Problem Statement

The current architecture has two parallel systems for tracking cache state:
1. **Journal system** - tracks metadata changes (range Add/Remove/Update)
2. **Size tracking system** - tracks cache size via separate delta files

This causes **drift** - the tracked size diverges from actual disk usage:
- Delta buffer lost on crash (RAM not flushed)
- Race conditions between checkpoint reads and instance writes
- Eviction deletes files but size not updated atomically
- Two sources of truth that can disagree

Both systems also duplicate effort:
- Use per-instance files on shared storage
- Require periodic consolidation/checkpointing
- Run on similar intervals (5s flush, 30s consolidation)

## Proposed Solution

Unify size tracking into the journal consolidator:
- Journal entries already contain size information (`compressed_size` in `RangeSpec`)
- Consolidator calculates size delta from processed entries
- Consolidator triggers eviction when cache exceeds capacity
- Increase consolidation frequency to 5s for near-realtime tracking

---

## User Stories

### 1. Cache Size Tracking

**As a** cache system operator  
**I want** cache size to be tracked through the journal consolidation system  
**So that** there is a single source of truth for cache state

#### Acceptance Criteria

1.1 Journal consolidator calculates size delta from Add/Remove operations during consolidation  
1.2 Size state is persisted to `size_tracking/size_state.json` after each consolidation cycle  
1.3 Size state includes total cache size and write cache size (separately tracked)  
1.4 Size state survives proxy restart (recovered from persisted file)  
1.5 Consolidation runs every 5 seconds (configurable)  

### 2. Eviction Triggering

**As a** cache system  
**I want** eviction to be triggered by the consolidator when cache exceeds capacity  
**So that** cache size is managed without a separate monitoring system

#### Acceptance Criteria

2.1 After each consolidation cycle, consolidator checks if total size exceeds max capacity  
2.2 If over capacity, consolidator triggers eviction via CacheManager  
2.3 Eviction uses distributed locking (always, not conditional)  
2.4 Size state is updated immediately after eviction (not waiting for next consolidation)  
2.5 Eviction bytes_freed is subtracted from size state atomically  

### 3. Dashboard and Metrics Integration

**As a** system administrator  
**I want** the dashboard and metrics to reflect current cache size  
**So that** I can monitor cache utilization

#### Acceptance Criteria

3.1 Dashboard displays current cache size from consolidator's size state  
3.2 Dashboard displays write cache size separately (cached PUT operations, next to total cache)  
3.3 Metrics endpoint exposes cache size metrics  
3.4 Size values update within 5 seconds of actual changes (consolidation interval)  
3.5 Last consolidation timestamp is exposed in metrics  
3.6 Dashboard API response includes `write_cache` field with size, max_size, and utilization  

### 4. Validation and Recovery

**As a** cache system  
**I want** periodic validation to correct any size tracking drift  
**So that** the system self-heals from inconsistencies

#### Acceptance Criteria

4.1 Daily validation scan calculates actual cache size from filesystem  
4.2 Validation corrects size state if drift exceeds threshold (e.g., 1%)  
4.3 Validation logs drift amount for monitoring  
4.4 On startup with missing size state, system schedules immediate validation  
4.5 Validation runs at configurable time of day (default: midnight)  

### 5. Component Removal

**As a** code maintainer  
**I want** the separate delta buffer system removed  
**So that** the codebase is simpler and has less duplication

#### Acceptance Criteria

5.1 `SizeDeltaBuffer` struct is removed from `cache_size_tracker.rs`  
5.2 Per-instance delta files (`delta-{instance_id}.log`) are no longer created  
5.3 `update_size()` method on CacheSizeTracker is removed (journal handles it)  
5.4 Checkpoint background task is removed (consolidator handles persistence)  
5.5 Existing delta files are cleaned up during migration  

### 6. Graceful Shutdown

**As a** cache system  
**I want** size state to be persisted on shutdown  
**So that** no tracking data is lost

#### Acceptance Criteria

6.1 On shutdown signal, consolidator runs final consolidation cycle  
6.2 Size state is persisted before process exits  
6.3 Any pending journal entries are processed before shutdown completes  

### 7. Multi-Instance Coordination

**As a** multi-instance deployment  
**I want** size tracking to work correctly across instances  
**So that** all instances see consistent cache size

#### Acceptance Criteria

7.1 Each instance writes to its own journal file (existing behavior)  
7.2 Consolidator reads from all instance journal files (existing behavior)  
7.3 Only one instance performs consolidation at a time (via locking)  
7.4 Size state file is shared across instances  
7.5 Instances that don't consolidate read size from shared state file  

### 8. Remove Non-Shared Storage Code Path

**As a** code maintainer  
**I want** the non-shared storage code path removed  
**So that** there is only one code path to maintain and test

#### Acceptance Criteria

8.1 Remove `shared_storage.enabled` config option (always enabled)  
8.2 Remove conditional logic that checks `shared_storage.enabled`  
8.3 Journal-based metadata writes always used (no direct writes)  
8.4 Distributed eviction locking always used  
8.5 Remove `HybridMetadataWriter` mode switching logic  
8.6 Update config documentation to remove shared_storage.enabled  

---

## Non-Functional Requirements

### Performance

- Consolidation cycle completes in < 1 second for typical workloads (< 1000 pending entries)
- Size state read is non-blocking (for dashboard/metrics)
- No additional disk I/O beyond existing journal operations

### Reliability

- Size tracking survives proxy crashes (journal entries preserved)
- Validation scan corrects any accumulated drift
- No data loss during migration from old system

### Compatibility

- Existing journal entry format unchanged
- Dashboard API unchanged (same JSON structure)
- Metrics endpoint unchanged (same metric names)

---

## Out of Scope

- Changing journal entry format (use existing `compressed_size` field)
- Real-time capacity checking for PUT requests (accept all, let eviction handle)
- Changes to eviction algorithm (LRU/TinyLFU unchanged)
- Changes to validation scan logic (reuse existing)
