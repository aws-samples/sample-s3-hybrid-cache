# Design: Cache Hit Performance (v1.1.39)

## Overview

Five changes to improve cache-hit latency and resource usage:

**A. Metadata Pass-Through** — Load metadata once per request via `get_metadata_cached()` and pass it through the call chain. Eliminates 3-4 redundant NFS reads per cache hit.

**B. Large File Full-Object Check Skip** — Skip the full-object cache check when `content_length` exceeds a threshold. Avoids scanning hundreds of cached ranges for large files that are never cached as a single full-object range.

**C. Connection Pool Tuning** — Increase `max_idle_per_host` default from 1 to 10.

**D. Consolidation Cycle Timeout** — Add a configurable timeout for the per-key processing phase of consolidation cycles.

**E. Streaming Range Data from Disk** — Stream cached range data in chunks instead of loading entire ranges into memory.

## Architecture

No new modules. All changes are within existing modules:

- `src/http_proxy.rs` — Pass metadata through `handle_range_request`, `serve_range_from_cache`, `get_cached_range_data`
- `src/cache.rs` — Add metadata parameter to `has_cached_ranges()`, `load_range_data_with_cache()`
- `src/range_handler.rs` — Add metadata parameter to `find_cached_ranges()`
- `src/disk_cache.rs` — Add metadata parameter to `find_cached_ranges()`, add `stream_range_data()` method
- `src/config.rs` — Add `full_object_check_threshold`, `consolidation_cycle_timeout` fields
- `src/journal_consolidator.rs` — Add timeout to `run_consolidation_cycle()`
- `config/config.example.yaml` — Document new config fields, update `max_idle_per_host` default

## Components and Interfaces

### A. Metadata Pass-Through

The key insight: `handle_range_request` already calls `get_metadata_cached()` in step 1 to get `content_length` for range parsing. The returned `NewCacheMetadata` contains everything needed by subsequent steps. We pass it through instead of re-reading from NFS.

#### Modified signatures

```rust
// cache.rs - CacheManager
pub async fn has_cached_ranges(
    &self,
    cache_key: &str,
    preloaded_metadata: Option<&NewCacheMetadata>,  // NEW
) -> Result<Option<(bool, u64)>>

// range_handler.rs - RangeHandler
pub async fn find_cached_ranges(
    &self,
    cache_key: &str,
    requested_range: &RangeSpec,
    current_etag: Option<&str>,
    preloaded_metadata: Option<&NewCacheMetadata>,  // NEW
) -> Result<RangeOverlap>

// disk_cache.rs - DiskCacheManager
pub async fn find_cached_ranges(
    &self,
    cache_key: &str,
    requested_start: u64,
    requested_end: u64,
    preloaded_metadata: Option<&NewCacheMetadata>,  // NEW
) -> Result<Vec<RangeSpec>>

// http_proxy.rs - HttpProxy
async fn serve_range_from_cache(
    method: Method,
    range_spec: &RangeSpec,
    overlap: &RangeOverlap,
    cache_key: &str,
    cache_manager: Arc<CacheManager>,
    range_handler: Arc<RangeHandler>,
    s3_client: Arc<S3Client>,
    host: &str,
    uri: &str,
    headers: &HeaderMap,
    config: Arc<Config>,
    preloaded_metadata: Option<&NewCacheMetadata>,  // NEW
) -> Result<Response<BoxBody<Bytes, hyper::Error>>, Infallible>
```

#### Flow after change

```
handle_range_request():
  1. metadata = get_metadata_cached()           → RAM cache (microseconds on hit)
  2. has_cached_ranges(metadata)                → uses preloaded metadata, no NFS
  3. find_cached_ranges(full, metadata)         → uses preloaded metadata, no NFS
  4. find_cached_ranges(range, metadata)        → uses preloaded metadata, no NFS
  5. serve_range_from_cache(metadata)           → uses preloaded metadata for headers, no NFS
  6. load_range_data_with_cache()               → RAM cache or 1 NFS read for range data
```

Total NFS reads per cache hit: 0-1 (down from 4-5).

#### Backward compatibility

All callers outside `handle_range_request` pass `None` for `preloaded_metadata`. Behavior is identical to current code — the method falls back to its existing NFS read path. Tests that call these methods directly continue to work unchanged.

### B. Large File Full-Object Check Skip

In `handle_range_request`, after loading metadata:

```rust
let skip_full_object_check = metadata
    .as_ref()
    .map(|m| m.object_metadata.content_length > config.cache.full_object_check_threshold)
    .unwrap_or(false);

if !skip_full_object_check {
    // existing full-object check logic
    match cache_manager.has_cached_ranges(&cache_key, metadata.as_ref()).await { ... }
}
```

New config field in `CacheConfig`:

```rust
#[serde(default = "default_full_object_check_threshold")]
pub full_object_check_threshold: u64,  // default: 67_108_864 (64 MiB)
```

### C. Connection Pool Tuning

Change default in `ConnectionPoolConfig`:

```rust
fn default() -> Self {
    Self {
        max_idle_per_host: 10,  // was 1
        ...
    }
}
```

Update `config.example.yaml` to document the change.

### D. Consolidation Cycle Timeout

Add timeout around the per-key processing phase in `run_consolidation_cycle()`:

```rust
let key_processing_timeout = self.config.consolidation_cycle_timeout;

let key_results = tokio::time::timeout(
    key_processing_timeout,
    stream::iter(key_futures)
        .buffer_unordered(KEY_CONCURRENCY_LIMIT)
        .collect::<Vec<_>>()
).await;

match key_results {
    Ok(results) => { /* process normally */ }
    Err(_) => {
        warn!(
            "Consolidation cycle timeout after {:?}, {} keys unprocessed",
            key_processing_timeout, remaining_keys
        );
        // Continue to delta collection and eviction check
    }
}
```

New config field in `SharedStorageConfig`:

```rust
#[serde(
    default = "default_consolidation_cycle_timeout",
    deserialize_with = "duration_serde::deserialize"
)]
pub consolidation_cycle_timeout: Duration,  // default: 30s
```

Size tracking (accumulator delta collection) runs before per-key processing and is unaffected by the timeout.

### E. Streaming Range Data from Disk

New method on `DiskCacheManager`:

```rust
pub async fn stream_range_data(
    &self,
    cache_key: &str,
    range_spec: &RangeSpec,
    chunk_size: usize,  // default: 65536 (64 KiB)
) -> Result<impl Stream<Item = Result<Bytes>>>
```

Modified `serve_range_from_cache`:
- For RAM cache hits: serve full data from memory (no change)
- For disk ranges below streaming threshold (default 1 MiB): load fully into memory (no change)
- For disk ranges at or above streaming threshold: use `stream_range_data()` and return a streaming body

LZ4 decompression constraint: LZ4 frame format requires the full compressed frame to decompress. Range data files are single LZ4 frames. For compressed ranges, the full file must be read and decompressed before streaming the decompressed output in chunks. This means streaming only saves memory for uncompressed ranges or when compression is disabled. For compressed ranges, the benefit is reduced to streaming the decompressed output (avoiding the final `Bytes::from()` copy).

New config field in `CacheConfig`:

```rust
#[serde(default = "default_disk_streaming_threshold")]
pub disk_streaming_threshold: u64,  // default: 1_048_576 (1 MiB)
```

Response headers (`Content-Length`, `Content-Range`) are set from metadata before streaming begins, not from data length.

## Testing Strategy

- Existing integration tests pass with `None` for preloaded_metadata (backward compatibility)
- Unit tests for `has_cached_ranges` and `find_cached_ranges` with preloaded metadata
- Unit test for full-object check skip based on content_length threshold
- Unit test for consolidation cycle timeout behavior
- Integration test for streaming range data from disk (verify correct bytes delivered)
- Config parsing tests for new fields with defaults
