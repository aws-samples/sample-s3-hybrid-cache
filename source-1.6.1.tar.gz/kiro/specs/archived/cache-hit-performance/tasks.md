# Implementation Plan: Cache Hit Performance (v1.1.39)

## Overview

Five areas ordered by dependency: config changes first (needed by later tasks), then metadata pass-through (highest impact), full-object check skip, connection pool tuning, consolidation timeout, and finally streaming range data (most complex, lowest priority). Rust is the implementation language.

## Tasks

- [x] 1. Config changes
  - [x] 1.1 Add `full_object_check_threshold: u64` to `CacheConfig` in `src/config.rs` with `#[serde(default = "default_full_object_check_threshold")]`. Default: 67_108_864 (64 MiB). Add default function.
    - _Requirements: 2.2_
  - [x] 1.2 Add `consolidation_cycle_timeout: Duration` to `SharedStorageConfig` in `src/config.rs` with `#[serde(default = "default_consolidation_cycle_timeout", deserialize_with = "duration_serde::deserialize")]`. Default: 30 seconds. Add default function.
    - _Requirements: 4.4_
  - [x] 1.3 Add `disk_streaming_threshold: u64` to `CacheConfig` in `src/config.rs` with `#[serde(default = "default_disk_streaming_threshold")]`. Default: 1_048_576 (1 MiB). Add default function.
    - _Requirements: 5.5_
  - [x] 1.4 Update `config/config.example.yaml`: add `full_object_check_threshold`, `consolidation_cycle_timeout`, `disk_streaming_threshold` with comments. Change `max_idle_per_host` default from 1 to 10 with comment explaining trade-off.
    - _Requirements: 2.2, 3.2, 4.4, 5.5_
  - [x] 1.5 Verify config parsing: `cargo test --release -p s3-proxy config` (or equivalent config tests) passes.

- [x] 2. Metadata pass-through — modified signatures
  - [x] 2.1 Add `preloaded_metadata: Option<&NewCacheMetadata>` parameter to `DiskCacheManager::find_cached_ranges()` in `src/disk_cache.rs`. When `Some`, use the provided metadata instead of calling `self.get_metadata()`. When `None`, fall back to existing behavior.
    - _Requirements: 1.3_
  - [x] 2.2 Update all callers of `DiskCacheManager::find_cached_ranges()` in `src/disk_cache.rs` (internal callers) and `src/cache.rs` to pass `None`.
    - _Requirements: 1.5_
  - [x] 2.3 Add `preloaded_metadata: Option<&NewCacheMetadata>` parameter to `RangeHandler::find_cached_ranges()` in `src/range_handler.rs`. When `Some`, pass it through to `disk_cache.find_cached_ranges()` instead of calling `disk_cache.get_metadata()`. When `None`, fall back to existing behavior.
    - _Requirements: 1.3_
  - [x] 2.4 Update all callers of `RangeHandler::find_cached_ranges()` in `src/http_proxy.rs` and test files to pass `None` initially.
    - _Requirements: 1.5_
  - [x] 2.5 Add `preloaded_metadata: Option<&NewCacheMetadata>` parameter to `CacheManager::has_cached_ranges()` in `src/cache.rs`. When `Some`, use it instead of calling `get_metadata_from_disk()`. When `None`, fall back to existing behavior.
    - _Requirements: 1.2_
  - [x] 2.6 Update all callers of `CacheManager::has_cached_ranges()` in `src/http_proxy.rs` and test files to pass `None` initially.
    - _Requirements: 1.5_

- [x] 3. Checkpoint — verify compilation and all tests pass
  - Run `cargo build --release` and `cargo test --release`. All existing tests must pass with `None` parameters (backward compatibility).

- [x] 4. Metadata pass-through — wire up in handle_range_request
  - [x] 4.1 In `handle_range_request()` in `src/http_proxy.rs`: after the existing `get_metadata_cached()` call (which loads metadata for content_length), capture the result as `Option<NewCacheMetadata>`. Pass it to `has_cached_ranges()`, both `find_cached_ranges()` calls, and `serve_range_from_cache()`.
    - _Requirements: 1.1_
  - [x] 4.2 Add `preloaded_metadata: Option<&NewCacheMetadata>` parameter to `serve_range_from_cache()` in `src/http_proxy.rs`. When `Some`, use it for building response headers instead of calling `get_metadata_from_disk()` with retry loop. When `None`, fall back to existing behavior.
    - _Requirements: 1.4_
  - [x] 4.3 Pass `preloaded_metadata` through `get_cached_range_data()` if needed, or restructure so metadata is used directly in `serve_range_from_cache()` for header construction.
    - _Requirements: 1.4_
  - [x] 4.4 Wire up metadata pass-through in the full-object GET path (`handle_get_head_request` around line 1402) where `has_cached_ranges` and `find_cached_ranges` are also called.
    - _Requirements: 1.1_
  - [x] 4.5 Wire up metadata pass-through in `forward_signed_range_request` path (around line 4568) where `serve_range_from_cache` is called.
    - _Requirements: 1.1_

- [x] 5. Checkpoint — verify compilation and all tests pass after wiring
  - Run `cargo build --release` and `cargo test --release`.

- [x] 6. Skip full-object cache check for large files
  - [x] 6.1 In `handle_range_request()` in `src/http_proxy.rs`: after loading metadata, check if `content_length > config.cache.full_object_check_threshold`. If so, skip the `has_cached_ranges` + `find_cached_ranges(full_range)` block and proceed directly to range-specific `find_cached_ranges`.
    - _Requirements: 2.1_
  - [x] 6.2 When `content_length` is unknown (metadata is `None`), proceed with the full-object check as before (no behavior change).
    - _Requirements: 2.3_

- [x] 7. Connection pool default change
  - [x] 7.1 Change `max_idle_per_host` default from 1 to 10 in `ConnectionPoolConfig::default()` in `src/config.rs`.
    - _Requirements: 3.1_

- [x] 8. Consolidation cycle timeout
  - [x] 8.1 In `run_consolidation_cycle()` in `src/journal_consolidator.rs`: wrap the per-key processing phase (`stream::iter(key_futures).buffer_unordered(...).collect()`) with `tokio::time::timeout(self.config.consolidation_cycle_timeout, ...)`.
    - _Requirements: 4.1_
  - [x] 8.2 On timeout: log a warning with the number of unprocessed keys. Process whatever results were collected before timeout. Proceed to cleanup and eviction check.
    - _Requirements: 4.2, 4.3_
  - [x] 8.3 Pass `consolidation_cycle_timeout` from `SharedStorageConfig` to `ConsolidationConfig` in the consolidator initialization.
    - _Requirements: 4.4_
  - [x] 8.4 Verify size tracking (accumulator delta collection) is unaffected — it runs before the per-key phase.
    - _Requirements: 4.5_

- [x] 9. Checkpoint — verify compilation and all tests pass
  - Run `cargo build --release` and `cargo test --release`.

- [x] 10. Stream range data from disk cache
  - [x] 10.1 Add `stream_range_data()` method to `DiskCacheManager` in `src/disk_cache.rs`. Opens the range file, reads in `chunk_size` chunks (default 64 KiB), yields `Bytes` via a channel or async stream. For LZ4-compressed files, read and decompress the full file first, then stream the decompressed output in chunks.
    - _Requirements: 5.1, 5.4_
  - [x] 10.2 Modify `serve_range_from_cache()` in `src/http_proxy.rs`: when the range size >= `config.cache.disk_streaming_threshold` and the data comes from disk (not RAM), use `stream_range_data()` and return a streaming `BoxBody` instead of `Full::new(Bytes::from(range_data))`.
    - _Requirements: 5.1, 5.2, 5.3, 5.5_
  - [x] 10.3 Set `Content-Length` and `Content-Range` headers from metadata before streaming begins.
    - _Requirements: 5.6_
  - [x] 10.4 Handle mid-stream disk read errors by dropping the stream (connection termination).
    - _Requirements: 5.7_
  - [x] 10.5 Add integration test: store an 8 MiB range on disk, serve it via streaming, verify all bytes match.

- [x] 11. Checkpoint — verify compilation and all tests pass
  - Run `cargo build --release` and `cargo test --release`.

- [-] 12. Version bump and changelog
  - [x] 12.1 Update `Cargo.toml` version to `1.1.39`
  - [x] 12.2 Add v1.1.39 entry to `CHANGELOG.md` describing: metadata pass-through (NFS reads reduced from ~5 to ~1 per cache hit), full-object check skip for large files, max_idle_per_host default 1→10, consolidation cycle timeout, streaming range data from disk
  - [-] 12.3 Commit: `git add -A && git commit -m "v1.1.39: Cache hit performance — metadata pass-through, large file optimization, streaming"`

- [~] 13. Final checkpoint
  - Run `cargo test --release`. All tests pass.

## Notes

- Task 10 (streaming) is the most complex and can be deferred to a follow-up version if needed. Tasks 1-9 deliver the majority of the latency improvement.
- The metadata pass-through (tasks 2+4) is the highest-impact change. If time is limited, prioritize tasks 1-5.
- All signature changes use `Option` parameters with `None` fallback, so backward compatibility is guaranteed without modifying test files upfront.
