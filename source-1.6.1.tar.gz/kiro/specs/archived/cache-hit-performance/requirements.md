# Requirements: Cache Hit Performance (v1.1.39)

## Introduction

Cache hit latency for range requests on NFS-backed deployments is dominated by redundant NFS metadata reads. A single cached 8 MiB range GET triggers 4-5 NFS reads of the same `.meta` file because most code paths bypass the RAM metadata cache. This spec addresses the top performance bottlenecks identified in `docs/PERFORMANCE_IMPROVEMENTS.md`.

Five areas: metadata pass-through to eliminate redundant NFS reads, skip full-object cache check for large files, connection pool tuning, consolidation cycle timeout protection, and streaming range data from disk cache.

## Glossary

- **MetadataCache**: RAM cache for `NewCacheMetadata` objects in `src/metadata_cache.rs`. Serves metadata in microseconds on hit, refreshes from NFS every 5 seconds.
- **get_metadata_cached()**: Method on `CacheManager` that checks `MetadataCache` first, falls back to NFS on miss/stale.
- **get_metadata_from_disk()**: Method on `CacheManager` that always reads from NFS, bypassing `MetadataCache`.
- **has_cached_ranges()**: Method on `CacheManager` that calls `get_metadata_from_disk()` to check if an object has cached ranges. Bypasses `MetadataCache`.
- **find_cached_ranges()**: Method on `RangeHandler` that acquires `disk_cache_manager` read lock and calls `DiskCacheManager::get_metadata()` to find overlapping ranges. Bypasses `MetadataCache`.
- **handle_range_request()**: The hot path in `HttpProxy` for range GET requests. Currently calls `get_metadata_cached()`, `has_cached_ranges()`, `find_cached_ranges()` (twice), and `get_metadata_from_disk()` — each reading the same `.meta` file.
- **serve_range_from_cache()**: Method that loads range data and builds the HTTP response. Currently re-reads metadata from NFS for response headers.
- **KEY_CONCURRENCY_LIMIT**: Constant controlling concurrent per-key processing in consolidation. Currently 8.

## Requirements

### Requirement 1: Metadata Pass-Through in handle_range_request

**User Story:** As a proxy operator on NFS, I want cache hits to read the metadata file at most once per request, so that cache-hit latency is halved.

#### Acceptance Criteria

1.1. WHEN `handle_range_request()` processes a range GET, IT SHALL load metadata via `get_metadata_cached()` once at the start and pass the result through the call chain.

1.2. `has_cached_ranges()` SHALL accept an optional pre-loaded metadata parameter. WHEN metadata is provided, it SHALL use it instead of calling `get_metadata_from_disk()`.

1.3. `find_cached_ranges()` on `RangeHandler` SHALL accept an optional pre-loaded metadata parameter. WHEN metadata is provided, it SHALL use it instead of acquiring the `disk_cache_manager` read lock and calling `DiskCacheManager::get_metadata()`.

1.4. `serve_range_from_cache()` SHALL accept pre-loaded metadata for building response headers. WHEN metadata is provided, it SHALL NOT call `get_metadata_from_disk()`.

1.5. All existing callers of `has_cached_ranges()`, `find_cached_ranges()`, and `serve_range_from_cache()` that do not have pre-loaded metadata SHALL continue to work unchanged (pass `None`).

1.6. The RAM `MetadataCache` hit/miss metrics SHALL continue to be recorded accurately.

### Requirement 2: Skip Full-Object Cache Check for Large Files

**User Story:** As a proxy operator, I want range requests for large files to skip the full-object cache check, so that each request avoids scanning hundreds of cached ranges unnecessarily.

#### Acceptance Criteria

2.1. WHEN `handle_range_request()` determines the object's `content_length` exceeds a configurable threshold (default: 64 MiB), IT SHALL skip the full-object cache check (`has_cached_ranges` + `find_cached_ranges` with full range) and proceed directly to range-specific lookup.

2.2. The threshold SHALL be configurable via `cache.full_object_check_threshold` in config.yaml. Default: 67108864 (64 MiB).

2.3. WHEN `content_length` is unknown (metadata not cached), the full-object check SHALL proceed as before (no behavior change for uncached objects).

### Requirement 3: Connection Pool max_idle_per_host

**User Story:** As a proxy operator, I want more idle connections kept alive to S3, so that burst cache misses reuse existing TLS connections instead of establishing new ones.

#### Acceptance Criteria

3.1. The default value for `connection_pool.max_idle_per_host` SHALL be changed from 1 to 10.

3.2. The example config SHALL document the new default and explain the trade-off (more idle connections = more memory, fewer TLS handshakes during bursts).

### Requirement 4: Consolidation Cycle Timeout

**User Story:** As a proxy operator, I want consolidation cycles to have a maximum duration, so that one slow NFS operation cannot block the next cycle or hold the global lock indefinitely.

#### Acceptance Criteria

4.1. `run_consolidation_cycle()` SHALL enforce a configurable maximum duration for the per-key processing phase. Default: 30 seconds.

4.2. WHEN the timeout is reached, the cycle SHALL stop processing remaining keys, log a warning with the number of unprocessed keys, and proceed to delta collection and eviction check.

4.3. Keys that were not processed due to timeout SHALL be retried in the next cycle (no data loss).

4.4. The timeout SHALL be configurable via `cache.shared_storage.consolidation_cycle_timeout` in config.yaml. Default: "30s".

4.5. Size tracking (accumulator delta collection) SHALL NOT be affected by the timeout — it runs before per-key processing and completes independently.

### Requirement 5: Stream Range Data from Disk Cache

**User Story:** As a proxy operator with high concurrency, I want cached range data streamed in chunks instead of loaded entirely into memory, so that memory usage scales better with concurrent requests.

#### Acceptance Criteria

5.1. WHEN serving a cached range, `serve_range_from_cache()` SHALL stream range data from disk in chunks (default: 64 KiB) instead of loading the entire range into a `Vec<u8>`.

5.2. The response body SHALL use a streaming body type compatible with hyper's `BoxBody<Bytes, hyper::Error>`.

5.3. RAM cache hits SHALL continue to serve the full data from memory (no streaming needed for RAM-cached data).

5.4. LZ4-compressed range data SHALL be decompressed during streaming. Each chunk SHALL be decompressed independently or the full range SHALL be decompressed before streaming if LZ4 frame format requires it.

5.5. The streaming threshold SHALL be configurable. Ranges smaller than the threshold (default: 1 MiB) SHALL continue to be loaded fully into memory. Ranges at or above the threshold SHALL be streamed.

5.6. Content-Length and Content-Range headers SHALL be set correctly before streaming begins (from metadata, not from data length).

5.7. IF a disk read error occurs mid-stream, the connection SHALL be terminated (partial response is acceptable per HTTP semantics for streaming).
