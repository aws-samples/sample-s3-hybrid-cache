# Implementation Plan: Accumulator Size Tracking

## Overview

Replace journal-based size tracking with an in-memory AtomicI64 accumulator. Changes span `journal_consolidator.rs` (new SizeAccumulator struct, modified consolidation cycle), `disk_cache.rs` (accumulator increment on store), `cache.rs` (accumulator decrement on eviction, RangeEvictionCandidate update), and `cache_size_tracker.rs` (delta file reset on validation).

## Tasks

- [x] 1. Implement SizeAccumulator struct and delta file I/O
  - [x] 1.1 Create `SizeAccumulator` struct in `journal_consolidator.rs` with `AtomicI64` fields for `delta` and `write_cache_delta`, `instance_id`, and `delta_file_path`
    - Implement `new()`, `add()`, `add_write_cache()`, `subtract()`, `subtract_write_cache()`
    - Implement `flush()` with atomic swap-to-zero and write-to-file, with rollback on failure
    - Implement `write_delta_file()` with atomic tmp+rename pattern
    - Delta file JSON format: `{"delta": i64, "write_cache_delta": i64, "instance_id": string, "timestamp": string}`
    - _Requirements: 1.1, 1.2, 1.4, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 5.1_

  - [x] 1.2 Write property test: Accumulator add/subtract algebraic sum
    - **Property 1: Accumulator add/subtract algebraic sum**
    - Generate random sequences of (add, subtract) operations with random u64 sizes
    - Execute all operations (optionally from multiple threads)
    - Assert final delta equals algebraic sum
    - Repeat for write_cache_delta independently
    - **Validates: Requirements 1.2, 1.4, 1.5, 2.1, 2.2, 5.2, 5.3, 5.4**

  - [x] 1.3 Write property test: Flush round-trip
    - **Property 2: Flush round-trip**
    - Generate random delta and write_cache_delta values
    - Call add/subtract to reach those values, then flush()
    - Assert accumulator is zero after flush
    - Read delta file, parse JSON, assert delta and write_cache_delta match pre-flush values
    - Assert instance_id and timestamp fields are present
    - **Validates: Requirements 3.3, 3.5, 5.5, 8.1, 8.2**

  - [x] 1.4 Write property test: Flush failure restores accumulator
    - **Property 3: Flush failure restores accumulator**
    - Generate random delta and write_cache_delta values
    - Make delta file path unwritable (e.g., read-only directory)
    - Call flush(), assert it returns error
    - Assert accumulator delta and write_cache_delta still equal original values
    - **Validates: Requirements 3.6**

- [x] 2. Implement consolidator delta collection and size state update
  - [x] 2.1 Add `SizeAccumulator` field to `JournalConsolidator` struct, initialize in `new()`
    - Add `size_accumulator: Arc<SizeAccumulator>` field
    - Add `pub fn size_accumulator(&self) -> &Arc<SizeAccumulator>` accessor
    - _Requirements: 1.1, 6.4_

  - [x] 2.2 Implement `collect_and_apply_deltas()` method on `JournalConsolidator`
    - Read all `delta_*.json` files from `size_tracking/` directory
    - Sum `delta` and `write_cache_delta` from each valid file
    - Skip files with invalid JSON (log warning)
    - Reset each successfully-read delta file to zero (atomic tmp+rename)
    - Return `(total_delta: i64, total_write_cache_delta: i64)`
    - _Requirements: 4.1, 4.2, 4.3, 4.5_

  - [x] 2.3 Implement `reset_all_delta_files()` method on `JournalConsolidator`
    - Read all `delta_*.json` files from `size_tracking/`
    - Write each file with `delta: 0, write_cache_delta: 0`
    - Used by validation scan after correcting drift
    - _Requirements: 6.3_

  - [x] 2.4 Write property test: Consolidator delta summation and reset
    - **Property 4: Consolidator delta summation and reset**
    - Generate N random delta files (1-10 files) with random delta and write_cache_delta values
    - Write them to a temp directory
    - Set initial size_state with random total_size and write_cache_size
    - Call collect_and_apply_deltas()
    - Assert returned sums match expected
    - Assert all delta files now contain zero
    - Assert size_state updated correctly (with clamping to 0)
    - **Validates: Requirements 4.1, 4.2, 4.3, 5.6**

  - [x] 2.5 Write property test: Validation scan resets all delta files
    - **Property 5: Validation scan resets all delta files**
    - Generate N random delta files with non-zero values
    - Call reset_all_delta_files()
    - Assert all files contain delta=0 and write_cache_delta=0
    - **Validates: Requirements 6.3**

- [x] 3. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Modify consolidation cycle to use accumulator deltas instead of journal-based size tracking
  - [x] 4.1 Modify `run_consolidation_cycle()` to flush accumulator and collect deltas
    - At cycle start (before global lock): call `self.size_accumulator.flush()`
    - After acquiring global lock: call `self.collect_and_apply_deltas()`
    - Apply returned deltas to size_state (with clamping to 0)
    - Remove the `atomic_update_size_delta(total_size_delta, total_write_cache_delta)` call that used journal-derived deltas
    - Keep journal processing for metadata updates only
    - _Requirements: 4.2, 4.4, 4.6, 7.4_

  - [x] 4.2 Modify `consolidate_object()` to stop feeding size deltas into size state
    - Remove `calculate_size_delta()` call from the size tracking path
    - `ConsolidationResult.size_delta` and `write_cache_delta` can remain for logging but must not be summed into size_state
    - Journal entries continue to be processed by `apply_journal_entries()` for metadata updates
    - _Requirements: 2.3, 4.4, 7.1, 7.2, 7.3_

- [x] 5. Wire accumulator into store_range and eviction paths
  - [x] 5.1 Modify `store_range()` in `disk_cache.rs` to increment accumulator after successful write
    - After successful HybridMetadataWriter call: `consolidator.size_accumulator().add(compressed_size)`
    - If `object_metadata.is_write_cached` is true: also call `add_write_cache(compressed_size)`
    - Only in the shared storage (HybridMetadataWriter) code path
    - _Requirements: 1.2, 1.3, 5.2_

  - [x] 5.2 Add `compressed_size` field to `RangeEvictionCandidate` in `cache.rs`
    - Populate from `RangeSpec.compressed_size` in `create_range_candidates_from_metadata()`
    - This ensures eviction uses the same value that was added at write time
    - _Requirements: 2.1_

  - [x] 5.3 Modify `perform_eviction_with_lock()` in `cache.rs` to decrement accumulator
    - After collecting `evicted_ranges_for_journal`, iterate and call `consolidator.size_accumulator().subtract(range.compressed_size)` for each evicted range
    - For write-cached ranges (check `bin_file_path.contains("mpus_in_progress/")` or metadata `is_write_cached`): also call `subtract_write_cache(compressed_size)`
    - Use `compressed_size` from `RangeEvictionCandidate` (not `bytes_freed`)
    - _Requirements: 2.1, 2.2, 5.4_

  - [x] 5.4 Modify `write_multipart_journal_entries()` in `journal_consolidator.rs` to increment accumulator
    - After writing journal entries for each range: `self.size_accumulator.add(range_spec.compressed_size)`
    - If `object_metadata.is_write_cached` or path contains `mpus_in_progress/`: also `add_write_cache()`
    - _Requirements: 1.5, 5.2, 5.3_

- [x] 6. Wire accumulator into validation scan and shutdown
  - [x] 6.1 Modify `update_size_from_validation()` in `journal_consolidator.rs` to reset delta files
    - After updating size_state from validation scan, call `self.reset_all_delta_files()`
    - Also reset the in-memory accumulator to zero: `self.size_accumulator.delta.store(0, Relaxed)` and same for write_cache_delta
    - _Requirements: 6.3_

  - [x] 6.2 Modify `shutdown()` in `journal_consolidator.rs` to flush accumulator
    - Call `self.size_accumulator.flush()` before existing shutdown logic
    - Log warning if flush fails (non-fatal — validation scan will correct)
    - _Requirements: 8.1, 8.2_

- [x] 7. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 8. Documentation and version bump
  - [x] 8.1 Update `Cargo.toml` version to `1.1.33`
  - [x] 8.2 Add `[1.1.33]` entry to `CHANGELOG.md` describing the accumulator-based size tracking change
    - Summarize what changed: replaced journal-based size tracking with in-memory AtomicI64 accumulator
    - Note new files: `size_tracking/delta_{instance_id}.json` per-instance delta files
    - Note removed code path: `calculate_size_delta()` no longer used for size state updates
    - Note behavioral change: size tracked at write/eviction time instead of during consolidation
    - Include migration notes if any (delta files are new, but backward-compatible — consolidator creates `size_tracking/` dir on first flush)
  - [x] 8.3 Update `docs/CACHING.md` to reflect the new accumulator-based size tracking mechanism
    - Replace any references to journal-based size calculation with accumulator approach
    - Document the per-instance delta file mechanism and consolidator integration
  - [x] 8.4 Update `docs/ARCHITECTURE.md` if it references the old size tracking flow
    - Update data flow descriptions to reflect accumulator → delta file → consolidator path
  - [x] 8.5 Commit version bump and changelog: `git add Cargo.toml CHANGELOG.md && git commit -m "v1.1.33: Accumulator-based size tracking"`

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Property tests validate universal correctness properties using `quickcheck`
- Unit tests validate specific examples and edge cases
- The `calculate_size_delta()` function and its tests can be left in place (for potential future use) but must be disconnected from the size tracking path in `run_consolidation_cycle()` and `consolidate_object()`
