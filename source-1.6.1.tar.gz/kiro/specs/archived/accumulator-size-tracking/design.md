# Design Document: Accumulator Size Tracking

## Overview

Replace journal-based size tracking with an in-memory `AtomicI64` accumulator per proxy instance. Size changes are recorded at the moment of write (`fetch_add`) and eviction (`fetch_sub`) with zero NFS overhead. Each instance periodically flushes its accumulated delta to a per-instance file on shared storage. The consolidator (already holding a global lock) reads all delta files, sums them into `size_state.json`, and resets the delta files.

This eliminates the root cause: the gap between "when data is written" and "when size is counted." Journal entries continue to serve their original purpose (metadata updates, access tracking, TTL refresh) but no longer participate in size calculations.

## Architecture

```mermaid
flowchart TD
    subgraph "Per Instance (in-memory)"
        SR[store_range] -->|fetch_add compressed_size| ACC[AtomicI64 Accumulator]
        MPU[write_multipart_journal_entries] -->|fetch_add compressed_size| ACC
        EV[perform_eviction_with_lock] -->|fetch_sub compressed_size| ACC
        ACC -->|swap to 0 every 5s| FLUSH[Flush to Delta File]
        
        SRACC[AtomicI64 Write Cache Accumulator] -->|swap to 0 every 5s| FLUSH
        SR -->|if write_cached| SRACC
        MPU -->|mpus_in_progress| SRACC
        EV -->|if write_cached| SRACC
    end

    subgraph "Shared NFS Storage"
        FLUSH --> DF1[delta_instance1.json]
        FLUSH --> DF2[delta_instance2.json]
        DF1 --> CONS[Consolidator under global lock]
        DF2 --> CONS
        CONS -->|sum deltas + update| SS[size_state.json]
        CONS -->|truncate| DF1
        CONS -->|truncate| DF2
    end

    subgraph "Unchanged"
        SR -->|journal Add entry| JE[Journal Entries]
        EV -->|journal Remove entry| JE
        JE -->|metadata updates only| CONSM[consolidate_object / apply_journal_entries]
    end
```

### Data Flow: Range Store

1. `store_range()` writes `.bin` file, creates journal entry via HybridMetadataWriter
2. On success: `accumulator.fetch_add(compressed_size, Relaxed)`
3. If `is_write_cached` or `mpus_in_progress/` path: also `write_cache_accumulator.fetch_add(compressed_size, Relaxed)`

### Data Flow: Eviction

1. `perform_eviction_with_lock()` collects `RangeEvictionCandidate` structs
2. `batch_evict_ranges()` deletes `.bin` files, returns `bytes_freed`
3. For each evicted range: `accumulator.fetch_sub(range.compressed_size, Relaxed)` using the RangeSpec `compressed_size` from the eviction candidate (NOT `bytes_freed`)
4. If write-cached or `mpus_in_progress/` path: also `write_cache_accumulator.fetch_sub(compressed_size, Relaxed)`
5. `write_eviction_journal_entries()` still writes Remove entries for metadata cleanup only

### Data Flow: Consolidation

1. Consolidator acquires global lock
2. Reads all `delta_*.json` files from `size_tracking/`
3. Sums `delta` and `write_cache_delta` values
4. Adds sums to `size_state.json` (clamping `total_size` and `write_cache_size` to minimum 0)
5. Truncates (resets) each delta file
6. Processes journal entries for metadata updates only (no `calculate_size_delta()` call)
7. Triggers eviction if needed based on updated size

## Components and Interfaces

### New: `SizeAccumulator` (in `journal_consolidator.rs`)

A lightweight struct holding the two atomic counters and flush logic. Lives inside `JournalConsolidator` since that component already owns size tracking state.

```rust
use std::sync::atomic::{AtomicI64, Ordering};

pub struct SizeAccumulator {
    /// Net size delta since last flush (bytes added - bytes removed)
    delta: AtomicI64,
    /// Net write-cache size delta since last flush
    write_cache_delta: AtomicI64,
    /// Instance ID for delta file naming
    instance_id: String,
    /// Path to this instance's delta file
    delta_file_path: PathBuf,
}

impl SizeAccumulator {
    pub fn new(cache_dir: &Path, instance_id: String) -> Self {
        let delta_file_path = cache_dir
            .join("size_tracking")
            .join(format!("delta_{}.json", instance_id));
        Self {
            delta: AtomicI64::new(0),
            write_cache_delta: AtomicI64::new(0),
            instance_id,
            delta_file_path,
        }
    }

    /// Called by store_range after successful write
    pub fn add(&self, compressed_size: u64) {
        self.delta.fetch_add(compressed_size as i64, Ordering::Relaxed);
    }

    /// Called by store_range for write-cached objects
    pub fn add_write_cache(&self, compressed_size: u64) {
        self.write_cache_delta.fetch_add(compressed_size as i64, Ordering::Relaxed);
    }

    /// Called by eviction after range deletion
    pub fn subtract(&self, compressed_size: u64) {
        self.delta.fetch_sub(compressed_size as i64, Ordering::Relaxed);
    }

    /// Called by eviction for write-cached range deletion
    pub fn subtract_write_cache(&self, compressed_size: u64) {
        self.write_cache_delta.fetch_sub(compressed_size as i64, Ordering::Relaxed);
    }

    /// Atomically swap accumulators to zero and write to delta file.
    /// If file write fails, restore the swapped values.
    pub async fn flush(&self) -> Result<()> {
        let delta = self.delta.swap(0, Ordering::Relaxed);
        let wc_delta = self.write_cache_delta.swap(0, Ordering::Relaxed);

        if delta == 0 && wc_delta == 0 {
            return Ok(()); // Nothing to flush
        }

        match self.write_delta_file(delta, wc_delta).await {
            Ok(()) => Ok(()),
            Err(e) => {
                // Restore values on failure
                self.delta.fetch_add(delta, Ordering::Relaxed);
                self.write_cache_delta.fetch_add(wc_delta, Ordering::Relaxed);
                Err(e)
            }
        }
    }

    async fn write_delta_file(&self, delta: i64, write_cache_delta: i64) -> Result<()> {
        // Ensure directory exists
        if let Some(parent) = self.delta_file_path.parent() {
            tokio::fs::create_dir_all(parent).await?;
        }

        let content = serde_json::json!({
            "delta": delta,
            "write_cache_delta": write_cache_delta,
            "instance_id": self.instance_id,
            "timestamp": chrono::Utc::now().to_rfc3339()
        });

        // Atomic write via temp file + rename
        let tmp_path = self.delta_file_path.with_extension("json.tmp");
        tokio::fs::write(&tmp_path, serde_json::to_string_pretty(&content)?).await?;
        tokio::fs::rename(&tmp_path, &self.delta_file_path).await?;
        Ok(())
    }
}
```

### Modified: `JournalConsolidator`

New field:
```rust
pub struct JournalConsolidator {
    // ... existing fields ...
    /// In-memory size accumulator for this instance
    size_accumulator: Arc<SizeAccumulator>,
}
```

New methods:
```rust
impl JournalConsolidator {
    /// Get reference to the size accumulator (for store_range and eviction to call)
    pub fn size_accumulator(&self) -> &Arc<SizeAccumulator> {
        &self.size_accumulator
    }

    /// Read all delta files, sum into size_state, reset delta files.
    /// Called during run_consolidation_cycle() under global lock.
    async fn collect_and_apply_deltas(&self) -> Result<(i64, i64)> {
        let size_tracking_dir = self.cache_dir.join("size_tracking");
        let mut total_delta: i64 = 0;
        let mut total_wc_delta: i64 = 0;

        let mut entries = tokio::fs::read_dir(&size_tracking_dir).await?;
        while let Some(entry) = entries.next_entry().await? {
            let path = entry.path();
            let file_name = path.file_name()
                .and_then(|n| n.to_str())
                .unwrap_or("");

            if !file_name.starts_with("delta_") || !file_name.ends_with(".json") {
                continue;
            }

            match tokio::fs::read_to_string(&path).await {
                Ok(content) => {
                    match serde_json::from_str::<serde_json::Value>(&content) {
                        Ok(json) => {
                            let delta = json.get("delta")
                                .and_then(|v| v.as_i64())
                                .unwrap_or(0);
                            let wc_delta = json.get("write_cache_delta")
                                .and_then(|v| v.as_i64())
                                .unwrap_or(0);
                            total_delta += delta;
                            total_wc_delta += wc_delta;

                            // Reset the delta file
                            let reset = serde_json::json!({
                                "delta": 0,
                                "write_cache_delta": 0,
                                "instance_id": json.get("instance_id")
                                    .and_then(|v| v.as_str())
                                    .unwrap_or("unknown"),
                                "timestamp": chrono::Utc::now().to_rfc3339()
                            });
                            let tmp_path = path.with_extension("json.tmp");
                            if let Err(e) = tokio::fs::write(
                                &tmp_path,
                                serde_json::to_string_pretty(&reset).unwrap_or_default()
                            ).await {
                                warn!("Failed to write reset delta file {:?}: {}", tmp_path, e);
                                continue;
                            }
                            if let Err(e) = tokio::fs::rename(&tmp_path, &path).await {
                                warn!("Failed to rename reset delta file {:?}: {}", path, e);
                            }
                        }
                        Err(e) => {
                            warn!("Invalid JSON in delta file {:?}: {}", path, e);
                        }
                    }
                }
                Err(e) => {
                    warn!("Failed to read delta file {:?}: {}", path, e);
                }
            }
        }

        Ok((total_delta, total_wc_delta))
    }
}
```

### Modified: `run_consolidation_cycle()`

Key changes:
1. After acquiring global lock, call `collect_and_apply_deltas()` to read/sum/reset delta files
2. Apply the summed deltas to `size_state.json` (replacing the `atomic_update_size_delta(total_size_delta, total_write_cache_delta)` call that used journal-derived deltas)
3. Continue processing journal entries for metadata updates only — remove the `calculate_size_delta()` call from the size tracking path
4. The `total_size_delta` accumulated from `consolidate_object()` calls is no longer used for size state updates

### Modified: `consolidate_object()`

The `size_delta` and `write_cache_delta` fields in `ConsolidationResult` become unused for size tracking. The method still calls `apply_journal_entries()` for metadata updates but no longer calls `calculate_size_delta()` on the result. The `ConsolidationResult` struct can retain the fields for logging/debugging but they don't feed into `size_state.json`.

### Modified: `store_range()` in `disk_cache.rs`

After the successful HybridMetadataWriter call (shared storage path), add:
```rust
// Track size via in-memory accumulator (zero NFS overhead)
if let Some(consolidator) = &self.journal_consolidator {
    consolidator.size_accumulator().add(compressed_size);
    // Track write cache if applicable
    if is_write_cached {
        consolidator.size_accumulator().add_write_cache(compressed_size);
    }
}
```

The `is_write_cached` flag needs to be passed through or determined from context. For `store_range()` called from the GET path, `is_write_cached` is false. For `store_range()` called from PUT/CompleteMPU paths, the `ObjectMetadata.is_write_cached` field indicates this.

### Modified: `perform_eviction_with_lock()` in `cache.rs`

After collecting `evicted_ranges_for_journal`, add accumulator decrements:
```rust
// Decrement accumulator using RangeSpec compressed_size (symmetric with add)
if let Some(consolidator) = self.journal_consolidator.read().await.as_ref() {
    for (cache_key, range_start, range_end, size, bin_file_path) in &evicted_ranges_for_journal {
        consolidator.size_accumulator().subtract(*size);
        // Check if write-cached
        if bin_file_path.contains("mpus_in_progress/") || is_write_cached_range(cache_key) {
            consolidator.size_accumulator().subtract_write_cache(*size);
        }
    }
}
```

Note: The `size` field in `evicted_ranges_for_journal` currently comes from `RangeEvictionCandidate.size`, which uses `fs::metadata().len()` (filesystem size). This must be changed to use `RangeSpec.compressed_size` instead, to maintain symmetry with the `fetch_add` at write time. The `RangeEvictionCandidate` struct should be updated to carry `compressed_size` from the RangeSpec, or the eviction code should use `compressed_size` directly.

### Modified: `RangeEvictionCandidate` in `cache.rs`

Add a `compressed_size` field populated from `RangeSpec.compressed_size`:
```rust
pub struct RangeEvictionCandidate {
    // ... existing fields ...
    /// Compressed size from RangeSpec (for accumulator symmetry)
    pub compressed_size: u64,
}
```

The accumulator subtract uses `compressed_size`, while `bytes_freed` from `batch_delete_ranges()` continues to use filesystem size for its return value (used only for logging).

### Modified: `write_multipart_journal_entries()` in `journal_consolidator.rs`

After writing journal entries, add accumulator increment:
```rust
pub async fn write_multipart_journal_entries(
    &self,
    cache_key: &str,
    ranges: Vec<RangeSpec>,
    object_metadata: ObjectMetadata,
) {
    // ... existing journal entry writing ...

    // Track size via accumulator for each successfully written range
    for range_spec in &ranges {
        self.size_accumulator.add(range_spec.compressed_size);
        // MPU completion ranges go under mpus_in_progress or are write-cached
        if range_spec.file_path.contains("mpus_in_progress/")
            || object_metadata.is_write_cached
        {
            self.size_accumulator.add_write_cache(range_spec.compressed_size);
        }
    }
}
```

### Modified: `update_size_from_validation()` in `journal_consolidator.rs`

When the daily validation scan corrects drift, it must also reset all delta files to prevent stale deltas from being re-applied on the next consolidation cycle:
```rust
pub async fn update_size_from_validation(&self, scanned_size: u64, write_cache_size: Option<u64>) {
    // ... existing logic to update size_state.json ...

    // Reset all delta files to prevent stale deltas
    self.reset_all_delta_files().await;
}
```

### Modified: `shutdown()` in `journal_consolidator.rs`

Flush the accumulator before the existing shutdown logic:
```rust
pub async fn shutdown(&self) -> Result<()> {
    // Flush pending accumulator delta to disk
    if let Err(e) = self.size_accumulator.flush().await {
        warn!("Failed to flush size accumulator on shutdown: {}", e);
    }
    // ... existing shutdown logic ...
}
```

### Flush Timing

The accumulator flush happens at the start of each consolidation cycle, before delta files are read. This is the simplest integration point — the instance flushes its own accumulator, then (if it wins the global lock) reads all delta files including its own freshly-flushed one.

```rust
// In run_consolidation_cycle():
// 1. Flush own accumulator to delta file (no lock needed)
self.size_accumulator.flush().await?;

// 2. Try to acquire global lock
let lock_acquired = self.try_acquire_global_consolidation_lock()?;
if !lock_acquired { return Ok(/* skipped */); }

// 3. Read all delta files, sum, apply to size_state (under lock)
let (total_delta, total_wc_delta) = self.collect_and_apply_deltas().await?;

// 4. Process journal entries for metadata only (under lock)
// ... existing consolidation logic minus calculate_size_delta ...
```

## Data Models

### Delta File Format

```json
{
    "delta": 1048576,
    "write_cache_delta": 0,
    "instance_id": "ip-10-0-1-42:12345",
    "timestamp": "2026-02-10T14:30:00.000Z"
}
```

Location: `{cache_dir}/size_tracking/delta_{instance_id}.json`

Each instance writes only its own file. The consolidator reads all files under the global lock.

### Updated `size_tracking/` Directory

```
size_tracking/
    size_state.json              # Authoritative total (updated by consolidator)
    validation.json              # Validation scan metadata
    delta_ip-10-0-1-42:12345.json  # Instance 1 pending delta
    delta_ip-10-0-1-43:12346.json  # Instance 2 pending delta
```

### SizeState (unchanged)

```rust
pub struct SizeState {
    pub total_size: u64,
    pub write_cache_size: u64,
    pub last_consolidation: SystemTime,
    pub consolidation_count: u64,
    pub last_updated_by: String,
}
```

No schema changes to `size_state.json`.


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Accumulator add/subtract algebraic sum

*For any* sequence of `add(a_1), add(a_2), ..., subtract(s_1), subtract(s_2), ...` operations (executed concurrently or sequentially) on a SizeAccumulator initialized to zero, the final accumulator `delta` value SHALL equal `sum(a_i) - sum(s_j)`. The same property holds independently for `write_cache_delta`.

This is an invariant property: the accumulator is a pure algebraic sum of all operations applied to it, regardless of ordering or concurrency.

**Validates: Requirements 1.2, 1.4, 1.5, 2.1, 2.2, 5.2, 5.3, 5.4**

### Property 2: Flush round-trip

*For any* SizeAccumulator with accumulated `delta=D` and `write_cache_delta=W`, after calling `flush()`:
1. The accumulator's `delta` SHALL be 0
2. The accumulator's `write_cache_delta` SHALL be 0
3. The delta file SHALL contain valid JSON with `"delta": D` and `"write_cache_delta": W`
4. The delta file SHALL contain `"instance_id"` (string) and `"timestamp"` (string) fields

This is a round-trip property: the value moves from memory to disk, and reading the file back recovers the original values.

**Validates: Requirements 3.3, 3.5, 5.5, 8.1, 8.2**

### Property 3: Flush failure restores accumulator

*For any* SizeAccumulator with accumulated `delta=D` and `write_cache_delta=W`, if `flush()` fails (e.g., due to I/O error), the accumulator's `delta` SHALL still equal `D` and `write_cache_delta` SHALL still equal `W`.

This is an error-condition property: failed operations must not lose data.

**Validates: Requirements 3.6**

### Property 4: Consolidator delta summation and reset

*For any* set of N delta files with values `{(d_1, w_1), (d_2, w_2), ..., (d_N, w_N)}` and an initial `size_state.total_size = T` and `size_state.write_cache_size = WC`, after `collect_and_apply_deltas()`:
1. The returned total delta SHALL equal `sum(d_i)`
2. The returned write cache delta SHALL equal `sum(w_i)`
3. All N delta files SHALL contain `"delta": 0` and `"write_cache_delta": 0`
4. The updated `size_state.total_size` SHALL equal `max(0, T + sum(d_i))`
5. The updated `size_state.write_cache_size` SHALL equal `max(0, WC + sum(w_i))`

This combines an invariant (sum correctness) with idempotence (reset prevents re-counting).

**Validates: Requirements 4.1, 4.2, 4.3, 5.6**

### Property 5: Validation scan resets all delta files

*For any* set of delta files in the `size_tracking/` directory (with arbitrary delta values), after `reset_all_delta_files()`, every delta file SHALL contain `"delta": 0` and `"write_cache_delta": 0`.

This is an idempotence property: resetting is safe to call multiple times.

**Validates: Requirements 6.3**

## Error Handling

| Scenario | Behavior |
|----------|----------|
| Delta file write fails during flush | Restore swapped values to accumulator via `fetch_add`. Log warning. Delta will be included in next flush attempt. |
| Delta file contains invalid JSON during consolidation | Log warning, skip file. Other delta files are still processed. Stale delta persists until next successful read or validation scan reset. |
| Delta file unreadable (permissions, NFS error) | Log warning, skip file. Same as invalid JSON handling. |
| `size_tracking/` directory missing | Create on first flush via `create_dir_all`. Consolidator handles missing directory gracefully. |
| Consolidator crashes mid-cycle after reading deltas but before resetting files | Deltas are re-applied on next cycle (double-counted). Daily validation scan corrects drift. Over-counting is safe (triggers eviction early). |
| Instance crashes before flush | At most `flush_interval` (5s) of deltas lost. Daily validation scan corrects. |
| Negative total_size after applying deltas | Clamp to 0. This can happen if eviction deltas exceed tracked size due to prior drift. Validation scan will correct. |
| Concurrent flush and consolidator read of same delta file | Consolidator runs under global lock. Flush writes atomically (tmp + rename). Consolidator either reads the old value or the new value, never a partial write. |

## Testing Strategy

### Property-Based Testing

Use the `quickcheck` crate (already a dev-dependency in this project) for property-based tests. Each property test runs a minimum of 100 iterations.

Property tests target the `SizeAccumulator` and `collect_and_apply_deltas` logic in isolation, using `tempdir` for delta file I/O.

### Unit Tests

Unit tests cover:
- `SizeAccumulator::new()` initializes both accumulators to 0
- Delta file path construction for various instance IDs
- Edge case: flush with zero delta (no file write)
- Edge case: consolidator with no delta files (returns 0, 0)
- Edge case: consolidator with one invalid and one valid delta file (skips invalid, processes valid)
- Edge case: negative delta larger than total_size (clamps to 0)
- Integration: `store_range()` → accumulator increment → flush → consolidation → size_state update

### Test Configuration

- PBT library: `quickcheck` (existing dependency)
- Minimum iterations: 100 per property
- Each property test references its design document property number
- Tag format: **Feature: accumulator-size-tracking, Property {N}: {title}**
