# Requirements Document

## Introduction

Replace the journal-based size tracking in the S3 proxy with an in-memory AtomicI64 accumulator that tracks cache size at write time. The current approach fails because HybridMetadataWriter writes ranges to `.meta` files immediately, so by the time consolidation runs, metadata-diff approaches see no change and journal-based approaches suffer from cross-cycle double-counting. The accumulator approach tracks size at the moment of write/eviction (zero overhead), flushes deltas to per-instance files on NFS, and lets the consolidator sum them into size_state.json.

## Glossary

- **Accumulator**: An AtomicI64 value maintained per proxy instance that tracks the net size delta since the last flush
- **Delta_File**: A per-instance JSON file (`size_tracking/delta_{instance_id}.json`) containing the flushed accumulator value
- **Size_State**: The persistent `size_state.json` file containing the authoritative total cache size, updated only by the Consolidator
- **Consolidator**: The JournalConsolidator component that runs under a global lock, processes journal entries for metadata updates, and now also sums delta files into Size_State
- **RangeSpec**: A struct containing range metadata including `compressed_size` (the on-disk .bin file size after compression)
- **Flush_Interval**: The period between accumulator flushes to Delta_File, equal to the existing `consolidation_interval` (default 5 seconds)
- **Validation_Scan**: The existing daily CacheSizeTracker scan that recalculates total cache size from metadata files and corrects drift
- **Write_Cache**: Cache capacity reserved for write-through objects (completed PutObject and CompleteMPU with `is_write_cached: true`) and in-progress multipart uploads (`mpus_in_progress/`). Tracked separately in Size_State as `write_cache_size` to enforce the `write_cache_percent` capacity limit and prevent unread writes from evicting the read cache

## Requirements

### Requirement 1: In-Memory Accumulator

**User Story:** As a proxy operator, I want cache size tracked at write time with zero per-write NFS overhead, so that size tracking is both accurate and performant.

#### Acceptance Criteria

1. THE Accumulator SHALL be an AtomicI64 initialized to zero on proxy startup
2. WHEN `store_range_data()` successfully writes a range file and journal entry, THE Accumulator SHALL increment by the `compressed_size` from the RangeSpec
3. WHEN `store_range_data()` fails before completing the range file write, THE Accumulator SHALL remain unchanged
4. THE Accumulator SHALL support concurrent fetch_add and fetch_sub operations from multiple tokio tasks without blocking
5. WHEN a write-cache range is stored via multipart upload completion (`write_multipart_journal_entries()`), THE Accumulator SHALL increment by the `compressed_size` of each finalized range

### Requirement 2: Eviction Size Tracking

**User Story:** As a proxy operator, I want eviction to subtract the same value that was added at write time, so that the accumulator remains symmetric and accurate.

#### Acceptance Criteria

1. WHEN a range is evicted, THE Accumulator SHALL decrement by the `compressed_size` value from the RangeSpec, not by the filesystem `bytes_freed` returned from `batch_delete_ranges()`
2. WHEN `perform_eviction_with_lock()` evicts multiple ranges, THE Accumulator SHALL decrement once per evicted range using each range's RangeSpec `compressed_size`
3. THE Proxy SHALL NOT subtract evicted range sizes via journal Remove entry processing in `calculate_size_delta()` — journal Remove entries SHALL be used only for metadata updates in `apply_journal_entries()`

### Requirement 3: Per-Instance Delta Files

**User Story:** As a proxy operator running multiple instances on shared NFS, I want each instance to write its own delta file without NFS locking, so that size tracking does not cause write contention.

#### Acceptance Criteria

1. THE Proxy SHALL flush the Accumulator value to a Delta_File at the Flush_Interval
2. THE Delta_File SHALL be located at `{cache_dir}/size_tracking/delta_{instance_id}.json`
3. WHEN flushing, THE Proxy SHALL atomically swap the Accumulator to zero and write the swapped value to the Delta_File
4. THE Proxy SHALL write only to its own Delta_File — each instance writes exclusively to one file
5. THE Delta_File SHALL contain a JSON object with fields: `delta` (i64), `instance_id` (string), `timestamp` (ISO 8601 string)
6. IF the Delta_File write fails, THEN THE Proxy SHALL add the swapped value back to the Accumulator so the delta is not lost

### Requirement 4: Consolidator Integration

**User Story:** As a proxy operator, I want the consolidator to sum per-instance deltas into size_state.json under the existing global lock, so that the total cache size is updated atomically.

#### Acceptance Criteria

1. WHEN the Consolidator runs a consolidation cycle (under the global lock), THE Consolidator SHALL read all Delta_Files in the `size_tracking/` directory
2. THE Consolidator SHALL sum the `delta` values from all Delta_Files and add the sum to the `total_size` in Size_State
3. WHEN the Consolidator has read a Delta_File, THE Consolidator SHALL truncate (reset to zero) that Delta_File
4. THE Consolidator SHALL NOT use `calculate_size_delta()` for updating `total_size` in Size_State — journal entries SHALL be processed only for metadata updates
5. IF a Delta_File contains invalid JSON or is unreadable, THEN THE Consolidator SHALL log a warning and skip that file without failing the consolidation cycle
6. WHEN the Consolidator updates Size_State, THE Consolidator SHALL clamp `total_size` to a minimum of zero

### Requirement 5: Write Cache Delta Tracking

**User Story:** As a proxy operator, I want write-cache size tracked separately via the same accumulator mechanism, so that the write-cache percentage limit prevents unread writes from evicting the read cache.

#### Acceptance Criteria

1. THE Proxy SHALL maintain a separate AtomicI64 Write_Cache_Accumulator for write-cache ranges
2. WHEN a range is stored for an object with `is_write_cached: true` (completed PutObject or CompleteMPU), THE Write_Cache_Accumulator SHALL increment by the `compressed_size`
3. WHEN a range under `mpus_in_progress/` is stored (in-progress multipart upload parts), THE Write_Cache_Accumulator SHALL increment by the `compressed_size`
4. WHEN a write-cached range or `mpus_in_progress/` range is evicted, THE Write_Cache_Accumulator SHALL decrement by the `compressed_size`
5. THE Delta_File SHALL include a `write_cache_delta` field (i64) alongside the main `delta` field
6. THE Consolidator SHALL update `write_cache_size` in Size_State using the summed `write_cache_delta` values

### Requirement 6: Crash Recovery

**User Story:** As a proxy operator, I want the system to recover from crashes with bounded size drift, so that the daily validation scan corrects any accumulated error.

#### Acceptance Criteria

1. WHEN a proxy instance crashes, THE lost in-memory delta SHALL be bounded by the Flush_Interval (5 seconds of writes)
2. THE Validation_Scan SHALL continue to run daily and correct any drift between tracked size and actual metadata-derived size
3. WHEN the Validation_Scan corrects drift, THE Validation_Scan SHALL reset all Delta_Files to zero to prevent stale deltas from being re-applied
4. WHEN a proxy instance starts, THE Accumulator SHALL initialize to zero (the instance has no pending delta at startup)

### Requirement 7: Journal System Continuity

**User Story:** As a proxy operator, I want the journal system to continue handling metadata updates, access tracking, and TTL refresh, so that only the size tracking path changes.

#### Acceptance Criteria

1. THE Journal system SHALL continue writing Add entries for new ranges (used by consolidation for metadata updates)
2. THE Journal system SHALL continue writing Remove entries for evicted ranges (used by `apply_journal_entries()` to remove ranges from `.meta` files)
3. THE Journal system SHALL continue processing TtlRefresh and AccessUpdate entries unchanged
4. THE `calculate_size_delta()` function SHALL be removed from the size tracking path in `run_consolidation_cycle()` and `consolidate_object()`
5. THE HybridMetadataWriter SHALL continue writing ranges to `.meta` files immediately (no change to immediate write behavior)

### Requirement 8: Shutdown Behavior

**User Story:** As a proxy operator, I want the accumulator flushed on graceful shutdown, so that pending deltas are not lost during restarts.

#### Acceptance Criteria

1. WHEN the proxy shuts down gracefully, THE Proxy SHALL flush the Accumulator to the Delta_File before exiting
2. WHEN the proxy shuts down gracefully, THE Proxy SHALL flush the Write_Cache_Accumulator to the Delta_File before exiting
