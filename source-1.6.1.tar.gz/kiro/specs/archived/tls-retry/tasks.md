# Implementation Plan

- [x] 1. Extract and enhance TLS retry helper function
  - Extract the existing retry logic from `signed_request_proxy.rs` into a reusable helper function
  - Update max_retries from 3 to 5
  - Ensure the function handles both TCP connection and TLS handshake failures
  - Add comprehensive logging for each retry attempt with hostname and attempt number
  - Add logging for successful recovery after failures
  - _Requirements: 1.1, 1.2, 1.4, 1.5, 2.1, 2.2, 2.4, 3.1, 3.3, 3.4_

- [ ]* 1.1 Write property test for retry bounds
  - **Property 1: Retry attempts are bounded**
  - **Validates: Requirements 1.1, 1.2**

- [ ]* 1.2 Write property test for exponential backoff
  - **Property 2: Exponential backoff increases delays**
  - **Validates: Requirements 2.4**

- [ ]* 1.3 Write property test for early termination on success
  - **Property 3: Successful retry stops further attempts**
  - **Validates: Requirements 1.4**

- [ ]* 1.4 Write property test for last error propagation
  - **Property 5: Last error is returned on exhaustion**
  - **Validates: Requirements 1.3**

- [ ]* 1.5 Write property test for timeout retry behavior
  - **Property 6: Timeout errors trigger retries**
  - **Validates: Requirements 1.5**

- [x] 2. Update signed_put_handler.rs to use retry helper
  - Replace the inline TLS connection code in `forward_signed_put_request` function (around lines 750-790)
  - Call the new `establish_tls_with_retry` helper function
  - Remove the old non-retry TLS connection code
  - Ensure timeout handling is preserved (30 second timeout per attempt)
  - _Requirements: 1.2, 2.1, 3.1, 3.4_

- [ ]* 2.1 Write property test for retry logging
  - **Property 7: Retry failures are logged with details**
  - **Validates: Requirements 2.2, 3.1, 3.4**

- [ ]* 2.2 Write property test for recovery logging
  - **Property 8: Successful recovery is logged**
  - **Validates: Requirements 3.3**

- [x] 3. Update s3_client.rs to use retry helper
  - Modify the `establish_tls_connection` method (around lines 233-250)
  - Replace direct TLS connection with call to `establish_tls_with_retry` helper
  - Ensure the configurable request timeout is respected per attempt
  - _Requirements: 1.1, 2.1, 3.1, 3.4_

- [ ]* 3.1 Write unit tests for s3_client TLS retry integration
  - Test that s3_client properly retries on TLS failures
  - Test that timeouts are respected per attempt
  - _Requirements: 1.1, 1.5_

- [x] 4. Update signed_request_proxy.rs to use the new helper
  - Replace the existing inline retry logic with a call to the extracted helper function
  - Update from 3 to 5 retries
  - Ensure backward compatibility with existing behavior
  - _Requirements: 1.1, 1.2, 1.4, 2.1_

- [ ]* 4.1 Write unit tests for signed_request_proxy retry integration
  - Test that signed_request_proxy properly uses the new helper
  - Test that 5 retries are attempted
  - _Requirements: 1.1, 1.2_

- [x] 5. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
