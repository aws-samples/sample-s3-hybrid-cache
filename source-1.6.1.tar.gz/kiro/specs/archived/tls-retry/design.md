# Design Document

## Overview

This design adds consistent TLS handshake retry logic to all modules that establish TLS connections to S3 endpoints. Currently, only `signed_request_proxy.rs` implements retry logic for TLS handshake failures, while `signed_put_handler.rs` and `s3_client.rs` fail immediately on TLS errors.

The solution will extract the retry logic into a reusable helper function and apply it consistently across all TLS connection points, improving system reliability when facing transient network issues.

## Architecture

### Current State

The codebase has three modules that establish TLS connections to S3:

1. **signed_request_proxy.rs** - Has retry logic (3 attempts with 100ms exponential backoff)
2. **signed_put_handler.rs** - No retry logic, fails immediately
3. **s3_client.rs** - No retry logic, fails immediately

All modules will be updated to use 5 retry attempts for improved reliability.

### Proposed Changes

1. Extract the retry logic from `signed_request_proxy.rs` into a reusable helper function
2. Apply the helper function to `signed_put_handler.rs` TLS connection establishment
3. Apply the helper function to `s3_client.rs` TLS connection establishment
4. Ensure consistent logging across all retry attempts

## Components and Interfaces

### TLS Retry Helper Function

Location: `src/signed_request_proxy.rs` (or new `src/tls_utils.rs` if preferred)

```rust
/// Establish TLS connection with retry logic
///
/// Attempts to establish a TLS connection with exponential backoff retry.
/// Retries on both connection failures and TLS handshake failures.
///
/// # Arguments
///
/// * `target_ip` - IP address to connect to
/// * `port` - Port number (typically 443)
/// * `hostname` - Hostname for TLS SNI
/// * `tls_connector` - TLS connector instance
/// * `max_retries` - Maximum number of retry attempts (default: 5)
///
/// # Returns
///
/// Returns a TLS stream on success, or ProxyError on failure after all retries
pub async fn establish_tls_with_retry(
    target_ip: IpAddr,
    port: u16,
    hostname: &str,
    tls_connector: &TlsConnector,
    max_retries: usize,
) -> Result<tokio_rustls::client::TlsStream<TcpStream>>
```

### Modified Functions

#### signed_put_handler.rs

The `forward_signed_put_request` function currently has inline TLS connection code without retry. This will be replaced with a call to the retry helper.

**Current code location:** Lines ~750-790
**Change:** Replace inline TLS connection with `establish_tls_with_retry` call

#### s3_client.rs

The `establish_tls_connection` method currently fails immediately on TLS errors. This will be modified to use the retry helper.

**Current code location:** Lines ~233-250
**Change:** Replace direct TLS connection with `establish_tls_with_retry` call

## Data Models

No new data structures are required. The existing error types (`ProxyError::TlsError`, `ProxyError::TimeoutError`, `ProxyError::ConnectionError`) are sufficient.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Retry attempts are bounded

*For any* TLS connection attempt, the system should retry at most 5 times before returning an error.
**Validates: Requirements 1.1, 1.2**

### Property 2: Exponential backoff increases delays

*For any* sequence of retry attempts, each subsequent delay should be greater than or equal to the previous delay (exponential backoff).
**Validates: Requirements 2.4**

### Property 3: Successful retry stops further attempts

*For any* TLS connection that succeeds on retry attempt N (where N < max_retries), no further retry attempts should be made.
**Validates: Requirements 1.4**

### Property 4: All TLS failures are logged

*For any* TLS handshake failure, a warning log entry should be created with the attempt number and error details.
**Validates: Requirements 3.1, 3.4**

### Property 5: Last error is returned on exhaustion

*For any* TLS connection that exhausts all retries, the error returned should be the error from the last retry attempt.
**Validates: Requirements 1.3**

### Property 6: Timeout errors trigger retries

*For any* TLS handshake that times out, the system should treat it as a retryable error and attempt additional retries.
**Validates: Requirements 1.5**

### Property 7: Retry failures are logged with details

*For any* TLS handshake retry attempt that fails, a warning log entry should be created containing the attempt number, target hostname, and error message.
**Validates: Requirements 2.2, 3.1, 3.4**

### Property 8: Successful recovery is logged

*For any* TLS connection that succeeds after one or more failures, an info log entry should be created indicating successful recovery.
**Validates: Requirements 3.3**

## Error Handling

### Retryable Errors

The following errors should trigger a retry:
- `ProxyError::TlsError` - TLS handshake failures
- `ProxyError::TimeoutError` - TLS handshake timeouts
- `ProxyError::ConnectionError` - TCP connection failures

### Non-Retryable Errors

The following errors should NOT trigger a retry:
- Invalid hostname/server name errors (fail fast)
- Configuration errors

### Retry Exhaustion

When all retry attempts are exhausted:
1. Log an error with the total number of attempts
2. Return the last error encountered
3. Allow the caller to handle the error (may trigger higher-level retries)

## Testing Strategy

### Unit Tests

1. **Test retry count enforcement**
   - Verify that exactly 5 attempts are made before giving up
   - Mock TLS connector to always fail
   - Count the number of connection attempts

2. **Test exponential backoff timing**
   - Verify delays increase exponentially (100ms, 200ms, 400ms)
   - Mock TLS connector to fail on first 2 attempts
   - Measure time between attempts

3. **Test successful retry**
   - Mock TLS connector to fail on first attempt, succeed on second
   - Verify only 2 attempts are made
   - Verify successful connection is returned

4. **Test immediate success**
   - Mock TLS connector to succeed on first attempt
   - Verify only 1 attempt is made
   - Verify no delays occur

5. **Test error propagation**
   - Mock TLS connector to always fail
   - Verify the last error is returned
   - Verify error type is preserved

### Property-Based Tests

Property-based tests will use the `quickcheck` library as specified in the tech stack.

1. **Property test for retry bounds**
   - Generate random failure counts (0 to 10)
   - Verify retry logic stops at max_retries regardless of failure count
   - **Feature: tls-retry, Property 1: Retry attempts are bounded**

2. **Property test for backoff progression**
   - Generate random retry sequences
   - Verify each delay is >= previous delay
   - **Feature: tls-retry, Property 2: Exponential backoff increases delays**

3. **Property test for early success termination**
   - Generate random success positions (1 to max_retries)
   - Verify no attempts occur after success
   - **Feature: tls-retry, Property 3: Successful retry stops further attempts**

### Integration Tests

1. **Test with real TLS connections**
   - Use a test S3 endpoint
   - Simulate network issues (if possible)
   - Verify retry behavior in real scenarios

2. **Test across all modules**
   - Verify `signed_put_handler.rs` retries TLS failures
   - Verify `s3_client.rs` retries TLS failures
   - Verify `signed_request_proxy.rs` continues to work

## Implementation Notes

### Logging Requirements

Each retry attempt must log:
- Attempt number (1-based)
- Target hostname
- Error message
- Log level: WARN for retries, ERROR for final failure, INFO for recovery

Example log messages:
```
WARN TLS handshake attempt 1 failed for s3.amazonaws.com: connection reset
WARN TLS handshake attempt 2 failed for s3.amazonaws.com: connection reset
ERROR TLS handshake failed after 5 attempts for s3.amazonaws.com
```

### Timeout Handling

Each TLS handshake attempt should have its own timeout (currently 30s in `signed_put_handler.rs`, configurable in `s3_client.rs`). The retry logic should respect these timeouts and treat timeout errors as retryable.

### Backward Compatibility

This change is backward compatible:
- No API changes to public interfaces
- No configuration changes required
- Only internal implementation changes
- Improves reliability without changing behavior for successful connections

## Performance Considerations

### Latency Impact

- Successful connections: No impact (same as before)
- Failed connections: Additional latency due to retries
  - 1st retry: +100ms
  - 2nd retry: +200ms
  - 3rd retry: +400ms
  - 4th retry: +800ms
  - 5th retry: +1600ms
  - Total worst case: +3100ms before final failure

This is acceptable because:
1. Failures are rare in production
2. Retries often succeed, avoiding client-visible errors
3. The alternative is immediate failure, which is worse for users

### Resource Usage

- Minimal additional resource usage
- Each retry creates a new TCP connection (old behavior on manual retry)
- No connection pooling impact (connections are not pooled during establishment)

## Deployment Considerations

### Rollout Strategy

1. Deploy to development environment
2. Monitor logs for retry patterns
3. Deploy to staging with increased logging
4. Monitor for any unexpected retry storms
5. Deploy to production

### Monitoring

Monitor the following metrics:
- TLS handshake failure rate
- TLS handshake retry rate
- TLS handshake success after retry rate
- Average retry count per failed connection

### Rollback Plan

If issues arise:
1. Revert to previous version
2. TLS connections will fail immediately again (previous behavior)
3. No data loss or corruption risk
