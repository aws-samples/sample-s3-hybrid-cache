# Design Document

## Overview

This design removes unnecessary HEAD cache lookups from GET request processing to eliminate duplicate HEAD cache log entries and maintain the transparent forwarder principle. Currently, GET request processing performs additional HEAD cache lookups at lines 758 and 768 in `src/http_proxy.rs`, which causes confusing log patterns where a single HEAD request generates both MISS and HIT entries.

The solution is to remove these additional HEAD cache lookups and make GET request processing rely solely on S3 response headers for metadata, maintaining the proxy's role as a transparent forwarder.

## Architecture

### Current (Problematic) Flow

```
Client sends HEAD request
  ↓
HEAD cache lookup (line 693) → MISS → Forward to S3 → Cache response
  ↓
GET processing logic runs (incorrectly)
  ↓
Additional HEAD cache lookup (line 758 or 768) → HIT → Log confusion
```

### New (Correct) Flow

```
Client sends HEAD request
  ↓
HEAD cache lookup (line 693) → MISS → Forward to S3 → Cache response → Return

Client sends GET request
  ↓
No HEAD cache lookups → Forward to S3 → Extract metadata from response → Cache data
```

## Components and Interfaces

### Modified Components

1. **HttpProxy::handle_get_head_request()**
   - Remove HEAD cache lookup at line 758 (ETag extraction)
   - Remove HEAD cache lookup at line 768 (content-length extraction)
   - Remove fallback HEAD request logic (lines 775+)
   - Make GET processing independent of HEAD cache state

2. **GET Request Metadata Handling**
   - Extract content-length from S3 GET response headers
   - Extract ETag from S3 GET response headers
   - Remove dependency on cached HEAD metadata

### Data Flow

```
┌────────┐                    ┌───────┐                    ┌────┐
│ Client │                    │ Proxy │                    │ S3 │
└───┬────┘                    └───┬───┘                    └─┬──┘
    │                             │                          │
    │ HEAD /object                │                          │
    ├────────────────────────────>│                          │
    │                             │ HEAD cache lookup        │
    │                             │ (MISS)                   │
    │                             │                          │
    │                             │ Forward HEAD             │
    │                             ├─────────────────────────>│
    │                             │                          │
    │                             │<─────────────────────────┤
    │                             │ HEAD response            │
    │                             │                          │
    │                             │ Cache HEAD response      │
    │<────────────────────────────┤ Return to client         │
    │ HEAD response               │                          │
    │                             │                          │
    │ GET /object                 │                          │
    ├────────────────────────────>│                          │
    │                             │ NO HEAD cache lookups    │
    │                             │                          │
    │                             │ Forward GET              │
    │                             ├─────────────────────────>│
    │                             │                          │
    │                             │<─────────────────────────┤
    │                             │ GET response + metadata  │
    │                             │                          │
    │                             │ Extract metadata from    │
    │                             │ GET response headers     │
    │<────────────────────────────┤ Cache data + metadata    │
    │ GET response                │                          │
    │                             │                          │
```

## Data Models

### Metadata Extraction

Instead of relying on cached HEAD metadata, GET requests will extract metadata directly from S3 response headers:

```rust
// OLD: Get from HEAD cache
let etag = cache_manager.get_head_cache_entry(&cache_key).await
    .ok()
    .and_then(|entry| entry)
    .and_then(|entry| entry.headers.get("etag").cloned());

// NEW: Get from GET response
let etag = s3_response.headers.get("etag").cloned();
```

### Content Length Handling

```rust
// OLD: Get from HEAD cache or make HEAD request
match cache_manager.get_head_cache_entry(&cache_key).await {
    Ok(Some(head_entry)) => {
        let length = head_entry.headers.get("content-length")
            .and_then(|v| v.parse::<u64>().ok());
    }
    _ => {
        // Make HEAD request to S3 (WRONG - violates transparent forwarder)
    }
}

// NEW: Get from GET response
let content_length = s3_response.headers.get("content-length")
    .and_then(|v| v.parse::<u64>().ok());
```

## Implementation Strategy

### Phase 1: Remove HEAD Cache Lookups

1. **Remove line 758**: ETag extraction from HEAD cache
2. **Remove line 768**: Content-length extraction from HEAD cache  
3. **Remove lines 775+**: Fallback HEAD request logic

### Phase 2: Update Metadata Extraction

1. **Extract ETag from GET response**: Use `s3_response.headers.get("etag")`
2. **Extract content-length from GET response**: Use `s3_response.headers.get("content-length")`
3. **Remove HEAD request fallback**: Don't make internal HEAD requests

### Phase 3: Simplify Logic

1. **Remove conditional branches**: Eliminate HEAD cache dependency checks
2. **Streamline GET processing**: Make it independent of HEAD cache state
3. **Preserve HEAD processing**: Keep HEAD request logic unchanged

## Error Handling

### Missing Metadata Scenarios

| Scenario | Current Behavior | New Behavior |
|----------|------------------|--------------|
| GET response missing ETag | Fall back to HEAD cache/request | Use empty ETag, log warning |
| GET response missing Content-Length | Fall back to HEAD cache/request | Extract from response body size |
| Range request without size | Make HEAD request to S3 | Use range response headers |

### Graceful Degradation

1. **Missing ETag**: Continue without ETag validation (log warning)
2. **Missing Content-Length**: Calculate from response body
3. **Range boundary issues**: Let S3 handle validation and return appropriate errors

## Testing Strategy

### Unit Tests

1. **Test GET processing without HEAD cache**: Verify GET requests work when HEAD cache is empty
2. **Test metadata extraction**: Verify ETag and content-length are extracted from GET responses
3. **Test HEAD processing unchanged**: Verify HEAD requests still work exactly as before

### Integration Tests

1. **Test HEAD then GET sequence**: Verify no duplicate HEAD cache logs
2. **Test GET without prior HEAD**: Verify GET works without cached HEAD metadata
3. **Test range requests**: Verify range processing works without HEAD cache dependency

### Property-Based Tests

Each correctness property will be implemented as a property-based test using quickcheck.

**Property Test Configuration:**
- Minimum 100 iterations per property test
- Each test tagged with: `**Feature: remove-get-head-lookups, Property {number}: {property_text}**`

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Single HEAD cache operation per HEAD request
*For any* HEAD request from a client, the proxy SHALL perform exactly one HEAD cache lookup and log exactly one HEAD cache operation.

**Validates: Requirements 1.2, 6.3**

### Property 2: No HEAD cache operations for GET requests  
*For any* GET request from a client, the proxy SHALL perform zero HEAD cache lookups and log zero HEAD cache operations.

**Validates: Requirements 1.1, 2.1**

### Property 3: GET metadata extraction from response
*For any* GET request, all required metadata (ETag, content-length) SHALL be extracted from the S3 GET response headers, not from cached HEAD metadata.

**Validates: Requirements 2.3, 3.3, 4.3**

### Property 4: No internal HEAD requests
*For any* GET request processing, the proxy SHALL NOT make internal HEAD requests to S3, maintaining transparent forwarder behavior.

**Validates: Requirements 2.1, 2.2, 5.3**

## Performance Considerations

### Positive Impacts

- **Reduced cache lookups**: Eliminates 1-2 HEAD cache lookups per GET request
- **Simplified logic**: Removes conditional branches and fallback paths
- **Faster processing**: Direct metadata extraction from response headers

### Neutral Impacts

- **Metadata availability**: GET responses contain the same metadata as HEAD responses
- **Cache efficiency**: No change to actual caching behavior
- **Network requests**: No change to S3 request patterns

### Monitoring

- **HEAD cache hit/miss ratios**: Should show cleaner patterns (no duplicate entries)
- **GET request latency**: Should remain the same or improve slightly
- **Error rates**: Should remain the same (better error handling for missing metadata)

## Alternatives Considered

### Alternative 1: Fix the duplicate logging

**Rejected**: Would still violate transparent forwarder principle by making internal HEAD requests.

### Alternative 2: Make HEAD cache lookups conditional

**Rejected**: Adds complexity and still creates dependency on HEAD cache state.

### Alternative 3: Separate HEAD and GET processing completely

**Considered**: This design achieves this by removing HEAD dependencies from GET processing.

## Backward Compatibility

This change improves behavior and removes a bug. No breaking changes to external APIs or client behavior.

**Impact**: Positive - eliminates confusing log entries and improves adherence to transparent forwarder principle.