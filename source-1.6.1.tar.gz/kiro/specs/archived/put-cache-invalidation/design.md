# Design Document: PUT Cache Invalidation

## Overview

This feature ensures cache consistency by invalidating cached GET and HEAD data when a PUT request succeeds, regardless of whether write caching is enabled. The implementation adds cache invalidation calls to the code paths that currently bypass invalidation when write caching is disabled.

## Architecture

The change is minimal and localized to `src/http_proxy.rs`. The existing `invalidate_cache_unified_for_operation` method in CacheManager already provides comprehensive cache invalidation across all layers:

```
┌─────────────────────────────────────────────────────────────────┐
│                        PUT Request Flow                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  PUT Request ──► Forward to S3 ──► S3 Response                  │
│                                         │                        │
│                                         ▼                        │
│                              ┌──────────────────┐               │
│                              │ Success (2xx)?   │               │
│                              └────────┬─────────┘               │
│                                       │                          │
│                         ┌─────────────┴─────────────┐           │
│                         │                           │            │
│                         ▼                           ▼            │
│                    [Success]                   [Failure]         │
│                         │                           │            │
│                         ▼                           ▼            │
│         ┌───────────────────────────┐      [No invalidation]    │
│         │ invalidate_cache_unified_ │                           │
│         │ for_operation(key, "PUT") │                           │
│         └───────────────────────────┘                           │
│                         │                                        │
│                         ▼                                        │
│         ┌───────────────────────────┐                           │
│         │ Invalidates:              │                           │
│         │ - RAM GET cache           │                           │
│         │ - RAM HEAD cache          │                           │
│         │ - Disk GET cache (ranges) │                           │
│         │ - Disk HEAD cache         │                           │
│         └───────────────────────────┘                           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### Modified Components

1. **http_proxy.rs - handle_put_request**
   - Add cache invalidation after successful PUT when write caching is disabled (signed PUT path)
   
2. **http_proxy.rs - handle_unsigned_put_request**
   - Add cache invalidation after successful PUT when write caching is disabled (unsigned PUT path)

3. **http_proxy.rs - forward_put_to_s3_with_body**
   - Modify to accept cache_manager and perform invalidation on success

4. **signed_put_handler.rs - finalize_multipart_upload**
   - Add cache invalidation before creating new object metadata for CompleteMultipartUpload

### Existing Components (No Changes)

- **CacheManager::invalidate_cache_unified_for_operation** - Already handles comprehensive invalidation
- **signed_put_handler.rs** - Already calls invalidation when write caching is enabled

## Data Models

No new data models required. The feature uses existing cache key generation and invalidation methods.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property Reflection

After analyzing the acceptance criteria, several properties can be consolidated:
- Properties 1.1, 2.1, 3.1, 3.2 all test that successful PUT invalidates cache - can be combined
- Properties 1.2, 2.2 test the specific case of write caching disabled - important to test separately
- Property 3.3 tests the negative case (failed PUT) - unique property
- Property 4.1, 4.2 test CompleteMultipartUpload HEAD cache invalidation - unique multipart scenario

### Properties

**Property 1: Successful PUT invalidates GET and HEAD cache**

*For any* cache key with existing GET and HEAD cache entries, when a PUT request succeeds for that key, both the GET cache and HEAD cache entries SHALL be removed.

**Validates: Requirements 1.1, 2.1, 3.1, 3.2**

**Property 2: Cache invalidation occurs regardless of write cache setting**

*For any* cache key with existing GET and HEAD cache entries, when write_cache_enabled is false and a PUT request succeeds, the GET and HEAD cache entries SHALL be removed.

**Validates: Requirements 1.2, 2.2**

**Property 3: Failed PUT preserves cache**

*For any* cache key with existing GET and HEAD cache entries, when a PUT request fails (non-2xx response), the GET and HEAD cache entries SHALL remain unchanged.

**Validates: Requirements 3.3**

**Property 4: CompleteMultipartUpload invalidates HEAD cache**

*For any* cache key with existing HEAD cache entries, when a CompleteMultipartUpload request succeeds for that key, the HEAD cache entry SHALL be removed.

**Validates: Requirements 4.1, 4.2**

## Error Handling

1. **Invalidation Failure**: If `invalidate_cache_unified_for_operation` fails, log a warning and continue. The PUT request should not fail due to cache invalidation errors.

2. **No Cache Entry**: If no cached data exists for the key, the invalidation method handles this gracefully (no error).

3. **Partial Invalidation**: If RAM cache invalidation succeeds but disk cache fails, the method logs warnings but continues. This is acceptable as the disk cache will eventually expire or be overwritten.

## Testing Strategy

### Dual Testing Approach

Both unit tests and property-based tests will be used:

- **Unit tests**: Verify specific scenarios and edge cases
- **Property-based tests**: Verify universal properties across random inputs

### Property-Based Testing

Use `quickcheck` (already in Cargo.toml) for property-based tests.

Each property test should:
1. Generate random cache keys
2. Set up cache state (GET and/or HEAD entries)
3. Perform PUT operation
4. Verify cache state matches expected outcome

### Test Configuration

- Minimum 100 iterations per property test
- Tests should be tagged with property reference: `**Feature: put-cache-invalidation, Property {N}: {description}**`

### Test Cases

1. **Property 1 Test**: Create GET+HEAD cache, PUT succeeds, verify both invalidated
2. **Property 2 Test**: Same as Property 1 but with write_cache_enabled=false
3. **Property 3 Test**: Create GET+HEAD cache, simulate failed PUT, verify cache preserved
4. **Property 4 Test**: Create HEAD cache, CompleteMultipartUpload succeeds, verify HEAD cache invalidated
5. **Edge Case**: PUT to key with no existing cache (should not error)
6. **Edge Case**: Invalidation failure handling (mock failure, verify PUT succeeds)
7. **Edge Case**: CompleteMultipartUpload with no existing HEAD cache (should not error)
