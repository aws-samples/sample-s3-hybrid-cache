# Implementation Plan

- [x] 1. Add cache invalidation for signed PUT when write caching disabled
  - [x] 1.1 Modify handle_put_request to call invalidate_cache_unified_for_operation after successful S3 response when write_cache_enabled is false
    - Add cache invalidation call after `forward_signed_request` returns success
    - Log warning if invalidation fails, do not fail the PUT request
    - _Requirements: 1.1, 1.2, 2.1, 2.2, 3.1, 5.1, 5.2_

  - [x] 1.2 Write property test for signed PUT cache invalidation
    - **Property 1: Successful PUT invalidates GET and HEAD cache**
    - **Validates: Requirements 1.1, 2.1, 3.1**

- [x] 2. Add cache invalidation for unsigned PUT when write caching disabled
  - [x] 2.1 Modify handle_unsigned_put_request to call invalidate_cache_unified_for_operation after successful S3 response when write_cache_enabled is false
    - Add cache invalidation call after `forward_put_to_s3_with_body` returns success
    - Log warning if invalidation fails, do not fail the PUT request
    - _Requirements: 1.1, 1.2, 2.1, 2.2, 3.2, 5.1, 5.2_

  - [x] 2.2 Write property test for unsigned PUT cache invalidation
    - **Property 2: Cache invalidation occurs regardless of write cache setting**
    - **Validates: Requirements 1.2, 2.2**

- [x] 3. Verify failed PUT does not invalidate cache
  - [x] 3.1 Review existing code to confirm failed PUT paths do not call invalidation
    - Verify handle_put_request does not invalidate on non-2xx response
    - Verify handle_unsigned_put_request does not invalidate on non-2xx response
    - _Requirements: 3.3, 4.4_

  - [x] 3.2 Write property test for failed PUT cache preservation
    - **Property 3: Failed PUT preserves cache**
    - **Validates: Requirements 3.3**

- [x] 4. Add cache invalidation for CompleteMultipartUpload
  - [x] 4.1 Modify finalize_multipart_upload to call invalidate_cache_unified_for_operation before creating new object metadata
    - Add cache invalidation call before writing new metadata file in finalize_multipart_upload
    - Log warning if invalidation fails, do not fail the CompleteMultipartUpload operation
    - _Requirements: 4.1, 4.2, 4.3, 5.1, 5.2_

  - [x] 4.2 Write property test for CompleteMultipartUpload cache invalidation
    - **Property 4: CompleteMultipartUpload invalidates HEAD cache**
    - **Validates: Requirements 4.1, 4.2**

- [x] 5. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
