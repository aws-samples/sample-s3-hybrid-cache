# Design Document: Eviction and Journal Cleanup Fixes

## Overview

This design addresses four related issues discovered during v1.1.9 testing:

1. **Stale journal entries accumulate** - Journal entries for evicted ranges are never cleaned up, causing CPU waste and log spam
2. **Size tracking drift** - When `atomic_subtract_size()` fails during eviction, the size state becomes inaccurate
3. **No eviction headroom** - Eviction only triggers at 100% capacity, leaving no buffer
4. **Delayed cleanup** - Evicted ranges aren't immediately marked as stale in the journal

The solution uses timestamp-based staleness detection (no cross-instance state), retry with exponential backoff for size updates, and configurable eviction thresholds.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CacheManager                                 │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  perform_eviction_with_lock()                                │   │
│  │  - Collects evicted ranges: Vec<(cache_key, start, end)>    │   │
│  │  - Calls consolidator.mark_ranges_evicted() after eviction  │   │
│  │  - Calls atomic_subtract_size_with_retry() for size update  │   │
│  └─────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      JournalConsolidator                             │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  validate_journal_entries_with_staleness()                   │   │
│  │  - Checks if range file exists                               │   │
│  │  - If not, checks if entry.timestamp + 5min < now            │   │
│  │  - Stale entries are removed from journal                    │   │
│  └─────────────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  atomic_subtract_size_with_retry()                           │   │
│  │  - Retries up to 3 times with exponential backoff            │   │
│  │  - Delays: 100ms, 200ms, 400ms (with ±20% jitter)           │   │
│  └─────────────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  mark_ranges_evicted()                                       │   │
│  │  - Stores evicted ranges in memory for immediate cleanup     │   │
│  │  - Next consolidation cycle removes matching entries         │   │
│  └─────────────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  maybe_trigger_eviction()                                    │   │
│  │  - Uses eviction_trigger_percent (default 95%)               │   │
│  │  - Triggers when current_size > max_size * trigger%          │   │
│  └─────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         CacheConfig                                  │
│  - eviction_trigger_percent: u8 (default: 95, range: 50-100)        │
│  - eviction_target_percent: u8 (default: 80, range: 50-99)          │
└─────────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. CacheConfig Changes

```rust
/// Cache configuration (in src/config.rs)
pub struct CacheConfig {
    // ... existing fields ...
    
    /// Percentage of max_cache_size at which eviction triggers (default: 95)
    /// Valid range: 50-100
    #[serde(default = "default_eviction_trigger_percent")]
    pub eviction_trigger_percent: u8,
    
    /// Percentage of max_cache_size to reduce to after eviction (default: 80)
    /// Valid range: 50-99, must be less than eviction_trigger_percent
    #[serde(default = "default_eviction_target_percent")]
    pub eviction_target_percent: u8,
}

fn default_eviction_trigger_percent() -> u8 { 95 }
fn default_eviction_target_percent() -> u8 { 80 }
```

### 2. ConsolidationConfig Changes

```rust
/// Configuration for journal consolidation (in src/journal_consolidator.rs)
pub struct ConsolidationConfig {
    // ... existing fields ...
    
    /// Percentage of max_cache_size at which eviction triggers (default: 95)
    pub eviction_trigger_percent: u8,
    
    /// Percentage of max_cache_size to reduce to after eviction (default: 80)
    pub eviction_target_percent: u8,
    
    /// Timeout for stale journal entries in seconds (default: 300 = 5 minutes)
    pub stale_entry_timeout_secs: u64,
}
```

### 3. JournalConsolidator New Methods

```rust
impl JournalConsolidator {
    /// Validate journal entries, removing stale entries based on timestamp
    /// 
    /// An entry is considered stale if:
    /// 1. The range file doesn't exist, AND
    /// 2. The entry's timestamp is older than stale_entry_timeout_secs
    pub async fn validate_journal_entries_with_staleness(
        &self,
        entries: &[JournalEntry],
    ) -> (Vec<JournalEntry>, Vec<JournalEntry>) {
        // Returns (valid_entries, stale_entries_to_remove)
    }
    
    /// Atomically subtract bytes from size state with retry and exponential backoff
    /// 
    /// Retries up to 3 times with delays of 100ms, 200ms, 400ms (with ±20% jitter)
    pub async fn atomic_subtract_size_with_retry(&self, bytes_freed: u64) -> Result<u64> {
        // Implementation with retry logic
    }
    
    /// Mark ranges as evicted for immediate journal cleanup
    /// 
    /// Called by CacheManager after eviction completes.
    /// Entries matching these ranges will be removed in the next consolidation cycle.
    pub fn mark_ranges_evicted(&self, evicted_ranges: Vec<(String, u64, u64)>) {
        // Store in memory for next consolidation cycle
    }
}
```

### 4. CacheManager Changes

```rust
impl CacheManager {
    /// Perform eviction while holding the lock
    /// 
    /// Modified to:
    /// 1. Collect evicted ranges during eviction
    /// 2. Call mark_ranges_evicted() after eviction
    /// 3. Use atomic_subtract_size_with_retry() for size updates
    async fn perform_eviction_with_lock(
        &self,
        current_size: u64,
        max_size: u64,
        skip_pre_eviction_consolidation: bool,
    ) -> Result<u64> {
        // Calculate target using eviction_target_percent
        let target_size = (max_size as f64 * (self.eviction_target_percent as f64 / 100.0)) as u64;
        
        // ... eviction logic, collecting evicted_ranges ...
        
        // Notify consolidator of evicted ranges
        if let Some(consolidator) = self.journal_consolidator.read().await.as_ref() {
            consolidator.mark_ranges_evicted(evicted_ranges);
        }
        
        // Update size state with retry
        // ...
    }
}
```

## Data Models

### Evicted Range Tracking

```rust
/// Tracks ranges that were evicted for immediate journal cleanup
/// Stored in JournalConsolidator as in-memory state (per-instance)
struct EvictedRangeTracker {
    /// Ranges evicted by this instance, keyed by cache_key
    /// Value is Vec<(start, end)> for the evicted ranges
    evicted_ranges: HashMap<String, Vec<(u64, u64)>>,
}
```

### Retry Configuration

```rust
/// Retry configuration for atomic_subtract_size
const RETRY_MAX_ATTEMPTS: u32 = 3;
const RETRY_BASE_DELAY_MS: u64 = 100;
const RETRY_JITTER_PERCENT: f64 = 0.2;  // ±20%
```



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Stale Entry Detection Based on Timestamp

*For any* journal entry where the range file doesn't exist, the entry SHALL be removed if and only if `entry.timestamp + 5 minutes < current_time`. Entries younger than 5 minutes with missing range files SHALL be retained (may still be streaming).

**Validates: Requirements 1.1, 1.3, 1.6**

### Property 2: Retry with Exponential Backoff and Jitter

*For any* sequence of `atomic_subtract_size()` failures, the system SHALL retry up to 3 times with delays that follow exponential backoff (base delays 100ms, 200ms, 400ms) and include jitter within ±20% of the base delay.

**Validates: Requirements 2.1, 2.2, 2.4**

### Property 3: Eviction Triggers at Configured Threshold

*For any* cache state where `current_size > max_size * (eviction_trigger_percent / 100)`, the system SHALL trigger eviction. For cache states at or below this threshold, eviction SHALL NOT be triggered.

**Validates: Requirements 3.3**

### Property 4: Eviction Targets Configured Percentage

*For any* eviction operation, the target size SHALL be calculated as `max_size * (eviction_target_percent / 100)`. The eviction SHALL attempt to free bytes until `current_size <= target_size`.

**Validates: Requirements 3.4**

### Property 5: Threshold Validation and Clamping

*For any* `eviction_trigger_percent` value, it SHALL be clamped to the range [50, 100]. *For any* `eviction_target_percent` value, it SHALL be clamped to the range [50, 99]. *For any* configuration where `eviction_target_percent >= eviction_trigger_percent`, the target SHALL be set to `eviction_trigger_percent - 10`.

**Validates: Requirements 3.5, 3.6, 3.7, 3.8, 3.9**

### Property 6: Evicted Ranges Bypass Timeout

*For any* journal entry whose (cache_key, start, end) matches a range that was just evicted, the entry SHALL be removed immediately regardless of its timestamp (bypassing the 5-minute timeout).

**Validates: Requirements 4.1, 4.3**

## Error Handling

### Lock Acquisition Failures

When `atomic_subtract_size()` fails to acquire the size state lock:
1. Log warning with attempt number and error details
2. Apply jittered exponential backoff delay
3. Retry up to 3 times
4. If all retries fail, log error with bytes that failed to subtract
5. Return error to caller (eviction still succeeds, but size state may drift)

### I/O Errors During Size State Update

When reading or writing size state fails:
1. Same retry logic as lock failures
2. If persistent, the next validation scan will correct the drift
3. Log error with specific I/O error details

### Missing Consolidator Reference

When eviction completes but consolidator is not available:
1. Log debug message (not an error - consolidator may not be initialized yet)
2. Skip `mark_ranges_evicted()` call
3. Stale entries will be cleaned up via timestamp-based detection (5-minute timeout)

### Invalid Configuration Values

When eviction thresholds are outside valid ranges:
1. Log warning with the invalid value and the clamped value
2. Clamp to valid range and continue
3. Do not fail startup - use corrected values

## Testing Strategy

### Unit Tests

1. **Stale entry detection**: Test `validate_journal_entries_with_staleness()` with entries at various ages
2. **Retry logic**: Test `atomic_subtract_size_with_retry()` with simulated failures
3. **Threshold validation**: Test `CacheConfig::validate()` with boundary values
4. **Target calculation**: Test eviction target calculation with various percentages

### Property-Based Tests

Property-based tests will use the `quickcheck` library with minimum 100 iterations per test.

1. **Staleness detection property**: Generate random journal entries with random timestamps, verify correct staleness classification
2. **Retry delay property**: Generate random failure sequences, verify delays follow exponential backoff with jitter
3. **Threshold clamping property**: Generate random threshold values, verify clamping behavior
4. **Eviction trigger property**: Generate random cache sizes and thresholds, verify correct trigger decisions

### Integration Tests

1. **End-to-end eviction with journal cleanup**: Fill cache, trigger eviction, verify journal entries are cleaned up
2. **Multi-instance coordination**: Run multiple instances, verify size state remains consistent after eviction
3. **Configuration propagation**: Verify thresholds flow from CacheConfig to ConsolidationConfig

### Test Configuration

- Property tests: 100+ iterations each
- Tag format: **Feature: eviction-and-journal-cleanup-fixes, Property N: {property_text}**
