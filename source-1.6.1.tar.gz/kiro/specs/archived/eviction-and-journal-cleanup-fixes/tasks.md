# Implementation Plan: Eviction and Journal Cleanup Fixes

## Overview

This implementation adds timeout-based stale journal entry cleanup, retry logic for size state updates, configurable eviction thresholds, and eviction notification to the journal consolidator. Changes span config.rs, journal_consolidator.rs, and cache.rs.

## Tasks

- [x] 1. Add configurable eviction thresholds to CacheConfig
  - [x] 1.1 Add `eviction_trigger_percent` and `eviction_target_percent` fields to CacheConfig
    - Add fields with default functions (95% and 80%)
    - Add serde attributes for deserialization
    - Update Default impl for CacheConfig
    - _Requirements: 3.1, 3.2_
  
  - [x] 1.2 Add validation for eviction threshold fields
    - Validate trigger is in range 50-100, clamp if outside
    - Validate target is in range 50-99, clamp if outside
    - Validate target < trigger, set target = trigger - 10 if violated
    - Log warnings for any clamped values
    - _Requirements: 3.5, 3.6, 3.7, 3.8, 3.9_
  
  - [x] 1.3 Write property test for threshold validation and clamping
    - **Property 5: Threshold Validation and Clamping**
    - **Validates: Requirements 3.5, 3.6, 3.7, 3.8, 3.9**

- [x] 2. Update ConsolidationConfig to receive eviction thresholds
  - [x] 2.1 Add eviction threshold fields to ConsolidationConfig
    - Add `eviction_trigger_percent: u8` field
    - Add `eviction_target_percent: u8` field
    - Add `stale_entry_timeout_secs: u64` field (default 300)
    - Update Default impl
    - _Requirements: 3.10, 1.5_
  
  - [x] 2.2 Update CacheManager to pass thresholds to ConsolidationConfig
    - Modify `create_configured_disk_cache_manager()` to pass thresholds
    - _Requirements: 3.10_

- [x] 3. Implement stale journal entry cleanup
  - [x] 3.1 Add `validate_journal_entries_with_staleness()` method to JournalConsolidator
    - Check if range file exists
    - If not, check if entry.timestamp + stale_timeout < now
    - Return tuple of (valid_entries, stale_entries_to_remove)
    - Log removed stale entries with cache_key, range, and age
    - _Requirements: 1.1, 1.2, 1.3, 1.4_
  
  - [x] 3.2 Update `consolidate_object()` to use new validation method
    - Replace call to `validate_journal_entries()` with `validate_journal_entries_with_staleness()`
    - Remove stale entries from journal after consolidation
    - _Requirements: 1.1_
  
  - [x] 3.3 Write property test for stale entry detection
    - **Property 1: Stale Entry Detection Based on Timestamp**
    - **Validates: Requirements 1.1, 1.3, 1.6**

- [x] 4. Implement retry logic for size state updates
  - [x] 4.1 Add `atomic_subtract_size_with_retry()` method to JournalConsolidator
    - Implement retry loop with max 3 attempts
    - Calculate delays with exponential backoff (100ms, 200ms, 400ms)
    - Add jitter (±20%) to delays
    - Log warning on each retry, error if all fail
    - _Requirements: 2.1, 2.2, 2.3, 2.4_
  
  - [x] 4.2 Update eviction code to use retry method
    - Replace `atomic_subtract_size()` calls with `atomic_subtract_size_with_retry()`
    - _Requirements: 2.1_
  
  - [x] 4.3 Write property test for retry with exponential backoff
    - **Property 2: Retry with Exponential Backoff and Jitter**
    - **Validates: Requirements 2.1, 2.2, 2.4**

- [x] 5. Update eviction trigger logic
  - [x] 5.1 Update `maybe_trigger_eviction()` to use configurable threshold
    - Change condition from `current_size > max_size` to `current_size > max_size * trigger_percent / 100`
    - _Requirements: 3.3_
  
  - [x] 5.2 Update `perform_eviction_with_lock()` to use configurable target
    - Change target calculation from `max_size * 0.8` to `max_size * target_percent / 100`
    - _Requirements: 3.4_
  
  - [x] 5.3 Write property test for eviction trigger threshold
    - **Property 3: Eviction Triggers at Configured Threshold**
    - **Validates: Requirements 3.3**
  
  - [x] 5.4 Write property test for eviction target percentage
    - **Property 4: Eviction Targets Configured Percentage**
    - **Validates: Requirements 3.4**

- [x] 6. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Implement eviction notification to journal consolidator
  - [x] 7.1 Add `mark_ranges_evicted()` method to JournalConsolidator
    - Add `evicted_ranges: Mutex<HashMap<String, Vec<(u64, u64)>>>` field
    - Implement method to store evicted ranges
    - _Requirements: 4.2_
  
  - [x] 7.2 Update `validate_journal_entries_with_staleness()` to check evicted ranges
    - Check if entry matches any evicted range
    - If so, mark as stale immediately (bypass timeout)
    - Clear matched evicted ranges after processing
    - _Requirements: 4.3_
  
  - [x] 7.3 Update `perform_eviction_with_lock()` to collect and notify evicted ranges
    - Collect (cache_key, start, end) for each deleted range
    - Call `mark_ranges_evicted()` after eviction completes
    - Handle case where consolidator is not available
    - _Requirements: 4.1, 4.2, 4.4_
  
  - [x] 7.4 Write property test for evicted ranges bypass timeout
    - **Property 6: Evicted Ranges Bypass Timeout**
    - **Validates: Requirements 4.1, 4.3**

- [x] 8. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- All tasks are required for comprehensive implementation
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
