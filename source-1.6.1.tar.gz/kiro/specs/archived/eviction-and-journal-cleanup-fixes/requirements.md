# Requirements Document

## Introduction

This feature addresses issues discovered during v1.1.9 testing where journal entries for evicted ranges accumulate indefinitely, size tracking becomes inaccurate after eviction failures, and eviction triggers only at 100% capacity leaving no headroom. The fixes improve cache reliability and reduce wasted CPU cycles from processing stale journal entries.

## Glossary

- **Journal_Entry**: A record in the journal file tracking a cache operation (Add, Remove, Update, TtlRefresh, AccessUpdate)
- **Journal_Consolidator**: Background process that consolidates journal entries into metadata files and tracks cache size
- **Range_File**: A `.bin` file containing cached data for a specific byte range of an S3 object
- **Size_State**: Persistent JSON file tracking total cache size, updated by the consolidator
- **Eviction**: Process of removing cached ranges to free disk space when cache exceeds capacity
- **Stale_Entry**: A journal entry referencing a range file that no longer exists and whose timestamp is older than the timeout threshold
- **Eviction_Trigger_Threshold**: Percentage of max cache capacity at which eviction starts (configurable, default 95%)
- **Eviction_Target**: Percentage of max cache capacity to reduce to after eviction (80%)

## Requirements

### Requirement 1: Timeout-Based Stale Journal Entry Cleanup

**User Story:** As a cache operator, I want stale journal entries to be automatically removed after a timeout, so that the consolidator doesn't waste CPU cycles processing entries for evicted ranges.

#### Acceptance Criteria

1. WHEN a journal entry has been invalid (range file doesn't exist) AND the entry's timestamp is older than 5 minutes, THEN THE Journal_Consolidator SHALL remove the entry from the journal
2. THE Journal_Consolidator SHALL use the existing `timestamp` field in JournalEntry to determine entry age
3. WHEN validating entries, THE Journal_Consolidator SHALL compare `entry.timestamp + 5 minutes` against current time to detect stale entries
4. THE Journal_Consolidator SHALL log when stale entries are removed, including the cache_key, range, and age of the entry
5. THE timeout threshold of 5 minutes SHALL be sufficient to handle NFS attribute caching delays during normal streaming operations
6. THE stale entry detection SHALL work correctly across multiple proxy instances since it uses the entry's own timestamp (no cross-instance state required)

### Requirement 2: Retry Size State Updates on Eviction

**User Story:** As a cache operator, I want size state updates to be retried on transient failures, so that eviction doesn't cause size tracking drift.

#### Acceptance Criteria

1. WHEN `atomic_subtract_size()` fails due to lock timeout or I/O error, THEN THE Journal_Consolidator SHALL retry with exponential backoff
2. THE Journal_Consolidator SHALL retry up to 3 times with delays of 100ms, 200ms, and 400ms
3. IF all retries fail, THEN THE Journal_Consolidator SHALL log an error with the bytes that failed to subtract
4. THE retry mechanism SHALL use jitter (±20%) to prevent thundering herd when multiple instances retry simultaneously

### Requirement 3: Configurable Eviction Thresholds

**User Story:** As a cache operator, I want to configure when eviction starts and what target it aims for, so that I can tune cache behavior for my workload.

#### Acceptance Criteria

1. THE CacheConfig SHALL include an `eviction_trigger_percent` field with default value of 95
2. THE CacheConfig SHALL include an `eviction_target_percent` field with default value of 80
3. WHEN cache size exceeds `eviction_trigger_percent` of max_cache_size, THEN THE system SHALL trigger eviction
4. WHEN eviction runs, THE system SHALL aim to reduce cache size to `eviction_target_percent` of max_cache_size
5. THE `eviction_trigger_percent` SHALL be configurable in the range 50-100
6. THE `eviction_target_percent` SHALL be configurable in the range 50-99
7. IF `eviction_trigger_percent` is set outside 50-100, THEN THE system SHALL log a warning and clamp to the valid range
8. IF `eviction_target_percent` is set outside 50-99, THEN THE system SHALL log a warning and clamp to the valid range
9. IF `eviction_target_percent` >= `eviction_trigger_percent`, THEN THE system SHALL log a warning and set target to trigger - 10
10. THE ConsolidationConfig SHALL receive both eviction thresholds from CacheConfig during initialization

### Requirement 4: Eviction Notification to Journal Consolidator

**User Story:** As a system component, I want the eviction process to notify the journal consolidator of evicted ranges, so that related journal entries can be cleaned up promptly.

#### Acceptance Criteria

1. WHEN eviction deletes a range file, THEN THE CacheManager SHALL record the (cache_key, start, end) of the deleted range
2. AFTER eviction completes, THE CacheManager SHALL call a method on Journal_Consolidator to mark these ranges as evicted
3. THE Journal_Consolidator SHALL immediately mark journal entries for evicted ranges as stale (bypassing the 5-minute timeout)
4. THE eviction notification mechanism SHALL be optional - if the consolidator is not available, eviction SHALL proceed without notification
