# Implementation Plan

- [ ] 1. Add helper function to update Content-Length header
  - Create `update_content_length_in_headers` function in `signed_put_handler.rs`
  - Parse headers into HashMap
  - Update Content-Length value (case-insensitive match)
  - Return updated HashMap
  - _Requirements: 2.1, 2.2, 2.3_

- [ ]* 1.1 Write unit tests for header update function
  - Test updating Content-Length with various case variations
  - Test preserving all other headers
  - Test handling missing Content-Length
  - Test handling malformed Content-Length
  - _Requirements: 2.1, 2.2, 2.3, 4.2, 4.3_

- [ ] 2. Track body size changes in handle_upload_part
  - Add variable to track original body size before stripping
  - Add variable to track body size after stripping
  - Add flag to indicate if body was modified
  - _Requirements: 1.1, 3.1_

- [ ] 3. Update Content-Length after stripping chunked encoding
  - After chunked encoding strip, check if body size changed
  - If changed, call `update_content_length_in_headers` with new size
  - Store updated headers for use in raw request building
  - Log the Content-Length update at DEBUG level
  - _Requirements: 1.1, 1.4, 2.2, 3.2_

- [ ] 4. Use updated headers when building raw HTTP request
  - Replace direct header iteration with updated headers HashMap
  - Ensure Content-Length is written with correct value
  - Preserve all other headers exactly
  - _Requirements: 1.2, 2.1, 2.4_

- [ ] 5. Add comprehensive logging for debugging
  - Log original Content-Length value before update
  - Log new Content-Length value after update
  - Log body sizes (original, stripped, header value) at DEBUG level
  - Add WARNING log if sizes still don't match after update
  - _Requirements: 1.3, 3.1, 3.2, 3.3, 3.4_

- [ ]* 5.1 Write property test for Content-Length accuracy
  - **Property 1: Content-Length matches body size**
  - **Validates: Requirements 1.1, 1.2**

- [ ] 6. Add edge case handling
  - Handle requests without Content-Length header gracefully
  - Handle requests without chunked encoding (no modification)
  - Handle Content-Length parse failures
  - _Requirements: 4.1, 4.2, 4.3, 4.4_

- [ ]* 6.1 Write property test for header preservation
  - **Property 2: Header preservation**
  - **Validates: Requirements 2.1**

- [ ]* 6.2 Write property test for no unnecessary modification
  - **Property 3: No modification when unnecessary**
  - **Validates: Requirements 4.1**

- [ ] 7. Test with actual AWS CLI multipart upload
  - Clear cache and restart proxy
  - Upload 500MB file using AWS CLI
  - Verify no 400 Bad Request errors
  - Verify all parts upload successfully
  - Verify cached ranges have correct sizes (8388608 bytes for 8MB parts)
  - _Requirements: 1.1, 1.2, 3.4_

- [ ] 8. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
