# Design Document

## Overview

This design addresses the Content-Length header mismatch bug that occurs when the proxy strips chunked transfer encoding from AWS CLI multipart upload requests. The current implementation correctly strips the chunked encoding wrapper (reducing body size by 10 bytes) but fails to update the Content-Length header, causing S3 to reject requests with 400 Bad Request errors.

## Architecture

The fix will be implemented in the `handle_upload_part` method of `SignedPutHandler` in `src/signed_put_handler.rs`. The solution involves:

1. Detecting when chunked encoding is stripped (already implemented)
2. Parsing the existing Content-Length header from the request
3. Updating the Content-Length header value to match the stripped body size
4. Rebuilding the raw HTTP request with the corrected header

## Components and Interfaces

### Modified Component: SignedPutHandler::handle_upload_part

**Current Flow:**
1. Read request body with `body.collect().await`
2. Strip chunked encoding if detected (reduces body by ~10 bytes)
3. Build raw HTTP request with original headers
4. Forward to S3 → **FAILS: Content-Length mismatch**

**New Flow:**
1. Read request body with `body.collect().await`
2. Strip chunked encoding if detected
3. **NEW:** Track original and new body sizes
4. **NEW:** Parse and update Content-Length header
5. Build raw HTTP request with corrected Content-Length
6. Forward to S3 → **SUCCESS**

### Helper Function: update_content_length_header

```rust
fn update_content_length_in_headers(
    headers: &hyper::HeaderMap,
    new_length: usize
) -> HashMap<String, String>
```

**Purpose:** Extract headers and update Content-Length value

**Parameters:**
- `headers`: Original request headers
- `new_length`: Corrected body size after stripping chunked encoding

**Returns:** HashMap with all headers, Content-Length updated

## Data Models

### Size Tracking Structure

```rust
struct BodySizeInfo {
    original_size: usize,      // Size with chunked encoding
    stripped_size: usize,      // Size after stripping
    content_length_header: usize, // Value from Content-Length header
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Content-Length matches body size

*For any* UploadPart request where chunked encoding is stripped, the Content-Length header in the forwarded request SHALL equal the actual body size in bytes.

**Validates: Requirements 1.1, 1.2**

### Property 2: Header preservation

*For any* UploadPart request, all headers except Content-Length SHALL be preserved exactly as received when forwarding to S3.

**Validates: Requirements 2.1**

### Property 3: No modification when unnecessary

*For any* UploadPart request without chunked encoding, the Content-Length header SHALL remain unchanged.

**Validates: Requirements 4.1**

## Error Handling

### Content-Length Parse Failure

**Scenario:** Content-Length header is malformed or missing

**Handling:**
- Log error with details
- Forward request unchanged
- Let S3 handle the invalid request

### Chunked Encoding Detection Failure

**Scenario:** Body appears to have chunked encoding but parsing fails

**Handling:**
- Log warning
- Forward request with original body and headers
- Existing behavior (already implemented)

### Size Mismatch Detection

**Scenario:** After stripping, body size still doesn't match Content-Length

**Handling:**
- Log warning with all three sizes (original, stripped, header value)
- Update Content-Length to match actual body size
- Forward request

## Testing Strategy

### Unit Tests

1. Test Content-Length header update with valid input
2. Test header preservation (all headers except Content-Length unchanged)
3. Test handling of missing Content-Length header
4. Test handling of malformed Content-Length header
5. Test no modification when chunked encoding not present

### Property-Based Tests

Property-based testing will use the `quickcheck` crate (already in use).

**Property Test 1: Content-Length accuracy**
- Generate random body sizes and chunked encoding wrappers
- Strip encoding and update Content-Length
- Verify Content-Length matches actual body size

**Property Test 2: Header preservation**
- Generate random header sets
- Update Content-Length
- Verify all other headers unchanged

### Integration Tests

1. Test actual multipart upload through proxy with AWS CLI
2. Verify S3 accepts the request (200 OK response)
3. Verify cached part has correct size (8388608 bytes for 8MB parts)
4. Verify finalized multipart upload creates correct range files

## Implementation Notes

### Content-Length Header Format

HTTP/1.1 specification requires:
```
Content-Length: <decimal-number>\r\n
```

The header name is case-insensitive, so we must handle:
- `Content-Length`
- `content-length`
- `CONTENT-LENGTH`

### Raw HTTP Request Building

Current code builds raw request as:
```rust
raw_request.extend_from_slice(
    format!("{} {} {:?}\r\n", method, path_and_query, version).as_bytes(),
);

for (name, value) in headers.iter() {
    raw_request.extend_from_slice(
        format!("{}: {}\r\n", name.as_str(), value_str).as_bytes(),
    );
}

raw_request.extend_from_slice(b"\r\n");
raw_request.extend_from_slice(&body_bytes);
```

**Fix:** Update Content-Length before building raw request:
```rust
// After stripping chunked encoding
let corrected_headers = if body_was_modified {
    update_content_length_in_headers(&headers, body_bytes.len())
} else {
    // Convert to HashMap without modification
    headers_to_map(&headers)
};

// Build raw request with corrected headers
for (name, value) in corrected_headers.iter() {
    raw_request.extend_from_slice(
        format!("{}: {}\r\n", name, value).as_bytes(),
    );
}
```

## Logging Strategy

### DEBUG Level
- Original Content-Length value
- New Content-Length value
- Body size before and after stripping

### INFO Level
- Confirmation of successful Content-Length update
- Successful forwarding with corrected header

### WARN Level
- Content-Length mismatch detected
- Failed to parse Content-Length header

### ERROR Level
- S3 returns 400 Bad Request (existing)
- Critical failures in header processing
