# Requirements Document

## Introduction

This specification addresses a critical bug in the S3 proxy's handling of AWS CLI multipart uploads. The proxy currently strips chunked transfer encoding from request bodies (correctly reducing body size from 8388618 to 8388608 bytes) but fails to update the Content-Length header before forwarding to S3. This causes S3 to reject uploads with 400 Bad Request errors because the Content-Length header (8388662 bytes) doesn't match the actual body size (8388608 bytes).

## Glossary

- **Proxy**: The S3 proxy server that intercepts and caches S3 requests
- **AWS CLI**: Amazon Web Services command-line interface that sends multipart uploads with chunked encoding
- **Chunked Encoding**: HTTP transfer encoding where data is sent in chunks with size prefixes (format: `<hex-size>\r\n<data>\r\n`)
- **Content-Length Header**: HTTP header specifying the exact size of the request body in bytes
- **S3**: Amazon Simple Storage Service, the upstream storage service
- **UploadPart**: A single part in a multipart upload operation

## Requirements

### Requirement 1

**User Story:** As a proxy operator, I want multipart uploads to succeed when the AWS CLI sends chunked-encoded bodies, so that large file uploads work reliably through the proxy.

#### Acceptance Criteria

1. WHEN the Proxy strips chunked encoding from an UploadPart request body THEN the Proxy SHALL update the Content-Length header to match the stripped body size
2. WHEN the Proxy forwards an UploadPart request to S3 THEN the Content-Length header SHALL exactly match the actual body size in bytes
3. WHEN the Proxy receives a 400 Bad Request from S3 due to Content-Length mismatch THEN the Proxy SHALL log the mismatch details for debugging
4. WHEN the Proxy successfully updates the Content-Length header THEN the Proxy SHALL log the old and new values at DEBUG level

### Requirement 2

**User Story:** As a developer, I want the proxy to correctly parse and rebuild HTTP headers when modifying request bodies, so that AWS signature validation doesn't break.

#### Acceptance Criteria

1. WHEN the Proxy rebuilds the raw HTTP request THEN the Proxy SHALL preserve all original headers except Content-Length
2. WHEN the Proxy updates the Content-Length header THEN the Proxy SHALL format it as `Content-Length: <size>` with proper CRLF line endings
3. WHEN the Proxy encounters multiple Content-Length headers THEN the Proxy SHALL replace all occurrences with the corrected value
4. WHEN the Proxy modifies headers THEN the Proxy SHALL maintain HTTP/1.1 specification compliance

### Requirement 3

**User Story:** As a system administrator, I want detailed logging of body size transformations, so that I can diagnose upload failures and verify correct operation.

#### Acceptance Criteria

1. WHEN the Proxy strips chunked encoding THEN the Proxy SHALL log the original body size, stripped body size, and size difference
2. WHEN the Proxy updates Content-Length THEN the Proxy SHALL log the original header value and new header value
3. WHEN the Proxy detects a Content-Length mismatch before forwarding THEN the Proxy SHALL log a WARNING with all relevant sizes
4. WHEN the Proxy successfully forwards a request with updated Content-Length THEN the Proxy SHALL log confirmation at INFO level

### Requirement 4

**User Story:** As a proxy operator, I want the fix to handle edge cases gracefully, so that the proxy remains stable under various conditions.

#### Acceptance Criteria

1. WHEN the Proxy receives a request without chunked encoding THEN the Proxy SHALL forward it unchanged with original Content-Length
2. WHEN the Proxy receives a request without a Content-Length header THEN the Proxy SHALL handle it gracefully without errors
3. WHEN the Proxy fails to parse the Content-Length header THEN the Proxy SHALL log an error and forward the request unchanged
4. WHEN the Proxy strips chunked encoding but the result matches Content-Length THEN the Proxy SHALL not modify the header
