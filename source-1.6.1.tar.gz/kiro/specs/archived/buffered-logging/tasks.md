# Tasks: Buffered Logging and Size Tracking

## Task 1: Implement SizeDeltaBuffer

- [x] 1.1 Create `SizeDeltaBuffer` struct in `src/cache_size_tracker.rs`
  - Add `pending_delta: AtomicI64` for accumulating deltas
  - Add `pending_write_delta: AtomicI64` for write cache deltas
  - Add `flush_interval`, `last_flush`, `flush_in_progress` fields
  - Add `instance_id` and `cache_dir` fields

- [x] 1.2 Implement `SizeDeltaBuffer` methods
  - `new(cache_dir, instance_id)` constructor
  - `record_delta(delta)` - atomic add to pending_delta
  - `record_write_delta(delta)` - atomic add to pending_write_delta
  - `should_flush()` - check if flush interval exceeded
  - `flush()` - write accumulated deltas to per-instance file
  - `force_flush()` - immediate flush for shutdown

- [x] 1.3 Implement per-instance delta file writing
  - Path: `size_tracking/delta-{instance_id}.log`
  - Format: `+/-{delta}\n` and `W:+/-{delta}\n` for write cache
  - Use atomic temp+rename for durability
  - Clear pending deltas after successful write

- [x] 1.4 Update `CacheSizeTracker` to use `SizeDeltaBuffer`
  - Replace direct `try_append_delta()` calls with `delta_buffer.record_delta()`
  - Replace `try_append_write_cache_delta()` with `delta_buffer.record_write_delta()`
  - Add periodic flush check in checkpoint loop
  - Flush delta buffer before writing checkpoint

## Task 2: Implement Delta Recovery from Per-Instance Files

- [x] 2.1 Implement `read_all_delta_files()` in `CacheSizeTracker`
  - Scan `size_tracking/` directory for `delta-*.log` files
  - Parse each file and sum deltas (both regular and write cache)
  - Return total delta and write cache delta

- [x] 2.2 Update `recover()` method
  - Read checkpoint
  - Call `read_all_delta_files()` to get deltas from all instances
  - Sum checkpoint + all deltas for recovered size
  - Remove old single-file delta.log handling

- [x] 2.3 Update checkpoint writing to clean up delta files
  - After writing checkpoint, truncate current instance's delta file
  - Optionally remove stale delta files from crashed instances (based on age)

## Task 3: Implement AccessLogBuffer

- [x] 3.1 Create `AccessLogBuffer` struct in `src/logging.rs`
  - Add `buffer: Arc<Mutex<Vec<AccessLogEntry>>>`
  - Add `log_dir`, `hostname` fields
  - Add `flush_interval`, `max_buffer_size` fields
  - Add `last_flush`, `flush_in_progress` fields

- [x] 3.2 Implement `AccessLogBuffer` methods
  - `new(log_dir, hostname, flush_interval, max_buffer_size)` constructor
  - `log(entry)` - add to buffer, check if flush needed
  - `maybe_flush()` - flush if interval exceeded or buffer full
  - `flush()` - write all entries to file
  - `force_flush()` - immediate flush for shutdown

- [x] 3.3 Implement buffered file writing
  - Maintain existing date-partitioned directory structure
  - Batch write all entries in single file operation
  - Use S3-compatible log format (existing `format_entry()`)
  - Use atomic temp+rename for durability

- [x] 3.4 Update `LoggerManager` to use `AccessLogBuffer`
  - Replace `AccessLogWriter` with `AccessLogBuffer`
  - Update `log_access()` to use buffer
  - Add `force_flush()` call in shutdown path

## Task 4: Add Configuration Options

- [x] 4.1 Add logging buffer configuration to `LoggingConfig`
  - `access_log_flush_interval: Duration` (default: 5s)
  - `access_log_buffer_size: usize` (default: 1000)
  - Add default functions and serde attributes

- [x] 4.2 Add size tracking buffer configuration to `CacheSizeConfig`
  - `size_tracking_flush_interval: Duration` (default: 5s)
  - `size_tracking_buffer_size: usize` (default: 10000)
  - Add default functions and serde attributes

- [x] 4.3 Wire configuration to buffer constructors
  - Pass config values to `AccessLogBuffer::new()`
  - Pass config values to `SizeDeltaBuffer::new()`

## Task 5: Implement Shutdown Coordination

- [x] 5.1 Add flush coordination to graceful shutdown
  - Flush `AccessLogBuffer` before shutdown
  - Flush `SizeDeltaBuffer` before shutdown
  - Write final checkpoint after delta flush
  - Log flush results

- [x] 5.2 Handle flush errors during shutdown
  - Log warnings for failed flushes
  - Continue shutdown even if flush fails
  - Report number of entries lost (if any)

## Task 6: Testing

- [x] 6.1 Unit tests for `SizeDeltaBuffer`
  - Test delta accumulation
  - Test flush writes correct format
  - Test per-instance file naming
  - Test flush timing logic

- [x] 6.2 Unit tests for `AccessLogBuffer`
  - Test entry buffering
  - Test flush writes correct format
  - Test buffer size limit triggers flush
  - Test flush timing logic

- [x] 6.3 Integration tests for delta recovery
  - Test recovery with multiple instance delta files
  - Test recovery with checkpoint + deltas
  - Test stale delta file handling

- [x] 6.4 Property-based tests
  - Property 1: Real-time size tracking accuracy
  - Property 2: Crash recovery completeness
  - Property 5: Per-instance isolation

## Task 7: Cleanup

- [x] 7.1 Remove old delta log code
  - Remove `try_append_delta()` method
  - Remove `try_append_write_cache_delta()` method
  - Remove single-file `delta_log_path` handling
  - Update `read_delta_log()` to use new format

- [x] 7.2 Remove `AccessLogWriter`
  - Remove struct and impl
  - Update any references to use `AccessLogBuffer`

- [x] 7.3 Remove or update obsolete tests
  - Remove tests for `try_append_delta()` synchronous behavior
  - Remove tests for single-file delta log format
  - Remove tests for `AccessLogWriter` direct writes
  - Update any tests that depend on immediate disk writes


## Task 8: Documentation and Release

- [x] 8.1 Update ARCHITECTURE.md
  - Add buffered logging to system architecture diagram
  - Document per-instance file strategy for shared storage

- [x] 8.2 Update CONFIGURATION.md
  - Document new `access_log_flush_interval` option
  - Document new `access_log_buffer_size` option
  - Document new `size_tracking_flush_interval` option
  - Document new `size_tracking_buffer_size` option

- [x] 8.3 Update config.example.yaml
  - Add new configuration options with comments

- [x] 8.4 Update CHANGELOG.md
  - Add entry for buffered access logging
  - Add entry for buffered size delta tracking
  - Note performance improvement for shared storage deployments

- [x] 8.5 Increment version in Cargo.toml
  - Bump minor version (feature addition)

## Task 9: Code Quality

- [x] 9.1 Run `cargo clippy` and fix warnings
  - Address any new warnings from added code
  - Ensure no clippy warnings in modified files

- [x] 9.2 Check for dead code
  - Run `cargo build --release 2>&1 | grep "warning: unused"`
  - Remove any unused functions, structs, or imports
  - Verify removed `AccessLogWriter` has no remaining references

- [x] 9.3 Run full test suite
  - `cargo test --release`
  - Verify no regressions in existing tests
  - Ensure all new tests pass

- [x] 9.4 Verify build with all features
  - `cargo build --release`
  - Check binary size is reasonable
  - Verify no new dependencies added unnecessarily
