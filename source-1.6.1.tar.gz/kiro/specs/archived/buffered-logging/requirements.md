# Requirements: Buffered Logging and Size Tracking

## Introduction

This feature optimizes disk I/O for shared filesystem deployments by buffering writes for access logs (SAL) and cache size delta tracking. Currently, both systems write synchronously per operation, which creates performance bottlenecks on NFS with multiple proxy instances.

**Problem Statement:**
- Access logs: 1 file open + write + flush per request
- Size delta log: 1 file open + write + flush per cache size change
- At 1000 requests/s across 4 nodes: 4000+ disk operations/s on shared storage
- NFS latency (1-10ms per operation) causes I/O wait and potential write failures

**Solution:**
- Buffer writes in RAM using the same pattern as `CacheHitUpdateBuffer`
- Flush periodically (every 5 seconds) or when buffer is full
- Use per-instance files to eliminate cross-node contention

## Glossary

- **SAL**: Server Access Log - S3-compatible access log format
- **Delta_Log**: File tracking incremental cache size changes between checkpoints
- **Flush_Interval**: Time between RAM buffer flushes to disk (default: 5 seconds)
- **Per_Instance_File**: File named with instance ID to avoid cross-node write contention

## Requirements

### Requirement 1: Buffered Access Logging

**User Story:** As a proxy operator running multiple instances on shared storage, I want access logs to be buffered in RAM and flushed periodically, so that logging doesn't create I/O bottlenecks.

#### Acceptance Criteria

1. THE Proxy SHALL buffer access log entries in RAM before writing to disk
2. THE Proxy SHALL flush the access log buffer every 5 seconds OR when the buffer reaches 1000 entries, whichever comes first
3. THE Proxy SHALL use `tracing-appender` with `RollingFileAppender` for access logs, matching the application log pattern
4. THE Proxy SHALL maintain the existing S3-compatible access log format
5. THE Proxy SHALL maintain the existing date-partitioned directory structure (`/logs/access/YYYY/MM/DD/`)
6. THE Proxy SHALL flush the access log buffer on graceful shutdown
7. WHEN access logging is disabled, THE Proxy SHALL NOT create any access log infrastructure

### Requirement 2: Buffered Cache Size Delta Tracking

**User Story:** As a proxy operator, I want cache size delta tracking to use buffered writes with per-instance files, so that size tracking doesn't create NFS contention while maintaining real-time capacity awareness.

#### Acceptance Criteria

1. THE Proxy SHALL maintain real-time cache size tracking in memory using atomic operations (existing behavior)
2. THE Proxy SHALL buffer delta log writes in RAM instead of writing per-operation
3. THE Proxy SHALL flush the delta buffer every 5 seconds OR when the buffer reaches 10000 deltas, whichever comes first
4. THE Proxy SHALL write delta logs to per-instance files: `size_tracking/delta-{instance_id}.log`
5. THE Proxy SHALL read all per-instance delta files during recovery to reconstruct total size
6. THE Proxy SHALL consolidate per-instance delta files into the checkpoint during checkpoint writes
7. THE Proxy SHALL flush the delta buffer on graceful shutdown
8. WHEN recovering from crash, THE Proxy SHALL sum deltas from all instance delta files

### Requirement 3: Flush Coordination

**User Story:** As a developer, I want the buffered logging systems to coordinate flushes efficiently, so that we minimize disk I/O while maintaining durability.

#### Acceptance Criteria

1. THE Proxy SHALL use a single background task for periodic flush coordination
2. THE Proxy SHALL allow force-flush of all buffers for testing and shutdown
3. THE Proxy SHALL log flush statistics at DEBUG level (entries flushed, duration, errors)
4. WHEN a flush fails, THE Proxy SHALL retain entries in the buffer and retry on next flush interval
5. THE Proxy SHALL NOT block request processing while flushing buffers

### Requirement 4: Configuration

**User Story:** As a system administrator, I want to configure buffer sizes and flush intervals, so that I can tune performance for my deployment.

#### Acceptance Criteria

1. THE Proxy SHALL provide configuration option `logging.access_log_flush_interval` (default: "5s")
2. THE Proxy SHALL provide configuration option `logging.access_log_buffer_size` (default: 1000)
3. THE Proxy SHALL provide configuration option `cache.size_tracking_flush_interval` (default: "5s")
4. THE Proxy SHALL provide configuration option `cache.size_tracking_buffer_size` (default: 10000)
5. THE Proxy SHALL validate configuration at startup and use defaults for invalid values


