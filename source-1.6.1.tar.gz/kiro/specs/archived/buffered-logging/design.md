# Design: Buffered Logging and Size Tracking

## Technical Design

### Overview

This design introduces RAM buffering for access logs and cache size delta tracking, using the same pattern as the existing `CacheHitUpdateBuffer`. Both systems will buffer writes in memory and flush periodically to per-instance files, eliminating NFS contention and reducing disk I/O by ~1000x.

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         S3 Proxy Instance                       │
│  ┌─────────────────────┐    ┌─────────────────────────────────┐ │
│  │  Request Handler    │    │  Cache Operations               │ │
│  │                     │    │                                 │ │
│  │  log_access()  ─────┼────┼──► AccessLogBuffer              │ │
│  │                     │    │    - entries: Vec<AccessLogEntry>│ │
│  │                     │    │    - flush every 5s             │ │
│  │                     │    │                                 │ │
│  │                     │    │  update_size() ─────────────────┼─┤
│  │                     │    │    │                            │ │
│  │                     │    │    ▼                            │ │
│  │                     │    │  SizeDeltaBuffer                │ │
│  │                     │    │    - pending_delta: AtomicI64   │ │
│  │                     │    │    - flush every 5s             │ │
│  └─────────────────────┘    └─────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼ (every 5 seconds)
┌─────────────────────────────────────────────────────────────────┐
│                    Shared Storage (NFS/EFS)                     │
│                                                                 │
│  logs/access/YYYY/MM/DD/                                        │
│    └── {timestamp}-{hostname}     ← Access logs (per-instance)  │
│                                                                 │
│  cache/size_tracking/                                           │
│    ├── checkpoint.json            ← Periodic checkpoint         │
│    └── delta-{instance_id}.log    ← Per-instance deltas         │
└─────────────────────────────────────────────────────────────────┘
```

### Component Design

#### 1. AccessLogBuffer

New struct in `src/logging.rs` that buffers access log entries:

```rust
pub struct AccessLogBuffer {
    buffer: Arc<Mutex<Vec<AccessLogEntry>>>,
    log_dir: PathBuf,
    hostname: String,
    flush_interval: Duration,
    max_buffer_size: usize,
    last_flush: Arc<RwLock<Instant>>,
    flush_in_progress: AtomicBool,
}

impl AccessLogBuffer {
    pub fn new(log_dir: PathBuf, hostname: String) -> Self;
    
    /// Add entry to buffer (non-blocking)
    pub async fn log(&self, entry: AccessLogEntry) -> Result<()>;
    
    /// Check if flush needed and perform if so
    async fn maybe_flush(&self) -> Result<()>;
    
    /// Flush buffer to disk
    pub async fn flush(&self) -> Result<FlushResult>;
    
    /// Force flush (for shutdown)
    pub async fn force_flush(&self) -> Result<FlushResult>;
}
```

**Flush behavior:**
- Writes all buffered entries to a single file per flush
- Uses atomic temp+rename for durability
- Appends to existing file if within same second, otherwise creates new file
- Format: One S3-compatible log line per entry

#### 2. SizeDeltaBuffer

New struct in `src/cache_size_tracker.rs` that buffers size deltas:

```rust
pub struct SizeDeltaBuffer {
    cache_dir: PathBuf,
    instance_id: String,
    pending_delta: AtomicI64,
    pending_write_delta: AtomicI64,
    flush_interval: Duration,
    last_flush: Arc<RwLock<Instant>>,
    flush_in_progress: AtomicBool,
}

impl SizeDeltaBuffer {
    pub fn new(cache_dir: PathBuf, instance_id: String) -> Self;
    
    /// Accumulate delta (instant, non-blocking)
    pub fn record_delta(&self, delta: i64);
    
    /// Accumulate write cache delta
    pub fn record_write_delta(&self, delta: i64);
    
    /// Check if flush needed
    pub fn should_flush(&self) -> bool;
    
    /// Flush accumulated deltas to disk
    pub async fn flush(&self) -> Result<FlushResult>;
}
```

**Delta file format:**
```
# delta-instance-a.log
+1048576
-524288
W:+2097152
```

Where `W:` prefix indicates write cache delta (existing format).

#### 3. Modified CacheSizeTracker

Update existing `CacheSizeTracker` to use `SizeDeltaBuffer`:

```rust
pub struct CacheSizeTracker {
    // Existing fields...
    current_size: AtomicU64,           // Real-time tracking (unchanged)
    write_cache_size: AtomicU64,       // Real-time tracking (unchanged)
    
    // New: buffered delta writing
    delta_buffer: SizeDeltaBuffer,
}

impl CacheSizeTracker {
    /// Update size - instant in-memory, buffered to disk
    pub fn update_size(&self, delta: i64) {
        // Instant: update in-memory counter
        self.current_size.fetch_add(delta as u64, Ordering::Relaxed);
        
        // Buffered: record for periodic flush
        self.delta_buffer.record_delta(delta);
    }
    
    /// Recovery: read all per-instance delta files
    async fn recover(&mut self) -> Result<(u64, bool)> {
        let checkpoint = self.read_checkpoint().await?;
        let total_delta = self.read_all_delta_files().await?;
        Ok((checkpoint.size_bytes + total_delta, false))
    }
    
    /// Read deltas from all instance files
    async fn read_all_delta_files(&self) -> Result<i64> {
        let mut total = 0i64;
        for entry in std::fs::read_dir(&self.size_tracking_dir)? {
            let path = entry?.path();
            if path.file_name()?.to_str()?.starts_with("delta-") {
                total += self.read_delta_file(&path).await?;
            }
        }
        Ok(total)
    }
}
```

#### 4. Modified LoggerManager

Update `LoggerManager` to use `AccessLogBuffer`:

```rust
pub struct LoggerManager {
    config: LoggingConfig,
    access_log_buffer: Option<AccessLogBuffer>,  // Changed from AccessLogWriter
}

impl LoggerManager {
    pub async fn log_access(&self, entry: AccessLogEntry, served_from_cache: bool) -> Result<()> {
        if let Some(buffer) = &self.access_log_buffer {
            let should_log = match self.config.access_log_mode {
                AccessLogMode::All => true,
                AccessLogMode::CachedOnly => served_from_cache,
            };
            if should_log {
                buffer.log(entry).await?;
            }
        }
        Ok(())
    }
}
```

### Configuration

Add to `src/config.rs`:

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoggingConfig {
    // Existing fields...
    
    /// Flush interval for access log buffer (default: 5s)
    #[serde(default = "default_access_log_flush_interval")]
    pub access_log_flush_interval: Duration,
    
    /// Maximum entries in access log buffer before forced flush (default: 1000)
    #[serde(default = "default_access_log_buffer_size")]
    pub access_log_buffer_size: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheSizeConfig {
    // Existing fields...
    
    /// Flush interval for size delta buffer (default: 5s)
    #[serde(default = "default_size_tracking_flush_interval")]
    pub size_tracking_flush_interval: Duration,
    
    /// Maximum deltas to accumulate before forced flush (default: 10000)
    #[serde(default = "default_size_tracking_buffer_size")]
    pub size_tracking_buffer_size: usize,
}
```

### Flush Coordination

Both buffers check flush conditions on each operation:

```rust
async fn maybe_flush(&self) -> Result<()> {
    let should_flush = {
        let last_flush = self.last_flush.read().await;
        last_flush.elapsed() >= self.flush_interval
    } || self.buffer_len() >= self.max_buffer_size;
    
    if should_flush {
        self.flush().await?;
    }
    Ok(())
}
```

Shutdown coordination in `main.rs`:

```rust
async fn graceful_shutdown(
    logger_manager: &mut LoggerManager,
    cache_size_tracker: &CacheSizeTracker,
) {
    // Flush all buffers
    if let Some(buffer) = &logger_manager.access_log_buffer {
        let _ = buffer.force_flush().await;
    }
    let _ = cache_size_tracker.delta_buffer.flush().await;
    let _ = cache_size_tracker.write_checkpoint().await;
}
```

### File Formats

#### Per-Instance Delta File

Path: `cache/size_tracking/delta-{instance_id}.log`

```
+1048576
-524288
+2097152
W:+1048576
W:-524288
```

- One delta per line
- `+` or `-` prefix for sign
- `W:` prefix for write cache deltas
- Simple text format for easy debugging

#### Access Log File

Path: `logs/access/YYYY/MM/DD/{timestamp}-{hostname}`

Same S3-compatible format as current implementation, just batched writes.

### Performance Impact

| Metric | Before | After |
|--------|--------|-------|
| Access log writes/s (4 nodes, 1000 req/s) | 4000 | 0.8 |
| Delta log writes/s (4 nodes, 1000 cache ops/s) | 4000 | 0.8 |
| NFS contention | High (shared files) | None (per-instance) |
| Max data loss on crash | 0 | 5 seconds |

### Error Handling

- **Flush failure**: Log warning, retain entries in buffer, retry next interval
- **Buffer overflow**: Force flush when max size reached
- **Disk full**: Log error, continue buffering (will retry)
- **Shutdown**: Best-effort flush, log if entries lost

## Correctness Properties

### Property 1: Real-Time Size Tracking Accuracy
For any sequence of cache operations, the in-memory `current_size` SHALL equal the sum of all size deltas applied, regardless of flush state.

### Property 2: Crash Recovery Completeness
After crash recovery, the reconstructed cache size SHALL equal checkpoint size plus sum of all deltas from all per-instance delta files.

### Property 3: Access Log Completeness
For any request where logging is enabled and the proxy shuts down gracefully, the access log entry SHALL be written to disk.

### Property 4: Buffer Flush Timing
The time between buffer updates and disk flush SHALL NOT exceed `flush_interval + flush_duration`.

### Property 5: Per-Instance Isolation
Writes from instance A SHALL NOT contend with writes from instance B (no shared file writes).
