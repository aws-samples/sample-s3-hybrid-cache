# Design Document

## Overview

This design implements a batch update mechanism to maintain cache coherency between RAM and disk caches. The system tracks RAM cache hits in memory and periodically flushes access statistics to disk metadata files, ensuring that hot data in RAM is not prematurely evicted from disk due to stale metadata.

The design follows a write-behind caching pattern where updates are batched in memory and asynchronously written to disk, minimizing write amplification while keeping metadata fresh enough for accurate eviction decisions.

## Architecture

### Component Overview

```
┌─────────────────────────────────────────────────────────────┐
│                      RAM Cache Layer                         │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  RamCache                                              │ │
│  │  - get() → records hit in AccessTracker               │ │
│  │  - evict_entry() → does NOT flush on evict            │ │
│  └────────────────────────────────────────────────────────┘ │
│                            │                                 │
│                            ▼                                 │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  AccessTracker (new component)                         │ │
│  │  - pending_updates: HashMap<CacheKey, AccessStats>    │ │
│  │  - last_flush: SystemTime                             │ │
│  │  - record_access(key, range)                          │ │
│  │  - should_flush() → bool                              │ │
│  │  - get_pending_updates() → Vec<Update>               │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Periodic flush (async)
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                   Batch Flush Coordinator                    │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  - Group updates by cache_key                          │ │
│  │  - Acquire file locks                                  │ │
│  │  - Read-modify-write metadata                          │ │
│  │  - Release locks                                       │ │
│  │  - Log metrics                                         │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                      Disk Cache Layer                        │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  NewCacheMetadata (.meta files)                        │ │
│  │  - ranges: Vec<RangeSpec>                             │ │
│  │    - last_accessed: SystemTime                        │ │
│  │    - access_count: u64                                │ │
│  │  - Updated atomically with file locking               │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### Data Flow

1. **RAM Cache Hit**: Client requests range → RAM cache serves → AccessTracker records hit
2. **Accumulation**: Multiple hits accumulate in pending_updates HashMap
3. **Flush Trigger**: Either flush_interval elapses OR pending_count >= flush_threshold
4. **Batch Processing**: Coordinator groups updates by cache_key
5. **Atomic Update**: For each cache_key, acquire lock → read metadata → update ranges → write → release lock
6. **Cleanup**: Clear pending updates, record metrics

## Components and Interfaces

### AccessTracker

New component added to RamCache for tracking pending disk updates and verification timestamps.

```rust
pub struct AccessTracker {
    /// Pending updates grouped by cache_key
    /// Maps cache_key to aggregated access statistics
    pending_updates: HashMap<String, PendingUpdate>,
    
    /// Last verification timestamp for each cache_key
    /// Maps cache_key to SystemTime of last coherency check
    last_verification: HashMap<String, SystemTime>,
    
    /// Last time a flush was performed
    last_flush: SystemTime,
    
    /// Configuration
    flush_interval: Duration,
    flush_threshold: usize,
    flush_on_eviction: bool,
    verification_interval: Duration, // Default: 1 second
}

pub struct PendingUpdate {
    /// Cache key for the object
    cache_key: String,
    
    /// Ranges that were accessed (for this cache_key)
    /// Maps (start, end) to access statistics
    ranges: HashMap<(u64, u64), RangeAccessStats>,
    
    /// First access time for this batch
    first_access: SystemTime,
}

pub struct RangeAccessStats {
    /// Number of accesses since last flush
    access_count_delta: u64,
    
    /// Most recent access time
    last_accessed: SystemTime,
}

impl AccessTracker {
    /// Record a RAM cache hit
    pub fn record_access(&mut self, cache_key: &str, start: u64, end: u64) {
        // O(1) HashMap insert/update
        // Aggregates multiple hits to same range
    }
    
    /// Check if verification is needed for a cache_key
    /// Returns true if no verification was performed within verification_interval
    pub fn should_verify(&self, cache_key: &str) -> bool {
        match self.last_verification.get(cache_key) {
            Some(last_time) => {
                SystemTime::now()
                    .duration_since(*last_time)
                    .unwrap_or_default() >= self.verification_interval
            }
            None => true, // Never verified, should verify
        }
    }
    
    /// Record that verification was performed for a cache_key
    pub fn record_verification(&mut self, cache_key: &str) {
        self.last_verification.insert(cache_key.to_string(), SystemTime::now());
    }
    
    /// Check if flush should be triggered
    pub fn should_flush(&self) -> bool {
        let interval_elapsed = SystemTime::now()
            .duration_since(self.last_flush)
            .unwrap_or_default() >= self.flush_interval;
        
        let threshold_reached = self.pending_updates.len() >= self.flush_threshold;
        
        interval_elapsed || threshold_reached
    }
    
    /// Get all pending updates and clear the tracker
    pub fn drain_pending_updates(&mut self) -> Vec<PendingUpdate> {
        self.last_flush = SystemTime::now();
        std::mem::take(&mut self.pending_updates)
            .into_values()
            .collect()
    }
    
    /// Get pending updates for a specific cache_key (for eviction write-back)
    pub fn drain_updates_for_key(&mut self, cache_key: &str) -> Option<PendingUpdate> {
        self.pending_updates.remove(cache_key)
    }
}
```

### RamCache Integration

Modify RamCache to integrate AccessTracker:

```rust
pub struct RamCache {
    // ... existing fields ...
    
    /// Access tracker for disk metadata updates and verification
    access_tracker: AccessTracker,
    
    /// Channel for sending flush requests to background task
    flush_tx: Option<tokio::sync::mpsc::UnboundedSender<FlushRequest>>,
}

pub enum VerificationResult {
    /// RAM cache data matches disk cache data
    Valid,
    
    /// RAM cache data does not match disk cache data
    Invalid,
    
    /// Disk cache entry does not exist
    DiskMissing,
    
    /// Verification failed due to I/O error
    Error(String),
}

impl RamCache {
    pub async fn get(&mut self, cache_key: &str, disk_cache: &DiskCacheManager) -> Option<RamCacheEntry> {
        if let Some(entry) = self.entries.get(cache_key).cloned() {
            // ... existing access tracking for RAM eviction ...
            
            // NEW: Verify RAM cache coherency with disk cache
            let base_key = Self::extract_base_key(cache_key);
            if self.access_tracker.should_verify(&base_key) {
                // Perform verification check
                match self.verify_cache_entry(cache_key, &entry, disk_cache).await {
                    VerificationResult::Valid => {
                        // Data matches, record verification and continue
                        self.access_tracker.record_verification(&base_key);
                    }
                    VerificationResult::Invalid => {
                        // Data mismatch, invalidate RAM cache entry
                        warn!("RAM cache entry {} failed verification, invalidating", cache_key);
                        self.entries.remove(cache_key);
                        return None; // Will trigger disk cache lookup
                    }
                    VerificationResult::DiskMissing => {
                        // Disk entry doesn't exist, invalidate RAM cache
                        warn!("Disk cache entry missing for {}, invalidating RAM cache", cache_key);
                        self.entries.remove(cache_key);
                        return None;
                    }
                    VerificationResult::Error(e) => {
                        // I/O error, log but serve RAM cache entry
                        warn!("Verification failed for {} due to error: {}, serving RAM cache", cache_key, e);
                        // Don't record verification timestamp, will retry next time
                    }
                }
            }
            
            // NEW: Record access for disk metadata update
            // Extract range info from cache_key (format: "key:range:start:end")
            if let Some((_, start, end)) = Self::parse_range_cache_key(cache_key) {
                self.access_tracker.record_access(
                    &base_key,
                    start,
                    end
                );
                
                // Check if flush should be triggered
                if self.access_tracker.should_flush() {
                    self.trigger_flush();
                }
            }
            
            // ... rest of existing code ...
        }
    }
    
    /// Verify that RAM cache entry matches disk cache entry
    async fn verify_cache_entry(
        &self,
        cache_key: &str,
        ram_entry: &RamCacheEntry,
        disk_cache: &DiskCacheManager,
    ) -> VerificationResult {
        let start_time = std::time::Instant::now();
        
        // Extract range info from cache_key
        let (base_key, start, end) = match Self::parse_range_cache_key(cache_key) {
            Some(parsed) => parsed,
            None => return VerificationResult::Error("Invalid cache key format".to_string()),
        };
        
        // Read disk cache metadata (lightweight operation, only reads .meta file)
        let metadata = match disk_cache.get_metadata(&base_key).await {
            Ok(Some(meta)) => meta,
            Ok(None) => return VerificationResult::DiskMissing,
            Err(e) => return VerificationResult::Error(format!("Failed to read metadata: {}", e)),
        };
        
        // Find the matching range in disk metadata
        let disk_range = metadata.ranges.iter()
            .find(|r| r.start == start && r.end == end);
        
        let disk_range = match disk_range {
            Some(r) => r,
            None => return VerificationResult::DiskMissing,
        };
        
        // Compare key properties (etag, size, compression)
        let matches = ram_entry.etag == disk_range.etag
            && ram_entry.size == (end - start)
            && ram_entry.compressed == disk_range.compressed;
        
        let duration = start_time.elapsed();
        if duration.as_millis() > 10 {
            warn!("Verification took {}ms for {}", duration.as_millis(), cache_key);
        }
        
        if matches {
            VerificationResult::Valid
        } else {
            VerificationResult::Invalid
        }
    }
    
    pub fn evict_entry(&mut self) -> Result<()> {
        let key_to_evict = /* ... existing eviction logic ... */;
        
        if let Some(key) = key_to_evict {
            // NOTE: We do NOT flush on eviction
            // Pending updates will be flushed on the next periodic flush
            // This avoids blocking eviction operations with disk I/O
            
            // ... existing eviction code ...
        }
    }
    
    fn trigger_flush(&mut self) {
        if let Some(tx) = &self.flush_tx {
            let updates = self.access_tracker.drain_pending_updates();
            if !updates.is_empty() {
                let _ = tx.send(FlushRequest::Batch(updates));
            }
        }
    }
}
```

### Batch Flush Coordinator

Background task that processes flush requests:

```rust
pub struct BatchFlushCoordinator {
    disk_cache_manager: Arc<tokio::sync::Mutex<DiskCacheManager>>,
    flush_rx: tokio::sync::mpsc::UnboundedReceiver<FlushRequest>,
}

pub enum FlushRequest {
    /// Periodic batch flush
    Batch(Vec<PendingUpdate>),
    
    /// Immediate flush (e.g., on eviction)
    Immediate(Vec<PendingUpdate>),
    
    /// Shutdown signal - flush all pending
    Shutdown,
}

impl BatchFlushCoordinator {
    pub async fn run(mut self) {
        while let Some(request) = self.flush_rx.recv().await {
            match request {
                FlushRequest::Batch(updates) => {
                    self.process_batch_flush(updates, false).await;
                }
                FlushRequest::Immediate(updates) => {
                    self.process_batch_flush(updates, true).await;
                }
                FlushRequest::Shutdown => {
                    info!("Flushing pending updates on shutdown");
                    break;
                }
            }
        }
    }
    
    async fn process_batch_flush(&self, updates: Vec<PendingUpdate>, immediate: bool) {
        let start = std::time::Instant::now();
        let mut keys_updated = 0;
        let mut ranges_updated = 0;
        let mut errors = Vec::new();
        
        for pending in updates {
            match self.update_metadata(&pending).await {
                Ok(count) => {
                    keys_updated += 1;
                    ranges_updated += count;
                }
                Err(e) => {
                    errors.push((pending.cache_key.clone(), e));
                }
            }
        }
        
        let duration = start.elapsed();
        
        info!(
            "Batch flush completed: keys={}, ranges={}, duration={:.2}ms, errors={}, immediate={}",
            keys_updated, ranges_updated, duration.as_secs_f64() * 1000.0, errors.len(), immediate
        );
        
        for (key, error) in errors {
            warn!("Failed to update metadata for {}: {}", key, error);
        }
    }
    
    async fn update_metadata(&self, pending: &PendingUpdate) -> Result<usize> {
        let disk_cache = self.disk_cache_manager.lock().await;
        
        // Delegate to DiskCacheManager method
        disk_cache.batch_update_range_access(
            &pending.cache_key,
            &pending.ranges
        ).await
    }
}
```

### DiskCacheManager Extension

Add batch update method and lightweight metadata reading to DiskCacheManager:

```rust
impl DiskCacheManager {
    /// Read metadata for a cache_key without locking (for verification)
    /// 
    /// This is a lightweight read-only operation that doesn't acquire locks.
    /// Used by RAM cache verification to check if data matches disk cache.
    /// 
    /// Returns None if metadata file doesn't exist.
    pub async fn get_metadata(&self, cache_key: &str) -> Result<Option<NewCacheMetadata>> {
        let metadata_path = self.get_new_metadata_file_path(cache_key);
        
        if !metadata_path.exists() {
            return Ok(None);
        }
        
        let metadata_content = tokio::fs::read_to_string(&metadata_path).await
            .map_err(|e| ProxyError::CacheError(format!("Failed to read metadata: {}", e)))?;
        
        let metadata: NewCacheMetadata = serde_json::from_str(&metadata_content)
            .map_err(|e| ProxyError::CacheError(format!("Failed to parse metadata: {}", e)))?;
        
        Ok(Some(metadata))
    }
    
    /// Batch update access statistics for multiple ranges of a cache_key
    /// 
    /// This method:
    /// 1. Acquires exclusive file lock (5s timeout)
    /// 2. Reads current metadata
    /// 3. Updates access_count and last_accessed for all specified ranges
    /// 4. Writes updated metadata atomically
    /// 5. Releases lock
    /// 
    /// Returns the number of ranges updated
    pub async fn batch_update_range_access(
        &self,
        cache_key: &str,
        range_updates: &HashMap<(u64, u64), RangeAccessStats>,
    ) -> Result<usize> {
        let metadata_path = self.get_new_metadata_file_path(cache_key);
        let lock_path = metadata_path.with_extension("meta.lock");
        
        // Check if metadata file exists
        if !metadata_path.exists() {
            warn!("Metadata file not found for {}, skipping update", cache_key);
            return Ok(0);
        }
        
        // Acquire lock with timeout
        let lock_file = tokio::time::timeout(
            Duration::from_secs(5),
            tokio::task::spawn_blocking({
                let lock_path = lock_path.clone();
                move || {
                    let file = std::fs::OpenOptions::new()
                        .create(true)
                        .write(true)
                        .open(&lock_path)?;
                    file.lock_exclusive()?;
                    Ok::<_, ProxyError>(file)
                }
            })
        ).await;
        
        let lock_file = match lock_file {
            Ok(Ok(Ok(file))) => file,
            _ => {
                warn!("Failed to acquire lock for {} within timeout", cache_key);
                return Err(ProxyError::CacheError("Lock timeout".to_string()));
            }
        };
        
        // Read current metadata
        let metadata_content = std::fs::read_to_string(&metadata_path)
            .map_err(|e| ProxyError::CacheError(format!("Failed to read metadata: {}", e)))?;
        
        let mut metadata: NewCacheMetadata = serde_json::from_str(&metadata_content)
            .map_err(|e| ProxyError::CacheError(format!("Failed to parse metadata: {}", e)))?;
        
        // Update ranges
        let mut updated_count = 0;
        for range_spec in &mut metadata.ranges {
            let key = (range_spec.start, range_spec.end);
            if let Some(stats) = range_updates.get(&key) {
                range_spec.access_count += stats.access_count_delta;
                range_spec.last_accessed = stats.last_accessed;
                updated_count += 1;
            }
        }
        
        // Write updated metadata
        let json = serde_json::to_string_pretty(&metadata)
            .map_err(|e| ProxyError::CacheError(format!("Failed to serialize metadata: {}", e)))?;
        std::fs::write(&metadata_path, json)
            .map_err(|e| ProxyError::CacheError(format!("Failed to write metadata: {}", e)))?;
        
        // Release lock (automatic on drop)
        lock_file.unlock()
            .map_err(|e| ProxyError::CacheError(format!("Failed to release lock: {}", e)))?;
        
        debug!(
            "Batch updated {} ranges for cache_key: {}",
            updated_count, cache_key
        );
        
        Ok(updated_count)
    }
}
```

## Data Models

### Configuration

Add new configuration fields to support batch updates:

```rust
pub struct CacheConfig {
    // ... existing fields ...
    
    /// Interval between periodic flushes of RAM cache access statistics to disk
    /// Default: 60 seconds
    /// Range: 10-600 seconds
    pub ram_cache_flush_interval: Duration,
    
    /// Number of pending updates that triggers an immediate flush
    /// Default: 100
    /// Range: 10-10000
    pub ram_cache_flush_threshold: usize,
    
    /// Whether to flush pending updates when RAM cache entries are evicted
    /// Default: false (do not flush on eviction to avoid blocking)
    pub ram_cache_flush_on_eviction: bool,
    
    /// Interval between RAM cache coherency verification checks
    /// Default: 1 second
    /// Range: 1-60 seconds
    pub ram_cache_verification_interval: Duration,
}
```

### Metrics

Add new metrics for monitoring batch update operations:

```rust
pub struct CacheMetrics {
    // ... existing fields ...
    
    /// Number of pending disk metadata updates
    pub pending_disk_updates: u64,
    
    /// Total number of batch flushes performed
    pub batch_flush_count: u64,
    
    /// Total number of cache keys updated via batch flush
    pub batch_flush_keys_updated: u64,
    
    /// Total number of ranges updated via batch flush
    pub batch_flush_ranges_updated: u64,
    
    /// Average batch flush duration in milliseconds
    pub batch_flush_avg_duration_ms: f64,
    
    /// Number of batch flush errors
    pub batch_flush_errors: u64,
    
    /// Total number of RAM cache verification checks performed
    pub ram_verification_checks: u64,
    
    /// Number of RAM cache entries invalidated due to verification failure
    pub ram_verification_invalidations: u64,
    
    /// Number of verification checks that found disk cache missing
    pub ram_verification_disk_missing: u64,
    
    /// Number of verification checks that failed due to I/O errors
    pub ram_verification_errors: u64,
    
    /// Average verification check duration in milliseconds
    pub ram_verification_avg_duration_ms: f64,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: RAM hit tracking

*For any* RAM cache hit, the access SHALL be recorded in the pending updates tracker within 1 millisecond without blocking the response
**Validates: Requirements 1.1, 1.2, 1.4**

### Property 2: Access aggregation

*For any* cache_key with multiple RAM hits, the pending updates SHALL aggregate access_count increments and track the most recent last_accessed timestamp
**Validates: Requirements 1.3**

### Property 3: Flush triggering

*For any* state where either flush_interval has elapsed OR pending_count >= flush_threshold, the system SHALL trigger a batch flush
**Validates: Requirements 1.5, 2.3**

### Property 4: Batch grouping

*For any* batch flush operation, updates SHALL be grouped by cache_key such that all ranges for a cache_key are updated in a single metadata file write
**Validates: Requirements 2.4, 2.5**

### Property 5: File locking

*For any* disk metadata update, the system SHALL acquire an exclusive file lock before reading and release it after writing
**Validates: Requirements 3.1, 3.3, 3.4**

### Property 6: Lock timeout handling

*For any* lock acquisition that exceeds the 5-second timeout, the system SHALL skip that update and retain it for the next flush cycle
**Validates: Requirements 3.2, 3.5**

### Property 7: Missing file handling

*For any* flush operation where the metadata file does not exist, the system SHALL log a warning and remove the pending update without crashing
**Validates: Requirements 4.1, 4.5**

### Property 8: Eviction does not block on flush

*For any* RAM cache eviction with pending updates for that cache_key, the eviction SHALL complete immediately without flushing to disk
**Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5**

### Property 10: Metrics recording

*For any* batch flush operation, the system SHALL record the number of keys updated, ranges updated, and flush duration in metrics
**Validates: Requirements 5.1, 5.2, 5.4**

### Property 11: Error logging

*For any* batch flush error, the system SHALL log the error with the affected cache_key without crashing the proxy
**Validates: Requirements 5.3, 4.5**

### Property 12: Configuration validation

*For any* invalid configuration value (flush_interval or flush_threshold out of range), the system SHALL log an error and use default values
**Validates: Requirements 7.5**

### Property 13: Disk metadata consistency

*For any* sequence of RAM cache hits followed by a flush, reading the disk metadata SHALL reflect the updated access_count and last_accessed values
**Validates: Requirements 8.3**

### Property 14: Concurrent update safety

*For any* concurrent batch flush operations on the same cache_key from multiple threads, file locking SHALL ensure only one update proceeds at a time and no data corruption occurs
**Validates: Requirements 8.4**

### Property 15: Eviction correctness

*For any* workload where data is hot in RAM, after flushing pending updates to disk, the disk eviction algorithm SHALL NOT select that data for eviction
**Validates: Requirements 9.5**

### Property 16: Verification throttling

*For any* RAM cache entry, verification checks SHALL be performed at most once per second, regardless of the number of cache hits
**Validates: Requirements 1.7, 8.1, 8.8**

### Property 17: Verification on mismatch

*For any* RAM cache entry where verification detects a mismatch with disk cache data, the RAM cache entry SHALL be invalidated and the request SHALL be served from disk cache
**Validates: Requirements 1.8, 8.5**

### Property 18: Verification performance

*For any* verification check that reads disk cache metadata, the operation SHALL complete within 10 milliseconds
**Validates: Requirements 8.3**

### Property 19: Verification error handling

*For any* verification check that fails due to I/O error, the system SHALL log the error and serve the RAM cache entry without invalidation
**Validates: Requirements 8.7**

### Property 20: Verification on disk missing

*For any* verification check where the disk cache entry does not exist, the RAM cache entry SHALL be invalidated and a cache miss SHALL be returned
**Validates: Requirements 8.6**

## Error Handling

### Lock Acquisition Failures

- **Timeout**: If lock cannot be acquired within 5 seconds, log warning and skip update
- **Retry**: Retain pending update for next flush cycle
- **Metrics**: Increment lock_timeout_count metric

### Metadata File Errors

- **Missing File**: Log warning, remove pending update (data was likely evicted)
- **Parse Error**: Log error, skip update, retain for retry
- **Write Error**: Log error, retain pending update for retry

### Flush Operation Failures

- **Partial Success**: Some keys updated, some failed - log each failure
- **Complete Failure**: Log error, retain all pending updates
- **Never Crash**: Flush failures must not crash the proxy

### Eviction Behavior

- **No Flush on Eviction**: Eviction does NOT trigger immediate flush to avoid blocking
- **Pending Updates Retained**: Pending updates for evicted keys remain in tracker
- **Periodic Flush**: Pending updates will be flushed on next periodic flush cycle
- **No Blocking**: Eviction completes immediately without disk I/O

## Testing Strategy

### Unit Tests

1. **AccessTracker Tests**
   - Test record_access() updates pending_updates correctly
   - Test should_flush() triggers on interval and threshold
   - Test drain_pending_updates() clears tracker
   - Test drain_updates_for_key() removes specific key

2. **Batch Flush Tests**
   - Test grouping of updates by cache_key
   - Test atomic read-modify-write of metadata
   - Test error handling for missing/corrupt files
   - Test lock acquisition and release

3. **Configuration Tests**
   - Test validation of flush_interval range (10-600s)
   - Test validation of flush_threshold range (10-10000)
   - Test default values when config is missing
   - Test error handling for invalid values

### Property-Based Tests

Use `quickcheck` for property-based testing with 100+ iterations per property.

1. **Property 1: RAM hit tracking**
   - Generate random cache keys and ranges
   - Perform RAM cache hits
   - Verify pending_updates contains entries
   - Verify response time < 1ms

2. **Property 2: Access aggregation**
   - Generate multiple hits to same cache_key
   - Verify access_count_delta is sum of hits
   - Verify last_accessed is most recent timestamp

3. **Property 3: Flush triggering**
   - Test time-based trigger with various intervals
   - Test count-based trigger with various thresholds
   - Verify flush occurs when either condition is met

4. **Property 13: Disk metadata consistency**
   - Generate random RAM cache hits
   - Trigger flush
   - Read disk metadata
   - Verify access_count and last_accessed match expectations

5. **Property 14: Concurrent update safety**
   - Spawn multiple threads updating same cache_key
   - Verify no data corruption
   - Verify all updates are applied

6. **Property 15: Eviction correctness**
   - Create workload with hot and cold data
   - Hot data: frequent RAM hits with flushes
   - Cold data: no RAM hits
   - Trigger disk eviction
   - Verify cold data is evicted, hot data remains

7. **Property 16: Verification throttling**
   - Generate multiple RAM cache hits to same entry within 1 second
   - Verify only one verification check is performed
   - Wait 1 second, generate more hits
   - Verify another verification check is performed

8. **Property 17: Verification on mismatch**
   - Create RAM cache entry with specific data
   - Modify disk cache entry to have different etag/size
   - Perform RAM cache hit
   - Verify RAM entry is invalidated
   - Verify request is served from disk

9. **Property 18: Verification performance**
   - Generate random RAM cache hits
   - Measure verification check duration
   - Verify all checks complete within 10ms

10. **Property 19: Verification error handling**
    - Simulate I/O error during verification
    - Verify RAM cache entry is still served
    - Verify error is logged
    - Verify verification timestamp is not updated

11. **Property 20: Verification on disk missing**
    - Create RAM cache entry
    - Delete disk cache entry
    - Perform RAM cache hit
    - Verify RAM entry is invalidated
    - Verify cache miss is returned

### Integration Tests

1. **End-to-End Coherency Test**
   - Start proxy with RAM and disk cache
   - Generate workload with hot data in RAM
   - Verify disk metadata is updated periodically
   - Trigger disk eviction
   - Verify hot data is not evicted

2. **Multi-Instance Test**
   - Start multiple proxy instances sharing disk cache
   - Generate RAM hits on different instances
   - Verify file locking prevents corruption
   - Verify all updates are applied correctly

3. **Shutdown Test**
   - Generate RAM hits with pending updates
   - Trigger graceful shutdown
   - Verify pending updates are flushed within 5 seconds
   - Verify no data loss

4. **Eviction Behavior Test**
   - Fill RAM cache to trigger eviction
   - Verify eviction completes immediately without flushing
   - Verify pending updates remain in tracker
   - Verify pending updates are flushed on next periodic flush

### Performance Tests

1. **Flush Performance**
   - Measure batch flush duration for various update counts
   - Verify flush completes within reasonable time (< 100ms for 100 keys)
   - Verify lock hold time < 100ms

2. **RAM Hit Performance**
   - Measure RAM cache hit latency with access tracking
   - Verify overhead < 1ms
   - Verify no blocking on disk I/O

3. **Write Amplification**
   - Measure disk writes with and without batching
   - Verify batching reduces writes by expected factor
   - Verify flush_interval and flush_threshold are effective

## Performance Considerations

### Write Amplification Reduction

- **Batching**: Group updates by cache_key to minimize file operations
- **Aggregation**: Multiple hits to same range increment counter, not separate writes
- **Configurable Interval**: Tune flush_interval based on workload (default 60s)
- **Threshold-Based**: Flush when pending_count reaches threshold (default 100)

### Response Time Impact

- **Non-Blocking**: RAM cache hits record access in O(1) HashMap operation
- **Async Flush**: Batch flush runs in background task, doesn't block responses
- **Target**: < 1ms overhead for access tracking

### Lock Contention

- **Short Critical Section**: Hold lock only during read-modify-write (target < 100ms)
- **Timeout**: 5-second timeout prevents indefinite blocking
- **Retry**: Failed updates retained for next cycle

### Memory Overhead

- **Bounded**: pending_updates HashMap size limited by flush_threshold
- **Typical**: ~100 entries × ~200 bytes = ~20KB memory overhead
- **Worst Case**: 10,000 entries × 200 bytes = ~2MB (at max threshold)

## Deployment Considerations

### Configuration Tuning

**High-Throughput Workloads:**
- Lower flush_interval (e.g., 30s) for fresher metadata
- Higher flush_threshold (e.g., 500) to batch more updates

**Low-Throughput Workloads:**
- Higher flush_interval (e.g., 300s) to reduce overhead
- Lower flush_threshold (e.g., 50) to flush sooner

**Write-Sensitive Storage:**
- Higher flush_interval to minimize writes
- Lower flush_threshold to ensure hot data is flushed before eviction

### Monitoring

Key metrics to monitor:
- `pending_disk_updates`: Should stay below flush_threshold
- `batch_flush_avg_duration_ms`: Should be < 100ms
- `batch_flush_errors`: Should be near zero
- `lock_timeout_count`: Should be near zero

### Backward Compatibility

- Feature is additive, doesn't break existing cache behavior
- If disabled (flush_interval = 0), system behaves as before
- Existing disk metadata files are compatible
- No migration required

## Future Enhancements

1. **Adaptive Flushing**: Adjust flush_interval based on hit rate
2. **Priority Flushing**: Flush hot data more frequently than cold data
3. **Compression**: Compress pending_updates for large workloads
4. **Distributed Coordination**: Coordinate flushes across multiple instances
5. **Metrics Dashboard**: Visualize cache coherency health
