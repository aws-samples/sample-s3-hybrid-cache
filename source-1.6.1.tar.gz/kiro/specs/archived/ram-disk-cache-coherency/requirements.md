# Requirements Document

## Introduction

This specification addresses a cache coherency issue in the multi-tier caching system where hot data in RAM cache can be prematurely evicted from disk cache due to stale access tracking metadata. When entries are served from RAM cache, their disk metadata (last_accessed, access_count) is not updated, causing the disk eviction algorithm to incorrectly identify hot data as cold and evict it. This leads to cache misses after RAM eviction or proxy restart.

The solution implements periodic batch updates of disk metadata for RAM cache hits, maintaining cache coherency while minimizing write amplification.

## Glossary

- **RAM Cache**: First-tier in-memory cache using LRU or TinyLFU eviction
- **Disk Cache**: Second-tier persistent cache with range-based storage
- **Cache Coherency**: Consistency between RAM and disk cache metadata
- **Access Tracking**: Recording last_accessed timestamp and access_count for eviction decisions
- **Batch Update**: Grouping multiple metadata updates into a single disk write operation
- **Write Amplification**: Excessive disk writes relative to actual data changes
- **Hot Data**: Frequently accessed data that should remain cached
- **Cold Data**: Infrequently accessed data that is a candidate for eviction
- **Eviction Algorithm**: Strategy for selecting cache entries to remove (LRU or TinyLFU)
- **RangeSpec**: Metadata structure for cached byte ranges including access tracking fields

## Requirements

### Requirement 1

**User Story:** As a proxy operator, I want hot data in RAM cache to remain protected in disk cache, so that cache misses don't occur after RAM eviction or restart.

#### Acceptance Criteria

1. WHEN the RAM cache serves a range THEN the system SHALL record the access in a pending updates tracker
2. WHEN the RAM cache serves a range THEN the system SHALL NOT block the response on disk metadata updates
3. WHEN pending updates exist for a cache key THEN the system SHALL aggregate access_count increments and track the most recent last_accessed timestamp
4. WHEN a RAM cache hit occurs THEN the system SHALL update the in-memory pending updates within 1 millisecond
5. WHEN the flush interval elapses THEN the system SHALL write all pending updates to disk metadata files
6. WHEN a RAM cache hit occurs THEN the system SHALL verify the RAM data matches the disk cache entry
7. WHEN a RAM cache hit verification check was performed within the last second THEN the system SHALL skip the verification check
8. WHEN RAM cache data does not match disk cache data THEN the system SHALL invalidate the RAM cache entry and serve from disk

### Requirement 2

**User Story:** As a proxy operator, I want disk metadata updates to be batched efficiently, so that write amplification is minimized while keeping metadata reasonably fresh.

#### Acceptance Criteria

1. WHEN the flush interval is configurable THEN the system SHALL accept values between 10 seconds and 600 seconds
2. WHEN the flush threshold is configurable THEN the system SHALL accept values between 10 and 10000 pending updates
3. WHEN either the flush interval elapses or the pending update count reaches the threshold THEN the system SHALL trigger a batch flush
4. WHEN performing a batch flush THEN the system SHALL group updates by cache_key to minimize file operations
5. WHEN performing a batch flush THEN the system SHALL update all ranges for a cache_key in a single metadata file write

### Requirement 3

**User Story:** As a proxy operator, I want disk metadata updates to use file locking, so that concurrent access from multiple proxy instances is safe.

#### Acceptance Criteria

1. WHEN updating disk metadata THEN the system SHALL acquire an exclusive file lock with a 5-second timeout
2. WHEN a file lock cannot be acquired within the timeout THEN the system SHALL log a warning and skip that update
3. WHEN updating disk metadata THEN the system SHALL read the current metadata, apply updates, and write atomically
4. WHEN updating disk metadata THEN the system SHALL release the file lock within 100 milliseconds
5. WHEN a lock acquisition fails THEN the system SHALL retain the pending update for the next flush cycle

### Requirement 4

**User Story:** As a proxy operator, I want the system to handle edge cases gracefully, so that cache operations remain reliable under all conditions.

#### Acceptance Criteria

1. WHEN a metadata file does not exist during flush THEN the system SHALL log a warning and remove the pending update
2. WHEN a metadata file cannot be parsed during flush THEN the system SHALL log an error and skip that update
3. WHEN a range is not found in metadata during flush THEN the system SHALL log a warning and remove the pending update
4. WHEN the proxy shuts down THEN the system SHALL attempt to flush all pending updates within 5 seconds
5. WHEN the flush operation fails THEN the system SHALL log the error but not crash the proxy

### Requirement 5

**User Story:** As a proxy operator, I want visibility into batch update operations, so that I can monitor cache coherency health.

#### Acceptance Criteria

1. WHEN a batch flush completes THEN the system SHALL log the number of cache keys updated and total ranges affected
2. WHEN a batch flush completes THEN the system SHALL record the flush duration in milliseconds
3. WHEN a batch flush encounters errors THEN the system SHALL log each error with the affected cache_key
4. WHEN pending updates accumulate THEN the system SHALL expose the pending update count via metrics
5. WHEN the flush interval is reached THEN the system SHALL log the flush trigger reason

### Requirement 6

**User Story:** As a proxy operator, I want RAM cache eviction to optionally write back access statistics, so that disk metadata remains accurate even for evicted entries.

#### Acceptance Criteria

1. WHEN a RAM cache entry is evicted THEN the system SHALL check for pending updates for that cache_key
2. WHEN pending updates exist for an evicted entry THEN the system SHALL immediately flush those updates to disk
3. WHEN flushing on eviction THEN the system SHALL complete the flush within 50 milliseconds or skip it
4. WHEN flushing on eviction fails THEN the system SHALL log a warning but complete the eviction
5. WHEN flushing on eviction succeeds THEN the system SHALL remove the pending updates from the tracker

### Requirement 7

**User Story:** As a proxy operator, I want configuration options for batch update behavior, so that I can tune performance for my workload.

#### Acceptance Criteria

1. WHEN the configuration specifies ram_cache_flush_interval THEN the system SHALL use that value for periodic flushes
2. WHEN the configuration specifies ram_cache_flush_threshold THEN the system SHALL trigger flushes at that pending update count
3. WHEN the configuration specifies ram_cache_flush_on_eviction THEN the system SHALL enable or disable write-back on eviction
4. WHEN no flush configuration is provided THEN the system SHALL use default values of 60 seconds and 100 updates
5. WHEN invalid configuration values are provided THEN the system SHALL log an error and use default values

### Requirement 8

**User Story:** As a proxy operator, I want RAM cache hits to verify data consistency with disk cache, so that stale or corrupted RAM cache entries are detected and corrected.

#### Acceptance Criteria

1. WHEN a RAM cache hit occurs THEN the system SHALL check if a verification was performed within the last second for that cache entry
2. WHEN no verification was performed within the last second THEN the system SHALL compare the RAM cache data with the disk cache entry
3. WHEN the verification check reads disk cache metadata THEN the system SHALL complete within 10 milliseconds
4. WHEN RAM cache data matches disk cache data THEN the system SHALL serve the RAM cache entry and update the last verification timestamp
5. WHEN RAM cache data does not match disk cache data THEN the system SHALL invalidate the RAM cache entry, log a warning, and serve from disk cache
6. WHEN disk cache entry does not exist during verification THEN the system SHALL invalidate the RAM cache entry and return a cache miss
7. WHEN verification fails due to I/O error THEN the system SHALL log the error and serve the RAM cache entry without invalidation
8. WHEN multiple concurrent requests hit the same RAM cache entry THEN the system SHALL perform at most one verification check per second

### Requirement 9

**User Story:** As a proxy operator, I want the batch update system to be testable, so that I can verify cache coherency is maintained.

#### Acceptance Criteria

1. WHEN a test triggers RAM cache hits THEN the system SHALL record pending updates in the tracker
2. WHEN a test manually triggers a flush THEN the system SHALL update disk metadata files
3. WHEN a test reads disk metadata after flush THEN the system SHALL reflect the updated access_count and last_accessed values
4. WHEN a test simulates concurrent updates THEN the system SHALL handle file locking correctly
5. WHEN a test verifies eviction behavior THEN the system SHALL demonstrate that updated metadata prevents premature eviction
