# Implementation Plan

- [x] 1. Add configuration fields for batch update settings
  - Add `ram_cache_flush_interval`, `ram_cache_flush_threshold`, `ram_cache_flush_on_eviction`, and `ram_cache_verification_interval` to `CacheConfig` struct
  - Implement validation for flush_interval (10-600 seconds), flush_threshold (10-10000), and verification_interval (1-60 seconds)
  - Set default values: 60 seconds, 100 updates, false for flush_on_eviction, 1 second for verification_interval
  - Add configuration parsing from YAML with error handling
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 2. Implement AccessTracker component
  - [x] 2.1 Create AccessTracker struct with pending_updates and last_verification HashMaps
    - Define `PendingUpdate` struct with cache_key and ranges HashMap
    - Define `RangeAccessStats` struct with access_count_delta and last_accessed
    - Add `last_verification` HashMap to track verification timestamps per cache_key
    - Implement `AccessTracker::new()` with configuration parameters including verification_interval
    - _Requirements: 1.1, 1.3, 8.1_

  - [x] 2.2 Implement record_access() method
    - Add O(1) HashMap insert/update logic
    - Aggregate multiple hits to same range (increment counter, update timestamp)
    - Ensure operation completes within 1ms
    - _Requirements: 1.1, 1.3, 1.4_

  - [x] 2.3 Implement should_flush() method
    - Check if flush_interval has elapsed since last_flush
    - Check if pending_updates count >= flush_threshold
    - Return true if either condition is met
    - _Requirements: 1.5, 2.3_

  - [x] 2.4 Implement drain_pending_updates() method
    - Update last_flush timestamp
    - Extract and return all pending updates
    - Clear the pending_updates HashMap
    - _Requirements: 1.5_

  - [x] 2.5 Implement drain_updates_for_key() method
    - Remove and return pending updates for specific cache_key
    - Used for eviction write-back
    - _Requirements: 6.1, 6.5_

  - [x] 2.6 Implement should_verify() method
    - Check if verification was performed within verification_interval for a cache_key
    - Return true if no verification exists or interval has elapsed
    - _Requirements: 8.1, 8.8_

  - [x] 2.7 Implement record_verification() method
    - Update last_verification timestamp for a cache_key
    - Called after successful verification check
    - _Requirements: 8.4_

  - [ ]* 2.8 Write property test for access aggregation
    - **Property 2: Access aggregation**
    - **Validates: Requirements 1.3**

- [x] 3. Integrate AccessTracker into RamCache
  - [x] 3.1 Add AccessTracker field to RamCache struct
    - Add flush_tx channel for sending flush requests
    - Initialize AccessTracker in RamCache::new()
    - Pass configuration from CacheManager
    - _Requirements: 1.1_

  - [x] 3.2 Modify RamCache::get() to perform verification and record accesses
    - Check should_verify() for the cache_key
    - If verification needed, call verify_cache_entry() and handle result
    - On Valid: record verification timestamp and continue
    - On Invalid: invalidate RAM entry, log warning, return None
    - On DiskMissing: invalidate RAM entry, log warning, return None
    - On Error: log error, serve RAM entry without recording verification
    - Parse range info from cache_key (format: "key:range:start:end")
    - Call access_tracker.record_access() on cache hit
    - Check should_flush() and trigger flush if needed
    - Ensure verification completes within 10ms
    - _Requirements: 1.1, 1.2, 1.4, 1.5, 1.6, 1.7, 1.8, 8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7_

  - [x] 3.3 Add helper methods for cache key parsing
    - Implement parse_range_cache_key() to extract start/end
    - Implement extract_base_key() to get cache_key without range suffix
    - Handle various cache key formats
    - _Requirements: 1.1_

  - [x] 3.4 Implement verify_cache_entry() method
    - Define VerificationResult enum (Valid, Invalid, DiskMissing, Error)
    - Parse range info from cache_key
    - Call disk_cache.get_metadata() to read disk metadata
    - Find matching range in disk metadata
    - Compare etag, size, and compression fields
    - Measure and log verification duration if > 10ms
    - Return appropriate VerificationResult
    - _Requirements: 1.6, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7_

  - [x] 3.5 Implement trigger_flush() method
    - Drain pending updates from AccessTracker
    - Send FlushRequest::Batch via channel
    - Handle channel send errors gracefully
    - _Requirements: 1.5, 2.3_

  - [ ]* 3.6 Write property test for RAM hit tracking
    - **Property 1: RAM hit tracking**
    - **Validates: Requirements 1.1, 1.2, 1.4**

- [x] 4. Implement eviction write-back in RamCache
  - [x] 4.1 Modify RamCache::evict_entry() for write-back
    - Check if flush_on_eviction is enabled
    - Extract base_key from evicted entry
    - Call drain_updates_for_key() to get pending updates
    - Send FlushRequest::Immediate if updates exist
    - Complete eviction regardless of flush result
    - _Requirements: 6.1, 6.2, 6.4, 6.5_

  - [ ]* 4.2 Write property test for eviction write-back
    - **Property 8: Eviction write-back**
    - **Validates: Requirements 6.1, 6.2, 6.5**

  - [ ]* 4.3 Write property test for eviction flush timeout
    - **Property 9: Eviction flush timeout**
    - **Validates: Requirements 6.3, 6.4**

- [x] 5. Implement BatchFlushCoordinator
  - [x] 5.1 Create BatchFlushCoordinator struct
    - Add disk_cache_manager Arc reference
    - Add flush_rx channel receiver
    - Define FlushRequest enum (Batch, Immediate, Shutdown)
    - _Requirements: 2.4, 2.5_

  - [x] 5.2 Implement run() method for background task
    - Loop receiving FlushRequest messages
    - Handle Batch, Immediate, and Shutdown requests
    - Call process_batch_flush() for each request
    - _Requirements: 1.5, 2.3_

  - [x] 5.3 Implement process_batch_flush() method
    - Track start time for duration measurement
    - Iterate through pending updates
    - Call update_metadata() for each cache_key
    - Collect success/error counts
    - Log completion with metrics (keys, ranges, duration, errors)
    - _Requirements: 2.4, 2.5, 5.1, 5.2, 5.3_

  - [x] 5.4 Implement update_metadata() helper
    - Lock disk_cache_manager
    - Call batch_update_range_access()
    - Return number of ranges updated
    - Handle errors and return Result
    - _Requirements: 2.5, 3.3_

  - [ ]* 5.5 Write property test for batch grouping
    - **Property 4: Batch grouping**
    - **Validates: Requirements 2.4, 2.5**

  - [ ]* 5.6 Write property test for metrics recording
    - **Property 10: Metrics recording**
    - **Validates: Requirements 5.1, 5.2, 5.4**

- [x] 6. Implement metadata reading and batch update in DiskCacheManager
  - [x] 6.1 Add get_metadata() method for lightweight metadata reading
    - Accept cache_key parameter
    - Return Result<Option<NewCacheMetadata>>
    - Read metadata file without acquiring lock (read-only operation)
    - Return None if file doesn't exist
    - Parse JSON and return metadata
    - Handle I/O and parse errors
    - _Requirements: 8.2, 8.3_

  - [x] 6.2 Add batch_update_range_access() method signature
    - Accept cache_key and HashMap of range updates
    - Return Result with number of ranges updated
    - _Requirements: 2.5, 3.3_

  - [x] 6.3 Implement file locking with timeout
    - Get metadata and lock file paths
    - Check if metadata file exists (return early if not)
    - Acquire exclusive lock with 5-second timeout using tokio::time::timeout
    - Handle timeout by logging warning and returning error
    - _Requirements: 3.1, 3.2, 4.1_

  - [x] 6.4 Implement read-modify-write logic
    - Read metadata file content
    - Parse JSON to NewCacheMetadata struct
    - Handle parse errors gracefully
    - Iterate through ranges and apply updates
    - Track number of ranges updated
    - _Requirements: 3.3, 4.2, 4.3_

  - [x] 6.5 Implement atomic metadata write
    - Serialize updated metadata to JSON
    - Write to metadata file
    - Release file lock
    - Ensure lock hold time < 100ms
    - _Requirements: 3.3, 3.4_

  - [x] 6.6 Add error handling for edge cases
    - Missing metadata file: log warning, return Ok(0)
    - Parse error: log error, return error
    - Range not found: log warning, continue with other ranges
    - Write error: log error, return error
    - _Requirements: 4.1, 4.2, 4.3, 4.5_

  - [ ]* 6.7 Write property test for file locking
    - **Property 5: File locking**
    - **Validates: Requirements 3.1, 3.3, 3.4**

  - [ ]* 6.8 Write property test for lock timeout handling
    - **Property 6: Lock timeout handling**
    - **Validates: Requirements 3.2, 3.5**

  - [ ]* 6.9 Write property test for missing file handling
    - **Property 7: Missing file handling**
    - **Validates: Requirements 4.1, 4.5**

- [x] 7. Wire up BatchFlushCoordinator in CacheManager
  - [x] 7.1 Create channel for flush requests
    - Create unbounded channel (tx, rx) in CacheManager::new()
    - Pass tx to RamCache during initialization
    - Store rx for BatchFlushCoordinator
    - _Requirements: 1.5_

  - [x] 7.2 Spawn BatchFlushCoordinator background task
    - Create BatchFlushCoordinator with disk_cache_manager and rx
    - Spawn tokio task running coordinator.run()
    - Store task handle for graceful shutdown
    - _Requirements: 1.5, 2.3_

  - [x] 7.3 Implement graceful shutdown
    - Send FlushRequest::Shutdown on proxy shutdown
    - Wait for coordinator task to complete (with 5s timeout)
    - Log if shutdown flush completes or times out
    - _Requirements: 4.4_

- [x] 8. Add metrics for batch update and verification operations
  - [x] 8.1 Add metrics fields to CacheMetrics struct
    - Add pending_disk_updates counter
    - Add batch_flush_count counter
    - Add batch_flush_keys_updated counter
    - Add batch_flush_ranges_updated counter
    - Add batch_flush_avg_duration_ms gauge
    - Add batch_flush_errors counter
    - Add ram_verification_checks counter
    - Add ram_verification_invalidations counter
    - Add ram_verification_disk_missing counter
    - Add ram_verification_errors counter
    - Add ram_verification_avg_duration_ms gauge
    - _Requirements: 5.4_

  - [x] 8.2 Update metrics in BatchFlushCoordinator
    - Increment batch_flush_count on each flush
    - Update batch_flush_keys_updated and batch_flush_ranges_updated
    - Calculate and update batch_flush_avg_duration_ms
    - Increment batch_flush_errors on failures
    - _Requirements: 5.1, 5.2, 5.4_

  - [x] 8.3 Update metrics in RamCache verification
    - Increment ram_verification_checks on each verification
    - Increment ram_verification_invalidations on Invalid result
    - Increment ram_verification_disk_missing on DiskMissing result
    - Increment ram_verification_errors on Error result
    - Calculate and update ram_verification_avg_duration_ms
    - _Requirements: 8.4, 8.5, 8.6, 8.7_

  - [x] 8.4 Expose pending_disk_updates metric
    - Update pending_disk_updates from AccessTracker count
    - Expose via metrics endpoint
    - _Requirements: 5.4_

- [x] 9. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 10. Write integration tests
  - [ ]* 10.1 Write end-to-end coherency test
    - Start proxy with RAM and disk cache
    - Generate workload with hot data in RAM
    - Verify disk metadata is updated periodically
    - Trigger disk eviction
    - Verify hot data is not evicted
    - _Requirements: 8.5_

  - [ ]* 10.2 Write property test for disk metadata consistency
    - **Property 13: Disk metadata consistency**
    - **Validates: Requirements 8.3**

  - [ ]* 10.3 Write property test for concurrent update safety
    - **Property 14: Concurrent update safety**
    - **Validates: Requirements 8.4**

  - [ ]* 10.4 Write property test for eviction correctness
    - **Property 15: Eviction correctness**
    - **Validates: Requirements 8.5**

  - [ ]* 10.5 Write multi-instance test
    - Start multiple proxy instances sharing disk cache
    - Generate RAM hits on different instances
    - Verify file locking prevents corruption
    - Verify all updates are applied correctly
    - _Requirements: 3.1, 3.2, 3.3_

  - [ ]* 10.6 Write shutdown test
    - Generate RAM hits with pending updates
    - Trigger graceful shutdown
    - Verify pending updates are flushed within 5 seconds
    - Verify no data loss
    - _Requirements: 4.4_

  - [ ]* 10.7 Write property test for verification throttling
    - **Property 16: Verification throttling**
    - **Validates: Requirements 1.7, 8.1, 8.8**

  - [ ]* 10.8 Write property test for verification on mismatch
    - **Property 17: Verification on mismatch**
    - **Validates: Requirements 1.8, 8.5**

  - [ ]* 10.9 Write property test for verification performance
    - **Property 18: Verification performance**
    - **Validates: Requirements 8.3**

  - [ ]* 10.10 Write property test for verification error handling
    - **Property 19: Verification error handling**
    - **Validates: Requirements 8.7**

  - [ ]* 10.11 Write property test for verification on disk missing
    - **Property 20: Verification on disk missing**
    - **Validates: Requirements 8.6**

- [ ] 11. Write unit tests for configuration
  - [ ]* 11.1 Test flush_interval validation
    - Test valid range (10-600 seconds)
    - Test boundary values
    - Test invalid values (< 10, > 600)
    - Verify default value (60 seconds)
    - _Requirements: 2.1, 7.1, 7.4, 7.5_

  - [ ]* 11.2 Test flush_threshold validation
    - Test valid range (10-10000)
    - Test boundary values
    - Test invalid values (< 10, > 10000)
    - Verify default value (100)
    - _Requirements: 2.2, 7.2, 7.4, 7.5_

  - [ ]* 11.3 Test flush_on_eviction configuration
    - Test enabling/disabling write-back
    - Verify default value (true)
    - _Requirements: 7.3, 7.4_

- [ ] 12. Write property tests for flush triggering
  - [ ]* 12.1 Write property test for flush triggering
    - **Property 3: Flush triggering**
    - **Validates: Requirements 1.5, 2.3**

  - [ ]* 12.2 Write property test for error logging
    - **Property 11: Error logging**
    - **Validates: Requirements 5.3, 4.5**

  - [ ]* 12.3 Write property test for configuration validation
    - **Property 12: Configuration validation**
    - **Validates: Requirements 7.5**

- [x] 13. Update documentation
  - [x]* 13.1 Update CACHING.md with batch update and verification behavior
    - Document AccessTracker component
    - Document verification mechanism and throttling
    - Document configuration options (flush and verification intervals)
    - Document performance characteristics
    - Document monitoring metrics
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 8.1, 8.3_

  - [x]* 13.2 Add configuration examples to config.example.yaml
    - Add ram_cache_flush_interval example
    - Add ram_cache_flush_threshold example
    - Add ram_cache_flush_on_eviction example
    - Add ram_cache_verification_interval example
    - Include comments explaining each option
    - _Requirements: 7.1, 7.2, 7.3_

- [x] 14. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
