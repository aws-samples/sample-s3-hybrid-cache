# Design Document

## Overview

This design outlines the complete removal of S3 versioning support from the proxy. The removal will simplify the codebase by eliminating version-specific cache keys, data structures, code paths, and the `versions/` cache directory. Versioned requests (those with `versionId` query parameters) will bypass the cache entirely and be forwarded directly to S3, ensuring users can still access versioned objects while the proxy focuses on its core caching functionality for non-versioned requests.

The removal is a simplification effort that reduces code complexity without impacting the proxy's primary use case as a transparent forwarder for standard S3 operations.

## Architecture

### Current State

The proxy currently supports versioning through:
- Version-aware cache keys: `/bucket/object_key:version:version_id`
- `version_id` fields in ObjectMetadata, CacheMetadata, and Range structures
- Separate `versions/` cache directory for versioned objects
- Version ID extraction from S3 response headers (`x-amz-version-id`)
- Version-specific methods in CacheManager and DiskCacheManager
- Version isolation logic to prevent conflicts between versions

### Target State

After removal:
- Simple cache keys: `/bucket/object_key` (no version component)
- No `version_id` fields in any data structures
- No `versions/` cache directory
- No version ID extraction or storage
- Versioned requests bypass cache entirely
- Simplified cache type determination logic
- Reduced code paths and test surface area

### Migration Strategy

This is a breaking change for any cached versioned objects. The migration approach:
1. **Clean slate**: Deploy new version, existing versioned cache entries become inaccessible
2. **Automatic cleanup**: Old `versions/` directory can be manually deleted after deployment
3. **Graceful degradation**: Versioned requests continue to work via S3 passthrough

## Components and Interfaces

### 1. Cache Key Generation

**Current Implementation:**
```rust
// Generates versioned cache keys
fn generate_versioned_cache_key(path: &str, version_id: &str) -> String {
    format!("{}:version:{}", path, version_id)
}
```

**New Implementation:**
```rust
// Only generates simple cache keys
fn generate_cache_key(path: &str) -> String {
    path.to_string()  // Path format: /bucket/object_key
}
// Remove: generate_versioned_cache_key()
// Remove: generate_versioned_part_cache_key()
```

### 2. Data Structures

**ObjectMetadata (cache_types.rs):**
```rust
// BEFORE
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub content_type: Option<String>,
    pub version_id: Option<String>,  // REMOVE THIS
    // ... other fields
}

// AFTER
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub content_type: Option<String>,
    // version_id removed
    // ... other fields
}
```

**CacheMetadata:**
```rust
// BEFORE
pub struct CacheMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub version_id: Option<String>,  // REMOVE THIS
    // ... other fields
}

// AFTER
pub struct CacheMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    // version_id removed
    // ... other fields
}
```

**Range:**
```rust
// BEFORE
pub struct Range {
    pub start: u64,
    pub end: u64,
    pub data: Vec<u8>,
    pub version_id: Option<String>,  // REMOVE THIS
    // ... other fields
}

// AFTER
pub struct Range {
    pub start: u64,
    pub end: u64,
    pub data: Vec<u8>,
    // version_id removed
    // ... other fields
}
```

**S3UrlParams:**
```rust
// BEFORE
pub struct S3UrlParams {
    pub version_id: Option<String>,  // REMOVE THIS
    pub part_number: Option<u32>,
    pub upload_id: Option<String>,
    // ... other fields
}

// AFTER
pub struct S3UrlParams {
    pub part_number: Option<u32>,
    pub upload_id: Option<String>,
    // ... other fields
}

// Remove methods:
// - is_versioned()
// - parse version_id from query string
```

### 3. Cache Type Determination

**DiskCacheManager (disk_cache.rs):**
```rust
// BEFORE
pub fn determine_cache_type(&self, cache_key: &str) -> &str {
    if cache_key.contains(":version:") && cache_key.contains(":part:") {
        "parts"
    } else if cache_key.contains(":part:") {
        "parts"
    } else if cache_key.contains(":version:") && cache_key.contains(":range:") {
        "ranges"
    } else if cache_key.contains(":range:") {
        "ranges"
    } else if cache_key.contains(":version:") {
        "versions"  // REMOVE THIS CASE
    } else {
        "objects"
    }
}

// AFTER
pub fn determine_cache_type(&self, cache_key: &str) -> &str {
    if cache_key.contains(":part:") {
        "parts"
    } else if cache_key.contains(":range:") {
        "ranges"
    } else {
        "objects"
    }
}
```

### 4. Cache Directory Initialization

**Permissions Module (permissions.rs):**
```rust
// BEFORE
let subdirs = vec!["objects", "ranges", "versions", "locks", "head_cache"];

// AFTER
let subdirs = vec!["objects", "ranges", "locks", "head_cache"];
// Remove "versions" from the list
```

### 5. Version ID Extraction

**Signed Request Proxy (signed_request_proxy.rs):**
```rust
// BEFORE
let version_id = response_headers
    .get("x-amz-version-id")
    .or_else(|| response_headers.get("X-Amz-Version-Id"))
    .cloned();

ObjectMetadata::new(etag, last_modified, content_length, content_type, version_id)

// AFTER
// Remove version_id extraction entirely
ObjectMetadata::new(etag, last_modified, content_length, content_type)
```

### 6. Cache Bypass Logic

**HTTP Proxy (http_proxy.rs):**
```rust
// NEW: Add version detection and bypass
fn should_bypass_cache(url_params: &S3UrlParams) -> bool {
    // Check for versionId in query parameters
    if url_params.has_version_id() {
        info!("Bypassing cache for versioned request");
        return true;
    }
    // ... other bypass conditions
    false
}
```

### 7. Multipart Upload Methods

**CacheManager (cache.rs):**
```rust
// BEFORE
pub async fn initiate_multipart_upload(
    &self,
    path: &str,
    version_id: Option<&str>,  // REMOVE THIS
) -> Result<()>

pub async fn store_part(
    &self,
    path: &str,
    part_number: u32,
    version_id: Option<&str>,  // REMOVE THIS
    data: &[u8],
    etag: String,
) -> Result<()>

pub async fn complete_multipart_upload(
    &self,
    path: &str,
    version_id: Option<&str>,  // REMOVE THIS
) -> Result<()>

// AFTER
pub async fn initiate_multipart_upload(
    &self,
    path: &str,
) -> Result<()>

pub async fn store_part(
    &self,
    path: &str,
    part_number: u32,
    data: &[u8],
    etag: String,
) -> Result<()>

pub async fn complete_multipart_upload(
    &self,
    path: &str,
) -> Result<()>
```

## Data Models

### Cache Key Format

**Before:**
- Non-versioned: `/bucket/object_key`
- Versioned: `/bucket/object_key:version:version_id`
- Versioned part: `/bucket/object_key:version:version_id:part:N`
- Versioned range: `/bucket/object_key:version:version_id:range:start-end`

**After:**
- All requests: `/bucket/object_key`
- Part: `/bucket/object_key:part:N`
- Range: `/bucket/object_key:range:start-end`

### Cache Directory Structure

**Before:**
```
cache_dir/
├── objects/          # Non-versioned objects
├── ranges/           # Non-versioned ranges
├── versions/         # Versioned objects (REMOVE)
├── head_cache/       # HEAD metadata
└── locks/            # Coordination locks
```

**After:**
```
cache_dir/
├── objects/          # All objects
├── ranges/           # All ranges
├── head_cache/       # HEAD metadata
└── locks/            # Coordination locks
```

### Metadata JSON Format

**Before:**
```json
{
  "cache_key": "/bucket/object.txt:version:abc123",
  "object_metadata": {
    "etag": "\"abc123\"",
    "last_modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    "content_length": 1024,
    "content_type": "text/plain",
    "version_id": "abc123"
  },
  "ranges": [...]
}
```

**After:**
```json
{
  "cache_key": "/bucket/object.txt",
  "object_metadata": {
    "etag": "\"abc123\"",
    "last_modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    "content_length": 1024,
    "content_type": "text/plain"
  },
  "ranges": [...]
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Cache keys never contain version components

*For any* cache key generated by the system, the cache key SHALL NOT contain the substring `:version:`

**Validates: Requirements 1.1, 1.3**

### Property 2: Version IDs do not affect cache key generation

*For any* bucket and object key, generating cache keys with different version IDs (or no version ID) SHALL produce identical cache keys

**Validates: Requirements 1.2**

### Property 3: Serialized metadata never contains version_id

*For any* ObjectMetadata, CacheMetadata, or Range structure, when serialized to JSON, the resulting JSON SHALL NOT contain a "version_id" key

**Validates: Requirements 2.5**

### Property 4: Cache type determination never returns "versions"

*For any* cache key, the cache type determination function SHALL NOT return "versions" as the cache type

**Validates: Requirements 3.2**

### Property 5: Versioned GET requests bypass cache

*For any* GET request with a versionId query parameter, the request SHALL bypass the cache and be forwarded directly to S3

**Validates: Requirements 5.1**

### Property 6: Versioned HEAD requests bypass cache

*For any* HEAD request with a versionId query parameter, the request SHALL bypass the cache and be forwarded directly to S3

**Validates: Requirements 5.2**

### Property 7: Versioned responses are not cached

*For any* request with a versionId query parameter, after the response is returned to the client, no cache entry SHALL exist for that request

**Validates: Requirements 5.4**

### Property 8: Multipart upload parts have no version IDs

*For any* multipart upload part stored in cache, the part metadata SHALL NOT contain a version_id field

**Validates: Requirements 9.2**

### Property 9: Completed multipart uploads have no version in cache key

*For any* completed multipart upload, the cache key SHALL NOT contain `:version:` substring

**Validates: Requirements 9.3**

### Property 10: Non-versioned GET requests are cached normally

*For any* GET request without a versionId query parameter, the response SHALL be cached and retrievable from cache on subsequent requests

**Validates: Requirements 12.1**

### Property 11: Non-versioned HEAD requests are cached normally

*For any* HEAD request without a versionId query parameter, the metadata SHALL be cached and retrievable from cache on subsequent requests

**Validates: Requirements 12.2**

### Property 12: PUT requests are cached normally

*For any* PUT request, the object SHALL be cached and retrievable from cache on subsequent GET requests

**Validates: Requirements 12.3**

### Property 13: Non-versioned multipart uploads are cached normally

*For any* multipart upload without version IDs, the completed upload SHALL be cached and retrievable from cache on subsequent GET requests

**Validates: Requirements 12.4**

### Property 14: Non-versioned range requests work normally

*For any* range request without a versionId query parameter, the range SHALL be cached and subsequent range requests SHALL be served from cache with proper merging

**Validates: Requirements 12.5**

### Property 15: Cache invalidation removes correct files

*For any* cache entry invalidation, only the metadata and range files for the non-versioned cache key SHALL be removed, and no version-specific files SHALL be checked

**Validates: Requirements 15.2**

## Error Handling

### Version Detection

The system will detect versioned requests by checking for the `versionId` query parameter in the request URL. This detection happens early in the request processing pipeline, before any cache lookup.

**Detection Logic:**
```rust
fn has_version_id(query_string: &str) -> bool {
    query_string.contains("versionId=")
}
```

### Cache Bypass Flow

When a versioned request is detected:
1. Log at INFO level: "Bypassing cache for versioned request: {path}?versionId={version_id}"
2. Increment cache bypass metric with reason "versioned_request"
3. Forward request directly to S3 without cache lookup
4. Return S3 response to client without caching
5. No cache entry is created or modified

### Backward Compatibility

**Existing Cached Versioned Objects:**
- Old `versions/` directory entries become inaccessible after deployment
- No automatic migration or cleanup
- Manual cleanup recommended: `rm -rf cache_dir/versions/`

**Non-Versioned Requests:**
- All existing non-versioned cache entries remain valid
- No changes to cache key format for non-versioned requests
- No changes to cache behavior for standard operations

### Error Scenarios

**Scenario 1: Versioned Request with Cache Lookup Attempt**
- Detection: Version ID found in query parameters
- Action: Skip cache lookup, forward to S3
- Result: Request succeeds, no cache pollution

**Scenario 2: Old Versioned Cache Entry Exists**
- Detection: `versions/` directory contains old entries
- Action: Entries are ignored, never accessed
- Result: No impact on operations, manual cleanup recommended

**Scenario 3: Code References Removed Methods**
- Detection: Compilation error for removed methods
- Action: Update calling code to remove version parameters
- Result: Compilation succeeds after updates

## Testing Strategy

### Unit Testing

Unit tests will verify:
1. **Cache key generation**: Keys never contain `:version:` substring
2. **Cache type determination**: Never returns "versions"
3. **Metadata serialization**: JSON never contains "version_id"
4. **Data structure compilation**: Structures compile without version_id fields
5. **Cache bypass detection**: Versioned requests are correctly identified

**Example Unit Tests:**
```rust
#[test]
fn test_cache_key_has_no_version_component() {
    let key = generate_cache_key("/bucket/object.txt");
    assert!(!key.contains(":version:"));
}

#[test]
fn test_cache_type_never_returns_versions() {
    let keys = vec![
        "/bucket/object",
        "/bucket/object:part:1",
        "/bucket/object:range:0-1024",
    ];
    for key in keys {
        assert_ne!(determine_cache_type(key), "versions");
    }
}

#[test]
fn test_metadata_json_has_no_version_id() {
    let metadata = ObjectMetadata::new(
        "etag".to_string(),
        "last_modified".to_string(),
        1024,
        Some("text/plain".to_string()),
    );
    let json = serde_json::to_string(&metadata).unwrap();
    assert!(!json.contains("version_id"));
}
```

### Property-Based Testing

Property-based tests will use the `quickcheck` framework to verify properties across many randomly generated inputs:

1. **Property 1-2**: Cache key format and determinism
2. **Property 3**: Metadata serialization
3. **Property 4**: Cache type determination
4. **Property 10-14**: Non-versioned request caching

**Example Property Test:**
```rust
use quickcheck::{quickcheck, TestResult};

#[quickcheck]
fn prop_cache_keys_never_contain_version(path: String) -> TestResult {
    if path.is_empty() || !path.starts_with('/') {
        return TestResult::discard();
    }
    
    let cache_key = generate_cache_key(&path);
    TestResult::from_bool(!cache_key.contains(":version:"))
}

#[quickcheck]
fn prop_version_id_does_not_affect_cache_key(
    path: String,
    version1: String,
    version2: String,
) -> TestResult {
    if path.is_empty() || !path.starts_with('/') {
        return TestResult::discard();
    }
    
    let key1 = generate_cache_key(&path);
    let key2 = generate_cache_key(&path);
    
    TestResult::from_bool(key1 == key2)
}
```

### Integration Testing

Integration tests will verify:
1. **Versioned request bypass**: GET/HEAD with versionId bypass cache
2. **Non-versioned caching**: Standard requests cache normally
3. **Multipart uploads**: Work without version tracking
4. **Cache invalidation**: Removes correct files
5. **Directory structure**: No `versions/` directory created

**Example Integration Test:**
```rust
#[tokio::test]
async fn test_versioned_get_bypasses_cache() {
    let cache_manager = setup_cache_manager();
    
    // Make versioned GET request
    let response = cache_manager
        .get_with_params("/bucket/object.txt", "versionId=abc123")
        .await
        .unwrap();
    
    // Verify response returned
    assert!(response.is_some());
    
    // Verify no cache entry created
    let cache_entry = cache_manager
        .get_cached_response("/bucket/object.txt")
        .await
        .unwrap();
    assert!(cache_entry.is_none());
}

#[tokio::test]
async fn test_non_versioned_get_caches_normally() {
    let cache_manager = setup_cache_manager();
    
    // Make non-versioned GET request
    let response1 = cache_manager
        .get("/bucket/object.txt")
        .await
        .unwrap();
    
    // Verify cached
    let response2 = cache_manager
        .get("/bucket/object.txt")
        .await
        .unwrap();
    
    assert_eq!(response1.body, response2.body);
}
```

### Manual Testing

Manual verification steps:
1. Deploy new version
2. Make versioned GET request: `curl http://proxy/bucket/object.txt?versionId=abc123`
3. Verify response returned and logs show cache bypass
4. Check cache directory: no `versions/` subdirectory
5. Make non-versioned GET request: `curl http://proxy/bucket/object.txt`
6. Verify response cached and subsequent requests served from cache
7. Check cache directory structure matches new format

## Implementation Notes

### Compilation Guarantees

Many requirements are enforced by the Rust compiler:
- Removing `version_id` fields from structures
- Removing versioned methods from APIs
- Updating method signatures to remove version parameters

Any code that references removed fields or methods will fail to compile, providing immediate feedback.

### Migration Path

**For Operators:**
1. Deploy new version of proxy
2. Versioned requests automatically bypass cache
3. Non-versioned requests continue working normally
4. Optionally clean up old `versions/` directory: `rm -rf cache_dir/versions/`

**For Developers:**
1. Update any code calling versioned methods
2. Remove version_id parameters from method calls
3. Update tests to remove version-related assertions
4. Verify compilation succeeds

### Performance Impact

**Positive Impacts:**
- Simpler cache key generation (no version component)
- Reduced metadata size (no version_id field)
- Fewer code paths to execute
- Smaller cache directory structure

**Neutral Impacts:**
- Versioned requests bypass cache (same as cache miss)
- No performance change for non-versioned requests

### Rollback Strategy

If rollback is needed:
1. Deploy previous version
2. Versioned caching resumes
3. Old `versions/` directory entries become accessible again
4. No data loss for non-versioned cache entries

## Dependencies

### External Dependencies

No new external dependencies required. This is purely a removal/simplification effort.

### Internal Dependencies

**Modified Modules:**
- `cache_types.rs`: Remove version_id fields
- `cache.rs`: Remove versioned methods
- `disk_cache.rs`: Simplify cache type determination
- `signed_request_proxy.rs`: Remove version ID extraction
- `signed_put_handler.rs`: Remove version ID storage
- `permissions.rs`: Remove versions directory
- `http_proxy.rs`: Add version bypass logic

**Modified Tests:**
- Remove `tests/versioning_multipart_test.rs`
- Update all tests that reference version_id
- Update integration tests to remove version assertions

**Modified Documentation:**
- `docs/CACHING.md`: Remove version cache section
- `README.md`: Remove versioning from features
- Configuration examples: Remove version references

## Deployment Considerations

### Breaking Changes

This is a **breaking change** for versioned object caching:
- Existing versioned cache entries become inaccessible
- Versioned requests will always go to S3 (no caching)
- Old `versions/` directory can be manually deleted

### Non-Breaking Aspects

- Non-versioned requests continue working identically
- Cache key format unchanged for non-versioned requests
- No configuration changes required
- No database migrations needed

### Deployment Steps

1. **Pre-deployment:**
   - Review and approve this design
   - Communicate breaking change to users
   - Document that versioned requests will bypass cache

2. **Deployment:**
   - Deploy new version using standard process
   - Monitor logs for version bypass messages
   - Verify non-versioned requests cache normally

3. **Post-deployment:**
   - Optionally clean up `versions/` directory
   - Update monitoring dashboards to remove version metrics
   - Archive versioned-request-validation spec

### Monitoring

**Key Metrics:**
- Cache bypass count with reason "versioned_request"
- Cache hit/miss rates (should remain stable for non-versioned)
- Error rates (should not increase)

**Log Messages:**
- "Bypassing cache for versioned request: {path}?versionId={version_id}"
- No more "Extracted version ID" messages
- No more version_id in cache operation logs

## Future Considerations

### Potential Re-addition

If versioning support is needed in the future:
1. Review this design document to understand what was removed
2. Review archived `versioned-request-validation` spec
3. Consider whether full versioning or limited support is needed
4. Implement as a new feature with updated design

### Alternative Approaches

**Partial Versioning Support:**
- Could support version ID passthrough without caching
- Current design already does this via bypass logic

**Version-Aware Cache Keys (Not Recommended):**
- Would require re-adding all removed complexity
- Not aligned with proxy's core use case

## Conclusion

This design provides a comprehensive plan for removing S3 versioning support from the proxy. The removal simplifies the codebase significantly while maintaining full functionality for non-versioned requests. Versioned requests will continue to work via S3 passthrough, ensuring no loss of functionality for users who need versioning - they just won't benefit from caching for those requests.

The implementation is straightforward, with many requirements enforced by the compiler. The testing strategy ensures correctness through unit tests, property-based tests, and integration tests. The deployment is low-risk for non-versioned operations, with clear communication about the breaking change for versioned caching.
