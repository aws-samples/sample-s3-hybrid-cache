# Requirements Document

## Introduction

Remove all S3 versioning support from the proxy to simplify the codebase and reduce maintenance burden. The proxy currently supports versioned object caching (requests with `versionId` query parameter), but this feature adds complexity without significant value for the proxy's core use case as a transparent forwarder. Removing versioning will eliminate the `versions/` cache directory, version-specific cache keys, and all version-related code paths.

This removal is justified because:
2. Versioned requests are rare in typical S3 proxy usage patterns
3. Versioning support adds significant code complexity for minimal benefit
4. The proxy can still forward versioned requests to S3, just without caching them

## Glossary

- **Version ID**: S3's unique identifier for a specific version of an object (e.g., "abc123")
- **Versioned Request**: S3 GET/HEAD request with `versionId` query parameter
- **Cache Key**: Unique identifier for cached data, format: `/bucket/object_key` (no version component after removal)
- **Sharded Path**: Bucket-first hash-based directory structure: `{type}/{bucket}/{XX}/{YYY}/{filename}`
- **Cache Manager**: Component coordinating RAM and disk caching operations
- **Disk Cache Manager**: Component handling file-based cache storage with sharding
- **ObjectMetadata**: Data structure containing object metadata including ETag, Last-Modified, Content-Length, etc.
- **S3UrlParams**: Structure for parsing S3 query parameters from request URLs

## Requirements

### Requirement 1: Remove Version ID from Cache Keys

**User Story:** As a developer, I want cache keys to never include version IDs, so that the caching logic is simplified.

#### Acceptance Criteria

1. WHEN generating a cache key for any request THEN the system SHALL use the format `/bucket/object_key` without version components
2. WHEN two requests have the same bucket and object key but different version IDs THEN the system SHALL generate identical cache keys
3. WHEN the cache key generation code is examined THEN the system SHALL NOT contain logic for appending `:version:` components
4. WHEN the cache key sanitization code is examined THEN the system SHALL NOT contain special handling for version ID encoding
5. WHEN cache keys are logged THEN the system SHALL NOT include version ID information

### Requirement 2: Remove Version ID from Data Structures

**User Story:** As a developer, I want data structures to not store version IDs, so that memory usage is reduced and serialization is simpler.

#### Acceptance Criteria

1. WHEN the ObjectMetadata structure is examined THEN the system SHALL NOT contain a `version_id` field
2. WHEN the CacheMetadata structure is examined THEN the system SHALL NOT contain a `version_id` field
3. WHEN the Range structure is examined THEN the system SHALL NOT contain a `version_id` field
4. WHEN the S3UrlParams structure is examined THEN the system SHALL NOT contain a `version_id` field
5. WHEN metadata is serialized to JSON THEN the system SHALL NOT include version ID fields

### Requirement 3: Remove Versions Directory

**User Story:** As a system administrator, I want the cache to not create a `versions/` directory, so that the cache structure is simpler.

#### Acceptance Criteria

1. WHEN the cache directory is initialized THEN the system SHALL NOT create a `versions/` subdirectory
2. WHEN determining cache type from a cache key THEN the system SHALL NOT return "versions" as a cache type
3. WHEN the permissions validation code is examined THEN the system SHALL NOT check for `versions/` directory permissions
4. WHEN the cache directory structure documentation is examined THEN the system SHALL NOT reference a `versions/` directory
5. WHEN listing cache subdirectories THEN the system SHALL NOT include "versions" in the list

### Requirement 4: Remove Version-Specific Code Paths

**User Story:** As a developer, I want version-specific code paths removed, so that the codebase is easier to maintain.

#### Acceptance Criteria

1. WHEN the cache manager code is examined THEN the system SHALL NOT contain methods for versioned cache operations
2. WHEN the disk cache code is examined THEN the system SHALL NOT contain logic for determining if a cache key is versioned
3. WHEN the cache type determination code is examined THEN the system SHALL NOT check for `:version:` in cache keys
4. WHEN the signed request proxy code is examined THEN the system SHALL NOT extract version IDs from response headers
5. WHEN the HTTP proxy code is examined THEN the system SHALL NOT parse version IDs from query parameters

### Requirement 5: Bypass Versioned Requests

**User Story:** As a user, I want versioned requests to bypass the cache, so that I can still access versioned objects from S3.

#### Acceptance Criteria

1. WHEN a GET request includes a `versionId` query parameter THEN the system SHALL forward the request directly to S3 without caching
2. WHEN a HEAD request includes a `versionId` query parameter THEN the system SHALL forward the request directly to S3 without caching
3. WHEN a versioned request is processed THEN the system SHALL log that caching was bypassed due to versioning
4. WHEN a versioned response is received from S3 THEN the system SHALL return it to the client without storing in cache
5. WHEN cache bypass occurs for versioned requests THEN the system SHALL increment appropriate metrics

### Requirement 6: Remove Version-Related Tests

**User Story:** As a developer, I want version-related tests removed, so that the test suite is focused on supported features.

#### Acceptance Criteria

1. WHEN the test suite is examined THEN the system SHALL NOT contain tests for versioned cache key generation
2. WHEN the test suite is examined THEN the system SHALL NOT contain tests for versioned object storage and retrieval
3. WHEN the test suite is examined THEN the system SHALL NOT contain tests for version isolation
4. WHEN the test suite is examined THEN the system SHALL NOT contain the `versioning_multipart_test.rs` file
5. WHEN the test suite is run THEN the system SHALL NOT execute any version-related test cases

### Requirement 7: Update Documentation

**User Story:** As a user, I want documentation to reflect that versioning is not supported, so that I have accurate expectations.

#### Acceptance Criteria

1. WHEN the caching documentation is examined THEN the system SHALL NOT describe version cache functionality
2. WHEN the cache directory structure documentation is examined THEN the system SHALL NOT reference a `versions/` directory
3. WHEN the cache bypass documentation is examined THEN the system SHALL explicitly state that versioned requests bypass the cache
4. WHEN the README is examined THEN the system SHALL NOT list versioning as a supported feature
5. WHEN the configuration documentation is examined THEN the system SHALL NOT reference version-related settings

### Requirement 8: Remove Version ID Extraction

**User Story:** As a developer, I want version ID extraction removed from response processing, so that response handling is simpler.

#### Acceptance Criteria

1. WHEN processing S3 responses THEN the system SHALL NOT extract the `x-amz-version-id` header
2. WHEN creating ObjectMetadata from responses THEN the system SHALL NOT include version ID parameters
3. WHEN logging response metadata THEN the system SHALL NOT include version ID information
4. WHEN the signed request proxy code is examined THEN the system SHALL NOT contain version ID extraction logic
5. WHEN the signed PUT handler code is examined THEN the system SHALL NOT store version IDs in metadata

### Requirement 9: Simplify Multipart Upload Handling

**User Story:** As a developer, I want multipart uploads to not track version IDs, so that multipart logic is simpler.

#### Acceptance Criteria

1. WHEN initiating a multipart upload THEN the system SHALL NOT accept or store version ID parameters
2. WHEN uploading parts THEN the system SHALL NOT associate parts with version IDs
3. WHEN completing multipart uploads THEN the system SHALL NOT include version IDs in the cache key
4. WHEN the multipart upload code is examined THEN the system SHALL NOT contain version ID parameters in method signatures
5. WHEN multipart metadata is stored THEN the system SHALL NOT include version ID fields

### Requirement 10: Remove Version-Related Metrics

**User Story:** As a system administrator, I want version-related metrics removed, so that metrics are focused on supported operations.

#### Acceptance Criteria

1. WHEN cache operations are logged THEN the system SHALL NOT include version ID in log messages
2. WHEN metrics are collected THEN the system SHALL NOT track version-specific cache hits or misses
3. WHEN the metrics code is examined THEN the system SHALL NOT contain version-related metric labels
4. WHEN the logging code is examined THEN the system SHALL NOT format version IDs for output
5. WHEN observability dashboards are configured THEN the system SHALL NOT display version-related metrics

### Requirement 11: Clean Up Version-Related Specs

**User Story:** As a developer, I want version-related spec documents removed or archived, so that the specs directory reflects current functionality.

#### Acceptance Criteria

1. WHEN the specs directory is examined THEN the system SHALL NOT contain an active `versioned-request-validation` spec
2. WHEN the specs directory is examined THEN the system SHALL contain this `remove-versioning` spec
3. WHEN version-related specs are archived THEN the system SHALL move them to an `archived/` subdirectory
4. WHEN the specs README is examined THEN the system SHALL NOT reference versioned request validation as a feature
5. WHEN new specs are created THEN the system SHALL NOT reference versioning as a supported capability

### Requirement 12: Maintain Backward Compatibility for Non-Versioned Requests

**User Story:** As a user, I want non-versioned requests to continue working exactly as before, so that existing functionality is not disrupted.

#### Acceptance Criteria

1. WHEN a GET request without `versionId` is processed THEN the system SHALL cache the response normally
2. WHEN a HEAD request without `versionId` is processed THEN the system SHALL cache the metadata normally
3. WHEN a PUT request is processed THEN the system SHALL cache the object normally
4. WHEN multipart uploads without versioning are processed THEN the system SHALL cache them normally
5. WHEN range requests without versioning are processed THEN the system SHALL cache and merge ranges normally

### Requirement 13: Error Handling for Versioned Requests

**User Story:** As a developer, I want clear logging when versioned requests are bypassed, so that I can understand cache behavior.

#### Acceptance Criteria

1. WHEN a versioned request is detected THEN the system SHALL log at INFO level that caching is bypassed
2. WHEN a versioned request is forwarded to S3 THEN the system SHALL log the request path and version ID
3. WHEN a versioned response is returned THEN the system SHALL log that the response was not cached
4. WHEN cache bypass metrics are incremented THEN the system SHALL include "versioned_request" as the bypass reason
5. WHEN debugging cache behavior THEN the system SHALL provide clear log messages distinguishing versioned from non-versioned requests

### Requirement 14: Remove Version-Related Configuration

**User Story:** As a system administrator, I want version-related configuration removed, so that configuration is simpler.

#### Acceptance Criteria

1. WHEN the configuration structure is examined THEN the system SHALL NOT contain version-related settings
2. WHEN the configuration documentation is examined THEN the system SHALL NOT describe version-related options
3. WHEN the example configuration files are examined THEN the system SHALL NOT include version-related settings
4. WHEN configuration is validated THEN the system SHALL NOT check for version-related fields
5. WHEN configuration is loaded THEN the system SHALL NOT parse version-related values

### Requirement 15: Simplify Cache Invalidation

**User Story:** As a developer, I want cache invalidation to not consider version IDs, so that invalidation logic is simpler.

#### Acceptance Criteria

1. WHEN invalidating a cache entry THEN the system SHALL NOT check for version-specific files
2. WHEN invalidating a cache entry THEN the system SHALL remove only non-versioned metadata and range files
3. WHEN the invalidation code is examined THEN the system SHALL NOT contain logic for version isolation
4. WHEN invalidating all versions of an object THEN the system SHALL invalidate only the single non-versioned entry
5. WHEN invalidation is logged THEN the system SHALL NOT include version ID information
