# Design Document: S3 Part-Number Request Caching

## Overview

This design extends the S3 proxy's caching capabilities to support GetObject requests with `partNumber` query parameters. Currently, these requests bypass the cache entirely. By treating parts as ranges and storing multipart metadata, we can serve repeated part requests from cache while maintaining compatibility with the existing range storage architecture.

The key insight is that S3's `Content-Range` header in GetObjectPart responses provides the exact byte offsets needed to store parts as ranges. Combined with the `x-amz-mp-parts-count` header, we can calculate boundaries for all parts and serve future requests from cache.

## Architecture

### High-Level Flow

```
Client Request (GET with partNumber=N)
    ↓
Parse partNumber from query string
    ↓
Check if ObjectMetadata exists with multipart info
    ↓
    ├─ Yes: Calculate expected byte range for part N
    │   ↓
    │   Check if range is cached
    │   ↓
    │   ├─ Yes: Serve from cache with Content-Range header
    │   └─ No: Fetch from S3, cache as range
    │
    └─ No: Fetch from S3, extract multipart metadata
        ↓
        Store part as range using Content-Range offsets
        ↓
        Update ObjectMetadata with PartsCount and PartSize
```

### Integration Points

1. **http_proxy.rs**: Remove bypass logic for GET requests with partNumber
2. **cache.rs**: Add multipart metadata extraction and part boundary calculation
3. **cache_types.rs**: Extend ObjectMetadata with multipart fields
4. **disk_cache.rs**: No changes needed (parts stored as regular ranges)
5. **s3_client.rs**: Extract multipart headers from responses

### Backward Compatibility

- Existing ObjectMetadata without multipart fields will use default values (None)
- First part request will populate metadata for subsequent requests
- Regular range requests continue to work unchanged
- No migration needed for existing cache entries

## Components and Interfaces

### 1. Multipart Metadata Extraction

**Location**: `src/cache.rs`

```rust
/// Extract multipart metadata from S3 response headers
pub struct MultipartInfo {
    pub parts_count: Option<u32>,
    pub part_size: Option<u64>,
    pub part_number: Option<u32>,
}

impl Cache {
    /// Extract multipart information from response headers
    fn extract_multipart_info(
        &self,
        headers: &HeaderMap,
        content_length: u64,
    ) -> MultipartInfo {
        // Parse x-amz-mp-parts-count header
        // Calculate part_size from content_length (for first part)
        // Extract part_number from request context
    }
    
    /// Calculate byte range for a given part number
    fn calculate_part_range(
        &self,
        part_number: u32,
        part_size: u64,
        parts_count: u32,
        total_size: u64,
    ) -> (u64, u64) {
        // For parts 1 to N-1: (part_number - 1) * part_size to part_number * part_size - 1
        // For part N: (N - 1) * part_size to total_size - 1
    }
}
```

### 2. Part Request Detection

**Location**: `src/http_proxy.rs`

```rust
impl HttpProxy {
    /// Check if request is a GetObjectPart (not an upload verification)
    fn is_get_object_part(
        method: &Method,
        query_params: &HashMap<String, String>,
    ) -> Option<u32> {
        // Return Some(part_number) if:
        // - Method is GET
        // - partNumber parameter exists and is valid
        // - uploadId parameter does NOT exist (that's upload verification)
        // Return None otherwise
    }
}
```

### 3. ObjectMetadata Extension

**Location**: `src/cache_types.rs`

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectMetadata {
    // ... existing fields ...
    
    /// Multipart object information
    #[serde(default)]
    pub parts_count: Option<u32>,
    
    #[serde(default)]
    pub part_size: Option<u64>,
    
    /// Upload ID for write caching (TODO: future feature)
    #[serde(default)]
    pub upload_id: Option<String>,
}
```

### 4. Cache Lookup for Parts

**Location**: `src/cache.rs`

```rust
impl Cache {
    /// Look up cached part by part number
    pub async fn lookup_part(
        &self,
        cache_key: &str,
        part_number: u32,
    ) -> Result<Option<CachedPartResponse>> {
        // 1. Load ObjectMetadata
        // 2. If parts_count and part_size exist, calculate expected range
        // 3. Check if range is cached
        // 4. If cached, return with Content-Range header
        // 5. If not cached or no metadata, return None
    }
    
    /// Store part response as a range
    pub async fn store_part(
        &self,
        cache_key: &str,
        part_number: u32,
        content_range: &str,
        headers: &HeaderMap,
        body: Bytes,
    ) -> Result<()> {
        // 1. Parse Content-Range to get start, end, total
        // 2. Store body as range file
        // 3. Update ObjectMetadata with multipart info if not present
        // 4. Add RangeSpec to metadata
    }
}
```

### 5. Content-Range Parsing

**Location**: `src/cache.rs`

```rust
/// Parse Content-Range header: "bytes 0-8388607/5368709120"
fn parse_content_range(content_range: &str) -> Result<(u64, u64, u64)> {
    // Returns (start, end, total_size)
    // Format: "bytes START-END/TOTAL"
}
```

## Data Models

### Extended ObjectMetadata

```rust
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub content_type: Option<String>,
    
    // Existing multipart upload fields (for write caching)
    pub upload_state: UploadState,
    pub cumulative_size: u64,
    pub parts: Vec<PartInfo>,
    
    // NEW: Multipart download metadata
    pub parts_count: Option<u32>,      // From x-amz-mp-parts-count header
    pub part_size: Option<u64>,        // Calculated from first part
    pub upload_id: Option<String>,     // TODO: For write caching
    
    // Existing compression fields
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
}
```

### Part Boundary Calculation

For a multipart object with:
- Total size: `T` bytes
- Parts count: `N`
- Part size: `P` bytes (uniform for parts 1 to N-1)

Part boundaries:
- Part 1: bytes 0 to P-1
- Part 2: bytes P to 2P-1
- Part k (k < N): bytes (k-1)P to kP-1
- Part N: bytes (N-1)P to T-1

Example from your request:
- Total size: 5,368,709,120 bytes (5GB)
- Parts count: 640
- Part 1 size: 8,388,608 bytes (8MB)
- Part size: 8,388,608 bytes
- Part 640 size: 5,368,709,120 - (639 * 8,388,608) = 8,388,608 bytes

### Cache Key Strategy

Cache keys remain unchanged - they are derived from bucket and object key WITHOUT query parameters:
- Request: `GET /bucket/object?partNumber=1`
- Cache key: `/bucket/object`

This allows all parts of the same object to share the same ObjectMetadata and be stored as ranges under the same cache entry.

## Data Flow Examples

### Example 1: First Part Request (Cache Miss)

```
1. Client: GET /bucket/5GB?partNumber=1
2. Proxy: Parse partNumber=1
3. Proxy: Check cache for /bucket/5GB with part 1
4. Proxy: No ObjectMetadata or no multipart info → fetch from S3
5. S3: Returns 200 with:
   - Content-Range: bytes 0-8388607/5368709120
   - Content-Length: 8388608
   - x-amz-mp-parts-count: 640
   - ETag: "..."
6. Proxy: Parse Content-Range → start=0, end=8388607, total=5368709120
7. Proxy: Store as range: /bucket/5GB range 0-8388607
8. Proxy: Update ObjectMetadata:
   - parts_count = 640
   - part_size = 8388608
   - content_length = 5368709120
9. Proxy: Stream response to client with original headers
```

### Example 2: Subsequent Part Request (Cache Hit)

```
1. Client: GET /bucket/5GB?partNumber=2
2. Proxy: Parse partNumber=2
3. Proxy: Load ObjectMetadata for /bucket/5GB
4. Proxy: Found parts_count=640, part_size=8388608
5. Proxy: Calculate part 2 range: (2-1)*8388608 to 2*8388608-1 = 8388608-16777215
6. Proxy: Check if range 8388608-16777215 is cached
7. Proxy: Range found in cache
8. Proxy: Read and decompress range data
9. Proxy: Construct response with:
   - Status: 206 Partial Content
   - Content-Range: bytes 8388608-16777215/5368709120
   - Content-Length: 8388608
   - x-amz-mp-parts-count: 640
   - ETag: "..." (from ObjectMetadata)
10. Proxy: Stream cached data to client
```

### Example 3: Last Part Request

```
1. Client: GET /bucket/5GB?partNumber=640
2. Proxy: Parse partNumber=640
3. Proxy: Load ObjectMetadata
4. Proxy: Calculate part 640 range:
   - Start: (640-1) * 8388608 = 5360320512
   - End: 5368709120 - 1 = 5368709119
   - Size: 8388608 bytes (happens to be same size)
5. Proxy: Check cache, serve if available, otherwise fetch from S3
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Part number extraction correctness
*For any* GET request with a valid numeric `partNumber` query parameter, the system should correctly extract the part number as an integer and identify the operation as GetObjectPart.
**Validates: Requirements 1.1, 1.2**

### Property 2: Invalid part number passthrough
*For any* GET request with an invalid or non-numeric `partNumber` parameter, the system should pass the request through to S3 without attempting to cache.
**Validates: Requirements 1.3**

### Property 3: Upload verification bypass
*For any* GET request containing both `partNumber` and `uploadId` parameters, the system should bypass caching since this is an upload verification request, not a download.
**Validates: Requirements 1.4**

### Property 4: Content-Range parsing round-trip
*For any* valid Content-Range header string (format: "bytes START-END/TOTAL"), parsing then formatting should produce an equivalent representation with the same start, end, and total values.
**Validates: Requirements 2.2**

### Property 5: Multipart metadata persistence
*For any* S3 response containing `x-amz-mp-parts-count` and calculable part size, storing this information in ObjectMetadata and then reading it back should yield the same values.
**Validates: Requirements 2.1, 2.4, 2.5**

### Property 6: Part storage as range
*For any* GetObjectPart response with a Content-Range header, the system should store the part data as a range using the exact byte offsets from the Content-Range, creating a RangeSpec with matching start and end values.
**Validates: Requirements 3.1, 3.3**

### Property 7: Compression round-trip for parts
*For any* part data that is compressed during storage, decompressing it should yield data identical to the original part data.
**Validates: Requirements 3.4, 4.5**

### Property 8: Metadata update preserves ranges
*For any* ObjectMetadata with existing cached ranges, updating the metadata with multipart information should not change the count or content of existing ranges.
**Validates: Requirements 3.5, 6.4**

### Property 9: Cached part response completeness
*For any* cached part served to a client, the response should include all required headers: Content-Range, x-amz-mp-parts-count (if available), and ETag, with values matching the original S3 response.
**Validates: Requirements 4.1, 4.2, 4.3, 4.4**

### Property 10: Part boundary calculation correctness
*For any* ObjectMetadata with parts_count and part_size, calculating the byte range for part number N (where 1 ≤ N ≤ parts_count) should produce:
- For parts 1 to N-1: start = (N-1) * part_size, end = N * part_size - 1
- For part N: start = (N-1) * part_size, end = total_size - 1
**Validates: Requirements 5.1, 5.2, 5.3**

### Property 11: Out-of-bounds part number handling
*For any* part number request where the part number exceeds the stored parts_count, the system should pass through to S3 without attempting a cache lookup.
**Validates: Requirements 5.4**

### Property 12: First part populates metadata
*For any* GetObjectPart response received when ObjectMetadata lacks multipart information, the system should extract and store both parts_count and calculated part_size in the metadata.
**Validates: Requirements 6.1, 6.2**

### Property 13: Metadata persistence round-trip
*For any* ObjectMetadata with multipart fields, persisting to disk and then loading should yield an equivalent ObjectMetadata with the same ETag, last_modified, parts_count, and part_size values.
**Validates: Requirements 6.3, 6.5**

### Property 14: Cache invalidation completeness
*For any* object with cached parts, when a PUT, DELETE, or ETag-mismatched HEAD request is received, all cached ranges and multipart metadata should be removed from both memory and disk.
**Validates: Requirements 7.1, 7.2, 7.3, 7.4, 7.5**

### Property 15: Cache metrics accuracy
*For any* sequence of GetObjectPart requests, the cache hit counter should equal the number of requests served from cache, and the cache miss counter should equal the number of requests served from S3.
**Validates: Requirements 8.1, 8.2**

### Property 16: Cache size tracking accuracy
*For any* sequence of part storage and eviction operations, the total cached size metric should equal the sum of all currently cached part sizes.
**Validates: Requirements 8.3, 8.4**

### Property 17: Backward compatibility with old metadata
*For any* ObjectMetadata file created before multipart fields were added, loading the metadata should succeed with default values (None) for parts_count, part_size, and upload_id.
**Validates: Requirements 9.3, 9.4**

### Property 18: Content-Range parsing error handling
*For any* malformed Content-Range header that fails to parse, the system should log the error and pass the request through to S3 without caching.
**Validates: Requirements 10.1**

## Error Handling

### Parse Errors

**Content-Range Parsing**:
- Invalid format → Log error, pass through to S3
- Missing components → Log error, pass through to S3
- Non-numeric values → Log error, pass through to S3

**Part Number Parsing**:
- Non-numeric → Pass through to S3
- Negative or zero → Pass through to S3
- Exceeds parts_count → Pass through to S3

### Storage Errors

**Disk Write Failures**:
- Log error with context (path, size, error message)
- Continue serving response to client
- Do not update ObjectMetadata
- Metrics: Increment cache_write_error counter

**Metadata Update Failures**:
- Log error with context
- Continue serving response to client
- Next request will retry metadata population

### Read Errors

**Cached Part Read Failures**:
- Log error with context
- Fall back to fetching from S3
- Optionally invalidate corrupted cache entry
- Metrics: Increment cache_read_error counter

**Metadata Read Failures**:
- Log error with context
- Treat as cache miss
- Fetch from S3 and attempt to repopulate metadata

### Corruption Detection

**Range File Corruption**:
- Detect via size mismatch or decompression failure
- Log error with cache key and range
- Invalidate affected range
- Fall back to S3
- Metrics: Increment cache_corruption counter

**Metadata Corruption**:
- Detect via JSON parse failure
- Log error with cache key
- Invalidate entire cache entry
- Fall back to S3
- Metrics: Increment metadata_corruption counter

## Testing Strategy

### Unit Tests

1. **Content-Range Parsing**:
   - Valid formats: "bytes 0-8388607/5368709120"
   - Invalid formats: missing components, non-numeric values
   - Edge cases: single byte ranges, maximum values

2. **Part Boundary Calculation**:
   - First part (part 1)
   - Middle parts (parts 2 to N-1)
   - Last part (part N)
   - Edge case: single-part object (N=1)

3. **Multipart Metadata Extraction**:
   - Extract parts_count from header
   - Calculate part_size from content_length
   - Handle missing headers gracefully

4. **ObjectMetadata Serialization**:
   - Serialize with multipart fields
   - Deserialize with multipart fields
   - Deserialize old format without multipart fields (backward compatibility)

### Property-Based Tests

The property-based testing library for Rust is **quickcheck** (already in use in the codebase). Each property test should run a minimum of 100 iterations.

1. **Property 1: Part number extraction correctness**
   - Tag: `**Feature: part-number-caching, Property 1: Part number extraction correctness**`
   - Generator: Random valid part numbers (1 to 10000)
   - Test: Extract part number and verify operation type

2. **Property 2: Invalid part number passthrough**
   - Tag: `**Feature: part-number-caching, Property 2: Invalid part number passthrough**`
   - Generator: Random invalid part numbers (non-numeric strings, negative, zero)
   - Test: Verify passthrough behavior

3. **Property 4: Content-Range parsing round-trip**
   - Tag: `**Feature: part-number-caching, Property 4: Content-Range parsing round-trip**`
   - Generator: Random valid byte ranges
   - Test: Format → Parse → Format should be equivalent

4. **Property 5: Multipart metadata persistence**
   - Tag: `**Feature: part-number-caching, Property 5: Multipart metadata persistence**`
   - Generator: Random parts_count and part_size values
   - Test: Store → Load → Verify equality

5. **Property 7: Compression round-trip for parts**
   - Tag: `**Feature: part-number-caching, Property 7: Compression round-trip for parts**`
   - Generator: Random byte arrays of various sizes
   - Test: Compress → Decompress → Verify equality

6. **Property 8: Metadata update preserves ranges**
   - Tag: `**Feature: part-number-caching, Property 8: Metadata update preserves ranges**`
   - Generator: Random ObjectMetadata with ranges
   - Test: Update metadata → Verify range count unchanged

7. **Property 10: Part boundary calculation correctness**
   - Tag: `**Feature: part-number-caching, Property 10: Part boundary calculation correctness**`
   - Generator: Random parts_count, part_size, total_size, and part_number
   - Test: Calculate boundaries and verify formula correctness

8. **Property 13: Metadata persistence round-trip**
   - Tag: `**Feature: part-number-caching, Property 13: Metadata persistence round-trip**`
   - Generator: Random ObjectMetadata with all fields
   - Test: Serialize → Deserialize → Verify equality

9. **Property 16: Cache size tracking accuracy**
   - Tag: `**Feature: part-number-caching, Property 16: Cache size tracking accuracy**`
   - Generator: Random sequences of store/evict operations
   - Test: Verify metric equals sum of cached sizes

10. **Property 17: Backward compatibility with old metadata**
    - Tag: `**Feature: part-number-caching, Property 17: Backward compatibility with old metadata**`
    - Generator: ObjectMetadata without multipart fields
    - Test: Deserialize and verify default values

### Integration Tests

1. **End-to-End Part Caching**:
   - Request part 1 (cache miss)
   - Verify part stored as range
   - Verify metadata populated
   - Request part 1 again (cache hit)
   - Verify response headers match

2. **Multiple Parts Caching**:
   - Request parts 1, 2, 3 sequentially
   - Verify all stored as separate ranges
   - Verify metadata contains correct parts_count and part_size
   - Request parts in different order
   - Verify all served from cache

3. **Last Part Handling**:
   - Request last part (part N)
   - Verify boundary calculation for potentially smaller last part
   - Verify correct Content-Range header

4. **Cache Invalidation**:
   - Cache multiple parts
   - Issue PUT request
   - Verify all parts invalidated
   - Request part again (cache miss)

5. **Backward Compatibility**:
   - Create cache entry without multipart fields
   - Request part
   - Verify metadata populated
   - Verify existing ranges preserved

### Performance Tests

1. **Part Caching Latency**:
   - Measure latency for first part request (cache miss)
   - Should be < 50ms overhead
   - Measure latency for subsequent part request (cache hit)
   - Should be < 10ms for parts under 10MB

2. **Metadata Update Performance**:
   - Measure time to update ObjectMetadata with multipart info
   - Should complete asynchronously without blocking response

3. **Part Boundary Calculation Performance**:
   - Measure time to calculate boundaries for various part numbers
   - Should be < 1ms for any part number

## Implementation Notes

### Phase 1: Core Functionality
1. Extend ObjectMetadata with multipart fields
2. Implement Content-Range parsing
3. Implement part boundary calculation
4. Update cache lookup to check for parts
5. Update cache storage to handle parts as ranges

### Phase 2: Metadata Management
1. Implement multipart metadata extraction from headers
2. Implement metadata population on first part request
3. Implement metadata persistence
4. Add backward compatibility handling

### Phase 3: Cache Operations
1. Update cache invalidation to handle parts
2. Implement cache hit/miss for parts
3. Add metrics for part caching
4. Add logging for part operations

### Phase 4: Error Handling
1. Add error handling for parse failures
2. Add error handling for storage failures
3. Add error handling for read failures
4. Add corruption detection and recovery

### Phase 5: Testing
1. Write unit tests for all components
2. Write property-based tests for core properties
3. Write integration tests for end-to-end flows
4. Write performance tests

### Backward Compatibility Strategy

**Existing Cache Entries**:
- Old ObjectMetadata files without multipart fields will deserialize successfully
- Default values (None) will be used for missing fields
- First part request will populate multipart metadata
- Existing ranges remain valid and accessible

**Migration**:
- No migration required
- Metadata is updated lazily on first part request
- Old cache entries continue to work for regular range requests

### Configuration

No new configuration options are required. Part caching will use existing cache configuration:
- `cache_dir`: Location for range files and metadata
- `cache_ttl`: TTL for cached parts (same as ranges)
- `max_cache_size`: Maximum cache size (parts count toward total)
- `compression_enabled`: Whether to compress cached parts

### Monitoring and Observability

**New Metrics**:
- `cache_part_hits`: Counter for part cache hits
- `cache_part_misses`: Counter for part cache misses
- `cache_part_stores`: Counter for parts stored
- `cache_part_evictions`: Counter for parts evicted
- `cache_part_errors`: Counter for part caching errors

**New Log Messages**:
- `INFO`: "Caching part {part_number} for {cache_key} as range {start}-{end}"
- `INFO`: "Serving part {part_number} from cache for {cache_key}"
- `DEBUG`: "Populated multipart metadata: parts_count={}, part_size={}"
- `WARN`: "Failed to parse Content-Range: {header_value}"
- `ERROR`: "Failed to store part {part_number}: {error}"

**Existing Metrics** (reused):
- `cache_size_bytes`: Includes part sizes
- `cache_entries`: Includes objects with parts
- `cache_ranges`: Includes parts stored as ranges
