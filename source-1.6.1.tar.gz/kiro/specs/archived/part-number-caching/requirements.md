# Requirements Document: S3 Part-Number Request Caching

## Introduction

This feature adds support for caching S3 GetObject requests with `partNumber` query parameters. Currently, the proxy bypasses cache for all part-number requests. This enhancement enables the proxy to cache downloaded parts as ranges, leveraging the existing range storage architecture to improve performance for clients that download multipart objects part-by-part.

## Glossary

- **GetObjectPart**: An S3 GetObject request with a `partNumber` query parameter that retrieves a specific part of a multipart-uploaded object
- **PartNumber**: A query parameter (1-indexed) identifying which part of a multipart object to retrieve
- **PartsCount**: The total number of parts in a multipart object, returned in the `x-amz-mp-parts-count` response header
- **PartSize**: The size in bytes of each part (uniform for parts 1 through N-1, with part N potentially smaller)
- **ContentRange**: HTTP response header indicating the byte range of the returned part (e.g., "bytes 0-8388607/5368709120")
- **ObjectMetadata**: Cache metadata structure storing object-level information including ETag, content length, and multipart information
- **RangeSpec**: Cache metadata structure pointing to a binary file containing cached range data
- **Cache Key**: Unique identifier for cached objects, derived from bucket and key (without query parameters)
- **AcceptRanges**: HTTP response header indicating the server supports range requests (always "bytes" for S3)
- **ChecksumCRC32C**: S3 response header containing CRC32C checksum of the object part
- **ChecksumType**: S3 response header indicating the type of checksum (e.g., "COMPOSITE" for multipart objects)
- **VersionId**: S3 response header containing the version identifier for versioned objects
- **ServerSideEncryption**: S3 response header indicating the encryption method used (e.g., "AES256")
- **PartsCount**: Alternative name for the `x-amz-mp-parts-count` header in AWS CLI output

## Requirements

### Requirement 1: Parse Part-Number Requests

**User Story:** As a proxy, I want to detect GetObject requests with partNumber parameters, so that I can handle them appropriately for caching.

#### Acceptance Criteria

1. WHEN a GET request contains a `partNumber` query parameter THEN the system SHALL extract the part number as an integer
2. WHEN a GET request contains a `partNumber` query parameter THEN the system SHALL identify the operation as GetObjectPart
3. WHEN the part number is invalid or non-numeric THEN the system SHALL pass the request through to S3 without caching
4. WHEN a GET request has both `partNumber` and `uploadId` parameters THEN the system SHALL bypass caching (this is an upload verification, not a download)

### Requirement 2: Extract Multipart Metadata from Response

**User Story:** As a proxy, I want to extract multipart metadata from S3 responses, so that I can store part information for future cache lookups.

#### Acceptance Criteria

1. WHEN the S3 response contains an `x-amz-mp-parts-count` header THEN the system SHALL extract and store the parts count
2. WHEN the S3 response contains a `Content-Range` header THEN the system SHALL parse the start byte, end byte, and total size
3. WHEN the S3 response contains a `Content-Length` header THEN the system SHALL calculate the part size from the content length
4. WHEN parts count is present THEN the system SHALL store it in the ObjectMetadata structure
5. WHEN part size can be calculated THEN the system SHALL store it in the ObjectMetadata structure

### Requirement 3: Store Parts as Ranges

**User Story:** As a proxy, I want to store downloaded parts as cached ranges, so that subsequent requests for the same part can be served from cache.

#### Acceptance Criteria

1. WHEN a GetObjectPart response is received THEN the system SHALL store the part data as a range using the ContentRange byte offsets
2. WHEN storing a part as a range THEN the system SHALL use the same storage mechanism as regular range requests
3. WHEN storing a part THEN the system SHALL create a RangeSpec with start and end bytes from ContentRange
4. WHEN storing a part THEN the system SHALL apply compression based on content-aware detection
5. WHEN storing a part THEN the system SHALL update the ObjectMetadata with multipart information (parts count, part size)

### Requirement 4: Serve Cached Parts

**User Story:** As a proxy, I want to serve GetObjectPart requests from cache when available, so that clients experience faster downloads.

#### Acceptance Criteria

1. WHEN a GetObjectPart request is received AND the corresponding range is cached THEN the system SHALL serve the response from cache
2. WHEN serving a cached part THEN the system SHALL include the original `Content-Range` header
3. WHEN serving a cached part THEN the system SHALL include the original `x-amz-mp-parts-count` header if available
4. WHEN serving a cached part THEN the system SHALL include the original `ETag` header
5. WHEN serving a cached part THEN the system SHALL decompress the data if it was compressed during storage
6. WHEN serving a cached part THEN the system SHALL ensure response consistency as defined in Requirement 10

### Requirement 5: Calculate Part Boundaries

**User Story:** As a proxy, I want to calculate expected part boundaries from stored metadata, so that I can validate cache hits for part requests.

#### Acceptance Criteria

1. WHEN ObjectMetadata contains parts count and part size THEN the system SHALL calculate the byte range for any requested part number
2. WHEN calculating part boundaries for parts 1 through N-1 THEN the system SHALL use the uniform part size
3. WHEN calculating part boundaries for part N THEN the system SHALL calculate the remaining bytes (total size - (N-1) * part size)
4. WHEN the requested part number exceeds parts count THEN the system SHALL pass through to S3 without cache lookup
5. WHEN part size or parts count is missing THEN the system SHALL pass through to S3 and attempt to populate metadata

### Requirement 6: Update Metadata on First Part Request

**User Story:** As a proxy, I want to populate multipart metadata when the first part is requested, so that subsequent part requests can benefit from calculated boundaries.

#### Acceptance Criteria

1. WHEN a GetObjectPart response is received AND ObjectMetadata does not contain parts count THEN the system SHALL update the metadata with parts count from the response header
2. WHEN a GetObjectPart response is received AND ObjectMetadata does not contain part size THEN the system SHALL calculate and store the part size
3. WHEN updating ObjectMetadata THEN the system SHALL persist the changes to the metadata file
4. WHEN ObjectMetadata is updated THEN the system SHALL maintain existing cached ranges
5. WHEN ObjectMetadata is updated THEN the system SHALL preserve the object ETag and last modified timestamp

### Requirement 7: Handle Cache Invalidation

**User Story:** As a proxy, I want to invalidate cached parts when the object changes, so that clients always receive current data.

#### Acceptance Criteria

1. WHEN a PUT request is received for an object with cached parts THEN the system SHALL invalidate all cached ranges for that object
2. WHEN a DELETE request is received for an object with cached parts THEN the system SHALL remove all cached ranges and metadata
3. WHEN a HEAD request reveals a different ETag THEN the system SHALL invalidate all cached ranges for that object
4. WHEN cached parts are invalidated THEN the system SHALL remove the corresponding range files from disk
5. WHEN cached parts are invalidated THEN the system SHALL clear multipart metadata from ObjectMetadata

### Requirement 8: Maintain Cache Statistics

**User Story:** As a system operator, I want to track cache performance for part requests, so that I can monitor the effectiveness of part caching.

#### Acceptance Criteria

1. WHEN a GetObjectPart request is served from cache THEN the system SHALL increment the cache hit counter
2. WHEN a GetObjectPart request is served from S3 THEN the system SHALL increment the cache miss counter
3. WHEN a part is stored in cache THEN the system SHALL update the total cached size metric
4. WHEN a cached part is evicted THEN the system SHALL decrement the total cached size metric
5. WHEN cache statistics are reported THEN the system SHALL distinguish between regular range requests and part requests

### Requirement 9: Write Cache Support (Future)

**User Story:** As a proxy, I want to prepare for write-caching of multipart uploads, so that the architecture supports future upload caching.

#### Acceptance Criteria

1. WHEN storing ObjectMetadata THEN the system SHALL include fields for tracking multipart upload state (marked as TODO for write caching)
2. WHEN storing ObjectMetadata THEN the system SHALL include fields for upload ID (marked as TODO for write caching)
3. WHEN the ObjectMetadata structure is extended THEN the system SHALL maintain backward compatibility with existing cached objects
4. WHEN reading ObjectMetadata without multipart fields THEN the system SHALL use default values
5. WHEN write caching is implemented in the future THEN the system SHALL reuse the same multipart metadata fields

### Requirement 10: Response Consistency

**User Story:** As a client, I want GetObjectPart responses to be identical whether served from cache or S3, so that my application behavior is consistent.

#### Acceptance Criteria

1. WHEN serving a cached part THEN the system SHALL include all headers that were present in the original S3 response
2. WHEN serving a cached part THEN the system SHALL include AcceptRanges header with value "bytes"
3. WHEN serving a cached part THEN the system SHALL include LastModified header with the original timestamp
4. WHEN serving a cached part THEN the system SHALL include ContentLength header matching the part size
5. WHEN serving a cached part THEN the system SHALL include ETag header from the original response
6. WHEN serving a cached part THEN the system SHALL include ContentRange header with correct byte range
7. WHEN serving a cached part THEN the system SHALL include ContentType header from the original response
8. WHEN serving a cached part THEN the system SHALL include PartsCount header (x-amz-mp-parts-count) if it was present in the original response
9. WHEN the original S3 response contained ChecksumCRC32C header THEN the cached response SHALL include the same ChecksumCRC32C header
10. WHEN the original S3 response contained ChecksumType header THEN the cached response SHALL include the same ChecksumType header
11. WHEN the original S3 response contained VersionId header THEN the cached response SHALL include the same VersionId header
12. WHEN the original S3 response contained ServerSideEncryption header THEN the cached response SHALL include the same ServerSideEncryption header
13. WHEN the original S3 response contained custom Metadata headers THEN the cached response SHALL include the same custom Metadata headers

### Requirement 11: Error Handling

**User Story:** As a proxy, I want to handle errors gracefully during part caching, so that failures don't disrupt client requests.

#### Acceptance Criteria

1. WHEN parsing ContentRange fails THEN the system SHALL log the error and pass through to S3 without caching
2. WHEN storing a part to disk fails THEN the system SHALL log the error and serve the response to the client
3. WHEN reading a cached part fails THEN the system SHALL fall back to fetching from S3
4. WHEN metadata update fails THEN the system SHALL log the error but continue serving the response
5. WHEN cache corruption is detected THEN the system SHALL invalidate the affected cache entry and fetch from S3

## Non-Functional Requirements

### Performance

- Part caching SHALL NOT add more than 50ms latency to the first request for a part
- Cached part responses SHALL be served within 10ms for parts under 10MB
- Metadata updates SHALL complete asynchronously without blocking response streaming

### Compatibility

- Part caching SHALL be compatible with existing range caching mechanisms
- Part caching SHALL work with both compressed and uncompressed storage
- Part caching SHALL support all S3-compatible storage backends

### Observability

- All part cache operations SHALL be logged with appropriate log levels
- Cache hit/miss ratios for parts SHALL be exposed via metrics endpoints
- Part caching errors SHALL be logged with sufficient context for debugging
