# Implementation Plan: S3 Part-Number Request Caching

- [x] 1. Extend ObjectMetadata with multipart fields
  - Add `parts_count: Option<u32>` field to ObjectMetadata
  - Add `part_size: Option<u64>` field to ObjectMetadata
  - Add `upload_id: Option<String>` field to ObjectMetadata (TODO for write caching)
  - Ensure fields use `#[serde(default)]` for backward compatibility
  - Update ObjectMetadata::new() and ObjectMetadata::default() methods
  - _Requirements: 2.4, 2.5, 9.1, 9.2, 9.3, 9.4_

- [x] 1.1 Write property test for ObjectMetadata backward compatibility
  - **Property 17: Backward compatibility with old metadata**
  - **Validates: Requirements 9.3, 9.4**

- [x] 1.2 Write property test for metadata persistence round-trip
  - **Property 13: Metadata persistence round-trip**
  - **Validates: Requirements 6.3, 6.5**

- [x] 2. Implement Content-Range parsing
  - Create `parse_content_range()` function in cache.rs
  - Parse format: "bytes START-END/TOTAL"
  - Return Result<(u64, u64, u64)> for (start, end, total)
  - Handle invalid formats with descriptive errors
  - Add unit tests for valid and invalid formats
  - _Requirements: 2.2, 11.1_

- [x] 2.1 Write property test for Content-Range round-trip
  - **Property 4: Content-Range parsing round-trip**
  - **Validates: Requirements 2.2**

- [x] 3. Implement part boundary calculation
  - Create `calculate_part_range()` function in cache.rs
  - Input: part_number, part_size, parts_count, total_size
  - Output: (start, end) byte offsets
  - Handle parts 1 to N-1 with uniform part_size
  - Handle part N with remaining bytes
  - Add unit tests for first, middle, last, and single-part cases
  - _Requirements: 5.1, 5.2, 5.3_

- [x] 3.1 Write property test for part boundary calculation
  - **Property 10: Part boundary calculation correctness**
  - **Validates: Requirements 5.1, 5.2, 5.3**

- [x] 4. Implement part number detection and extraction
  - Update `should_bypass_cache()` in http_proxy.rs to NOT bypass GET requests with partNumber
  - Create `is_get_object_part()` function to detect GetObjectPart requests
  - Check for GET method + partNumber parameter + NO uploadId parameter
  - Extract and validate part number as u32
  - Return None for invalid part numbers (non-numeric, negative, zero)
  - _Requirements: 1.1, 1.2, 1.3, 1.4_

- [x] 4.1 Write property test for part number extraction
  - **Property 1: Part number extraction correctness**
  - **Validates: Requirements 1.1, 1.2**

- [x] 4.2 Write property test for invalid part number handling
  - **Property 2: Invalid part number passthrough**
  - **Validates: Requirements 1.3**

- [x] 4.3 Write property test for upload verification bypass
  - **Property 3: Upload verification bypass**
  - **Validates: Requirements 1.4**

- [x] 5. Implement multipart metadata extraction
  - Create `extract_multipart_info()` function in cache.rs
  - Extract `x-amz-mp-parts-count` header from S3 response
  - Calculate part_size from Content-Length (for first part)
  - Store part_number from request context
  - Return MultipartInfo struct
  - _Requirements: 2.1, 2.3_

- [x] 5.1 Write property test for multipart metadata persistence
  - **Property 5: Multipart metadata persistence**
  - **Validates: Requirements 2.1, 2.4, 2.5**

- [x] 6. Implement part storage as range
  - Update cache storage logic to handle GetObjectPart responses
  - Parse Content-Range header to get byte offsets
  - Store part data as range file using existing range storage mechanism
  - Create RangeSpec with start/end from Content-Range
  - Apply compression based on content-aware detection
  - Update ObjectMetadata with multipart info if not present
  - Store all response headers for later retrieval (for response consistency)
  - _Requirements: 3.1, 3.3, 3.4, 3.5, 10.1_

- [x] 6.1 Write property test for part storage as range
  - **Property 6: Part storage as range**
  - **Validates: Requirements 3.1, 3.3**

- [x] 6.2 Write property test for compression round-trip
  - **Property 7: Compression round-trip for parts**
  - **Validates: Requirements 3.4, 4.5**

- [x] 6.3 Write property test for metadata update preserves ranges
  - **Property 8: Metadata update preserves ranges**
  - **Validates: Requirements 3.5, 6.4**

- [x] 7. Implement cache lookup for parts
  - Create `lookup_part()` function in cache.rs
  - Load ObjectMetadata for cache key
  - If parts_count and part_size exist, calculate expected range for part_number
  - Check if calculated range is cached
  - If cached, return range data with appropriate headers
  - If not cached or no metadata, return None (cache miss)
  - _Requirements: 4.1, 5.1, 5.4, 5.5_

- [ ]* 7.1 Write property test for out-of-bounds part number handling
  - **Property 11: Out-of-bounds part number handling**
  - **Validates: Requirements 5.4**

- [x] 8. Implement cached part response construction
  - Construct HTTP response with status 206 Partial Content
  - Include all headers that were present in the original S3 response
  - Include required headers: AcceptRanges, LastModified, ContentLength, ETag, ContentRange, ContentType
  - Include conditional headers if they were in original: ChecksumCRC32C, ChecksumType, VersionId, ServerSideEncryption
  - Include x-amz-mp-parts-count header if available in metadata
  - Include any custom Metadata headers from original response
  - Decompress range data if it was compressed
  - Stream response body to client
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 10.1-10.13_

- [x] 8.1 Write property test for cached part response completeness
  - **Property 9: Cached part response completeness**
  - **Validates: Requirements 4.1, 4.2, 4.3, 4.4, 10.1-10.13**

- [x] 8.2 Implement response header storage and retrieval
  - Extend ObjectMetadata or create separate structure to store original response headers
  - Store all headers from original S3 response during part caching
  - Implement header retrieval during cache hit to ensure response consistency
  - Handle optional headers (ChecksumCRC32C, VersionId, etc.) correctly
  - Ensure backward compatibility with existing cache entries
  - _Requirements: 10.1-10.13_

- [x] 8.3 Write property test for response header consistency
  - **Property 19: Response header consistency**
  - **Validates: Requirements 10.1-10.13**

- [x] 9. Implement metadata population on first part request
  - When GetObjectPart response is received and ObjectMetadata lacks multipart info
  - Extract parts_count from x-amz-mp-parts-count header
  - Calculate part_size from Content-Length
  - Update ObjectMetadata with multipart fields
  - Persist updated metadata to disk
  - Preserve existing ETag, last_modified, and cached ranges
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5_

- [x] 9.1 Write property test for first part populates metadata
  - **Property 12: First part populates metadata**
  - **Validates: Requirements 6.1, 6.2**

- [x] 10. Update cache invalidation for parts
  - Update invalidation logic for PUT requests to clear multipart metadata
  - Update invalidation logic for DELETE requests to remove all parts
  - Update invalidation logic for ETag mismatches to clear parts
  - Ensure all range files are deleted from disk
  - Ensure multipart fields are cleared from ObjectMetadata
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 10.1 Write property test for cache invalidation completeness
  - **Property 14: Cache invalidation completeness**
  - **Validates: Requirements 7.1, 7.2, 7.3, 7.4, 7.5**

- [x] 11. Add metrics for part caching
  - Add cache_part_hits counter
  - Add cache_part_misses counter
  - Add cache_part_stores counter
  - Add cache_part_evictions counter
  - Add cache_part_errors counter
  - Update existing cache_size_bytes metric to include parts
  - Distinguish part requests from regular range requests in metrics
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 11.1 Write property test for cache metrics accuracy
  - **Property 15: Cache metrics accuracy**
  - **Validates: Requirements 8.1, 8.2**

- [x] 11.2 Write property test for cache size tracking accuracy
  - **Property 16: Cache size tracking accuracy**
  - **Validates: Requirements 8.3, 8.4**

- [x] 12. Add error handling for part caching
  - Handle Content-Range parsing failures (log and pass through)
  - Handle part storage failures (log and continue serving response)
  - Handle cached part read failures (log and fall back to S3)
  - Handle metadata update failures (log and continue)
  - Handle cache corruption (invalidate and fall back to S3)
  - Add appropriate error counters to metrics
  - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5_

- [ ]* 12.1 Write property test for Content-Range parsing error handling
  - **Property 18: Content-Range parsing error handling**
  - **Validates: Requirements 11.1**

- [ ]* 12.2 Write unit tests for storage error handling
  - Test disk write failures
  - Test metadata update failures
  - Verify response continues to client
  - _Requirements: 11.2, 11.4_

- [ ]* 12.3 Write unit tests for read error handling
  - Test cached part read failures
  - Test metadata read failures
  - Verify fallback to S3
  - _Requirements: 11.3_

- [ ]* 12.4 Write unit tests for corruption detection
  - Test range file corruption
  - Test metadata corruption
  - Verify invalidation and fallback
  - _Requirements: 11.5_

- [x] 13. Add logging for part operations
  - Log part caching: "Caching part {part_number} for {cache_key} as range {start}-{end}"
  - Log cache hits: "Serving part {part_number} from cache for {cache_key}"
  - Log metadata population: "Populated multipart metadata: parts_count={}, part_size={}"
  - Log parse errors: "Failed to parse Content-Range: {header_value}"
  - Log storage errors: "Failed to store part {part_number}: {error}"
  - Use appropriate log levels (INFO, DEBUG, WARN, ERROR)
  - _Requirements: All (observability)_

- [-] 14. Write integration tests
  - Test end-to-end part caching (cache miss then cache hit)
  - Test multiple parts caching (parts 1, 2, 3)
  - Test last part handling (part N with potentially different size)
  - Test cache invalidation (PUT invalidates all parts)
  - Test backward compatibility (old metadata without multipart fields)
  - _Requirements: All_

- [x] 14.1 Write integration test for end-to-end part caching
  - Request part 1 (cache miss)
  - Verify part stored and metadata populated
  - Request part 1 again (cache hit)
  - Verify response headers match

- [ ]* 14.2 Write integration test for multiple parts
  - Request parts 1, 2, 3 sequentially
  - Verify all stored as separate ranges
  - Request in different order
  - Verify all served from cache

- [ ]* 14.3 Write integration test for last part
  - Request last part (part N)
  - Verify boundary calculation
  - Verify correct Content-Range header

- [ ]* 14.4 Write integration test for cache invalidation
  - Cache multiple parts
  - Issue PUT request
  - Verify all parts invalidated
  - Request part again (cache miss)

- [ ]* 14.5 Write integration test for backward compatibility
  - Create cache entry without multipart fields
  - Request part
  - Verify metadata populated
  - Verify existing ranges preserved

- [ ]* 14.6 Write integration test for response consistency
  - Request part 1 (cache miss) and capture all response headers
  - Request part 1 again (cache hit) and capture all response headers
  - Verify cached response headers exactly match original S3 response headers
  - Test with objects that have optional headers (checksums, versioning, encryption)
  - Test with objects that lack optional headers
  - _Requirements: 10.1-10.13_

- [x] 15. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ]* 16. Write performance tests
  - Test part caching latency (should be < 50ms overhead)
  - Test cached part response latency (should be < 10ms for parts under 10MB)
  - Test metadata update performance (should be async)
  - Test part boundary calculation performance (should be < 1ms)
  - _Requirements: Non-functional performance requirements_

- [x] 17. Update documentation
  - Update CACHING.md with part caching information
  - Document new ObjectMetadata fields
  - Document Content-Range parsing
  - Document part boundary calculation
  - Add examples of part caching usage
  - Document new metric
  - Update developer.md
  - ensure all documentation is concise, clear, and complete, without embellishment


- [x] 18. Tidy repository
  - Archive spec docs and any summary
  - Remove unused files

