# Design Document: Web Dashboard

## Overview

The web dashboard provides a lightweight, browser-based interface for monitoring S3 proxy cache performance and viewing application logs. The dashboard integrates with the existing proxy architecture by adding a new HTTP server component that serves static HTML/CSS/JavaScript and provides JSON APIs for real-time data.

The dashboard follows the existing proxy patterns: it uses the same configuration system, logging framework, and component architecture. It leverages existing metrics collection from MetricsManager and log access from the logging system.

## Architecture

### Component Integration

The dashboard integrates into the existing proxy architecture as follows:

```mermaid
graph TB
    subgraph "Main Process"
        Main[main.rs]
        Config[Config System]
        
        subgraph "Existing Components"
            HTTP[HTTP Proxy]
            HTTPS[HTTPS Proxy]
            Health[Health Server]
            Metrics[Metrics Server]
            Cache[Cache Manager]
            Logs[Logger Manager]
        end
        
        subgraph "New Dashboard Component"
            Dashboard[Dashboard Server]
            Static[Static File Handler]
            API[JSON API Handler]
            LogReader[Log Reader]
        end
    end
    
    Main --> Dashboard
    Config --> Dashboard
    Dashboard --> Cache
    Dashboard --> Logs
    Dashboard --> Metrics
    
    subgraph "Browser"
        UI[Dashboard UI]
        JS[JavaScript Client]
    end
    
    UI --> Dashboard
    JS --> API
```

### Server Architecture

The dashboard server follows the same pattern as the existing health and metrics servers:

- **Dedicated HTTP Server**: Runs on a separate port (default 8080, configurable)
- **Async Request Handling**: Uses Hyper with Tokio for non-blocking operations
- **Component References**: Holds Arc references to existing managers for data access
- **Graceful Shutdown**: Integrates with the existing shutdown coordinator

## Components and Interfaces

### 1. Dashboard Configuration

Add dashboard configuration to the existing config system:

```rust
/// Dashboard configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DashboardConfig {
    pub enabled: bool,
    pub port: u16,
    pub bind_address: String,
    #[serde(deserialize_with = "duration_serde::deserialize")]
    pub cache_stats_refresh_interval: Duration,
    #[serde(deserialize_with = "duration_serde::deserialize")]
    pub logs_refresh_interval: Duration,
    pub max_log_entries: usize,
}

impl Default for DashboardConfig {
    fn default() -> Self {
        Self {
            enabled: true,  // Enabled by default per requirements
            port: 8080,
            bind_address: "0.0.0.0".to_string(),
            cache_stats_refresh_interval: Duration::from_secs(5),
            logs_refresh_interval: Duration::from_secs(10),
            max_log_entries: 100,
        }
    }
}
```

### 2. Dashboard Server

```rust
pub struct DashboardServer {
    config: Arc<DashboardConfig>,
    cache_manager: Option<Arc<CacheManager>>,
    metrics_manager: Option<Arc<RwLock<MetricsManager>>>,
    logger_manager: Option<Arc<tokio::sync::Mutex<LoggerManager>>>,
    log_reader: Arc<LogReader>,
}

impl DashboardServer {
    pub fn new(config: Arc<DashboardConfig>) -> Self;
    pub fn set_cache_manager(&mut self, cache_manager: Arc<CacheManager>);
    pub fn set_metrics_manager(&mut self, metrics_manager: Arc<RwLock<MetricsManager>>);
    pub fn set_logger_manager(&mut self, logger_manager: Arc<tokio::sync::Mutex<LoggerManager>>);
    pub async fn start(&self) -> Result<()>;
    async fn handle_request(&self, req: Request<hyper::body::Incoming>) -> Result<Response<String>>;
}
```

### 3. Static File Handler

```rust
pub struct StaticFileHandler {
    // Embedded static files using include_str! for simplicity
}

impl StaticFileHandler {
    pub fn new() -> Self;
    pub async fn handle_static_request(&self, path: &str) -> Result<Response<String>>;
    fn get_content_type(path: &str) -> &'static str;
}
```

### 4. API Handler

```rust
pub struct ApiHandler {
    cache_manager: Option<Arc<CacheManager>>,
    metrics_manager: Option<Arc<RwLock<MetricsManager>>>,
    log_reader: Arc<LogReader>,
}

impl ApiHandler {
    pub fn new(log_reader: Arc<LogReader>) -> Self;
    pub async fn handle_api_request(&self, path: &str) -> Result<Response<String>>;
    async fn get_cache_stats(&self) -> Result<CacheStatsResponse>;
    async fn get_logs(&self, params: LogQueryParams) -> Result<LogsResponse>;
}
```

### 5. Log Reader

```rust
pub struct LogReader {
    app_log_dir: PathBuf,
    hostname: String,
}

#[derive(Debug, Serialize)]
pub struct LogEntry {
    pub timestamp: DateTime<Utc>,
    pub level: String,
    pub target: String,
    pub message: String,
    pub fields: HashMap<String, String>,
}

#[derive(Debug, Deserialize)]
pub struct LogQueryParams {
    pub limit: Option<usize>,
    pub level_filter: Option<String>,
    pub since: Option<DateTime<Utc>>,
}

impl LogReader {
    pub fn new(app_log_dir: PathBuf, hostname: String) -> Self;
    pub async fn read_recent_logs(&self, params: LogQueryParams) -> Result<Vec<LogEntry>>;
    fn parse_log_line(&self, line: &str) -> Option<LogEntry>;
}
```

## Data Models

### Cache Statistics Response

```rust
#[derive(Debug, Serialize)]
pub struct CacheStatsResponse {
    pub timestamp: DateTime<Utc>,
    pub ram_cache: CacheStats,
    pub disk_cache: CacheStats,
    pub overall: OverallStats,
}

#[derive(Debug, Serialize)]
pub struct CacheStats {
    pub hit_rate: f32,
    pub hits: u64,
    pub misses: u64,
    pub size_bytes: u64,
    pub size_human: String,
    pub evictions: u64,
}

#[derive(Debug, Serialize)]
pub struct OverallStats {
    pub total_requests: u64,
    pub cache_effectiveness: f32,
    pub uptime_seconds: u64,
}
```

### Logs Response

```rust
#[derive(Debug, Serialize)]
pub struct LogsResponse {
    pub entries: Vec<LogEntry>,
    pub total_count: usize,
    pub has_more: bool,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

<function_calls>
<invoke name="prework">
<parameter name="featureName">web-dashboard

Based on the prework analysis, I'll now convert the testable acceptance criteria into correctness properties:

### Property Reflection

After reviewing all properties identified in the prework, I can consolidate some related properties:
- Properties 2.1 and 2.2 (RAM and disk cache stats) can be combined into a single comprehensive cache stats property
- Properties 2.5 and 2.6 (eviction counts and overall stats) are part of the same cache stats response
- Properties 3.5 and 3.6 (log filtering and limits) can be combined into a comprehensive log API property
- Properties 5.2 and 5.6 both test configuration validation and can be combined

### Property 1: Dashboard accessibility without authentication
*For any* HTTP request to the dashboard URL, the server should return a successful response (200 OK) without requiring authentication headers
**Validates: Requirements 1.1**

### Property 2: Dashboard response performance
*For any* request to the dashboard, the server should respond within 500ms for initial page load
**Validates: Requirements 1.3**

### Property 3: Dashboard port separation
*For any* dashboard configuration, the dashboard port should be different from the proxy HTTP port (80) and HTTPS port (443)
**Validates: Requirements 1.4**

### Property 4: Comprehensive cache statistics
*For any* cache stats API request, the response should include RAM cache stats (hit rate, hits, misses, size), disk cache stats (hit rate, hits, misses, size), eviction counts, and overall effectiveness metrics
**Validates: Requirements 2.1, 2.2, 2.5, 2.6**

### Property 5: Human-readable size formatting
*For any* byte value in cache statistics, sizes should be formatted with appropriate units (B, KB, MB, GB) and reasonable precision
**Validates: Requirements 2.4**

### Property 6: Default log entry limit
*For any* logs API request without a limit parameter, the response should return at most 100 log entries
**Validates: Requirements 3.1**

### Property 7: Log entry structure
*For any* log entry in the API response, it should contain timestamp, log level, and message content fields
**Validates: Requirements 3.3**

### Property 8: Structured log data formatting
*For any* log entry containing structured data (key-value pairs), the formatted message should include all key-value pairs in a readable format
**Validates: Requirements 3.4**

### Property 9: Comprehensive log API functionality
*For any* logs API request with level filter or limit parameters, the response should respect the filters and return the correct number of entries matching the criteria
**Validates: Requirements 3.5, 3.6**

### Property 10: Concurrent connection handling
*For any* set of up to 10 concurrent dashboard requests, all requests should complete successfully within reasonable time bounds
**Validates: Requirements 4.2**

### Property 11: Static asset size limits
*For any* static asset (CSS, JavaScript), the total combined size should be less than 100KB to ensure fast loading
**Validates: Requirements 4.4**

### Property 12: Configuration validation and defaults
*For any* dashboard configuration, invalid port numbers or bind addresses should be rejected, and missing configuration should use default values (port 8080, bind to all interfaces)
**Validates: Requirements 5.2, 5.4**

### Property 13: Consistent logging integration
*For any* dashboard operation that generates logs, the logs should appear in the same location and format as main proxy logs
**Validates: Requirements 5.5**

### Property 14: Graceful shutdown behavior
*For any* active dashboard connection during proxy shutdown, the connection should be closed gracefully without hanging
**Validates: Requirements 5.6**

### Property 15: Navigation structure
*For any* dashboard HTML response, it should contain navigation elements for "Cache Stats" and "Application Logs" sections
**Validates: Requirements 6.1**

### Property 16: System information display
*For any* dashboard response, it should include the proxy instance hostname and version information
**Validates: Requirements 6.4**

## Error Handling

### Dashboard Server Errors
- **Port Binding Failures**: If the dashboard port is already in use, log error and continue proxy operation without dashboard
- **Component Reference Failures**: If cache manager or metrics manager are unavailable, return appropriate HTTP error codes (503 Service Unavailable)
- **Configuration Errors**: Invalid dashboard configuration should be logged and fall back to defaults where possible

### API Error Responses
- **Cache Stats Unavailable**: Return 503 with error message if cache manager is not available
- **Log Reading Errors**: Return 500 with error message if log files cannot be read
- **Invalid Parameters**: Return 400 with descriptive error message for invalid query parameters

### Static File Handling
- **Missing Files**: Return 404 for non-existent static files
- **Content Type Detection**: Proper MIME type headers for CSS, JavaScript, and HTML files

## Testing Strategy

### Dual Testing Approach
The dashboard will be tested using both unit tests and property-based tests:

**Unit Tests**:
- Static file serving for specific files (HTML, CSS, JS)
- API endpoint responses with known data
- Configuration parsing and validation
- Error handling for specific failure scenarios

**Property-Based Tests**:
- Cache statistics API with randomized cache states (Property 4, 5)
- Log API with various filter combinations (Property 6, 7, 8, 9)
- Concurrent access patterns (Property 10)
- Configuration validation with random invalid inputs (Property 12)
- Performance characteristics across different request patterns (Property 2)

### Property-Based Testing Configuration
- **Testing Library**: Use `quickcheck` for Rust property-based testing
- **Test Iterations**: Minimum 100 iterations per property test
- **Test Tags**: Each property test tagged with format: **Feature: web-dashboard, Property {number}: {property_text}**

### Integration Testing
- Dashboard server startup and shutdown integration with main proxy
- Component reference sharing between dashboard and existing managers
- End-to-end testing of dashboard functionality with running proxy instance

## Implementation Notes

### Static File Embedding
Static files (HTML, CSS, JavaScript) will be embedded in the binary using `include_str!` macros to avoid external file dependencies and simplify deployment.

### Async Architecture
The dashboard server follows the same async patterns as existing components:
- Uses `tokio::spawn` for the main server task
- Non-blocking request handling with async/await
- Shared state access through Arc<RwLock<T>> patterns

### Memory Efficiency
- Static files served directly from embedded strings
- JSON responses generated on-demand without caching
- Log reading uses streaming to avoid loading entire log files into memory

### Security Considerations
- No authentication required (per requirements)
- Dashboard should only be accessible on configured network interfaces
- Input validation for all API parameters to prevent injection attacks
- Rate limiting considerations for production deployments (future enhancement)