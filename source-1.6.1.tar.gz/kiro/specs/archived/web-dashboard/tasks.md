# Implementation Plan: Web Dashboard

## Overview

This implementation plan creates a web-based dashboard for the S3 proxy that displays cache statistics and application logs. The dashboard integrates with existing proxy components and follows established patterns for configuration, logging, and server architecture.

## Tasks

- [x] 1. Add dashboard configuration to config system
  - Add `DashboardConfig` struct to `src/config.rs`
  - Add dashboard field to main `Config` struct with default enabled
  - Add CLI arguments and environment variable support for dashboard config
  - Add configuration validation for port and bind address
  - _Requirements: 5.1, 5.2, 5.4_

- [x] 1.1 Write property test for dashboard configuration
  - **Property 12: Configuration validation and defaults**
  - **Validates: Requirements 5.2, 5.4**

- [x] 2. Create dashboard server module
  - [x] 2.1 Create `src/dashboard.rs` with `DashboardServer` struct
    - Implement server initialization and component references
    - Add methods to set cache manager, metrics manager, and logger manager references
    - _Requirements: 1.4, 5.5_

  - [x] 2.2 Implement HTTP request routing
    - Handle static file requests (/, /index.html, /style.css, /script.js)
    - Handle API requests (/api/cache-stats, /api/logs)
    - Return appropriate HTTP status codes and content types
    - _Requirements: 1.1, 1.2_

  - [x] 2.3 Write property test for dashboard accessibility
    - **Property 1: Dashboard accessibility without authentication**
    - **Validates: Requirements 1.1**

  - [x] 2.4 Write property test for port separation
    - **Property 3: Dashboard port separation**
    - **Validates: Requirements 1.4**

- [x] 3. Implement static file handler
  - [x] 3.1 Create embedded HTML dashboard interface
    - Create minimal HTML with navigation for Cache Stats and Application Logs
    - Include hostname and version information in header
    - Add auto-refresh functionality with configurable intervals
    - _Requirements: 6.1, 6.4_

  - [x] 3.2 Create embedded CSS for styling
    - Minimal, responsive CSS for dashboard layout
    - Ensure total CSS size is under size limits for fast loading
    - _Requirements: 4.4_

  - [x] 3.3 Create embedded JavaScript for functionality
    - API calls to fetch cache stats and logs
    - Auto-refresh timers (5s for cache stats, 10s for logs)
    - Basic table sorting and filtering functionality
    - Ensure total JavaScript size is under size limits
    - _Requirements: 2.3, 3.2, 4.4_

  - [x] 3.4 Write property test for static asset size limits
    - **Property 11: Static asset size limits**
    - **Validates: Requirements 4.4**

  - [x] 3.5 Write property test for navigation structure
    - **Property 15: Navigation structure**
    - **Validates: Requirements 6.1**

- [x] 4. Implement cache statistics API
  - [x] 4.1 Create cache stats response structures
    - Define `CacheStatsResponse`, `CacheStats`, and `OverallStats` structs
    - Implement JSON serialization for all response types
    - _Requirements: 2.1, 2.2, 2.5, 2.6_

  - [x] 4.2 Implement cache stats collection
    - Integrate with existing `MetricsManager` to get cache statistics
    - Calculate hit rates, effectiveness percentages, and format sizes
    - Handle cases where cache manager is unavailable
    - _Requirements: 2.1, 2.2, 2.5, 2.6_

  - [x] 4.3 Add human-readable size formatting
    - Implement function to format bytes as KB, MB, GB with appropriate precision
    - Apply formatting to all size fields in cache stats response
    - _Requirements: 2.4_

  - [x] 4.4 Write property test for comprehensive cache statistics
    - **Property 4: Comprehensive cache statistics**
    - **Validates: Requirements 2.1, 2.2, 2.5, 2.6**

  - [x] 4.5 Write property test for human-readable size formatting
    - **Property 5: Human-readable size formatting**
    - **Validates: Requirements 2.4**

- [x] 5. Implement application logs API
  - [x] 5.1 Create log reader module
    - Create `LogReader` struct to read from application log files
    - Implement log line parsing for tracing format
    - Handle structured data extraction from log entries
    - _Requirements: 3.3, 3.4_

  - [x] 5.2 Implement log query functionality
    - Support limit parameter with default of 100 entries
    - Support log level filtering (ERROR, WARN, INFO, DEBUG)
    - Support time-based filtering for recent logs
    - _Requirements: 3.1, 3.5, 3.6_

  - [x] 5.3 Create logs response structures
    - Define `LogEntry` and `LogsResponse` structs
    - Implement JSON serialization with proper timestamp formatting
    - _Requirements: 3.3, 3.4_

  - [x] 5.4 Write property test for default log entry limit
    - **Property 6: Default log entry limit**
    - **Validates: Requirements 3.1**

  - [x] 5.5 Write property test for log entry structure
    - **Property 7: Log entry structure**
    - **Validates: Requirements 3.3**

  - [x] 5.6 Write property test for structured log data formatting
    - **Property 8: Structured log data formatting**
    - **Validates: Requirements 3.4**

  - [x] 5.7 Write property test for comprehensive log API functionality
    - **Property 9: Comprehensive log API functionality**
    - **Validates: Requirements 3.5, 3.6**

- [x] 6. Integrate dashboard server with main application
  - [x] 6.1 Add dashboard server startup to main.rs
    - Create dashboard server instance with configuration
    - Set component references (cache manager, metrics manager, logger manager)
    - Start dashboard server task if enabled in configuration
    - _Requirements: 5.1, 5.3_

  - [x] 6.2 Add dashboard server to shutdown coordination
    - Integrate dashboard server with existing shutdown coordinator
    - Ensure graceful shutdown of dashboard connections
    - _Requirements: 5.6_

  - [x] 6.3 Write property test for graceful shutdown behavior
    - **Property 14: Graceful shutdown behavior**
    - **Validates: Requirements 5.6**

- [x] 7. Add performance and reliability features
  - [x] 7.1 Implement concurrent connection handling
    - Ensure dashboard can handle multiple simultaneous connections
    - Add appropriate error handling for connection failures
    - _Requirements: 4.2_

  - [x] 7.2 Add response time optimization
    - Optimize API response generation for sub-500ms performance
    - Add caching for frequently accessed data where appropriate
    - _Requirements: 1.3, 4.3_

  - [x] 7.3 Write property test for dashboard response performance
    - **Property 2: Dashboard response performance**
    - **Validates: Requirements 1.3**

  - [x] 7.4 Write property test for concurrent connection handling
    - **Property 10: Concurrent connection handling**
    - **Validates: Requirements 4.2**

- [x] 8. Add logging integration and system information
  - [x] 8.1 Implement consistent logging for dashboard operations
    - Use existing tracing framework for dashboard server logs
    - Ensure dashboard logs appear in same location as proxy logs
    - _Requirements: 5.5_

  - [x] 8.2 Add system information API
    - Provide hostname and version information for dashboard header
    - Include uptime and basic system status
    - _Requirements: 6.4_

  - [x] 8.3 Write property test for consistent logging integration
    - **Property 13: Consistent logging integration**
    - **Validates: Requirements 5.5**

  - [x] 8.4 Write property test for system information display
    - **Property 16: System information display**
    - **Validates: Requirements 6.4**

- [x] 9. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Add error handling and edge cases
  - [x] 10.1 Implement comprehensive error handling
    - Handle cache manager unavailable scenarios
    - Handle log file reading errors gracefully
    - Return appropriate HTTP error codes (400, 404, 500, 503)
    - _Requirements: 4.1, 4.5_

  - [x] 10.2 Add input validation for API parameters
    - Validate log query parameters (limit, level, timestamps)
    - Sanitize inputs to prevent injection attacks
    - Return descriptive error messages for invalid inputs
    - _Requirements: 3.5, 3.6_

  - [x] 10.3 Write unit tests for error handling scenarios
    - Test API responses when components are unavailable
    - Test invalid parameter handling
    - Test file system error scenarios

- [x] 11. Final integration and validation
  - [x] 11.1 Update configuration documentation
    - Document dashboard configuration options in example config
    - Add dashboard section to configuration documentation
    - _Requirements: 5.1, 5.2, 5.4_

  - [x] 11.2 Verify integration with existing components
    - Test dashboard with various cache states and log conditions
    - Verify dashboard doesn't impact main proxy performance
    - Test dashboard startup/shutdown with main proxy lifecycle
    - _Requirements: 4.5, 5.1, 5.3, 5.6_

- [x] 12. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
- The dashboard integrates with existing proxy architecture without disrupting core functionality