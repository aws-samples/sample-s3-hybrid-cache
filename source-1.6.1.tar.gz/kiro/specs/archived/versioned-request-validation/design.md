# Design Document

## Overview

This design validates that S3 versioned requests (requests with `versionId` query parameter) work correctly with the new bucket-first hash-based sharded disk caching format. The validation focuses on ensuring that:

1. Versioned cache keys are generated correctly and include version IDs
2. Sharded paths are resolved correctly for versioned objects (hashing object_key only, not bucket or version)
3. Versioned objects are stored and retrieved correctly using the sharded structure
4. Different versions of the same object are isolated and don't interfere with each other
5. Versioned objects support all cache operations: storage, retrieval, range requests, invalidation, and multipart uploads

The new sharding architecture uses a bucket-first approach with BLAKE3 hashing:
- Cache keys: `bucket:object_key` or `bucket:object_key:version:version_id`
- Sharded paths: `{type}/{bucket}/{XX}/{YYY}/{filename}` where XX/YYY are derived from BLAKE3(object_key)
- Metadata files: Lightweight JSON files (<100KB) in `objects/` directory
- Range files: Compressed binary files in `ranges/` directory

## Architecture

### Component Overview

The versioned request validation involves these key components:

1. **Cache Manager** (`src/cache.rs`):
   - Generates versioned cache keys using format `bucket:object_key:version:version_id`
   - Coordinates storage and retrieval of versioned objects
   - Handles version isolation and invalidation

2. **Disk Cache Manager** (`src/disk_cache.rs`):
   - Resolves sharded paths for versioned cache keys
   - Stores metadata and range files in bucket-first sharded structure
   - Handles file locking for concurrent access
   - Implements atomic operations for metadata and range updates

3. **S3 URL Params** (`src/s3_client.rs`):
   - Parses `versionId` query parameter from S3 requests
   - Provides version information to cache operations

### Sharding Architecture for Versioned Objects

**Cache Key Format**:
- Non-versioned: `bucket:object_key`
- Versioned: `bucket:object_key:version:version_id`

**Path Resolution**:
1. Parse cache key to extract bucket, object_key, and version_id
2. Hash object_key (NOT bucket or version_id) using BLAKE3
3. Extract first 2 hex digits for level 1 directory (XX)
4. Extract next 3 hex digits for level 2 directory (YYY)
5. Sanitize full cache key for filename (percent-encode special chars)
6. Construct path: `{type}/{bucket}/{XX}/{YYY}/{sanitized_cache_key}{suffix}`

**Example**:
```
Cache key: my-bucket:photos/vacation.jpg:version:abc123
BLAKE3(photos/vacation.jpg) = a7f3c2...
Level 1: a7
Level 2: f3c
Sanitized: my-bucket%3Aphotos%2Fvacation.jpg%3Aversion%3Aabc123
Metadata: objects/my-bucket/a7/f3c/my-bucket%3Aphotos%2Fvacation.jpg%3Aversion%3Aabc123.meta
Range: ranges/my-bucket/a7/f3c/my-bucket%3Aphotos%2Fvacation.jpg%3Aversion%3Aabc123_0-1048575.bin
```

**Key Properties**:
- Different versions of the same object share the same shard directory (same bucket/XX/YYY)
- Same object key in different buckets have different bucket directories but same hash directories
- Version ID is included in the filename but NOT in the hash computation
- This ensures efficient directory organization while maintaining version isolation

## Components and Interfaces

### Cache Key Generation

**Interface**: `CacheManager::generate_versioned_cache_key(path: &str, version_id: &str) -> String`

**Behavior**:
- Input: S3 path (e.g., `/bucket/object.txt`) and version ID (e.g., `abc123`)
- Output: Cache key in format `bucket:object_key:version:version_id`
- Version ID is included verbatim without modification
- Special characters in version ID are preserved in cache key
- Deterministic: same inputs always produce same output

**Example**:
```rust
let cache_key = CacheManager::generate_versioned_cache_key("/my-bucket/file.txt", "v123");
// Result: "my-bucket:file.txt:version:v123"
```

### Sharded Path Resolution

**Interface**: `get_sharded_path(base_dir: &Path, cache_key: &str, suffix: &str) -> Result<PathBuf>`

**Behavior**:
- Parses cache key to extract bucket and object_key
- Hashes object_key (excluding bucket and version components) using BLAKE3
- Extracts directory levels from hash (XX/YYY)
- Sanitizes full cache key for filename
- Constructs path: `base_dir/bucket/XX/YYY/filename`

**Example**:
```rust
let path = get_sharded_path(
    Path::new("/cache/objects"),
    "my-bucket:file.txt:version:v123",
    ".meta"
)?;
// Result: /cache/objects/my-bucket/a7/f3c/my-bucket%3Afile.txt%3Aversion%3Av123.meta
```

### Versioned Object Storage

**Interface**: `DiskCacheManager::store_range(cache_key: &str, start: u64, end: u64, data: &[u8], metadata: ObjectMetadata) -> Result<()>`

**Behavior**:
- Compresses range data using content-aware compression
- Writes range data to temporary file
- Acquires exclusive lock on metadata file
- Updates metadata with new range spec
- Atomically renames metadata file
- Atomically renames range file (making it visible)
- Releases lock

**Atomic Guarantees**:
- Metadata is updated BEFORE range file becomes visible
- Prevents race condition where range file exists but isn't in metadata
- Uses file locking to prevent concurrent write conflicts

### Versioned Object Retrieval

**Interface**: `DiskCacheManager::get_metadata(cache_key: &str) -> Result<Option<NewCacheMetadata>>`

**Behavior**:
- Reads metadata file from sharded path
- Parses JSON to NewCacheMetadata structure
- Checks expiration (lazy expiration)
- Returns None if metadata doesn't exist or is expired
- Handles corrupted metadata gracefully (logs error, deletes file, returns None)

**Interface**: `DiskCacheManager::find_cached_ranges(cache_key: &str, start: u64, end: u64) -> Result<Vec<RangeSpec>>`

**Behavior**:
- Gets metadata for cache key
- Filters out expired ranges (lazy expiration)
- Finds all ranges that overlap with requested range
- Returns range specs (includes file paths, compression info, sizes)
- Optimizes for exact match and full containment cases

### Version Isolation

**Mechanism**:
- Each version has a unique cache key including version ID
- Metadata and range files are named using the full cache key (including version)
- Different versions have different filenames even in the same shard directory
- Invalidation uses exact cache key matching, so only the specified version is affected

**Example**:
```
Version A: my-bucket:file.txt:version:v1
  Metadata: objects/my-bucket/XX/YYY/my-bucket%3Afile.txt%3Aversion%3Av1.meta
  Range: ranges/my-bucket/XX/YYY/my-bucket%3Afile.txt%3Aversion%3Av1_0-1023.bin

Version B: my-bucket:file.txt:version:v2
  Metadata: objects/my-bucket/XX/YYY/my-bucket%3Afile.txt%3Aversion%3Av2.meta
  Range: ranges/my-bucket/XX/YYY/my-bucket%3Afile.txt%3Aversion%3Av2_0-1023.bin

Non-versioned: my-bucket:file.txt
  Metadata: objects/my-bucket/XX/YYY/my-bucket%3Afile.txt.meta
  Range: ranges/my-bucket/XX/YYY/my-bucket%3Afile.txt_0-1023.bin
```

All three coexist in the same shard directory without conflicts.

### Filename Sanitization

**Interface**: `sanitize_object_key_for_filename(object_key: &str, suffix: &str) -> String`

**Behavior**:
- Percent-encodes filesystem-unsafe characters: space, /, \, :, *, ?, ", <, >, |, %
- Preserves non-ASCII UTF-8 characters (unicode)
- For keys exceeding 200 characters after encoding, uses BLAKE3 hash as filename
- Appends suffix to result

**Examples**:
```
Input: "file.txt", suffix: ".meta"
Output: "file.txt.meta"

Input: "path/to/file.txt", suffix: ".meta"
Output: "path%2Fto%2Ffile.txt.meta"

Input: "file:with:colons", suffix: ".bin"
Output: "file%3Awith%3Acolons.bin"

Input: (250 'a' characters), suffix: ".meta"
Output: "a7f3c2d1e5b8...9f4a.meta" (64 hex chars + suffix)
```

## Data Models

### Cache Key Structure

```
Non-versioned: bucket:object_key
Versioned: bucket:object_key:version:version_id
Range: bucket:object_key:range:start-end
Versioned Range: bucket:object_key:version:version_id:range:start-end
```

### NewCacheMetadata

```rust
pub struct NewCacheMetadata {
    pub cache_key: String,                    // Full cache key including version
    pub object_metadata: ObjectMetadata,      // Includes version_id field
    pub ranges: Vec<RangeSpec>,               // List of cached ranges
    pub created_at: SystemTime,
    pub expires_at: SystemTime,
    pub compression_info: CompressionInfo,
}
```

### ObjectMetadata

```rust
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub content_type: Option<String>,
    pub version_id: Option<String>,           // Version ID from S3
    pub upload_state: UploadState,
    pub cumulative_size: u64,
}
```

### RangeSpec

```rust
pub struct RangeSpec {
    pub start: u64,
    pub end: u64,
    pub file_path: String,                    // Relative path from ranges/ directory
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
    pub expires_at: SystemTime,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Versioned Cache Key Uniqueness

*For any* bucket, object_key, and two different version IDs (v1 and v2), generating cache keys for (bucket, object_key, v1) and (bucket, object_key, v2) should produce different cache keys.

**Validates: Requirements 1.3**

### Property 2: Versioned Cache Key Determinism

*For any* bucket, object_key, and version ID, generating the cache key multiple times with the same inputs should always produce the same cache key.

**Validates: Requirements 1.4**

### Property 3: Version ID Preservation in Cache Key

*For any* version ID (including those with special characters), the version ID should appear unmodified in the generated cache key.

**Validates: Requirements 1.5**

### Property 4: Sharded Path Consistency for Same Object

*For any* bucket and object_key, and two different version IDs, the sharded paths for both versions should have the same bucket/XX/YYY prefix (same shard directory).

**Validates: Requirements 2.3**

### Property 5: Bucket Isolation in Sharded Paths

*For any* object_key and two different buckets, the sharded paths should have different bucket directories but the same XX/YYY hash directories.

**Validates: Requirements 2.4**

### Property 6: Long Filename Handling

*For any* cache key that, when sanitized, exceeds 200 characters, the filename should be a 64-character BLAKE3 hash.

**Validates: Requirements 2.5, 10.2**

### Property 7: Filename Sanitization Correctness

*For any* cache key containing filesystem-unsafe characters (/, \, :, *, ?, ", <, >, |, %), the sanitized filename should have those characters percent-encoded.

**Validates: Requirements 10.1**

### Property 8: Filename Uniqueness for Different Versions

*For any* bucket, object_key, and two different version IDs, the sanitized filenames should be different.

**Validates: Requirements 10.5**

### Property 9: Version Isolation During Storage

*For any* two versions (A and B) of the same object, storing version A should not modify or delete any files belonging to version B.

**Validates: Requirements 5.1**

### Property 10: Version Isolation During Retrieval

*For any* two versions (A and B) of the same object with different data, retrieving version A should return the data for version A, not version B.

**Validates: Requirements 5.4**

### Property 11: Non-Versioned Cache Key Format

*For any* bucket and object_key, generating a cache key without a version ID should produce a key in the format `bucket:object_key` without any `:version:` component.

**Validates: Requirements 1.2**

### Property 12: Versioned Cache Key Format

*For any* bucket, object_key, and version ID, generating a versioned cache key should produce a key in the format `bucket:object_key:version:version_id`.

**Validates: Requirements 1.1**

### Property 13: Sharded Path Structure

*For any* versioned cache key, the resolved sharded path should match the structure `{type}/{bucket}/{XX}/{YYY}/{sanitized_key}{suffix}` where XX is 2 hex digits and YYY is 3 hex digits.

**Validates: Requirements 2.2**

### Property 14: Object Key Hashing Only

*For any* versioned cache key `bucket:object_key:version:version_id`, the hash directories (XX/YYY) should be computed from BLAKE3(object_key) only, not from the bucket or version_id.

**Validates: Requirements 2.1**

## Error Handling

### Corrupted Metadata Files

**Scenario**: Metadata file exists but contains invalid JSON or corrupted data

**Handling**:
1. Log error with cache key and version ID
2. Record corrupted metadata metric
3. Delete corrupted metadata file
4. Return cache miss (None)
5. Next request will fetch from S3 and recreate cache entry

**Rationale**: Corrupted metadata should not block cache operations. Treating it as a cache miss ensures the system remains functional.

### Missing Range Files

**Scenario**: Metadata indicates a range is cached, but the range file doesn't exist

**Handling**:
1. Log warning with cache key, version ID, and range
2. Treat the range as not cached
3. Fetch missing range from S3
4. Update cache with fetched range

**Rationale**: Missing range files can occur due to manual deletion or disk errors. The system should recover gracefully by fetching from S3.

### Disk Space Exhaustion

**Scenario**: Disk is full when trying to write a range file

**Handling**:
1. Detect "No space left on device" error
2. Log error with cache key, version ID, and attempted size
3. Record disk full event metric
4. Clean up temporary files
5. Return error to caller
6. Request continues to S3 (caching is bypassed)

**Rationale**: Disk space exhaustion should not cause request failures. The proxy should continue serving requests from S3.

### Concurrent Write Conflicts

**Scenario**: Two clients try to write the same versioned object simultaneously

**Handling**:
1. Use file locking on metadata file
2. First writer acquires lock, second writer waits
3. Second writer reads updated metadata after acquiring lock
4. Both writes succeed without conflicts

**Rationale**: File locking ensures atomic metadata updates and prevents lost updates.

### Invalid Cache Key Format

**Scenario**: Cache key doesn't contain a slash (missing bucket or object_key)

**Handling**:
1. Return error from `parse_cache_key` function
2. Log error with invalid cache key
3. Fall back to old flat structure (for backward compatibility)

**Rationale**: Invalid cache keys should be handled gracefully without crashing the system.

## Testing Strategy

### Unit Testing

Unit tests will verify specific examples and edge cases:

1. **Cache Key Generation**:
   - Test versioned cache key format
   - Test non-versioned cache key format
   - Test version IDs with special characters
   - Test empty version IDs

2. **Sharded Path Resolution**:
   - Test path structure for versioned keys
   - Test bucket isolation
   - Test hash directory consistency
   - Test long filename handling

3. **Filename Sanitization**:
   - Test percent-encoding of special characters
   - Test long key hashing
   - Test determinism

4. **Version Isolation**:
   - Test storing multiple versions
   - Test retrieving specific versions
   - Test invalidating specific versions

5. **Error Handling**:
   - Test corrupted metadata handling
   - Test missing range file handling
   - Test invalid cache key handling

### Property-Based Testing

Property-based tests will verify universal properties across all inputs using the `quickcheck` library. Each test will run a minimum of 100 iterations with randomly generated inputs.

**Testing Framework**: `quickcheck` (Rust property-based testing library)

**Configuration**: Minimum 100 iterations per property test

**Property Test Tagging**: Each property-based test must include a comment with the format:
```rust
// **Feature: versioned-request-validation, Property N: <property_text>**
```

This links the test to the specific correctness property in this design document.

**Property Tests**:

1. **Property 1: Versioned Cache Key Uniqueness**
   - Generate random bucket, object_key, and two different version IDs
   - Verify cache keys are different

2. **Property 2: Versioned Cache Key Determinism**
   - Generate random bucket, object_key, and version ID
   - Generate cache key twice
   - Verify both results are identical

3. **Property 3: Version ID Preservation in Cache Key**
   - Generate random version IDs with special characters
   - Verify version ID appears unmodified in cache key

4. **Property 4: Sharded Path Consistency for Same Object**
   - Generate random bucket, object_key, and two version IDs
   - Resolve sharded paths for both versions
   - Verify bucket/XX/YYY prefix is identical

5. **Property 5: Bucket Isolation in Sharded Paths**
   - Generate random object_key and two different buckets
   - Resolve sharded paths for both
   - Verify bucket directories differ but XX/YYY are the same

6. **Property 6: Long Filename Handling**
   - Generate cache keys that exceed 200 characters when sanitized
   - Verify filename is exactly 64 hex characters (BLAKE3 hash)

7. **Property 7: Filename Sanitization Correctness**
   - Generate cache keys with filesystem-unsafe characters
   - Verify all unsafe characters are percent-encoded

8. **Property 8: Filename Uniqueness for Different Versions**
   - Generate random bucket, object_key, and two version IDs
   - Sanitize both cache keys
   - Verify filenames are different

9. **Property 9: Version Isolation During Storage**
   - Store two versions of the same object
   - Verify each has separate metadata and range files
   - Verify files don't interfere with each other

10. **Property 10: Version Isolation During Retrieval**
    - Store two versions with different data
    - Retrieve version A
    - Verify returned data matches version A, not version B

11. **Property 11: Non-Versioned Cache Key Format**
    - Generate random bucket and object_key without version ID
    - Verify cache key doesn't contain `:version:`

12. **Property 12: Versioned Cache Key Format**
    - Generate random bucket, object_key, and version ID
    - Verify cache key matches format `bucket:object_key:version:version_id`

13. **Property 13: Sharded Path Structure**
    - Generate random versioned cache keys
    - Resolve sharded paths
    - Verify path matches structure `{type}/{bucket}/{XX}/{YYY}/{filename}`
    - Verify XX is 2 hex digits and YYY is 3 hex digits

14. **Property 14: Object Key Hashing Only**
    - Generate versioned cache keys with same object_key but different buckets/versions
    - Verify XX/YYY directories are the same (hash is from object_key only)

### Integration Testing

Integration tests will verify end-to-end workflows:

1. **Versioned Object Storage and Retrieval**:
   - Store a versioned object
   - Retrieve it by version ID
   - Verify data matches

2. **Multiple Version Storage**:
   - Store multiple versions of the same object
   - Retrieve each version
   - Verify each returns correct data

3. **Versioned Range Requests**:
   - Store a versioned object
   - Request byte ranges
   - Verify ranges are served from cache

4. **Versioned Object Invalidation**:
   - Store multiple versions
   - Invalidate one version
   - Verify only that version is removed

5. **Versioned Multipart Uploads**:
   - Initiate versioned multipart upload
   - Upload parts
   - Complete upload
   - Retrieve completed object
   - Verify data is correct

6. **Version Isolation**:
   - Store version A
   - Store version B
   - Invalidate version A
   - Verify version B still exists and is retrievable

7. **Corrupted Metadata Recovery**:
   - Store a versioned object
   - Corrupt the metadata file
   - Attempt retrieval
   - Verify cache miss and S3 fallback

8. **Missing Range File Recovery**:
   - Store a versioned object with ranges
   - Delete a range file
   - Request the range
   - Verify S3 fallback and cache update

## Performance Considerations

### Metadata File Size

- Metadata files remain small (<100KB) even with hundreds of ranges
- JSON parsing is fast (sub-10ms for typical metadata)
- Metadata-only operations (TTL transitions) are very fast

### Directory Scalability

- Bucket-first sharding supports tens of millions of objects per bucket
- 1,048,576 leaf directories per bucket (256 × 4,096)
- Optimal capacity: ~2.6 billion files per bucket
- Lazy directory creation avoids startup overhead

### Concurrent Access

- Read operations don't acquire locks (concurrent reads are fast)
- Write operations use file locking (serialized per cache key)
- Different versions can be written concurrently (different lock files)
- Lock contention is minimal due to fine-grained locking

### Cache Lookup Performance

- O(1) hash computation (BLAKE3 is very fast)
- O(log n) directory traversal (filesystem operation)
- Sub-millisecond lookups for typical cases
- Metadata parsing: sub-10ms for typical files

### Storage Efficiency

- Compression reduces storage by 50-90% for compressible data
- Content-aware compression avoids double-compression
- Unified range storage eliminates data duplication
- Metadata overhead is minimal (<1% of total storage)

## Security Considerations

### Filename Safety

- Percent-encoding prevents directory traversal attacks
- Long filenames are hashed to prevent filesystem limits
- Version IDs are sanitized before use in filenames

### Concurrent Access Safety

- File locking prevents race conditions
- Atomic operations prevent partial writes
- Corrupted files are detected and removed

### Version Isolation

- Different versions cannot interfere with each other
- Invalidation is version-specific
- No cross-version data leakage

## Backward Compatibility

### Migration from Flat Structure

The new sharded structure is a breaking change from the old flat structure. However, the system handles this gracefully:

1. **New Installations**: Use sharded structure from the start
2. **Existing Installations**: Cache repopulates on demand from S3
3. **No Migration Tool**: Clean slate approach is recommended

### Fallback Behavior

If sharded path resolution fails (e.g., invalid cache key format), the system falls back to the old flat structure for backward compatibility. This ensures the system remains functional even with unexpected inputs.

## Monitoring and Observability

### Metrics

- Cache hit/miss rates for versioned objects
- Metadata file sizes
- Range file counts per object
- Corrupted metadata events
- Disk full events
- Lock wait times

### Logging

All log messages for versioned operations include:
- Cache key (including version ID)
- Version ID (explicitly)
- Operation type (store, retrieve, invalidate)
- File paths (metadata and range files)
- Timing information
- Error details (if applicable)

### Example Log Messages

```
INFO Storing versioned object: key=my-bucket:file.txt:version:v123, size=1024 bytes
INFO Metadata file created: key=my-bucket:file.txt:version:v123, path=objects/my-bucket/a7/f3c/...
INFO Range file created: key=my-bucket:file.txt:version:v123, range=0-1023, path=ranges/my-bucket/a7/f3c/...
INFO Retrieving versioned object: key=my-bucket:file.txt:version:v123, result=cache_hit
INFO Invalidating versioned object: key=my-bucket:file.txt:version:v123, removed=2 files
ERROR Corrupted metadata detected: key=my-bucket:file.txt:version:v123, recovery=delete_and_cache_miss
```
