# Requirements Document

## Introduction

Validate that S3 versioned requests (requests with `versionId` query parameter) are correctly handled with the new bucket-first hash-based sharded disk caching format. The proxy currently supports versioned object caching, but we need to ensure the new sharding architecture (bucket/XX/YYY structure) correctly stores and retrieves versioned objects without conflicts or data corruption.

This validation is critical because versioned objects use different cache keys (`path:version:version_id`) and must be isolated from non-versioned objects and from other versions of the same object.

## Glossary

- **Version ID**: S3's unique identifier for a specific version of an object (e.g., "abc123")
- **Versioned Request**: S3 GET/HEAD request with `versionId` query parameter
- **Cache Key**: Unique identifier for cached data, format: `bucket:object_key` or `bucket:object_key:version:version_id`
- **Sharded Path**: Bucket-first hash-based directory structure: `{type}/{bucket}/{XX}/{YYY}/{filename}`
- **BLAKE3 Hash**: Cryptographic hash function used for directory sharding (hashes object_key, not bucket)
- **Metadata File**: JSON file (`.meta`) containing object metadata and range index
- **Range File**: Binary file (`.bin`) containing compressed cached data for a byte range
- **Cache Manager**: Component coordinating RAM and disk caching operations
- **Disk Cache Manager**: Component handling file-based cache storage with sharding

## Requirements

### Requirement 1: Versioned Cache Key Generation

**User Story:** As a developer, I want versioned objects to have unique cache keys, so that different versions never conflict.

#### Acceptance Criteria

1. WHEN generating a cache key for a versioned request THEN the system SHALL include the version ID in the format `bucket:object_key:version:version_id`
2. WHEN generating a cache key for a non-versioned request THEN the system SHALL use the format `bucket:object_key` without version components
3. WHEN two requests have the same bucket and object key but different version IDs THEN the system SHALL generate different cache keys
4. WHEN two requests have the same bucket, object key, and version ID THEN the system SHALL generate identical cache keys
5. WHEN the version ID contains special characters THEN the system SHALL include them in the cache key without modification

### Requirement 2: Sharded Path Resolution for Versioned Objects

**User Story:** As a developer, I want versioned objects to use the sharded directory structure, so that they benefit from scalability improvements.

#### Acceptance Criteria

1. WHEN resolving a sharded path for a versioned cache key THEN the system SHALL hash only the object_key portion (excluding bucket and version components)
2. WHEN resolving a sharded path for `bucket:object_key:version:version_id` THEN the system SHALL produce path `{type}/{bucket}/{XX}/{YYY}/{sanitized_key}.meta`
3. WHEN two versions of the same object are cached THEN the system SHALL place them in the same shard directory (same bucket/XX/YYY)
4. WHEN the same object key exists in different buckets THEN the system SHALL place them in different bucket directories but same hash directories
5. WHEN the sanitized cache key exceeds 200 characters THEN the system SHALL use BLAKE3 hash as the filename

### Requirement 3: Versioned Object Storage

**User Story:** As a user, I want to cache different versions of the same object, so that I can access historical versions quickly.

#### Acceptance Criteria

1. WHEN storing a versioned object THEN the system SHALL create a metadata file at the sharded path with version ID in the metadata
2. WHEN storing a versioned object THEN the system SHALL create range files at the sharded path with version-specific filenames
3. WHEN storing multiple versions of the same object THEN the system SHALL create separate metadata and range files for each version
4. WHEN storing a versioned object THEN the system SHALL include the version ID in the ObjectMetadata structure
5. WHEN storing a versioned object as a full object THEN the system SHALL store it as range 0-N in the ranges directory

### Requirement 4: Versioned Object Retrieval

**User Story:** As a user, I want to retrieve specific versions of objects from cache, so that I get the correct historical data.

#### Acceptance Criteria

1. WHEN retrieving a versioned object from cache THEN the system SHALL use the version-specific cache key to locate the metadata file
2. WHEN retrieving a versioned object from cache THEN the system SHALL load metadata from the sharded path
3. WHEN retrieving a versioned object from cache THEN the system SHALL load range files from the sharded path
4. WHEN retrieving a versioned object THEN the system SHALL return the version ID in the response metadata
5. WHEN requesting a non-existent version THEN the system SHALL return cache miss and fetch from S3

### Requirement 5: Version Isolation

**User Story:** As a developer, I want different versions to be completely isolated, so that version conflicts never occur.

#### Acceptance Criteria

1. WHEN caching version A of an object THEN the system SHALL NOT affect cached data for version B of the same object
2. WHEN invalidating version A of an object THEN the system SHALL NOT invalidate version B of the same object
3. WHEN caching a non-versioned object THEN the system SHALL NOT affect cached versioned objects with the same object key
4. WHEN retrieving version A THEN the system SHALL NOT return data from version B even if they share the same object key
5. WHEN listing cached files in a shard directory THEN the system SHALL correctly identify which files belong to which version

### Requirement 6: Versioned Range Requests

**User Story:** As a user, I want to request byte ranges from versioned objects, so that I can efficiently access large versioned files.

#### Acceptance Criteria

1. WHEN requesting a byte range from a versioned object THEN the system SHALL generate a cache key including the version ID
2. WHEN storing a range from a versioned object THEN the system SHALL create a range file at the version-specific sharded path
3. WHEN retrieving a range from a versioned object THEN the system SHALL load the correct version-specific range file
4. WHEN multiple ranges of a versioned object are cached THEN the system SHALL store them as separate range files in the same shard directory
5. WHEN requesting a range that spans multiple cached ranges THEN the system SHALL merge them correctly for the specific version

### Requirement 7: Versioned Object Invalidation

**User Story:** As a developer, I want to invalidate specific versions, so that stale versioned data is removed from cache.

#### Acceptance Criteria

1. WHEN invalidating a versioned object THEN the system SHALL remove the version-specific metadata file from the sharded path
2. WHEN invalidating a versioned object THEN the system SHALL remove all version-specific range files from the sharded path
3. WHEN invalidating a versioned object THEN the system SHALL NOT remove files belonging to other versions
4. WHEN invalidating all versions of an object THEN the system SHALL remove metadata and range files for all versions
5. WHEN invalidating a non-existent version THEN the system SHALL complete without errors

### Requirement 8: Versioned Multipart Uploads

**User Story:** As a user, I want to cache multipart uploads of versioned objects, so that large versioned objects are cached efficiently.

#### Acceptance Criteria

1. WHEN initiating a multipart upload for a versioned object THEN the system SHALL create metadata with the version ID
2. WHEN storing parts of a versioned multipart upload THEN the system SHALL associate parts with the correct version
3. WHEN completing a versioned multipart upload THEN the system SHALL store ranges with version-specific cache keys
4. WHEN retrieving a completed versioned multipart upload THEN the system SHALL merge ranges for the correct version
5. WHEN invalidating a versioned multipart upload THEN the system SHALL remove all parts and ranges for that version only

### Requirement 9: Backward Compatibility

**User Story:** As a system administrator, I want the new sharding format to handle versioned objects correctly, so that upgrades don't break versioned object caching.

#### Acceptance Criteria

1. WHEN the system starts with an empty cache THEN the system SHALL create sharded directories lazily on first versioned object write
2. WHEN storing a versioned object in the new format THEN the system SHALL NOT create files in the old flat structure
3. WHEN retrieving a versioned object THEN the system SHALL only check the new sharded structure
4. WHEN the cache contains no versioned objects THEN the system SHALL NOT create version-specific directories
5. WHEN migrating from old to new format THEN the system SHALL handle missing old-format versioned objects gracefully

### Requirement 10: Filename Sanitization for Versioned Objects

**User Story:** As a developer, I want version IDs to be safely encoded in filenames, so that filesystem operations never fail.

#### Acceptance Criteria

1. WHEN sanitizing a versioned cache key THEN the system SHALL percent-encode filesystem-unsafe characters in the version ID
2. WHEN the versioned cache key exceeds 200 characters THEN the system SHALL use BLAKE3 hash as the filename
3. WHEN the version ID contains colons THEN the system SHALL encode them as `%3A` in the filename
4. WHEN the version ID contains slashes THEN the system SHALL encode them as `%2F` in the filename
5. WHEN two versioned cache keys differ only in version ID THEN the system SHALL produce different sanitized filenames

### Requirement 11: Versioned Object Expiration

**User Story:** As a user, I want versioned objects to respect TTL settings, so that stale versioned data is eventually removed.

#### Acceptance Criteria

1. WHEN storing a versioned object THEN the system SHALL set expiration time based on GET_TTL configuration
2. WHEN retrieving an expired versioned object THEN the system SHALL treat it as a cache miss
3. WHEN a versioned object expires THEN the system SHALL remove its metadata and range files
4. WHEN checking expiration for a versioned object THEN the system SHALL NOT affect expiration of other versions
5. WHEN GET_TTL is infinite THEN the system SHALL cache versioned objects indefinitely until explicitly invalidated

### Requirement 12: Versioned Object Compression

**User Story:** As a developer, I want versioned objects to be compressed, so that cache space is used efficiently.

#### Acceptance Criteria

1. WHEN storing a versioned object THEN the system SHALL apply content-aware compression based on file extension
2. WHEN storing a versioned object range THEN the system SHALL compress the range data using LZ4 if appropriate
3. WHEN retrieving a versioned object THEN the system SHALL decompress the data using the algorithm specified in metadata
4. WHEN the versioned object is already compressed (e.g., .zip, .gz) THEN the system SHALL store it without additional compression
5. WHEN compression metadata is stored THEN the system SHALL include original size, compressed size, and algorithm

### Requirement 13: Concurrent Access to Versioned Objects

**User Story:** As a user, I want multiple clients to access different versions concurrently, so that version access is performant.

#### Acceptance Criteria

1. WHEN multiple clients request different versions of the same object THEN the system SHALL serve them concurrently without blocking
2. WHEN one client writes version A while another reads version B THEN the system SHALL NOT cause read failures
3. WHEN two clients write the same version concurrently THEN the system SHALL use file locking to prevent corruption
4. WHEN reading a versioned object THEN the system SHALL NOT acquire write locks
5. WHEN writing a versioned object THEN the system SHALL acquire a version-specific lock file

### Requirement 14: Error Handling for Versioned Objects

**User Story:** As a developer, I want clear error messages for versioned object operations, so that I can debug issues quickly.

#### Acceptance Criteria

1. WHEN a versioned object metadata file is corrupted THEN the system SHALL log an error with the version ID and fall back to S3
2. WHEN a versioned range file is missing THEN the system SHALL log a warning with the version ID and fetch from S3
3. WHEN sharded path resolution fails for a versioned key THEN the system SHALL log an error with the cache key and version ID
4. WHEN disk space is exhausted while storing a versioned object THEN the system SHALL log an error and return a clear error message
5. WHEN a versioned object operation fails THEN the system SHALL include the version ID in all log messages

### Requirement 15: Metrics for Versioned Objects

**User Story:** As a system administrator, I want metrics for versioned object caching, so that I can monitor version-specific cache performance.

#### Acceptance Criteria

1. WHEN a versioned object is cached THEN the system SHALL increment cache storage metrics
2. WHEN a versioned object is retrieved from cache THEN the system SHALL increment cache hit metrics
3. WHEN a versioned object cache miss occurs THEN the system SHALL increment cache miss metrics
4. WHEN versioned objects are invalidated THEN the system SHALL increment invalidation metrics
5. WHEN logging cache operations THEN the system SHALL include version ID in log messages for versioned requests
