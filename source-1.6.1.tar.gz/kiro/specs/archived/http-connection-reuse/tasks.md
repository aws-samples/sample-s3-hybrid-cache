# Implementation Plan: HTTP/1.1 Connection Reuse

**Status: COMPLETE** - All tasks implemented and verified.

- [x] 1. Add connection pool configuration support
  - Added `ConnectionPoolConfig` struct to config module
  - Added configuration fields to `config.yaml` schema
  - Implemented default values (30s idle timeout, 10 max idle per host)
  - Added configuration validation
  - _Requirements: 5.1, 5.2, 5.3_

- [x] 2. Refactor S3Client to use Hyper Client
- [x] 2.1 Add Hyper Client infrastructure to S3Client
  - Added `hyper::Client` with `CustomHttpsConnector` to S3Client struct
  - Added `ConnectionPoolConfig` field to S3Client
  - Updated S3Client::new() to initialize Hyper client with pooling
  - _Requirements: 1.1, 2.1_

- [x] 2.2 Implement client creation and caching
  - Implemented `CustomHttpsConnector` for endpoint connections
  - Configured `HttpsConnectorBuilder` with native roots
  - Set pool_idle_timeout and pool_max_idle_per_host from config
  - _Requirements: 1.2, 1.3, 2.2, 5.3_

- [x] 2.3 Write property test for client caching
  - **Property 1: Connection Reuse for Sequential Requests**
  - **Validates: Requirements 1.1**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 2.4 Refactor forward_request to use Hyper Client
  - Replaced manual TLS connection with `client.request()`
  - Updated request building to use Hyper's Request builder
  - Handle response conversion from Hyper to S3Response
  - _Requirements: 1.1, 7.1_

- [x] 2.5 Write property test for request/response equivalence
  - **Property 20: Request/Response Behavioral Equivalence**
  - **Validates: Requirements 7.1**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 3. Integrate with existing load balancing
- [x] 3.1 Implement IP-specific request routing
  - Added method to select target IP from ConnectionPoolManager
  - Implemented URI rewriting to use specific IP address
  - Preserve Host header with original endpoint name
  - _Requirements: 4.1, 4.2_

- [x] 3.2 Maintain per-IP metrics
  - Record request metrics with target IP address
  - Update ConnectionPoolManager with request results
  - Track connection reuse per IP
  - _Requirements: 4.3, 6.4_

- [x] 3.3 Write property test for load balancing
  - **Property 13: Load Balancing Strategy Application**
  - **Validates: Requirements 4.2**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 3.4 Handle DNS updates
  - Detect new IP addresses from DNS resolution
  - Create clients for new IPs as needed
  - Remove clients for IPs no longer in DNS
  - _Requirements: 4.4, 4.5_

- [x] 3.5 Write property test for dynamic pool management
  - **Property 15: Dynamic Pool Creation for New IPs**
  - **Validates: Requirements 4.4**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 4. Implement connection health monitoring
- [x] 4.1 Add error handling for connection failures
  - Detect network errors and remove connections
  - Handle timeout errors with connection removal
  - Detect TLS errors and retry with new connection
  - _Requirements: 1.4, 3.1, 3.2, 3.3_

- [x] 4.2 Write property test for error handling
  - **Property 4: Error-Triggered Connection Removal**
  - **Validates: Requirements 1.4, 3.1, 3.2, 3.3**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 4.3 Implement connection validation
  - Added validation check before using pooled connection
  - Remove invalid connections from pool
  - Retry with different connection on validation failure
  - _Requirements: 3.4, 3.5_

- [x] 4.4 Write property test for connection validation
  - **Property 10: Connection Validation Before Use**
  - **Validates: Requirements 3.4**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 5. Add observability and metrics
- [x] 5.1 Implement connection reuse logging
  - Log debug message when connection is reused
  - Log info message when new connection is created
  - Log debug message when connection is closed due to timeout
  - Include connection ID and target IP in logs
  - _Requirements: 6.1, 6.2, 6.3_

- [x] 5.2 Add connection pool statistics
  - Implemented method to get pool statistics
  - Include total connections, idle connections, reuse count
  - Exposed statistics through existing metrics endpoint
  - _Requirements: 6.4_

- [x] 5.3 Implement error logging
  - Log connection errors with details
  - Include connection ID, IP, and error type
  - Log at appropriate level (error for failures, debug for retries)
  - _Requirements: 6.5_

- [x] 5.4 Write property test for metrics consistency
  - **Property 14: Metrics Recording on Reuse**
  - **Validates: Requirements 4.3**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 6. Ensure backward compatibility
- [x] 6.1 Verify existing features work
  - Tested caching with connection pooling
  - Tested range requests with connection pooling
  - Tested signed requests with connection pooling
  - Tested write-through caching with connection pooling
  - _Requirements: 7.3_

- [x] 6.2 Write property test for feature compatibility
  - **Property 22: Feature Compatibility**
  - **Validates: Requirements 7.3**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 6.3 Verify existing metrics continue to work
  - Tested ConnectionPoolManager metrics
  - Tested health monitoring endpoints
  - Verified metrics accuracy with connection pooling
  - _Requirements: 7.4_

- [x] 6.4 Write property test for metrics preservation
  - **Property 23: Existing Metrics Preservation**
  - **Validates: Requirements 7.4**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 6.5 Implement graceful shutdown
  - Close all pooled connections on shutdown
  - Wait for in-flight requests to complete
  - Clean up client resources
  - _Requirements: 7.5_

- [x] 6.6 Write property test for graceful shutdown
  - **Property 24: Graceful Shutdown**
  - **Validates: Requirements 7.5**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 7. Add configuration and feature flag
- [x] 7.1 Add feature flag for connection pooling
  - Added `keepalive_enabled` configuration option
  - Default to true for new deployments
  - Allow disabling for rollback if needed
  - _Requirements: 5.3_

- [x] 7.2 Document configuration options
  - Documented idle_timeout parameter
  - Documented max_idle_per_host parameter
  - Documented keepalive_enabled flag
  - Provided configuration examples
  - _Requirements: 5.1, 5.2, 5.3_

- [x] 8. Checkpoint - All tests pass
  - All tests pass

- [x] 9. Performance testing and tuning
- [x] 9.1 Benchmark latency improvements
  - Measured latency for sequential requests
  - Compared with baseline (no connection reuse)
  - Verified improvement target
  - Tested with various request patterns
  - _Requirements: 1.1_

- [x] 9.2 Test connection pool under load
  - Tested with high concurrent request volume
  - Verified pool size limits are enforced
  - Checked for connection leaks
  - Monitored memory usage
  - _Requirements: 2.4, 5.4_

- [x] 9.3 Write property test for pool size enforcement
  - **Property 8: Pool Size Limit Enforcement**
  - **Validates: Requirements 2.4**
  - Implemented in `tests/connection_keepalive_property_test.rs`

- [x] 9.4 Tune default parameters
  - Adjusted idle timeout based on testing
  - Adjusted max idle connections based on testing
  - Documented recommended values for different workloads
  - _Requirements: 5.1, 5.2_

- [x] 10. Final checkpoint - All tests pass
  - All tests pass

## Notes

- Feature is fully implemented and deployed
- Connection keepalive is enabled by default
- Configuration available in `ConnectionPoolConfig`
- Metrics tracked in `MetricsManager.connection_keepalive_stats`
- Property tests in `tests/connection_keepalive_property_test.rs`
- Integration tests in `tests/connection_keepalive_test.rs`
- Benchmark tests in `tests/connection_keepalive_benchmark.rs`
