# Design Document: HTTP/1.1 Connection Reuse

## Overview

This design implements HTTP/1.1 connection reuse with keep-alive to optimize S3 request performance by eliminating redundant TCP and TLS handshakes. The current implementation creates a new TCP connection and performs a TLS handshake for every request, resulting in approximately 4 RTTs (40-80ms) of overhead per request. By reusing connections, we can reduce this to 1 RTT for subsequent requests, achieving a 40-60% latency reduction.

The design leverages Hyper's built-in `Client` with connection pooling capabilities, integrating it with the existing `ConnectionPoolManager` for metrics, load balancing, and health monitoring.

## Architecture

### Current Architecture
```
Request → S3Client.forward_request()
  → get_connection() [metadata only]
  → establish_tls_with_retry() [new TCP + TLS]
  → send_http_request() [HTTP request/response]
  → abort connection
  → release_connection() [metadata only]
```

### New Architecture
```
Request → S3Client.forward_request()
  → hyper::Client.request() [reuses existing connection if available]
    → Connection Pool [managed by Hyper]
      → Existing connection (if available and healthy)
      → OR new TCP + TLS connection
  → record metrics in ConnectionPoolManager
```

### Key Changes

1. **Replace manual connection handling** with `hyper::Client`
2. **Integrate Hyper's pool** with existing `ConnectionPoolManager` for metrics
3. **Maintain per-IP pools** for load balancing compatibility
4. **Configure idle timeouts** and pool sizes

## Components and Interfaces

### 1. S3Client Refactoring

**Current Interface** (preserved):
```rust
pub struct S3Client {
    pool_manager: Arc<Mutex<ConnectionPoolManager>>,
    tls_connector: TlsConnector,
    request_timeout: Duration,
    max_retries: usize,
}

impl S3Client {
    pub async fn forward_request(&self, context: S3RequestContext) -> Result<S3Response>;
}
```

**New Internal Structure**:
```rust
pub struct S3Client {
    // Hyper clients per endpoint (for connection pooling)
    clients: Arc<RwLock<HashMap<String, Client<HttpsConnector<HttpConnector>>>>>,
    
    // Existing pool manager for metrics and load balancing
    pool_manager: Arc<Mutex<ConnectionPoolManager>>,
    
    // Connection pool configuration
    pool_config: ConnectionPoolConfig,
    
    request_timeout: Duration,
    max_retries: usize,
}

#[derive(Clone)]
pub struct ConnectionPoolConfig {
    pub idle_timeout: Duration,           // Default: 90 seconds
    pub max_idle_per_host: usize,         // Default: 10
    pub enable_http2: bool,               // Default: false
}
```

### 2. Hyper Client Integration

```rust
use hyper::client::Client;
use hyper_rustls::HttpsConnectorBuilder;

impl S3Client {
    fn create_client_for_endpoint(&self, endpoint: &str) -> Result<Client<HttpsConnector<HttpConnector>>> {
        let https = HttpsConnectorBuilder::new()
            .with_native_roots()
            .https_or_http()
            .enable_http1()
            .build();
        
        // Note: Hyper's pool_idle_timeout applies to all connections uniformly.
        // We use the standard 30s timeout here. The extended 90s timeout for one
        // connection will be implemented through custom connection management logic.
        let client = Client::builder()
            .pool_idle_timeout(self.pool_config.idle_timeout)
            .pool_max_idle_per_host(self.pool_config.max_idle_per_host)
            .build(https);
        
        Ok(client)
    }
    
    async fn get_or_create_client(&self, endpoint: &str) -> Result<Client<HttpsConnector<HttpConnector>>> {
        // Check if client exists
        {
            let clients = self.clients.read().await;
            if let Some(client) = clients.get(endpoint) {
                return Ok(client.clone());
            }
        }
        
        // Create new client
        let client = self.create_client_for_endpoint(endpoint)?;
        
        // Store for reuse
        {
            let mut clients = self.clients.write().await;
            clients.insert(endpoint.to_string(), client.clone());
        }
        
        Ok(client)
    }
}
```

### 3. Load Balancing Integration

To maintain compatibility with existing IP-based load balancing:

```rust
impl S3Client {
    async fn forward_request_with_load_balancing(
        &self,
        context: &S3RequestContext,
    ) -> Result<S3Response> {
        // Get target IP from existing load balancer
        let target_ip = {
            let mut pool_manager = self.pool_manager.lock().await;
            pool_manager.select_ip_for_request(&context.host, context.request_size).await?
        };
        
        // Build URI with specific IP
        let uri_with_ip = self.build_uri_with_ip(&context.uri, target_ip)?;
        
        // Get Hyper client for this endpoint
        let client = self.get_or_create_client(&context.host).await?;
        
        // Build HTTP request
        let request = self.build_hyper_request(context, uri_with_ip)?;
        
        // Send request (Hyper handles connection reuse)
        let start = Instant::now();
        let response = client.request(request).await
            .map_err(|e| ProxyError::HttpError(format!("Request failed: {}", e)))?;
        
        // Record metrics
        let duration = start.elapsed();
        self.record_request_metrics(&context.host, target_ip, duration, true).await?;
        
        // Convert Hyper response to S3Response
        self.convert_hyper_response(response, target_ip, duration).await
    }
}
```

### 4. Metrics Integration

```rust
impl S3Client {
    async fn record_request_metrics(
        &self,
        endpoint: &str,
        ip: IpAddr,
        duration: Duration,
        success: bool,
    ) -> Result<()> {
        let mut pool_manager = self.pool_manager.lock().await;
        pool_manager.record_request_metrics(endpoint, ip, duration, None, success)?;
        
        // Log connection reuse (Hyper doesn't expose this directly, so we infer from timing)
        if duration < Duration::from_millis(30) {
            debug!("Likely connection reuse for {} (fast response: {:?})", endpoint, duration);
        }
        
        Ok(())
    }
}
```

## Data Models

### Connection Pool Configuration

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConnectionPoolConfig {
    /// Duration most connections can remain idle before being closed
    #[serde(default = "default_idle_timeout")]
    pub idle_timeout: Duration,
    
    /// Duration for the longest-lived connection to remain idle
    #[serde(default = "default_extended_idle_timeout")]
    pub extended_idle_timeout: Duration,
    
    /// Maximum number of idle connections per host
    #[serde(default = "default_max_idle")]
    pub max_idle_per_host: usize,
}

fn default_idle_timeout() -> Duration {
    Duration::from_secs(30)
}

fn default_extended_idle_timeout() -> Duration {
    Duration::from_secs(90)
}

fn default_max_idle() -> usize {
    10
}

impl Default for ConnectionPoolConfig {
    fn default() -> Self {
        Self {
            idle_timeout: default_idle_timeout(),
            extended_idle_timeout: default_extended_idle_timeout(),
            max_idle_per_host: default_max_idle(),
        }
    }
}
```

### Configuration File Extension

```yaml
# config.yaml
connection_pool:
  idle_timeout: "30s"           # Most connections close after 30s idle
  extended_idle_timeout: "90s"  # One connection per endpoint can stay 90s
  max_idle_per_host: 10
```

### Idle Timeout Strategy

The connection pool implements a tiered timeout strategy:
- **Standard timeout (30s)**: Applied to most idle connections
- **Extended timeout (90s)**: Applied to the most recently used connection per endpoint

This ensures:
1. Quick cleanup of unused connections (30s)
2. One "warm" connection always available for burst traffic (90s)
3. Optimal balance between resource usage and performance

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Connection Reuse for Sequential Requests
*For any* sequence of requests to the same S3 endpoint where requests are separated by less than the idle timeout, the second and subsequent requests should reuse the connection from the first request (observable through reduced latency or connection metrics).
**Validates: Requirements 1.1**

### Property 2: Idle Connection Preservation
*For any* connection that has been idle for a duration less than the configured timeout, making a new request should reuse that connection rather than creating a new one.
**Validates: Requirements 1.2**

### Property 3: Idle Timeout Enforcement
*For any* connection that has been idle for longer than the configured timeout, the connection should no longer be available in the pool for reuse.
**Validates: Requirements 1.3**

### Property 4: Error-Triggered Connection Removal
*For any* connection that encounters a network error, timeout, or S3 connection-level error, that connection should be removed from the pool and subsequent requests should use a different connection.
**Validates: Requirements 1.4, 3.1, 3.2, 3.3**

### Property 5: Pool Retrieval Before Creation
*For any* request when an available connection exists in the pool for the target endpoint, that connection should be retrieved and used rather than creating a new connection.
**Validates: Requirements 2.1**

### Property 6: Connection Creation on Empty Pool
*For any* request when no available connection exists in the pool, a new connection should be created and added to the pool.
**Validates: Requirements 2.2**

### Property 7: Connection Return After Success
*For any* successful request, the connection used should be returned to the pool and available for subsequent requests.
**Validates: Requirements 2.3**

### Property 8: Pool Size Limit Enforcement
*For any* connection pool at maximum capacity, adding a new connection should result in the oldest idle connection being closed, maintaining the pool size at the configured maximum.
**Validates: Requirements 2.4**

### Property 9: Metrics Update on Connection Use
*For any* connection returned to the pool after use, the connection's last-used timestamp and request count should be updated to reflect the recent usage.
**Validates: Requirements 2.5**

### Property 10: Connection Validation Before Use
*For any* connection retrieved from the pool, the connection should be validated as healthy before being used for a request.
**Validates: Requirements 3.4**

### Property 11: Failed Validation Handling
*For any* connection that fails validation when retrieved from the pool, that connection should be removed and a different connection should be obtained.
**Validates: Requirements 3.5**

### Property 12: Per-IP Pool Separation
*For any* S3 endpoint with multiple IP addresses, separate connection pools should exist for each IP address.
**Validates: Requirements 4.1**

### Property 13: Load Balancing Strategy Application
*For any* request requiring a connection, the target IP address should be selected using the configured load balancing strategy before retrieving or creating a connection.
**Validates: Requirements 4.2**

### Property 14: Metrics Recording on Reuse
*For any* connection reuse event, metrics should be recorded for the associated IP address including request duration and success status.
**Validates: Requirements 4.3**

### Property 15: Dynamic Pool Creation for New IPs
*For any* DNS resolution that returns new IP addresses not currently in the pool, new connection pools should be created for those IP addresses.
**Validates: Requirements 4.4**

### Property 16: Graceful Connection Draining
*For any* IP address removed from DNS resolution, all connections to that IP should be gracefully closed and removed from the pool.
**Validates: Requirements 4.5**

### Property 17: Configuration Parameter Application
*For any* custom configuration values for idle timeout or max connections, those values should be applied to all connection pools created after configuration is loaded.
**Validates: Requirements 5.3**

### Property 18: Connection Reuse at Capacity
*For any* connection pool at maximum size, new requests should reuse existing connections rather than creating additional connections beyond the limit.
**Validates: Requirements 5.4**

### Property 19: Idle Connection Cleanup
*For any* connection that remains idle beyond the configured timeout, the connection should be closed and removed from the pool to free resources.
**Validates: Requirements 5.5**

### Property 20: Request/Response Behavioral Equivalence
*For any* request sent through the new connection pooling implementation, the response should be identical to what would be received from the previous implementation (same status, headers, body).
**Validates: Requirements 7.1**

### Property 21: Error Handling Equivalence
*For any* error scenario (network error, timeout, S3 error), the error handling and retry behavior should match the current implementation.
**Validates: Requirements 7.2**

### Property 22: Feature Compatibility
*For any* request type (cached, range, signed, etc.), all existing features should continue to function correctly with connection pooling enabled.
**Validates: Requirements 7.3**

### Property 23: Existing Metrics Preservation
*For any* metrics query to ConnectionPoolManager, all existing metrics and health monitoring data should continue to be available and accurate.
**Validates: Requirements 7.4**

### Property 24: Graceful Shutdown
*For any* system shutdown, all pooled connections across all endpoints should be gracefully closed before the process exits.
**Validates: Requirements 7.5**

## Error Handling

### Connection Errors
- **Network errors**: Remove connection from pool, retry with new connection
- **Timeout errors**: Close connection, remove from pool, retry
- **TLS errors**: Remove connection, retry with new connection
- **HTTP errors**: Keep connection if recoverable (4xx), remove if connection-level (connection reset)

### Pool Management Errors
- **Pool full**: Reuse existing connection (don't create new)
- **No available connections**: Create new connection
- **Validation failure**: Remove invalid connection, get another

### Fallback Strategy
If connection pooling encounters persistent errors:
1. Log error with details
2. Fall back to creating new connection for request
3. Continue attempting to use pool for subsequent requests
4. Alert if pool is consistently failing

## Testing Strategy

### Unit Tests
- Test connection pool configuration loading
- Test client creation with various configurations
- Test metrics recording and integration
- Test error handling for various failure scenarios
- Test pool size limit enforcement
- Test idle timeout behavior

### Property-Based Tests
Using `quickcheck` framework:

1. **Connection Reuse Property**: Generate sequences of requests, verify connections are reused
2. **Pool Size Property**: Generate random request patterns, verify pool never exceeds max size
3. **Timeout Property**: Generate requests with random delays, verify timeout enforcement
4. **Load Balancing Property**: Generate requests with multiple IPs, verify distribution
5. **Error Recovery Property**: Generate requests with random errors, verify proper handling
6. **Metrics Consistency Property**: Generate request sequences, verify metrics match actual behavior

### Integration Tests
- Test end-to-end request flow with connection reuse
- Test with real S3 endpoints (or mocked S3)
- Test concurrent requests to same endpoint
- Test DNS changes and pool updates
- Test graceful shutdown with active connections
- Test backward compatibility with existing features

### Performance Tests
- Benchmark latency improvement (target: 40-60% reduction for sequential requests)
- Measure connection creation rate (should decrease significantly)
- Test connection pool under high load
- Verify no connection leaks over extended periods
- Compare memory usage before/after

## Implementation Notes

### Phase 1: Core Implementation
1. Add `hyper::Client` to `S3Client`
2. Implement `get_or_create_client()` method
3. Refactor `forward_request()` to use Hyper client
4. Integrate with existing `ConnectionPoolManager` for metrics
5. Add configuration support

### Phase 2: Load Balancing Integration
1. Implement IP-specific URI building
2. Integrate with existing IP selection logic
3. Maintain per-IP metrics
4. Test with multiple S3 IPs

### Phase 3: Monitoring and Tuning
1. Add connection reuse logging
2. Add pool statistics endpoint
3. Tune default parameters based on testing
4. Document configuration options



## Migration Strategy

1. **Feature flag**: Add configuration option to enable/disable new pooling
2. **Gradual rollout**: Enable for subset of traffic initially
3. **Monitoring**: Watch for latency improvements and any errors
4. **Rollback plan**: Can disable via configuration if issues arise
5. **Full deployment**: Enable for all traffic once validated

## Performance Expectations

### Latency Reduction
- **First request**: Same as current (4 RTTs)
- **Subsequent requests**: 1 RTT (75% reduction in connection overhead)
- **Overall improvement**: 40-60% for workloads with sequential requests to same endpoint

### Resource Usage
- **Memory**: Slight increase due to pooled connections (~10KB per idle connection)
- **File descriptors**: Same or fewer (reusing connections)
- **CPU**: Slight decrease (fewer TLS handshakes)

### Scalability
- Connection pools scale per endpoint
- Each endpoint can have up to `max_idle_per_host` idle connections
- Total connections = endpoints × max_idle_per_host
- Example: 10 endpoints × 10 connections = 100 max idle connections
