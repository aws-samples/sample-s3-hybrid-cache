# Requirements Document

## Introduction

This specification implements a unified cache management system that combines intelligent eviction with per-range TTL expiration for the S3 proxy. The current system has several limitations:

1. **No intelligent eviction**: Disk cache only uses TTL expiration and capacity bypass
2. **Object-level TTL**: All ranges for an object share one TTL, wasting space on cold ranges
3. **No access tracking**: Cannot make eviction decisions based on usage patterns
4. **Frequent eviction scans**: Evicting just enough space causes repeated scans

The solution implements per-range TTL and access tracking, uses the configured eviction algorithm (LRU/TinyLFU), triggers eviction at 95% capacity, and evicts to 90% capacity to ensure space is always available for new data.

## Glossary

- **Proxy**: The S3 proxy server that intercepts and caches S3 requests
- **Range**: A contiguous byte range of an object stored as a separate .bin file
- **RangeSpec**: Metadata describing a cached range including TTL and access statistics
- **Per-Range TTL**: Each range has independent expiration time based on its access pattern
- **Eviction Algorithm**: Strategy for selecting ranges to evict (LRU/TinyLFU)
- **Eviction Trigger**: Threshold at which eviction starts (95% of max capacity)
- **Eviction Target**: Target size after eviction completes (90% of max capacity)
- **Eviction Buffer**: Space freed during eviction to minimize scan frequency (5% of capacity)
- **Hot Range**: Frequently accessed range with refreshed TTL
- **Cold Range**: Rarely accessed range that expires independently
- **Metadata Lock**: File lock preventing concurrent updates to .meta files

## Requirements

### Requirement 1

**User Story:** As a proxy user, I want each cached range to have its own TTL, so that frequently accessed ranges stay cached while rarely accessed ranges expire independently.

#### Acceptance Criteria

1. WHEN the Proxy caches a range THEN the Proxy SHALL store created_at, last_accessed, access_count, and expires_at for that specific range
2. WHEN the Proxy accesses a cached range THEN the Proxy SHALL update only that range's last_accessed and access_count
3. WHEN a range's TTL is refreshed THEN the Proxy SHALL update only that range's expires_at without affecting other ranges
4. WHEN the Proxy detects an expired range during access THEN the Proxy SHALL attempt conditional validation before removing it
5. WHEN conditional validation returns 304 Not Modified THEN the Proxy SHALL refresh the range TTL and serve from cache
6. WHEN conditional validation returns 200 OK THEN the Proxy SHALL remove the expired range and forward the request to S3 to cache new data
7. WHEN conditional validation fails or returns an unexpected status THEN the Proxy SHALL remove the expired range and forward the original request to S3
8. WHEN all ranges for an object expire THEN the Proxy SHALL remove the object metadata file

### Requirement 2

**User Story:** As a proxy user, I want disk cache eviction to use the configured algorithm (LRU/TinyLFU), so that the most valuable ranges remain cached.

#### Acceptance Criteria

1. WHEN the Proxy reaches cache capacity THEN the Proxy SHALL select ranges for eviction based on the configured algorithm
2. WHEN the eviction algorithm is LRU THEN the Proxy SHALL evict ranges with the oldest last_accessed timestamp
3. WHEN the eviction algorithm is TinyLFU THEN the Proxy SHALL evict ranges with the lowest combined frequency and recency score
4. WHEN multiple ranges have equal eviction scores THEN the Proxy SHALL evict the range with the oldest created_at timestamp

### Requirement 3

**User Story:** As a proxy user, I want eviction to start before capacity is reached and free sufficient space, so that cache performance remains high under load and space is always available for new data.

#### Acceptance Criteria

1. WHEN the Proxy reaches 95% of max capacity THEN the Proxy SHALL trigger eviction
2. WHEN the Proxy triggers eviction THEN the Proxy SHALL calculate target size as 90% of max capacity
3. WHEN the Proxy performs eviction THEN the Proxy SHALL evict ranges until cache size is at or below the target
4. WHEN eviction completes THEN the Proxy SHALL have freed at least 5% of total capacity
5. WHEN the Proxy cannot free sufficient space THEN the Proxy SHALL bypass caching for new data
6. WHEN cache size is below 95% THEN the Proxy SHALL NOT trigger eviction

### Requirement 4

**User Story:** As a proxy user, I want range metadata updates to be atomic and consistent, so that concurrent access from multiple instances doesn't corrupt data.

#### Acceptance Criteria

1. WHEN the Proxy updates range metadata THEN the Proxy SHALL acquire an exclusive file lock on the .meta file
2. WHEN the Proxy holds a metadata lock THEN other instances SHALL wait for the lock to be released
3. WHEN the Proxy updates range access statistics THEN the Proxy SHALL use in-place editing for efficiency
4. WHEN the Proxy updates range TTL THEN the Proxy SHALL modify only the specific range in the metadata
5. WHEN the Proxy releases a metadata lock THEN other instances SHALL be able to acquire it immediately

### Requirement 5

**User Story:** As a system operator running multiple proxy instances, I want eviction to be coordinated across instances, so that only one instance performs eviction at a time.

#### Acceptance Criteria

1. WHEN multiple Proxy instances reach capacity simultaneously THEN only one instance SHALL perform eviction
2. WHEN a Proxy instance performs eviction THEN it SHALL acquire the global eviction lock
3. WHEN a Proxy instance holds the global eviction lock THEN other instances SHALL wait or bypass caching
4. WHEN a Proxy instance is actively performing eviction THEN it SHALL periodically refresh the global eviction lock to prevent it from becoming stale
5. WHEN the global eviction lock has not been refreshed within the timeout period THEN any instance SHALL break the stale lock and proceed
6. WHEN eviction completes THEN the Proxy SHALL release the global eviction lock

### Requirement 6

**User Story:** As a proxy user, I want conditional validation to refresh TTLs on individual ranges, so that hot ranges stay cached without keeping cold ranges.

#### Acceptance Criteria

1. WHEN the Proxy receives a 304 Not Modified for a range request THEN the Proxy SHALL refresh only that range's TTL
2. WHEN the Proxy performs a HEAD request and ETag matches THEN the Proxy SHALL refresh TTLs only on ranges with matching ETag
3. WHEN the Proxy performs a HEAD request and ETag differs THEN the Proxy SHALL invalidate all ranges with mismatched ETag
4. WHEN the Proxy refreshes a range TTL THEN the Proxy SHALL update the range's expires_at to current time plus GET_TTL
5. WHEN the Proxy refreshes a range TTL THEN the Proxy SHALL update the range's last_accessed to current time

### Requirement 7

**User Story:** As a proxy user, I want range access statistics to be updated efficiently, so that cache performance is not degraded by tracking overhead.

#### Acceptance Criteria

1. WHEN the Proxy updates range access statistics THEN the update SHALL complete in less than 5ms
2. WHEN the Proxy updates range access statistics THEN the Proxy SHALL use in-place editing of the metadata file
3. WHEN the Proxy updates range access statistics THEN the Proxy SHALL not use fsync for performance
4. WHEN the Proxy updates range access statistics THEN the Proxy SHALL acquire the metadata lock
5. WHEN the Proxy updates range access statistics THEN the Proxy SHALL update only the specific range's fields

### Requirement 8

**User Story:** As a system operator, I want eviction and TTL operations to be logged, so that I can monitor cache behavior and troubleshoot issues.

#### Acceptance Criteria

1. WHEN the Proxy triggers eviction THEN the Proxy SHALL log the trigger reason, current size, and target size
2. WHEN the Proxy evicts ranges THEN the Proxy SHALL log the cache keys, range boundaries, and eviction scores
3. WHEN the Proxy completes eviction THEN the Proxy SHALL log the number of ranges evicted and space freed
4. WHEN the Proxy refreshes a range TTL THEN the Proxy SHALL log the cache key, range boundaries, and new expiration
5. WHEN the Proxy expires a range THEN the Proxy SHALL log the cache key, range boundaries, and expiration reason

### Requirement 9

**User Story:** As a proxy user, I want the system to handle edge cases gracefully, so that cache remains functional under all conditions.

#### Acceptance Criteria

1. WHEN a range's metadata is corrupted THEN the Proxy SHALL treat it as having default statistics and log a warning
2. WHEN eviction cannot free sufficient space THEN the Proxy SHALL bypass caching and log a warning
3. WHEN a metadata lock is held longer than timeout THEN the Proxy SHALL break the lock and log a warning
4. WHEN the Proxy deletes a range THEN the Proxy SHALL also delete the corresponding .bin file
5. WHEN the Proxy deletes the last range for an object THEN the Proxy SHALL also delete the .meta file

### Requirement 10

**User Story:** As a proxy user, I want known stale data to be actively removed, so that cache doesn't accumulate invalid entries.

#### Acceptance Criteria

1. WHEN the Proxy detects an ETag mismatch for a cached range THEN the Proxy SHALL immediately delete that range
2. WHEN the Proxy receives a PUT request for an object THEN the Proxy SHALL immediately invalidate all cached ranges for that object
3. WHEN the Proxy detects corrupted cache files THEN the Proxy SHALL immediately delete those files
4. WHEN conditional validation returns 200 OK THEN the Proxy SHALL immediately delete the old cached range
5. WHEN the Proxy deletes stale ranges THEN it SHALL log the cache key, range boundaries, and reason
