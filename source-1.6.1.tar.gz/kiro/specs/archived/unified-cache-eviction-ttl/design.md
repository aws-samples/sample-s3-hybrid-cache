# Design Document

## Overview

This design implements a unified cache management system combining per-range TTL expiration with intelligent eviction based on access patterns. The key innovations are:

1. **Per-Range TTL**: Each range has independent expiration, allowing hot ranges to stay cached while cold ranges expire
2. **Embedded Access Tracking**: Access statistics stored directly in RangeSpec (no separate files)
3. **In-Place Updates**: Efficient metadata updates using file locking and in-place editing
4. **Early Eviction Trigger**: Start eviction at 95% capacity to ensure space is always available
5. **5% Eviction Buffer**: Evict to 90% capacity to minimize scan frequency
6. **Proper Locking**: File locks prevent corruption in multi-instance deployments

## Architecture

### Current State

```rust
pub struct NewCacheMetadata {
    pub expires_at: SystemTime,  // ← Single TTL for entire object
    pub ranges: Vec<RangeSpec>,
}

pub struct RangeSpec {
    pub start: u64,
    pub end: u64,
    pub file_path: String,
    // No TTL, no access tracking
}
```

**Problems**:
- All ranges expire together
- No access-based eviction
- Wastes space on cold ranges

### Proposed State

```rust
pub struct NewCacheMetadata {
    pub cache_key: String,
    pub object_metadata: ObjectMetadata,
    pub ranges: Vec<RangeSpec>,  // ← Each range has own TTL
    pub created_at: SystemTime,
    // No object-level expires_at
    pub compression_info: CompressionInfo,
}

pub struct RangeSpec {
    // Range identification
    pub start: u64,
    pub end: u64,
    pub file_path: String,
    
    // Compression
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
    
    // Per-range TTL and access tracking (NEW)
    pub created_at: SystemTime,
    pub last_accessed: SystemTime,
    pub access_count: u64,
    pub expires_at: SystemTime,
}
```

### Eviction Flow with 5% Buffer

```
Cache reaches 95% capacity (9.5GB of 10GB max)
↓
Trigger eviction
↓
Calculate target: 90% of 10GB = 9GB
↓
Scan all ranges, calculate scores
↓
Sort by eviction score (LRU/TinyLFU)
↓
Evict ranges until size ≤ 9GB
↓
Freed 500MB (5% buffer)
↓
Cache new data without immediate re-eviction
```

**Benefits**: 
- Always have space available for new data (never hit 100%)
- 500MB buffer before next eviction scan
- Prevents cache thrashing at capacity limit

## Components and Interfaces

### 1. Enhanced RangeSpec

**Location**: `src/cache_types.rs`

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RangeSpec {
    // Range identification
    pub start: u64,
    pub end: u64,
    pub file_path: String,
    
    // Compression
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
    
    // Per-range TTL and access tracking
    pub created_at: SystemTime,
    pub last_accessed: SystemTime,
    pub access_count: u64,
    pub expires_at: SystemTime,
}

impl RangeSpec {
    /// Check if range is expired
    pub fn is_expired(&self) -> bool {
        SystemTime::now() > self.expires_at
    }
    
    /// Calculate LRU score (lower = evict first)
    pub fn lru_score(&self) -> u64 {
        self.last_accessed
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
    }
    
    /// Calculate TinyLFU score (lower = evict first)
    pub fn tinylfu_score(&self) -> u64 {
        let now = SystemTime::now();
        let recency_factor = now
            .duration_since(self.last_accessed)
            .unwrap_or_default()
            .as_secs()
            .max(1);
        
        // Frequency weighted by recency
        self.access_count * 1000 / recency_factor
    }
    
    /// Refresh TTL after access or validation
    pub fn refresh_ttl(&mut self, new_ttl: Duration) {
        self.expires_at = SystemTime::now() + new_ttl;
        self.last_accessed = SystemTime::now();
    }
    
    /// Update access statistics
    pub fn record_access(&mut self) {
        self.last_accessed = SystemTime::now();
        self.access_count += 1;
    }
}
```

### 2. Metadata Update with Locking

**Location**: `src/disk_cache.rs`

```rust
impl DiskCacheManager {
    /// Update range access statistics with file locking
    pub async fn update_range_access(
        &mut self,
        cache_key: &str,
        range_start: u64,
        range_end: u64,
    ) -> Result<()> {
        let metadata_path = self.get_new_metadata_file_path(cache_key);
        let lock_path = metadata_path.with_extension("meta.lock");
        
        // Acquire exclusive lock
        let lock_file = std::fs::OpenOptions::new()
            .create(true)
            .write(true)
            .open(&lock_path)?;
        lock_file.lock_exclusive()?;
        
        // Read metadata
        let mut metadata = self.load_metadata_new(cache_key).await?;
        
        // Find and update the specific range
        if let Some(range) = metadata.ranges.iter_mut()
            .find(|r| r.start == range_start && r.end == range_end)
        {
            range.record_access();
            
            // Write updated metadata in-place
            let json = serde_json::to_string_pretty(&metadata)?;
            std::fs::write(&metadata_path, json)?;
            // No fsync for performance
        }
        
        // Release lock (automatic on drop)
        lock_file.unlock()?;
        
        Ok(())
    }
    
    /// Refresh range TTL after validation
    pub async fn refresh_range_ttl(
        &mut self,
        cache_key: &str,
        range_start: u64,
        range_end: u64,
        new_ttl: Duration,
    ) -> Result<()> {
        let metadata_path = self.get_new_metadata_file_path(cache_key);
        let lock_path = metadata_path.with_extension("meta.lock");
        
        // Acquire exclusive lock
        let lock_file = std::fs::OpenOptions::new()
            .create(true)
            .write(true)
            .open(&lock_path)?;
        lock_file.lock_exclusive()?;
        
        // Read metadata
        let mut metadata = self.load_metadata_new(cache_key).await?;
        
        // Find and update the specific range
        if let Some(range) = metadata.ranges.iter_mut()
            .find(|r| r.start == range_start && r.end == range_end)
        {
            range.refresh_ttl(new_ttl);
            
            // Write updated metadata in-place
            let json = serde_json::to_string_pretty(&metadata)?;
            std::fs::write(&metadata_path, json)?;
        }
        
        // Release lock
        lock_file.unlock()?;
        
        Ok(())
    }
    
    /// Remove an invalidated range after conditional validation (lazy expiration)
    /// This should be called during cache lookup when conditional validation (If-Modified-Since)
    /// returns 200 OK, indicating the cached data is stale.
    pub async fn remove_invalidated_range(
        &mut self,
        cache_key: &str,
        range_start: u64,
        range_end: u64,
    ) -> Result<()> {
        let metadata_path = self.get_new_metadata_file_path(cache_key);
        let lock_path = metadata_path.with_extension("meta.lock");
        
        // Acquire exclusive lock
        let lock_file = std::fs::OpenOptions::new()
            .create(true)
            .write(true)
            .open(&lock_path)?;
        lock_file.lock_exclusive()?;
        
        // Read metadata
        let mut metadata = self.load_metadata_new(cache_key).await?;
        
        // Find the specific expired range
        if let Some(range) = metadata.ranges.iter()
            .find(|r| r.start == range_start && r.end == range_end && r.is_expired())
        {
            // Delete .bin file for this range
            let range_path = self.cache_dir.join("ranges").join(&range.file_path);
            if range_path.exists() {
                std::fs::remove_file(&range_path)?;
            }
            
            // Remove this range from metadata
            metadata.ranges.retain(|r| !(r.start == range_start && r.end == range_end));
            
            if metadata.ranges.is_empty() {
                // No ranges left, delete metadata file
                std::fs::remove_file(&metadata_path)?;
            } else {
                // Update metadata
                let json = serde_json::to_string_pretty(&metadata)?;
                std::fs::write(&metadata_path, json)?;
            }
        }
        
        // Release lock
        lock_file.unlock()?;
        
        Ok(())
    }
}
```

### 3. Global Eviction Lock Management

**Location**: `src/cache.rs`

The global eviction lock prevents multiple instances from evicting simultaneously. The lock includes a heartbeat mechanism to distinguish between active eviction and crashed processes.

```rust
impl CacheManager {
    /// Acquire global eviction lock
    async fn acquire_global_eviction_lock(&self) -> Result<bool> {
        let lock_path = self.cache_dir.join("locks").join("eviction.lock");
        
        // Try to create lock file with exclusive access
        match std::fs::OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(&lock_path)
        {
            Ok(mut file) => {
                // Write lock metadata (timestamp + instance ID)
                let lock_data = format!("{}:{}", 
                    SystemTime::now().duration_since(SystemTime::UNIX_EPOCH)?.as_secs(),
                    self.instance_id
                );
                file.write_all(lock_data.as_bytes())?;
                Ok(true)
            }
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {
                // Lock exists - check if it's stale
                if self.is_eviction_lock_stale(&lock_path).await? {
                    warn!("Breaking stale eviction lock");
                    std::fs::remove_file(&lock_path)?;
                    // Retry acquisition
                    self.acquire_global_eviction_lock().await
                } else {
                    Ok(false)
                }
            }
            Err(e) => Err(e.into()),
        }
    }
    
    /// Check if eviction lock is stale (not refreshed within timeout)
    async fn is_eviction_lock_stale(&self, lock_path: &Path) -> Result<bool> {
        let lock_data = std::fs::read_to_string(lock_path)?;
        let parts: Vec<&str> = lock_data.split(':').collect();
        
        if parts.len() != 2 {
            return Ok(true); // Malformed lock
        }
        
        let lock_timestamp = parts[0].parse::<u64>()?;
        let now = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH)?.as_secs();
        let age = now.saturating_sub(lock_timestamp);
        
        // Lock is stale if not refreshed in 60 seconds
        Ok(age > 60)
    }
    
    /// Refresh global eviction lock (update timestamp)
    async fn refresh_global_eviction_lock(&self) -> Result<()> {
        let lock_path = self.cache_dir.join("locks").join("eviction.lock");
        
        // Update lock file with new timestamp
        let lock_data = format!("{}:{}", 
            SystemTime::now().duration_since(SystemTime::UNIX_EPOCH)?.as_secs(),
            self.instance_id
        );
        std::fs::write(&lock_path, lock_data)?;
        
        Ok(())
    }
    
    /// Release global eviction lock
    async fn release_global_eviction_lock(&self) -> Result<()> {
        let lock_path = self.cache_dir.join("locks").join("eviction.lock");
        
        if lock_path.exists() {
            std::fs::remove_file(&lock_path)?;
        }
        
        Ok(())
    }
}
```

**Lock Lifecycle**:
1. Instance acquires lock (creates file with timestamp + instance ID)
2. Background task refreshes lock every 30 seconds during eviction
3. Other instances check lock age before breaking it (must be >60s old)
4. Instance releases lock when eviction completes or fails

**Stale Lock Detection**:
- Lock is stale if timestamp is >60 seconds old
- Refresh interval is 30 seconds, so active eviction always keeps lock fresh
- Only crashed/hung processes will have stale locks

### 4. Eviction with 5% Buffer

**Location**: `src/cache.rs`

```rust
impl CacheManager {
    /// Trigger eviction when 95% capacity reached
    pub async fn evict_if_needed(
        &self,
        required_space: u64,
    ) -> Result<()> {
        let current_size = self.get_current_cache_size().await?;
        let max_size = self.get_max_cache_size();
        let eviction_trigger = (max_size as f64 * 0.95) as u64;
        
        // Trigger eviction at 95% capacity
        if current_size + required_space > eviction_trigger {
            info!(
                "Cache at 95% capacity: current={}, required={}, trigger={}, max={}, triggering eviction",
                current_size, required_space, eviction_trigger, max_size
            );
            
            // Calculate target: 90% of capacity (5% buffer)
            let target_size = (max_size as f64 * 0.90) as u64;
            let space_to_free = current_size.saturating_sub(target_size) + required_space;
            
            info!(
                "Eviction target: current={}, target={}, space_to_free={}",
                current_size, target_size, space_to_free
            );
            
            self.perform_eviction(space_to_free).await?;
        }
        
        Ok(())
    }
    
    /// Perform eviction to free specified space
    async fn perform_eviction(&self, space_to_free: u64) -> Result<()> {
        // Acquire global eviction lock
        let lock_acquired = self.acquire_global_eviction_lock().await?;
        if !lock_acquired {
            warn!("Failed to acquire global eviction lock, bypassing cache");
            return Err(ProxyError::CacheError("Eviction lock held by another instance".to_string()));
        }
        
        // Spawn background task to refresh lock periodically
        let lock_refresh_handle = tokio::spawn({
            let cache_mgr = self.clone();
            async move {
                let mut interval = tokio::time::interval(Duration::from_secs(30));
                loop {
                    interval.tick().await;
                    if let Err(e) = cache_mgr.refresh_global_eviction_lock().await {
                        warn!("Failed to refresh eviction lock: {}", e);
                        break;
                    }
                }
            }
        });
        
        // Scan all ranges and calculate eviction scores
        let mut candidates = self.scan_all_ranges().await?;
        
        // Sort by eviction score (lowest first)
        candidates.sort_by_key(|c| c.eviction_score);
        
        // Evict ranges until we've freed enough space
        let mut freed_space = 0u64;
        let mut evicted_count = 0u64;
        
        for candidate in candidates {
            if freed_space >= space_to_free {
                break;
            }
            
            info!(
                "Evicting range: key={}, range={}-{}, score={}, size={}",
                candidate.cache_key, candidate.start, candidate.end,
                candidate.eviction_score, candidate.size_bytes
            );
            
            self.evict_range(&candidate.cache_key, candidate.start, candidate.end).await?;
            freed_space += candidate.size_bytes;
            evicted_count += 1;
        }
        
        info!(
            "Eviction complete: evicted={} ranges, freed={} bytes",
            evicted_count, freed_space
        );
        
        // Stop lock refresh task
        lock_refresh_handle.abort();
        
        // Release global eviction lock
        self.release_global_eviction_lock().await?;
        
        if freed_space < space_to_free {
            warn!(
                "Eviction freed insufficient space: freed={}, required={}",
                freed_space, space_to_free
            );
            return Err(ProxyError::CacheError("Insufficient space after eviction".to_string()));
        }
        
        Ok(())
    }
    
    /// Scan all ranges across all objects
    async fn scan_all_ranges(&self) -> Result<Vec<EvictionCandidate>> {
        let objects_dir = self.cache_dir.join("objects");
        let mut candidates = Vec::new();
        
        for entry in std::fs::read_dir(&objects_dir)? {
            let entry = entry?;
            let path = entry.path();
            
            if path.extension() == Some(std::ffi::OsStr::new("meta")) {
                let cache_key = self.extract_cache_key_from_path(&path)?;
                let metadata = self.load_metadata_new(&cache_key).await?;
                
                // Add each range as a candidate
                for range in &metadata.ranges {
                    let score = self.calculate_eviction_score(range);
                    
                    candidates.push(EvictionCandidate {
                        cache_key: cache_key.clone(),
                        start: range.start,
                        end: range.end,
                        eviction_score: score,
                        size_bytes: range.uncompressed_size,
                        last_accessed: range.last_accessed,
                        access_count: range.access_count,
                    });
                }
            }
        }
        
        Ok(candidates)
    }
    
    /// Calculate eviction score for a range
    fn calculate_eviction_score(&self, range: &RangeSpec) -> u64 {
        match self.eviction_algorithm {
            CacheEvictionAlgorithm::LRU => range.lru_score(),
            CacheEvictionAlgorithm::TinyLFU => range.tinylfu_score(),
        }
    }
    
    /// Evict a single range
    async fn evict_range(
        &self,
        cache_key: &str,
        start: u64,
        end: u64,
    ) -> Result<()> {
        let metadata_path = self.get_new_metadata_file_path(cache_key);
        let lock_path = metadata_path.with_extension("meta.lock");
        
        // Acquire exclusive lock
        let lock_file = std::fs::OpenOptions::new()
            .create(true)
            .write(true)
            .open(&lock_path)?;
        lock_file.lock_exclusive()?;
        
        // Read metadata
        let mut metadata = self.load_metadata_new(cache_key).await?;
        
        // Find the range to evict
        if let Some(range) = metadata.ranges.iter()
            .find(|r| r.start == start && r.end == end)
        {
            // Delete .bin file
            let range_path = self.cache_dir.join("ranges").join(&range.file_path);
            if range_path.exists() {
                std::fs::remove_file(&range_path)?;
            }
        }
        
        // Remove range from metadata
        metadata.ranges.retain(|r| !(r.start == start && r.end == end));
        
        if metadata.ranges.is_empty() {
            // No ranges left, delete metadata file
            std::fs::remove_file(&metadata_path)?;
        } else {
            // Update metadata
            let json = serde_json::to_string_pretty(&metadata)?;
            std::fs::write(&metadata_path, json)?;
        }
        
        // Release lock
        lock_file.unlock()?;
        
        Ok(())
    }
}

/// Eviction candidate (per-range)
struct EvictionCandidate {
    cache_key: String,
    start: u64,
    end: u64,
    eviction_score: u64,
    size_bytes: u64,
    last_accessed: SystemTime,
    access_count: u64,
}
```

### 5. Stale Data Removal

**Location**: `src/disk_cache.rs`

```rust
impl DiskCacheManager {
    /// Delete a stale range (known to be invalid)
    pub async fn delete_stale_range(
        &mut self,
        cache_key: &str,
        start: u64,
        end: u64,
        reason: &str,
    ) -> Result<()> {
        let metadata_path = self.get_new_metadata_file_path(cache_key);
        let lock_path = metadata_path.with_extension("meta.lock");
        
        info!(
            "Deleting stale range: key={}, range={}-{}, reason={}",
            cache_key, start, end, reason
        );
        
        // Acquire exclusive lock
        let lock_file = std::fs::OpenOptions::new()
            .create(true)
            .write(true)
            .open(&lock_path)?;
        lock_file.lock_exclusive()?;
        
        // Read metadata
        let mut metadata = self.load_metadata_new(cache_key).await?;
        
        // Find and delete the range
        if let Some(range) = metadata.ranges.iter()
            .find(|r| r.start == start && r.end == end)
        {
            // Delete .bin file
            let range_path = self.cache_dir.join("ranges").join(&range.file_path);
            if range_path.exists() {
                std::fs::remove_file(&range_path)?;
            }
        }
        
        // Remove range from metadata
        metadata.ranges.retain(|r| !(r.start == start && r.end == end));
        
        if metadata.ranges.is_empty() {
            // No ranges left, delete metadata file
            std::fs::remove_file(&metadata_path)?;
        } else {
            // Update metadata
            let json = serde_json::to_string_pretty(&metadata)?;
            std::fs::write(&metadata_path, json)?;
        }
        
        // Release lock
        lock_file.unlock()?;
        
        Ok(())
    }
    
    /// Delete all ranges for an object (e.g., on PUT conflict)
    pub async fn delete_all_ranges(
        &mut self,
        cache_key: &str,
        reason: &str,
    ) -> Result<()> {
        info!(
            "Deleting all ranges for object: key={}, reason={}",
            cache_key, reason
        );
        
        let metadata_path = self.get_new_metadata_file_path(cache_key);
        
        if !metadata_path.exists() {
            return Ok(()); // Nothing to delete
        }
        
        // Load metadata to get range files
        let metadata = self.load_metadata_new(cache_key).await?;
        
        // Delete all .bin files
        for range in &metadata.ranges {
            let range_path = self.cache_dir.join("ranges").join(&range.file_path);
            if range_path.exists() {
                std::fs::remove_file(&range_path)?;
            }
        }
        
        // Delete metadata file
        std::fs::remove_file(&metadata_path)?;
        
        Ok(())
    }
}
```

### 6. Integration with Cache Operations

**On Cache Read**:
```rust
// Async update (don't block response)
tokio::spawn({
    let cache_mgr = self.clone();
    let key = cache_key.to_string();
    let (start, end) = (range_start, range_end);
    async move {
        let _ = cache_mgr.update_range_access(&key, start, end).await;
    }
});
```

**On Cache Write**:
```rust
// Check capacity and evict if needed
self.evict_if_needed(data.len() as u64).await?;

// Store range with initial access statistics
let range_spec = RangeSpec {
    start,
    end,
    file_path,
    compression_algorithm,
    compressed_size,
    uncompressed_size,
    created_at: SystemTime::now(),
    last_accessed: SystemTime::now(),
    access_count: 1,
    expires_at: SystemTime::now() + get_ttl,
};
```

**On Cache Lookup (Expired Range Detected)**:
```rust
// Range is expired - perform conditional validation with S3
let response = s3_client.get_object_conditional(
    bucket, key, 
    Some(range.last_modified),  // If-Modified-Since
    start, end
).await?;

match response.status() {
    StatusCode::NOT_MODIFIED => {
        // Object hasn't changed - refresh TTL and serve from cache
        self.refresh_range_ttl(cache_key, start, end, get_ttl).await?;
        // Serve cached data
    }
    StatusCode::OK => {
        // Object changed - data is stale, remove invalidated range
        self.remove_invalidated_range(cache_key, start, end).await?;
        // Forward original request to S3 to fetch and cache new data
    }
    _ => {
        // Validation failed or unexpected status - remove expired range and forward to S3
        warn!("Conditional validation failed, forwarding to S3");
        self.remove_invalidated_range(cache_key, start, end).await?;
        // Forward original request to S3 and cache response if successful
    }
}
```

**On Cache Lookup (Non-Expired Range)**:
```rust
// Range is still valid - just update access stats and serve
self.update_range_access(cache_key, start, end).await?;
// Serve cached data
```

**On ETag Mismatch**:
```rust
// Cached range has wrong ETag - actively remove stale data
self.delete_stale_range(cache_key, start, end, "ETag mismatch").await?;
```

## Data Models

### Enhanced RangeSpec

```rust
pub struct RangeSpec {
    // Range identification
    pub start: u64,
    pub end: u64,
    pub file_path: String,
    
    // Compression
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
    
    // Per-range TTL and access tracking
    pub created_at: SystemTime,
    pub last_accessed: SystemTime,
    pub access_count: u64,
    pub expires_at: SystemTime,
}
```

**Storage**: Embedded in `objects/{key}.meta` file

**Size Impact**: +64 bytes per range (~4 SystemTime fields + u64)

**Metadata File Size**: 
- 10 ranges: ~2KB (was ~1.5KB)
- 100 ranges: ~15KB (was ~10KB)
- Still well under 100KB limit

### NewCacheMetadata (Updated)

```rust
pub struct NewCacheMetadata {
    pub cache_key: String,
    pub object_metadata: ObjectMetadata,
    pub ranges: Vec<RangeSpec>,  // Each with own TTL
    pub created_at: SystemTime,
    // No object-level expires_at
    pub compression_info: CompressionInfo,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do.*

### Property 1: Per-range TTL independence

*For any* object with multiple cached ranges, updating the TTL of one range SHALL NOT affect the TTL of other ranges.

**Validates: Requirements 1.1, 1.2, 1.3**

### Property 2: Eviction respects algorithm

*For any* eviction operation, the ranges selected for eviction SHALL have lower eviction scores than ranges that remain cached.

**Validates: Requirements 2.1, 2.2, 2.3**

### Property 3: Eviction triggers and frees buffer space

*For any* cache state at or above 95% capacity, eviction SHALL be triggered and reduce cache size to at most 90% of max capacity.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4**

### Property 4: Metadata updates are atomic

*For any* metadata update operation, either all changes are visible or none are visible (no partial updates).

**Validates: Requirements 4.1, 4.2, 4.4**

### Property 5: Only one instance evicts

*For any* multi-instance deployment, at most one instance SHALL hold the global eviction lock at any time.

**Validates: Requirements 5.1, 5.2, 5.3**

### Property 5a: Active eviction keeps lock fresh

*For any* instance performing eviction, the global eviction lock SHALL be refreshed periodically to prevent it from becoming stale.

**Validates: Requirements 5.4**

### Property 6: Expired ranges removed independently

*For any* range that expires, only that range SHALL be removed without affecting non-expired ranges.

**Validates: Requirements 1.4**

### Property 7: Conditional validation refreshes specific range

*For any* 304 Not Modified response for a range request, only that specific range's TTL SHALL be refreshed.

**Validates: Requirements 6.1**

### Property 8: Stale data is actively removed

*For any* range detected as stale (ETag mismatch, PUT conflict, validation returns new data), that range SHALL be immediately deleted from cache.

**Validates: Requirements 10.1, 10.2, 10.4**

## Error Handling

### Corrupted Range Metadata

**Scenario**: Range in metadata has invalid timestamps or counts.

**Handling**: Use default values (created_at from file mtime, access_count=1). Log warning.

### Lock Timeout

**Scenario**: Metadata lock held longer than timeout (60s).

**Handling**: Break lock, log warning with previous holder info, proceed with operation.

### Stale Eviction Lock

**Scenario**: Global eviction lock exists but hasn't been refreshed in >60 seconds (crashed/hung process).

**Handling**: Break stale lock, log warning with previous holder info, acquire lock and proceed with eviction.

### Insufficient Space After Eviction

**Scenario**: Evicted all possible ranges but still not enough space.

**Handling**: Return error, bypass caching for new data, log warning.

### Concurrent Metadata Updates

**Scenario**: Two instances try to update same metadata simultaneously.

**Handling**: File lock ensures serialization. Second instance waits for lock.

## Testing Strategy

### Unit Tests

1. **RangeSpec Methods**:
   - Test is_expired() with various timestamps
   - Test lru_score(), tinylfu_score()
   - Test refresh_ttl() updates expires_at
   - Test record_access() updates last_accessed and access_count

2. **Metadata Locking**:
   - Test lock acquisition blocks concurrent access
   - Test lock release allows next access
   - Test stale lock is broken

3. **Eviction Trigger and Buffer**:
   - Test eviction triggers at 95% capacity
   - Test eviction targets 90% of capacity
   - Test eviction stops when target reached
   - Test eviction frees at least 5%
   - Test no eviction when below 95% capacity

### Property-Based Tests

Using `quickcheck` with minimum 100 iterations:

1. **Property 1: Per-range TTL independence**
   - Generate random objects with multiple ranges
   - Update TTL on one range
   - Verify other ranges unchanged
   - **Feature: unified-cache-eviction-ttl, Property 1**

2. **Property 2: Eviction respects algorithm**
   - Generate random ranges with access statistics
   - Perform eviction
   - Verify evicted ranges have lower scores
   - **Feature: unified-cache-eviction-ttl, Property 2**

3. **Property 3: Eviction triggers and frees buffer space**
   - Generate cache at 95% capacity
   - Add data that would exceed 95%
   - Verify eviction is triggered
   - Verify size ≤ 90% of capacity after eviction
   - **Feature: unified-cache-eviction-ttl, Property 3**

4. **Property 6: Expired ranges removed independently**
   - Generate object with mixed expired/valid ranges
   - Remove expired ranges
   - Verify valid ranges remain
   - **Feature: unified-cache-eviction-ttl, Property 6**

### Integration Tests

1. **Hot/Cold Range Separation**:
   - Cache large object (100 ranges)
   - Access only 10 ranges repeatedly
   - Wait for TTL expiration
   - Verify only hot ranges remain

2. **Multi-Instance Eviction**:
   - Two instances share cache
   - Both reach capacity
   - Verify only one performs eviction
   - Verify lock coordination

3. **Eviction Under Load**:
   - Continuous cache writes
   - Verify eviction triggers at 95% capacity
   - Verify eviction maintains cache between 90-95% capacity
   - Verify no corruption

## Implementation Notes

### Performance Considerations

**Metadata Updates**:
- In-place editing: ~2-5ms per update
- File locking overhead: ~0.1-0.5ms
- No fsync: Acceptable risk for access stats
- Async updates: Don't block cache reads

**Eviction Scan**:
- Per-range scanning: More candidates but same I/O
- 10,000 ranges: ~1-2 seconds to scan
- Trigger at 95%, target 90%: 5% buffer reduces scan frequency by 20x
- Always have space available for new data (never hit 100%)

**Lock Contention**:
- Metadata locks: Per-object, minimal contention
- Global eviction lock: Rare (only when at capacity)

### Backward Compatibility

**Migration**:
- Old metadata without per-range fields: Add defaults on first read
- created_at: Use file mtime
- last_accessed: Use current time
- access_count: 1
- expires_at: created_at + GET_TTL

**Graceful Degradation**:
- Missing fields: Use defaults
- Corrupted timestamps: Use current time
- Invalid access_count: Use 1

### Configuration

```yaml
cache:
  eviction_algorithm: "lru"  # or "tinylfu"
  eviction_trigger_percent: 95  # Trigger eviction at 95% capacity
  eviction_target_percent: 90   # Evict to 90% capacity (5% buffer)
  distributed_eviction:
    enabled: true
    lock_timeout_seconds: 60  # Lock is stale if not refreshed within this time
    lock_refresh_interval_seconds: 30  # How often to refresh lock during eviction
  metadata_lock_timeout_seconds: 60  # NEW
```
