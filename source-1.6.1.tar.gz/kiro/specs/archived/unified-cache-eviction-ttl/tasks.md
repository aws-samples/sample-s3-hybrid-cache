# Implementation Plan

- [x] 1. Remove LFU algorithm from codebase and documentation. Careful not to impact connection pooling, only cache eviction.
  - Remove LFU enum variant from CacheEvictionAlgorithm
  - Remove lfu_score() method implementations
  - Remove LFU references from configuration parsing
  - Remove LFU references from documentation (docs/CACHING.md, README.md, config examples)
  - Update tests to remove LFU test cases
  - _Requirements: 2.1, 2.2, 2.3_

- [x] 2. Add per-range TTL and access tracking to RangeSpec
  - Add created_at, last_accessed, access_count, expires_at fields to RangeSpec in cache_types.rs
  - Implement is_expired() method
  - Implement lru_score() method
  - Implement tinylfu_score() method
  - Implement refresh_ttl() method
  - Implement record_access() method
  - Remove object-level expires_at from NewCacheMetadata
  - _Requirements: 1.1_

- [x] 3. Implement metadata update operations with file locking
  - Implement update_range_access() in DiskCacheManager with exclusive file locking
  - Implement refresh_range_ttl() in DiskCacheManager
  - Implement remove_invalidated_range() for lazy expiration
  - Use in-place editing for metadata updates (no fsync for performance)
  - Add lock timeout handling (60s default)
  - _Requirements: 1.2, 1.3, 4.1, 4.2, 4.3, 4.4, 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 4. Implement global eviction lock with heartbeat mechanism
  - Implement acquire_global_eviction_lock() with timestamp + instance ID
  - Implement is_eviction_lock_stale() to check lock age (>60s)
  - Implement refresh_global_eviction_lock() to update timestamp
  - Implement release_global_eviction_lock()
  - Add configuration for lock_timeout_seconds and lock_refresh_interval_seconds
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6_

- [x] 5. Implement eviction with 5% buffer
  - Implement evict_if_needed() to check capacity and trigger eviction
  - Calculate target size as 95% of max capacity
  - Implement perform_eviction() with lock acquisition and background refresh task
  - Spawn background task to refresh eviction lock every 30 seconds
  - Implement scan_all_ranges() to collect eviction candidates
  - Implement calculate_eviction_score() using configured algorithm (LRU/TinyLFU)
  - Sort candidates by eviction score (lowest first)
  - Implement evict_range() to remove individual ranges
  - Stop lock refresh task when eviction completes
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 3.1, 3.2, 3.3, 3.4, 3.5_

- [x] 6. Implement stale data removal operations
  - Implement delete_stale_range() for known invalid data (ETag mismatch, validation failure)
  - Implement delete_all_ranges() for PUT conflicts
  - Add logging for all stale data removal operations
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [x] 7. Integrate per-range TTL with cache operations
  - Update cache write to initialize range with access statistics and TTL
  - Update cache read to spawn async task for update_range_access()
  - Implement lazy expiration on cache lookup (check is_expired())
  - Implement conditional validation with If-Modified-Since for expired ranges
  - Handle 304 Not Modified: refresh TTL and serve from cache
  - Handle 200 OK: remove invalidated range and forward to S3 to cache new data
  - Handle validation failure or unexpected status: remove invalidated range and forward original request to S3
  - Call evict_if_needed() before caching new data
  - _Requirements: 1.4, 1.5, 1.6, 1.7, 6.1, 6.4, 6.5_

- [x] 8. Implement comprehensive logging for eviction and TTL operations
  - Log eviction trigger with reason, current size, target size
  - Log each range eviction with cache key, range boundaries, eviction score, size
  - Log eviction completion with count and space freed
  - Log TTL refresh with cache key, range boundaries, new expiration
  - Log range expiration with cache key, range boundaries, reason
  - Log stale data removal with cache key, range boundaries, reason
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 9. Handle edge cases and error conditions
  - Handle corrupted range metadata with default statistics
  - Handle insufficient space after eviction (bypass caching)
  - Handle metadata lock timeout (break lock after 60s)
  - Handle stale eviction lock (break if >60s old)
  - Ensure .bin file deletion when range is deleted
  - Ensure .meta file deletion when last range is deleted
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 10. Update configuration system
  - Add eviction_buffer_percent configuration (default 5)
  - Add distributed_eviction.lock_timeout_seconds (default 60)
  - Add distributed_eviction.lock_refresh_interval_seconds (default 30)
  - Add metadata_lock_timeout_seconds (default 60)
  - Update config.example.yaml with new settings
  - _Requirements: 3.1, 5.4, 5.5_

- [x] 11. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 12. Tidy and optimize test suite
  - Review all test files for redundant or duplicate tests
  - Consolidate similar test cases where appropriate
  - Remove unnecessary test setup/teardown code
  - Optimize slow-running tests by reducing iteration counts or data sizes where safe
  - Ensure test names are clear and descriptive
  - Add missing test documentation/comments where needed
  - Verify all tests use proper cleanup (temp directories, cache files)
  - Check for and remove any disabled/commented-out tests
  - Ensure consistent test structure and patterns across the suite
  - _Requirements: All (test quality and maintainability)_
