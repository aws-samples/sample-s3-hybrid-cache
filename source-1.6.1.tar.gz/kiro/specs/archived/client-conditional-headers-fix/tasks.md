# Implementation Plan

- [x] 1. Update ConditionalResult enum in range_handler.rs
  - Remove `PreconditionFailed` variant from enum
  - Update all match statements that reference this variant
  - _Requirements: 5.1, 5.3_

- [x] 2. Remove conditional validation logic (OBSOLETE - new approach)
  - This task is no longer needed with the new always-forward approach
  - _Requirements: N/A_

- [x] 3. Remove immediate 412 response in http_proxy.rs
  - Remove `ConditionalResult::PreconditionFailed` match arm
  - Remove call to `handle_precondition_failed()` that invalidates cache
  - Allow conditional requests to proceed to normal flow (serve from cache or forward to S3)
  - _Requirements: 6.3_

- [x] 4. Implement conditional request detection in http_proxy.rs
  - Add function to detect any conditional headers (If-Match, If-None-Match, If-Modified-Since, If-Unmodified-Since)
  - Modify handle_get_head_request to always forward conditional requests to S3
  - Remove all conditional validation logic from proxy
  - _Requirements: 1.1, 2.1, 3.1, 4.1, 5.1, 5.2, 5.3_

- [x] 5. Update S3 response handling for conditional requests
  - When S3 returns 412: Return to client, do NOT invalidate cache
  - When S3 returns 200: Return to client, invalidate old cache, cache new data
  - When S3 returns 304: Return to client, refresh TTL
  - _Requirements: 1.2, 1.3, 2.2, 2.3, 3.2, 3.3, 3.4, 4.2, 4.3, 4.4, 6.1, 6.2, 6.3_

- [x] 6. Remove ConditionalResult enum and validation functions
  - Remove ConditionalResult enum entirely from range_handler.rs
  - Remove validate_conditional_headers() function
  - Remove extract_conditional_headers() function
  - Update all references to use direct S3 forwarding
  - _Requirements: 5.3_

- [x] 7. Add logging for conditional request handling
  - Log when any conditional request is forwarded to S3
  - Log S3 response status for forwarded conditional requests
  - Log cache invalidation when S3 returns new data
  - Log TTL refresh when S3 returns 304
  - _Requirements: 8.1, 8.2, 8.3, 8.4_

- [ ]* 8. Write unit tests for conditional request detection
  - Test detection of If-Match header
  - Test detection of If-None-Match header
  - Test detection of If-Modified-Since header
  - Test detection of If-Unmodified-Since header
  - Test detection of multiple conditional headers
  - Test non-conditional requests are not detected
  - _Requirements: 5.1, 5.2_

- [ ]* 9. Write integration test for If-Match always forwarded
  - Setup: Cache object with ETag "v2"
  - Request: GET with If-Match: "v1"
  - Mock S3: Returns 412 Precondition Failed
  - Verify: Request forwarded to S3, client receives 412, cache NOT invalidated
  - _Requirements: 3.1, 3.4, 6.3_

- [ ]* 10. Write integration test for If-None-Match always forwarded
  - Setup: Cache object with ETag "v1"
  - Request: GET with If-None-Match: "v1"
  - Mock S3: Returns 304 Not Modified
  - Verify: Request forwarded to S3, client receives 304, cache TTL refreshed
  - _Requirements: 1.1, 1.2, 6.2_

- [ ]* 11. Write integration test for If-Modified-Since always forwarded
  - Setup: Cache object with Last-Modified "2024-01-01"
  - Request: GET with If-Modified-Since: "2024-01-02"
  - Mock S3: Returns 304 Not Modified
  - Verify: Request forwarded to S3, client receives 304, cache TTL refreshed
  - _Requirements: 2.1, 2.2, 6.2_

- [ ]* 12. Write integration test for If-Unmodified-Since always forwarded
  - Setup: Cache object with Last-Modified "2024-01-01"
  - Request: GET with If-Unmodified-Since: "2023-12-01"
  - Mock S3: Returns 412 Precondition Failed
  - Verify: Request forwarded to S3, client receives 412, cache NOT invalidated
  - _Requirements: 4.1, 4.4, 6.3_

- [ ]* 13. Write integration test for S3 200 response handling
  - Setup: Cache object with ETag "v1"
  - Request: GET with If-Match: "v1"
  - Mock S3: Object changed to ETag "v2", returns 200 OK
  - Verify: Client receives new data, old cache invalidated, new data cached
  - _Requirements: 3.2, 6.1_

- [ ]* 14. Write property test for always forward conditional requests
  - **Property 1: Always forward conditional requests**
  - **Validates: Requirements 1.1, 2.1, 3.1, 4.1, 5.1**

- [ ]* 15. Write property test for cache management based on S3 response
  - **Property 2: Cache management based on S3 response**
  - **Validates: Requirements 6.1, 6.2, 6.3**

- [ ]* 16. Write property test for no conditional decisions in proxy
  - **Property 3: No conditional decisions in proxy**
  - **Validates: Requirements 5.3**

- [ ]* 17. Write property test for S3 response preservation
  - **Property 4: S3 response preservation**
  - **Validates: Requirements 1.2, 1.3, 2.2, 2.3, 3.2, 3.3, 3.4, 4.2, 4.3, 4.4**

- [x] 18. Update documentation
  - Update docs/CACHING.md to describe new always-forward approach for conditional requests
  - Document that proxy never makes conditional decisions, always defers to S3
  - Add note about bug fix in CHANGELOG if exists
  - _Requirements: All_

- [x] 19. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.


- [x] 20. Create user test script
  - Create a script that tests the proxy with various Get, Put, Head, Copy, scenarios including conditional requests.
  - Use aws s3, aws s3api, and boto3 to interact with S3. Not curl (it's unauthenticated).
  - output results to a file. Include in that file suitable prompt information so that Kiro can parse it, report on the results, and address any errors
  - prompt the user for bucket and optional prefix to use. Assume the user environment has read+write permissions to access the bucket and prefix.

- [ ] 21. Tidy repository
  - Archive spec docs and any summary
  - Remove unused files
