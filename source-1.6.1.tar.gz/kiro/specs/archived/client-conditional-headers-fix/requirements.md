# Requirements Document

## Introduction

Fix incorrect handling of client-provided conditional headers (If-Match, If-None-Match, If-Modified-Since, If-Unmodified-Since) in the S3 proxy. Currently, the proxy attempts to make conditional decisions based on cached metadata, which can lead to incorrect responses and improper cache management.

The correct behavior is to always forward ALL conditional requests to S3 and let S3 make the authoritative decision about whether conditions are met. The proxy should then manage cache state based solely on S3's response, ensuring perfect HTTP compliance and eliminating edge cases.

## Glossary

- **Proxy**: The S3 caching proxy system
- **Client**: Application making HTTP requests through the proxy
- **S3**: Amazon S3 backend storage service
- **Conditional Headers**: HTTP headers (If-Match, If-None-Match, If-Modified-Since, If-Unmodified-Since) used for cache validation
- **ETag**: Entity tag uniquely identifying a specific version of a resource
- **Cache Invalidation**: Removing stale data from the proxy's cache

## Requirements

### Requirement 1: If-None-Match Handling (Always Forward)

**User Story:** As a client, I want the proxy to forward my If-None-Match conditional request to S3, so that S3 can make the authoritative decision about whether the condition is met.

#### Acceptance Criteria

1.1. WHEN a client sends If-None-Match header, THEN the Proxy SHALL always forward the request to S3 with the client's If-None-Match header

1.2. WHEN S3 returns 304 Not Modified for an If-None-Match request, THEN the Proxy SHALL return 304 to the client and refresh the cached entry's TTL

1.3. WHEN S3 returns 200 OK with data for an If-None-Match request, THEN the Proxy SHALL return the data to the client, invalidate old cached data, and cache the new data

### Requirement 2: If-Modified-Since Handling (Always Forward)

**User Story:** As a client, I want the proxy to forward my If-Modified-Since conditional request to S3, so that S3 can make the authoritative decision about whether the condition is met.

#### Acceptance Criteria

2.1. WHEN a client sends If-Modified-Since header, THEN the Proxy SHALL always forward the request to S3 with the client's If-Modified-Since header

2.2. WHEN S3 returns 304 Not Modified for an If-Modified-Since request, THEN the Proxy SHALL return 304 to the client and refresh the cached entry's TTL

2.3. WHEN S3 returns 200 OK with data for an If-Modified-Since request, THEN the Proxy SHALL return the data to the client, invalidate old cached data, and cache the new data

### Requirement 3: If-Match Handling (Always Forward)

**User Story:** As a client, I want the proxy to forward my If-Match conditional request to S3, so that S3 can make the authoritative decision about whether the condition is met.

#### Acceptance Criteria

3.1. WHEN a client sends If-Match header, THEN the Proxy SHALL always forward the request to S3 with the client's If-Match header

3.2. WHEN S3 returns 200 OK with data for an If-Match request, THEN the Proxy SHALL return the data to the client, invalidate old cached data, and cache the new data

3.3. WHEN S3 returns 304 Not Modified for an If-Match request, THEN the Proxy SHALL return 304 to the client and refresh the cached entry's TTL

3.4. WHEN S3 returns 412 Precondition Failed for an If-Match request, THEN the Proxy SHALL return 412 to the client WITHOUT invalidating the cache

### Requirement 4: If-Unmodified-Since Handling (Always Forward)

**User Story:** As a client, I want the proxy to forward my If-Unmodified-Since conditional request to S3, so that S3 can make the authoritative decision about whether the condition is met.

#### Acceptance Criteria

4.1. WHEN a client sends If-Unmodified-Since header, THEN the Proxy SHALL always forward the request to S3 with the client's If-Unmodified-Since header

4.2. WHEN S3 returns 200 OK with data for an If-Unmodified-Since request, THEN the Proxy SHALL return the data to the client, invalidate old cached data, and cache the new data

4.3. WHEN S3 returns 304 Not Modified for an If-Unmodified-Since request, THEN the Proxy SHALL return 304 to the client and refresh the cached entry's TTL

4.4. WHEN S3 returns 412 Precondition Failed for an If-Unmodified-Since request, THEN the Proxy SHALL return 412 to the client WITHOUT invalidating the cache

### Requirement 5: Universal Conditional Request Handling

**User Story:** As a system operator, I want the proxy to handle all conditional requests consistently by always deferring to S3's authoritative decisions, so that HTTP semantics are perfectly preserved.

#### Acceptance Criteria

5.1. WHEN a client sends ANY conditional header (If-Match, If-None-Match, If-Modified-Since, If-Unmodified-Since), THEN the Proxy SHALL always forward the request to S3 with ALL client headers

5.2. WHEN a client sends multiple conditional headers, THEN the Proxy SHALL forward all headers to S3 and let S3 determine the appropriate response according to HTTP semantics

5.3. WHEN the Proxy receives any conditional request, THEN the Proxy SHALL NOT make any conditional decisions based on cached metadata

### Requirement 6: Cache Management Based on S3 Response

**User Story:** As a system operator, I want the proxy to manage cache state based solely on S3's authoritative responses, so that cache consistency is guaranteed.

#### Acceptance Criteria

6.1. WHEN S3 returns 200 OK with new data in response to any conditional request, THEN the Proxy SHALL invalidate old cached data and cache the new data

6.2. WHEN S3 returns 304 Not Modified in response to any conditional request, THEN the Proxy SHALL refresh the cached entry's TTL and NOT invalidate the cache

6.3. WHEN S3 returns 412 Precondition Failed in response to any conditional request, THEN the Proxy SHALL NOT invalidate or modify the cached data

6.4. WHEN the Proxy receives any client conditional header, THEN the Proxy SHALL NOT invalidate cache based solely on the client's header values

### Requirement 7: Non-Conditional Request Handling

**User Story:** As a client, I want the proxy to serve non-conditional requests from cache when possible, so that I get fast responses for normal requests.

#### Acceptance Criteria

7.1. WHEN a client sends a request WITHOUT any conditional headers, THEN the Proxy SHALL check cache first and serve from cache if available and not expired

7.2. WHEN a client sends a request WITHOUT any conditional headers AND cache is expired or missing, THEN the Proxy SHALL forward to S3 and cache the response

### Requirement 8: Logging and Observability

**User Story:** As a system operator, I want detailed logging of conditional request handling, so that I can debug cache behavior and understand client-proxy-S3 interactions.

#### Acceptance Criteria

8.1. WHEN a client sends any conditional header, THEN the Proxy SHALL log that the request is being forwarded to S3 with the conditional headers

8.2. WHEN S3 responds to a forwarded conditional request, THEN the Proxy SHALL log the S3 response status and any cache actions taken

8.3. WHEN cache is invalidated due to S3 returning new data, THEN the Proxy SHALL log the cache invalidation with the cache key and reason

8.4. WHEN cache TTL is refreshed due to S3 returning 304, THEN the Proxy SHALL log the TTL refresh action
