# Design Document

## Overview

This design fixes the incorrect handling of client conditional headers (If-Match, If-None-Match, If-Modified-Since, If-Unmodified-Since) in the S3 proxy. The current implementation attempts to make conditional decisions based on cached metadata, which can lead to incorrect responses and improper cache management.

The correct behavior is to always forward ALL conditional requests to S3 and let S3 make the authoritative decision about whether conditions are met. The proxy should then manage cache state based solely on S3's response, ensuring perfect HTTP compliance and eliminating edge cases.

## Architecture

### Current (Incorrect) Flow

```
Client sends If-Match: "old-etag"
Cached ETag: "current-etag"
  ↓
Proxy compares headers and makes decision
  ↓
Proxy returns response based on cache comparison ❌ WRONG
```

### New (Correct) Flow

```
Client sends ANY conditional header
  ↓
Proxy always forwards to S3 with ALL client headers
  ↓
S3 makes authoritative decision and responds:
  - 200: Return to client, invalidate old cache, cache new data ✓
  - 304: Return to client, refresh cache TTL ✓
  - 412: Return to client, keep cache unchanged ✓
```

## Components and Interfaces

### Modified Components

1. **RangeHandler::validate_conditional_headers()**
   - Current: Makes conditional decisions based on cached metadata
   - New: Removed entirely - no conditional validation in proxy
   - All conditional requests are forwarded to S3

2. **HttpProxy::handle_range_request() and handle_get_head_request()**
   - Current: Uses conditional validation to make cache decisions
   - New: Detects any conditional headers and always forwards to S3
   - No conditional logic - just forward and respond to S3's answer

### Data Flow

```
┌────────┐                    ┌───────┐                    ┌────┐
│ Client │                    │ Proxy │                    │ S3 │
└───┬────┘                    └───┬───┘                    └─┬──┘
    │                             │                          │
    │ GET /obj                    │                          │
    │ If-Match: "old"             │                          │
    ├────────────────────────────>│                          │
    │                             │                          │
    │                             │ Check cache              │
    │                             │ ETag: "current"          │
    │                             │                          │
    │                             │ Mismatch detected        │
    │                             │ Forward to S3            │
    │                             ├─────────────────────────>│
    │                             │ If-Match: "old"          │
    │                             │                          │
    │                             │<─────────────────────────┤
    │                             │ 412 Precondition Failed  │
    │                             │                          │
    │                             │ Keep cache (no invalidate)
    │<────────────────────────────┤                          │
    │ 412 Precondition Failed     │                          │
    │                             │                          │
```

## Data Models

### ConditionalResult Enum

```rust
// ConditionalResult enum is no longer needed
// All conditional requests are forwarded to S3
// No conditional validation logic in proxy
```

**Change**: Remove the entire ConditionalResult enum and all conditional validation logic since we always forward to S3.

### Request Detection

The proxy will detect conditional requests by checking for the presence of any conditional headers:
- If-Match
- If-None-Match  
- If-Modified-Since
- If-Unmodified-Since

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Always forward conditional requests
*For any* client request containing conditional headers, proxy SHALL always forward the request to S3 with all client headers, regardless of cached metadata.

**Validates: Requirements 1.1, 2.1, 3.1, 4.1, 5.1**

### Property 2: Cache management based on S3 response
*For any* conditional request, cache SHALL only be modified based on S3's response: 200→invalidate and cache new data, 304→refresh TTL, 412→no change.

**Validates: Requirements 6.1, 6.2, 6.3**

### Property 3: No conditional decisions in proxy
*For any* conditional request, proxy SHALL NOT make conditional decisions based on cached metadata comparison.

**Validates: Requirements 5.3**

### Property 4: S3 response preservation
*For any* conditional request, proxy SHALL return S3's exact response status and headers to the client.

**Validates: Requirements 1.2, 1.3, 2.2, 2.3, 3.2, 3.3, 3.4, 4.2, 4.3, 4.4**

## Error Handling

### S3 Response Handling

| S3 Status | Action | Cache Invalidation |
|-----------|--------|-------------------|
| 200 OK | Return data to client, cache new data | Yes - old data invalidated |
| 304 Not Modified | Return 304 to client, refresh TTL | No |
| 412 Precondition Failed | Return 412 to client | No |
| 4xx/5xx | Return error to client | No |

### Edge Cases

1. **Cache miss with conditional headers**: Forward to S3 with client's headers, cache response if 200 OK
2. **Multiple conditional headers**: Follow HTTP semantics - If-Match takes precedence over If-Unmodified-Since
3. **Malformed conditional headers**: Forward to S3, let S3 handle validation

## Testing Strategy

### Unit Tests

1. Test `validate_conditional_headers()` returns correct `ConditionalResult` for each header combination
2. Test cache invalidation only occurs when S3 returns 200 OK
3. Test 304 optimization still works for If-None-Match and If-Modified-Since

### Property-Based Tests

Each correctness property will be implemented as a property-based test using the testing framework specified in the project (quickcheck or similar).

**Property Test Configuration:**
- Minimum 100 iterations per property test
- Each test tagged with: `**Feature: client-conditional-headers-fix, Property {number}: {property_text}**`

### Integration Tests

1. **Test If-Match mismatch forwarding**:
   - Setup: Cache object with ETag "v2"
   - Request: GET with If-Match: "v1"
   - Verify: Request forwarded to S3, S3 returns 412, cache not invalidated

2. **Test If-Match mismatch with new data**:
   - Setup: Cache object with ETag "v1"
   - Request: GET with If-Match: "v1"
   - S3 has: ETag "v2" (object changed)
   - Verify: S3 returns 200, old cache invalidated, new data cached

3. **Test If-None-Match optimization**:
   - Setup: Cache object with ETag "v1"
   - Request: GET with If-None-Match: "v1"
   - Verify: 304 returned from cache, no S3 request

## Implementation Notes

### Code Changes Required

1. **src/range_handler.rs**:
   - Modify `validate_conditional_headers()` to return `Proceed` instead of `PreconditionFailed` for If-Match/If-Unmodified-Since mismatches
   - Remove `PreconditionFailed` variant from `ConditionalResult` enum

2. **src/http_proxy.rs**:
   - Remove the `ConditionalResult::PreconditionFailed` match arm that immediately returns 412
   - Remove call to `handle_precondition_failed()` that invalidates cache
   - Let conditional requests proceed to S3 forwarding logic
   - Handle S3 responses appropriately (412 → no invalidation, 200 → invalidate and cache)

3. **Logging**:
   - Add debug logs when forwarding conditional requests to S3
   - Add info logs when S3 confirms cache is stale (200 OK)
   - Add debug logs when S3 confirms cache is valid (412 or 304)

### Backward Compatibility

This is a bug fix that changes behavior. The new behavior is correct per HTTP semantics, but clients relying on the incorrect behavior (immediate 412 without S3 check) may see different responses.

**Impact**: Low - the new behavior is more correct and follows HTTP caching standards.

### Performance Considerations

- **Optimization preserved**: If-None-Match and If-Modified-Since still return 304 from cache without S3 request
- **Additional S3 requests**: If-Match and If-Unmodified-Since mismatches now forward to S3 (correct behavior)
- **Cache efficiency**: Improved - cache no longer incorrectly invalidated on client conditional header mismatches

## Alternatives Considered

### Alternative 1: Keep current behavior

**Rejected**: Current behavior is incorrect per HTTP semantics. Client conditional headers should not cause cache invalidation without S3 confirmation.

### Alternative 2: Always forward conditional requests to S3

**Rejected**: Would lose the optimization of returning 304 from cache for If-None-Match and If-Modified-Since matches.

### Alternative 3: Add configuration option

**Rejected**: There's only one correct behavior per HTTP standards. Configuration would add complexity without benefit.
