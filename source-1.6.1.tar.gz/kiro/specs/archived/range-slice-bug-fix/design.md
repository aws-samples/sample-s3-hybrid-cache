# Design Document

## Overview

This design addresses a critical bug in the multipart upload caching logic where HTTP framing data (54 extra bytes per part) is incorrectly included in cached part data. This causes range misalignment between what clients request and what is cached, leading to file corruption and AWS SDK errors.

### Root Cause

Testing revealed the bug originates in **multipart upload caching**, not range serving:

**Evidence:**
- GET requests: S3 returns part 1 as exactly 8,388,608 bytes (`0-8388607`) ✓ Correct
- PUT uploads: Proxy caches part 1 as 8,388,662 bytes (`0-8388661`) ✗ Bug - 54 extra bytes
- Result: When client requests `bytes=0-8388607`, cache contains `0-8388661`, causing misalignment

The 54 extra bytes appear to be HTTP framing data (headers, chunk encoding markers, or delimiters) that should be stripped before caching.

### Fix Strategy

1. **Primary Fix**: Modify multipart upload caching in `signed_put_handler.rs` to strip HTTP framing before storing part data
2. **Secondary Fix**: Add range slicing logic in `http_proxy.rs` as a defensive measure for any existing misaligned cached data

## Architecture

### Current Behavior (Buggy)

```
Client Request: bytes=0-8388607 (8388608 bytes)
Cached Range:   0-8388661 (8388662 bytes)
Current Return: 0-8388661 (8388662 bytes) ❌ WRONG - returns entire cached range
```

### Fixed Behavior

```
Client Request: bytes=0-8388607 (8388608 bytes)
Cached Range:   0-8388661 (8388662 bytes)
Fixed Return:   0-8388607 (8388608 bytes) ✓ CORRECT - slices to requested range
```

## Components and Interfaces

### Primary Affected Module: `src/signed_put_handler.rs`

The root cause is in the multipart upload part caching logic. The fix requires:

1. **HTTP Framing Detection**: Identify where HTTP framing data is being included in cached parts
2. **Data Stripping**: Remove all HTTP headers, chunk encoding markers, and delimiters before caching
3. **Byte Boundary Calculation**: Ensure cached ranges match S3's actual part boundaries (e.g., `0-8388607` for 8 MiB parts)
4. **Validation**: Verify cached part size matches expected size (8,388,608 bytes for 8 MiB parts)

### Secondary Affected Module: `src/http_proxy.rs`

As a defensive measure, add range slicing logic to handle any existing misaligned cached data:

1. **Range Slice Calculation**: Calculate the offset and length to extract from the cached range
2. **Data Extraction**: Slice the cached bytes to match the requested range exactly
3. **Header Correction**: Ensure Content-Length and Content-Range headers match the sliced data
4. **Logging Enhancement**: Add detailed logging of slicing operations

### Key Functions to Modify

#### `handle_get_request` or similar range serving function

Current problematic flow:
```rust
// Load cached range (e.g., 0-8388661)
let cached_data = disk_cache.load_range(cached_range)?;

// ❌ BUG: Returns entire cached_data without slicing
return Ok(Response::builder()
    .header("Content-Length", cached_data.len())
    .body(cached_data)?);
```

Fixed flow:
```rust
// Load cached range (e.g., 0-8388661)
let cached_data = disk_cache.load_range(cached_range)?;

// ✓ FIX: Calculate slice offset and length
let slice_start = requested_range.start - cached_range.start;
let slice_end = slice_start + (requested_range.end - requested_range.start + 1);

// ✓ FIX: Extract only the requested bytes
let sliced_data = cached_data[slice_start..slice_end].to_vec();

// ✓ FIX: Return sliced data with correct headers
return Ok(Response::builder()
    .header("Content-Length", sliced_data.len())
    .header("Content-Range", format!("bytes {}-{}/{}", 
        requested_range.start, requested_range.end, total_size))
    .body(sliced_data)?);
```

## Data Models

### Range Representation

```rust
struct ByteRange {
    start: u64,  // Inclusive start byte
    end: u64,    // Inclusive end byte
}

impl ByteRange {
    /// Calculate the number of bytes in this range
    fn len(&self) -> u64 {
        self.end - self.start + 1
    }
    
    /// Calculate the slice offset within a containing range
    fn slice_offset_in(&self, container: &ByteRange) -> u64 {
        self.start - container.start
    }
    
    /// Calculate the slice length to extract
    fn slice_length(&self) -> usize {
        (self.end - self.start + 1) as usize
    }
}
```

### Slice Calculation Examples

**Example 1: Start of cached range**
```
Requested: 0-8388607
Cached:    0-8388661
Offset:    0
Length:    8388608
Result:    cached_data[0..8388608]
```

**Example 2: Middle of cached range**
```
Requested: 100-200
Cached:    0-500
Offset:    100
Length:    101
Result:    cached_data[100..201]
```

**Example 3: End of cached range**
```
Requested: 8388600-8388661
Cached:    0-8388661
Offset:    8388600
Length:    62
Result:    cached_data[8388600..8388662]
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 0: Multipart part size correctness

*For any* multipart upload part of size N bytes, the cached range SHALL contain exactly N bytes without any HTTP framing overhead.

**Validates: Requirements 5.1, 5.2**

### Property 1: Exact byte count returned

*For any* client-requested byte range and any cached range that contains it, the number of bytes returned SHALL equal the number of bytes requested.

**Validates: Requirements 1.1, 1.2**

### Property 2: Content-Length header accuracy

*For any* range response, the Content-Length header value SHALL equal the actual number of bytes in the response body.

**Validates: Requirements 1.3**

### Property 3: Content-Range header accuracy

*For any* range response, the Content-Range header SHALL reflect the exact start and end bytes being returned, matching the requested range.

**Validates: Requirements 1.4**

### Property 4: Slice calculation correctness

*For any* requested range that is fully contained within a cached range, the slice offset SHALL equal (requested_start - cached_start) and the slice length SHALL equal (requested_end - requested_start + 1).

**Validates: Requirements 1.2, 1.5**

### Property 5: Identity property for exact matches

*For any* requested range that exactly matches a cached range, no slicing SHALL occur and the entire cached range SHALL be returned.

**Validates: Requirements 3.1**

### Property 6: Multiple range concatenation

*For any* request requiring multiple cached ranges, each cached range SHALL be sliced appropriately before concatenation, and the total bytes returned SHALL equal the requested byte count.

**Validates: Requirements 3.5**

### Property 7: Logging completeness

*For any* range serving operation involving slicing, the logs SHALL contain the requested range, cached range, slice offset, and slice length.

**Validates: Requirements 2.1, 2.2, 2.3**

### Property 8: Part boundary alignment

*For any* multipart upload with standard 8 MiB parts, part N SHALL be cached with range boundaries `(N-1)*8388608` to `N*8388608-1`.

**Validates: Requirements 5.3, 5.4, 5.5**

## Error Handling

### Slice Boundary Validation

```rust
fn validate_slice_bounds(
    requested: &ByteRange,
    cached: &ByteRange,
    cached_data_len: usize,
) -> Result<()> {
    // Ensure requested range is within cached range
    if requested.start < cached.start || requested.end > cached.end {
        return Err(ProxyError::InvalidRange(
            format!("Requested range {}-{} not contained in cached range {}-{}",
                requested.start, requested.end, cached.start, cached.end)
        ));
    }
    
    // Ensure slice doesn't exceed cached data length
    let slice_end = (requested.end - cached.start + 1) as usize;
    if slice_end > cached_data_len {
        return Err(ProxyError::InvalidRange(
            format!("Slice end {} exceeds cached data length {}",
                slice_end, cached_data_len)
        ));
    }
    
    Ok(())
}
```

### Error Scenarios

1. **Slice bounds exceed cached data**: Log error and return 500 Internal Server Error
2. **Requested range not contained in cached range**: This should never happen (logic error), log critical error
3. **Integer overflow in slice calculation**: Use checked arithmetic and return error if overflow occurs

## Testing Strategy

### Unit Tests

**Multipart Upload Caching Tests:**
1. **8 MiB part test**: Upload 8 MiB part, verify cached range is exactly `0-8388607` (8,388,608 bytes)
2. **Multiple parts test**: Upload 3 parts, verify ranges are `0-8388607`, `8388608-16777215`, `16777216-25165823`
3. **Last part test**: Upload final 4 MiB part, verify correct size and boundaries
4. **HTTP framing detection**: Verify no HTTP headers or chunk markers in cached data

**Range Serving Tests:**
1. **Exact match test**: Requested range == cached range, no slicing needed
2. **Start slice test**: Requested range at start of cached range
3. **End slice test**: Requested range at end of cached range
4. **Middle slice test**: Requested range in middle of cached range
5. **Full file test**: Requested range 0-N where N is file size
6. **Small range test**: Single byte range (e.g., 100-100)

### Property-Based Tests

Use `quickcheck` to generate random range combinations and verify:

1. **Property 0 Test**: Generate random part sizes, verify cached data contains exactly that many bytes without HTTP framing
2. **Property 1 Test**: Generate random requested and cached ranges, verify returned byte count equals requested count
3. **Property 2 Test**: Verify Content-Length header matches actual body length
4. **Property 4 Test**: Verify slice offset and length calculations for random ranges
5. **Property 5 Test**: Verify no slicing occurs when ranges match exactly
6. **Property 8 Test**: Generate random multipart uploads, verify all part boundaries align with 8 MiB boundaries

### Integration Tests

1. **Multipart upload then download test**: Upload 100MB file via multipart, then download with range requests, verify no corruption
2. **Part boundary verification test**: Upload file, inspect cached ranges, verify they match S3 part boundaries exactly
3. **Archive.zip corruption test**: Download the specific file that triggered the bug, verify file integrity
4. **AWS SDK sync test**: Use `aws s3 sync` to download files, verify no "DEST_COPY_TOO_SMALL" errors
5. **Multi-range test**: Request multiple ranges from same file, verify each is sliced correctly
6. **Large file test**: Download 500MB+ file in chunks, verify all chunks are correct size
7. **54-byte bug regression test**: Upload via multipart, verify cached ranges do NOT have +54 byte offset

### Test Configuration

- Property-based tests: Minimum 100 iterations per property
- Use `quickcheck` crate for property testing
- Tag each property test with: `**Feature: range-slice-bug-fix, Property N: [property text]**`

## Implementation Notes

### Performance Considerations

1. **Memory Efficiency**: Slicing creates a new Vec, consider using `Bytes::slice()` for zero-copy slicing if using the `bytes` crate
2. **Logging Overhead**: Only log slice operations at DEBUG level to avoid performance impact in production
3. **Validation Cost**: Slice bound validation is O(1), minimal overhead

### Backward Compatibility

This fix corrects buggy behavior, so there is no backward compatibility concern. All clients will benefit from correct range serving.

### Deployment Strategy

1. Deploy fix to staging environment
2. Run integration tests with real S3 files
3. Verify AWS SDK operations (sync, cp with multipart)
4. Deploy to production with monitoring for Content-Length mismatches
