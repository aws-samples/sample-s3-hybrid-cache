# Requirements Document

## Introduction

This specification addresses a critical bug in the S3 proxy's range serving logic where cached range data is not properly sliced to match the exact client-requested byte range. When a client requests a specific byte range (e.g., `bytes=0-8388607`), but the cache contains a larger range that encompasses the request (e.g., `0-8388661`), the proxy incorrectly returns the entire cached range instead of extracting only the requested portion. This causes file corruption and AWS SDK errors like "AWS_ERROR_DEST_COPY_TOO_SMALL".

### Root Cause Analysis

Testing revealed that the bug originates in the **multipart upload caching logic**, not the range serving logic. When files are uploaded via multipart upload through the proxy:

1. **Correct behavior (GET requests)**: When downloading via GET with `--part-number`, S3 returns exactly 8,388,608 bytes (8 MiB) for each part, stored as ranges like `0-8388607`, `8388608-16777215`, etc.

2. **Buggy behavior (PUT uploads)**: When uploading via multipart PUT through the proxy, the proxy caches each part with **54 extra bytes**, storing ranges like `0-8388661`, `8388662-16777323`, etc.

3. **Consequence**: When a client later requests `bytes=0-8388607`, the cache contains `0-8388661` (54 bytes too large), causing range misalignment and file corruption.

The 54 extra bytes appear to be HTTP framing data (headers or chunk encoding markers) that are incorrectly included in the cached part data during multipart upload processing.

## Glossary

- **Requested Range**: The specific byte range requested by the client in the Range header (e.g., `bytes=0-8388607`)
- **Cached Range**: The byte range stored in the disk cache (e.g., `0-8388661`)
- **Range Slice**: The operation of extracting a subset of bytes from a larger cached range to match the exact requested range
- **Content-Length**: The HTTP header indicating the number of bytes being returned in the response body
- **Content-Range**: The HTTP header indicating which bytes of the full resource are being returned (e.g., `bytes 0-8388607/527784854`)
- **Multipart Upload**: S3 operation where large files are uploaded in multiple parts, each part typically 8 MiB (8,388,608 bytes)
- **HTTP Framing**: HTTP protocol overhead including headers, chunk encoding markers, and delimiters that should not be included in cached data

## Requirements

### Requirement 1

**User Story:** As a client downloading a file through the S3 proxy, I want to receive exactly the bytes I requested, so that my downloaded file is not corrupted.

#### Acceptance Criteria

1. WHEN a client requests a byte range THEN the system SHALL return exactly the number of bytes specified in the request
2. WHEN the cached range is larger than the requested range THEN the system SHALL extract only the requested portion from the cached data
3. WHEN serving a cached range THEN the system SHALL set the Content-Length header to match the exact number of bytes being returned
4. WHEN serving a cached range THEN the system SHALL set the Content-Range header to reflect the exact bytes being returned
5. WHEN the requested range is `bytes=0-8388607` and the cached range is `0-8388661` THEN the system SHALL return exactly 8388608 bytes (not 8388662 bytes)

### Requirement 5

**User Story:** As a system storing multipart upload data, I want to cache only the actual part data without HTTP framing, so that cached ranges align with S3's actual byte boundaries.

#### Acceptance Criteria

1. WHEN caching a multipart upload part THEN the system SHALL strip all HTTP framing data before storage
2. WHEN an 8 MiB multipart part is uploaded THEN the system SHALL cache exactly 8,388,608 bytes (not 8,388,662 bytes)
3. WHEN storing part 1 of a multipart upload THEN the system SHALL cache range `0-8388607` (not `0-8388661`)
4. WHEN storing part 2 of a multipart upload THEN the system SHALL cache range `8388608-16777215` (not `8388662-16777323`)
5. WHEN completing a multipart upload THEN all cached part ranges SHALL align with S3's actual part boundaries

### Requirement 2

**User Story:** As a developer debugging range serving issues, I want detailed logging of range slicing operations, so that I can verify correct behavior.

#### Acceptance Criteria

1. WHEN serving a cached range THEN the system SHALL log the requested range, cached range, and actual bytes returned
2. WHEN slicing a cached range THEN the system SHALL log the slice offset and length being extracted
3. WHEN there is a mismatch between requested and cached ranges THEN the system SHALL log the slicing operation being performed
4. WHEN the Content-Length header is set THEN the system SHALL log the value to enable verification

### Requirement 3

**User Story:** As a system operator, I want the proxy to handle edge cases in range slicing, so that all valid range requests are served correctly.

#### Acceptance Criteria

1. WHEN the requested range exactly matches the cached range THEN the system SHALL return the entire cached range without slicing
2. WHEN the requested range is at the start of a cached range THEN the system SHALL slice from offset 0
3. WHEN the requested range is at the end of a cached range THEN the system SHALL slice to the end of the requested range
4. WHEN the requested range is in the middle of a cached range THEN the system SHALL slice from the appropriate offset
5. WHEN multiple cached ranges are needed THEN the system SHALL slice each cached range appropriately and concatenate the results

### Requirement 4

**User Story:** As a client using the AWS SDK, I want range responses to be byte-accurate, so that multipart downloads and sync operations complete successfully.

#### Acceptance Criteria

1. WHEN the AWS SDK requests a specific range THEN the system SHALL return exactly that range to prevent "DEST_COPY_TOO_SMALL" errors
2. WHEN serving the last range of a file THEN the system SHALL ensure the Content-Range end byte matches the request
3. WHEN the client validates Content-Length against the requested range THEN the system SHALL pass validation
4. WHEN multiple range requests are made for the same file THEN the system SHALL consistently return correct byte counts for each range
