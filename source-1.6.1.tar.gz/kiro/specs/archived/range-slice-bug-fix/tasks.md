# Implementation Plan

- [x] 1. Add range slicing helper functions to ByteRange or range utilities
  - Create `slice_offset_in()` method to calculate offset within containing range
  - Create `slice_length()` method to calculate number of bytes to extract
  - Add validation function to check slice bounds
  - _Requirements: 1.2, 3.2, 3.3, 3.4_

- [ ]* 1.1 Write property test for slice offset calculation
  - **Property 4: Slice calculation correctness**
  - **Validates: Requirements 1.2, 1.5**

- [ ]* 1.2 Write unit tests for range slicing edge cases
  - Test exact match (no slicing needed)
  - Test start of range slicing
  - Test end of range slicing
  - Test middle of range slicing
  - _Requirements: 3.1, 3.2, 3.3, 3.4_

- [x] 2. Fix range serving logic in http_proxy.rs for single cached range hits
  - Locate the code path where cached range data is loaded and returned
  - Calculate slice offset: `requested_start - cached_start`
  - Calculate slice length: `requested_end - requested_start + 1`
  - Extract sliced bytes from cached data: `cached_data[offset..offset+length]`
  - Update Content-Length header to match sliced data length
  - Update Content-Range header to reflect exact bytes being returned
  - Add detailed logging of slice operation (requested range, cached range, offset, length)
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.1, 2.2, 2.3_

- [ ]* 2.1 Write property test for exact byte count returned
  - **Property 1: Exact byte count returned**
  - **Validates: Requirements 1.1, 1.2**

- [ ]* 2.2 Write property test for Content-Length header accuracy
  - **Property 2: Content-Length header accuracy**
  - **Validates: Requirements 1.3**

- [ ]* 2.3 Write property test for Content-Range header accuracy
  - **Property 3: Content-Range header accuracy**
  - **Validates: Requirements 1.4**

- [x] 3. Fix range serving logic for multiple cached range hits
  - Locate the code path where multiple cached ranges are concatenated
  - For each cached range, calculate and apply appropriate slice
  - Ensure sliced ranges are concatenated in correct order
  - Verify total bytes returned equals requested byte count
  - Add logging for each range slice operation
  - _Requirements: 3.5, 2.1, 2.2_

- [ ]* 3.1 Write property test for multiple range concatenation
  - **Property 6: Multiple range concatenation**
  - **Validates: Requirements 3.5**

- [x] 4. Add identity optimization for exact range matches
  - Check if requested range exactly matches cached range
  - Skip slicing operation when ranges match
  - Add logging to indicate no slicing needed
  - _Requirements: 3.1, 2.1_

- [ ]* 4.1 Write property test for identity property
  - **Property 5: Identity property for exact matches**
  - **Validates: Requirements 3.1**

- [x] 5. Add comprehensive logging for debugging
  - Log requested range, cached range, and slice parameters at DEBUG level
  - Log Content-Length and Content-Range headers being set
  - Log when slicing is skipped due to exact match
  - Ensure logging includes all information needed to debug range issues
  - _Requirements: 2.1, 2.2, 2.3, 2.4_

- [ ]* 5.1 Write property test for logging completeness
  - **Property 7: Logging completeness**
  - **Validates: Requirements 2.1, 2.2, 2.3**

- [x] 6. Create integration test for Archive.zip corruption bug
  - Set up test that uploads a multi-part file (50MB+)
  - Download file through proxy using range requests
  - Verify downloaded file matches original (checksum comparison)
  - Verify no "DEST_COPY_TOO_SMALL" errors occur
  - Test with AWS SDK sync operation
  - _Requirements: 4.1, 4.2, 4.3, 4.4_

- [x] 7. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
