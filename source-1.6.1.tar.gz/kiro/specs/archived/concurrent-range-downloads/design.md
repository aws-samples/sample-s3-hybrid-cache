# ARCHIVED — Integrated into correct-get-part-behaviour spec

See the InFlightTracker Design section in `.kiro/specs/correct-get-part-behaviour/design.md`.

---

