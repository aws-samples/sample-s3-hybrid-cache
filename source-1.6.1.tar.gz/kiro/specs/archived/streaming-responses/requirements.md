# Streaming Response Architecture - Requirements

## Problem Statement

The proxy currently buffers entire responses in memory before sending to clients. This causes:
1. AWS SDK throughput timeout failures on large files (500MB)
2. High memory usage proportional to file size
3. Increased latency (first byte delayed until entire response buffered)
4. Poor scalability for large objects

### Current Architecture Issues

**S3 Client** (`src/s3_client.rs:323`):
```rust
let body_bytes = body.collect().await  // Buffers entire response
```

**HTTP Proxy** (`src/http_proxy.rs`):
```rust
Response<Full<Bytes>>  // Requires complete body
```

**Impact**: For 8MB range requests, the proxy waits to collect all 8MB from S3 before sending any data to client. AWS SDK sees no data flow during collection and triggers throughput timeout.

## Requirements

### 1. Stream S3 Responses

**REQ-1.1**: S3 client SHALL return streaming response bodies instead of buffered `Bytes`

**REQ-1.2**: S3 client SHALL support both streaming and buffered modes for backward compatibility

**REQ-1.3**: Streaming responses SHALL begin sending data to client immediately as received from S3

**REQ-1.4**: Streaming SHALL work with both HTTP and HTTPS connections

### 2. Stream HTTP Proxy Responses

**REQ-2.1**: HTTP proxy SHALL return streaming response bodies using `BoxBody` or `StreamBody`

**REQ-2.2**: All response paths (cache hit, cache miss, fallback) SHALL support streaming

**REQ-2.3**: HEAD requests SHALL continue using empty bodies (no streaming needed)

**REQ-2.4**: Error responses SHALL continue using buffered bodies (small, no streaming benefit)

### 3. Stream Cache Reads

**REQ-3.1**: Disk cache reads SHALL stream file contents in chunks instead of loading entire file

**REQ-3.2**: RAM cache reads MAY continue using buffered approach (already in memory)

**REQ-3.3**: Range merging SHALL support streaming when possible

**REQ-3.4**: Chunk size for streaming SHALL be configurable (default: 64KB)

### 4. Maintain Cache Writes

**REQ-4.1**: Cache writes SHALL continue to buffer data (necessary for compression and storage)

**REQ-4.2**: Cache writes SHALL remain asynchronous (background tasks)

**REQ-4.3**: Streaming responses SHALL clone data for async cache writes

**REQ-4.4**: Memory overhead from cloning SHALL be acceptable trade-off for streaming

### 5. Performance Requirements

**REQ-5.1**: First byte latency SHALL be reduced by at least 90% for large responses

**REQ-5.2**: Memory usage SHALL remain constant regardless of response size

**REQ-5.3**: Throughput SHALL match or exceed current buffered implementation

**REQ-5.4**: AWS SDK throughput monitoring SHALL be satisfied for all file sizes

### 6. Compatibility Requirements

**REQ-6.1**: Existing tests SHALL pass with minimal modifications

**REQ-6.2**: Configuration format SHALL remain unchanged

**REQ-6.3**: Cache format SHALL remain unchanged

**REQ-6.4**: API behavior SHALL remain unchanged from client perspective

### 7. Error Handling

**REQ-7.1**: Stream errors SHALL be propagated to client appropriately

**REQ-7.2**: Partial stream failures SHALL not corrupt cache

**REQ-7.3**: Connection drops SHALL be handled gracefully

**REQ-7.4**: Logging SHALL indicate streaming vs buffered responses

## Success Criteria

1. ✅ 500MB file downloads successfully through proxy without timeout
2. ✅ Memory usage stays constant during large file transfers
3. ✅ First byte latency < 100ms for any response size
4. ✅ All existing tests pass
5. ✅ No regression in cache hit performance
6. ✅ AWS SDK throughput monitoring satisfied

## Out of Scope

- Streaming for PUT requests (write path remains buffered)
- Streaming compression (compress before streaming)
- Adaptive chunk sizing based on network conditions
- HTTP/2 or HTTP/3 support (future enhancement)

## Dependencies

- `http-body-util` crate (already in use)
- `tokio::fs::File` for async file streaming
- `tokio_util::codec` for file chunking
- `futures::stream` for stream composition

## Risks

1. **Complexity**: Streaming adds complexity to error handling
2. **Testing**: Harder to test streaming behavior
3. **Memory**: Cloning for cache writes increases memory temporarily
4. **Debugging**: Streaming issues harder to diagnose than buffered

## Mitigation

1. Comprehensive error handling with detailed logging
2. Property-based tests for streaming behavior
3. Monitor memory metrics during implementation
4. Add streaming-specific diagnostic logging
