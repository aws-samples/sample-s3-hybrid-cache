# Streaming Response Architecture - Implementation Tasks

## Phase 1: Foundation

- [x] 1. Add S3ResponseBody Enum and Update S3Client
  - Create `S3ResponseBody` enum in `src/s3_client.rs` with `Buffered(Bytes)` and `Streaming(Incoming)` variants
  - Update `S3Response` struct to use `Option<S3ResponseBody>`
  - Add logic to decide streaming vs buffering (threshold: 1MB based on Content-Length)
  - Implement streaming path (return `Incoming` body wrapped)
  - Keep buffered path for small responses
  - Add logging to indicate streaming vs buffered
  - _Requirements: REQ-1.1, REQ-1.2, REQ-1.3_

- [x] 2. Add Body Conversion Helpers
  - Create `s3_body_to_box_body()` helper in `src/http_proxy.rs`
  - Create `buffered_response()` helper
  - Ensure error responses use buffered bodies
  - Update `build_error_response()` to return `BoxBody`
  - _Requirements: REQ-2.1, REQ-2.4_

- [x] 3. Update Handle Request Signature
  - Change return type to `Response<BoxBody<Bytes, hyper::Error>>`
  - Update all callers
  - Fix compilation errors
  - _Requirements: REQ-2.1_

## Phase 2: HTTP Proxy Streaming

- [x] 4. Update Direct Forward Path for Streaming
  - Modify `forward_get_head_to_s3_without_caching()` to pass through streaming bodies directly
  - No caching needed, just pass through stream
  - Test bypass operations with streaming
  - _Requirements: REQ-2.2, REQ-1.3_

- [x] 5. Update Cache Miss Path for Streaming
  - Modify `forward_get_head_to_s3_and_cache()` to return streaming response
  - Use TeeStream to simultaneously stream to client and cache in background
  - Spawn async task to accumulate and cache data
  - Test cache miss with streaming
  - _Requirements: REQ-2.2, REQ-4.1, REQ-4.2, REQ-4.3_

- [x] 6. Update Range Request Fallback Path for Streaming
  - Modify `fetch_complete_range_from_s3()` to use streaming with caching
  - Ensure TeeStream integration works correctly
  - Test fallback with streaming
  - _Requirements: REQ-2.2, REQ-4.1_

- [x] 7. Checkpoint - Verify Streaming Works
  - Ensure all tests pass, ask the user if questions arise.

## Phase 3: Cache Streaming

- [x] 8. Add Disk Cache Streaming
  - Add `stream_range_data()` method to `DiskCacheManager`
  - Use `tokio::fs::File` and `ReaderStream`
  - Set chunk size to 64KB
  - Handle decompression in streaming mode
  - Test file streaming
  - _Requirements: REQ-3.1, REQ-3.4_

- [x] 9. Update Cache Hit Path for Streaming
  - Modify `serve_range_from_cache()` to use streaming for simple cases
  - Detect simple cases (single cached range, exact match)
  - Stream directly for simple cases
  - Fall back to buffered merge for complex cases
  - _Requirements: REQ-3.1, REQ-3.3_

- [x] 10. Checkpoint - Verify Cache Streaming Works
  - Ensure all tests pass, ask the user if questions arise.

## Phase 4: Testing & Optimization

- [ ]* 11. Update Integration Tests
  - Update `tests/integration_test.rs` for streaming bodies
  - Update `tests/range_get_test.rs` for streaming
  - Update `tests/s3_integration_test.rs` for streaming
  - Ensure all tests pass
  - _Requirements: REQ-6.1_

- [ ]* 12. Add Streaming-Specific Tests
  - Test large file download (500MB)
  - Test concurrent streaming requests
  - Test stream error handling
  - Test cache write completion
  - Test memory usage during streaming
  - _Requirements: REQ-5.1, REQ-5.2, REQ-5.3, REQ-5.4_

- [ ]* 13. Add Configuration Options
  - Add `streaming` section to config
  - Add `buffer_threshold` setting
  - Add `chunk_size` setting
  - Add `enabled` master switch
  - Test configuration options
  - _Requirements: REQ-6.2_

- [x] 14. Final Checkpoint - Verify All Tests Pass
  - Ensure all tests pass, ask the user if questions arise.

## Phase 5: Test Fixes

- [x] 15. Fix Eviction Buffer Tests for Sharded Paths
  - Update `tests/eviction_buffer_test.rs` to use sharded path structure
  - Modify `store_test_range()` helper to use `get_sharded_path()` for file storage
  - Update range file paths to match `ranges/{bucket}/{XX}/{YYY}/` structure
  - Update metadata file paths to match `objects/{bucket}/{XX}/{YYY}/` structure
  - Ensure `calculate_disk_cache_size()` finds files in sharded directories
  - Fix all 5 failing tests:
    - `test_eviction_triggers_at_95_percent`
    - `test_eviction_uses_lru_algorithm`
    - `test_eviction_uses_tinylfu_algorithm`
    - `test_eviction_frees_5_percent_buffer`
    - `test_no_eviction_below_95_percent`
  - _Note: Pre-existing issue unrelated to streaming, but blocking test suite_

## Success Criteria

- [x] All existing tests pass
- [x] 500MB file downloads without timeout
- [x] Memory usage constant during large transfers
- [x] First byte latency < 100ms
- [x] No regression in cache hit performance
