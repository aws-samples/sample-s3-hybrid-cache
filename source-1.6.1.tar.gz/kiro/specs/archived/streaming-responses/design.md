# Streaming Response Architecture - Design

## Implementation Status

**Phase 1-2: COMPLETE** ✅ (December 2025)
- S3 client supports streaming bodies via `S3ResponseBody` enum
- HTTP proxy returns `BoxBody<Bytes, hyper::Error>` for streaming support
- Complete range cache misses stream directly from S3 with background caching
- `TeeStream` enables simultaneous streaming to client and caching

**Phase 3: PARTIAL**
- Simple streaming for complete cache misses implemented
- Complex merges (partial cache hits) still buffered

**Phase 4: PENDING**
- Additional testing and optimization needed

## Overview

Transform the proxy from a buffered architecture to a streaming architecture, allowing data to flow from S3 → Proxy → Client without intermediate buffering.

## Architecture Changes

### 1. Response Body Types

**Current**:
```rust
Response<Full<Bytes>>  // Fully buffered
```

**New**:
```rust
use http_body_util::combinators::BoxBody;
use bytes::Bytes;
use hyper::Error;

Response<BoxBody<Bytes, Error>>  // Streaming or buffered
```

`BoxBody` is a type-erased body that can wrap any body type, allowing us to return either streaming or buffered bodies through the same interface.

### 2. S3 Client Streaming

#### Current Implementation

```rust
pub struct S3Response {
    pub status: StatusCode,
    pub headers: HashMap<String, String>,
    pub body: Option<Bytes>,  // Fully buffered
    pub request_duration: Duration,
    pub connection_ip: IpAddr,
}

// In forward_request:
let body_bytes = body.collect().await?.to_bytes();
```

#### New Implementation

```rust
use http_body_util::StreamBody;
use hyper::body::{Body, Frame, Incoming};

pub enum S3ResponseBody {
    Buffered(Bytes),
    Streaming(StreamBody<Incoming>),
}

pub struct S3Response {
    pub status: StatusCode,
    pub headers: HashMap<String, String>,
    pub body: Option<S3ResponseBody>,  // Streaming or buffered
    pub request_duration: Duration,
    pub connection_ip: IpAddr,
}

// In forward_request:
// Option 1: Stream mode (default for large responses)
let body = S3ResponseBody::Streaming(StreamBody::new(body));

// Option 2: Buffered mode (for small responses or when needed)
let body_bytes = body.collect().await?.to_bytes();
let body = S3ResponseBody::Buffered(body_bytes);
```

**Decision Point**: When to buffer vs stream?
- Stream: Responses > 1MB (configurable threshold)
- Buffer: Responses < 1MB, error responses, metadata operations

### 3. HTTP Proxy Response Construction

#### Helper Functions

```rust
use http_body_util::{BodyExt, Full, StreamBody};

// Convert S3ResponseBody to BoxBody
fn s3_body_to_box_body(body: S3ResponseBody) -> BoxBody<Bytes, hyper::Error> {
    match body {
        S3ResponseBody::Buffered(bytes) => {
            Full::new(bytes).map_err(|never| match never {}).boxed()
        }
        S3ResponseBody::Streaming(stream) => {
            stream.map_err(|e| hyper::Error::from(e)).boxed()
        }
    }
}

// Create buffered response (for errors, small responses)
fn buffered_response(
    status: StatusCode,
    headers: HeaderMap,
    body: Bytes,
) -> Response<BoxBody<Bytes, hyper::Error>> {
    let mut builder = Response::builder().status(status);
    for (key, value) in headers {
        builder = builder.header(key, value);
    }
    builder.body(Full::new(body).boxed()).unwrap()
}

// Create streaming response
fn streaming_response(
    status: StatusCode,
    headers: HeaderMap,
    body: S3ResponseBody,
) -> Response<BoxBody<Bytes, hyper::Error>> {
    let mut builder = Response::builder().status(status);
    for (key, value) in headers {
        builder = builder.header(key, value);
    }
    builder.body(s3_body_to_box_body(body)).unwrap()
}
```

### 4. Cache Read Streaming

#### Disk Cache Streaming

```rust
use tokio::fs::File;
use tokio::io::AsyncReadExt;
use futures::stream::{Stream, StreamExt};

pub async fn stream_range_data(
    &self,
    cache_key: &str,
    start: u64,
    end: u64,
) -> Result<impl Stream<Item = Result<Bytes>>> {
    let path = self.get_range_path(cache_key, start, end);
    let file = File::open(&path).await?;
    
    // Create stream that reads file in chunks
    let chunk_size = 65536; // 64KB chunks
    let stream = tokio_util::io::ReaderStream::new(file);
    
    Ok(stream.map(|result| {
        result.map_err(|e| ProxyError::IoError(e))
    }))
}
```

#### Range Merging with Streaming

**Challenge**: Merging multiple ranges requires reading them in order and concatenating.

**Solution**: For simple cases (single cached range), stream directly. For complex merges, buffer temporarily.

```rust
pub async fn serve_range_streaming(
    &self,
    cache_key: &str,
    range_spec: &RangeSpec,
) -> Result<S3ResponseBody> {
    let overlap = self.detect_overlap(cache_key, range_spec).await?;
    
    // Simple case: single cached range covers entire request
    if overlap.cached_ranges.len() == 1 
        && overlap.cached_ranges[0].start == range_spec.start
        && overlap.cached_ranges[0].end == range_spec.end 
    {
        // Stream directly from cache
        let stream = self.disk_cache.stream_range_data(
            cache_key,
            range_spec.start,
            range_spec.end,
        ).await?;
        
        return Ok(S3ResponseBody::Streaming(StreamBody::new(stream)));
    }
    
    // Complex case: multiple ranges or partial coverage
    // Fall back to buffered merge
    let data = self.merge_ranges_buffered(cache_key, range_spec, &overlap).await?;
    Ok(S3ResponseBody::Buffered(Bytes::from(data)))
}
```

### 5. Cache Write Strategy

Cache writes must buffer data to compress and store. Strategy:

1. **Clone data for caching**: When streaming response, clone chunks for async cache write
2. **Accumulate in background**: Background task accumulates chunks and writes to cache
3. **No blocking**: Response streams immediately, caching happens in parallel

```rust
// In response path:
let (tx, rx) = tokio::sync::mpsc::channel(100);

// Spawn cache writer
let cache_key_clone = cache_key.clone();
tokio::spawn(async move {
    let mut accumulated = Vec::new();
    while let Some(chunk) = rx.recv().await {
        accumulated.extend_from_slice(&chunk);
    }
    // Write accumulated data to cache
    cache_manager.store_range(&cache_key_clone, &accumulated).await;
});

// Create tee stream that sends to both client and cache
let stream = original_stream.map(move |chunk| {
    if let Ok(ref bytes) = chunk {
        let _ = tx.try_send(bytes.clone());
    }
    chunk
});

// Return streaming response
Ok(S3ResponseBody::Streaming(StreamBody::new(stream)))
```

## Implementation Phases

### Phase 1: Foundation (Day 1)

1. Update `S3Response` to support streaming bodies
2. Add `S3ResponseBody` enum
3. Update `S3Client::forward_request` to return streaming bodies
4. Add helper functions for body conversion
5. Update error response paths (keep buffered)

**Files**: `src/s3_client.rs`, `src/error.rs`

### Phase 2: HTTP Proxy Streaming (Day 2)

1. Change `handle_request` return type to `Response<BoxBody<Bytes, hyper::Error>>`
2. Update all response construction to use new helpers
3. Update cache miss path to stream from S3
4. Update fallback path to stream from S3
5. Keep HEAD requests buffered (no body anyway)

**Files**: `src/http_proxy.rs`

### Phase 3: Cache Streaming (Day 2-3)

1. Add `stream_range_data` to `DiskCacheManager`
2. Update `RangeHandler` to support streaming
3. Implement simple streaming for single-range cache hits
4. Keep complex merges buffered (optimization for later)
5. Add tee stream for cache writes

**Files**: `src/disk_cache.rs`, `src/range_handler.rs`, `src/cache.rs`

### Phase 4: Testing & Optimization (Day 3)

1. Update integration tests for streaming
2. Add streaming-specific tests
3. Performance testing with large files
4. Memory profiling
5. Optimize chunk sizes

**Files**: `tests/*.rs`

## Configuration

Add streaming configuration to `config.yaml`:

```yaml
streaming:
  enabled: true  # Master switch
  buffer_threshold: 1048576  # 1MB - stream responses larger than this
  chunk_size: 65536  # 64KB - chunk size for file streaming
  cache_write_buffer: 104857600  # 100MB - max buffer for async cache writes
```

## Error Handling

### Stream Errors

```rust
// Wrap streams with error handling
let stream = original_stream.map(|result| {
    result.map_err(|e| {
        error!("Stream error: {}", e);
        hyper::Error::from(e)
    })
});
```

### Partial Failures

- If stream fails mid-transfer, client sees connection drop
- Cache write failures logged but don't affect client
- Partial cache writes cleaned up by TTL expiration

## Performance Considerations

### Memory Usage

**Before**: Peak memory = response size (e.g., 8MB for 8MB range)
**After**: Peak memory = chunk size × concurrent streams (e.g., 64KB × 10 = 640KB)

**Savings**: ~90% reduction for large responses

### Latency

**Before**: First byte after full S3 response collected (~1-2 seconds for 8MB)
**After**: First byte as soon as first chunk received (~10-50ms)

**Improvement**: ~95% reduction in first byte latency

### Throughput

**Before**: Limited by buffering overhead
**After**: Limited only by network bandwidth

**Improvement**: Matches direct S3 connection speed

## Backward Compatibility

- Configuration: Add new `streaming` section, defaults maintain current behavior
- API: Response format unchanged from client perspective
- Cache: No changes to cache storage format
- Tests: Update to handle streaming bodies, logic unchanged

## Monitoring

Add metrics:
- `streaming_responses_total`: Count of streamed responses
- `buffered_responses_total`: Count of buffered responses
- `stream_errors_total`: Count of stream errors
- `first_byte_latency_seconds`: Histogram of first byte latency
- `response_streaming_duration_seconds`: Histogram of full stream duration

## Rollback Plan

If streaming causes issues:
1. Set `streaming.enabled: false` in config
2. Proxy falls back to buffered mode
3. No code changes needed
4. No cache invalidation needed
