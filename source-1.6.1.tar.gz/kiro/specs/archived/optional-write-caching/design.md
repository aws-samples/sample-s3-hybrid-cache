# Design Document

## Overview

This design implements optional write-through caching for the S3 proxy. Currently, write caching is always enabled and creates directory structures on startup, even though the feature is incomplete. This change makes write caching opt-in via configuration, with appropriate warnings when enabled, while maintaining full read caching functionality.

The design focuses on minimal code changes to existing functionality while adding clear configuration control and appropriate warnings. When write caching is disabled (the new default), PutObject operations bypass the cache entirely and are forwarded directly to S3.

## Architecture

### Configuration Layer

The existing `write_cache_enabled` boolean parameter in the `CacheConfig` structure will be modified to:

- Change default from `true` to `false` (disabled by default)
- Remain configurable via YAML configuration files
- Be overridable via environment variable `WRITE_CACHE_ENABLED` (already exists)
- Be overridable via command-line flag `--write-cache-enabled` (new)

### Cache Initialization Layer

The cache initialization process will be modified to conditionally create write cache directories based on the `write_cache_enabled` configuration:

- When disabled (false): Skip creation of `write_cache` subdirectory
- When enabled (true): Create `write_cache` subdirectory and log warning message

### HTTP Proxy Layer

The HTTP proxy PUT request handler will check the `write_cache_enabled` configuration before attempting to cache PUT operations:

- When disabled (false): Forward PutObject directly to S3, bypass all write cache logic
- When enabled (true): Use existing write-through caching implementation

### Steering Documentation Layer

The testing guidelines in steering documentation will be updated to reflect that write caching tests should be skipped unless the change specifically involves write caching functionality.

## Components and Interfaces

### Configuration Component

**File:** `src/config.rs`

**Changes:**
- Change default value of existing `write_cache_enabled` field from `true` to `false` in `Default` implementation
- Add command-line argument `--write-cache-enabled` (environment variable already exists)

**Interface:**
```rust
pub struct CacheConfig {
    // ... existing fields ...
    pub write_cache_enabled: bool,  // MODIFIED: now defaults to false
    // ... existing fields ...
}
```

### Cache Manager Component

**File:** `src/cache.rs`

**Changes:**
- Accept `write_cache_enabled` parameter in constructor
- Conditionally create `write_cache` subdirectory in `initialize()` method based on flag
- Log warning when write caching is enabled
- Store configuration flag for runtime checks

**Interface:**
```rust
impl CacheManager {
    pub fn new_with_all_ttls_and_overrides(
        // ... existing parameters ...
        write_cache_enabled: bool,  // NEW parameter
    ) -> Self;
    
    pub async fn initialize(&self) -> Result<()>;  // Modified to check flag
    
    pub fn is_write_caching_enabled(&self) -> bool;  // NEW method
}
```

### Disk Cache Component

**File:** `src/disk_cache.rs`

**Changes:**
- Accept `write_cache_enabled` parameter in constructor
- Conditionally create `write_cache` subdirectory in `initialize()` method based on flag

**Interface:**
```rust
impl DiskCacheManager {
    pub fn new(
        cache_dir: PathBuf,
        compression_enabled: bool,
        compression_threshold: usize,
        write_cache_enabled: bool,  // NEW parameter
    ) -> Self;
    
    pub async fn initialize(&self) -> Result<()>;  // Modified to check flag
}
```

### HTTP Proxy Component

**File:** `src/http_proxy.rs`

**Changes:**
- Check `write_cache_enabled` configuration before caching PUT operations
- When disabled (false), forward PUT requests directly to S3 without caching
- When enabled (true), use existing write-through caching logic

**Interface:**
```rust
async fn handle_put_request(
    // ... existing parameters ...
) -> Result<Response<Body>> {
    // Check config.cache.write_cache_enabled
    // If false: forward to S3 directly
    // If true: use existing write cache logic
}
```

### Permissions Component

**File:** `src/permissions.rs`

**Changes:**
- Conditionally include `write_cache` in subdirectory list based on configuration

**Interface:**
```rust
pub async fn validate_directory_permissions(
    path: &PathBuf,
    dir_type: &str,
    write_cache_enabled: bool,  // NEW parameter
) -> Result<()>;
```

## Data Models

### Configuration Data Model

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheConfig {
    #[serde(deserialize_with = "pathbuf_serde::deserialize")]
    pub cache_dir: PathBuf,
    pub max_cache_size: u64,
    pub ram_cache_enabled: bool,
    pub max_ram_cache_size: u64,
    pub eviction_algorithm: EvictionAlgorithm,
    
    // MODIFIED: Changed default from true to false
    #[serde(default)]  // Now defaults to false
    pub write_cache_enabled: bool,
    pub write_cache_percent: f32,
    pub write_cache_max_object_size: u64,
    
    // ... other fields ...
}
```

### Cache Manager Internal State

```rust
pub struct CacheManager {
    cache_dir: PathBuf,
    write_cache_enabled: bool,  // NEW: Runtime flag
    // ... existing fields ...
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Default configuration disables write caching

*For any* configuration loaded with default values, the `write_cache_enabled` field should be `false`

**Validates: Requirements 1.1**

### Property 2: Write cache bypass when disabled

*For any* PutObject operation when `write_cache_enabled` is `false`, the operation should forward directly to S3 without storing data in local cache directories

**Validates: Requirements 1.2**

### Property 3: Write cache directory not created when disabled

*For any* cache initialization when `write_cache_enabled` is `false`, the `write_cache` subdirectory should not be created

**Validates: Requirements 1.3**

### Property 4: Read caching unaffected by write cache setting

*For any* GET or HEAD operation, the caching behavior should be identical regardless of the `write_cache_enabled` setting

**Validates: Requirements 1.4**

### Property 5: Configuration enables write caching

*For any* configuration with `write_cache_enabled` set to `true`, the system should enable write-through caching functionality

**Validates: Requirements 2.1**

### Property 6: Warning logged when enabled

*For any* system startup with `write_cache_enabled` set to `true`, a warning message "Write caching is not complete and may give errors" should be logged

**Validates: Requirements 2.2**

### Property 7: Write cache directory created when enabled

*For any* cache initialization when `write_cache_enabled` is `true`, the `write_cache` subdirectory should be created

**Validates: Requirements 2.3**

### Property 8: Write caching functions when enabled

*For any* PutObject operation when `write_cache_enabled` is `true`, the operation should cache the object data in the write cache directory

**Validates: Requirements 2.4, 2.5**

### Property 9: Configuration validation for boolean type

*For any* configuration file with `write_cache_enabled` set to a non-boolean value, the configuration parser should return an error

**Validates: Requirements 3.1, 3.3**

### Property 10: Configuration defaults to false when missing

*For any* configuration file without a `write_cache_enabled` field, the value should default to `false`

**Validates: Requirements 3.2**

### Property 11: Environment variable override

*For any* configuration with `WRITE_CACHE_ENABLED` environment variable set, the environment variable value should override the file configuration

**Validates: Requirements 3.4**

### Property 12: Command-line flag override

*For any* configuration with `--write-cache-enabled` flag provided, the flag value should override both file and environment variable configuration

**Validates: Requirements 3.5**

## Error Handling

### Configuration Errors

**Invalid Type Error:**
- **Trigger:** `write_cache_enabled` field has non-boolean value in YAML
- **Response:** Return `ProxyError::ConfigError` with descriptive message
- **Recovery:** Refuse to start, require user to fix configuration

**Environment Variable Parse Error:**
- **Trigger:** `WRITE_CACHE_ENABLED` environment variable has non-boolean value
- **Response:** Log warning and use default value (`false`)
- **Recovery:** Continue with default, log warning message

### Runtime Errors

**Write Cache Directory Creation Failure (when enabled):**
- **Trigger:** Cannot create `write_cache` directory due to permissions or disk space
- **Response:** Return `ProxyError::CacheError` with descriptive message
- **Recovery:** Fail initialization, require user intervention

**Write Cache Operation Failure (when enabled):**
- **Trigger:** Write cache operation fails during PUT request
- **Response:** Log error, forward request to S3 anyway
- **Recovery:** Continue serving request, cache miss for future reads

## Testing Strategy

### Unit Tests

Unit tests will verify specific configuration scenarios and edge cases:

1. **Configuration Parsing Tests:**
   - Test default configuration has `write_cache_enabled = false`
   - Test parsing valid boolean values (`true`, `false`)
   - Test parsing invalid values returns error
   - Test missing field defaults to `false`

2. **Environment Variable Tests:**
   - Test `WRITE_CACHE_ENABLED=true` enables write caching
   - Test `WRITE_CACHE_ENABLED=false` disables write caching
   - Test invalid environment variable value uses default

3. **Command-Line Argument Tests:**
   - Test `--write-cache-enabled` flag enables write caching
   - Test flag overrides file configuration
   - Test flag overrides environment variable

4. **Directory Creation Tests:**
   - Test `write_cache` directory not created when disabled
   - Test `write_cache` directory created when enabled
   - Test other directories always created regardless of setting

5. **Warning Message Tests:**
   - Test warning logged when write caching enabled
   - Test no warning logged when write caching disabled

### Property-Based Tests

Property-based tests will verify universal behaviors across all inputs using the QuickCheck framework:

1. **Property Test: Default Configuration**
   - Generate random configuration files without `write_cache_enabled` field
   - Verify all parsed configurations have `write_cache_enabled = false`
   - **Validates: Property 1**

2. **Property Test: Write Cache Bypass**
   - Generate random PutObject requests with `write_cache_enabled = false`
   - Verify no data written to `write_cache` directory
   - **Validates: Property 2**

3. **Property Test: Directory Creation**
   - Generate random cache configurations with varying `write_cache_enabled` values
   - Verify `write_cache` directory existence matches configuration
   - **Validates: Properties 3, 7**

4. **Property Test: Read Caching Independence**
   - Generate random GET/HEAD requests with varying `write_cache_enabled` values
   - Verify identical caching behavior regardless of write cache setting
   - **Validates: Property 4**

5. **Property Test: Configuration Validation**
   - Generate random configuration values (boolean and non-boolean)
   - Verify boolean values parse correctly and non-boolean values error
   - **Validates: Properties 9, 10**

6. **Property Test: Override Precedence**
   - Generate random combinations of file, environment, and CLI configurations
   - Verify CLI > environment > file precedence
   - **Validates: Properties 11, 12**

### Integration Tests

Integration tests will verify end-to-end behavior:

1. **Test: PUT Request with Write Caching Disabled**
   - Configure proxy with `write_cache_enabled = false`
   - Send PUT request
   - Verify object stored in S3
   - Verify no data in `write_cache` directory
   - Verify subsequent GET request fetches from S3

2. **Test: PUT Request with Write Caching Enabled**
   - Configure proxy with `write_cache_enabled = true`
   - Send PUT request
   - Verify object stored in S3
   - Verify data cached in `write_cache` directory
   - Verify subsequent GET request served from cache

3. **Test: Configuration Override Chain**
   - Set file config to `false`
   - Set environment variable to `true`
   - Set CLI flag to `false`
   - Verify final configuration is `false` (CLI wins)

4. **Test: Startup Warning Message**
   - Configure proxy with `write_cache_enabled = true`
   - Start proxy
   - Verify warning message in logs
   - Verify proxy starts successfully

### Test Configuration

All property-based tests will:
- Use QuickCheck framework (already in dependencies)
- Run minimum 100 iterations per property
- Be tagged with comments referencing design document properties
- Use format: `// Feature: optional-write-caching, Property N: <description>`

### Test Execution Strategy

1. Run unit tests first to verify basic functionality
2. Run property-based tests to verify universal behaviors
3. Run integration tests to verify end-to-end scenarios
4. All tests must pass before considering implementation complete

## Implementation Notes

### Backward Compatibility

The existing `write_cache_enabled` field will simply have its default changed from `true` to `false`. Existing configuration files that explicitly set `write_cache_enabled: true` will continue to work as before.

### Migration Path

Users with existing configurations:
1. If they have `write_cache_enabled: true` explicitly set, it will continue to work
2. If they rely on the default value, write caching will be disabled after upgrade
3. New installations will have write caching disabled by default

### Performance Considerations

When write caching is disabled:
- PUT requests have lower latency (no local write overhead)
- Subsequent GET requests may have higher latency (must fetch from S3)
- Disk I/O reduced (no write cache operations)
- Cache capacity fully available for read caching

### Logging Strategy

- **INFO level:** Log when write caching is enabled/disabled during initialization
- **WARN level:** Log warning message when write caching is enabled
- **DEBUG level:** Log when PUT requests bypass cache due to disabled write caching

### Configuration File Examples

**Disabled (default):**
```yaml
cache:
  cache_dir: /cache
  max_cache_size: 10737418240
  write_cache_enabled: false  # Optional, defaults to false
```

**Enabled with warning:**
```yaml
cache:
  cache_dir: /cache
  max_cache_size: 10737418240
  write_cache_enabled: true  # Explicitly enable
  write_cache_percent: 10.0
  write_cache_max_object_size: 268435456
```
