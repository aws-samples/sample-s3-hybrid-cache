# Design Document: Cache Bypass Headers

## Overview

This feature adds support for standard HTTP cache control headers (`Cache-Control` and `Pragma`) that allow clients to explicitly bypass the proxy's cache for GET and HEAD requests. This enables debugging, testing, and scenarios where clients need guaranteed fresh data from S3.

The implementation integrates with the existing cache bypass logic in `http_proxy.rs`, adding header-based bypass detection early in the request processing pipeline.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         HTTP Request                                 │
│  Headers: Cache-Control: no-cache, Pragma: no-cache                 │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    Cache Bypass Header Parser                        │
│  - Parse Cache-Control directives (case-insensitive)                │
│  - Parse Pragma header                                               │
│  - Determine bypass mode: None, NoCache, NoStore                    │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
                    ▼               ▼               ▼
              ┌─────────┐    ┌───────────┐   ┌───────────┐
              │  None   │    │  NoCache  │   │  NoStore  │
              │ Normal  │    │  Bypass   │   │  Bypass   │
              │ Cache   │    │  + Cache  │   │  No Cache │
              │ Logic   │    │  Response │   │  Response │
              └─────────┘    └───────────┘   └───────────┘
                    │               │               │
                    ▼               ▼               ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         S3 Request                                   │
│  (Cache-Control and Pragma headers stripped before forwarding)      │
└─────────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### CacheBypassMode Enum

New enum to represent the cache bypass behavior:

```rust
/// Cache bypass mode determined from request headers
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CacheBypassMode {
    /// No bypass - use normal cache logic
    None,
    /// Bypass cache lookup but cache the response (Cache-Control: no-cache or Pragma: no-cache)
    NoCache,
    /// Bypass cache lookup and do not cache the response (Cache-Control: no-store)
    NoStore,
}
```

### CacheBypassHeaderParser

New module for parsing cache control headers:

```rust
/// Parse cache bypass headers from request
/// 
/// Returns the most restrictive bypass mode found:
/// - NoStore > NoCache > None
/// 
/// Cache-Control takes precedence over Pragma when both are present.
pub fn parse_cache_bypass_headers(
    headers: &HashMap<String, String>,
    config_enabled: bool,
) -> CacheBypassMode {
    if !config_enabled {
        return CacheBypassMode::None;
    }
    
    // Check Cache-Control first (takes precedence)
    if let Some(cache_control) = headers.get("cache-control") {
        let mode = parse_cache_control(cache_control);
        if mode != CacheBypassMode::None {
            return mode;
        }
    }
    
    // Fall back to Pragma header
    if let Some(pragma) = headers.get("pragma") {
        if parse_pragma_no_cache(pragma) {
            return CacheBypassMode::NoCache;
        }
    }
    
    CacheBypassMode::None
}

/// Parse Cache-Control header value
/// 
/// Handles:
/// - Case-insensitive directive matching
/// - Multiple comma-separated directives
/// - Whitespace around directives
/// - Unknown directives (ignored)
/// 
/// Returns NoStore if both no-cache and no-store are present (more restrictive)
fn parse_cache_control(value: &str) -> CacheBypassMode {
    let mut has_no_cache = false;
    let mut has_no_store = false;
    
    for directive in value.split(',') {
        let directive = directive.trim().to_lowercase();
        match directive.as_str() {
            "no-cache" => has_no_cache = true,
            "no-store" => has_no_store = true,
            _ => {} // Ignore unknown directives
        }
    }
    
    if has_no_store {
        CacheBypassMode::NoStore
    } else if has_no_cache {
        CacheBypassMode::NoCache
    } else {
        CacheBypassMode::None
    }
}

/// Parse Pragma header for no-cache directive
fn parse_pragma_no_cache(value: &str) -> bool {
    value.trim().eq_ignore_ascii_case("no-cache")
}
```

### Configuration Extension

Add to `CacheConfig` in `config.rs`:

```rust
/// Enable cache bypass header support (Cache-Control, Pragma)
/// Default: true
#[serde(default = "default_cache_bypass_headers_enabled")]
pub cache_bypass_headers_enabled: bool,

fn default_cache_bypass_headers_enabled() -> bool {
    true
}
```

### Integration with HttpProxy

Modify `handle_get_head_request` in `http_proxy.rs`:

```rust
// Early in handle_get_head_request, after header parsing:

// Check for cache bypass headers (Requirements 1.1-1.4, 2.1-2.4, 3.1-3.4)
let bypass_mode = parse_cache_bypass_headers(
    &header_map,
    config.cache.cache_bypass_headers_enabled,
);

if bypass_mode != CacheBypassMode::None {
    let bypass_reason = match bypass_mode {
        CacheBypassMode::NoCache => "no-cache directive",
        CacheBypassMode::NoStore => "no-store directive",
        CacheBypassMode::None => unreachable!(),
    };
    
    // Log bypass at INFO level (Requirement 5.4)
    info!(
        "Cache bypass via header: method={} path={} reason={}",
        method, path, bypass_reason
    );
    
    // Record metrics (Requirements 5.1-5.3)
    if let Some(metrics_mgr) = metrics_manager.clone() {
        let reason = bypass_reason.to_string();
        tokio::spawn(async move {
            let mgr = metrics_mgr.read().await;
            mgr.record_cache_bypass(&reason).await;
        });
    }
    
    // Strip cache headers before forwarding (Requirements 6.1-6.3)
    let mut forwarded_headers = header_map.clone();
    forwarded_headers.remove("cache-control");
    forwarded_headers.remove("pragma");
    
    // Check if this operation is normally cacheable
    // LIST operations, metadata operations, etc. should never be cached
    let (is_non_cacheable_op, _, _) = Self::should_bypass_cache(path, &query_params);
    
    // Determine if we should cache the response:
    // - NoStore mode: never cache
    // - NoCache mode: cache only if the operation is normally cacheable
    let should_cache_response = bypass_mode == CacheBypassMode::NoCache && !is_non_cacheable_op;
    
    if should_cache_response {
        // Forward to S3 and cache the response
        // Use the normal caching path but skip the cache lookup
        return Self::forward_get_head_to_s3_with_caching(
            method.clone(),
            uri.clone(),
            host,
            forwarded_headers,
            cache_manager,
            s3_client,
            metrics_manager,
        ).await;
    } else {
        // Forward to S3 without caching
        return Self::forward_get_head_to_s3_without_caching(
            method.clone(),
            uri.clone(),
            host,
            forwarded_headers,
            s3_client,
            None,
        ).await;
    }
}
```

### Important: Respecting Non-Cacheable Operations

The `no-cache` directive only affects cache lookup bypass, not cacheability rules. Operations that are normally non-cacheable (LIST, metadata operations, etc.) remain non-cacheable even with `no-cache`:

| Operation Type | Normal Behavior | With `no-cache` | With `no-store` |
|---------------|-----------------|-----------------|-----------------|
| GetObject | Cache lookup + cache response | Skip lookup, cache response | Skip lookup, no cache |
| HeadObject | Cache lookup + cache response | Skip lookup, cache response | Skip lookup, no cache |
| ListObjects | No cache | No cache | No cache |
| GetObjectAcl | No cache | No cache | No cache |
| Other metadata | No cache | No cache | No cache |

This ensures that:
1. `no-cache` provides fresh data while still benefiting future requests
2. `no-store` provides fresh data with no caching at all
3. Non-cacheable operations remain non-cacheable regardless of headers

## Data Models

### Metrics Extension

Add new bypass reason tracking to `MetricsManager`:

```rust
// In ErrorStats struct
pub cache_bypasses_by_reason: HashMap<String, u64>,

// New bypass reasons:
// - "no-cache directive"
// - "no-store directive"  
// - "pragma no-cache"
```

The existing `record_cache_bypass` method already supports arbitrary reason strings, so no changes needed to the metrics API.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Cache bypass with no-cache header

*For any* GET or HEAD request with `Cache-Control: no-cache` header, the proxy SHALL skip the cache lookup and forward the request directly to S3.

**Validates: Requirements 1.1, 1.2**

### Property 2: Response caching with no-cache header

*For any* cacheable request (GetObject, HeadObject) with `Cache-Control: no-cache` that receives a successful response from S3, the response SHALL be cached normally for future requests.

**Validates: Requirements 1.3**

### Property 2a: Non-cacheable operations remain non-cacheable

*For any* non-cacheable operation (LIST, metadata operations) with `Cache-Control: no-cache` or `Pragma: no-cache`, the response SHALL NOT be cached regardless of the bypass header.

**Validates: Requirements 1.4, 3.4**

### Property 3: Cache bypass with no-store header

*For any* GET or HEAD request with `Cache-Control: no-store` header, the proxy SHALL skip the cache lookup and forward the request directly to S3.

**Validates: Requirements 2.1, 2.2**

### Property 4: No caching with no-store header

*For any* request with `Cache-Control: no-store` that receives a successful response from S3, the response SHALL NOT be cached.

**Validates: Requirements 2.3**

### Property 5: Cache bypass with Pragma no-cache

*For any* GET or HEAD request with `Pragma: no-cache` header (and no Cache-Control header), the proxy SHALL skip the cache lookup and forward the request directly to S3.

**Validates: Requirements 3.1, 3.2**

### Property 6: Cache-Control precedence over Pragma

*For any* request with both `Cache-Control` and `Pragma` headers present, the proxy SHALL use the `Cache-Control` directive and ignore `Pragma`.

**Validates: Requirements 3.4**

### Property 7: Case-insensitive header parsing

*For any* `Cache-Control` header value with directives in any case variation (e.g., "NO-CACHE", "No-Cache", "no-cache"), the proxy SHALL recognize and process the directive correctly.

**Validates: Requirements 4.1**

### Property 8: Multiple directive parsing

*For any* `Cache-Control` header with multiple comma-separated directives and varying whitespace, the proxy SHALL correctly parse and identify all relevant directives.

**Validates: Requirements 4.2, 4.3, 4.5**

### Property 9: no-store takes precedence over no-cache

*For any* `Cache-Control` header containing both `no-cache` and `no-store` directives, the proxy SHALL treat the request as `no-store` (the more restrictive option).

**Validates: Requirements 4.4**

### Property 10: Header stripping on forward

*For any* request forwarded to S3, the `Cache-Control` and `Pragma` headers SHALL be removed while all other headers are preserved.

**Validates: Requirements 6.1, 6.2, 6.3**

### Property 11: Configuration disable behavior

*For any* request when `cache_bypass_headers_enabled` is false, the proxy SHALL ignore `Cache-Control` and `Pragma` headers and process the request through normal cache logic.

**Validates: Requirements 7.3, 7.4**

## Error Handling

### Invalid Header Values

- Malformed `Cache-Control` headers are parsed best-effort
- Unknown directives are silently ignored
- Empty header values result in no bypass

### Configuration Errors

- Invalid `cache_bypass_headers_enabled` value defaults to `true`
- Configuration validation at startup logs warnings for invalid values

### Metrics Errors

- Metrics recording failures are logged but do not affect request processing
- Metrics are recorded asynchronously to avoid blocking requests

## Testing Strategy

### Unit Tests

1. **Header parsing tests**
   - Test `parse_cache_control` with various inputs
   - Test case-insensitivity
   - Test multiple directives
   - Test whitespace handling
   - Test unknown directives

2. **Configuration tests**
   - Test default value (enabled)
   - Test explicit enable/disable
   - Test config parsing from YAML

### Property-Based Tests

Property-based tests will use `quickcheck` to verify correctness properties across many generated inputs.

1. **Property 7: Case-insensitive parsing**
   - Generate random case variations of "no-cache" and "no-store"
   - Verify correct parsing regardless of case

2. **Property 8: Multiple directive parsing**
   - Generate headers with random combinations of directives and whitespace
   - Verify correct identification of bypass directives

3. **Property 9: no-store precedence**
   - Generate headers with both directives in random order
   - Verify no-store always wins

4. **Property 10: Header stripping**
   - Generate random header sets including cache headers
   - Verify cache headers removed, others preserved

### Integration Tests

1. **End-to-end bypass tests**
   - Send requests with bypass headers through proxy
   - Verify cache is bypassed
   - Verify response is correct

2. **Metrics verification**
   - Send bypass requests
   - Verify metrics endpoint shows correct counts

3. **Configuration tests**
   - Test with feature enabled/disabled
   - Verify behavior matches configuration
