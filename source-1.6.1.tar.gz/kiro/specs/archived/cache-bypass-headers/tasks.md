# Implementation Plan: Cache Bypass Headers

## Overview

This implementation adds support for standard HTTP cache control headers (`Cache-Control: no-cache`, `Cache-Control: no-store`, `Pragma: no-cache`) that allow clients to explicitly bypass the proxy's cache for GET and HEAD requests.

## Tasks

- [x] 1. Add configuration option for cache bypass headers
  - Add `cache_bypass_headers_enabled` field to `CacheConfig` in `src/config.rs`
  - Add default function `default_cache_bypass_headers_enabled()` returning `true`
  - Update `Default` impl for `CacheConfig`
  - _Requirements: 7.1, 7.2_

- [-] 2. Implement cache bypass header parsing
  - [x] 2.1 Create `CacheBypassMode` enum in `src/http_proxy.rs`
    - Define variants: `None`, `NoCache`, `NoStore`
    - _Requirements: 1.1, 2.1_

  - [x] 2.2 Implement `parse_cache_control` function
    - Parse comma-separated directives
    - Handle case-insensitive matching
    - Handle whitespace around directives
    - Return `NoStore` if both no-cache and no-store present
    - Ignore unknown directives
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

  - [x] 2.3 Implement `parse_pragma_no_cache` function
    - Check for "no-cache" value (case-insensitive)
    - _Requirements: 3.1, 3.2_

  - [x] 2.4 Implement `parse_cache_bypass_headers` function
    - Check config enabled flag first
    - Parse Cache-Control header (takes precedence)
    - Fall back to Pragma header
    - Return appropriate `CacheBypassMode`
    - _Requirements: 3.4, 7.3, 7.4_

  - [x] 2.5 Write property test for case-insensitive parsing
    - **Property 7: Case-insensitive header parsing**
    - **Validates: Requirements 4.1**

  - [x] 2.6 Write property test for multiple directive parsing
    - **Property 8: Multiple directive parsing**
    - **Validates: Requirements 4.2, 4.3, 4.5**

  - [x] 2.7 Write property test for no-store precedence
    - **Property 9: no-store takes precedence over no-cache**
    - **Validates: Requirements 4.4**

- [x] 3. Integrate cache bypass headers into request handling
  - [x] 3.1 Add bypass header check in `handle_get_head_request`
    - Call `parse_cache_bypass_headers` early in the function
    - Check before existing cache bypass logic
    - _Requirements: 1.1, 1.2, 2.1, 2.2, 3.1, 3.2_

  - [x] 3.2 Implement logging for cache bypass
    - Log at INFO level with bypass reason
    - Include method, path, and reason in log
    - _Requirements: 1.5, 2.4, 5.4_

  - [x] 3.3 Implement metrics recording for cache bypass
    - Record bypass count by reason
    - Use existing `record_cache_bypass` method
    - _Requirements: 5.1, 5.2, 5.3, 5.5_

  - [x] 3.4 Implement header stripping before S3 forward
    - Remove `cache-control` header
    - Remove `pragma` header
    - Preserve all other headers
    - _Requirements: 6.1, 6.2, 6.3_

  - [x] 3.5 Write property test for header stripping
    - **Property 10: Header stripping on forward**
    - **Validates: Requirements 6.1, 6.2, 6.3**

- [x] 4. Implement response caching logic
  - [x] 4.1 Implement NoCache mode response caching
    - Check if operation is normally cacheable using `should_bypass_cache`
    - Cache response only for cacheable operations (GetObject, HeadObject)
    - Do not cache LIST, metadata operations even with no-cache header
    - _Requirements: 1.3, 1.4, 3.3, 3.4_

  - [x] 4.2 Implement NoStore mode (no caching)
    - Forward to S3 without caching response
    - Use existing `forward_get_head_to_s3_without_caching`
    - _Requirements: 2.3_

  - [x] 4.3 Write property test for non-cacheable operations
    - **Property 2a: Non-cacheable operations remain non-cacheable**
    - **Validates: Requirements 1.4, 3.4**

- [x] 5. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Write integration tests
  - [x] 6.1 Write integration test for no-cache bypass
    - Test GET request with Cache-Control: no-cache
    - Verify cache is bypassed
    - Verify response is cached for future requests
    - _Requirements: 1.1, 1.3_

  - [x] 6.2 Write integration test for no-store bypass
    - Test GET request with Cache-Control: no-store
    - Verify cache is bypassed
    - Verify response is NOT cached
    - _Requirements: 2.1, 2.3_

  - [x] 6.3 Write integration test for Pragma no-cache
    - Test GET request with Pragma: no-cache
    - Verify cache is bypassed
    - _Requirements: 3.1_

  - [x] 6.4 Write integration test for config disable
    - Test with cache_bypass_headers_enabled: false
    - Verify headers are ignored
    - _Requirements: 7.3, 7.4_

- [x] 7. Update documentation
  - Add cache bypass headers section to `docs/features/CACHING.md`
  - Document supported headers and their behavior
  - Document configuration option
  - Add examples of usage
  - _Requirements: 5.4_

- [x] 8. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 9. Increment version to 0.4.0
  - Update version in `Cargo.toml` from current version to `0.4.0`
  - Update `CHANGELOG.md` with new version section
  - Document cache bypass headers feature
  - Document any other changes since last version

- [x] 10. Consolidate tests
  - Review test files in `tests/` directory. 
  - We have too many tests. Remove duplicate or redundant tests
  - Identify tests that can be combined into logical groups
  - Merge related property tests into single files where appropriate
  - Ensure test naming follows consistent conventions
  - **Completed**: Consolidated 37 property test files into 4 consolidated files:
    - `cache_bypass_headers_property_test.rs` (5 files → 1)
    - `dashboard_property_test.rs` (13 files → 1)
    - `distributed_eviction_lock_property_test.rs` (8 files → 1)
    - `range_based_eviction_property_test.rs` (9 files → 1)

- [x] 11. Tidy repository
  - Remove unused or obsolete files
  - Consider whichs specs should be archived
  - Remove temporary files and build artifacts not in `.gitignore`
  - Review and clean up markdown files in root (e.g., `CONFIG_DEFAULTS_FIX.md`, `SHARED_STORAGE_MODE_REFACTOR.md`)
  - Ensure `.gitignore` is comprehensive
  - Verify all documentation is up to date, including licsening.
  - **Completed**:
    - Deleted obsolete root markdown files: `CONFIG_DEFAULTS_FIX.md`, `SHARED_STORAGE_MODE_REFACTOR.md`
    - Deleted temporary test config files: `test-atomic-disabled.yaml`, `test-atomic-enabled.yaml`
    - Archived 24 completed specs to `.kiro/specs/archived/`
    - Updated `.gitignore` with additional entries for Kiro artifacts, coverage reports, and benchmarks
    - Verified `LICENSE_COMPLIANCE.md` and `THIRD_PARTY_LICENSES` are current

## Notes

- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
