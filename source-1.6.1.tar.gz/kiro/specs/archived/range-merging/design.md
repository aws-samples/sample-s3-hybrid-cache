# Design Document: Intelligent Range Merging for Partial Cache Hits

## Overview

This design implements intelligent range merging to optimize partial cache hits. When a GET request requires bytes that are partially cached, the system will serve cached portions and only fetch missing bytes from S3, then merge them into a complete response. This eliminates unnecessary S3 bandwidth usage and improves response times.

## Architecture

### High-Level Flow

```
Client Request (bytes=0-104857599)
    ↓
Parse Range Header
    ↓
Find Cached Ranges (returns RangeOverlap)
    ↓
┌─────────────────────────────────────┐
│ Can serve from cache?               │
├─────────────────────────────────────┤
│ YES: All bytes cached               │
│  → Load cached ranges               │
│  → Merge if multiple ranges         │
│  → Return 206 response              │
├─────────────────────────────────────┤
│ NO: Some bytes missing              │
│  → Identify missing ranges          │
│  → Consolidate missing ranges       │
│  → Fetch only missing from S3       │
│  → Cache fetched ranges             │
│  → Merge cached + fetched           │
│  → Return 206 response              │
└─────────────────────────────────────┘
```

### Component Interaction

```
┌──────────────┐
│ HttpProxy    │
│              │
│ handle_range │
│  _request()  │
└──────┬───────┘
       │
       ↓
┌──────────────────┐
│ RangeHandler     │
│                  │
│ find_cached_     │
│  ranges()        │
│                  │
│ merge_ranges()   │◄─── NEW
│                  │
│ consolidate_     │◄─── NEW
│  missing()       │
└──────┬───────────┘
       │
       ↓
┌──────────────────┐
│ DiskCacheManager │
│                  │
│ load_range_data()│
│                  │
│ store_range()    │
└──────────────────┘
```

## Components and Interfaces

### 1. RangeHandler (Enhanced)

**New Methods:**

```rust
impl RangeHandler {
    /// Merge multiple range segments into a single contiguous byte vector
    /// Validates alignment and extracts correct byte offsets from each range
    pub async fn merge_ranges(
        &self,
        requested_range: &RangeSpec,
        cached_ranges: &[Range],
        fetched_ranges: &[(RangeSpec, Vec<u8>)],
    ) -> Result<Vec<u8>>;
    
    /// Consolidate missing ranges to minimize S3 requests
    /// Merges ranges with small gaps to reduce request count
    pub fn consolidate_missing_ranges(
        &self,
        missing_ranges: Vec<RangeSpec>,
        max_gap_size: u64,
    ) -> Vec<RangeSpec>;
    
    /// Extract bytes from a cached range that overlap with requested range
    /// Handles partial overlaps and full containment
    pub async fn extract_bytes_from_cached_range(
        &self,
        cache_key: &str,
        cached_range: &Range,
        requested_start: u64,
        requested_end: u64,
    ) -> Result<Vec<u8>>;
    
    /// Fetch multiple missing ranges from S3 in parallel
    /// Returns fetched data with their corresponding range specs
    pub async fn fetch_missing_ranges(
        &self,
        cache_key: &str,
        missing_ranges: &[RangeSpec],
        s3_client: &Arc<crate::s3_client::S3Client>,
        host: &str,
        uri: &hyper::Uri,
        headers: &HashMap<String, String>,
    ) -> Result<Vec<(RangeSpec, Vec<u8>)>>;
}
```

### 2. HttpProxy (Modified)

**Updated Method:**

```rust
impl HttpProxy {
    /// Forward range request to S3 - NOW USES OVERLAP DATA
    async fn forward_range_request_to_s3(
        method: Method,
        uri: hyper::Uri,
        host: String,
        headers: HashMap<String, String>,
        cache_key: String,
        range_spec: RangeSpec,
        overlap: crate::range_handler::RangeOverlap,  // NO LONGER IGNORED
        cache_manager: Arc<CacheManager>,
        range_handler: Arc<RangeHandler>,
        s3_client: Arc<S3Client>,
    ) -> std::result::Result<Response<Full<Bytes>>, Infallible>;
    
    /// Serve range from cache with merging support - ENHANCED
    async fn serve_range_from_cache(
        method: Method,
        range_spec: &RangeSpec,
        overlap: &crate::range_handler::RangeOverlap,
        cache_key: &str,
        cache_manager: Arc<CacheManager>,
        range_handler: Arc<RangeHandler>,
    ) -> std::result::Result<Response<Full<Bytes>>, Infallible>;
}
```

## Data Models

### RangeMergeSegment (New)

```rust
/// Represents a segment of data to be merged
#[derive(Debug, Clone)]
pub struct RangeMergeSegment {
    /// Absolute start position in the final merged output
    pub output_start: u64,
    /// Absolute end position in the final merged output
    pub output_end: u64,
    /// Source of this segment
    pub source: RangeMergeSource,
}

#[derive(Debug, Clone)]
pub enum RangeMergeSource {
    /// Data from cache with range metadata
    Cached {
        range: Range,
        /// Offset within the cached range to start reading
        read_offset: u64,
        /// Number of bytes to read from cached range
        read_length: u64,
    },
    /// Data fetched from S3
    Fetched {
        data: Vec<u8>,
        range_spec: RangeSpec,
    },
}
```

### RangeMergeResult (New)

```rust
/// Result of range merging operation with metrics
#[derive(Debug)]
pub struct RangeMergeResult {
    /// Merged data ready to send to client
    pub data: Vec<u8>,
    /// Number of bytes served from cache
    pub bytes_from_cache: u64,
    /// Number of bytes fetched from S3
    pub bytes_from_s3: u64,
    /// Number of segments merged
    pub segments_merged: usize,
    /// Cache efficiency percentage (0-100)
    pub cache_efficiency: f64,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Merged data completeness
*For any* requested range and any combination of cached and fetched ranges, the merged output size SHALL equal the requested range size (end - start + 1)
**Validates: Requirements 2.4**

### Property 2: Merged data correctness
*For any* requested range that can be fully served (cached or fetched), the merged output SHALL be byte-identical to fetching the entire range from S3
**Validates: Requirements 2.1**

### Property 3: Byte order preservation
*For any* set of range segments being merged, the output SHALL contain bytes in ascending order matching the requested range
**Validates: Requirements 2.1**

### Property 4: Cached range extraction correctness
*For any* cached range that overlaps with a requested range, extracting the overlapping portion SHALL return the correct byte offsets from the cached data
**Validates: Requirements 2.2, 2.3**

### Property 5: Missing range minimization
*For any* set of missing ranges, consolidating them SHALL result in fewer or equal S3 requests while covering the same byte ranges
**Validates: Requirements 1.2**

### Property 6: No unnecessary S3 fetches
*For any* requested range where all bytes are cached (possibly in non-contiguous ranges), the system SHALL NOT contact S3
**Validates: Requirements 1.3**

### Property 7: Fetched data caching
*For any* bytes fetched from S3 to fill missing ranges, those bytes SHALL be cached for future requests
**Validates: Requirements 1.4**

### Property 8: Range alignment validation
*For any* merge operation, if byte alignment errors are detected, the system SHALL log the error and fall back to fetching the complete range from S3
**Validates: Requirements 2.5**

### Property 9: Cache efficiency calculation
*For any* merge operation, the cache efficiency percentage SHALL equal (bytes_from_cache / total_bytes) * 100
**Validates: Requirements 3.5**

### Property 10: Consolidation gap threshold
*For any* two missing ranges separated by a gap smaller than the threshold, consolidating them SHALL merge them into a single range
**Validates: Requirements 1.2**

## Error Handling

### Error Scenarios

1. **Cached Range File Missing**
   - Detection: `load_range_data()` returns file not found error
   - Recovery: Mark range as missing, fetch from S3, recache
   - Logging: Error level with cache key and range

2. **Decompression Failure**
   - Detection: Decompression returns error
   - Recovery: Invalidate corrupted cache entry, fetch from S3
   - Logging: Error level with compression algorithm and file path

3. **Byte Alignment Mismatch**
   - Detection: Merged data size doesn't match requested range size
   - Recovery: Log error, fetch complete range from S3
   - Logging: Error level with expected vs actual sizes

4. **S3 Fetch Failure**
   - Detection: S3 client returns error
   - Recovery: Return error to client (cannot serve without S3 data)
   - Logging: Error level with S3 error details

5. **Partial Merge Failure**
   - Detection: Some segments merge successfully, others fail
   - Recovery: Fall back to fetching complete range from S3
   - Logging: Warn level with partial success details

### Error Recovery Strategy

```rust
async fn merge_ranges_with_fallback(
    &self,
    requested_range: &RangeSpec,
    overlap: &RangeOverlap,
    // ... other params
) -> Result<Vec<u8>> {
    match self.merge_ranges(requested_range, &overlap.cached_ranges, &fetched_ranges).await {
        Ok(merged_data) => {
            // Validate merged data size
            let expected_size = requested_range.end - requested_range.start + 1;
            if merged_data.len() as u64 != expected_size {
                error!(
                    "Merge validation failed: expected {} bytes, got {} bytes",
                    expected_size, merged_data.len()
                );
                // Fall back to complete S3 fetch
                return self.fetch_complete_range_from_s3(requested_range, ...).await;
            }
            Ok(merged_data)
        }
        Err(e) => {
            error!("Range merge failed: {}, falling back to complete S3 fetch", e);
            self.fetch_complete_range_from_s3(requested_range, ...).await
        }
    }
}
```

## Testing Strategy

### Unit Tests

1. **Range Extraction Tests**
   - Test extracting bytes from cached range with full containment
   - Test extracting bytes from cached range with partial overlap
   - Test extracting bytes from cached range at boundaries
   - Test error handling for invalid offsets

2. **Range Consolidation Tests**
   - Test consolidating adjacent missing ranges
   - Test consolidating ranges with small gaps
   - Test not consolidating ranges with large gaps
   - Test consolidating multiple ranges into minimal set

3. **Range Merging Tests**
   - Test merging single cached range
   - Test merging multiple contiguous cached ranges
   - Test merging cached and fetched ranges
   - Test merging with gaps (should fail validation)
   - Test merging with overlaps (should deduplicate)

### Property-Based Tests

```rust
#[quickcheck]
fn prop_merge_completeness(
    requested_start: u64,
    requested_size: u64,
    cached_ranges: Vec<(u64, u64)>,
) -> bool {
    // Generate test data
    let requested_end = requested_start + requested_size - 1;
    let requested_range = RangeSpec { start: requested_start, end: requested_end };
    
    // Simulate merge operation
    let merged_data = merge_ranges_test_helper(&requested_range, &cached_ranges);
    
    // Property: merged data size must equal requested size
    merged_data.len() as u64 == requested_size
}

#[quickcheck]
fn prop_merge_correctness(
    requested_start: u64,
    requested_size: u64,
    full_data: Vec<u8>,
) -> bool {
    // Split full_data into random cached ranges
    let cached_ranges = split_into_random_ranges(&full_data, requested_start);
    
    // Merge the ranges
    let merged_data = merge_ranges_test_helper(
        &RangeSpec { start: requested_start, end: requested_start + requested_size - 1 },
        &cached_ranges
    );
    
    // Property: merged data must match original data
    let expected = &full_data[requested_start as usize..(requested_start + requested_size) as usize];
    merged_data == expected
}

#[quickcheck]
fn prop_consolidation_minimizes_requests(
    missing_ranges: Vec<(u64, u64)>,
    max_gap: u64,
) -> bool {
    let consolidated = consolidate_missing_ranges(missing_ranges.clone(), max_gap);
    
    // Property: consolidated ranges should be <= original count
    consolidated.len() <= missing_ranges.len()
}

#[quickcheck]
fn prop_no_s3_fetch_when_fully_cached(
    requested_range: RangeSpec,
    cached_ranges: Vec<Range>,
) -> bool {
    // Ensure cached_ranges fully cover requested_range
    let fully_covered = covers_range(&cached_ranges, &requested_range);
    
    if fully_covered {
        let overlap = find_cached_ranges(&requested_range, &cached_ranges);
        // Property: should be able to serve from cache
        overlap.can_serve_from_cache && overlap.missing_ranges.is_empty()
    } else {
        true // Skip test if not fully covered
    }
}
```

### Integration Tests

1. **Multipart Upload Followed by GET**
   - Upload 100MB file via multipart (13 parts)
   - Immediately GET the file
   - Verify: Served entirely from cache
   - Verify: No S3 fetch occurred
   - Verify: Response is byte-identical to uploaded data

2. **Partial Cache Hit Scenario**
   - Cache ranges: 0-8MB, 16-24MB, 32-40MB
   - Request: 0-40MB
   - Verify: Only missing ranges (8-16MB, 24-32MB) fetched from S3
   - Verify: Response is complete and correct
   - Verify: Missing ranges are now cached

3. **Non-Aligned Range Request**
   - Cache ranges: 0-8388607, 8388608-16777215 (8MB boundaries)
   - Request: 1000000-10000000 (crosses boundary)
   - Verify: Served from cached ranges without S3 fetch
   - Verify: Correct bytes extracted from each cached range

4. **Cache Efficiency Metrics**
   - Request with 80% cache hit
   - Verify: Metrics show 80% from cache, 20% from S3
   - Verify: Logging shows correct byte counts

## Performance Considerations

### Optimization 1: Parallel S3 Fetches

When multiple missing ranges need to be fetched, fetch them in parallel:

```rust
async fn fetch_missing_ranges(
    &self,
    missing_ranges: &[RangeSpec],
    // ... other params
) -> Result<Vec<(RangeSpec, Vec<u8>)>> {
    // Fetch all missing ranges in parallel
    let fetch_futures: Vec<_> = missing_ranges
        .iter()
        .map(|range| self.fetch_single_range(range, ...))
        .collect();
    
    let results = futures::future::join_all(fetch_futures).await;
    
    // Collect successful fetches
    results.into_iter()
        .filter_map(|r| r.ok())
        .collect()
}
```

### Optimization 2: Gap Threshold Tuning

The `max_gap_size` parameter for range consolidation should be tuned based on:
- Network latency vs bandwidth tradeoff
- Typical S3 request overhead (~50-100ms)
- Cost of fetching extra bytes vs making extra requests

**Recommended default: 256KB**
- Rationale: If gap < 256KB, fetching extra bytes is faster than making another request

### Optimization 3: Memory-Efficient Merging

For large ranges, avoid loading all data into memory at once:

```rust
async fn merge_ranges_streaming(
    &self,
    requested_range: &RangeSpec,
    segments: &[RangeMergeSegment],
) -> Result<Vec<u8>> {
    let total_size = (requested_range.end - requested_range.start + 1) as usize;
    let mut output = Vec::with_capacity(total_size);
    
    for segment in segments {
        match &segment.source {
            RangeMergeSource::Cached { range, read_offset, read_length } => {
                // Load only the needed portion
                let data = self.load_range_data_partial(range, *read_offset, *read_length).await?;
                output.extend_from_slice(&data);
            }
            RangeMergeSource::Fetched { data, .. } => {
                output.extend_from_slice(data);
            }
        }
    }
    
    Ok(output)
}
```

### Optimization 4: Cache Warming

After fetching missing ranges, cache them immediately for future requests:

```rust
async fn cache_fetched_ranges(
    &self,
    cache_key: &str,
    fetched_ranges: &[(RangeSpec, Vec<u8>)],
    object_metadata: &ObjectMetadata,
) -> Result<()> {
    // Cache all fetched ranges in parallel
    let cache_futures: Vec<_> = fetched_ranges
        .iter()
        .map(|(range_spec, data)| {
            self.disk_cache_manager.lock().await.store_range(
                cache_key,
                range_spec.start,
                range_spec.end,
                data,
                object_metadata.clone(),
            )
        })
        .collect();
    
    futures::future::join_all(cache_futures).await;
    Ok(())
}
```

## Logging and Observability

### Log Levels and Messages

**INFO Level:**
```rust
info!(
    "Range merge completed: cache_key={}, requested={}-{}, segments={}, cache_efficiency={:.2}%, bytes_from_cache={}, bytes_from_s3={}, duration={:.2}ms",
    cache_key, start, end, segments_merged, cache_efficiency, bytes_from_cache, bytes_from_s3, duration_ms
);
```

**DEBUG Level:**
```rust
debug!(
    "Extracting bytes from cached range: cached_range={}-{}, requested={}-{}, extract_offset={}, extract_length={}",
    cached_start, cached_end, requested_start, requested_end, offset, length
);
```

**WARN Level:**
```rust
warn!(
    "Range merge validation failed: expected_size={}, actual_size={}, falling back to complete S3 fetch",
    expected_size, actual_size
);
```

**ERROR Level:**
```rust
error!(
    "Failed to load cached range data: cache_key={}, range={}-{}, error={}, recovery=fetch_from_s3",
    cache_key, start, end, error
);
```

### Metrics

New metrics to track:
- `range_merge_operations_total` - Counter of merge operations
- `range_merge_cache_efficiency` - Histogram of cache efficiency percentages
- `range_merge_segments_merged` - Histogram of segments per merge
- `range_merge_duration_seconds` - Histogram of merge operation duration
- `s3_fetch_bytes_saved` - Counter of bytes NOT fetched due to cache hits
- `range_consolidation_reduction` - Gauge of request reduction from consolidation

## Migration Strategy

### Phase 1: Add New Functions (Non-Breaking)

1. Implement `merge_ranges()` function
2. Implement `consolidate_missing_ranges()` function
3. Implement `extract_bytes_from_cached_range()` function
4. Add comprehensive unit tests

### Phase 2: Update HTTP Proxy (Breaking Change)

1. Modify `forward_range_request_to_s3()` to use overlap data
2. Update `serve_range_from_cache()` to support multiple ranges
3. Add integration tests

### Phase 3: Enable and Monitor

1. Deploy to staging environment
2. Monitor metrics and logs
3. Tune `max_gap_size` parameter
4. Deploy to production with gradual rollout

### Rollback Plan

If issues arise:
1. Feature flag to disable range merging
2. Fall back to current behavior (fetch entire range from S3)
3. Investigate and fix issues
4. Re-enable with fixes

## Security Considerations

1. **Byte Range Validation**
   - Validate that merged data doesn't exceed requested range
   - Prevent buffer overflows in merge operations
   - Validate all offsets are within bounds

2. **Cache Poisoning Prevention**
   - Verify ETag matches across all cached ranges
   - Invalidate cache if ETag mismatch detected
   - Use atomic file operations to prevent partial writes

3. **Resource Limits**
   - Limit maximum number of ranges to merge (e.g., 100)
   - Limit maximum total size of merge operation (e.g., 5GB)
   - Prevent memory exhaustion from large merges

## Future Enhancements

1. **Multi-Range Response Support**
   - Support `multipart/byteranges` responses
   - Handle multiple non-contiguous ranges in single request

2. **Predictive Range Caching**
   - Analyze access patterns
   - Pre-fetch likely-to-be-requested ranges
   - Optimize range boundaries based on usage

3. **Adaptive Gap Threshold**
   - Dynamically adjust `max_gap_size` based on network conditions
   - Learn optimal threshold from historical performance

4. **Range Compression Optimization**
   - Compress merged ranges before caching
   - Use different compression for different range sizes
