# Requirements Document: Intelligent Range Merging for Partial Cache Hits

## Introduction

Currently, when a GET request requires a range that is partially cached (some bytes cached, some missing), the proxy forwards the entire range request to S3 instead of only fetching the missing portions. This results in unnecessary S3 bandwidth usage and slower response times. This feature will implement intelligent range merging to serve cached portions and only fetch missing bytes from S3.

## Glossary

- **Range Request**: An HTTP GET request with a Range header specifying byte ranges
- **Partial Cache Hit**: When some but not all requested bytes are available in cache
- **Range Overlap**: The intersection between requested ranges and cached ranges
- **Missing Range**: A byte range that is requested but not available in cache
- **Range Merging**: The process of combining multiple range segments into a single response
- **S3 Proxy**: The caching proxy server that sits between clients and S3

## Requirements

### Requirement 1

**User Story:** As a proxy operator, I want the system to minimize S3 bandwidth usage, so that I can reduce costs and improve performance.

#### Acceptance Criteria

1. WHEN a range request has partial cache coverage THEN the S3 Proxy SHALL fetch only the missing byte ranges from S3
2. WHEN multiple missing ranges exist THEN the S3 Proxy SHALL consolidate them into minimal S3 requests
3. WHEN all requested bytes are cached in non-contiguous ranges THEN the S3 Proxy SHALL serve the response without contacting S3
4. WHEN fetching missing ranges from S3 THEN the S3 Proxy SHALL cache the fetched data for future requests
5. WHEN merging cached and fetched ranges THEN the S3 Proxy SHALL preserve byte order and alignment

### Requirement 2

**User Story:** As a client application, I want to receive correct byte ranges, so that my downloads are not corrupted.

#### Acceptance Criteria

1. WHEN the S3 Proxy merges multiple range segments THEN the system SHALL return bytes in the correct order matching the requested range
2. WHEN cached ranges overlap with requested ranges THEN the system SHALL extract the correct byte offsets from each cached range
3. WHEN a cached range fully contains the requested range THEN the system SHALL extract only the requested portion
4. WHEN merging ranges THEN the system SHALL validate that the total response size matches the requested range size
5. WHEN byte alignment errors occur THEN the system SHALL log the error and fetch the complete range from S3

### Requirement 3

**User Story:** As a system administrator, I want detailed logging of range merging operations, so that I can troubleshoot caching issues.

#### Acceptance Criteria

1. WHEN the system performs range merging THEN the S3 Proxy SHALL log the number of cached segments used
2. WHEN the system fetches missing ranges THEN the S3 Proxy SHALL log the byte ranges fetched from S3
3. WHEN range merging completes THEN the S3 Proxy SHALL log the total bytes served from cache versus S3
4. WHEN range merging fails THEN the S3 Proxy SHALL log detailed error information including which ranges failed
5. WHEN calculating cache efficiency THEN the S3 Proxy SHALL report the percentage of bytes served from cache

### Requirement 4

**User Story:** As a developer, I want the range merging logic to be testable, so that I can verify correctness.

#### Acceptance Criteria

1. WHEN testing range merging THEN the system SHALL provide a function to merge byte vectors from multiple sources
2. WHEN testing range extraction THEN the system SHALL provide a function to extract byte ranges from cached data
3. WHEN testing range consolidation THEN the system SHALL provide a function to identify minimal S3 fetch ranges
4. WHEN testing end-to-end THEN the system SHALL support property-based tests for range merging correctness
5. WHEN testing edge cases THEN the system SHALL handle empty ranges, single-byte ranges, and maximum-size ranges

### Requirement 5

**User Story:** As a proxy operator, I want the system to handle multipart upload finalization efficiently, so that subsequent GET requests are fully cached.

#### Acceptance Criteria

1. WHEN a multipart upload is finalized THEN the S3 Proxy SHALL create range files that align with common request patterns
2. WHEN creating range files from multipart parts THEN the S3 Proxy SHALL use atomic file operations to prevent race conditions
3. WHEN a GET request follows multipart upload completion THEN the S3 Proxy SHALL serve the request entirely from cache
4. WHEN range files are created THEN the S3 Proxy SHALL compress the data before writing to disk
5. WHEN range metadata is written THEN the S3 Proxy SHALL ensure all range files exist before writing the metadata file
