# Implementation Plan: Intelligent Range Merging

- [x] 1. Implement core range merging data structures and utilities
  - Create `RangeMergeSegment` and `RangeMergeSource` types in `range_handler.rs`
  - Create `RangeMergeResult` type for tracking merge metrics
  - Add helper functions for range overlap calculations
  - _Requirements: 1.1, 2.1, 3.5_

- [ ]* 1.1 Write property test for range overlap calculations
  - **Property 1: Merged data completeness**
  - **Validates: Requirements 2.4**

- [x] 2. Implement byte extraction from cached ranges
  - Add `extract_bytes_from_cached_range()` method to `RangeHandler`
  - Handle full containment case (cached range fully contains requested range)
  - Handle partial overlap case (cached range partially overlaps requested range)
  - Handle boundary cases (start/end alignment)
  - Add validation for offset and length parameters
  - _Requirements: 2.2, 2.3_

- [ ]* 2.1 Write property test for cached range extraction
  - **Property 4: Cached range extraction correctness**
  - **Validates: Requirements 2.2, 2.3**

- [ ]* 2.2 Write unit tests for byte extraction edge cases
  - Test extraction at range boundaries
  - Test extraction with zero-length ranges
  - Test extraction with invalid offsets
  - _Requirements: 2.2, 2.3, 4.5_

- [x] 3. Implement missing range consolidation
  - Add `consolidate_missing_ranges()` method to `RangeHandler`
  - Implement gap threshold logic (default 256KB)
  - Sort missing ranges by start position
  - Merge ranges with gaps smaller than threshold
  - Return minimal set of consolidated ranges
  - _Requirements: 1.2_

- [ ]* 3.1 Write property test for range consolidation
  - **Property 5: Missing range minimization**
  - **Validates: Requirements 1.2**

- [ ]* 3.2 Write property test for consolidation gap threshold
  - **Property 10: Consolidation gap threshold**
  - **Validates: Requirements 1.2**

- [ ]* 3.3 Write unit tests for consolidation edge cases
  - Test consolidating adjacent ranges
  - Test consolidating ranges with large gaps (should not merge)
  - Test consolidating single range (should return unchanged)
  - Test consolidating empty list (should return empty)
  - _Requirements: 1.2, 4.5_

- [x] 4. Implement range merging logic
  - Add `merge_ranges()` method to `RangeHandler`
  - Create merge plan from cached and fetched ranges
  - Sort segments by output position
  - Extract bytes from each segment
  - Concatenate segments in order
  - Validate merged data size matches requested range size
  - Calculate cache efficiency metrics
  - _Requirements: 1.5, 2.1, 2.4, 3.5_

- [ ]* 4.1 Write property test for merge completeness
  - **Property 1: Merged data completeness**
  - **Validates: Requirements 2.4**

- [ ]* 4.2 Write property test for merge correctness
  - **Property 2: Merged data correctness**
  - **Validates: Requirements 2.1**

- [ ]* 4.3 Write property test for byte order preservation
  - **Property 3: Byte order preservation**
  - **Validates: Requirements 2.1**

- [ ]* 4.4 Write unit tests for merge edge cases
  - Test merging single cached range
  - Test merging multiple contiguous ranges
  - Test merging with gaps (should fail validation)
  - Test merging with overlaps (should handle correctly)
  - _Requirements: 2.1, 2.4, 4.5_

- [x] 5. Implement parallel S3 fetch for missing ranges
  - Add `fetch_missing_ranges()` method to `RangeHandler`
  - Create S3 request for each missing range
  - Execute fetches in parallel using `futures::join_all`
  - Collect successful fetches with their range specs
  - Handle fetch failures gracefully
  - Cache fetched ranges immediately
  - _Requirements: 1.1, 1.4_

- [ ]* 5.1 Write unit tests for parallel fetch logic
  - Test fetching single missing range
  - Test fetching multiple missing ranges in parallel
  - Test handling partial fetch failures
  - _Requirements: 1.1, 1.4_

- [x] 6. Update `serve_range_from_cache()` to support multiple ranges
  - Remove "not implemented" error for multiple cached ranges
  - Call `merge_ranges()` when multiple cached ranges exist
  - Add validation for merged data size
  - Add logging for merge operations
  - Calculate and log cache efficiency metrics
  - _Requirements: 1.3, 2.1, 3.1, 3.3, 3.5_

- [ ]* 6.1 Write property test for no unnecessary S3 fetches
  - **Property 6: No unnecessary S3 fetches**
  - **Validates: Requirements 1.3**

- [x] 7. Update `forward_range_request_to_s3()` to use overlap data
  - Remove underscore prefix from `overlap` parameter (stop ignoring it)
  - Check if `overlap.missing_ranges` is empty (fully cached case)
  - If fully cached, call `serve_range_from_cache()` instead of S3 fetch
  - If partially cached, consolidate missing ranges
  - Fetch only consolidated missing ranges from S3
  - Merge cached and fetched ranges
  - Cache fetched ranges for future requests
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

- [ ]* 7.1 Write property test for fetched data caching
  - **Property 7: Fetched data caching**
  - **Validates: Requirements 1.4**

- [x] 8. Add comprehensive error handling and fallback logic
  - Implement `merge_ranges_with_fallback()` wrapper
  - Add validation for merged data size
  - Fall back to complete S3 fetch on merge failure
  - Add error logging with detailed context
  - Handle cached range file missing errors
  - Handle decompression failures
  - Handle byte alignment mismatches
  - _Requirements: 2.5, 8.2 (from design)_

- [ ]* 8.1 Write property test for range alignment validation
  - **Property 8: Range alignment validation**
  - **Validates: Requirements 2.5**

- [ ]* 8.2 Write unit tests for error recovery
  - Test fallback to S3 on merge failure
  - Test fallback on cached file missing
  - Test fallback on decompression failure
  - Test fallback on size mismatch
  - _Requirements: 2.5_

- [x] 9. Add logging and metrics for range merging operations
  - Add INFO level logging for merge completion with metrics
  - Add DEBUG level logging for byte extraction operations
  - Add WARN level logging for validation failures
  - Add ERROR level logging for merge failures
  - Implement cache efficiency calculation
  - Log bytes served from cache vs S3
  - Log number of segments merged
  - Log merge operation duration
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [ ]* 9.1 Write property test for cache efficiency calculation
  - **Property 9: Cache efficiency calculation**
  - **Validates: Requirements 3.5**

- [x] 10. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 11. Add integration test for multipart upload followed by GET
  - Create test that uploads 100MB file via multipart (13 parts)
  - Immediately GET the file after upload completes
  - Verify response is served entirely from cache (no S3 fetch)
  - Verify response is byte-identical to uploaded data
  - Verify cache efficiency is 100%
  - _Requirements: 5.3_

- [x] 12. Add integration test for partial cache hit scenario
  - Create test with specific cached ranges (0-8MB, 16-24MB, 32-40MB)
  - Request full range (0-40MB)
  - Verify only missing ranges (8-16MB, 24-32MB) are fetched from S3
  - Verify response is complete and correct
  - Verify missing ranges are now cached
  - Verify cache efficiency is approximately 60%
  - _Requirements: 1.1, 1.2, 1.4, 1.5_

- [x] 13. Add integration test for non-aligned range request
  - Create test with cached ranges at 8MB boundaries
  - Request range that crosses boundaries (e.g., 1MB-10MB)
  - Verify request is served from cached ranges without S3 fetch
  - Verify correct bytes are extracted from each cached range
  - Verify response is byte-identical to S3 response
  - _Requirements: 1.3, 2.2, 2.3_

- [x] 14. Add integration test for range consolidation
  - Create test with multiple small missing ranges
  - Verify ranges with small gaps are consolidated into fewer S3 requests
  - Verify ranges with large gaps are NOT consolidated
  - Verify all missing bytes are fetched correctly
  - _Requirements: 1.2_

- [x] 15. Final Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 16. Add configuration for gap threshold tuning
  - Add `range_merge_gap_threshold` config option (default: 256KB)
  - Document configuration in config.example.yaml
  - Pass threshold to `consolidate_missing_ranges()`
  - _Requirements: 1.2_

- [x] 17. Update documentation
  - Update CACHING.md with range merging behavior
  - Add section on cache efficiency optimization
  - Document gap threshold configuration
  - Add examples of partial cache hit scenarios
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
