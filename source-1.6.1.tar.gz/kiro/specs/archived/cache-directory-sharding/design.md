# Design Document: Cache Directory Sharding

## Overview

This design implements bucket-first hash-based directory sharding for the S3 proxy cache to support tens of millions of cached objects without filesystem performance degradation. The solution uses BLAKE3 hashing to uniformly distribute files across a hierarchical directory structure organized by bucket.

**Key Design Principles:**
- Bucket-first organization enables per-bucket cache management
- BLAKE3 hashing provides fast, uniform distribution
- Two-level hierarchy (XX/YYY) supports billions of files per bucket
- Clean filenames without bucket name redundancy
- Breaking change with no backward compatibility

## Architecture

### Directory Structure

```
cache_dir/
├── objects/                    # Metadata files
│   ├── {bucket}/              # S3 bucket name
│   │   ├── {XX}/              # First 2 hex digits of BLAKE3(object_key)
│   │   │   ├── {YYY}/         # Next 3 hex digits of BLAKE3(object_key)
│   │   │   │   ├── {object_key}.meta
│   │   │   │   └── ...
│   │   │   └── ...
│   │   └── ...
│   └── ...
└── ranges/                     # Range binary files
    ├── {bucket}/
    │   ├── {XX}/
    │   │   ├── {YYY}/
    │   │   │   ├── {object_key}_{start}-{end}.bin
    │   │   │   └── ...
    │   │   └── ...
    │   └── ...
    └── ...
```

### Cache Key Format

**Format:** `bucket:object_key`

**Examples:**
- `my-bucket:path/to/object`
- `my-bucket:file.txt`
- `my.bucket.name:deeply/nested/path/file.tar.gz`

**Parsing:**
- Split on first `:` to extract bucket and object key
- Bucket becomes directory name (used as-is, no encoding)
- Object key is hashed for sharding and sanitized for filename

### Hash-Based Sharding

**Hash Function:** BLAKE3
- 10x faster than SHA-256
- Cryptographically secure
- Excellent distribution properties
- License: CC0-1.0 OR Apache-2.0

**Directory Levels:**
- Level 1: First 2 hex digits → 256 directories
- Level 2: Next 3 hex digits → 4,096 subdirectories per L1
- Total: 1,048,576 leaf directories per bucket

**Capacity:**
- Maximum: 10.5B files per bucket (10,000 files/directory limit)
- Optimal: 2.6B files per bucket (40% safety margin)
- Example: 100M objects × 10 ranges = 1.1B files → ~1,049 files/directory

## Components and Interfaces

### 1. Path Resolution Module

**New Functions:**

```rust
/// Parse cache key into bucket and object key
fn parse_cache_key(cache_key: &str) -> Result<(&str, &str)>

/// Get sharded path for cache file
fn get_sharded_path(
    base_dir: &Path,
    cache_key: &str,
    suffix: &str,
) -> Result<PathBuf>

/// Sanitize object key for filename
fn sanitize_object_key_for_filename(
    object_key: &str,
    suffix: &str,
) -> String
```

**Implementation:**

```rust
fn parse_cache_key(cache_key: &str) -> Result<(&str, &str)> {
    cache_key.split_once(':')
        .ok_or_else(|| ProxyError::CacheError(
            format!("Invalid cache key format: {}", cache_key)
        ))
}

fn get_sharded_path(
    base_dir: &Path,
    cache_key: &str,
    suffix: &str,
) -> Result<PathBuf> {
    let (bucket, object_key) = parse_cache_key(cache_key)?;
    
    // Hash object key only (not bucket)
    let hash = blake3::hash(object_key.as_bytes());
    let hash_hex = hash.to_hex();
    
    // Extract directory levels
    let level1 = &hash_hex[0..2];   // 2 hex digits
    let level2 = &hash_hex[2..5];   // 3 hex digits
    
    // Sanitize object key for filename
    let filename = sanitize_object_key_for_filename(object_key, suffix);
    
    // Construct path: base_dir/bucket/XX/YYY/filename
    Ok(base_dir
        .join(bucket)
        .join(level1)
        .join(level2)
        .join(filename))
}

fn sanitize_object_key_for_filename(object_key: &str, suffix: &str) -> String {
    use percent_encoding::{utf8_percent_encode, AsciiSet, CONTROLS};
    
    const FRAGMENT: &AsciiSet = &CONTROLS
        .add(b' ').add(b'/').add(b'\\').add(b':')
        .add(b'*').add(b'?').add(b'"').add(b'<')
        .add(b'>').add(b'|').add(b'%');
    
    let sanitized = utf8_percent_encode(object_key, FRAGMENT).to_string();
    
    // Max filename length: 200 chars (reserve space for suffix)
    if sanitized.len() > 200 {
        // Use BLAKE3 hash for long keys (64 hex chars)
        let hash = blake3::hash(object_key.as_bytes());
        format!("{}{}", hash.to_hex(), suffix)
    } else {
        format!("{}{}", sanitized, suffix)
    }
}
```

### 2. DiskCacheManager Updates

**Modified Methods:**

```rust
impl DiskCacheManager {
    /// Get metadata file path (updated for sharding)
    pub fn get_new_metadata_file_path(&self, cache_key: &str) -> Result<PathBuf> {
        get_sharded_path(&self.cache_dir.join("objects"), cache_key, ".meta")
    }
    
    /// Get range file path (updated for sharding)
    pub fn get_new_range_file_path(&self, cache_key: &str, start: u64, end: u64) -> Result<PathBuf> {
        let suffix = format!("_{}-{}.bin", start, end);
        get_sharded_path(&self.cache_dir.join("ranges"), cache_key, &suffix)
    }
    
    /// Initialize cache directory structure
    pub async fn initialize(&self) -> Result<()> {
        // Create base directories only (not flat subdirectories)
        for subdir in &["objects", "ranges", "locks", "head_cache"] {
            let subdir_path = self.cache_dir.join(subdir);
            if !subdir_path.exists() {
                std::fs::create_dir_all(&subdir_path)?;
            }
        }
        Ok(())
    }
    
    /// Store range with new sharded paths
    pub async fn store_range(
        &mut self,
        cache_key: &str,
        start: u64,
        end: u64,
        data: &[u8],
        object_metadata: ObjectMetadata,
    ) -> Result<()> {
        // Use get_new_range_file_path which now uses sharding
        let range_file_path = self.get_new_range_file_path(cache_key, start, end)?;
        
        // Create parent directories if needed
        if let Some(parent) = range_file_path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        
        // ... rest of implementation
    }
}
```

### 3. BLAKE3 Integration

**Dependency Addition:**

```toml
# Cargo.toml
[dependencies]
blake3 = "1.5"
```

**Usage:**

```rust
use blake3;

// Hash for directory sharding
let hash = blake3::hash(object_key.as_bytes());
let hash_hex = hash.to_hex();

// Hash for long filenames
let hash = blake3::hash(object_key.as_bytes());
let filename = format!("{}.meta", hash.to_hex());
```

## Data Models

### Existing Types (Unchanged)

```rust
pub struct NewCacheMetadata {
    pub cache_key: String,
    pub object_metadata: ObjectMetadata,
    pub ranges: Vec<RangeSpec>,
    pub created_at: SystemTime,
    pub expires_at: SystemTime,
    pub compression_info: CompressionInfo,
}

pub struct RangeSpec {
    pub start: u64,
    pub end: u64,
    pub file_path: String,  // Relative path to .bin file
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
    pub created_at: SystemTime,
    pub last_accessed: SystemTime,
    pub access_count: u64,
    pub expires_at: SystemTime,
}
```

**Note:** The `file_path` in `RangeSpec` will now contain paths like `bucket_XX_YYY_object_0-8388607.bin` (relative to ranges directory).

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Bucket-first path structure
*For any* cache key with format `bucket:object_key`, the resulting path should have bucket as the first directory level after the base directory (objects or ranges)
**Validates: Requirements 1.1, 1.2**

### Property 2: Hash-based directory distribution
*For any* object key, the hash directories should be derived from BLAKE3(object_key) with first 2 hex digits as level 1 and next 3 hex digits as level 2
**Validates: Requirements 2.1, 2.2**

### Property 3: Same object key, same hash directories
*For any* two cache keys with different buckets but same object key, they should resolve to the same XX/YYY hash directories but different bucket directories
**Validates: Requirements 2.3**

### Property 4: Hash determinism
*For any* cache key, computing the path multiple times should always produce identical results
**Validates: Requirements 2.4, 5.4**

### Property 5: Uniform hash distribution
*For any* set of 100,000 random object keys, the distribution across hash directories should have standard deviation within 10% of the expected uniform distribution
**Validates: Requirements 2.5**

### Property 6: Filename excludes bucket name
*For any* cache key, the resulting filename should not contain the bucket name, only the sanitized object key
**Validates: Requirements 3.1, 3.2**

### Property 7: Filesystem-unsafe character encoding
*For any* object key containing filesystem-unsafe characters (space, /, \, :, *, ?, ", <, >, |, %), the filename should have these characters percent-encoded
**Validates: Requirements 3.3**

### Property 8: Long key hash filename
*For any* object key that exceeds 200 characters after percent-encoding, the filename should be exactly 64 hex characters (BLAKE3 hash) plus the extension
**Validates: Requirements 3.4, 3.5**

### Property 9: BLAKE3 usage for sharding
*For any* cache key, the directory hash should be computed using BLAKE3, not SHA-256
**Validates: Requirements 4.2, 4.3**

### Property 10: Invalid cache key error handling
*For any* string without a colon, parse_cache_key should return an error indicating invalid format
**Validates: Requirements 5.2**

### Property 11: Automatic directory creation
*For any* cache key, storing a file should automatically create all parent directories if they don't exist
**Validates: Requirements 5.3**

### Property 12: Metadata storage path correctness
*For any* cache key, storing metadata should write to `objects/{bucket}/{XX}/{YYY}/{object_key}.meta`
**Validates: Requirements 6.1**

### Property 13: Metadata round-trip
*For any* cache key and metadata, storing then retrieving metadata should return equivalent data
**Validates: Requirements 6.2**

### Property 14: Atomic metadata writes
*For any* metadata write operation, a .tmp file should be created first, then atomically renamed to .meta
**Validates: Requirements 6.3**

### Property 15: Relative range file paths
*For any* metadata containing range specifications, the range file paths should be relative (not absolute)
**Validates: Requirements 6.4**

### Property 16: Graceful metadata corruption handling
*For any* corrupted or missing metadata file, the system should return a cache miss without crashing
**Validates: Requirements 6.5**

### Property 17: Range storage path correctness
*For any* cache key and byte range, storing a range should write to `ranges/{bucket}/{XX}/{YYY}/{object_key}_{start}-{end}.bin`
**Validates: Requirements 7.1**

### Property 18: Range round-trip
*For any* cache key and byte range data, storing then retrieving the range should return equivalent data
**Validates: Requirements 7.2**

### Property 19: Atomic range writes
*For any* range write operation, a .tmp file should be created first, then atomically renamed to .bin
**Validates: Requirements 7.3**

### Property 20: Separate range files
*For any* object with multiple byte ranges, each range should be stored in a separate .bin file
**Validates: Requirements 7.4**

### Property 21: Range cache miss behavior
*For any* cache key with missing range files, the system should treat it as a cache miss and fetch from S3
**Validates: Requirements 7.5**

### Property 22: Bucket-first structure usage
*For any* cache operation (store, retrieve, invalidate), the system should use the bucket-first sharded path structure
**Validates: Requirements 8.2, 8.3**

### Property 23: Cache invalidation cleanup
*For any* cache key, invalidating should remove both metadata and range files from the sharded paths
**Validates: Requirements 8.4**

### Property 24: Orphaned file cleanup traversal
*For any* cleanup operation, the system should traverse the bucket-first directory structure to find orphaned files
**Validates: Requirements 8.5**

### Property 25: Cache miss repopulation
*For any* cache key not in cache, the system should fetch from S3 and populate the cache using sharded paths
**Validates: Requirements 9.2**

### Property 26: GET request sharding
*For any* GET request, cached responses should be stored using the bucket-first sharded structure
**Validates: Requirements 10.1**

### Property 27: HEAD request sharding
*For any* HEAD request, cached metadata should be stored using the bucket-first sharded structure
**Validates: Requirements 10.2**

### Property 28: Range request sharding
*For any* range request, cached byte ranges should be stored using the bucket-first sharded structure
**Validates: Requirements 10.3**

### Property 29: Multi-directory distribution
*For any* set of 1000 stored objects, they should be distributed across multiple hash directories (not all in one)
**Validates: Requirements 12.3**

### Property 30: Lazy bucket directory creation
*For any* bucket, the bucket directory should be created only when the first object for that bucket is stored
**Validates: Requirements 13.3**

### Property 31: Lazy hash directory creation
*For any* hash shard, the hash directories should be created only when the first object mapping to that shard is stored
**Validates: Requirements 13.4**

## Error Handling

### Error Types

```rust
pub enum CacheShardingError {
    InvalidCacheKey(String),
    HashComputationFailed(String),
    DirectoryCreationFailed(String),
    FileOperationFailed(String),
}
```

### Error Scenarios

1. **Invalid Cache Key Format**
   - Missing colon separator
   - Empty bucket or object key
   - Return: `InvalidCacheKey` error

2. **Directory Creation Failure**
   - Insufficient permissions
   - Disk full
   - Return: `DirectoryCreationFailed` error

3. **File Operation Failure**
   - Atomic write failure
   - File lock timeout
   - Return: `FileOperationFailed` error

4. **Corrupted Metadata**
   - Invalid JSON
   - Missing required fields
   - Action: Treat as cache miss, log warning

## Testing Strategy

### Unit Tests

**Path Resolution Tests:**
- Test `parse_cache_key` with valid and invalid formats
- Test `get_sharded_path` produces correct structure
- Test `sanitize_object_key_for_filename` handles special characters
- Test long key hashing uses BLAKE3

**Hash Distribution Tests:**
- Generate 100K random keys
- Verify uniform distribution (chi-squared test)
- Verify deterministic hashing

**Edge Case Tests:**
- Bucket names with periods and hyphens
- Object keys with special characters
- Very long object keys (>200 chars)
- Cache keys with multiple colons

### Integration Tests

**End-to-End Tests:**
- Store and retrieve metadata using sharded paths
- Store and retrieve ranges using sharded paths
- Test multiple buckets with same object keys
- Test cache invalidation removes all files
- Test orphaned file cleanup

**Multi-Bucket Tests:**
- Store objects in multiple buckets
- Verify bucket directories are separate
- Verify same object keys in different buckets work correctly

### Property-Based Tests

Using `quickcheck` framework:

```rust
#[quickcheck]
fn prop_path_determinism(cache_key: String) -> bool {
    if !cache_key.contains(':') { return true; }
    let path1 = get_sharded_path(&PathBuf::from("cache"), &cache_key, ".meta");
    let path2 = get_sharded_path(&PathBuf::from("cache"), &cache_key, ".meta");
    path1 == path2
}

#[quickcheck]
fn prop_bucket_first_structure(bucket: String, object_key: String) -> bool {
    let cache_key = format!("{}:{}", bucket, object_key);
    if let Ok(path) = get_sharded_path(&PathBuf::from("cache"), &cache_key, ".meta") {
        path.to_string_lossy().contains(&bucket)
    } else {
        true
    }
}

#[quickcheck]
fn prop_filename_excludes_bucket(bucket: String, object_key: String) -> bool {
    let cache_key = format!("{}:{}", bucket, object_key);
    if let Ok(path) = get_sharded_path(&PathBuf::from("cache"), &cache_key, ".meta") {
        let filename = path.file_name().unwrap().to_str().unwrap();
        !filename.contains(&bucket)
    } else {
        true
    }
}
```

## Performance Considerations

### Lookup Performance

**Flat Structure (baseline):**
- O(n) directory scan for 10M files
- 10-100ms typical latency

**Sharded Structure:**
- O(1) hash computation: ~1μs (BLAKE3)
- O(1) directory traversal: 3 levels (base/bucket/XX/YYY)
- O(log 1000) inode lookup: ~10 comparisons
- <1ms typical latency

**Improvement:** 10-100x faster

### Write Performance

**Additional Overhead:**
- BLAKE3 hash: ~1μs
- Directory creation: Amortized O(1)
- Total impact: <1% overhead

### Space Overhead

**Directory Inodes:**
- Per bucket: 256 + (256 × 4,096) = 1,049,088 directories
- Inode size: ~256 bytes
- Total per bucket: ~268 MB

**Impact:** Negligible for modern filesystems

## Migration Strategy

### Clean Slate Deployment

1. Deploy new version with sharded structure
2. Cache starts empty
3. Cache repopulates on demand from S3
4. No migration tool needed
5. Zero downtime (cache misses fetch from S3)

**Rationale:**
- Simplest approach with no migration complexity
- Cache naturally repopulates with most-accessed objects first
- No risk of migration errors or data corruption
- Immediate benefit from new structure

## Dependencies

### New Dependencies

```toml
[dependencies]
blake3 = "1.5"
```

### License Compliance

**BLAKE3 License:** CC0-1.0 OR Apache-2.0 OR Apache-2.0 WITH LLVM-exception
- No GPL or copyleft restrictions
- Compatible with project's Apache-2.0 license
- No attribution required under CC0-1.0 option

**Action Required:**
- Update `LICENSE_COMPLIANCE_REPORT.md` with BLAKE3 information

## Implementation Notes

### Scope Limitations

**In Scope:**
- Read caching (GET, HEAD, range requests)
- Metadata file sharding
- Range file sharding
- DiskCacheManager updates

**Out of Scope:**
- Write caching (PUT operations)
- Migration tool
- Backward compatibility
- Performance benchmarking tools

### Breaking Changes

This is a breaking change:
- Old cache files will not be read
- Cache will be empty after upgrade
- No fallback to flat structure
- Users should expect cache repopulation period

### Future Enhancements

**Potential Improvements:**
- Dynamic shard depth based on load
- Per-bucket cache statistics
- Shard rebalancing tools
- Cache warming utilities
