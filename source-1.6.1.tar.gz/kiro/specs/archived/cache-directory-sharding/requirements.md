# Requirements Document

## Introduction

Implement bucket-first hash-based directory sharding for the S3 proxy cache to support tens of millions of cached objects without filesystem performance degradation. Modern filesystems experience significant slowdowns when directories contain more than 10,000 files. The current flat directory structure will become a bottleneck as cache usage scales.

This is a breaking change that replaces the existing flat cache structure with a hierarchical bucket-first organization using BLAKE3 hashing for uniform distribution.

## Glossary

- **Cache Key**: Format `bucket:object_key` used to identify cached objects
- **Bucket**: S3 bucket name (first part of cache key before `:`)
- **Object Key**: S3 object path within bucket (part after `:` in cache key)
- **Metadata File**: JSON file (`.meta`) containing object metadata and range tracking
- **Range File**: Binary file (`.bin`) containing cached byte range data
- **Leaf Directory**: Final directory level containing actual cache files
- **BLAKE3**: Cryptographic hash function used for directory sharding
- **Sharding**: Distributing files across multiple directories based on hash
- **Read Caching**: Caching GET and HEAD requests (excludes write caching/PUT operations)

## Requirements

### Requirement 1: Bucket-First Directory Structure

**User Story:** As a system administrator, I want the cache organized by bucket first, so that I can manage cache on a per-bucket basis.

#### Acceptance Criteria

1. WHEN the cache stores files THEN the system SHALL organize them as `{type}/{bucket}/{XX}/{YYY}/{filename}` where type is "objects" or "ranges"
2. WHEN parsing a cache key THEN the system SHALL split on the first colon to extract bucket and object key separately
3. WHEN creating directory paths THEN the system SHALL use the bucket name directly as a directory name without encoding
4. WHEN a bucket name contains periods or hyphens THEN the system SHALL use them as-is since S3 naming rules ensure filesystem safety
5. WHEN clearing cache for a bucket THEN the system SHALL support removing all files via `rm -rf cache_dir/{type}/{bucket}/`

### Requirement 2: BLAKE3 Hash-Based Sharding

**User Story:** As a developer, I want uniform file distribution across directories, so that no single directory becomes a performance bottleneck.

#### Acceptance Criteria

1. WHEN computing directory paths THEN the system SHALL hash only the object key using BLAKE3 (excluding bucket name)
2. WHEN extracting directory levels THEN the system SHALL use the first 2 hex digits for level 1 and next 3 hex digits for level 2
3. WHEN the same object key exists in different buckets THEN the system SHALL place them in the same hash directories but different bucket directories
4. WHEN hashing object keys THEN the system SHALL produce deterministic results for the same input
5. WHEN distributing 100K random object keys THEN the system SHALL achieve uniform distribution with standard deviation within 10% of expected value

### Requirement 3: Filename Conventions

**User Story:** As a developer, I want clean, readable filenames, so that debugging and troubleshooting are easier.

#### Acceptance Criteria

1. WHEN creating metadata filenames THEN the system SHALL use format `{sanitized_object_key}.meta` without bucket name
2. WHEN creating range filenames THEN the system SHALL use format `{sanitized_object_key}_{start}-{end}.bin` without bucket name
3. WHEN sanitizing object keys THEN the system SHALL percent-encode filesystem-unsafe characters (space, /, \, :, *, ?, ", <, >, |, %)
4. WHEN an object key exceeds 200 characters after encoding THEN the system SHALL use the full BLAKE3 hash (64 hex chars) as the filename
5. WHEN using hash as filename THEN the system SHALL ensure the filename is exactly 64 hex characters plus extension

### Requirement 4: BLAKE3 Integration

**User Story:** As a developer, I want fast, secure hashing, so that cache operations remain performant at scale.

#### Acceptance Criteria

1. WHEN adding dependencies THEN the system SHALL include `blake3 = "1.5"` in Cargo.toml
2. WHEN hashing for directory sharding THEN the system SHALL use BLAKE3 instead of SHA-256
3. WHEN hashing long object keys for filenames THEN the system SHALL use BLAKE3 instead of SHA-256
4. WHEN computing hashes THEN the system SHALL achieve at least 10x faster performance than SHA-256
5. WHEN the system starts THEN the system SHALL verify BLAKE3 is available and functional

### Requirement 5: Path Resolution

**User Story:** As a developer, I want consistent path resolution, so that cache lookups always find the correct files.

#### Acceptance Criteria

1. WHEN resolving a cache key to a path THEN the system SHALL parse bucket and object key, compute hash, and construct path in one operation
2. WHEN the cache key format is invalid THEN the system SHALL return an error indicating the expected format
3. WHEN constructing paths THEN the system SHALL create parent directories automatically if they don't exist
4. WHEN the same cache key is resolved multiple times THEN the system SHALL return identical paths
5. WHEN resolving paths THEN the system SHALL complete in under 10 microseconds for typical keys

### Requirement 6: Metadata File Updates

**User Story:** As a developer, I want metadata files in the new structure, so that range tracking works correctly.

#### Acceptance Criteria

1. WHEN storing metadata THEN the system SHALL write to `objects/{bucket}/{XX}/{YYY}/{object_key}.meta`
2. WHEN reading metadata THEN the system SHALL look up files using the new path structure
3. WHEN metadata files are written THEN the system SHALL use atomic operations (write to .tmp, then rename)
4. WHEN metadata contains range specifications THEN the system SHALL reference range files using relative paths
5. WHEN metadata is corrupted or missing THEN the system SHALL handle gracefully without crashing

### Requirement 7: Range File Updates

**User Story:** As a developer, I want range files in the new structure, so that cached byte ranges are properly organized.

#### Acceptance Criteria

1. WHEN storing ranges THEN the system SHALL write to `ranges/{bucket}/{XX}/{YYY}/{object_key}_{start}-{end}.bin`
2. WHEN reading ranges THEN the system SHALL look up files using the new path structure
3. WHEN range files are written THEN the system SHALL use atomic operations (write to .tmp, then rename)
4. WHEN multiple ranges exist for an object THEN the system SHALL store each in a separate .bin file
5. WHEN range files are missing THEN the system SHALL treat as cache miss and fetch from S3

### Requirement 8: DiskCacheManager Updates

**User Story:** As a developer, I want the disk cache manager to use the new structure, so that all cache operations work correctly.

#### Acceptance Criteria

1. WHEN DiskCacheManager initializes THEN the system SHALL NOT create flat subdirectories (objects, ranges as leaf directories)
2. WHEN storing cache entries THEN the system SHALL use the new bucket-first sharded paths
3. WHEN retrieving cache entries THEN the system SHALL use the new bucket-first sharded paths
4. WHEN invalidating cache entries THEN the system SHALL remove files from the new bucket-first sharded paths
5. WHEN cleaning up orphaned files THEN the system SHALL traverse the new directory structure

### Requirement 9: Breaking Change Migration

**User Story:** As a system administrator, I want clear guidance on migration, so that I can transition to the new cache structure.

#### Acceptance Criteria

1. WHEN deploying the new version THEN the system SHALL NOT attempt to read from old flat structure
2. WHEN the cache is empty after deployment THEN the system SHALL repopulate from S3 on cache misses
3. WHEN documentation is provided THEN the system SHALL include migration options (clean slate, offline migration, parallel cache)
4. WHEN a migration tool is provided THEN the system SHALL support dry-run mode for validation
5. WHEN migration completes THEN the system SHALL verify all files are in the new structure

### Requirement 10: Read Caching Only

**User Story:** As a developer, I want to focus on read caching, so that the implementation scope is manageable.

#### Acceptance Criteria

1. WHEN implementing sharding THEN the system SHALL update GET request caching paths
2. WHEN implementing sharding THEN the system SHALL update HEAD request caching paths
3. WHEN implementing sharding THEN the system SHALL update range request caching paths
4. WHEN implementing sharding THEN the system SHALL NOT modify write caching (PUT operations)
5. WHEN write caching is disabled THEN the system SHALL NOT create write_cache directories

### Requirement 11: Testing and Validation

**User Story:** As a developer, I want comprehensive tests, so that the new structure works reliably.

#### Acceptance Criteria

1. WHEN testing path resolution THEN the system SHALL verify bucket-first structure is correct
2. WHEN testing with multiple buckets THEN the system SHALL verify files are separated by bucket directory
3. WHEN testing hash distribution THEN the system SHALL verify uniform distribution across 100K keys
4. WHEN testing edge cases THEN the system SHALL handle bucket names with periods and hyphens
5. WHEN testing long object keys THEN the system SHALL verify BLAKE3 hash is used as filename

### Requirement 12: Performance Requirements

**User Story:** As a system administrator, I want fast cache operations, so that the proxy remains performant.

#### Acceptance Criteria

1. WHEN looking up cache files THEN the system SHALL complete in under 1 millisecond
2. WHEN computing BLAKE3 hashes THEN the system SHALL complete in under 10 microseconds
3. WHEN storing 1000 objects THEN the system SHALL distribute them across multiple directories
4. WHEN a directory contains 10,000 files THEN the system SHALL maintain lookup performance
5. WHEN the cache contains 100M files THEN the system SHALL maintain sub-millisecond lookup times

### Requirement 13: Cache Initialization

**User Story:** As a system administrator, I want the cache to initialize with the new structure, so that it works correctly from first use.

#### Acceptance Criteria

1. WHEN the cache directory is empty THEN the system SHALL create the base objects and ranges directories
2. WHEN the cache directory exists THEN the system SHALL use the new bucket-first structure for all operations
3. WHEN bucket directories don't exist THEN the system SHALL create them on first write for that bucket
4. WHEN hash directories don't exist THEN the system SHALL create them on first write to that shard
5. WHEN the system starts THEN the system SHALL NOT require any migration or compatibility checks

### Requirement 14: Cache Expiration

**User Story:** As a system administrator, I want cached entries to expire based on TTL, so that stale data is automatically removed.

#### Acceptance Criteria

1. WHEN storing metadata THEN the system SHALL set expires_at based on configured TTL
2. WHEN storing ranges THEN the system SHALL set per-range expires_at based on configured TTL
3. WHEN reading metadata THEN the system SHALL check if expires_at has passed and treat as cache miss if expired
4. WHEN reading ranges THEN the system SHALL check if range expires_at has passed and skip expired ranges
5. WHEN an entry expires THEN the system SHALL remove associated files during next access or cleanup

### Requirement 15: Cache Invalidation

**User Story:** As a developer, I want to invalidate cache entries, so that updated objects are fetched from S3.

#### Acceptance Criteria

1. WHEN invalidating a cache entry THEN the system SHALL remove the metadata file from `objects/{bucket}/{XX}/{YYY}/`
2. WHEN invalidating a cache entry THEN the system SHALL remove all associated range files from `ranges/{bucket}/{XX}/{YYY}/`
3. WHEN invalidation fails for a file THEN the system SHALL log a warning but continue with other files
4. WHEN invalidating by bucket THEN the system SHALL support removing entire bucket directory
5. WHEN ETag changes THEN the system SHALL invalidate existing cache entries for that object

### Requirement 16: Orphaned File Cleanup

**User Story:** As a system administrator, I want orphaned files cleaned up, so that disk space is not wasted.

#### Acceptance Criteria

1. WHEN cleaning up orphaned files THEN the system SHALL traverse `ranges/{bucket}/{XX}/{YYY}/` directories
2. WHEN a range file exists without corresponding metadata THEN the system SHALL remove the orphaned range file
3. WHEN a .tmp file exists THEN the system SHALL remove it as it indicates a failed write
4. WHEN cleaning up THEN the system SHALL log the number of orphaned files removed
5. WHEN cleanup completes THEN the system SHALL report total disk space reclaimed

### Requirement 17: Per-Bucket Cache Management

**User Story:** As a system administrator, I want to manage cache per bucket, so that I can control storage usage by tenant.

#### Acceptance Criteria

1. WHEN querying bucket cache stats THEN the system SHALL count files in `objects/{bucket}/` and `ranges/{bucket}/`
2. WHEN clearing bucket cache THEN the system SHALL remove `objects/{bucket}/` and `ranges/{bucket}/` directories
3. WHEN listing cached buckets THEN the system SHALL enumerate top-level directories under `objects/` and `ranges/`
4. WHEN calculating bucket disk usage THEN the system SHALL sum file sizes recursively under bucket directories
5. WHEN a bucket is cleared THEN the system SHALL log the number of files and bytes removed

### Requirement 18: Capacity Management

**User Story:** As a system administrator, I want to monitor cache capacity, so that I can prevent disk exhaustion.

#### Acceptance Criteria

1. WHEN checking directory capacity THEN the system SHALL count files per leaf directory and warn if approaching 10,000
2. WHEN disk space is low THEN the system SHALL log warnings and optionally trigger eviction
3. WHEN storing files THEN the system SHALL handle "disk full" errors gracefully without corrupting cache
4. WHEN capacity limits are reached THEN the system SHALL provide metrics on which buckets/directories are largest
5. WHEN monitoring THEN the system SHALL track total files, total bytes, and files per directory distribution

### Requirement 19: Partial Eviction Support

**User Story:** As a developer, I want to evict specific ranges, so that I can free space without removing entire objects.

#### Acceptance Criteria

1. WHEN deleting specific ranges THEN the system SHALL remove only the specified .bin files
2. WHEN deleting ranges THEN the system SHALL update metadata to remove range specifications
3. WHEN deleting the last range THEN the system SHALL keep metadata file for object tracking
4. WHEN deletion fails for a range file THEN the system SHALL log warning but continue with metadata update
5. WHEN batch deleting ranges THEN the system SHALL update metadata once for all deletions

### Requirement 20: License Compliance

**User Story:** As a project maintainer, I want to ensure license compatibility, so that the project remains legally compliant.

#### Acceptance Criteria

1. WHEN adding BLAKE3 THEN the system SHALL document its license (CC0-1.0 OR Apache-2.0)
2. WHEN updating LICENSE_COMPLIANCE_REPORT.md THEN the system SHALL include BLAKE3 license information
3. WHEN BLAKE3 is used THEN the system SHALL ensure no GPL or copyleft restrictions apply
4. WHEN distributing the software THEN the system SHALL comply with BLAKE3's Apache-2.0 license option
5. WHEN attribution is required THEN the system SHALL include appropriate notices
