# Implementation Plan

- [x] 1. Add BLAKE3 dependency and update license documentation
  - Add `blake3 = "1.5"` to Cargo.toml dependencies
  - Update LICENSE_COMPLIANCE_REPORT.md with BLAKE3 license info (CC0-1.0 OR Apache-2.0)
  - Verify BLAKE3 compiles and is available
  - _Requirements: 4.1, 14.1, 14.2_

- [x] 2. Implement path resolution functions
  - [x] 2.1 Implement `parse_cache_key()` function
    - Split cache key on first colon
    - Return bucket and object key as tuple
    - Return error for invalid format (no colon)
    - _Requirements: 1.2, 5.2_
  
  - [x] 2.2 Implement `sanitize_object_key_for_filename()` function
    - Percent-encode filesystem-unsafe characters
    - Handle long keys (>200 chars) with BLAKE3 hash
    - Return sanitized filename with suffix
    - _Requirements: 3.3, 3.4, 3.5_
  
  - [x] 2.3 Implement `get_sharded_path()` function
    - Parse cache key to extract bucket and object key
    - Compute BLAKE3 hash of object key only
    - Extract first 2 hex digits for level 1, next 3 for level 2
    - Construct path: base_dir/bucket/XX/YYY/filename
    - _Requirements: 1.1, 2.1, 2.2, 5.1_
  
  - [ ]* 2.4 Write property test for path determinism
    - **Property 4: Hash determinism**
    - **Validates: Requirements 2.4, 5.4**
  
  - [ ]* 2.5 Write property test for bucket-first structure
    - **Property 1: Bucket-first path structure**
    - **Validates: Requirements 1.1, 1.2**
  
  - [ ]* 2.6 Write property test for filename excludes bucket
    - **Property 6: Filename excludes bucket name**
    - **Validates: Requirements 3.1, 3.2**
  
  - [ ]* 2.7 Write unit tests for edge cases
    - Test bucket names with periods and hyphens
    - Test object keys with special characters
    - Test very long object keys (>200 chars)
    - Test invalid cache key formats
    - _Requirements: 1.4, 3.3, 3.4, 5.2_

- [x] 3. Update DiskCacheManager path methods
  - [x] 3.1 Update `get_new_metadata_file_path()` to use sharding
    - Replace flat path logic with `get_sharded_path()`
    - Use "objects" as base directory
    - Use ".meta" as suffix
    - _Requirements: 6.1_
  
  - [x] 3.2 Update `get_new_range_file_path()` to use sharding
    - Replace flat path logic with `get_sharded_path()`
    - Use "ranges" as base directory
    - Use "_{start}-{end}.bin" as suffix
    - _Requirements: 7.1_
  
  - [x] 3.3 Update `initialize()` to not create flat subdirectories
    - Remove creation of flat "objects", "ranges" subdirectories
    - Only create base directories: "objects", "ranges", "locks", "head_cache"
    - Do not create bucket or hash directories (lazy creation)
    - _Requirements: 8.1, 13.1_
  
  - [ ]* 3.4 Write integration test for path methods
    - Test metadata path generation
    - Test range path generation
    - Verify bucket-first structure
    - _Requirements: 6.1, 7.1_

- [x] 4. Update DiskCacheManager storage operations
  - [x] 4.1 Update `store_range()` to create parent directories
    - Ensure parent directories are created before writing
    - Use `std::fs::create_dir_all()` for lazy directory creation
    - Handle directory creation errors gracefully
    - _Requirements: 5.3, 13.3, 13.4_
  
  - [x] 4.2 Verify atomic write operations still work
    - Ensure .tmp files are created in correct sharded paths
    - Verify atomic rename to final path
    - Test with multiple buckets
    - _Requirements: 6.3, 7.3_
  
  - [ ]* 4.3 Write property test for metadata round-trip
    - **Property 13: Metadata round-trip**
    - **Validates: Requirements 6.2**
  
  - [ ]* 4.4 Write property test for range round-trip
    - **Property 18: Range round-trip**
    - **Validates: Requirements 7.2**

- [x] 5. Update DiskCacheManager retrieval operations
  - [x] 5.1 Update `get_metadata()` to use sharded paths
    - Use new `get_new_metadata_file_path()` for lookups
    - Handle missing files as cache miss
    - _Requirements: 6.2_
  
  - [x] 5.2 Update `get_range()` to use sharded paths
    - Use new `get_new_range_file_path()` for lookups
    - Handle missing files as cache miss
    - _Requirements: 7.2, 7.5_
  
  - [ ]* 5.3 Write property test for cache miss behavior
    - **Property 21: Range cache miss behavior**
    - **Validates: Requirements 7.5**
  
  - [ ]* 5.4 Write property test for graceful error handling
    - **Property 16: Graceful metadata corruption handling**
    - **Validates: Requirements 6.5**

- [x] 6. Update DiskCacheManager invalidation operations
  - [x] 6.1 Update `invalidate_cache_entry()` to use sharded paths
    - Use new path methods for file removal
    - Remove both metadata and range files
    - Handle missing files gracefully
    - _Requirements: 8.4_
  
  - [x] 6.2 Update orphaned file cleanup to traverse new structure
    - Update `cleanup_orphaned_files()` to traverse bucket/XX/YYY structure
    - Handle multiple buckets
    - Clean up empty directories
    - _Requirements: 8.5_
  
  - [ ]* 6.3 Write integration test for invalidation
    - **Property 23: Cache invalidation cleanup**
    - **Validates: Requirements 8.4**

- [ ] 7. Replace SHA-256 with BLAKE3 for long keys
  - [x] 7.1 Update `sanitize_cache_key_new()` to use BLAKE3
    - Replace `sha2::Sha256` with `blake3::hash()`
    - Keep same logic for >200 char threshold
    - Update format string to use BLAKE3 hash
    - _Requirements: 4.3_
  
  - [ ]* 7.2 Write property test for BLAKE3 usage
    - **Property 9: BLAKE3 usage for sharding**
    - **Validates: Requirements 4.2, 4.3**
  
  - [ ]* 7.3 Write unit test for long key hashing
    - **Property 8: Long key hash filename**
    - **Validates: Requirements 3.4, 3.5**

- [x] 8. Update range file path references in metadata
  - [x] 8.1 Verify RangeSpec file_path is relative
    - Check that range file paths in metadata are relative
    - Update if needed to use relative paths
    - _Requirements: 6.4_
  
  - [ ]* 8.2 Write property test for relative paths
    - **Property 15: Relative range file paths**
    - **Validates: Requirements 6.4**

- [x] 9. Test hash distribution quality
  - [x]* 9.1 Write property test for uniform distribution
    - **Property 5: Uniform hash distribution**
    - Generate 100K random object keys
    - Verify distribution across hash directories
    - Use chi-squared test for uniformity
    - **Validates: Requirements 2.5**
  
  - [x]* 9.2 Write property test for same object key in different buckets
    - **Property 3: Same object key, same hash directories**
    - **Validates: Requirements 2.3**
  
  - [x]* 9.3 Write property test for multi-directory distribution
    - **Property 29: Multi-directory distribution**
    - Store 1000 objects and verify spread across directories
    - **Validates: Requirements 12.3**

- [x] 10. Integration testing with multiple buckets
  - [ ]* 10.1 Write integration test for multiple buckets
    - Store objects in multiple buckets
    - Verify bucket directories are separate
    - Verify same object keys work in different buckets
    - _Requirements: 1.1, 2.3_
  
  - [ ]* 10.2 Write integration test for bucket cleanup
    - Store objects in a bucket
    - Remove bucket directory
    - Verify all files are gone
    - _Requirements: 1.5_

- [x] 11. Test read caching operations
  - [ ]* 11.1 Write integration test for GET request caching
    - **Property 26: GET request sharding**
    - Verify GET responses use sharded paths
    - **Validates: Requirements 10.1**
  
  - [ ]* 11.2 Write integration test for HEAD request caching
    - **Property 27: HEAD request sharding**
    - Verify HEAD metadata uses sharded paths
    - **Validates: Requirements 10.2**
  
  - [ ]* 11.3 Write integration test for range request caching
    - **Property 28: Range request sharding**
    - Verify range requests use sharded paths
    - **Validates: Requirements 10.3**

- [x] 12. Final integration testing
  - [ ]* 12.1 Write end-to-end integration test
    - Store metadata and ranges
    - Retrieve and verify data
    - Invalidate and verify cleanup
    - Test with multiple buckets
    - _Requirements: 1.1, 6.2, 7.2, 8.4_
  
  - [ ]* 12.2 Write test for lazy directory creation
    - **Property 30: Lazy bucket directory creation**
    - **Property 31: Lazy hash directory creation**
    - Verify directories created only when needed
    - **Validates: Requirements 13.3, 13.4**

- [x] 13. Documentation updates
  - [x] 13.1 Update docs/CACHING.md with new structure
    - Document bucket-first hierarchy
    - Explain hash-based sharding
    - Provide examples
    - _Requirements: 9.3_
  
  - [x] 13.2 Update README.md if needed
    - Mention cache structure change
    - Note breaking change
    - _Requirements: 9.3_

- [x] 14. Update cleanup methods to traverse sharded structure
  - [x] 14.1 Update `cleanup_temp_files()` to traverse bucket/XX/YYY structure
    - Replace flat directory scan with recursive traversal
    - Scan ranges/bucket/XX/YYY/ for .tmp files
    - Scan objects/bucket/XX/YYY/ for .meta.tmp files
    - Follow same pattern as `cleanup_orphaned_files()`
    - _Requirements: 8.5_
  
  - [x] 14.2 Update `perform_cache_cleanup()` to traverse bucket/XX/YYY structure
    - Replace flat directory scans with recursive traversal
    - Traverse ranges/bucket/XX/YYY/ for orphaned .bin files
    - Traverse objects/bucket/XX/YYY/ for orphaned .meta files
    - Handle multiple buckets correctly
    - Clean up empty directories after cleanup
    - _Requirements: 8.5_
  
  - [x] 14.3 Update edge case tests to work with sharded paths
    - Fix `test_bin_file_deletion_on_eviction` to use proper cache flow
    - Fix `test_meta_file_deletion_on_last_range_eviction` to use proper cache flow
    - Fix `test_multiple_range_eviction_meta_deletion` to use proper cache flow
    - Tests should use CacheManager for both storing and evicting
    - _Requirements: 8.4, 8.5_

- [x] 15. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
