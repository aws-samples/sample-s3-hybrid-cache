# Range Cache Retrieval Fix - Implementation Tasks

## Problem Statement
Range cache entries are being stored successfully but never retrieved, causing all range requests to go to S3 even when data is cached. The issue is that ranges are stored in separate cache entries with range-specific keys, but lookups only check the main cache entry's ranges vector.

## Root Cause
- Ranges stored with keys like: `host:/path:range:0-8388607`
- Main cache entry has key: `host:/path`
- `find_cached_ranges` only checks main entry's ranges vector
- `add_range_to_existing_cache_entry` tries to maintain ranges in main entry but it's not working
- Result: "cached: 0, missing: 1" on every request, even iteration 2+

## Tasks

- [x] 1. Fix range storage to use main cache entry only
  - Modify `store_range_in_cache` to store ranges in main cache entry's ranges vector
  - Remove creation of separate range-specific cache entries
  - Ensure main cache entry is created if it doesn't exist
  - _Requirements: 3.1, 3.2, 3.3_

- [x] 2. Simplify range retrieval logic
  - Remove `get_range_from_cache` lookup for range-specific entries
  - Rely solely on main cache entry's ranges vector
  - Ensure `find_cached_ranges` correctly identifies overlapping ranges
  - _Requirements: 3.2, 3.3_

- [ ] 3. Test range caching with AWS CLI
  - Clear cache and restart proxy
  - Run test with 10MB file, 3 iterations
  - Verify iteration 1 goes to S3 (cache miss)
  - Verify iterations 2-3 serve from cache (no S3 requests)
  - Verify cache hit performance is orders of magnitude faster
  - _Requirements: 2.2, 3.1_

- [ ] 4. Verify full object and range request handling
  - Test full object GET request (no range header)
  - Test range request for partial object
  - Test range request that spans multiple cached ranges
  - Verify correct combination of cached + origin data
  - _Requirements: 2.1, 3.1, 3.4_
