# Requirements: Outstanding Work

## 1. High Priority - Critical Correctness

### 1.1 Full Object Range Replacement
**Type**: Implementation  
**Priority**: Critical  
**Source**: Cache Invalidation spec, Requirement 2.9

When a full object GET response is cached, the system SHALL detect and remove any existing partial range files for that object to prevent serving stale partial ranges.

**Acceptance Criteria**:
- System detects existing range files when caching full object
- All partial range files are removed before storing full object
- Metadata is updated to reflect full object storage
- Operation is logged with object key and range count

### 1.2 ETag Validation in Range Requests
**Type**: Implementation  
**Priority**: Critical  
**Source**: Cache Invalidation spec, Requirement 3.3

The system SHALL pass current ETag from HEAD response to range lookup functions to enable ETag validation of cached ranges.

**Acceptance Criteria**:
- HEAD response ETag is extracted and passed to find_cached_ranges()
- Cached ranges with mismatched ETags are treated as missing
- ETag mismatches are logged with object key and range details
- No stale ranges are served to clients

### 1.3 HTTP Date Parsing
**Type**: Implementation  
**Priority**: Critical  
**Source**: Code TODO in src/cache.rs

The system SHALL implement proper HTTP date parsing and comparison for If-Modified-Since and If-Unmodified-Since conditional request headers.

**Acceptance Criteria**:
- HTTP date strings are parsed according to RFC 7231
- Date comparisons are performed correctly
- Invalid date formats are handled gracefully
- Conditional requests work correctly with cache validation

## 2. Medium Priority - Property-Based Testing

### 2.1 RAM-Disk Cache Coherency Tests
**Type**: Testing  
**Priority**: Medium  
**Source**: RAM-Disk Cache Coherency spec

The system SHALL validate all correctness properties through property-based tests using quickcheck framework.

**Acceptance Criteria**:
- 20 property tests implemented covering all requirements
- 3 integration tests for end-to-end scenarios
- 3 unit tests for configuration validation
- All tests pass with minimum 100 quickcheck iterations

### 2.2 Cache Invalidation Tests
**Type**: Testing  
**Priority**: Medium  
**Source**: Cache Invalidation and Lookup spec

The system SHALL validate cache consistency mechanisms through property-based tests.

**Acceptance Criteria**:
- 7 property tests implemented covering all requirements
- Tests validate HEAD cache invalidation, range replacement, ETag handling
- All tests pass with minimum 100 quickcheck iterations

### 2.3 Distributed Eviction Lock Tests
**Type**: Testing  
**Priority**: Medium  
**Source**: Distributed Eviction Lock spec

The system SHALL validate multi-instance coordination through property-based and integration tests.

**Acceptance Criteria**:
- 8 property tests for lock correctness properties
- 2 unit tests for metrics and error handling
- 2 integration tests for multi-instance scenarios
- All tests pass with minimum 100 quickcheck iterations

### 2.4 Cache Key Simplification Tests
**Type**: Testing  
**Priority**: Medium  
**Source**: Cache Key Simplification spec

The system SHALL validate cache key format changes through property-based tests.

**Acceptance Criteria**:
- 8 property tests for key uniqueness, format, portability
- 1 integration test for cross-endpoint caching
- 1 performance test measuring improvements
- All tests pass with minimum 100 quickcheck iterations

## 3. Low Priority - Code Cleanup

### 3.1 Remove HTTPS Self-Signed Mode
**Type**: Cleanup  
**Priority**: Low  
**Source**: Product simplification

The system SHALL remove the self-signed TLS termination mode for HTTPS, keeping only TCP passthrough mode.

**Acceptance Criteria**:
- Self-signed TLS termination code is removed from https_proxy.rs
- TLS certificate generation code is removed from tls.rs
- HttpsMode enum only contains Passthrough variant
- Configuration no longer accepts "selfsigned" mode
- Tests for self-signed mode are removed
- Documentation is updated to reflect passthrough-only mode

## 4. Low Priority - Observability

### 4.1 Compression Timing Metrics
**Type**: Enhancement  
**Priority**: Low  
**Source**: Code TODO in src/metrics.rs:430

The system SHALL track compression operation timing for observability.

**Acceptance Criteria**:
- Compression duration is measured in milliseconds
- Metric is exposed via HTTP metrics endpoint
- Metric is included in OTLP export if enabled

### 4.2 Idle Connection Tracking
**Type**: Enhancement  
**Priority**: Low  
**Source**: Code TODO in src/metrics.rs:449

The system SHALL track idle connections in the connection pool.

**Acceptance Criteria**:
- Idle connection count is tracked separately from active
- Metric is exposed via HTTP metrics endpoint
- Metric is included in OTLP export if enabled

### 4.3 DNS Refresh Tracking
**Type**: Enhancement  
**Priority**: Low  
**Source**: Code TODO in src/metrics.rs:482

The system SHALL track DNS refresh operations for monitoring.

**Acceptance Criteria**:
- DNS refresh count is incremented on each refresh
- Metric is exposed via HTTP metrics endpoint
- Metric is included in OTLP export if enabled

### 4.4 Throughput Calculation
**Type**: Enhancement  
**Priority**: Low  
**Source**: Code TODO in src/s3_client.rs:469

The system SHALL calculate request throughput based on request/response size.

**Acceptance Criteria**:
- Throughput is calculated as bytes per second
- Calculation includes both request and response sizes
- Metric is recorded in connection pool metrics

### 4.5 Cache Key Sanitization Verification
**Type**: Implementation  
**Priority**: Low  
**Source**: Cache Key Simplification spec, Task 6

The system SHALL verify cache key sanitization works correctly with the new format.

**Acceptance Criteria**:
- Sanitization produces collision-free filenames
- Shorter keys reduce SHA-256 hashing frequency
- File path generation works with new format
- Round-trip (sanitize → extract) preserves original key

## Requirements Summary

| Priority | Implementation | Testing | Total |
|----------|----------------|---------|-------|
| High | 3 | 0 | 3 |
| Medium | 0 | 43 | 43 |
| Low | 3 | 12 | 15 |
| **Total** | **6** | **55** | **61** |
