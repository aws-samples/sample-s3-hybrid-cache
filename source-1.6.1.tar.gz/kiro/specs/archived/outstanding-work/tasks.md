# Implementation Plan: Outstanding Work

## Phase 1: Critical Correctness (High Priority)

- [x] 1. Implement full object range replacement
  - [x] 1.1 Add range detection logic in store_response or forward_get_head_to_s3_and_cache
    - Query metadata to find existing cached ranges for object
    - Check if any ranges exist before storing full object
    - _Requirements: 1.1_
  
  - [x] 1.2 Implement range file deletion
    - Iterate through existing ranges in metadata
    - Delete each range file from disk
    - Log deletion with object key and range count
    - _Requirements: 1.1_
  
  - [x] 1.3 Update metadata after range deletion
    - Clear ranges array in metadata
    - Set upload_state to Complete
    - Store updated metadata
    - _Requirements: 1.1_
  
  - [x] 1.4 Add comprehensive logging
    - Log when partial ranges are detected
    - Log each range file deletion
    - Log completion with total ranges removed
    - _Requirements: 1.1_

- [x] 2. Implement ETag validation in range requests
  - [x] 2.1 Extract ETag from HEAD response
    - Get ETag header from HEAD response in forward_get_head_to_s3_and_cache
    - Handle missing ETag gracefully (use None)
    - _Requirements: 1.2_
  
  - [x] 2.2 Update find_cached_ranges signature
    - Add current_etag: Option<&str> parameter
    - Update all call sites to pass ETag
    - _Requirements: 1.2_
  
  - [x] 2.3 Implement ETag comparison in find_cached_ranges
    - Compare cached range ETag with current ETag
    - Skip ranges with mismatched ETags
    - Log ETag mismatches with details
    - _Requirements: 1.2_
  
  - [x] 2.4 Update range_handler.rs call sites
    - Pass ETag to all find_cached_ranges calls
    - Ensure compilation succeeds
    - _Requirements: 1.2_

- [x] 3. Implement HTTP date parsing
  - [x] 3.1 Add httpdate crate dependency
    - Add `httpdate = "1.0"` to Cargo.toml
    - Import parse_http_date function
    - _Requirements: 1.3_
  
  - [x] 3.2 Implement If-Modified-Since parsing
    - Parse client date string using parse_http_date
    - Parse cache last_modified date
    - Compare dates as SystemTime
    - Return false (not modified) if cache date <= client date
    - Handle parse errors gracefully (log warning, skip condition)
    - _Requirements: 1.3_
  
  - [x] 3.3 Implement If-Unmodified-Since parsing
    - Parse client date string using parse_http_date
    - Parse cache last_modified date
    - Compare dates as SystemTime
    - Return false (precondition failed) if cache date > client date
    - Handle parse errors gracefully (log warning, skip condition)
    - _Requirements: 1.3_
  
  - [x] 3.4 Add unit tests for date parsing
    - Test valid HTTP date formats
    - Test invalid date formats
    - Test boundary conditions
    - Test comparison logic
    - _Requirements: 1.3_

- [x] 4. Checkpoint - Verify critical fixes work
  - Run all existing tests
  - Manually test range replacement scenario
  - Manually test ETag validation scenario
  - Manually test conditional request scenarios
  - Ensure no regressions

## Phase 2: RAM-Disk Cache Coherency Tests (Medium Priority)

- [x] 5. Write property tests for AccessTracker
  - [x]* 5.1 Property 2: Access aggregation
    - Generate random sequence of access records
    - Record multiple accesses to same range
    - Verify access counts are aggregated correctly
    - Verify last_accessed timestamp is updated
    - **Validates: Requirements 1.3**
  
  - [x]* 5.2 Property 1: RAM hit tracking
    - Generate random cache hits
    - Verify all hits are recorded in pending_updates
    - Verify record_access completes within 1ms
    - **Validates: Requirements 1.1, 1.2, 1.4**

- [x] 6. Write property tests for eviction behavior
  - [x]* 6.1 Property 8: Eviction write-back
    - Generate RAM cache with pending updates
    - Trigger eviction with flush_on_eviction enabled
    - Verify pending updates are flushed immediately
    - **Validates: Requirements 6.1, 6.2, 6.5**
  
  - [x]* 6.2 Property 9: Eviction flush timeout
    - Generate RAM cache with pending updates
    - Trigger eviction with flush_on_eviction disabled
    - Verify eviction completes immediately without flushing
    - Verify pending updates remain in tracker
    - **Validates: Requirements 6.3, 6.4**

- [ ] 7. Write property tests for batch flushing
  - [ ]* 7.1 Property 4: Batch grouping
    - Generate random pending updates
    - Trigger batch flush
    - Verify all updates are grouped by cache_key
    - Verify batch_update_range_access is called for each key
    - **Validates: Requirements 2.4, 2.5**
  
  - [ ]* 7.2 Property 10: Metrics recording
    - Generate random flush operations
    - Verify batch_flush_count increments
    - Verify batch_flush_keys_updated is correct
    - Verify batch_flush_ranges_updated is correct
    - Verify batch_flush_avg_duration_ms is updated
    - **Validates: Requirements 5.1, 5.2, 5.4**
  
  - [ ]* 7.3 Property 3: Flush triggering
    - Generate pending updates below threshold
    - Verify flush is not triggered
    - Add updates to exceed threshold
    - Verify flush is triggered
    - Advance time past flush_interval
    - Verify flush is triggered
    - **Validates: Requirements 1.5, 2.3**
  
  - [ ]* 7.4 Property 11: Error logging
    - Generate flush operation that fails
    - Verify error is logged
    - Verify pending updates are retained
    - Verify proxy does not crash
    - **Validates: Requirements 5.3, 4.5**

- [ ] 8. Write property tests for file locking
  - [ ]* 8.1 Property 5: File locking
    - Simulate concurrent batch_update_range_access calls
    - Verify only one acquires lock at a time
    - Verify all updates are applied correctly
    - Verify no data corruption
    - **Validates: Requirements 3.1, 3.3, 3.4**
  
  - [ ]* 8.2 Property 6: Lock timeout handling
    - Simulate batch_update_range_access with held lock
    - Verify timeout occurs after 5 seconds
    - Verify warning is logged
    - Verify error is returned
    - **Validates: Requirements 3.2, 3.5**
  
  - [ ]* 8.3 Property 7: Missing file handling
    - Call batch_update_range_access for non-existent metadata
    - Verify warning is logged
    - Verify Ok(0) is returned
    - Verify no error occurs
    - **Validates: Requirements 4.1, 4.5**

- [ ] 9. Write property tests for verification
  - [ ]* 9.1 Property 16: Verification throttling
    - Generate rapid RAM cache hits
    - Verify verification is throttled by verification_interval
    - Verify not every hit triggers verification
    - **Validates: Requirements 1.7, 8.1, 8.8**
  
  - [ ]* 9.2 Property 17: Verification on mismatch
    - Generate RAM cache hit with mismatched disk metadata
    - Verify RAM entry is invalidated
    - Verify warning is logged
    - Verify None is returned
    - **Validates: Requirements 1.8, 8.5**
  
  - [ ]* 9.3 Property 18: Verification performance
    - Generate random verification checks
    - Measure verification duration
    - Verify all checks complete within 10ms
    - **Validates: Requirements 8.3**
  
  - [ ]* 9.4 Property 19: Verification error handling
    - Simulate verification with I/O error
    - Verify error is logged
    - Verify RAM entry is served anyway
    - Verify no crash occurs
    - **Validates: Requirements 8.7**
  
  - [ ]* 9.5 Property 20: Verification on disk missing
    - Generate RAM cache hit with missing disk file
    - Verify RAM entry is invalidated
    - Verify warning is logged
    - Verify None is returned
    - **Validates: Requirements 8.6**

- [ ] 10. Write integration tests for RAM-disk coherency
  - [ ]* 10.1 End-to-end coherency test
    - Start proxy with RAM and disk cache
    - Generate workload with hot data in RAM
    - Verify disk metadata is updated periodically
    - Trigger disk eviction
    - Verify hot data is not evicted (high access count)
    - **Validates: Requirements 8.5**
  
  - [ ]* 10.2 Multi-instance test
    - Start multiple proxy instances sharing disk cache
    - Generate RAM hits on different instances
    - Verify file locking prevents corruption
    - Verify all updates are applied correctly
    - **Validates: Requirements 3.1, 3.2, 3.3**
  
  - [ ]* 10.3 Shutdown test
    - Generate RAM hits with pending updates
    - Trigger graceful shutdown
    - Verify pending updates are flushed within 5 seconds
    - Verify no data loss
    - **Validates: Requirements 4.4**

- [ ] 11. Write property tests for disk metadata
  - [ ]* 11.1 Property 13: Disk metadata consistency
    - Generate random batch updates
    - Apply updates to metadata
    - Verify metadata is consistent after updates
    - Verify access counts are correct
    - Verify last_accessed timestamps are correct
    - **Validates: Requirements 8.3**
  
  - [ ]* 11.2 Property 14: Concurrent update safety
    - Simulate concurrent batch_update_range_access calls
    - Verify no updates are lost
    - Verify no data corruption
    - Verify final state is consistent
    - **Validates: Requirements 8.4**
  
  - [ ]* 11.3 Property 15: Eviction correctness
    - Generate cache with various access patterns
    - Trigger eviction
    - Verify least-accessed entries are evicted first
    - Verify most-accessed entries are retained
    - **Validates: Requirements 8.5**

- [ ] 12. Write unit tests for configuration
  - [ ]* 12.1 Test flush_interval validation
    - Test valid range (10-600 seconds)
    - Test boundary values (10, 600)
    - Test invalid values (< 10, > 600)
    - Verify default value (60 seconds)
    - **Validates: Requirements 2.1, 7.1, 7.4, 7.5**
  
  - [ ]* 12.2 Test flush_threshold validation
    - Test valid range (10-10000)
    - Test boundary values (10, 10000)
    - Test invalid values (< 10, > 10000)
    - Verify default value (100)
    - **Validates: Requirements 2.2, 7.2, 7.4, 7.5**
  
  - [ ]* 12.3 Test flush_on_eviction configuration
    - Test enabling write-back (true)
    - Test disabling write-back (false)
    - Verify default value (true)
    - **Validates: Requirements 7.3, 7.4**

- [ ] 13. Write property test for configuration validation
  - [ ]* 13.1 Property 12: Configuration validation
    - Generate random configuration values
    - Verify invalid values are rejected
    - Verify valid values are accepted
    - Verify defaults are applied correctly
    - **Validates: Requirements 7.5**

## Phase 3: Cache Invalidation Tests (Medium Priority)

- [ ] 14. Write property tests for object size storage
  - [ ]* 14.1 Property 1: Object size storage from multiple sources
    - Generate random objects with various sizes
    - Cache via HEAD response
    - Verify metadata content_length matches actual size
    - Cache via GET response
    - Verify metadata content_length matches actual size
    - Cache via PUT operation
    - Verify metadata content_length matches actual size
    - Cache via multipart upload completion
    - Verify metadata content_length matches actual size
    - **Validates: Requirements 1.1, 1.2, 1.3, 1.4**

- [ ] 15. Write property tests for range utilization
  - [ ]* 15.1 Property 2: Cached ranges are utilized for full object GET
    - Generate random objects with random cached ranges
    - Perform full object GET
    - Verify cached ranges are served from cache
    - Verify missing ranges are fetched from S3
    - Verify response is complete and correct
    - **Validates: Requirements 2.4, 2.5**
  
  - [ ]* 15.2 Property 3: Complete cache hit requires no S3 requests
    - Generate random objects with all ranges cached
    - Perform full object GET
    - Verify zero S3 requests are made
    - Verify response is served entirely from cache
    - **Validates: Requirements 2.6**

- [ ] 16. Write property tests for full object caching
  - [ ]* 16.1 Property 4: Full object GET caches response when size unknown
    - Generate random objects with no size in metadata
    - Perform full object GET
    - Verify response is cached
    - Verify content_length is stored in metadata
    - **Validates: Requirements 2.8**

- [ ] 17. Write property tests for range replacement
  - [ ]* 17.1 Property 5: Full object cache replaces partial ranges
    - Generate random objects with partial ranges cached
    - Cache full object GET response
    - Verify partial ranges are removed
    - Verify full object is stored
    - Verify metadata reflects full object
    - **Validates: Requirements 2.9**

- [ ] 18. Write property tests for HEAD cache invalidation
  - [ ]* 18.1 Property 6: PUT invalidates HEAD cache
    - Generate random objects with HEAD cache
    - Perform PUT operation
    - Verify HEAD cache is invalidated
    - Verify HEAD cache file is deleted
    - **Validates: Requirements 3.1**

- [ ] 19. Write property tests for ETag invalidation
  - [ ]* 19.1 Property 7: ETag mismatch invalidates cached ranges
    - Generate random objects with cached ranges
    - Update metadata with different ETag
    - Perform range request
    - Verify ranges with mismatched ETags are not used
    - Verify missing ranges are fetched from S3
    - **Validates: Requirements 3.3**

## Phase 4: Distributed Eviction Lock Tests (Medium Priority)

- [ ] 20. Write property tests for lock staleness
  - [ ]* 20.1 Property 4: Stale Lock Recovery
    - Create lock file with old timestamp
    - Attempt to acquire lock
    - Verify stale lock is detected
    - Verify lock is forcibly acquired
    - Verify warning is logged
    - **Validates: Requirements 2.2, 2.3**

- [ ] 21. Write property tests for lock acquisition
  - [ ]* 21.1 Property 7: Atomic Lock Acquisition
    - Simulate concurrent lock acquisition attempts
    - Verify only one instance acquires lock
    - Verify others receive Ok(false)
    - Verify no race conditions
    - **Validates: Requirements 1.5**
  
  - [ ]* 21.2 Property 3: Lock File Completeness
    - Acquire lock
    - Read lock file
    - Verify all required fields are present (instance_id, process_id, hostname, acquired_at, timeout_seconds)
    - Verify fields have correct values
    - **Validates: Requirements 1.4, 4.3, 4.4, 4.5, 4.6, 4.7**

- [ ] 22. Write property tests for lock release
  - [ ]* 22.1 Property 6: Ownership Verification on Release
    - Acquire lock with instance A
    - Attempt to release lock with instance B
    - Verify release fails
    - Verify warning is logged
    - Verify lock file remains
    - Release lock with instance A
    - Verify release succeeds
    - Verify lock file is deleted
    - **Validates: Requirements 3.3**

- [ ] 23. Write property tests for eviction coordination
  - [ ]* 23.1 Property 1: Mutual Exclusion
    - Simulate multiple instances detecting over-limit
    - Verify only one acquires lock and evicts
    - Verify others skip eviction
    - **Validates: Requirements 5.5, 1.3**
  
  - [ ]* 23.2 Property 2: Lock Acquisition Precedes Eviction
    - Trigger eviction
    - Verify lock is acquired before eviction starts
    - Verify eviction does not start if lock acquisition fails
    - **Validates: Requirements 1.1, 5.1**
  
  - [ ]* 23.3 Property 5: Lock Release After Eviction
    - Trigger eviction
    - Verify lock is released after eviction completes
    - Verify lock is released even if eviction fails
    - **Validates: Requirements 3.1, 3.2, 5.4**
  
  - [ ]* 23.4 Property 9: Eviction Skip on Lock Failure
    - Simulate lock held by another instance
    - Trigger eviction
    - Verify eviction is skipped
    - Verify Ok(0) is returned
    - **Validates: Requirements 1.3, 5.3**

- [ ] 24. Write unit tests for metrics
  - [ ]* 24.1 Test metrics tracking
    - Acquire lock successfully
    - Verify lock_acquisitions_successful increments
    - Fail to acquire lock
    - Verify lock_acquisitions_failed increments
    - Recover stale lock
    - Verify stale_locks_recovered increments
    - Verify metrics are exposed via HTTP endpoint
    - **Validates: Requirements 7.1, 7.2, 7.3, 7.4, 7.5**

- [ ] 25. Write unit tests for error scenarios
  - [ ]* 25.1 Test error handling
    - Simulate filesystem error during lock acquisition
    - Verify error is logged
    - Verify error is returned
    - Verify no panic occurs
    - Simulate corrupted lock file
    - Verify lock is treated as stale
    - Verify warning is logged
    - Simulate permission error
    - Verify error is logged
    - Verify error is returned
    - **Validates: Requirements 8.1, 8.2, 8.3, 8.4, 8.5**

- [ ] 26. Write integration tests for distributed eviction
  - [ ]* 26.1 Multi-instance coordination test
    - Start 3 simulated proxy instances
    - All instances detect over-limit simultaneously
    - Verify only one acquires lock and evicts
    - Verify others skip eviction
    - Verify total eviction is correct (not over-evicted)
    - **Validates: Requirements 5.5, 9.1, 9.2, 10.1, 10.2, 10.3**
  
  - [ ]* 26.2 Stale lock recovery test
    - Create stale lock file (old timestamp)
    - Start proxy instance
    - Trigger eviction
    - Verify stale lock is detected and recovered
    - Verify eviction proceeds
    - Verify warning is logged
    - **Validates: Requirements 2.2, 2.3**

- [ ] 27. Write property test for lock file location
  - [ ]* 27.1 Property 10: Lock File Location Consistency
    - Generate random cache directory paths
    - Verify lock file path is always {cache_dir}/locks/global_eviction.lock
    - Verify path is consistent across instances
    - **Validates: Requirements 4.1**

## Phase 5: Cache Key Simplification Tests (Medium Priority)

- [ ] 28. Write property tests for cache key format
  - [ ]* 28.1 Property 1: Cache Key Uniqueness
    - Generate pairs of different S3 paths
    - Generate cache keys for each
    - Verify cache keys are different
    - Verify no collisions occur
    - **Validates: Requirements 2.5**
  
  - [ ]* 28.2 Property 2: Cache Key Format Consistency
    - Generate random S3 paths
    - Generate cache keys using different functions
    - Verify all follow same format (path-only, no host)
    - Verify format is consistent across all cache key types
    - **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 2.1**

- [ ] 29. Write property tests for path extraction
  - [ ]* 29.1 Property 3: Path Extraction Correctness
    - Generate random cache keys
    - Extract path from each key
    - Verify extracted path matches original
    - Verify extraction handles all key formats
    - **Validates: Requirements 2.2, 7.2**

- [ ] 30. Write property tests for sanitization
  - [ ]* 30.1 Property: No Sanitization Collisions
    - Generate pairs of different cache keys
    - Sanitize each key to filename
    - Verify different keys produce different filenames
    - Test edge cases: keys with literal `_colon_`, `_slash_`, etc.
    - Verify round-trip: sanitize then extract produces original key
    - **Validates: Requirements 2.5, 3.1, 3.4**
  
  - [ ]* 30.2 Property 7: Sanitization Consistency
    - Generate random cache keys
    - Sanitize each key multiple times
    - Verify sanitization is deterministic
    - Verify same key always produces same filename
    - **Validates: Requirements 3.1, 3.4**

- [ ] 31. Write property tests for cache portability
  - [ ]* 31.1 Property 4: Cache Portability
    - Generate random S3 paths
    - Generate cache keys for different endpoints
    - Verify cache keys are identical (no host in key)
    - Verify cached entry works across endpoints
    - **Validates: Requirements 5.1, 5.2, 5.4**

- [ ] 32. Write property tests for cache cleanup
  - [ ]* 32.1 Property 5: Cache Cleanup Correctness
    - Generate random cache entries with new format
    - Trigger cache cleanup
    - Verify all associated files are deleted
    - Verify cache size calculation is correct
    - **Validates: Requirements 8.1, 8.2, 8.3**

- [ ] 33. Write property tests for key length
  - [ ]* 33.1 Property 6: Cache Key Length Reduction
    - Generate random S3 paths
    - Generate old format keys (with host)
    - Generate new format keys (without host)
    - Verify new keys are shorter
    - Measure average reduction (should be ~40%)
    - **Validates: Requirements 3.3, 10.1**

- [ ] 34. Write integration test for cache operations
  - [ ]* 34.1 Integration test for new cache key format
    - Test cache operations with new format
    - Test cross-endpoint cache portability
    - Test cache eviction with new format
    - Test all cache types (full objects, ranges, versions)
    - **Validates: Requirements 5.1, 5.2, 5.3, 9.5**

- [ ] 35. Write performance test
  - [ ]* 35.1 Performance test for cache key improvements
    - Measure average cache key length reduction
    - Measure reduction in SHA-256 hashing frequency
    - Verify no performance regression in cache operations
    - Document performance improvements
    - **Validates: Requirements 10.1, 10.2, 10.3, 10.4, 10.5**

## Phase 6: Code Cleanup (Low Priority)

- [x] 36. Remove HTTPS self-signed mode
  - [x] 36.1 Remove SelfSigned variant from HttpsMode enum
    - Edit src/config.rs
    - Remove #[serde(rename = "selfsigned")] SelfSigned variant
    - Keep only Passthrough variant
    - _Requirements: 3.1_
  
  - [x] 36.2 Remove TLS termination code from https_proxy.rs
    - Remove start_tls_termination() method
    - Remove TLS-related imports and fields
    - Simplify start() method to only call start_passthrough()
    - _Requirements: 3.1_
  
  - [x] 36.3 Remove or simplify tls.rs
    - Check if tls.rs is used elsewhere in the codebase
    - If only used for self-signed mode, remove entire file
    - If used elsewhere, remove self-signed certificate generation code
    - _Requirements: 3.1_
  
  - [x] 36.4 Remove self-signed mode tests
    - Remove test_self_signed_tls_mode() from tests/s3_integration_test.rs
    - Remove any other self-signed mode test cases
    - _Requirements: 3.1_
  
  - [x] 36.5 Update configuration and documentation
    - Update config.example.yaml to remove self-signed mode references
    - Update .kiro/steering/product.md to reflect passthrough-only mode
    - Update any other documentation mentioning self-signed mode
    - _Requirements: 3.1_
  
  - [x] 36.6 Verify compilation and tests
    - Run cargo build to ensure no compilation errors
    - Run cargo test to ensure all tests pass
    - Verify HTTPS passthrough mode still works correctly
    - _Requirements: 3.1_

## Phase 7: Observability Enhancements (Low Priority)

- [x] 37. Add compression timing metrics
  - [x] 37.1 Add compression_time_ms field to CompressionMetrics
    - Add AtomicU64 field to struct
    - Initialize to 0
    - _Requirements: 4.1_
  
  - [x] 37.2 Measure compression duration
    - Record start time before compression
    - Record end time after compression
    - Calculate duration in milliseconds
    - Store in compression_time_ms metric
    - _Requirements: 4.1_
  
  - [x] 37.3 Expose metric via HTTP endpoint
    - Add compression_time_ms to metrics output
    - Format as Prometheus metric
    - _Requirements: 4.1_
  
  - [x] 37.4 Include in OTLP export
    - Add compression_time_ms to OTLP metric export
    - Export as gauge metric
    - _Requirements: 4.1_

- [x] 38. Add idle connection tracking
  - [x] 38.1 Add idle_connections field to ConnectionPoolMetrics
    - Add AtomicU64 field to struct
    - Initialize to 0
    - _Requirements: 4.2_
  
  - [x] 38.2 Track idle connections in connection pool
    - Increment when connection becomes idle
    - Decrement when connection becomes active
    - Update on connection close
    - _Requirements: 4.2_
  
  - [x] 38.3 Expose metric via HTTP endpoint
    - Add idle_connections to metrics output
    - Format as Prometheus metric
    - _Requirements: 4.2_
  
  - [x] 38.4 Include in OTLP export
    - Add idle_connections to OTLP metric export
    - Export as gauge metric
    - _Requirements: 4.2_

- [x] 39. Add DNS refresh tracking
  - [x] 39.1 Add dns_refresh_count field to ConnectionPoolMetrics
    - Add AtomicU64 field to struct
    - Initialize to 0
    - _Requirements: 4.3_
  
  - [x] 39.2 Increment on DNS refresh
    - Increment counter when DNS refresh occurs
    - Add logging for DNS refresh events
    - _Requirements: 4.3_
  
  - [x] 39.3 Expose metric via HTTP endpoint
    - Add dns_refresh_count to metrics output
    - Format as Prometheus metric
    - _Requirements: 4.3_
  
  - [x] 39.4 Include in OTLP export
    - Add dns_refresh_count to OTLP metric export
    - Export as counter metric
    - _Requirements: 4.3_

- [x] 40. Add throughput calculation
  - [x] 40.1 Calculate throughput in s3_client.rs
    - Get request size from request body
    - Get response size from response body
    - Calculate total bytes transferred
    - Calculate duration in seconds
    - Calculate throughput as bytes per second
    - _Requirements: 4.4_
  
  - [x] 40.2 Pass throughput to record_request_metrics
    - Update record_request_metrics call with calculated throughput
    - Handle None case for unknown sizes
    - _Requirements: 4.4_
  
  - [x] 40.3 Store throughput in connection pool metrics
    - Add throughput to ConnectionMetrics struct
    - Update metric on each request
    - Calculate average throughput
    - _Requirements: 4.4_

- [x] 41. Verify cache key sanitization
  - [x] 41.1 Test sanitization with new format
    - Generate various cache key formats
    - Verify sanitization produces valid filenames
    - Verify no collisions occur
    - _Requirements: 4.5_
  
  - [x] 41.2 Measure SHA-256 hashing frequency
    - Count keys that require hashing (> 200 chars)
    - Compare old format vs new format
    - Verify reduction in hashing frequency
    - _Requirements: 4.5_
  
  - [x] 41.3 Test file path generation
    - Generate cache keys with various characters
    - Verify file paths are valid
    - Verify paths work on all platforms
    - _Requirements: 4.5_
  
  - [x] 41.4 Verify round-trip correctness
    - Sanitize cache key to filename
    - Extract cache key from filename
    - Verify extracted key matches original
    - Test with various key formats
    - _Requirements: 4.5_

## Phase 8: Final Validation

- [-] 42. Run full test suite
  - Run `cargo test` to execute all tests
  - Verify all 60 new tests pass
  - Verify all existing tests still pass
  - Verify no regressions

- [ ] 43. Run property tests with high iteration count
  - Run property tests with 1000 iterations
  - Verify all properties hold
  - Investigate any failures

- [ ] 44. Performance validation
  - Run performance test suite
  - Verify no performance regressions
  - Document any improvements

- [ ] 45. Update documentation
  - Update CACHING.md with range replacement behavior
  - Update ERROR_HANDLING.md with HTTP date parsing
  - Add property test documentation to code comments
  - Update release notes

- [ ] 46. Final checkpoint
  - Review all completed tasks
  - Verify all requirements are met
  - Ensure all code TODOs are resolved
  - Confirm spec is complete
