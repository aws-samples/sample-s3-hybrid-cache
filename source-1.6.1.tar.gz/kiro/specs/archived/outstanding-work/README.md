# Outstanding Work - Testing & Code TODOs

## Overview

This spec consolidates all incomplete testing and implementation tasks from existing specs and code TODOs. The core implementations are complete, but comprehensive testing is needed to validate correctness guarantees.

## Problem Statement

Four major specs have completed implementation but lack comprehensive property-based testing:
- **RAM-Disk Cache Coherency**: 20 property tests + 3 integration tests + 3 unit tests needed
- **Cache Invalidation and Lookup**: 7 property tests + 1 implementation task needed
- **Distributed Eviction Lock**: 8 property tests + 2 unit tests + 2 integration tests needed
- **Cache Key Simplification**: 8 property tests + 1 implementation task + 1 integration test needed

Additionally, 5 code TODOs require implementation for observability and correctness.

## Solution

Systematically complete all outstanding work in priority order:
1. **High Priority**: Critical correctness features (ETag validation, HTTP date parsing, range replacement)
2. **Medium Priority**: Property-based tests validating core guarantees
3. **Low Priority**: Observability enhancements (metrics, performance tests)

## Key Features

- **60 Total Tests**: 48 property tests, 7 integration tests, 5 unit tests
- **7 Implementation Tasks**: 2 in specs, 5 code TODOs
- **Property-Based Testing**: Uses `quickcheck` framework per project conventions
- **Comprehensive Coverage**: Validates all correctness properties from specs

## Files

- `requirements.md` - Consolidated requirements from all specs
- `design.md` - Task organization and priority recommendations
- `tasks.md` - Executable task list organized by priority

## Status

**Phase**: Ready for Implementation

All specs have completed core implementation. This spec provides a consolidated view of remaining work.

## Quick Start

Open `tasks.md` and start with high-priority tasks:
1. Task 1: Full object range replacement (cache correctness)
2. Task 2: ETag validation in range requests (cache consistency)
3. Task 3: HTTP date parsing (conditional requests)

## Related Specs

- `ram-disk-cache-coherency` - RAM/disk cache coordination
- `cache-invalidation-and-lookup` - Cache consistency mechanisms
- `distributed-eviction-lock` - Multi-instance coordination
- `cache-key-simplification` - Simplified cache key format

## Test Statistics

| Category | Count | Percentage |
|----------|-------|------------|
| Property Tests | 48 | 80% |
| Integration Tests | 7 | 12% |
| Unit Tests | 5 | 8% |
| **Total** | **60** | **100%** |

## Priority Breakdown

- **High Priority**: 3 tasks (critical correctness)
- **Medium Priority**: 43 tasks (property tests)
- **Low Priority**: 14 tasks (observability)
