# Design: Outstanding Work

## Overview

This spec consolidates all incomplete work from existing specs and code TODOs. The design organizes tasks by priority and provides implementation guidance for each category.

## Architecture

### Task Organization

```
Outstanding Work
├── High Priority (Critical Correctness)
│   ├── Full Object Range Replacement
│   ├── ETag Validation in Range Requests
│   └── HTTP Date Parsing
│
├── Medium Priority (Property-Based Testing)
│   ├── RAM-Disk Cache Coherency (26 tests)
│   ├── Cache Invalidation (7 tests)
│   ├── Distributed Eviction Lock (12 tests)
│   └── Cache Key Simplification (10 tests)
│
└── Low Priority (Observability)
    ├── Metrics Enhancements (4 tasks)
    └── Cache Key Sanitization (1 task)
```

## High Priority Tasks

### 1. Full Object Range Replacement

**Location**: `src/cache.rs` or `src/http_proxy.rs`  
**Function**: `store_response()` or `forward_get_head_to_s3_and_cache()`

**Implementation Strategy**:
1. When caching full object GET response, check for existing range files
2. Query metadata to find all cached ranges for the object
3. Delete range files before storing full object
4. Update metadata to reflect full object storage
5. Log operation with object key and range count removed

**Code Pattern**:
```rust
// In store_response or similar function
async fn cache_full_object_response(
    &self,
    cache_key: &str,
    response_data: Bytes,
    metadata: ResponseMetadata,
) -> Result<()> {
    // Check for existing partial ranges
    if let Some(existing_metadata) = self.get_metadata(cache_key).await? {
        if !existing_metadata.ranges.is_empty() {
            info!(
                "Replacing {} partial ranges with full object: {}",
                existing_metadata.ranges.len(),
                cache_key
            );
            
            // Remove old range files
            for range in &existing_metadata.ranges {
                self.delete_range_file(cache_key, range).await?;
            }
        }
    }
    
    // Store full object as range
    self.store_full_object_as_range_new(cache_key, response_data, metadata).await
}
```

### 2. ETag Validation in Range Requests

**Location**: `src/http_proxy.rs`  
**Line**: ~1365 (TODO comment)

**Implementation Strategy**:
1. Extract ETag from HEAD response in `forward_get_head_to_s3_and_cache()`
2. Pass ETag to `find_cached_ranges()` call
3. Update `find_cached_ranges()` signature to accept `Option<&str>` for ETag
4. Compare cached range ETag with provided ETag
5. Skip ranges with mismatched ETags (treat as missing)

**Code Pattern**:
```rust
// In forward_get_head_to_s3_and_cache
let current_etag = head_response.headers()
    .get("etag")
    .and_then(|v| v.to_str().ok());

// Pass to find_cached_ranges
match range_handler.find_cached_ranges(
    &cache_key,
    &range_spec,
    current_etag  // Add this parameter
).await {
    // ...
}

// In find_cached_ranges
pub async fn find_cached_ranges(
    &self,
    cache_key: &str,
    requested_range: &RangeSpec,
    current_etag: Option<&str>,  // Add this parameter
) -> Result<RangeOverlap> {
    // Compare ETags when checking cached ranges
    for cached_range in &metadata.ranges {
        if let Some(etag) = current_etag {
            if cached_range.etag != etag {
                warn!(
                    "ETag mismatch for cached range: cache_key={}, range={}-{}, cached_etag={}, current_etag={}",
                    cache_key, cached_range.start, cached_range.end, cached_range.etag, etag
                );
                continue; // Skip this range
            }
        }
        // ... rest of logic
    }
}
```

### 3. HTTP Date Parsing

**Location**: `src/cache.rs`  
**Lines**: 5179, 5189 (TODO comments)

**Implementation Strategy**:
1. Add `httpdate` crate dependency to `Cargo.toml`
2. Parse HTTP date strings using `httpdate::parse_http_date()`
3. Compare parsed dates as `SystemTime` values
4. Handle parse errors gracefully (log warning, skip condition)

**Code Pattern**:
```rust
use httpdate::parse_http_date;
use std::time::SystemTime;

// In check_conditional_headers
if let Some(if_modified_since) = conditions.get("if-modified-since") {
    match parse_http_date(if_modified_since) {
        Ok(client_date) => {
            if let Ok(cache_date) = parse_http_date(&cache_entry.metadata.last_modified) {
                if cache_date <= client_date {
                    return Ok(false); // Not modified
                }
            }
        }
        Err(e) => {
            warn!("Failed to parse If-Modified-Since header: {}", e);
        }
    }
}
```

**Dependency**:
```toml
# Add to Cargo.toml
httpdate = "1.0"
```

## Medium Priority Tasks

### Property-Based Testing Strategy

All property tests follow the same pattern using `quickcheck`:

**Test Structure**:
```rust
#[cfg(test)]
mod tests {
    use super::*;
    use quickcheck::{quickcheck, TestResult};
    use quickcheck_macros::quickcheck;

    #[quickcheck]
    fn prop_test_name(input: ArbitraryType) -> TestResult {
        // Setup
        let system = setup_test_system();
        
        // Execute
        let result = system.operation(input);
        
        // Verify property holds
        if !property_holds(result) {
            return TestResult::failed();
        }
        
        TestResult::passed()
    }
}
```

**Test Location**:
- Property tests: Inline with source files using `#[cfg(test)]`
- Integration tests: `tests/` directory
- Unit tests: Inline with source files using `#[cfg(test)]`

**Quickcheck Configuration**:
- Minimum 100 iterations per property test
- Use `#[quickcheck]` macro for automatic test generation
- Define custom `Arbitrary` implementations for domain types

### RAM-Disk Cache Coherency Tests (26 tests)

**Files**: `src/ram_cache.rs`, `src/cache.rs`, `tests/ram_disk_coherency_test.rs`

**Key Properties**:
1. **Access Tracking**: RAM hits are recorded with O(1) performance
2. **Batch Flushing**: Updates are batched and flushed periodically
3. **Verification**: RAM entries are verified against disk periodically
4. **Eviction Write-Back**: Pending updates are flushed on eviction
5. **File Locking**: Concurrent updates use file locking correctly

**Test Categories**:
- 20 property tests (inline in source files)
- 3 integration tests (in `tests/` directory)
- 3 unit tests (inline in source files)

### Cache Invalidation Tests (7 tests)

**Files**: `src/cache.rs`, `src/http_proxy.rs`, `tests/cache_invalidation_test.rs`

**Key Properties**:
1. **Object Size Storage**: Size is stored from all sources (HEAD/GET/PUT/MPU)
2. **Range Utilization**: Cached ranges are used for full object GETs
3. **Complete Cache Hit**: No S3 requests when all ranges cached
4. **Full Object Caching**: Full GETs are cached when size unknown
5. **Range Replacement**: Full objects replace partial ranges
6. **HEAD Invalidation**: PUTs invalidate HEAD cache
7. **ETag Invalidation**: ETag mismatches invalidate ranges

### Distributed Eviction Lock Tests (12 tests)

**Files**: `src/cache.rs`, `tests/distributed_eviction_test.rs`

**Key Properties**:
1. **Mutual Exclusion**: Only one instance evicts at a time
2. **Lock Acquisition**: Lock is acquired before eviction
3. **Lock Completeness**: Lock file contains all required fields
4. **Stale Recovery**: Stale locks are detected and recovered
5. **Lock Release**: Lock is released after eviction
6. **Ownership Verification**: Only owner can release lock

**Test Categories**:
- 8 property tests (inline in `src/cache.rs`)
- 2 unit tests (inline in `src/cache.rs` and `src/metrics.rs`)
- 2 integration tests (in `tests/` directory)

### Cache Key Simplification Tests (10 tests)

**Files**: `src/cache.rs`, `src/disk_cache.rs`, `tests/cache_key_test.rs`

**Key Properties**:
1. **Uniqueness**: Different cache keys produce different filenames
2. **Format Consistency**: All cache keys follow same format
3. **Path Extraction**: Extracting path from key is correct
4. **Portability**: Same key works across endpoints
5. **Cleanup Correctness**: Cache cleanup works with new format
6. **Length Reduction**: New format is shorter than old format
7. **Sanitization Consistency**: Sanitization is deterministic
8. **No Collisions**: Sanitization prevents filename collisions

## Low Priority Tasks

### Remove HTTPS Self-Signed Mode

**Files**: `src/https_proxy.rs`, `src/tls.rs`, `src/config.rs`, `tests/s3_integration_test.rs`

**Rationale**: The self-signed TLS termination mode adds complexity without providing significant value. TCP passthrough mode is simpler, more performant, and sufficient for the proxy's use case. Self-signed certificates also cause trust issues in production environments.

**Implementation Strategy**:
1. Remove `SelfSigned` variant from `HttpsMode` enum in `config.rs`
2. Remove `start_tls_termination()` method from `https_proxy.rs`
3. Remove TLS certificate generation logic from `tls.rs` (or remove entire file if only used for self-signed)
4. Update `start()` method in `https_proxy.rs` to only handle passthrough mode
5. Remove self-signed mode tests from `tests/s3_integration_test.rs`
6. Update configuration examples to remove self-signed mode references
7. Update documentation to reflect passthrough-only mode

**Code Pattern**:
```rust
// In config.rs - Simplify HttpsMode enum
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum HttpsMode {
    Passthrough,  // TCP passthrough (only mode)
}

// In https_proxy.rs - Simplify start() method
pub async fn start(&mut self) -> Result<()> {
    info!("Starting HTTPS proxy in TCP passthrough mode on {}", self.listen_addr);
    self.start_passthrough().await
}
```

**Files to Modify**:
- `src/config.rs`: Remove `SelfSigned` variant from `HttpsMode` enum
- `src/https_proxy.rs`: Remove `start_tls_termination()` method and TLS-related code
- `src/tls.rs`: Remove or simplify (check if used elsewhere)
- `tests/s3_integration_test.rs`: Remove `test_self_signed_tls_mode()` test
- `config.example.yaml`: Update HTTPS mode documentation
- `.kiro/steering/product.md`: Update to reflect passthrough-only mode

### Metrics Enhancements

**Files**: `src/metrics.rs`, `src/compression.rs`, `src/connection_pool.rs`, `src/s3_client.rs`

**Implementation Pattern**:
```rust
// 1. Add metric field to struct
pub struct Metrics {
    pub compression_time_ms: AtomicU64,
    pub idle_connections: AtomicU64,
    pub dns_refresh_count: AtomicU64,
}

// 2. Update metric during operation
let start = Instant::now();
let result = compress_data(data);
let duration = start.elapsed().as_millis() as u64;
metrics.compression_time_ms.store(duration, Ordering::Relaxed);

// 3. Expose via HTTP endpoint
fn format_metrics(&self) -> String {
    format!(
        "compression_time_ms {}\n",
        self.compression_time_ms.load(Ordering::Relaxed)
    )
}

// 4. Include in OTLP export
fn export_otlp(&self) -> Vec<Metric> {
    vec![
        Metric::gauge("compression_time_ms", self.compression_time_ms.load(Ordering::Relaxed)),
    ]
}
```

### Cache Key Sanitization Verification

**File**: `src/cache.rs`, `src/disk_cache.rs`

**Implementation**:
1. Verify percent encoding produces collision-free filenames
2. Measure SHA-256 hashing frequency reduction
3. Test file path generation with various key formats
4. Verify round-trip (sanitize → extract) preserves original key

## Testing Strategy

### Property Test Template

```rust
#[cfg(test)]
mod property_tests {
    use super::*;
    use quickcheck_macros::quickcheck;
    use tempfile::TempDir;

    #[quickcheck]
    fn prop_name(input: Vec<u8>) -> bool {
        // Setup
        let temp_dir = TempDir::new().unwrap();
        let cache = setup_cache(temp_dir.path());
        
        // Execute
        let result = cache.operation(input);
        
        // Verify property
        verify_property(result)
    }
}
```

### Integration Test Template

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;
    use tokio::test;
    use tempfile::TempDir;

    #[tokio::test]
    async fn test_scenario() {
        // Setup
        let temp_dir = TempDir::new().unwrap();
        let cache = setup_cache(temp_dir.path()).await;
        
        // Execute scenario
        cache.operation1().await.unwrap();
        cache.operation2().await.unwrap();
        
        // Verify end state
        assert!(verify_state(&cache).await);
    }
}
```

### Unit Test Template

```rust
#[cfg(test)]
mod unit_tests {
    use super::*;

    #[test]
    fn test_function() {
        // Setup
        let input = create_test_input();
        
        // Execute
        let result = function_under_test(input);
        
        // Verify
        assert_eq!(result, expected_output);
    }
}
```

## Implementation Order

### Phase 1: Critical Correctness (Week 1)
1. Full object range replacement
2. ETag validation in range requests
3. HTTP date parsing

### Phase 2: Core Property Tests (Week 2-3)
1. RAM-Disk Cache Coherency (20 property tests)
2. Cache Invalidation (7 property tests)
3. Distributed Eviction Lock (8 property tests)
4. Cache Key Simplification (8 property tests)

### Phase 3: Integration Tests (Week 4)
1. RAM-Disk coherency integration tests (3 tests)
2. Distributed eviction integration tests (2 tests)
3. Cache key integration test (1 test)

### Phase 4: Unit Tests & Observability (Week 5)
1. Configuration unit tests (3 tests)
2. Metrics unit tests (2 tests)
3. Metrics enhancements (4 tasks)
4. Cache key sanitization verification (1 task)
5. Performance testing (1 task)

## Success Criteria

### Correctness
- All property tests pass with 100+ quickcheck iterations
- All integration tests pass consistently
- All unit tests pass
- No regressions in existing tests

### Coverage
- All 60 tests implemented and passing
- All 7 implementation tasks completed
- All code TODOs resolved

### Quality
- Tests follow project conventions (quickcheck, tempfile, tokio::test)
- Tests are deterministic and reproducible
- Tests have clear failure messages
- Tests run in reasonable time (< 5 minutes total)

## Dependencies

### New Crate Dependencies
```toml
# Add to Cargo.toml if not already present
httpdate = "1.0"  # For HTTP date parsing
```

### Existing Dependencies (Already in Project)
- `quickcheck = "1.0"` - Property-based testing
- `quickcheck_macros = "1.0"` - Derive macros for property tests
- `tempfile = "3.0"` - Temporary directories in tests
- `tokio-test = "0.4"` - Tokio testing utilities

## Documentation Updates

After completing tasks, update:
- `docs/CACHING.md` - Document range replacement behavior
- `docs/ERROR_HANDLING.md` - Document HTTP date parsing errors
- Code comments - Add property test documentation
- Release notes - Document bug fixes and improvements
