# Design Document

## Overview

This design addresses a critical cache lookup bug where `find_cached_ranges` returns 0 cached ranges despite valid metadata and range files existing on disk. The issue manifests when:
- Metadata file exists with the correct cache key
- Metadata contains valid ranges covering the requested byte range
- Ranges are not expired (TTL set to ~10 years)
- Range binary files exist on disk

The root cause is likely one of the following:
1. Cache key format mismatch between storage and lookup operations
2. Incorrect path construction in sharded directory structure
3. Cache key sanitization inconsistency
4. Missing or incorrect bucket name parsing

Additionally, this design implements HEAD cache to GET cache invalidation to ensure stale data is never served.

## Architecture

### Component Interaction

```
HTTP Request → RangeHandler → DiskCacheManager → Filesystem
                    ↓                ↓
              Cache Key         Path Resolution
              Sanitization      (Sharding Logic)
                    ↓                ↓
              find_cached_ranges → get_metadata
                                      ↓
                                File Existence Check
                                      ↓
                                Range Overlap Detection
```

### Key Components

1. **RangeHandler** (`src/range_handler.rs`)
   - Receives HTTP range requests
   - Constructs cache keys from S3 paths
   - Calls `disk_cache.find_cached_ranges()`
   - Handles ETag validation

2. **DiskCacheManager** (`src/disk_cache.rs`)
   - Manages disk-based cache storage
   - Implements sharded directory structure
   - Provides `get_metadata()` and `find_cached_ranges()`
   - Handles cache key sanitization

3. **Path Resolution Functions**
   - `get_sharded_path()`: Constructs bucket/XX/YYY/filename paths
   - `parse_cache_key()`: Extracts bucket and object key
   - `sanitize_object_key_for_filename()`: Makes keys filesystem-safe

## Components and Interfaces

### Enhanced Logging Interface

```rust
// Add diagnostic logging at each critical point in the cache lookup path

// In range_handler.rs - find_cached_ranges()
debug!(
    "[CACHE_LOOKUP] Starting cache lookup: cache_key={}, requested_range={}-{}, current_etag={:?}",
    cache_key, requested_range.start, requested_range.end, current_etag
);

// In disk_cache.rs - get_new_metadata_file_path()
debug!(
    "[PATH_RESOLUTION] Constructing metadata path: cache_key={}, sharded_path={:?}",
    cache_key, metadata_file_path
);

// In disk_cache.rs - get_metadata()
debug!(
    "[METADATA_LOOKUP] Checking metadata file: cache_key={}, path={:?}, exists={}",
    cache_key, metadata_file_path, metadata_file_path.exists()
);

// In disk_cache.rs - find_cached_ranges()
debug!(
    "[RANGE_OVERLAP] Checking range overlap: cached_range={}-{}, requested_range={}-{}, overlaps={}",
    range_spec.start, range_spec.end, requested_start, requested_end, overlaps
);
```

### Cache Key Validation Interface

```rust
/// Validate cache key consistency between storage and lookup
pub struct CacheKeyValidator {
    /// Original cache key as received
    pub original_key: String,
    /// Sanitized cache key for filesystem
    pub sanitized_key: String,
    /// Bucket name extracted from key
    pub bucket: String,
    /// Object key extracted from key
    pub object_key: String,
    /// Full metadata file path
    pub metadata_path: PathBuf,
    /// Full range file path (for a sample range)
    pub range_path: PathBuf,
}

impl CacheKeyValidator {
    /// Create validator and log all key transformations
    pub fn new(cache_key: &str, disk_cache: &DiskCacheManager) -> Result<Self>;
    
    /// Log all key components for debugging
    pub fn log_diagnostics(&self);
}
```

### HEAD Cache Invalidation Interface

```rust
/// Check if GET cache should be invalidated based on HEAD metadata
pub async fn validate_cache_against_head(
    &self,
    cache_key: &str,
    head_etag: &str,
    head_last_modified: &str,
) -> Result<CacheValidationResult>;

pub enum CacheValidationResult {
    /// Cache is valid, can be used
    Valid,
    /// Cache is stale, must be invalidated
    Stale {
        reason: StaleReason,
        cached_etag: String,
        cached_last_modified: String,
        current_etag: String,
        current_last_modified: String,
    },
}

pub enum StaleReason {
    ETagMismatch,
    LastModifiedMismatch,
}
```

## Data Models

### Diagnostic Log Entry

```rust
#[derive(Debug, Serialize)]
pub struct CacheLookupDiagnostic {
    /// Timestamp of the lookup attempt
    pub timestamp: SystemTime,
    /// Original cache key
    pub cache_key: String,
    /// Sanitized cache key
    pub sanitized_key: String,
    /// Requested byte range
    pub requested_range: (u64, u64),
    /// Metadata file path checked
    pub metadata_path: PathBuf,
    /// Whether metadata file exists
    pub metadata_exists: bool,
    /// Number of ranges in metadata (if found)
    pub ranges_in_metadata: Option<usize>,
    /// Number of overlapping ranges found
    pub overlapping_ranges: usize,
    /// Current ETag for validation
    pub current_etag: Option<String>,
    /// Cached ETag (if metadata found)
    pub cached_etag: Option<String>,
}
```

### Cache Invalidation Event

```rust
#[derive(Debug, Serialize)]
pub struct CacheInvalidationEvent {
    /// Timestamp of invalidation
    pub timestamp: SystemTime,
    /// Cache key being invalidated
    pub cache_key: String,
    /// Reason for invalidation
    pub reason: StaleReason,
    /// Old metadata
    pub old_etag: String,
    pub old_last_modified: String,
    /// New metadata from HEAD
    pub new_etag: String,
    pub new_last_modified: String,
    /// Number of ranges deleted
    pub ranges_deleted: usize,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Cache key sanitization consistency across all operations

*For any* cache key, sanitizing it should produce identical results whether used for storage, lookup, metadata path construction, or range path construction, and special characters should be percent-encoded consistently, and keys exceeding 200 characters should be hashed consistently using BLAKE3
**Validates: Requirements 2.1, 2.2, 2.3, 2.4**

### Property 2: Sharded path construction correctness

*For any* valid cache key, constructing a sharded path should correctly parse the bucket name, compute hash-based shard directories (XX/YYY) from the object key, and combine bucket, hash directories, and sanitized filename in the correct order (base_dir/bucket/XX/YYY/filename)
**Validates: Requirements 3.1, 3.2, 3.3**

### Property 3: Cache key normalization consistency

*For any* S3 path, normalizing it should produce the same result regardless of whether it has a leading slash or different URL encoding, and comparing two normalized keys should detect any remaining format differences
**Validates: Requirements 5.3, 5.5**

### Property 4: Cache storage and retrieval round-trip

*For any* cache key and range data, storing the range then looking up the same cache key should return the stored range with matching byte positions and data
**Validates: Requirements 4.4**

### Property 5: HEAD metadata comparison triggers invalidation

*For any* cached object, when a HEAD request returns metadata (ETag or Last-Modified) that differs from the cached metadata, the system should compare both values and immediately delete all cached metadata and range binary files for that object
**Validates: Requirements 7.1, 7.2, 7.3, 7.4**

### Property 6: Range merge logging only when necessary

*For any* requested range that exactly matches or is fully contained within a single cached range, no range merge operations should be logged, and merge logging should only occur when multiple segments need to be combined
**Validates: Requirements 8.1, 8.2, 8.3, 8.4**

## Error Handling

### Cache Key Parsing Errors

**Scenario**: Cache key cannot be parsed to extract bucket and object key

**Handling**:
1. Log error with full cache key for debugging
2. Fall back to flat directory structure (no sharding)
3. Continue operation with warning
4. Return cache miss if file not found in flat structure

### Path Construction Errors

**Scenario**: Sharded path construction fails due to invalid characters or filesystem limits

**Handling**:
1. Log error with cache key and attempted path
2. Fall back to BLAKE3 hash-based filename
3. Retry path construction with hashed filename
4. Return error if retry fails

### Metadata File Not Found

**Scenario**: Metadata file doesn't exist at computed path despite being expected

**Handling**:
1. Log diagnostic information:
   - Original cache key
   - Sanitized cache key
   - Computed file path
   - Directory listing of parent directory
2. Return cache miss (None)
3. Allow normal cache population flow

### ETag Mismatch During Lookup

**Scenario**: Cached ETag doesn't match current ETag from S3

**Handling**:
1. Log ETag mismatch with both values
2. Treat all cached ranges as missing
3. Return empty cached_ranges list
4. Caller will fetch from S3 and recache

### HEAD Cache Invalidation Failure

**Scenario**: Deletion of cached files fails during invalidation

**Handling**:
1. Log deletion failure with file path and error
2. Continue attempting to delete remaining files
3. Return success if at least metadata was deleted
4. Log warning for any files that couldn't be deleted

## Testing Strategy

### Unit Tests

1. **Cache Key Sanitization Tests**
   - Test that same key produces same sanitized output
   - Test special characters are encoded consistently
   - Test long keys are hashed consistently
   - Test keys with and without leading slashes

2. **Sharded Path Construction Tests**
   - Test bucket extraction from various key formats
   - Test hash-based directory creation
   - Test path construction with special characters
   - Test fallback to flat structure on parse errors

3. **Range Overlap Detection Tests**
   - Test exact match detection
   - Test full containment detection
   - Test partial overlap detection
   - Test non-overlapping ranges

### Integration Tests

1. **Cache Lookup Diagnostic Test** (Requirement 4)
   - Store a range with known cache key
   - Verify metadata file exists at expected path
   - Verify range binary file exists at expected path
   - Call `find_cached_ranges` with same key
   - Assert range is found
   - Verify diagnostic logs show correct path resolution

2. **HEAD Cache Invalidation Test** (Requirement 7)
   - Store ranges for an object with ETag "old-etag"
   - Simulate HEAD request returning ETag "new-etag"
   - Verify all cached ranges are deleted
   - Verify metadata file is deleted
   - Verify invalidation event is logged

3. **Cache Key Format Mismatch Test** (Requirement 5)
   - Store range with key "/bucket/path/to/object"
   - Attempt lookup with key "bucket/path/to/object" (no leading slash)
   - Verify lookup succeeds (keys should be normalized)
   - Verify diagnostic logs show key normalization

### Property-Based Tests

Using `quickcheck` framework:

1. **Property Test: Sanitization Consistency**
   - Generate random cache keys
   - Sanitize each key twice
   - Assert both results are identical

2. **Property Test: Sharded Path Determinism**
   - Generate random cache keys
   - Call `get_sharded_path` multiple times
   - Assert all paths are identical

3. **Property Test: Range Overlap Detection**
   - Generate random range pairs
   - Calculate mathematical overlap
   - Assert system detects overlap correctly

### Diagnostic Test Execution

The diagnostic test should be run with environment variable `RUST_LOG=debug` to capture all diagnostic logging. Output should be analyzed to identify:
- Where cache key format changes
- Where path construction diverges from expected
- Where file existence checks fail
- Where range overlap detection fails

## Implementation Notes

### Cache Key Normalization

All cache keys should be normalized before use:
1. Remove leading slash if present
2. Ensure bucket/object format
3. Apply consistent percent encoding
4. Hash if length exceeds 200 characters

### Sharded Path Construction

The sharding logic must be consistent:
1. Parse bucket from cache key (before first `/`)
2. Hash object key (after first `/`) using BLAKE3
3. Extract first 2 hex digits for level 1 directory
4. Extract next 3 hex digits for level 2 directory
5. Sanitize object key for filename
6. Combine: `base_dir/bucket/XX/YYY/filename`

### HEAD Cache Integration

HEAD cache and GET cache are separate:
- HEAD cache stores metadata only (ETag, Last-Modified, Content-Length)
- GET cache stores actual range data
- HEAD cache TTL is independent of GET cache TTL
- HEAD metadata should be checked before serving GET cache
- Mismatched metadata triggers immediate GET cache deletion

### Diagnostic Logging Format

All diagnostic logs should use a consistent prefix for easy filtering:
- `[CACHE_LOOKUP]` - Cache lookup operations
- `[PATH_RESOLUTION]` - Path construction operations
- `[METADATA_LOOKUP]` - Metadata file operations
- `[RANGE_OVERLAP]` - Range overlap detection
- `[CACHE_INVALIDATION]` - Cache invalidation events
- `[RANGE_MERGE]` - Range merge operations (only when merging is actually performed)

This allows filtering logs with: `grep "\[CACHE_LOOKUP\]" logfile`

### Range Merge Logging Optimization

Range merge operations should only be logged when merging is actually necessary:

**Do NOT log merge operations when:**
- Requested range exactly matches a cached range (exact match optimization)
- Requested range is fully contained within a single cached range (full containment optimization)

**DO log merge operations when:**
- Multiple cached ranges need to be combined
- Cached ranges and fetched data need to be merged
- Partial overlaps require data assembly from multiple sources

This reduces log noise and makes it easier to identify actual merge operations that may impact performance.
