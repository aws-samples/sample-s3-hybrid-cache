# Requirements Document

## Introduction

This specification addresses a critical cache lookup bug where `find_cached_ranges` returns 0 cached ranges even though the metadata file exists with the correct cache key, contains valid ranges covering the entire file, the ranges are not expired (TTL set to ~10 years), and the range binary files exist on disk. The root cause appears to be in the cache key handling or path resolution logic in the `find_cached_ranges` function in `range_handler.rs` or `disk_cache.rs`.

## Glossary

- **Cache Key**: A unique identifier for cached objects, typically derived from the S3 bucket and object path
- **Metadata File**: A JSON file containing information about cached ranges, including their byte positions, ETags, and expiration times
- **Range Binary File**: A file containing the actual cached data for a specific byte range
- **Sharded Path**: A directory structure using hash-based sharding (bucket/XX/YYY) for scalability
- **Sanitized Key**: A cache key that has been encoded to be filesystem-safe using percent encoding
- **DiskCacheManager**: The component responsible for reading and writing cache files to disk
- **RangeHandler**: The component responsible for processing HTTP range requests and coordinating cache lookups
- **Cache Invalidation**: The process of deleting cached metadata and range binary files from disk when they become stale

## Requirements

### Requirement 1

**User Story:** As a developer, I want detailed diagnostic logging throughout the cache lookup path, so that I can identify exactly where the cache lookup is failing.

#### Acceptance Criteria

1. WHEN `find_cached_ranges` is called in `range_handler.rs` THEN THE system SHALL log the cache key, requested range, and current ETag being passed to `disk_cache.find_cached_ranges`
2. WHEN `get_new_metadata_file_path` is called THEN THE system SHALL log the input cache key and the resulting file path
3. WHEN `get_metadata` checks for file existence THEN THE system SHALL log whether the metadata file exists at the computed path
4. WHEN metadata is successfully loaded THEN THE system SHALL log the number of ranges found and their byte positions
5. WHEN `find_cached_ranges` in `disk_cache.rs` iterates through ranges THEN THE system SHALL log each range being checked for overlap with the requested range

### Requirement 2

**User Story:** As a developer, I want to verify that cache keys are being consistently sanitized, so that lookups use the same key format as storage operations.

#### Acceptance Criteria

1. WHEN a cache key is sanitized for storage THEN THE system SHALL use the same sanitization function as cache key lookups
2. WHEN `get_new_metadata_file_path` is called THEN THE system SHALL apply the same sanitization logic as `store_range`
3. WHEN cache keys contain special characters THEN THE system SHALL percent-encode them consistently across all operations
4. WHEN cache keys exceed 200 characters THEN THE system SHALL hash them consistently using BLAKE3 across all operations
5. WHEN diagnostic logging is enabled THEN THE system SHALL log both the original and sanitized cache keys for comparison

### Requirement 3

**User Story:** As a developer, I want to verify that sharded paths are being constructed correctly, so that cache lookups find files in the correct directory structure.

#### Acceptance Criteria

1. WHEN `get_sharded_path` is called THEN THE system SHALL parse the bucket name from the cache key correctly
2. WHEN the bucket name is extracted THEN THE system SHALL compute the hash-based shard directories (XX/YYY) correctly
3. WHEN a sharded path is constructed THEN THE system SHALL combine bucket, hash directories, and sanitized filename in the correct order
4. WHEN `get_sharded_path` fails to parse the cache key THEN THE system SHALL fall back to flat structure and log a warning
5. WHEN diagnostic logging is enabled THEN THE system SHALL log the full sharded path being constructed

### Requirement 4

**User Story:** As a developer, I want to add a diagnostic test that reproduces the cache lookup bug, so that I can verify the fix works correctly.

#### Acceptance Criteria

1. WHEN the diagnostic test runs THEN THE system SHALL store a range using `store_range` with a known cache key
2. WHEN the range is stored THEN THE system SHALL verify the metadata file exists at the expected path
3. WHEN the range is stored THEN THE system SHALL verify the range binary file exists at the expected path
4. WHEN `find_cached_ranges` is called with the same cache key THEN THE system SHALL return the stored range
5. WHEN the test completes THEN THE system SHALL clean up all created files

### Requirement 5

**User Story:** As a developer, I want to verify that the cache key format matches between storage and lookup operations, so that I can identify any format mismatches.

#### Acceptance Criteria

1. WHEN a range is stored THEN THE system SHALL log the cache key format being used
2. WHEN a range is looked up THEN THE system SHALL log the cache key format being used
3. WHEN cache keys are compared THEN THE system SHALL detect any differences in format (e.g., leading slashes, URL encoding)
4. WHEN a cache key mismatch is detected THEN THE system SHALL log both versions for comparison
5. WHEN the system processes S3 paths THEN THE system SHALL normalize them consistently (e.g., removing or preserving leading slashes)

### Requirement 6

**User Story:** As a developer, I want to verify that the `get_metadata` function is being called with the correct cache key, so that I can rule out issues in the metadata retrieval logic.

#### Acceptance Criteria

1. WHEN `get_metadata` is called THEN THE system SHALL log the exact cache key received
2. WHEN `get_metadata` constructs the metadata file path THEN THE system SHALL log the full path being checked
3. WHEN `get_metadata` checks file existence THEN THE system SHALL log the result of the existence check
4. WHEN the metadata file exists but is not found THEN THE system SHALL log potential path construction issues
5. WHEN metadata is successfully loaded THEN THE system SHALL log the ETag and number of ranges found

### Requirement 7

**User Story:** As a system operator, I want the GET cache to be automatically invalidated when HEAD metadata indicates the object has changed, so that stale data is never served to clients.

#### Acceptance Criteria

1. WHEN a HEAD request returns object metadata THEN THE system SHALL compare the ETag with the cached GET data ETag
2. WHEN a HEAD request returns object metadata THEN THE system SHALL compare the Last-Modified timestamp with the cached GET data Last-Modified timestamp
3. WHEN the HEAD ETag differs from the cached GET ETag THEN THE system SHALL immediately delete all cached metadata and range binary files for that object
4. WHEN the HEAD Last-Modified differs from the cached GET Last-Modified THEN THE system SHALL immediately delete all cached metadata and range binary files for that object
5. WHEN GET cache is deleted due to HEAD metadata mismatch THEN THE system SHALL log the deletion with both old and new metadata values

### Requirement 8

**User Story:** As a developer, I want range merge operations to only be logged when they are actually performed, so that logs are not cluttered with irrelevant merge information.

#### Acceptance Criteria

1. WHEN a requested range exactly matches a cached range THEN THE system SHALL NOT log range merge operations
2. WHEN a requested range is fully contained within a single cached range THEN THE system SHALL NOT log range merge operations
3. WHEN a requested range requires merging multiple cached ranges THEN THE system SHALL log the merge operation with details
4. WHEN a requested range requires merging cached and fetched data THEN THE system SHALL log the merge operation with cache efficiency metrics
5. WHEN range merge logging occurs THEN THE system SHALL include the number of segments being merged and bytes from each source
