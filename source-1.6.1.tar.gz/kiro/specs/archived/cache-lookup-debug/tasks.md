# Implementation Plan

- [x] 1. Add comprehensive diagnostic logging to cache lookup path
  - Add `[CACHE_LOOKUP]` prefixed debug logs in `range_handler.rs::find_cached_ranges()` showing cache key, requested range, and current ETag
  - Add `[PATH_RESOLUTION]` prefixed debug logs in `disk_cache.rs::get_new_metadata_file_path()` showing input cache key and resulting path
  - Add `[METADATA_LOOKUP]` prefixed debug logs in `disk_cache.rs::get_metadata()` showing cache key, computed path, and file existence check result
  - Add `[RANGE_OVERLAP]` prefixed debug logs in `disk_cache.rs::find_cached_ranges()` showing each range being checked for overlap
  - Ensure all logs include both original and sanitized cache keys for comparison
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.5, 5.1, 5.2, 6.1, 6.2, 6.3, 6.5_

- [ ]* 1.1 Write property test for diagnostic logging completeness
  - **Property 6: Diagnostic logging completeness**
  - **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5**

- [x] 2. Implement cache key validation and normalization
  - Create `CacheKeyValidator` struct to track key transformations
  - Implement cache key normalization function that removes leading slashes consistently
  - Ensure `sanitize_cache_key_new()` is used consistently across all operations
  - Add validation that storage and lookup use identical sanitization
  - Add diagnostic logging for cache key format mismatches
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 5.3, 5.4, 5.5_

- [ ]* 2.1 Write property test for cache key sanitization consistency
  - **Property 1: Cache key sanitization consistency across all operations**
  - **Validates: Requirements 2.1, 2.2, 2.3, 2.4**

- [ ]* 2.2 Write property test for cache key normalization consistency
  - **Property 3: Cache key normalization consistency**
  - **Validates: Requirements 5.3, 5.5**

- [x] 3. Verify and fix sharded path construction
  - Review `get_sharded_path()` implementation for correctness
  - Ensure bucket name parsing handles all valid S3 bucket name formats
  - Verify hash-based directory computation (XX/YYY) is consistent
  - Ensure fallback to flat structure logs appropriate warnings
  - Add diagnostic logging for full sharded path construction
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [ ]* 3.1 Write property test for sharded path construction correctness
  - **Property 2: Sharded path construction correctness**
  - **Validates: Requirements 3.1, 3.2, 3.3**

- [x] 4. Create diagnostic integration test for cache lookup
  - Write test that stores a range with a known cache key
  - Verify metadata file exists at expected sharded path
  - Verify range binary file exists at expected sharded path
  - Call `find_cached_ranges()` with same cache key
  - Assert that the stored range is found and returned
  - Capture and analyze diagnostic logs to identify any path mismatches
  - Test with various cache key formats (with/without leading slash, special characters, long keys)
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

- [ ]* 4.1 Write property test for cache storage and retrieval round-trip
  - **Property 4: Cache storage and retrieval round-trip**
  - **Validates: Requirements 4.4**

- [x] 5. Implement HEAD cache to GET cache invalidation
  - Add `validate_cache_against_head()` function to `DiskCacheManager`
  - Implement ETag comparison between HEAD metadata and cached GET metadata
  - Implement Last-Modified comparison between HEAD metadata and cached GET metadata
  - Call `invalidate_cache_entry()` when metadata mismatch is detected
  - Add `[CACHE_INVALIDATION]` prefixed logging with old and new metadata values
  - Integrate validation check before serving cached GET data
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [ ]* 5.1 Write property test for HEAD metadata comparison triggers invalidation
  - **Property 5: HEAD metadata comparison triggers invalidation**
  - **Validates: Requirements 7.1, 7.2, 7.3, 7.4**

- [ ]* 5.2 Write integration test for HEAD cache invalidation
  - Store ranges for an object with specific ETag and Last-Modified
  - Simulate HEAD request returning different ETag
  - Verify all cached ranges and metadata are deleted
  - Verify invalidation event is logged with both old and new values
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 6. Optimize range merge logging
  - Modify range merge logging to check if merge is actually needed
  - Skip `[RANGE_MERGE]` logs when requested range exactly matches cached range
  - Skip `[RANGE_MERGE]` logs when requested range is fully contained in single cached range
  - Only log merge operations when multiple segments are actually being combined
  - Include cache efficiency metrics (bytes from cache vs S3) in merge logs
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [ ]* 6.1 Write property test for range merge logging optimization
  - **Property 6: Range merge logging only when necessary**
  - **Validates: Requirements 8.1, 8.2, 8.3, 8.4**

- [ ] 7. Run diagnostic test with full logging and analyze results
  - Set `RUST_LOG=debug` environment variable
  - Run the diagnostic integration test from task 4
  - Capture all log output to a file
  - Analyze logs to identify:
    - Where cache key format changes between storage and lookup
    - Where path construction diverges from expected sharded structure
    - Where file existence checks fail despite files existing
    - Where range overlap detection fails to find valid ranges
  - Document findings and create targeted fixes based on analysis
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.5, 3.5, 5.1, 5.2, 6.1, 6.2, 6.3, 6.4, 6.5_

- [x] 8. Fix identified cache lookup bugs
  - Based on diagnostic test analysis, implement targeted fixes for:
    - Cache key format inconsistencies
    - Path construction errors
    - Sanitization mismatches
    - Bucket name parsing issues
  - Ensure all fixes maintain backward compatibility with existing cache structure
  - Re-run diagnostic test to verify fixes resolve the issue
  - _Requirements: All requirements_

- [x] 9. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Fix remaining integration tests for TTL parameter
  - Update `partial_cache_hit_test.rs` to add TTL parameter to all `store_range()` calls
  - Update `range_consolidation_test.rs` to add TTL parameter to all `store_range()` calls
  - Update `non_aligned_range_test.rs` to add TTL parameter to all `store_range()` calls
  - Add `std::time::Duration::from_secs(315360000)` (10 years) as the 6th parameter to each call
  - Run tests to verify all integration tests pass
  - _Requirements: All requirements_
