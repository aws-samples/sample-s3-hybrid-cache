# Implementation Plan

- [x] 1. Extend cache types for write cache tracking
  - [x] 1.1 Add write cache fields to ObjectMetadata
    - Add `is_write_cached: bool` field
    - Add `write_cache_expires_at: Option<SystemTime>` field
    - Add `write_cache_created_at: Option<SystemTime>` field
    - Add `write_cache_last_accessed: Option<SystemTime>` field
    - Ensure backward compatibility with existing metadata files
    - _Requirements: 1.2, 1.3, 5.1_

  - [x] 1.2 Write property test for metadata serialization round-trip
    - **Property 1: Full PUT creates single range**
    - **Validates: Requirements 1.1, 1.2**

  - [x] 1.3 Add MultipartUploadTracker struct
    - Create `MultipartUploadTracker` with uploadId, cache_key, started_at, parts
    - Create `CachedPartInfo` with part_number, size, etag, range_file_path
    - Add serialization/deserialization for JSON storage
    - _Requirements: 2.2, 8.3_

- [x] 2. Implement WriteCacheManager
  - [x] 2.1 Create WriteCacheManager struct
    - Add max_size, current_size (AtomicU64), write_ttl, incomplete_upload_ttl
    - Add eviction_algorithm field
    - Add reference to DiskCacheManager
    - _Requirements: 6.1, 6.5_

  - [x] 2.2 Implement capacity management methods
    - Implement `ensure_capacity(estimated_compressed_size)` with eviction
    - Implement `reserve_capacity(compressed_size)`
    - Implement `release_capacity(compressed_size)`
    - Implement `current_usage()`
    - _Requirements: 6.1, 6.2, 6.3_

  - [x] 2.3 Write property test for capacity enforcement
    - **Property 10: Write cache capacity enforcement with eviction**
    - **Validates: Requirements 6.1, 6.2, 6.5**

  - [x] 2.4 Implement eviction methods
    - Implement `evict_to_target(target_size)` using configured algorithm
    - Implement `evict_incomplete_uploads()` for TTL-based cleanup
    - Use distributed eviction lock for shared cache coordination
    - _Requirements: 6.5, 6.6, 4.2, 4.3_

  - [x] 2.5 Write property test for eviction order
    - **Property 12: Write cache eviction order**
    - **Validates: Requirements 6.5**

- [x] 3. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Implement full PUT caching
  - [x] 4.1 Modify SignedPutHandler for write cache integration
    - Check write cache capacity before caching
    - Store object as single range (0 to content-length-1)
    - Set is_write_cached=true in metadata
    - Set write_cache_expires_at based on put_ttl
    - _Requirements: 1.1, 1.2, 1.3_

  - [x] 4.2 Write property test for full PUT storage
    - **Property 1: Full PUT creates single range**
    - **Validates: Requirements 1.1, 1.2**

  - [x] 4.3 Implement response passthrough
    - Ensure S3 response returned unchanged to client
    - Cache operation happens in background
    - _Requirements: 1.5_

  - [x] 4.4 Write property test for response passthrough
    - **Property 2: Response passthrough**
    - **Validates: Requirements 1.5, 2.4, 3.5, 9.5**

- [x] 5. Implement multipart upload tracking
  - [x] 5.1 Handle CreateMultipartUpload
    - Parse uploadId from S3 response XML
    - Create mpus_in_progress/{uploadId}/upload.meta
    - Record started_at timestamp
    - Return S3 response unchanged
    - _Requirements: 4.1_

  - [x] 5.2 Handle UploadPart caching
    - Store part data as range file with part number suffix
    - Update upload.meta with part info (acquire lock first)
    - Track uploadId, partNumber, size, etag
    - Return S3 response unchanged
    - _Requirements: 2.1, 2.2, 2.4, 2.5_

  - [x] 5.3 Write property test for part storage
    - **Property 5: Multipart part storage**
    - **Validates: Requirements 2.1, 2.2, 2.5**

  - [x] 5.4 Handle CompleteMultipartUpload
    - Acquire lock on upload.meta
    - Read all parts, sort by part number
    - Calculate byte offsets for each part
    - Rename part files with final offsets
    - Create object metadata with final ETag from S3 XML
    - Set is_write_cached=true, write_cache_expires_at
    - Delete mpus_in_progress/{uploadId}/
    - Return S3 response unchanged
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

  - [x] 5.5 Write property test for byte offset calculation
    - **Property 6: Multipart byte offset calculation**
    - **Validates: Requirements 2.3, 3.2**

  - [x] 5.6 Write property test for completion metadata
    - **Property 7: Multipart completion creates linked metadata**
    - **Validates: Requirements 3.1, 3.3, 3.4**

- [x] 6. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Implement TTL management
  - [x] 7.1 Implement TTL refresh on GET access
    - When serving write-cached object via GET, update write_cache_expires_at
    - Update write_cache_last_accessed
    - _Requirements: 1.4, 5.2_

  - [x] 7.2 Write property test for TTL refresh
    - **Property 4: TTL refresh on access**
    - **Validates: Requirements 1.4, 5.2**

  - [x] 7.3 Implement TTL-based expiration
    - Check write_cache_expires_at on access (lazy expiration)
    - If actively_remove_cached_data=true, include in daily scan
    - _Requirements: 5.3, 5.4_

- [x] 8. Implement incomplete upload cleanup
  - [x] 8.1 Implement AbortMultipartUpload handling
    - Forward to S3
    - Delete all cached parts for uploadId
    - Delete mpus_in_progress/{uploadId}/
    - Return S3 response unchanged
    - _Requirements: 4.5, 4.6_

  - [x] 8.2 Write property test for abort cleanup
    - **Property 9: Abort upload cleanup**
    - **Validates: Requirements 4.5, 8.5_

  - [x] 8.3 Implement incomplete upload scanner
    - Acquire distributed eviction lock
    - Scan mpus_in_progress/ for upload.meta files
    - Check file mtime for last activity
    - Evict uploads where mtime + incomplete_upload_ttl < now
    - Acquire per-upload lock before deletion
    - _Requirements: 4.2, 4.3, 8a.4_

  - [x] 8.4 Write property test for incomplete upload eviction
    - **Property 8: Incomplete upload eviction**
    - **Validates: Requirements 4.2, 4.3**

- [x] 9. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Implement startup and scheduled tasks
  - [x] 10.1 Add write cache cleanup to startup
    - Clean up incomplete uploads older than TTL
    - Calculate write cache usage from metadata
    - Initialize WriteCacheManager.current_size
    - Log write cache status
    - _Requirements: 4.2, 6.3_

  - [x] 10.2 Add write cache to daily validation scan
    - If actively_remove_cached_data=true, scan for expired write-cached objects
    - Always run incomplete upload cleanup
    - _Requirements: 5.3, 5.4_

  - [x] 10.3 Integrate with CacheSizeTracker
    - Add write cache size tracking to delta log
    - Add write_cache_size to checkpoint
    - Update validation scan to distinguish write vs read cache
    - _Requirements: 6.3_

- [x] 11. Implement cache coherency
  - [x] 11.1 Handle DELETE invalidation
    - Invalidate write-cached objects on DELETE
    - _Requirements: 9.3_

  - [x] 11.2 Handle PUT overwrite
    - Replace existing cache entry on new PUT
    - Reset TTL
    - _Requirements: 5.6, 9.4_

  - [x] 11.3 Write property test for overwrite behavior
    - **Property 16: Cache invalidation on overwrite**
    - **Validates: Requirements 5.5, 9.4**

  - [x] 11.4 Handle S3 errors
    - Don't cache on S3 error
    - Return error unchanged to client
    - _Requirements: 9.1, 9.5, 10.1_

  - [x] 11.5 Write property test for no caching on failure
    - **Property 15: No caching on S3 failure**
    - **Validates: Requirements 9.1**

- [x] 12. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 13. Add configuration options
  - [x] 13.1 Add incomplete_upload_ttl config
    - Add to CacheConfig struct
    - Add validation (1h to 7d range)
    - Add to config.example.yaml with documentation
    - _Requirements: 4.4, 12.4_

  - [x] 13.2 Update existing write cache config documentation
    - Document write_cache_enabled
    - Document write_cache_percent
    - Document put_ttl
    - Document write_cache_max_object_size
    - _Requirements: 12.1, 12.2, 12.3, 12.5_

- [x] 14. Add monitoring and logging
  - [x] 14.1 Add write cache metrics
    - Add write_cache_size metric
    - Add write_cache_hits counter
    - Add incomplete_uploads_evicted counter
    - _Requirements: 11.4_

  - [x] 14.2 Add logging for write cache operations
    - Log PUT cache operations with key, size, TTL
    - Log bypass reasons
    - Log incomplete upload evictions
    - Log write cache hits on GET
    - _Requirements: 11.1, 11.2, 11.3, 11.5_

- [x] 15. Final Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.


- [x] 16. Documentation and cleanup
  - [x] 16.1 Update CONFIGURATION.md
    - Document incomplete_upload_ttl configuration
    - Update write cache section with finalized behavior
    - Add examples for multipart upload caching
    - _Requirements: 12.4_

  - [x] 16.2 Update docs/CACHING.md
    - Add write-through caching section
    - Document multipart upload caching behavior
    - Document TTL refresh on read
    - Document incomplete upload eviction
    - Add shared cache considerations
    - _Requirements: 11.1, 11.2, 11.3_

  - [x] 16.3 Update README.md
    - Update feature list to reflect finalized write caching
    - Update configuration example
    - _Requirements: 12.1_

  - [x] 16.4 Clean up repository
    - Review and archive obsolete write cache specs:
      - .kiro/specs/signed-put-caching/ (superseded by this spec)
      - .kiro/specs/write-cache-to-range-transition/ (superseded by this spec)
      - .kiro/specs/write-cache-path-fix/ (superseded by this spec)
      - .kiro/specs/optional-write-caching/ (incorporated into this spec)
    - Move archived specs to .kiro/specs/archived/
    - Remove any temporary test files or debug artifacts
    - Ensure all new source files are properly formatted (cargo fmt)
    - Run cargo clippy and fix any warnings

  - [x] 16.5 Update config.example.yaml
    - Add incomplete_upload_ttl with documentation
    - Ensure all write cache options are documented
    - _Requirements: 12.4_

- [x] 17. Final Checkpoint - Full test suite and documentation review
  - Ensure all tests pass, ask the user if questions arise.
  - Verify documentation is complete and accurate.
