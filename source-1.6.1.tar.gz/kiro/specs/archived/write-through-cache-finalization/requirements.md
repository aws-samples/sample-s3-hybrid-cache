# Requirements Document: Write-Through Cache Finalization

## Introduction

The S3 Proxy currently has an incomplete write-through caching implementation for PUT operations. This specification finalizes the write cache feature to provide a complete, production-ready solution. Write caching enables subsequent GET requests to be served from cache immediately after a successful PUT, eliminating the need to fetch from S3.

Key aspects of this finalization:
- Full PUT operations stored as single ranges
- Multipart uploads stored as ranges with part information for GET part, GET range, and GET full object cache hits
- Incomplete multipart uploads evicted after configurable timeout (default: 1 hour)
- Write cache has separate TTL (default: 1 day), refreshed on read
- Write cache limited to configurable percentage of disk cache (default: 10%)
- Write cache does not consume RAM cache
- All S3 responses returned to client unchanged

## Glossary

- **Write Cache**: Cache storage for objects uploaded via PUT requests, with separate TTL and capacity limits
- **Full PUT**: A single PutObject operation that uploads an entire object in one request
- **Multipart Upload**: An upload split into multiple UploadPart requests, finalized by CompleteMultipartUpload
- **UploadPart**: Individual part of a multipart upload, identified by uploadId and partNumber
- **CompleteMultipartUpload**: S3 API call that assembles parts into a final object
- **AbortMultipartUpload**: S3 API call that cancels an in-progress multipart upload
- **CreateMultipartUpload**: S3 API call that initiates a multipart upload and returns an uploadId
- **Range**: A contiguous byte range of an object, stored as a separate file
- **Write Cache TTL**: Time-to-live for write-cached objects (default: 1 day), refreshed on read access
- **Incomplete Upload TTL**: Time-to-live for incomplete multipart uploads (default: 1 day)
- **Write Cache Capacity**: Maximum disk space for write cache, expressed as percentage of total cache
- **ETag**: Entity tag returned by S3 that uniquely identifies an object version
- **uploadId**: Unique identifier for a multipart upload session

## Requirements

### Requirement 1: Full PUT Object Caching

**User Story:** As a system operator, I want full PUT requests to be cached as single ranges, so that subsequent GET requests can be served from cache.

#### Acceptance Criteria

1. WHEN a PutObject request succeeds (S3 returns 200), THEN the Proxy SHALL store the object data as a single range (0 to content-length-1)
2. WHEN storing a full PUT, THEN the Proxy SHALL create metadata with ETag and Content-Type from S3 response (Last-Modified learned on first cache-miss GET or first HEAD after PUT)
3. WHEN storing a full PUT, THEN the Proxy SHALL set the write cache TTL (default: 1 day)
4. WHEN a cached PUT object is accessed via GET, THEN the Proxy SHALL refresh the TTL
5. WHEN the S3 PutObject response is received, THEN the Proxy SHALL return it to the client unchanged

### Requirement 2: Multipart Upload Part Caching

**User Story:** As a system operator, I want multipart upload parts to be cached, so that GET requests for parts or ranges can be served from cache.

#### Acceptance Criteria

1. WHEN an UploadPart request succeeds, THEN the Proxy SHALL store the part data as a range file with part number metadata
2. WHEN storing an UploadPart, THEN the Proxy SHALL track the uploadId, partNumber, size, and ETag
3. WHEN storing an UploadPart, THEN the Proxy SHALL calculate cumulative byte offset based on previously cached parts
4. WHEN an UploadPart response is received, THEN the Proxy SHALL return it to the client unchanged
5. WHEN multiple parts are uploaded, THEN the Proxy SHALL store each part as a separate range file

### Requirement 3: Multipart Upload Completion

**User Story:** As a system operator, I want completed multipart uploads to be queryable as full objects, so that GET full object, GET range, and GET part requests all result in cache hits.

#### Acceptance Criteria

1. WHEN CompleteMultipartUpload succeeds, THEN the Proxy SHALL create object metadata linking all cached parts as ranges
2. WHEN creating completion metadata, THEN the Proxy SHALL calculate final byte offsets for each part
3. WHEN creating completion metadata, THEN the Proxy SHALL store the final ETag from S3 response
4. WHEN CompleteMultipartUpload succeeds, THEN the Proxy SHALL set the write cache TTL on the completed object
5. WHEN a CompleteMultipartUpload response is received, THEN the Proxy SHALL return it to the client unchanged

### Requirement 4: Incomplete Multipart Upload Eviction

**User Story:** As a system operator, I want incomplete multipart uploads to be automatically evicted, so that abandoned uploads don't consume cache space indefinitely.

#### Acceptance Criteria

1. WHEN a multipart upload is initiated (CreateMultipartUpload), THEN the Proxy SHALL record the uploadId and start time
2. WHEN an incomplete multipart upload exceeds the incomplete upload TTL (default: 1 day), THEN the Proxy SHALL evict all cached parts
3. WHEN evicting incomplete uploads, THEN the Proxy SHALL remove both part data files and tracking metadata
4. WHEN the incomplete upload TTL is configurable, THEN the Proxy SHALL accept values from 1 hour to 7 days
5. WHEN AbortMultipartUpload is received, THEN the Proxy SHALL forward to S3 and immediately evict all cached parts for that uploadId
6. WHEN AbortMultipartUpload response is received, THEN the Proxy SHALL return it to the client unchanged

### Requirement 5: Write Cache TTL Management

**User Story:** As a system operator, I want write-cached objects to have a separate TTL that refreshes on read, so that frequently accessed objects remain cached.

#### Acceptance Criteria

1. WHEN a write-cached object is stored, THEN the Proxy SHALL set expiration to current time plus write cache TTL
2. WHEN a write-cached object is accessed via GET, THEN the Proxy SHALL refresh the expiration time
3. WHEN a write-cached object expires AND actively_remove_cached_data is true, THEN the Proxy SHALL actively remove it in background scans
4. WHEN a write-cached object expires AND actively_remove_cached_data is false, THEN the Proxy SHALL remove it lazily on access or via capacity eviction
5. WHEN the write cache TTL is configurable, THEN the Proxy SHALL accept values from 1 minute to 30 days
6. WHEN a write-cached object is overwritten by a new PUT, THEN the Proxy SHALL reset the TTL

### Requirement 6: Write Cache Capacity Limits

**User Story:** As a system operator, I want write cache to be limited to a percentage of disk cache, so that read cache is not starved by write operations.

#### Acceptance Criteria

1. WHEN write cache capacity is configured, THEN the Proxy SHALL limit write cache to that percentage of total disk cache (default: 10%)
2. WHEN a new PUT request would exceed write cache capacity, THEN the Proxy SHALL first attempt to evict existing write-cached objects
3. WHEN eviction cannot free sufficient space for a new PUT, THEN the Proxy SHALL bypass caching for that request
4. WHEN checking capacity, THEN the Proxy SHALL consider only write-cached objects, not read-cached objects
5. WHEN write cache capacity is configurable, THEN the Proxy SHALL accept values from 1% to 50%
6. WHEN evicting write-cached objects, THEN the Proxy SHALL use the configured eviction algorithm (LRU or TinyLFU), consistent with read cache eviction

### Requirement 7: Write Cache Initial Storage

**User Story:** As a system operator, I want PUT operations to write directly to disk cache, so that RAM cache is not consumed by write operations.

#### Acceptance Criteria

1. WHEN a PUT object is cached, THEN the Proxy SHALL store it only on disk, not in RAM cache
2. WHEN a write-cached object is accessed via GET, THEN the Proxy SHALL serve from disk cache initially
3. WHEN a write-cached object is accessed via GET, THEN the Proxy SHALL treat it like any other cached range for RAM cache promotion
4. WHEN a write-cached range is promoted to RAM cache, THEN it SHALL follow normal RAM cache eviction rules
5. WHEN calculating write cache capacity, THEN the Proxy SHALL only count disk storage, not RAM cache copies

### Requirement 8: Multipart Upload Storage Location

**User Story:** As a system operator, I want multipart upload parts stored in the standard cache location, so that cache management is simplified.

#### Acceptance Criteria

1. WHEN storing multipart upload parts, THEN the Proxy SHALL use the standard ranges directory structure
2. WHEN storing multipart upload parts, THEN the Proxy SHALL use the same sharding scheme as read cache
3. WHEN tracking incomplete uploads, THEN the Proxy SHALL maintain metadata in the mpus_in_progress directory
4. WHEN a multipart upload completes, THEN the Proxy SHALL move tracking metadata to standard object metadata
5. WHEN a multipart upload is aborted or expires, THEN the Proxy SHALL clean up both parts and tracking metadata

### Requirement 8a: Shared Cache Support for Multipart Uploads

**User Story:** As a system operator running multiple proxy instances with a shared cache volume, I want multipart uploads to work correctly regardless of which instance handles each request.

#### Acceptance Criteria

1. WHEN multiple instances share a cache volume, THEN any instance SHALL be able to handle CreateMultipartUpload, UploadPart, or CompleteMultipartUpload for the same upload
2. WHEN updating multipart upload tracking metadata, THEN the Proxy SHALL acquire a file lock to prevent concurrent modifications
3. WHEN completing a multipart upload, THEN the Proxy SHALL read parts from the shared tracking file regardless of which instance cached them
4. WHEN scanning for incomplete uploads, THEN the Proxy SHALL use the distributed eviction lock to prevent duplicate cleanup
5. WHEN checking upload expiration, THEN the Proxy SHALL use file modification time from the shared filesystem to avoid clock skew issues

### Requirement 9: Cache Coherency with S3

**User Story:** As a system operator, I want write cache to maintain coherency with S3, so that stale data is not served.

#### Acceptance Criteria

1. WHEN a PUT request fails at S3, THEN the Proxy SHALL NOT cache the data
2. WHEN a cached object's ETag differs from S3 response, THEN the Proxy SHALL invalidate the cache entry
3. WHEN a DELETE request is received for a cached object, THEN the Proxy SHALL invalidate the cache entry
4. WHEN a new PUT overwrites an existing cached object, THEN the Proxy SHALL replace the cache entry
5. WHEN S3 returns an error for any operation, THEN the Proxy SHALL return the error to the client unchanged

### Requirement 10: Error Handling

**User Story:** As a system operator, I want write cache errors to be handled gracefully, so that S3 operations succeed even if caching fails.

#### Acceptance Criteria

1. WHEN cache write fails, THEN the Proxy SHALL log the error and continue without caching
2. WHEN cache capacity is exceeded during streaming, THEN the Proxy SHALL discard cached data and continue forwarding
3. WHEN disk is full, THEN the Proxy SHALL bypass caching and forward requests directly to S3
4. WHEN metadata write fails, THEN the Proxy SHALL clean up any partial cache data
5. WHEN cache read fails for a write-cached object, THEN the Proxy SHALL fetch from S3

### Requirement 11: Monitoring and Observability

**User Story:** As a system operator, I want visibility into write cache behavior, so that I can monitor effectiveness and troubleshoot issues.

#### Acceptance Criteria

1. WHEN a PUT is cached, THEN the Proxy SHALL log the operation with cache key, size, and TTL
2. WHEN a PUT bypasses cache, THEN the Proxy SHALL log the reason (capacity, error, disabled)
3. WHEN an incomplete multipart upload is evicted, THEN the Proxy SHALL log the uploadId and age
4. WHEN write cache capacity is reached, THEN the Proxy SHALL emit a metric
5. WHEN a write-cached object is served via GET, THEN the Proxy SHALL log it as a write cache hit

### Requirement 12: Configuration

**User Story:** As a system operator, I want write cache behavior to be configurable, so that I can tune it for my workload.

#### Acceptance Criteria

1. WHEN write_cache_enabled is false, THEN the Proxy SHALL not cache any PUT operations
2. WHEN write_cache_percent is configured, THEN the Proxy SHALL limit write cache to that percentage of disk cache
3. WHEN put_ttl is configured, THEN the Proxy SHALL use that value for write cache TTL
4. WHEN incomplete_upload_ttl is configured, THEN the Proxy SHALL use that value for incomplete multipart eviction
5. WHEN write_cache_max_object_size is configured, THEN the Proxy SHALL bypass caching for objects larger than that size
