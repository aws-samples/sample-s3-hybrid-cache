# Design Document: Write-Through Cache Finalization

## Overview

This design finalizes the write-through caching implementation for PUT operations in the S3 Proxy. The system caches uploaded objects so that subsequent GET requests can be served from cache without fetching from S3. The design handles both full PUT operations and multipart uploads, with separate TTL management and capacity limits for write-cached data.

Key design decisions:
- **Unified storage**: Write-cached data uses the same ranges directory structure as read cache
- **Separate capacity tracking**: Write cache limited to configurable percentage (default 10%) of disk cache
- **TTL refresh on read**: Write cache TTL (default 1 day) refreshes when objects are accessed
- **Incomplete upload eviction**: Multipart uploads not completed within TTL (default 1 day) are evicted
- **Disk-only storage**: Write cache does not consume RAM cache to preserve RAM for hot read data

## S3 API Reference

Based on AWS S3 API documentation:

### PutObject Response
- Returns `ETag` header (MD5 hash or multipart ETag format)
- Returns `x-amz-version-id` if versioning enabled
- Returns checksum headers if checksums were provided in request
- HTTP 200 on success

### CreateMultipartUpload Response
- Returns XML body with `UploadId`, `Bucket`, `Key`
- HTTP 200 on success
- The `UploadId` is required for all subsequent UploadPart and CompleteMultipartUpload calls

### UploadPart Response
- Returns `ETag` header for the part (MD5 of part data)
- Returns `x-amz-server-side-encryption` if SSE enabled
- HTTP 200 on success
- Part numbers must be 1-10000
- Part size minimum 5MB (except last part), maximum 5GB

### CompleteMultipartUpload Response
- Returns XML body with `Location`, `Bucket`, `Key`, `ETag`
- The final `ETag` is NOT a simple MD5 - it's formatted as `"hash-N"` where N is part count
- HTTP 200 on success
- Parts are assembled in part number order (not upload order)

## Architecture

### Data Flow: Full PUT

```
Client PUT /bucket/object
         │
         ▼
┌─────────────────────────────────────┐
│     SignedPutHandler                │
│  1. Check write cache capacity      │
│  2. Stream body to temp file        │
│  3. Forward to S3                   │
└──────────────┬──────────────────────┘
               │
    ┌──────────┴──────────┐
    │                     │
    ▼                     ▼
┌────────┐         ┌──────────────┐
│   S3   │         │ Temp Cache   │
└────┬───┘         │ (.tmp file)  │
     │             └──────────────┘
     │ 200 OK
     ▼
┌─────────────────────────────────────┐
│     Background Task                  │
│  1. Commit temp → range file        │
│  2. Create metadata with TTL        │
│  3. Track as write-cached           │
└─────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│  ranges/{bucket}/{XX}/{YYY}/        │
│    {key}_0-{size-1}.bin             │
│  objects/{bucket}/{XX}/{YYY}/       │
│    {key}.meta (is_write_cached=true)│
└─────────────────────────────────────┘
```

### Data Flow: Multipart Upload

```
CreateMultipartUpload
         │
         ▼
┌─────────────────────────────────────┐
│  Forward to S3, get UploadId        │
│  Return XML response to client      │
│  Create: mpus_in_progress/{uploadId}│
│    upload.meta (start_time, key)    │
└─────────────────────────────────────┘

UploadPart (partNumber=1, uploadId=xyz)
         │
         ▼
┌─────────────────────────────────────┐
│  Stream body to S3 + temp file      │
│  S3 returns ETag for part           │
│  Return response to client          │
│  Store: ranges/{bucket}/{XX}/{YYY}/ │
│    {key}_part1_0-{size-1}.bin       │
│  Update: mpus_in_progress/{uploadId}│
│    upload.meta (add part1 info)     │
└─────────────────────────────────────┘

UploadPart (partNumber=2, uploadId=xyz)
         │
         ▼
┌─────────────────────────────────────┐
│  Same flow as part 1                │
│  Store: {key}_part2_0-{size-1}.bin  │
│  Update upload.meta with part2      │
└─────────────────────────────────────┘

CompleteMultipartUpload (uploadId=xyz)
         │
         ▼
┌─────────────────────────────────────┐
│  Forward to S3                      │
│  S3 returns final ETag in XML body  │
│  Return response to client          │
│  Calculate final byte offsets:      │
│    part1: 0 to size1-1              │
│    part2: size1 to size1+size2-1    │
│  Rename range files with offsets    │
│  Create object metadata with ETag   │
│  Delete mpus_in_progress/{uploadId} │
└─────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│  ranges/{bucket}/{XX}/{YYY}/        │
│    {key}_0-{size1-1}.bin            │
│    {key}_{size1}-{total-1}.bin      │
│  objects/{bucket}/{XX}/{YYY}/       │
│    {key}.meta (is_write_cached=true,│
│                etag from S3 XML)    │
└─────────────────────────────────────┘
```

### Data Flow: AbortMultipartUpload

```
AbortMultipartUpload (uploadId=xyz)
         │
         ▼
┌─────────────────────────────────────┐
│  Forward to S3                      │
│  Return response to client          │
│  Delete all cached parts for upload │
│  Delete mpus_in_progress/{uploadId} │
└─────────────────────────────────────┘
```

## Components and Interfaces

### WriteCacheManager

New component responsible for write cache capacity tracking and eviction.

```rust
pub struct WriteCacheManager {
    /// Maximum write cache size in bytes
    max_size: u64,
    /// Current write cache usage in bytes
    current_size: AtomicU64,
    /// Write cache TTL
    write_ttl: Duration,
    /// Incomplete upload TTL
    incomplete_upload_ttl: Duration,
    /// Eviction algorithm (same as read cache: LRU or TinyLFU)
    eviction_algorithm: CacheEvictionAlgorithm,
    /// Reference to disk cache for storage operations
    disk_cache: Arc<DiskCacheManager>,
}

impl WriteCacheManager {
    /// Check if there's capacity for a new write, evicting if necessary
    /// `estimated_compressed_size` is the expected compressed size on disk
    /// Returns true if space is available (possibly after eviction)
    pub async fn ensure_capacity(&self, estimated_compressed_size: u64) -> bool;
    
    /// Reserve capacity for a write (call after ensure_capacity succeeds)
    /// `compressed_size` is the actual compressed size written to disk
    pub fn reserve_capacity(&self, compressed_size: u64);
    
    /// Release capacity after eviction or expiration
    /// `compressed_size` is the compressed size being freed
    pub fn release_capacity(&self, compressed_size: u64);
    
    /// Get current write cache usage (compressed bytes on disk)
    pub fn current_usage(&self) -> u64;
    
    /// Evict write-cached objects to free space using configured algorithm
    /// Uses same eviction algorithm as read cache (LRU or TinyLFU)
    /// Returns compressed bytes freed
    pub async fn evict_to_target(&self, target_size: u64) -> Result<u64>;
    
    /// Evict incomplete multipart uploads older than TTL
    /// Returns compressed bytes freed
    pub async fn evict_incomplete_uploads(&self) -> Result<u64>;
}
```

**Compression and Capacity**:
- All capacity tracking uses **compressed size** (actual disk usage)
- When checking capacity before write: estimate compressed size (use compression ratio heuristic)
- After write completes: update with actual compressed size
- This ensures capacity limits reflect real disk usage

### Shared Disk Capacity Tracking

The existing `CacheSizeTracker` handles shared disk scenarios and is extended for write cache:

**How it works**:
1. **Delta logging**: Each write/delete operation logs a delta to `size_tracking/delta.log`
2. **Periodic checkpoints**: Checkpoint file stores cumulative size
3. **Startup recovery**: Read checkpoint + replay deltas since checkpoint
4. **Periodic validation**: Full scan to correct drift (scheduled, not on every operation)

**Write cache extension**:
- Write cache usage tracked separately from read cache
- Delta log entries tagged with `type: "write"` or `type: "read"`
- Checkpoint stores both `read_cache_size` and `write_cache_size`
- Validation scan distinguishes by `is_write_cached` metadata flag

**Multi-instance behavior**:
- Each instance logs deltas to shared `delta.log` (append-only, atomic)
- Checkpoint updates use file locking
- Validation scan uses distributed eviction lock
- All instances converge to same usage values

**Accuracy vs Performance tradeoff**:
- Delta logging is fast (append-only)
- Checkpoint is periodic (not every operation)
- Validation corrects drift (scheduled, e.g., daily)
- Capacity checks use in-memory counter (fast, eventually consistent)
```

### Modified ObjectMetadata

Extended to track write cache status:

```rust
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub content_type: Option<String>,
    pub response_headers: HashMap<String, String>,
    pub upload_state: UploadState,
    pub cumulative_size: u64,
    pub parts: Vec<PartInfo>,
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub parts_count: Option<u32>,
    pub part_size: Option<u64>,
    pub upload_id: Option<String>,
    
    // NEW: Write cache tracking
    pub is_write_cached: bool,
    pub write_cache_expires_at: Option<SystemTime>,
    pub write_cache_created_at: Option<SystemTime>,
    pub write_cache_last_accessed: Option<SystemTime>,
}
```

### MultipartUploadTracker

Tracks in-progress multipart uploads:

```rust
pub struct MultipartUploadTracker {
    pub upload_id: String,
    pub cache_key: String,
    pub started_at: SystemTime,
    pub parts: Vec<CachedPartInfo>,
    pub total_size: u64,
}

pub struct CachedPartInfo {
    pub part_number: u32,
    pub size: u64,
    pub etag: String,
    pub range_file_path: String,
}
```

## Data Models

### Write Cache Entry Storage

Write-cached objects are stored identically to read-cached objects, with additional metadata:

```
# Full PUT object
ranges/{bucket}/{XX}/{YYY}/{key}_0-{size-1}.bin
objects/{bucket}/{XX}/{YYY}/{key}.meta

# Multipart upload (in progress)
ranges/{bucket}/{XX}/{YYY}/{key}_part{N}_0-{partsize-1}.bin
mpus_in_progress/{uploadId}/upload.meta

# Multipart upload (completed)
ranges/{bucket}/{XX}/{YYY}/{key}_0-{offset1}.bin
ranges/{bucket}/{XX}/{YYY}/{key}_{offset1+1}-{offset2}.bin
...
objects/{bucket}/{XX}/{YYY}/{key}.meta
```

### Metadata File Format

```json
{
  "cache_key": "bucket/path/to/object",
  "object_metadata": {
    "etag": "\"abc123\"",
    "last_modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    "content_length": 1048576,
    "content_type": "application/octet-stream",
    "is_write_cached": true,
    "write_cache_expires_at": "2024-12-15T10:30:00Z",
    "write_cache_created_at": "2024-12-14T10:30:00Z",
    "write_cache_last_accessed": "2024-12-14T15:45:00Z"
  },
  "ranges": [
    {
      "start": 0,
      "end": 1048575,
      "file_path": "bucket/ab/cde/object_0-1048575.bin",
      "compression_algorithm": "Lz4",
      "compressed_size": 524288,
      "uncompressed_size": 1048576
    }
  ],
  "created_at": "2024-12-14T10:30:00Z",
  "expires_at": "2024-12-15T10:30:00Z"
}
```

### Multipart Upload Tracking File

```json
{
  "upload_id": "abc123xyz",
  "cache_key": "bucket/path/to/object",
  "started_at": "2024-12-14T10:30:00Z",
  "parts": [
    {
      "part_number": 1,
      "size": 5242880,
      "etag": "\"d8e8fca2dc0f896fd7cb4cb0031ba249\"",
      "range_file_path": "bucket/ab/cde/object_part1_0-5242879.bin"
    },
    {
      "part_number": 2,
      "size": 5242880,
      "etag": "\"7b52009b64fd0a2a49e6d8a939753077\"",
      "range_file_path": "bucket/ab/cde/object_part2_0-5242879.bin"
    }
  ],
  "total_size": 10485760
}
```

## Shared Cache Considerations

### Multi-Instance Deployment Scenarios

When multiple proxy instances share a cache volume (e.g., NFS, EFS, shared Docker volume), multipart uploads may be distributed across instances:

**Scenario 1: Parts uploaded to different instances**
```
Instance A: CreateMultipartUpload → returns uploadId
Instance B: UploadPart 1 (uploadId)
Instance A: UploadPart 2 (uploadId)
Instance C: CompleteMultipartUpload (uploadId)
```

**Scenario 2: Incomplete upload scanner race**
```
Instance A: Scans mpus_in_progress/, finds expired upload
Instance B: Scans mpus_in_progress/, finds same expired upload
Both try to delete → potential race condition
```

### Design for Shared Cache

1. **Part data storage (NO lock needed)**
   - Each part has a unique filename: `{key}_part{N}_0-{size-1}.bin`
   - Different part numbers → different files → no conflict
   - Same part number uploaded twice → atomic overwrite (S3 allows re-upload)
   - Write uses temp file + atomic rename → no partial reads

2. **Tracking metadata updates (lock needed)**
   - `mpus_in_progress/{uploadId}/upload.meta` tracks all parts
   - Lock acquired when updating tracking file
   - Lock scope: only the specific uploadId, not global
   - Concurrent uploads to DIFFERENT uploadIds → no contention

3. **Concurrent part uploads to SAME uploadId**
   ```
   Instance A: UploadPart 1 → write part1.bin (no lock)
   Instance B: UploadPart 2 → write part2.bin (no lock)
   Instance A: Update tracking → acquire lock, add part1, release
   Instance B: Update tracking → acquire lock, add part2, release
   ```
   - Part data writes are parallel (different files)
   - Tracking updates are serialized (same file)
   - Lock contention is brief (just metadata update)

4. **CompleteMultipartUpload coordination**
   - Acquire lock on `mpus_in_progress/{uploadId}/upload.meta`
   - Read all parts from tracking file
   - Calculate offsets, rename files
   - Create object metadata
   - Delete tracking directory
   - Release lock

5. **Incomplete upload scanner coordination**
   - Uses distributed eviction lock (same as read cache eviction)
   - Only one instance scans at a time
   - Prevents duplicate cleanup work

### File Locking Strategy

```rust
// For multipart upload operations
async fn with_upload_lock<F, T>(upload_id: &str, operation: F) -> Result<T>
where
    F: FnOnce() -> Future<Output = Result<T>>
{
    let lock_path = mpus_in_progress/{upload_id}/upload.lock;
    let lock = acquire_file_lock(&lock_path, timeout)?;
    let result = operation().await;
    release_file_lock(lock)?;
    result
}
```

### Edge Cases

1. **Instance crashes during CompleteMultipartUpload**
   - Lock times out after `lock_timeout_seconds`
   - Next instance can retry completion
   - Parts remain intact until completion or TTL expiration

2. **Network partition during part upload**
   - Part may be partially written
   - S3 will reject CompleteMultipartUpload if parts are invalid
   - Incomplete upload scanner cleans up after TTL

3. **Clock skew between instances**
   - Use file modification time (from shared filesystem) for TTL checks
   - Avoid relying on instance-local clocks for expiration

4. **GET request during incomplete multipart upload**
   - Proxy checks existing read cache first (object may exist from previous upload)
   - If cache miss, forward to S3 (S3 is source of truth)
   - In-progress upload parts are NOT served - they're internal tracking only
   - Parts only become accessible after CompleteMultipartUpload creates object metadata
   - This ensures we never serve partial/inconsistent data

5. **Object exists, then new multipart upload started**
   - Existing cached object remains valid until new upload completes
   - GET requests continue to serve existing cached version
   - On CompleteMultipartUpload: new object metadata replaces old
   - Old ranges invalidated, new ranges become active

6. **ListParts during upload**
   - S3 API: ListParts returns parts for an in-progress upload
   - Proxy: Forward to S3 (no caching of ListParts responses)
   - Cached parts are internal tracking only, not exposed via ListParts

## S3 API Considerations

### Part Number Ordering

S3 assembles parts in **part number order**, not upload order. If parts are uploaded as 3, 1, 2, the final object is assembled as 1, 2, 3. The design handles this by:
1. Storing parts with their part number in the filename
2. Sorting parts by part_number during CompleteMultipartUpload
3. Calculating byte offsets based on sorted order

### ETag Format

- **PutObject**: ETag is MD5 hash of content (32 hex chars)
- **UploadPart**: ETag is MD5 hash of part content
- **CompleteMultipartUpload**: Final ETag is `"hash-N"` format where N is part count
  - Example: `"d41d8cd98f00b204e9800998ecf8427e-3"` for 3-part upload
  - This is NOT the MD5 of the full object

### Part Size Constraints

- Minimum part size: 5MB (5,242,880 bytes) except for last part
- Maximum part size: 5GB
- Maximum parts: 10,000
- The proxy does not enforce these - S3 will reject invalid requests

### Checksum Headers

S3 supports optional checksums (CRC32, CRC32C, SHA1, SHA256). The proxy:
1. Passes checksum headers through to S3 unchanged
2. Does NOT validate checksums (S3 handles validation)
3. Stores checksum headers in metadata for response reconstruction
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Full PUT creates single range

*For any* successful PutObject request, the cached data SHALL be stored as a single range file spanning bytes 0 to content-length-1, and the metadata SHALL contain exactly one range entry.

**Validates: Requirements 1.1, 1.2**

### Property 2: Response passthrough

*For any* S3 response (success or error), the response returned to the client SHALL be byte-for-byte identical to the S3 response.

**Validates: Requirements 1.5, 2.4, 3.5, 9.5**

### Property 3: Write cache TTL initialization

*For any* write-cached object, the expiration time SHALL be set to creation time plus the configured write cache TTL.

**Validates: Requirements 1.3, 5.1**

### Property 4: TTL refresh on access

*For any* GET request to a write-cached object, the expiration time SHALL be updated to current time plus write cache TTL.

**Validates: Requirements 1.4, 5.2**

### Property 5: Multipart part storage

*For any* successful UploadPart request, the part data SHALL be stored as a range file, and the tracking metadata SHALL contain the uploadId, partNumber, size, and ETag.

**Validates: Requirements 2.1, 2.2, 2.5**

### Property 6: Multipart byte offset calculation

*For any* multipart upload with N parts, the final byte offsets SHALL be calculated such that part K starts at sum(size of parts 1 to K-1) and ends at sum(size of parts 1 to K) - 1.

**Validates: Requirements 2.3, 3.2**

### Property 7: Multipart completion creates linked metadata

*For any* successful CompleteMultipartUpload, the object metadata SHALL contain range entries for all cached parts with correct byte offsets, and the final ETag from S3.

**Validates: Requirements 3.1, 3.3, 3.4**

### Property 8: Incomplete upload eviction

*For any* multipart upload that exceeds the incomplete upload TTL without completion, all cached parts and tracking metadata SHALL be actively removed (regardless of `actively_remove_cached_data` setting, since incomplete uploads are abandoned).

**Validates: Requirements 4.2, 4.3**

### Property 9: Abort upload cleanup

*For any* AbortMultipartUpload request, all cached parts and tracking metadata for that uploadId SHALL be immediately removed.

**Validates: Requirements 4.5, 8.5**

### Property 10: Write cache capacity enforcement with eviction

*For any* PUT request, if the write cache usage plus request size exceeds the configured write cache capacity, the system SHALL first attempt to evict existing write-cached objects. If eviction cannot free sufficient space, the request SHALL bypass caching.

**Validates: Requirements 6.1, 6.2, 6.5**

### Property 11: Separate capacity tracking

*For any* capacity calculation, write cache usage SHALL only include objects with is_write_cached=true, not read-cached objects.

**Validates: Requirements 6.3**

### Property 12: Write cache eviction order

*For any* write cache eviction triggered by capacity limits, objects SHALL be evicted according to the configured eviction algorithm (LRU or TinyLFU), consistent with read cache eviction.

**Validates: Requirements 6.5**

### Property 13: Write cache initial disk-only storage

*For any* PUT operation, the cached data SHALL be stored only on disk initially (not in RAM cache). Once accessed via GET, the range SHALL be eligible for RAM cache promotion like any other cached range.

**Validates: Requirements 7.1, 7.3, 7.4**

### Property 14: Standard directory structure

*For any* write-cached object (full PUT or multipart part), the range files SHALL be stored in the standard ranges/{bucket}/{XX}/{YYY}/ directory structure using the same sharding scheme as read cache.

**Validates: Requirements 8.1, 8.2**

### Property 15: No caching on S3 failure

*For any* PUT request where S3 returns an error status, no cache entry SHALL be created.

**Validates: Requirements 9.1**

### Property 16: Cache invalidation on overwrite

*For any* PUT request to an existing cached object, the old cache entry SHALL be replaced with the new data and TTL reset.

**Validates: Requirements 5.5, 9.4**

### Property 17: Streaming capacity handling

*For any* PUT request where cache capacity is exceeded during streaming, the partial cached data SHALL be discarded and the request SHALL continue forwarding to S3.

**Validates: Requirements 10.2**

### Property 18: Metadata failure cleanup

*For any* cache operation where metadata write fails, any associated range files SHALL be cleaned up.

**Validates: Requirements 10.4**

## Error Handling

### Error Scenarios and Recovery

| Scenario | Detection | Recovery | Cache State |
|----------|-----------|----------|-------------|
| S3 returns error | Response status 4xx/5xx | Discard temp file, return error | No cache entry |
| Write cache full | Capacity check fails | Bypass caching, forward to S3 | Unchanged |
| Disk full during write | ENOSPC error | Discard partial, forward to S3 | Cleaned up |
| Metadata write fails | I/O error | Delete range file, log error | Cleaned up |
| Part upload fails | S3 error | Don't cache part, return error | Partial upload intact |
| Complete fails | S3 error | Keep parts, mark incomplete | Parts remain |
| Abort received | AbortMultipartUpload | Delete all parts and tracking | Cleaned up |
| Incomplete TTL expires | Background scan | Delete parts and tracking | Cleaned up |

### Race Condition Handling

1. **Concurrent PUT to same object**: Last writer wins, previous cache entry replaced
2. **GET during PUT**: GET fetches from S3 (cache not yet committed)
3. **DELETE during PUT**: DELETE invalidates any existing cache, PUT creates new entry
4. **Concurrent UploadPart**: Each part stored independently, no conflict
5. **Complete during eviction**: Complete takes precedence, eviction skips

## Testing Strategy

### Unit Tests

1. **WriteCacheManager capacity tests**
   - Reserve/release capacity tracking
   - Capacity limit enforcement
   - Eviction ordering

2. **Multipart offset calculation tests**
   - Single part offset
   - Multiple parts sequential offsets
   - Large part sizes

3. **TTL management tests**
   - Initial TTL setting
   - TTL refresh on access
   - Expiration detection

### Property-Based Tests

Using `quickcheck` framework with minimum 100 iterations per property.

**Property 1: Full PUT creates single range**
```rust
#[quickcheck]
fn prop_full_put_single_range(data: Vec<u8>) -> TestResult {
    // Store via PUT, verify single range 0 to len-1
}
```

**Property 6: Multipart byte offset calculation**
```rust
#[quickcheck]
fn prop_multipart_offsets(part_sizes: Vec<u64>) -> TestResult {
    // Calculate offsets, verify no gaps or overlaps
}
```

**Property 10: Write cache capacity enforcement**
```rust
#[quickcheck]
fn prop_capacity_enforcement(requests: Vec<(String, u64)>, capacity: u64) -> TestResult {
    // Submit requests, verify total cached <= capacity
}
```

**Property 12: Write cache eviction order**
```rust
#[quickcheck]
fn prop_eviction_order(objects: Vec<(String, SystemTime)>) -> TestResult {
    // Fill cache, trigger eviction, verify oldest evicted first
}
```

### Integration Tests

1. **PUT then GET test**
   - PUT object through proxy
   - GET same object
   - Verify cache hit

2. **Multipart upload test**
   - CreateMultipartUpload
   - UploadPart x N
   - CompleteMultipartUpload
   - GET full object → cache hit
   - GET range → cache hit

3. **Incomplete upload eviction test**
   - Start multipart upload
   - Upload some parts
   - Wait for TTL
   - Verify parts evicted

4. **Capacity limit test**
   - Configure small write cache
   - PUT objects until full
   - Verify bypass behavior

5. **TTL refresh test**
   - PUT object
   - Wait partial TTL
   - GET object (refresh)
   - Wait partial TTL again
   - Verify still cached

## Configuration

### New Configuration Options

```yaml
cache:
  # Existing options
  write_cache_enabled: true
  write_cache_percent: 10.0  # Percentage of max_cache_size
  write_cache_max_object_size: 268435456  # 256MB
  put_ttl: "1d"  # Write cache TTL, refreshed on read
  
  # New options
  incomplete_upload_ttl: "1d"  # TTL for incomplete multipart uploads (default: 1 day)
  write_cache_eviction_batch_size: 100  # Objects to evict per cycle
```

### Configuration Validation

- `write_cache_percent`: 1.0 to 50.0
- `incomplete_upload_ttl`: 1h to 7d
- `put_ttl`: 1m to 30d
- `write_cache_max_object_size`: 1KB to max_cache_size

## Implementation Notes

### Startup Behavior

On cache manager initialization:

1. **Clean up temporary files** (existing)
   - Remove `.tmp` files from previous crashes
   - Prevents orphaned partial writes

2. **Clean up stale write cache files** (existing, enhanced)
   - Scan `write_cache/` for files older than `put_ttl`
   - Delete expired files
   - Log each deletion with path and age

3. **Clean up incomplete multipart uploads** (NEW)
   - Acquire distributed eviction lock (prevents concurrent cleanup across nodes)
   - Scan `mpus_in_progress/` for `upload.meta` files
   - For each upload:
     - Check file modification time (not creation time) - recent activity means another node may be working
     - Only evict if `last_modified + incomplete_upload_ttl < now`
     - Acquire per-upload lock before deletion (prevents race with active upload)
     - Delete all cached parts
     - Delete tracking metadata
     - Log: "Cleaned up stale incomplete upload: uploadId={}, age={}"
   - Release distributed eviction lock

4. **Calculate write cache usage** (NEW)
   - Scan metadata files for `is_write_cached=true`
   - Sum `compressed_size` of write-cached ranges (actual disk usage)
   - Initialize `WriteCacheManager.current_size`
   - Note: Uses compressed size because that's what consumes disk space

5. **Log write cache status**
   - Log: "Write cache initialized: usage={}/{} ({}%)"

### Daily Validation Scan (Midnight)

The existing daily validation scan at `validation_time_of_day` (default: midnight) is enhanced:

1. **Existing: HEAD cache cleanup** - Always runs
2. **Existing: GET cache cleanup** - If `actively_remove_cached_data=true`
3. **NEW: Write cache cleanup** - If `actively_remove_cached_data=true`
   - Scan metadata for expired write-cached objects
   - Delete expired ranges and metadata
4. **NEW: Incomplete upload cleanup** - Always runs
   - Same logic as startup cleanup
   - Catches uploads that expired since last scan

### Background Tasks

#### 1. Incomplete Upload Scanner

**Purpose**: Clean up abandoned multipart uploads that were never completed or aborted.

**Trigger**: Runs every hour (configurable)

**Process**:
```
1. Acquire distributed eviction lock (prevents concurrent cleanup across nodes)
2. Scan mpus_in_progress/ directory for upload.meta files
3. For each upload.meta:
   a. Get file modification time (last activity, not creation)
   b. Calculate age = now - last_modified
   c. If age > incomplete_upload_ttl (default 1 day):
      - Try to acquire per-upload lock (upload.lock)
      - If lock acquired (no other node working on it):
        - Read list of cached parts from upload.meta
        - Delete each part's range file from ranges/{bucket}/{XX}/{YYY}/
        - Delete the upload.meta file
        - Delete the mpus_in_progress/{uploadId}/ directory
        - Release per-upload lock
        - Log: "Evicted incomplete multipart upload: uploadId={}, age={}, parts={}"
      - If lock not acquired:
        - Skip (another node is actively working on this upload)
        - Log: "Skipped incomplete upload cleanup, lock held: uploadId={}"
4. Release distributed eviction lock
```

**Why use file mtime instead of started_at**:
- `started_at` (in JSON) is when CreateMultipartUpload was called
- File system `mtime` of `upload.meta` is updated each time we write to it
- We update `upload.meta` after each successful UploadPart (adding part info)
- Therefore, `mtime` reflects the most recent UploadPart activity
- An upload with recent activity should not be evicted
- Using file system mtime accounts for activity from any node (no need to parse JSON)

**Why always active**: Incomplete uploads represent abandoned work. Unlike completed objects that might still be valid, incomplete uploads will NEVER be completed (the client has moved on). Leaving them indefinitely wastes disk space with no benefit.

**Example scenario**:
- Client starts multipart upload at 10:00 Monday
- Uploads parts 1, 2, 3
- Client crashes or abandons upload (no CompleteMultipartUpload)
- At 10:00 Tuesday (after 1 day TTL), scanner removes parts 1, 2, 3 and tracking metadata

#### 2. Write Cache TTL Scanner (respects `actively_remove_cached_data`)

**Purpose**: Remove expired write-cached objects (completed PUTs and completed multipart uploads).

**Behavior**:
- If `actively_remove_cached_data: true`: Actively scan and remove expired write-cached objects
- If `actively_remove_cached_data: false`: Expired objects removed lazily on access or via capacity eviction

**Consistent with read cache**: Uses the same expiration behavior as read cache to avoid surprising operators.

### Performance Considerations

1. **Capacity tracking**: Use atomic counter, not filesystem scan
2. **Eviction**: Batch evictions to reduce I/O
3. **Metadata updates**: Async TTL refresh, don't block GET response
4. **Part storage**: Write parts directly to final location, no rename needed
