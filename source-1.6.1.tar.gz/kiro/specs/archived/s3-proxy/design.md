# S3 Proxy Design Document

## Overview

The S3 Proxy is a high-performance HTTP proxy server designed to accelerate access to Amazon S3 and S3-compatible storage services through intelligent caching, range-aware request handling, and comprehensive logging. The system acts as a transparent intermediary that maintains full S3 API compatibility while providing significant performance improvements through strategic caching of objects, ranges, and metadata.

The proxy implements a sophisticated caching strategy that handles full objects, byte ranges, object versions, and multipart object parts independently. It provides HTTP proxy with caching on port 80, and HTTPS support on port 443 with TCP passthrough by default (or optional self-signed TLS termination). The system implements write-through caching for PUT operations and provides shared cache volume support for scale-out deployments. The system ensures data consistency through conditional request validation and provides comprehensive logging for monitoring and troubleshooting.

## Architecture

The S3 Proxy follows a modular architecture with clear separation of concerns:

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│     Client      │────│   HTTP Proxy     │────│   S3 Endpoint   │
│   Applications  │    │     Server       │    │    Services     │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                              │
                              │
                    ┌─────────▼─────────┐
                    │  Cache Management │
                    │     System        │
                    └───────────────────┘
                              │
                    ┌─────────▼─────────┐
                    │   File System     │
                    │   Cache Storage   │
                    └───────────────────┘
```

### Core Components

1. **Configuration Manager**: Loads and validates YAML configuration files with support for duration strings (e.g., "30s", "5m"), environment variable overrides, and command-line arguments
2. **HTTP/HTTPS Request Handler**: Processes incoming client requests on both HTTP (port 80) and HTTPS (port 443) and manages response delivery
3. **TCP Proxy Handler**: Provides transparent TCP passthrough for HTTPS connections (default mode)
4. **TLS Certificate Manager**: Generates and manages self-signed certificates for HTTPS support (when self-signed mode enabled)
5. **Connection Pool Manager**: Maintains persistent HTTP connections to S3 endpoints with IP load balancing
6. **S3 Request Forwarder**: Handles communication with S3 endpoints using TLS with system root certificates for secure connections
6. **RAM Cache Manager**: Optional in-memory cache layer with configurable eviction algorithms (LRU, LFU, TinyLFU)
7. **Disk Cache Manager**: File system-based cache storage with compression support
8. **Cache Compression Handler**: LZ4 compression/decompression for cached objects and ranges
9. **Range Handler**: Processes HTTP range requests and manages partial content caching
10. **Version Manager**: Handles S3 object versioning and multipart object parts
11. **Conditional Request Processor**: Validates HTTP conditional headers against cached metadata
12. **Write-Through Cache Handler**: Manages PUT request caching with TTL and size limits
13. **Shared Cache Coordinator**: Handles file locking and coordination for shared cache volumes
14. **Access Logger**: Provides comprehensive request/response logging in S3-compatible format
15. **Application Logger**: Handles system errors, warnings, and debug logging with host identification
16. **Health Manager**: Monitors system component health and provides health check endpoints
17. **Metrics Manager**: Collects and aggregates system metrics for monitoring and observability
18. **OTLP Exporter**: Exports metrics using OpenTelemetry Protocol to observability backends
19. **Shutdown Coordinator**: Manages graceful shutdown of all system components

## Components and Interfaces

### Configuration Manager
- **Purpose**: Load, parse, and validate system configuration from YAML files, environment variables, and command-line arguments
- **Key Methods**:
  - `load()`: Load configuration from file with fallback to defaults
  - `parse_duration(string)`: Parse duration strings like "30s", "5m", "1h" into Duration objects
  - `apply_env_overrides()`: Override config values from environment variables
  - `apply_cli_overrides(args)`: Override config values from command-line arguments
  - `validate()`: Validate configuration values and constraints
- **Configuration Format**: Supports human-readable duration strings (e.g., "30s", "5m", "1h") for all timeout and interval settings
- **Interfaces**: Provides configuration to all system components during initialization

### HTTP Request Handler
- **Purpose**: Accept and process HTTP requests from clients
- **Key Methods**:
  - `handle_request(request)`: Main request processing entry point
  - `validate_request(request)`: Validates required headers and parameters
  - `validate_host_header(request)`: Extracts and validates Host header, stripping port if present
  - `build_response(status, headers, body)`: Constructs HTTP responses
- **Host Header Processing**: 
  - Extracts hostname from Host header (e.g., "s3.amazonaws.com" or "s3.us-east-1.amazonaws.com")
  - Strips port number if present (e.g., "s3.amazonaws.com:8081" → "s3.amazonaws.com")
  - Uses the stripped hostname as the S3 endpoint for forwarding requests
  - This allows clients to use `--endpoint-url "http://s3.amazonaws.com:8081"` where the port routes to the proxy but the hostname identifies the S3 service
- **Interfaces**: Communicates with Cache Manager and S3 Request Forwarder

### S3 Request Forwarder
- **Purpose**: Forward requests to S3 endpoints and handle responses with secure TLS connections
- **Key Methods**:
  - `new()`: Initialize S3 client with system root certificates for TLS validation
  - `forward_request(request, endpoint)`: Sends request to S3 service over TLS
  - `handle_s3_response(response)`: Processes S3 response data
  - `build_conditional_request(request, cache_metadata)`: Adds conditional headers for cache validation
- **TLS Configuration**: Loads system root certificates (via rustls-native-certs) to validate S3 endpoint certificates
- **Security**: Ensures all S3 connections use proper certificate validation to prevent MITM attacks
- **Interfaces**: Communicates with HTTP Request Handler and receives cache metadata from Cache Manager

### Cache Manager
- **Purpose**: Manage all caching operations including storage, retrieval, and expiration
- **Key Methods**:
  - `get_cached_response(cache_key)`: Retrieve cached data
  - `store_response(cache_key, response, metadata)`: Store response in cache
  - `invalidate_cache(cache_key)`: Remove cached data
  - `is_cache_valid(cache_key, conditions)`: Validate cache against conditions
  - `merge_ranges(existing_ranges, new_range)`: Optimize overlapping range storage
- **Interfaces**: Provides caching services to all other components

### Range Handler
- **Purpose**: Process HTTP range requests and manage partial content
- **Key Methods**:
  - `parse_range_header(range_header)`: Extract byte range specifications
  - `find_cached_ranges(cache_key, requested_range)`: Identify cached portions
  - `build_partial_response(cached_data, fresh_data, range)`: Combine cached and fresh data
- **Interfaces**: Works closely with Cache Manager and S3 Request Forwarder

### TLS Certificate Manager
- **Purpose**: Generate and manage self-signed certificates for HTTPS support
- **Key Methods**:
  - `generate_certificate(domain)`: Create self-signed certificate for specified domain
  - `load_certificate()`: Load existing certificate from storage
  - `validate_certificate(domain)`: Check certificate validity for domain
- **Interfaces**: Provides certificates to HTTP/HTTPS Request Handler

### Write-Through Cache Handler
- **Purpose**: Manage caching of PUT operations with size and TTL constraints
- **Key Methods**:
  - `cache_put_request(request, response)`: Cache successful PUT operations
  - `cleanup_expired_writes()`: Remove expired write-cached objects
  - `enforce_write_cache_limit()`: Maintain write cache size limits
  - `is_multipart_upload(request)`: Detect multipart upload operations to skip caching
- **Interfaces**: Coordinates with Cache Manager for storage operations

### Shared Cache Coordinator
- **Purpose**: Coordinate cache operations across multiple proxy instances on shared volumes
- **Key Methods**:
  - `acquire_write_lock(cache_key)`: Obtain exclusive write access to cache entry
  - `release_write_lock(cache_key)`: Release write lock after operation
  - `is_cache_entry_active(cache_key)`: Check if other instances are using cache entry
  - `coordinate_cleanup()`: Safely perform cache cleanup across instances
- **Interfaces**: Works with Cache Manager to ensure safe concurrent operations

### TCP Proxy Handler
- **Purpose**: Provide transparent TCP passthrough for HTTPS connections (default mode)
- **Key Methods**:
  - `establish_tcp_tunnel(client_socket, s3_endpoint)`: Create direct TCP tunnel
  - `forward_tcp_traffic(client_socket, server_socket)`: Bidirectional traffic forwarding
  - `handle_tunnel_error(error)`: Manage connection failures and cleanup
- **Interfaces**: Operates independently without caching or TLS termination

### Connection Pool Manager
- **Purpose**: Maintain persistent HTTP connections with IP load balancing and external DNS resolution
- **Key Methods**:
  - `new()`: Initialize with external DNS servers (Google DNS, Cloudflare DNS) that bypass /etc/hosts
  - `get_connection(endpoint, request_size)`: Obtain optimal connection for request
  - `refresh_dns(endpoint)`: Periodically resolve hostnames for new IP addresses using external DNS
  - `monitor_connection_health()`: Track performance metrics and connection reliability
  - `balance_load(connections, request)`: Select best connection based on request characteristics
- **DNS Configuration**: Uses external DNS servers (8.8.8.8, 8.8.4.4, 1.1.1.1, 1.0.0.1) with hosts file bypass enabled to ensure S3 endpoints resolve to real AWS IPs even when clients configure their hosts file to point S3 to the proxy
- **Interfaces**: Provides connections to S3 Request Forwarder

### RAM Cache Manager
- **Purpose**: Optional in-memory cache layer with configurable eviction algorithms
- **Key Methods**:
  - `get_from_ram(cache_key)`: Retrieve cached data from memory
  - `store_in_ram(cache_key, data, metadata)`: Store data in memory cache
  - `evict_entries(algorithm)`: Remove entries using LRU, LFU, or TinyLFU algorithms
  - `check_ram_limits()`: Enforce memory usage limits
- **Interfaces**: Works as first-tier cache before Disk Cache Manager

### Cache Compression Handler
- **Purpose**: Multi-algorithm content-aware compression/decompression for cached objects and ranges with per-entry metadata tracking
- **Key Methods**:
  - `compress_content_aware_with_metadata(data, path)`: Compress data with full metadata including algorithm used, sizes, and file extension
  - `decompress_with_algorithm(data, algorithm)`: Decompress cached data using the specific algorithm that was used for compression
  - `should_compress_content(path, size)`: Determine if compression should be applied based on content type and current rules
  - `compress_with_algorithm(data, algorithm)`: Compress using a specific algorithm (LZ4, future: Zstd, Brotli)
  - `should_recompress_entry(compression_info)`: Determine if cache entry should be migrated to new compression settings
- **Algorithm Support**: Currently supports LZ4 and None (uncompressed), designed for easy addition of future algorithms (Zstd, Brotli, LZ4HC)
- **Content-Aware Logic**: Automatically skips compression for already-compressed formats (images, videos, archives, documents) while compressing text-based files (JSON, HTML, CSS, JS, logs, etc.)
- **Cache Consistency**: Per-entry algorithm metadata ensures cache entries remain valid across compression rule changes and algorithm upgrades
- **Interfaces**: Integrates with both RAM and Disk Cache Managers

### Application Logger
- **Purpose**: Handle system errors, warnings, and debug logging with host identification
- **Key Methods**:
  - `log_error(message, context)`: Log error messages with context
  - `log_warning(message)`: Log warning messages
  - `log_debug(message)`: Log debug information
  - `create_host_log_directory()`: Create host-specific log directories
- **Interfaces**: Used by all components for application-level logging

### Health Manager
- **Purpose**: Monitor system component health and provide health check endpoints
- **Key Methods**:
  - `check_health()`: Perform comprehensive health check of all components
  - `check_cache_health(cache_manager)`: Assess cache system health and performance
  - `check_connection_pool_health(connection_pool)`: Monitor connection pool status
  - `handle_health_request(request)`: Process HTTP health check requests
- **Interfaces**: Monitors Cache Manager, Connection Pool Manager, and Compression Handler

### Metrics Manager
- **Purpose**: Collect and aggregate system metrics for monitoring and observability
- **Key Methods**:
  - `collect_metrics()`: Gather comprehensive system metrics from all components
  - `record_request(success, response_time)`: Track individual request metrics
  - `record_proxy_request(type, latency, size, success)`: Record proxy-specific metrics
  - `record_s3_request(type, latency, success, status)`: Track S3 backend metrics
  - `handle_metrics_request(request)`: Serve metrics via HTTP endpoint
- **Interfaces**: Collects data from all system components and integrates with OTLP Exporter

### OTLP Exporter
- **Purpose**: Export metrics using OpenTelemetry Protocol to observability backends
- **Key Methods**:
  - `initialize()`: Set up OTLP exporter with configured endpoint and settings
  - `export_metrics(metrics)`: Export system metrics in OTLP format
  - `record_proxy_request(type, latency, size, success)`: Record individual proxy metrics
  - `record_s3_request(type, first_byte_latency, total_latency, success, status)`: Track S3 metrics
  - `shutdown()`: Gracefully shutdown OTLP exporter and flush pending metrics
- **Interfaces**: Receives metrics from Metrics Manager and exports to external observability systems

### Shutdown Coordinator
- **Purpose**: Manage graceful shutdown of all system components
- **Key Methods**:
  - `listen_for_shutdown()`: Monitor for shutdown signals (SIGINT, SIGTERM)
  - `initiate_shutdown()`: Begin graceful shutdown sequence
  - `release_cache_locks(cache_manager)`: Release all cache locks held by this instance
  - `close_connection_pools(connection_pool)`: Gracefully close all connection pools
- **Interfaces**: Coordinates shutdown across Cache Manager, Connection Pool Manager, and OTLP Exporter

## Data Models

### Cache Entry (Metadata File)
```rust
struct CacheEntry {
    cache_key: String,              // Unique identifier for cached object
    headers: HashMap<String, String>, // HTTP response headers
    ranges: Vec<RangeSpec>,         // Index of cached ranges (no embedded data)
    object_metadata: ObjectMetadata, // Object-level metadata
    created_at: SystemTime,         // Cache creation timestamp
    expires_at: SystemTime,         // Cache expiration timestamp for GET requests (GET_TTL)
    is_put_cached: bool,            // Whether this was cached via PUT (uses PUT_TTL initially)
    compression_info: CompressionInfo, // Compression metadata
}
```

**Note**: The `CacheEntry` is stored in `.meta` files and contains NO binary data. All range data is stored separately in `.bin` files referenced by the `ranges` array. This keeps metadata files lightweight (<100KB) even with hundreds of cached ranges.

**Separate GET and HEAD TTL Design**: The cache system maintains completely independent TTLs for GET and HEAD operations:
- `expires_at`: Controls when cached data expires for GET requests (default: infinite)
- HEAD metadata has its own separate cache with HEAD_TTL (default: 1 hour)
- HEAD_TTL expiration does NOT affect GET request caching
- HEAD metadata is actively removed when HEAD_TTL expires
- All parts, ranges, and multipart components of an object share the same expiration time

**PUT to GET TTL Transition**: Objects cached via PUT operations:
- Initially use PUT_TTL (default: 1 hour) to avoid caching objects that are never read
- When accessed via GET within PUT_TTL, transition to using GET_TTL (default: infinite)
- This optimizes for "upload once, download many" patterns while avoiding cache pollution

### Object Metadata
```rust
struct ObjectMetadata {
    etag: String,                   // S3 object ETag
    last_modified: String,          // Last-Modified timestamp
    content_length: u64,            // Object size
    content_type: Option<String>,   // Content-Type header
    version_id: Option<String>,     // S3 version ID (if applicable)
    cache_control: Option<String>,  // Cache-Control header value
}
```

**Note**: This struct contains only object-level metadata, not range-specific information. Range specifications are stored separately in the `ranges` array of the `CacheEntry`.

### Range Specification
```rust
struct RangeSpec {
    start: u64,                     // Starting byte position
    end: u64,                       // Ending byte position
    file_path: String,              // Path to .bin file containing range data
    compression_algorithm: CompressionAlgorithm, // Compression used for this range
    compressed_size: u64,           // Size of compressed data in .bin file
    uncompressed_size: u64,         // Original size of range data
}
```

**Note**: The `RangeSpec` struct contains only metadata and a pointer to the binary file. The actual range data is stored separately in `.bin` files in the `ranges/` directory. This separation prevents metadata bloat and enables efficient metadata parsing without loading range data into memory.

### Cache Key Structure
Cache keys are constructed to ensure proper isolation:
- Full objects: `{path}`
- Object parts: `{path}:part:{part_number}`
- Range requests: `{base_key}:range:{start}-{end}`

**Note**: Versioned requests (those with `versionId` query parameter) bypass the cache entirely and are forwarded directly to S3. This simplifies the caching logic while still allowing clients to access versioned objects.

### Cache Key Sanitization

Cache keys are sanitized for filesystem compatibility and length constraints:

**Character Sanitization**: Special characters are replaced with safe alternatives:
- `:` → `_colon_`
- `/` → `_slash_`
- `?` → `_question_`
- `&` → `_amp_`
- `=` → `_eq_`

**Length Handling**: To accommodate filesystem limits (255 bytes for filenames):
- Cache keys ≤200 characters: Use sanitized key directly
- Cache keys >200 characters: Use SHA-256 hash of the full key
- This supports S3 object keys up to 1024 characters (S3's maximum)

**Rationale**: Most filesystems have a 255-byte filename limit. By hashing keys >200 characters, we ensure the sanitized key + file extension (`.meta`, `.bin`, `.lock`) stays well under this limit while supporting the full range of valid S3 object keys.

## Cache Storage Implementation

### Two-File Cache Design

The disk cache uses a two-file approach for each cache entry, optimized for shared disk deployments and independent metadata validation:

**File Structure:**
```
cache_dir/
├── objects/          # Lightweight metadata files (no embedded data)
│   ├── {sanitized_key}.meta      # JSON metadata + range index
│   └── {sanitized_key}.meta.lock # Lock file for metadata updates
├── ranges/           # All cached data stored as binary ranges
│   ├── {sanitized_key}_0-8388607.bin       # Range data (full objects or partial)
│   ├── {sanitized_key}_8388608-16777215.bin
│   └── {sanitized_key}_16777216-25165823.bin
├── head_cache/       # HEAD request metadata cache (separate from GET)
│   └── {sanitized_key}.head      # HEAD response headers and metadata
└── locks/            # Coordination locks for shared cache
    └── {sanitized_key}.lock      # Lock file for write coordination
```

**Directory Purpose:**

- **objects/**: Stores lightweight metadata files (`.meta`) containing object metadata and an index of cached ranges - NO embedded binary data, typically <100KB even with hundreds of ranges
- **ranges/**: Stores ALL cached data as binary files (`.bin`) - full objects are stored as range 0-N, partial ranges stored separately for efficient access
- **head_cache/**: Stores HEAD request metadata separately from GET data (independent HEAD_TTL)
- **locks/**: Contains lock files for coordinating writes in shared cache deployments

**Note on partNumber requests**: As of Requirement 22, GET requests with `partNumber` query parameters bypass the cache entirely due to their rare usage.

**Architecture Note**: The range storage architecture treats all cached data uniformly as ranges:
- Full objects: Stored as a single range 0-N in `ranges/` directory
- Partial ranges: Each range stored as a separate `.bin` file
- Metadata: Lightweight `.meta` files in `objects/` contain only range specifications (start, end, file path), not the actual data
- This separation enables efficient concurrent access, prevents metadata bloat (126MB+ JSON files), and allows sub-10ms metadata parsing even with hundreds of cached ranges

**Design Rationale:**

1. **Metadata-Only Operations**: Separate `.meta` files enable HEAD request validation and metadata refresh without reading large `.cache` files
2. **Independent TTL Support**: Metadata file can be updated independently to refresh `metadata_expires_at` without touching cached data
3. **Atomic Operations**: Temp files (`.cache.tmp`, `.meta.tmp`) are written then atomically renamed for consistency
4. **Shared Disk Coordination**: File-based locking works reliably across NFS and network filesystems without requiring a database
5. **Fine-Grained Locking**: Each cache entry has its own `.lock` file for concurrent access control
6. **Crash Recovery**: Orphaned temp files can be safely cleaned up; lock files have expiration timestamps

**Metadata Validation Flow:**
```
1. Client requests object
2. Check cache: data valid, metadata expired
3. Send HEAD request to S3 with cached ETag/Last-Modified
4. If unchanged (304): Update only .meta file with new metadata_expires_at
5. If changed: Invalidate both .cache and .meta files, fetch fresh data
6. Serve cached data to client
```

This design provides optimal performance for shared cache scenarios while supporting efficient metadata validation without re-downloading unchanged objects.

### HEAD Cache Entry
```rust
struct HeadCacheEntry {
    cache_key: String,              // Unique identifier for HEAD metadata
    headers: HashMap<String, String>, // HTTP response headers from HEAD
    metadata: CacheMetadata,        // Cache-specific metadata (ETag, Last-Modified)
    created_at: SystemTime,         // HEAD cache creation timestamp
    expires_at: SystemTime,         // HEAD_TTL expiration timestamp
}
```

**HEAD Cache Behavior:**
- HEAD metadata is cached separately from GET data
- HEAD_TTL expiration does NOT affect GET operations
- HEAD metadata is actively removed when HEAD_TTL expires
- HEAD requests check only HEAD cache, not GET cache



### Cache Lock
```rust
struct CacheLock {
    cache_key: String,              // Cache entry being locked
    lock_id: String,                // Unique lock identifier
    instance_id: String,            // Proxy instance holding the lock
    acquired_at: SystemTime,        // Lock acquisition timestamp
    expires_at: SystemTime,         // Lock expiration timestamp
}
```

### Cache Statistics
```rust
struct CacheStatistics {
    total_cache_size: u64,          // Total allocated cache space
    read_cache_size: u64,           // Space used by read cache
    write_cache_size: u64,          // Space used by write-through cache
    write_cache_percent: f32,       // Current write cache percentage
    max_write_cache_percent: f32,   // Maximum allowed write cache percentage
    ram_cache_size: u64,            // Space used by RAM cache
    ram_cache_hit_rate: f32,        // RAM cache hit rate percentage
    compression_ratio: f32,         // Average compression ratio achieved
}
```

### Connection Pool
```rust
struct ConnectionPool {
    endpoint: String,               // S3 endpoint hostname
    ip_addresses: Vec<IpAddress>,   // Resolved IP addresses for load balancing
    connections: HashMap<IpAddr, Vec<Connection>>, // Connections per IP address
    health_metrics: HashMap<IpAddr, HealthMetrics>, // Performance metrics per IP
    last_dns_refresh: SystemTime,   // Last DNS resolution timestamp
    max_connections_per_ip: usize,  // Maximum connections per IP address
}
```

### Connection Health Metrics
```rust
struct HealthMetrics {
    ip_address: IpAddr,             // IP address being monitored
    average_latency: Duration,      // Average request latency
    success_rate: f32,              // Success rate percentage (0.0-1.0)
    active_connections: usize,      // Currently active connections
    total_requests: u64,            // Total requests sent to this IP
    failed_requests: u64,           // Failed requests to this IP
    last_failure: Option<SystemTime>, // Timestamp of last failure
    consecutive_failures: u32,      // Count of consecutive failures
}
```

### RAM Cache Entry
```rust
struct RamCacheEntry {
    cache_key: String,              // Unique identifier for cached object
    data: Vec<u8>,                  // Cached data (compressed or uncompressed)
    metadata: CacheMetadata,        // Cache-specific metadata
    created_at: SystemTime,         // Cache creation timestamp
    last_accessed: SystemTime,      // Last access timestamp for LRU
    access_count: u64,              // Access count for LFU
    compressed: bool,               // Whether data is compressed
}
```

### Compression Algorithm Support
```rust
enum CompressionAlgorithm {
    None,        // No compression applied
    Lz4,         // LZ4 compression (current default)
    // Future algorithms:
    // Zstd,     // Zstandard compression
    // Brotli,   // Brotli compression
    // Lz4Hc,    // LZ4 High Compression
}
```

### Compression Metadata
```rust
struct CompressionInfo {
    body_algorithm: CompressionAlgorithm,  // Algorithm used for compression
    original_size: Option<u64>,            // Size before compression
    compressed_size: Option<u64>,          // Size after compression
    file_extension: Option<String>,        // File extension when cached
}
```

### Compression Statistics
```rust
struct CompressionStats {
    total_objects_compressed: u64,   // Total objects that were compressed
    total_objects_uncompressed: u64, // Total objects stored without compression
    total_bytes_before: u64,        // Total bytes before compression
    total_bytes_after: u64,         // Total bytes after compression
    compression_failures: u64,      // Number of compression failures
    decompression_failures: u64,    // Number of decompression failures
    average_compression_ratio: f32, // Average compression ratio achieved
}
```

### OTLP Configuration
```rust
struct OtlpConfig {
    enabled: bool,                           // Enable/disable OTLP export
    endpoint: String,                        // OTLP HTTP endpoint URL
    export_interval: Duration,               // Frequency of metric exports
    timeout: Duration,                       // Request timeout for OTLP exports
    headers: HashMap<String, String>,        // Custom headers for authentication
    compression: OtlpCompression,            // Compression algorithm for OTLP requests
}

enum OtlpCompression {
    None,    // No compression
    Gzip,    // GZIP compression
}
```

### Health Check Data Models
```rust
struct SystemHealth {
    status: HealthStatus,                    // Overall system health status
    timestamp: SystemTime,                   // When health check was performed
    components: Vec<ComponentHealth>,        // Individual component health
    uptime_seconds: u64,                     // System uptime in seconds
}

struct ComponentHealth {
    name: String,                            // Component name (cache, connection_pool, etc.)
    status: HealthStatus,                    // Component health status
    message: Option<String>,                 // Optional status message
    last_check: SystemTime,                  // When component was last checked
    response_time_ms: Option<u64>,           // Component response time
}

enum HealthStatus {
    Healthy,    // Component operating normally
    Degraded,   // Component has issues but still functional
    Unhealthy,  // Component is not functioning properly
}
```

### Metrics Data Models
```rust
struct SystemMetrics {
    timestamp: SystemTime,                   // When metrics were collected
    uptime_seconds: u64,                     // System uptime
    cache: Option<CacheMetrics>,             // Cache performance metrics
    compression: Option<CompressionMetrics>, // Compression efficiency metrics
    connection_pool: Option<ConnectionPoolMetrics>, // Connection pool metrics
    request_metrics: RequestMetrics,         // Request processing metrics
}

struct RequestMetrics {
    total_requests: u64,                     // Total number of requests processed
    successful_requests: u64,                // Number of successful requests
    failed_requests: u64,                    // Number of failed requests
    average_response_time_ms: u64,           // Average response time
    requests_per_second: f32,                // Current request rate
}
```
## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

After analyzing the acceptance criteria, I've identified the following correctness properties that must hold for the S3 proxy system:

### Request Forwarding Properties

**Property 1: Host-based routing consistency**
*For any* HTTP request with a valid Host header, the proxy should forward the request to the S3 endpoint corresponding to that host
**Validates: Requirements 1.1**

**Property 2: Response forwarding completeness**
*For any* S3 response, the proxy should forward the complete response (status, headers, body) to the client without modification
**Validates: Requirements 1.2**

**Property 3: Concurrent request handling**
*For any* set of concurrent requests up to the configured limit, the proxy should handle all requests simultaneously without blocking, and return 429 Too Many Requests for requests exceeding the limit
**Validates: Requirements 1.5**

### Caching Properties

**Property 4: GET response caching**
*For any* successful GET request (200 response), the proxy should cache both response body and headers for future requests
**Validates: Requirements 2.1**

**Property 5: Cache hit efficiency**
*For any* cached GET or HEAD request, subsequent identical requests should be served from cache without contacting S3
**Validates: Requirements 2.2, 2.4**

**Property 6: Cache failure resilience**
*For any* request when cache storage fails, the proxy should continue serving by forwarding to S3
**Validates: Requirements 2.5**

### Range Request Properties

**Property 7: Range caching isolation**
*For any* range request, the proxy should cache only the requested byte range, not the entire object
**Validates: Requirements 3.1**

**Property 8: Range overlap optimization**
*For any* range request that overlaps with cached ranges, the proxy should serve cached portions from cache and fetch only missing portions from S3
**Validates: Requirements 3.2**

**Property 9: Range merging efficiency**
*For any* set of overlapping cached ranges, the proxy should merge them to optimize storage space
**Validates: Requirements 3.3**

**Property 10: Range cache validation**
*For any* range request with cached portions, the proxy should preserve client-specified conditional headers exactly and only add cache validation headers (If-Unmodified-Since, If-Match) for conditions not already specified by the client
**Validates: Requirements 3.6**

**Property 11: Cache invalidation on precondition failure**
*For any* range request that receives a 412 response, the proxy should invalidate cached portions and retry without conditional headers
**Validates: Requirements 3.7**

**Property 11a: Client conditional header preservation**
*For any* range request with client-specified conditional headers, the proxy should preserve those headers exactly and only add cache validation headers for conditions not specified by the client
**Validates: Requirements 3.8**

### Conditional Request Properties

**Property 12: If-Match validation**
*For any* request with If-Match headers, the proxy should validate against cached metadata and return 412 if the condition fails
**Validates: Requirements 4.1**

**Property 13: If-None-Match validation**
*For any* request with If-None-Match headers, the proxy should validate against cached metadata and return 304 if the condition matches
**Validates: Requirements 4.2**

**Property 14: If-Modified-Since validation**
*For any* request with If-Modified-Since headers, the proxy should validate against cached Last-Modified and return 304 if not modified
**Validates: Requirements 4.3**

**Property 15: If-Unmodified-Since validation**
*For any* request with If-Unmodified-Since headers, the proxy should validate against cached Last-Modified and return 412 if modified
**Validates: Requirements 4.4**

### Cache Expiration Properties

**Property 16: Cache-Control max-age compliance**
*For any* response with Cache-Control max-age, the proxy should expire the cached object after the specified duration
**Validates: Requirements 5.1**

**Property 17: Cache directive compliance**
*For any* response with Cache-Control no-cache or no-store, the proxy should not cache the response or expire it immediately
**Validates: Requirements 5.2**

**Property 18: Expires header handling**
*For any* response with an Expires header and no Cache-Control, the proxy should use the Expires timestamp for cache expiration
**Validates: Requirements 5.3**

**Property 18a: GET_TTL expiration for GET requests**
*For any* GET request when GET_TTL has expired, the proxy should fetch fresh content from S3 and update the cache
**Validates: Requirements 5.5**

**Property 18b: HEAD_TTL expiration for HEAD requests**
*For any* HEAD request when HEAD_TTL has expired, the proxy should actively remove HEAD metadata and fetch fresh metadata from S3
**Validates: Requirements 5.6**

**Property 18c: Independent GET and HEAD TTL**
*For any* cache configuration, the proxy should use completely separate TTL values for GET requests (default: infinite) and HEAD requests (default: 1 hour), where HEAD_TTL expiration does NOT affect GET operations
**Validates: Requirements 5.7**

**Property 18d: Unified expiration for parts and ranges**
*For any* object with multiple cached parts or ranges, all parts and ranges should share the same expiration time and expire together
**Validates: Requirements 5.9**

### Versioning Properties

**Property 19: Versioned request bypass**
*For any* object request with a versionId parameter, the proxy should forward the request directly to S3 without caching
**Validates: Requirements 6.1**

**Property 20: Versioned request logging**
*For any* versioned request processed, the proxy should log that caching was bypassed due to versioning
**Validates: Requirements 6.2**

**Property 21: Versioned response passthrough**
*For any* versioned response received from S3, the proxy should return it to the client without storing in cache
**Validates: Requirements 6.3**

**Property 22: Metadata mismatch invalidation**
*For any* S3 response with metadata that differs from cached metadata, the proxy should invalidate all cached entries for that object and serve only fresh data
**Validates: Requirements 6.6**

### Multipart Object Properties

**Property 23: Part caching isolation**
*For any* request with a partNumber parameter, the proxy should cache that part separately from the full object and other parts
**Validates: Requirements 7.1**

**Property 23: Part cache efficiency**
*For any* cached object part, subsequent requests for the same part should be served from cache without contacting S3
**Validates: Requirements 7.2**

**Property 24: Multipart upload passthrough**
*For any* multipart upload operation, the proxy should pass it through to S3 without caching
**Validates: Requirements 7.3**

### Logging Properties

**Property 25: Log format compliance**
*For any* request when Server Access Logging is enabled, the proxy should write logs in S3-compatible format with all required fields
**Validates: Requirements 8.1**

**Property 26: Selective logging accuracy**
*For any* request in cached-only logging mode, the proxy should log only requests served entirely from cache
**Validates: Requirements 8.2**

### HTTPS and Certificate Properties

**Property 27: HTTPS port availability**
*For any* proxy startup, the system should listen on both port 80 (HTTP) and port 443 (HTTPS) simultaneously
**Validates: Requirements 9.1**

**Property 28: Certificate domain consistency**
*For any* HTTPS connection, the proxy should present a self-signed certificate matching the configured domain (default *.amazonaws.com)
**Validates: Requirements 9.2, 9.3**

**Property 29: TLS termination correctness**
*For any* HTTPS request, the proxy should properly terminate TLS and forward the request to S3 over HTTPS
**Validates: Requirements 9.4**

### Write-Through Caching Properties

**Property 30: PUT request write-through caching**
*For any* successful PUT request for a whole object, the proxy should cache the object data during upload and retain it after successful completion with PUT_TTL
**Validates: Requirements 10.1**

**Property 31: Failed PUT cleanup**
*For any* PUT request that does not return 200 status, the proxy should delete any cached object data
**Validates: Requirements 10.2**

**Property 32: PUT to GET TTL transition**
*For any* PUT-cached object accessed via GET within PUT_TTL, the proxy should transition the cache entry to use GET_TTL instead of PUT_TTL
**Validates: Requirements 10.4**

**Property 33: PUT TTL expiration**
*For any* write-cached object not accessed within PUT_TTL (default 1 hour), the proxy should expire and remove it from cache
**Validates: Requirements 10.7**

**Property 34: Multipart upload exclusion**
*For any* multipart upload operation, the proxy should not use write-through caching and should pass through without caching
**Validates: Requirements 10.5**

**Property 35: Write cache size enforcement**
*For any* cache state, write-cached objects should not exceed WRITE_CACHE_PERCENT (default 10%) of total cache size
**Validates: Requirements 10.6**

### Shared Cache Volume Properties

**Property 36: Write lock coordination**
*For any* cache write operation on a shared volume, the proxy should acquire a write lock before modifying cache files
**Validates: Requirements 11.2**

**Property 37: Lock timeout handling**
*For any* write lock that cannot be acquired within timeout, the proxy should skip caching and serve by forwarding to S3
**Validates: Requirements 11.3**

**Property 38: Concurrent read safety**
*For any* cache read operation on a shared volume, the proxy should handle concurrent access without requiring locks
**Validates: Requirements 11.4**

**Property 39: Coordinated cache cleanup**
*For any* cache cleanup operation, the proxy should coordinate with other instances to prevent deletion of actively used entries
**Validates: Requirements 11.5**

### OTLP Metrics Export Properties

**Property 40: OTLP export reliability**
*For any* system metrics collection, when OTLP export is enabled, the proxy should export metrics to the configured endpoint without affecting proxy performance
**Validates: Requirements 19.1, 19.7**

**Property 41: OTLP metric accuracy**
*For any* proxy request, S3 request, or cache operation, the corresponding OTLP metrics should accurately reflect the actual system behavior and performance
**Validates: Requirements 19.3, 19.4, 19.5**

**Property 42: OTLP export interval compliance**
*For any* configured OTLP export interval, metrics should be exported at the specified frequency using delta temporality
**Validates: Requirements 19.2**

**Property 43: OTLP authentication and compression**
*For any* OTLP export request, when custom headers or compression are configured, the proxy should include the specified headers and apply the configured compression
**Validates: Requirements 19.8, 19.9**

### Range Storage Architecture Properties

**Property 44: Metadata size efficiency**
*For any* cache entry, the metadata file size should be O(n) where n is the number of ranges, with each range spec consuming approximately 150-200 bytes in JSON format, keeping metadata files under 100KB for typical workloads
**Validates: Range Storage Redesign Requirements 1.4**

**Property 45: Range data separation**
*For any* stored range, the range bytes should NOT appear in the metadata JSON file, only in separate `.bin` files
**Validates: Range Storage Redesign Requirements 1.2**

**Property 46: Atomic range storage**
*For any* range write operation, either both the binary file and metadata entry exist, or neither exists (no partial state)
**Validates: Range Storage Redesign Requirements 3.1, 3.4**

**Property 47: Deterministic file paths**
*For any* cache key and range boundaries, the generated file path should be identical across multiple invocations
**Validates: Range Storage Redesign Requirements 6.2, 6.4**

**Property 48: Metadata lookup performance**
*For any* cache entry with up to 1000 cached ranges, checking range availability should complete in under 10 milliseconds
**Validates: Range Storage Redesign Requirements 2.3**

**Property 49: No orphaned files**
*For any* cache entry deletion, all associated range binary files should be deleted along with the metadata file
**Validates: Range Storage Redesign Requirements 7.3**

**Property 50: Lazy loading**
*For any* metadata read operation, range binary data should NOT be loaded into memory
**Validates: Range Storage Redesign Requirements 2.5**

## Error Handling

The S3 Proxy implements comprehensive error handling to ensure reliability and proper client communication:

### Client Error Handling
- **Missing Host Header**: Return 400 Bad Request with S3-compatible XML error response
- **Invalid Range Headers**: Forward to S3 and return the S3 error response
- **Malformed Requests**: Return appropriate 4xx status codes with descriptive error messages

### Server Error Handling
- **S3 Connection Failures**: Return 502 Bad Gateway with retry-after headers when appropriate
- **Cache Storage Failures**: Continue serving requests by forwarding to S3, log cache errors
- **Timeout Handling**: Implement configurable timeouts for S3 requests with proper error responses
- **Concurrent Request Limit Exceeded**: Return 429 Too Many Requests with Retry-After header when the configured concurrent request limit is reached
- **Resource Exhaustion**: Return 503 Service Unavailable when other resource limits (memory, disk space) are exceeded
- **Certificate Generation Failures**: Log certificate errors and continue with HTTP-only operation
- **Write Lock Timeout**: Skip caching and serve request by forwarding to S3 when write locks cannot be acquired
- **Write Cache Limit Exceeded**: Evict oldest write-cached objects to maintain size limits

### Cache Error Handling
- **Cache Corruption**: Detect and invalidate corrupted cache entries, serve from S3
- **Disk Space Issues**: Implement cache eviction policies and graceful degradation
- **Atomic Operations**: Use atomic file operations to prevent partial writes and corruption

### OTLP Export Error Handling
- **OTLP Endpoint Unavailable**: Log export failures and continue normal proxy operation without affecting performance
- **OTLP Authentication Failures**: Log authentication errors and retry with exponential backoff
- **OTLP Timeout Errors**: Implement configurable timeouts and graceful failure handling
- **OTLP Metric Serialization Errors**: Log serialization failures and continue with next export cycle
- **Network Connectivity Issues**: Implement retry logic with circuit breaker pattern for OTLP exports

### Health Check Error Handling
- **Component Health Check Failures**: Mark individual components as unhealthy while maintaining overall system operation
- **Health Endpoint Unavailable**: Return appropriate HTTP status codes and error messages
- **Health Check Timeout**: Implement timeouts for component health checks to prevent blocking

### Graceful Shutdown Error Handling
- **Shutdown Signal Handling**: Properly handle SIGINT and SIGTERM signals for graceful shutdown
- **Cache Lock Release Failures**: Force release locks if graceful release fails during shutdown
- **Connection Pool Cleanup Errors**: Implement timeout-based cleanup for connection pools during shutdown
- **OTLP Export Flush Failures**: Attempt to flush pending metrics during shutdown with timeout protection

## Containerization

The S3 Proxy is designed for containerized deployment using Docker, leveraging the shared storage coordination model for multi-instance scaling.

### Container Architecture

The proxy runs as a single-process container that binds to ports 80 and 443 inside the container namespace. The container uses the `NET_BIND_SERVICE` capability to bind to privileged ports without requiring full root privileges:

```bash
docker run --cap-add=NET_BIND_SERVICE -p 80:80 -p 443:443 s3-proxy
```

### Volume Mounts

The container requires volume mounts for persistent data and configuration:

```dockerfile
# Shared cache storage (required for multi-instance coordination)
VOLUME ["/cache"]

# Shared log storage (required for logging across instances)
VOLUME ["/logs"]
#   /logs/access/ - Server Access Logs (S3-compatible format)
#   /logs/app/    - Application logs (errors, warnings, debug)

# Configuration file (optional, uses defaults if not provided)
VOLUME ["/config"]
```

**Note**: TLS certificates are generated in memory when HTTPS self-signed mode is explicitly enabled. The default HTTPS mode uses TCP passthrough without certificates.

### Multi-Instance Coordination

Multiple container instances coordinate exclusively through the shared cache volume using file-based locking. No network communication between containers is required or assumed:

```
Container Instance 1 ──┐
                       ├── Shared Cache Volume (/cache)
Container Instance 2 ──┤    ├── Cache files
                       │    ├── Lock files (.lock)
Container Instance N ──┤    └── Metadata files (.meta)
                       │
                       └── Shared Log Volume (/logs)
                           ├── access/2024/01/15/2024-01-15-14-30-00-host1
                           ├── access/2024/01/15/2024-01-15-14-30-05-host2
                           ├── app/host1/proxy.log
                           ├── app/host2/proxy.log
                           └── [date-partitioned access logs + host-specific app logs]
```

Each container instance:
- Operates independently without knowledge of other instances
- Uses file locking for cache write coordination
- Performs cache reads without locking (read-only operations are safe)
- Coordinates cleanup operations through lock files
- Writes Server Access Logs with hostname-based filenames to prevent conflicts
- Uses date-partitioned directory structure for access log organization
- Writes application logs to host-specific subdirectories under `/logs/app/`

### Container Configuration

The container accepts configuration through:
- Environment variables for runtime settings
- Mounted configuration file at `/config/proxy.yaml`
- Command-line arguments passed to the container entrypoint

Key environment variables:
- `CACHE_DIR=/cache` - Cache storage directory (mounted volume)
- `ACCESS_LOG_DIR=/logs/access` - Server Access Logs directory (mounted volume)
- `APP_LOG_DIR=/logs/app` - Application logs directory (mounted volume)
- `HTTP_PORT=80` - HTTP listening port (always HTTP proxy with caching)
- `HTTPS_PORT=443` - HTTPS listening port (TCP passthrough by default)
- `HTTPS_MODE=passthrough` - HTTPS mode: passthrough (default) or selfsigned (TLS termination)
- `HTTPS_DOMAIN=*.amazonaws.com` - Certificate domain (only when HTTPS_MODE=selfsigned)

### Health Checks

The container includes a built-in health check endpoint at `/_health` that validates:
- HTTP port availability (always HTTP proxy with caching)
- HTTPS port availability (TCP passthrough by default)
- Cache directory accessibility
- Access log directory accessibility
- Application log directory accessibility
- S3 endpoint connectivity (basic connectivity test)
- Certificate validity (only when HTTPS_MODE=selfsigned)

### Resource Considerations

Container resource limits should account for:
- **Memory**: RAM caching, connection pooling, and request buffering
- **CPU**: Compression operations and concurrent request handling
- **Disk I/O**: Cache read/write operations and log writing
- **Network**: S3 communication and client connections

The shared cache volume should be sized appropriately for the expected working set and configured with appropriate filesystem performance characteristics for concurrent access.

## Testing Strategy

The S3 Proxy will be tested using a dual approach combining unit tests and property-based tests to ensure comprehensive coverage and correctness validation.

### Property-Based Testing

Property-based testing will be implemented using **QuickCheck** for Rust (or **gopter** for Go), configured to run a minimum of 100 iterations per property test. Each property-based test will be tagged with a comment explicitly referencing the correctness property from this design document using the format: **Feature: s3-proxy, Property {number}: {property_text}**

Property-based tests will verify:
- Request routing and forwarding behavior across various input combinations
- Cache consistency and isolation across different object types and versions
- Range request handling with overlapping and non-overlapping byte ranges
- Conditional request validation with various header combinations
- Cache expiration behavior with different cache control directives
- Error handling with malformed inputs and edge cases

### Unit Testing

Unit tests will complement property-based tests by covering:
- Specific examples that demonstrate correct behavior
- Integration points between components
- Error conditions and edge cases not easily generated by property tests
- Configuration validation and system initialization

### Test Coverage Requirements

- Each correctness property must be implemented by a single property-based test
- Property-based tests should be configured to run at least 100 iterations
- Unit tests should focus on specific examples and integration scenarios
- All error handling paths must be covered by appropriate tests
- Cache consistency scenarios must be thoroughly tested with both approaches

### OTLP and Observability Testing

OTLP metrics export and observability features require specialized testing approaches:

**OTLP Export Testing:**
- Unit tests for OTLP configuration validation and endpoint connectivity
- Integration tests with mock OTLP receivers to verify metric format and content
- Property-based tests for metric accuracy across various request patterns
- Error handling tests for OTLP endpoint failures and network issues

**Health Check Testing:**
- Unit tests for individual component health assessment
- Integration tests for health endpoint HTTP responses
- Property-based tests for health status consistency across system states
- Performance tests to ensure health checks don't impact proxy performance

**Metrics Collection Testing:**
- Unit tests for metric aggregation and calculation accuracy
- Property-based tests for metric consistency across concurrent operations
- Integration tests for metrics HTTP endpoint functionality
- Load tests to verify metrics collection overhead is minimal

**Graceful Shutdown Testing:**
- Unit tests for signal handling and shutdown coordination
- Integration tests for cache lock release and connection cleanup
- Property-based tests for shutdown behavior under various system states
- Timeout tests to ensure shutdown completes within configured timeouts

The combination of unit and property-based testing ensures that the system is both correct in general (properties hold across all inputs) and reliable in specific scenarios (unit tests catch concrete bugs).