# Implementation Plan

- [x] 1. Set up project structure and core dependencies
  - Create Rust project with Cargo.toml including tokio, hyper, serde, quickcheck, rustls, lz4, and file locking dependencies
  - Set up basic project structure with modules for TCP proxy, HTTP proxy, cache, compression, connection pooling, and logging
  - Configure logging frameworks for both access logs and application logs
  - _Requirements: 1.1, 1.2, 9.1, 11.1, 15.3, 15.4_

- [x] 2. Implement core data models and structures
  - [x] 2.1 Create cache entry and metadata data structures
    - Define CacheEntry, CacheMetadata, Range, WriteCacheEntry, RamCacheEntry, and CacheLock structs with proper serialization
    - Implement cache key generation functions for different object types (full, versioned, parts, ranges)
    - _Requirements: 2.1, 6.1, 7.1, 10.1, 11.2_

  - [x] 2.2 Create connection pool and health monitoring structures
    - Define ConnectionPool, HealthMetrics, and connection management data structures
    - Implement IP address resolution and load balancing structures
    - _Requirements: 16.1, 16.2, 16.3_

  - [x] 2.3 Create cache statistics and compression structures
    - Define CacheStatistics, CompressionStats for monitoring cache usage and compression efficiency
    - Implement write cache size tracking and RAM cache management structures
    - _Requirements: 10.5, 12.1, 13.1_

  - [ ]* 2.4 Write property test for cache key generation
    - **Property 19: Version isolation**
    - **Validates: Requirements 6.1, 6.2**

  - [ ]* 2.5 Write property test for range versioning
    - **Property 20: Version cache key construction**
    - **Validates: Requirements 6.3**

- [x] 3. Implement TCP proxy handler (default HTTPS mode)
  - [x] 3.1 Create TCP passthrough functionality
    - Implement transparent TCP tunneling for HTTPS connections (default mode)
    - Add bidirectional traffic forwarding without TLS termination
    - Handle connection establishment and error management
    - _Requirements: 14.1, 14.2, 14.3, 14.5, 14.6_

  - [x] 3.2 Implement TCP proxy error handling
    - Add connection failure detection and cleanup
    - Handle tunnel establishment failures gracefully
    - _Requirements: 14.6_

  - [ ]* 3.3 Write property test for TCP passthrough
    - **Property 29: TLS termination correctness** (for passthrough mode)
    - **Validates: Requirements 14.3**

- [x] 4. Implement HTTP proxy server (always on port 80)
  - [x] 4.1 Create HTTP server with caching
    - Set up tokio HTTP server listening on port 80 with full caching capabilities
    - Implement Host header validation and routing logic
    - Add concurrent request limiting with 429 responses
    - _Requirements: 1.1, 1.3, 1.5, 14.8, 14.9_

  - [x] 4.2 Implement dual-mode HTTPS server
    - Set up HTTPS server on port 443 supporting both TCP passthrough (default) and self-signed TLS termination
    - Add mode switching based on configuration (HTTPS_MODE environment variable)
    - _Requirements: 9.1, 14.1, 14.7_

  - [ ]* 4.3 Write property test for HTTP proxy availability
    - **Property 27: HTTPS port availability** (adapted for HTTP always-on)
    - **Validates: Requirements 14.8**

  - [ ]* 4.4 Write property test for request routing
    - **Property 1: Host-based routing consistency**
    - **Validates: Requirements 1.1**

  - [ ]* 4.5 Write property test for concurrent request handling
    - **Property 3: Concurrent request handling**
    - **Validates: Requirements 1.5**

- [x] 5. Implement connection pooling and load balancing
  - [x] 5.1 Create connection pool manager
    - Implement persistent HTTP connection pools per IP address
    - Add DNS resolution and refresh logic (default 1 minute)
    - Implement connection health monitoring and performance metrics
    - _Requirements: 16.1, 16.2, 16.3, 16.8_

  - [x] 5.2 Implement intelligent load balancing
    - Add request size-based connection selection (small vs large requests)
    - Implement IP address performance tracking and selection
    - Handle connection failures and IP exclusion logic
    - _Requirements: 16.4, 16.5, 16.6, 16.7, 16.9_

  - [ ]* 5.3 Write property test for connection pool management
    - **Property for connection health monitoring**
    - **Validates: Requirements 16.3**

- [x] 6. Implement cache compression system
  - [x] 6.1 Create LZ4 compression handler
    - Implement LZ4 compression/decompression for cached objects
    - Add compression threshold logic (skip small objects)
    - Handle compression and decompression failures gracefully
    - _Requirements: 12.1, 12.2, 12.5, 12.6_

  - [x] 6.2 Integrate compression with caching
    - Apply compression to both full objects and range data
    - Add compression statistics tracking and monitoring
    - _Requirements: 12.3, 12.4, 12.7_

  - [ ]* 6.3 Write property test for compression round-trip
    - **Property for compression consistency**
    - **Validates: Requirements 12.1, 12.3**

- [x] 7. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 8. Implement S3 request forwarding with connection pooling
  - [x] 8.1 Create S3 client with connection pooling
    - Implement HTTPS client using connection pools for S3 communication
    - Handle request forwarding with proper error handling and retries
    - Integrate with load balancing for optimal performance
    - _Requirements: 1.2, 1.4, 16.1_

  - [x] 8.2 Add conditional request header support
    - Implement If-Match, If-None-Match, If-Modified-Since, If-Unmodified-Since handling
    - Add logic to build conditional requests for cache validation
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 3.6_

  - [ ]* 8.3 Write property test for response forwarding
    - **Property 2: Response forwarding completeness**
    - **Validates: Requirements 1.2**

  - [ ]* 8.4 Write property test for conditional request validation
    - **Property 12: If-Match validation**
    - **Validates: Requirements 4.1**

  - [ ]* 8.5 Write property test for If-None-Match validation
    - **Property 13: If-None-Match validation**
    - **Validates: Requirements 4.2**

- [x] 9. Implement TLS certificate management (self-signed mode)
  - [x] 9.1 Create self-signed certificate generation
    - Implement in-memory certificate generation for specified domains
    - Add support for wildcard certificates (*.amazonaws.com default)
    - Handle certificate validation and domain consistency
    - _Requirements: 9.2, 9.3_

  - [x] 9.2 Implement certificate error handling
    - Handle certificate generation failures with fallback to TCP mode
    - Add certificate expiration checking
    - _Requirements: 9.5_

  - [ ]* 9.3 Write property test for certificate domain consistency
    - **Property 28: Certificate domain consistency**
    - **Validates: Requirements 9.2, 9.3**

- [x] 10. Implement disk cache system with compression
  - [x] 10.1 Create file-based cache storage
    - Implement atomic file operations for cache storage with compression
    - Add cache directory management and cleanup
    - Integrate with shared cache coordination system
    - _Requirements: 2.1, 2.2, 11.1, 12.1_

  - [x] 10.2 Implement cache retrieval and validation
    - Add cache lookup with decompression and expiration checking
    - Implement cache hit/miss logic for GET and HEAD requests
    - Integrate with RAM cache for hierarchical caching
    - _Requirements: 2.2, 2.4, 5.1, 5.2, 5.3, 12.3, 13.2_

  - [ ]* 10.3 Write property test for GET response caching
    - **Property 4: GET response caching**
    - **Validates: Requirements 2.1**

  - [ ]* 10.4 Write property test for cache hit efficiency
    - **Property 5: Cache hit efficiency**
    - **Validates: Requirements 2.2, 2.4**

  - [ ]* 10.5 Write property test for cache failure resilience
    - **Property 6: Cache failure resilience**
    - **Validates: Requirements 2.5**

- [x] 11. Implement shared cache coordination
  - [x] 11.1 Create file locking system
    - Implement write lock acquisition and release for cache files
    - Add lock timeout handling and cleanup
    - _Requirements: 11.2, 11.3_

  - [x] 11.2 Implement cache coordination logic
    - Add multi-instance cache operation coordination
    - Handle concurrent read access without locks
    - Implement coordinated cache cleanup
    - _Requirements: 11.1, 11.4, 11.5_

  - [ ]* 11.3 Write property test for write lock coordination
    - **Property 36: Write lock coordination**
    - **Validates: Requirements 11.2**

  - [ ]* 11.4 Write property test for lock timeout handling
    - **Property 37: Lock timeout handling**
    - **Validates: Requirements 11.3**

  - [ ]* 11.5 Write property test for concurrent read safety
    - **Property 38: Concurrent read safety**
    - **Validates: Requirements 11.4**

- [x] 12. Implement RAM caching system
  - [x] 12.1 Create RAM cache manager
    - Implement in-memory cache layer with configurable size limits
    - Add support for LRU, LFU, and TinyLFU eviction algorithms
    - Integrate with compression system for memory efficiency
    - _Requirements: 13.1, 13.2, 13.3, 13.4_

  - [x] 12.2 Implement RAM cache coordination
    - Add RAM cache as first-tier before disk cache
    - Implement cache hierarchy (RAM -> Disk -> S3)
    - Handle RAM cache eviction and promotion logic
    - _Requirements: 13.2, 13.5, 13.6_

  - [ ]* 12.3 Write property test for RAM cache eviction
    - **Property for eviction algorithm correctness**
    - **Validates: Requirements 13.4, 13.5**

- [x] 13. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 14. Implement write-through caching
  - [x] 14.1 Create write-through cache handler
    - Implement PUT request caching during upload with compression
    - Add multipart upload detection to skip write caching
    - Integrate with both RAM and disk cache layers
    - _Requirements: 10.1, 10.4_

  - [x] 14.2 Implement write cache management
    - Add PUT TTL expiration logic (default 1 hour)
    - Implement write cache size enforcement (default 10% limit)
    - Handle failed PUT cleanup across cache layers
    - _Requirements: 10.2, 10.5, 10.6_

  - [ ]* 14.3 Write property test for PUT request write-through caching
    - **Property 30: PUT request write-through caching**
    - **Validates: Requirements 10.1**

  - [ ]* 14.4 Write property test for failed PUT cleanup
    - **Property 31: Failed PUT cleanup**
    - **Validates: Requirements 10.2**

  - [ ]* 14.5 Write property test for PUT to GET TTL transition
    - **Property 32: PUT to GET TTL transition**
    - **Validates: Requirements 10.4**

  - [ ]* 14.6 Write property test for PUT TTL expiration
    - **Property 33: PUT TTL expiration**
    - **Validates: Requirements 10.7**

  - [ ]* 14.7 Write property test for multipart upload exclusion
    - **Property 34: Multipart upload exclusion**
    - **Validates: Requirements 10.5**

  - [ ]* 14.8 Write property test for write cache size enforcement
    - **Property 35: Write cache size enforcement**
    - **Validates: Requirements 10.6**

- [x] 15. Implement range request handling
  - [x] 15.1 Create range header parsing
    - Parse HTTP Range headers and validate byte ranges
    - Handle invalid range requests by forwarding to S3
    - _Requirements: 3.1, 3.5_

  - [x] 15.2 Implement range caching logic with compression
    - Add range-specific cache storage and retrieval with compression
    - Implement range overlap detection and merging
    - Integrate with both RAM and disk cache layers
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 12.7_

  - [x] 15.3 Add range cache validation with conditional headers
    - Implement conditional header injection for uncached range portions
    - Handle 412 responses by invalidating cache and retrying
    - _Requirements: 3.6, 3.7, 3.8_

  - [ ]* 15.4 Write property test for range caching isolation
    - **Property 7: Range caching isolation**
    - **Validates: Requirements 3.1**

  - [ ]* 15.5 Write property test for range overlap optimization
    - **Property 8: Range overlap optimization**
    - **Validates: Requirements 3.2**

  - [ ]* 15.6 Write property test for range merging efficiency
    - **Property 9: Range merging efficiency**
    - **Validates: Requirements 3.3**

  - [ ]* 15.7 Write property test for range cache validation
    - **Property 10: Range cache validation**
    - **Validates: Requirements 3.6**

  - [ ]* 15.9 Write property test for client conditional header preservation
    - **Property 11a: Client conditional header preservation**
    - **Validates: Requirements 3.8**

  - [ ]* 15.8 Write property test for cache invalidation on precondition failure
    - **Property 11: Cache invalidation on precondition failure**
    - **Validates: Requirements 3.7**

- [x] 16. Implement versioning and multipart support
  - [x] 16.1 Add version ID handling
    - Parse versionId parameters and include in cache keys
    - Implement version-specific cache isolation across cache layers
    - _Requirements: 6.1, 6.2, 6.3_

  - [x] 16.2 Implement selective cache invalidation
    - Add logic to invalidate current version cache on PUT requests
    - Handle HEAD/GET metadata consistency validation
    - _Requirements: 6.4, 6.5_

  - [x] 16.3 Implement metadata mismatch detection and invalidation
    - Add logic to compare S3 response metadata with cached metadata
    - Invalidate all cached entries (full object, ranges, parts) when metadata differs
    - Ensure only fresh data is served when cache is invalidated due to metadata mismatch
    - _Requirements: 6.6_

  - [x] 16.4 Add multipart object support
    - Parse partNumber parameters and implement part caching
    - Handle multipart upload passthrough without caching
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

  - [ ]* 16.5 Write property test for selective cache invalidation
    - **Property 21: Selective cache invalidation**
    - **Validates: Requirements 6.4**

  - [ ]* 16.6 Write property test for metadata mismatch invalidation
    - **Property 22: Metadata mismatch invalidation**
    - **Validates: Requirements 6.6**

  - [ ]* 16.7 Write property test for part caching isolation
    - **Property 22: Part caching isolation**
    - **Validates: Requirements 7.1**

  - [ ]* 16.8 Write property test for part cache efficiency
    - **Property 23: Part cache efficiency**
    - **Validates: Requirements 7.2**

  - [ ]* 16.9 Write property test for multipart upload passthrough
    - **Property 24: Multipart upload passthrough**
    - **Validates: Requirements 7.3**

- [x] 17. Implement cache expiration and management
  - [x] 17.1 Add cache expiration logic
    - Implement Cache-Control and Expires header parsing
    - Add automatic cache expiration and cleanup across cache layers
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

  - [x] 17.2 Implement cache eviction policies
    - Add LRU cache eviction when storage limits are reached
    - Implement cache size monitoring and management
    - Coordinate eviction between RAM and disk cache layers
    - _Requirements: 2.5, 13.4, 13.5_

  - [x] 17.3 Implement corrected TTL behavior
    - Separate GET_TTL and HEAD_TTL completely (HEAD_TTL does not affect GET operations)
    - Implement separate HEAD cache with active removal when HEAD_TTL expires
    - Implement PUT→GET TTL transition (PUT-cached objects transition to GET_TTL when accessed)
    - Ensure all parts/ranges of an object expire together
    - Add actively_remove_cached_data configuration support
    - _Requirements: 5.5, 5.6, 5.7, 5.9, 10.4_

  - [ ]* 17.4 Write property test for Cache-Control max-age compliance
    - **Property 16: Cache-Control max-age compliance**
    - **Validates: Requirements 5.1**

  - [ ]* 17.5 Write property test for cache directive compliance
    - **Property 17: Cache directive compliance**
    - **Validates: Requirements 5.2**

  - [ ]* 17.6 Write property test for Expires header handling
    - **Property 18: Expires header handling**
    - **Validates: Requirements 5.3**

  - [ ]* 17.7 Write property test for GET_TTL expiration
    - **Property 18a: GET_TTL expiration for GET requests**
    - **Validates: Requirements 5.5**

  - [ ]* 17.8 Write property test for HEAD_TTL expiration
    - **Property 18b: HEAD_TTL expiration for HEAD requests**
    - **Validates: Requirements 5.6**

  - [ ]* 17.9 Write property test for independent GET and HEAD TTL
    - **Property 18c: Independent GET and HEAD TTL**
    - **Validates: Requirements 5.7**

  - [ ]* 17.10 Write property test for unified part/range expiration
    - **Property 18d: Unified expiration for parts and ranges**
    - **Validates: Requirements 5.9**

- [x] 18. Implement comprehensive logging system
  - [x] 18.1 Create S3-compatible access logging
    - Implement Server Access Logs in S3-compatible format with date partitioning
    - Add configurable logging modes (all requests vs cached-only)
    - Write logs to /logs/access/ with hostname-based filenames
    - _Requirements: 8.1, 8.2, 8.3, 15.3, 15.7_

  - [x] 18.2 Create application logging system
    - Implement application logs (errors, warnings, debug) with host identification
    - Write logs to /logs/app/{hostname}/ subdirectories
    - Add log rotation and management for both access and application logs
    - _Requirements: 15.5, 15.8, 15.9, 15.10_

  - [ ]* 18.3 Write property test for log format compliance
    - **Property 25: Log format compliance**
    - **Validates: Requirements 8.1**

  - [ ]* 18.4 Write property test for selective logging accuracy
    - **Property 26: Selective logging accuracy**
    - **Validates: Requirements 8.2**

- [x] 19. Add configuration and operational features
  - [x] 19.1 Implement configuration file support
    - Add YAML configuration parsing for all system components
    - Support cache settings, logging options, HTTPS mode, compression, RAM cache, and connection pooling
    - _Requirements: 1.5, 5.4, 9.3, 10.5, 10.6, 12.4, 13.1, 16.2_

  - [x] 19.2 Add health checks and metrics
    - [x] 19.2.1 Create HealthManager module with component health checks
      - Implement health status tracking for cache, connection pool, and compression
      - Add component-level health checks with response times
      - _Requirements: 1.4, 2.5, 10.5, 12.1, 13.1, 16.3_
    
    - [x] 19.2.2 Wire up health check HTTP endpoint server
      - Create HTTP server on configured health port (default 8080)
      - Route requests to HealthManager.handle_health_request()
      - Integrate HealthManager with cache, connection pool, and compression components
      - Return JSON health status with appropriate HTTP status codes
      - _Requirements: 1.4, 2.5, 10.5, 12.1, 13.1, 16.3_
    
    - [x] 19.2.3 Wire up metrics HTTP endpoint server
      - Create HTTP server on configured metrics port (default 9090)
      - Expose Prometheus-compatible metrics endpoint
      - Integrate MetricsManager with all system components
      - _Requirements: 1.4, 2.5, 10.5, 12.1, 13.1, 16.3_

  - [x] 19.3 Implement graceful shutdown
    - Add signal handling for graceful shutdown of all components
    - Ensure in-flight requests complete before shutdown
    - Release all cache locks and close connection pools during shutdown
    - _Requirements: 1.5, 11.2, 16.9_

- [x] 20. Final integration and testing
  - [x] 20.1 Integration testing with real S3 endpoints
    - Test against actual S3 and S3-compatible services
    - Validate end-to-end functionality with TCP passthrough and self-signed modes
    - Test connection pooling and load balancing with real S3 endpoints
    - _Requirements: All_

  - [x] 20.2 Multi-instance shared cache testing
    - Test multiple proxy instances using shared cache volume
    - Validate write lock coordination and cache consistency
    - Test RAM cache coordination and compression across instances
    - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 12.1, 13.1_

  - [ ]* 20.3 Write remaining property tests for conditional requests
    - **Property 14: If-Modified-Since validation**
    - **Property 15: If-Unmodified-Since validation**
    - **Validates: Requirements 4.3, 4.4**

  - [ ]* 20.4 Write property test for coordinated cache cleanup
    - **Property 39: Coordinated cache cleanup**
    - **Validates: Requirements 11.5**

- [x] 21. Final Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 22. Implement cache performance validation and short test mode
  - [x] 22.1 Fix non-range GET request handling to use range cache
    - Modify handle_get_head_request to convert non-range GET requests to full range requests (bytes=0-N)
    - Perform HEAD request (using cached HEAD if available) to determine content length
    - Call handle_range_request with synthesized range header
    - Remove obsolete get_cached_response logic that checks separate GET cache
    - _Requirements: 4.2 (Range Storage Redesign)_
  
  - [x] 22.2 Create short performance test mode
    - Add SHORT_MODE environment variable support to performance test script
    - Configure short mode to test 0.1MB and 50MB files with 3 iterations
    - Skip s5cmd tests in short mode
    - Update usage documentation to describe SHORT_MODE
    - _Requirements: 19.1, 19.8_
  
  - [x] 22.3 Create build test script with performance validation
    - Create scripts/test_with_perf.sh that runs all tests plus short performance test
    - Run cargo build, unit tests, and integration tests first
    - Start proxy and run short performance test
    - Parse test results to extract cache miss and cache hit timings
    - Calculate average times and speedup ratio
    - Fail if cache hits are not at least 2x faster than cache misses
    - Clean up test resources (bucket, files, proxy)
    - _Requirements: 19.2, 19.3, 19.4, 19.5, 19.6_
  
  - [x] 22.4 Add real-time log monitoring to performance test
    - Tail proxy logs during test execution
    - Filter for cache hit/miss events
    - Display cache activity to verify correct behavior
    - Save log output for post-test analysis
    - _Requirements: 19.7_
