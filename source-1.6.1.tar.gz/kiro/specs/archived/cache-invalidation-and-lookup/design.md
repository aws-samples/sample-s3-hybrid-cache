# Design Document

## Overview

This design addresses two critical cache coordination issues that prevent optimal cache utilization in the S3 proxy:

1. **Missing Range Cache Lookup**: Full object GET requests don't check for cached ranges before fetching from S3, even when ranges are available
2. **Stale HEAD Cache**: PUT operations don't invalidate HEAD cache entries, causing subsequent requests to use outdated metadata

The solution involves enhancing object metadata to track total object size from multiple sources (HEAD, full GET, PUT, multipart uploads) and modifying the full object GET handler to check for cached ranges when object size is known.

## Architecture

### Current State

**Full Object GET Flow (Current)**:
```
Client → Full GET → Proxy
                     ↓
                  Check HEAD cache
                     ↓
                  Get content_length
                     ↓
                  Split into parallel ranges
                     ↓
                  Fetch ALL ranges from S3 ← PROBLEM: Doesn't check cache
                     ↓
                  Return to client
```

**PUT Flow (Current)**:
```
Client → PUT → Proxy
                ↓
             Cache PUT data
                ↓
             Return to client
                ↓
             HEAD cache remains stale ← PROBLEM: Not invalidated
```

### Proposed State

**Enhanced Object Metadata**:
```rust
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,  // ← Enhanced: Track from multiple sources
    pub content_type: Option<String>,
    pub version_id: Option<String>,
    pub upload_state: UploadState,
    pub cumulative_size: u64,
    pub parts: Vec<PartInfo>,
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
}
```

**Full Object GET Flow (Proposed)**:
```
Client → Full GET → Proxy
                     ↓
                  Check object metadata for size
                     ↓
                  Size known? ──No──→ Forward full request to S3
                     ↓                      ↓
                    Yes                  Cache response
                     ↓                      ↓
                  Check for cached ranges  Replace partial ranges
                     ↓
                  Any cached? ──No──→ Forward full request to S3
                     ↓
                    Yes
                     ↓
                  Split into parallel ranges
                     ↓
                  find_cached_ranges() for each
                     ↓
                  Serve cached + fetch missing
```

**PUT Flow (Proposed)**:
```
Client → PUT → Proxy
                ↓
             Cache PUT data
                ↓
             Store object size in metadata
                ↓
             Invalidate HEAD cache ← NEW
                ↓
             Return to client
```

## Components and Interfaces

### 1. ObjectMetadata Enhancement

**Location**: `src/cache_types.rs`

The `ObjectMetadata` struct already has a `content_length` field. We need to ensure it's populated from all sources:

- HEAD responses (already done)
- Full object GET responses (needs implementation)
- PUT requests (needs implementation)
- Completed multipart uploads (needs implementation)

**No struct changes needed** - just ensure the field is populated correctly.

### 2. Cache Manager Interface

**Location**: `src/cache.rs`

Add method to check if any ranges are cached:

```rust
impl CacheManager {
    /// Check if any ranges are cached for an object
    pub async fn has_cached_ranges(&self, cache_key: &str) -> Result<bool>;
    
    /// Invalidate HEAD cache entry
    pub async fn invalidate_head_cache(&self, cache_key: &str) -> Result<()>;
}
```

### 3. HTTP Proxy Handler

**Location**: `src/http_proxy.rs`

Modify the full object GET handler (around line 385-450) to:

1. Check if object size is known from metadata
2. Check if any ranges are cached
3. If both true, use the existing parallel range fetch logic with `find_cached_ranges()`
4. If either false, forward the full request to S3

### 4. Signed PUT Handler

**Location**: `src/signed_put_handler.rs`

Add HEAD cache invalidation after successful PUT:

```rust
// After caching PUT data
cache_manager.invalidate_head_cache(&cache_key).await?;
```

## Data Models

### ObjectMetadata (Existing)

```rust
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,  // Populated from HEAD/GET/PUT/MPU
    pub content_type: Option<String>,
    pub version_id: Option<String>,
    pub upload_state: UploadState,
    pub cumulative_size: u64,
    pub parts: Vec<PartInfo>,
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
}
```

### HEAD Cache Entry (Existing)

Stored in `head_cache/` directory as JSON files with headers and metadata.

### Range Cache (Existing)

Stored in `ranges/` directory as binary files with corresponding `.meta` files in `objects/`.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*


### Property 1: Object size storage from multiple sources

*For any* HEAD response, full object GET response, PUT request, or completed multipart upload, when cached, the object metadata SHALL contain the correct content_length value matching the actual object size.

**Validates: Requirements 1.1, 1.2, 1.3, 1.4**

### Property 2: Cached ranges are utilized for full object GET

*For any* full object GET request where object size is known and some ranges are cached, the proxy SHALL serve cached ranges from cache and only fetch missing ranges from S3.

**Validates: Requirements 2.4, 2.5**

### Property 3: Complete cache hit requires no S3 requests

*For any* full object GET request where all ranges are cached, the proxy SHALL serve the entire response from cache without making any S3 requests.

**Validates: Requirements 2.6**

### Property 4: Full object GET caches response when size unknown

*For any* full object GET request where object size is not known in metadata, the proxy SHALL forward the request to S3 and cache the complete response.

**Validates: Requirements 2.8**

### Property 5: Full object cache replaces partial ranges

*For any* object with partial cached ranges, when a full object GET response is cached, the new full object data SHALL replace all existing partial ranges.

**Validates: Requirements 2.9**

### Property 6: PUT invalidates HEAD cache

*For any* successful PUT operation, the HEAD cache entry for that object SHALL be invalidated (removed from head_cache directory).

**Validates: Requirements 3.1**

### Property 7: ETag mismatch invalidates cached ranges

*For any* cached ranges with an ETag that differs from the current object metadata ETag, those ranges SHALL be invalidated.

**Validates: Requirements 3.3**

## Error Handling

### Missing Object Size

**Scenario**: Full object GET request but no object size in metadata and no cached ranges.

**Handling**: Forward the full request to S3 as-is. Cache the response and populate object size.

**Logging**: Debug log indicating size unknown, forwarding to S3.

### HEAD Cache Invalidation Failure

**Scenario**: PUT completes but HEAD cache invalidation fails (e.g., file permission error).

**Handling**: Log warning but don't fail the PUT operation. The stale HEAD cache will eventually expire based on TTL.

**Logging**: Warning with cache key and error details.

### Partial Range Replacement Failure

**Scenario**: Full object GET cached but replacing partial ranges fails.

**Handling**: Log warning. The new full object is still cached, but old partial ranges may remain (will be detected as stale via ETag mismatch).

**Logging**: Warning with cache key and error details.

### Range Cache Lookup Failure

**Scenario**: find_cached_ranges() fails due to I/O error.

**Handling**: Treat as cache miss and fetch all ranges from S3. Log the error.

**Logging**: Warning with cache key and error details.

## Testing Strategy

### Unit Tests

Unit tests will verify specific behaviors and edge cases:

1. **Object Size Storage**:
   - Test HEAD response caching stores content_length
   - Test full GET response caching stores content_length
   - Test PUT caching stores content_length
   - Test multipart upload completion stores content_length

2. **HEAD Cache Invalidation**:
   - Test PUT invalidates HEAD cache
   - Test HEAD cache file is removed
   - Test invalidation failure doesn't break PUT

3. **Range Cache Lookup**:
   - Test has_cached_ranges() returns true when ranges exist
   - Test has_cached_ranges() returns false when no ranges exist
   - Test find_cached_ranges() is called during full GET

4. **Full Object Cache Replacement**:
   - Test full GET replaces partial ranges
   - Test metadata is updated with new ETag
   - Test old range files are removed

### Property-Based Tests

Property-based tests will verify universal properties across many inputs using the `quickcheck` library. Each test will run a minimum of 100 iterations.

1. **Property 1: Object size storage from multiple sources**
   - Generate random objects with various sizes
   - Cache via HEAD/GET/PUT/MPU
   - Verify metadata content_length matches actual size
   - **Feature: cache-invalidation-and-lookup, Property 1**

2. **Property 2: Cached ranges are utilized for full object GET**
   - Generate random objects with random cached ranges
   - Perform full object GET
   - Verify cached ranges served from cache, missing ranges from S3
   - **Feature: cache-invalidation-and-lookup, Property 2**

3. **Property 3: Complete cache hit requires no S3 requests**
   - Generate random objects with all ranges cached
   - Perform full object GET
   - Verify zero S3 requests made
   - **Feature: cache-invalidation-and-lookup, Property 3**

4. **Property 4: Full object GET caches response when size unknown**
   - Generate random objects with no size in metadata
   - Perform full object GET
   - Verify response is cached with correct size
   - **Feature: cache-invalidation-and-lookup, Property 4**

5. **Property 5: Full object cache replaces partial ranges**
   - Generate random objects with partial ranges cached
   - Cache full object GET response
   - Verify partial ranges are replaced
   - **Feature: cache-invalidation-and-lookup, Property 5**

6. **Property 6: PUT invalidates HEAD cache**
   - Generate random objects with HEAD cache
   - Perform PUT operation
   - Verify HEAD cache is invalidated
   - **Feature: cache-invalidation-and-lookup, Property 6**

7. **Property 7: ETag mismatch invalidates cached ranges**
   - Generate random objects with cached ranges
   - Update metadata with different ETag
   - Verify ranges are invalidated
   - **Feature: cache-invalidation-and-lookup, Property 7**

### Integration Tests

Integration tests will verify end-to-end behavior:

1. **Full Object GET After PUT**:
   - PUT an object
   - Verify HEAD cache invalidated
   - GET the full object
   - Verify served from PUT cache

2. **Partial Then Full GET**:
   - GET partial ranges
   - GET full object
   - Verify partial ranges replaced

3. **Multiple Instance Coordination**:
   - Instance A PUTs object
   - Instance B GETs full object
   - Verify HEAD cache coordination

## Implementation Notes

### Existing Code Reuse

The implementation will leverage existing functionality:

- `find_cached_ranges()` already exists in `CacheManager`
- Parallel range fetching already exists in `http_proxy.rs`
- Object metadata structure already has `content_length` field
- HEAD cache storage already exists

### Key Changes Required

1. **http_proxy.rs** (line ~385-490):
   - Verify that full object GET correctly converts to range request
   - Verify that `handle_range_request()` is called with correct range
   - Verify that `find_cached_ranges()` is being called
   - Debug why cached ranges aren't being found/used
   - Add comprehensive logging to trace the full flow

2. **range_handler.rs**:
   - Investigate `find_cached_ranges()` to ensure it correctly matches cached ranges
   - Verify range boundary matching logic
   - Add logging for cache lookups

3. **cache.rs**:
   - Add `has_cached_ranges()` method for quick existence check
   - Add `invalidate_head_cache()` method
   - Ensure `content_length` populated from all sources (HEAD/GET/PUT/MPU)

4. **signed_put_handler.rs**:
   - Add HEAD cache invalidation after successful PUT
   - Add logging for invalidation

5. **disk_cache.rs**:
   - Ensure full object cache replaces partial ranges
   - Add ETag mismatch detection and invalidation

### Performance Considerations

- `has_cached_ranges()` should be fast (check for metadata file existence)
- HEAD cache invalidation is a simple file delete (fast)
- Range cache lookup already optimized with binary search
- No additional S3 requests introduced (only optimization to avoid unnecessary requests)

### Backward Compatibility

- Existing cache entries without `content_length` will be treated as "size unknown"
- Existing HEAD cache entries remain valid until invalidated by PUT
- No migration required for existing cache data
