# Implementation Plan

- [x] 1. Add diagnostic logging to trace full object GET flow
  - Add debug logs in http_proxy.rs to trace full object GET conversion to range request
  - Add debug logs in handle_range_request to show range being processed
  - Add debug logs in find_cached_ranges to show what ranges are being looked up
  - Add debug logs to show what cached ranges are found
  - _Requirements: 2.1, 2.2, 2.4_

- [x] 2. Investigate and fix range cache lookup for full object GETs
  - [x] 2.1 Add test to reproduce the issue
    - Create test that PUTs an object, then does full object GET
    - Verify that cached ranges are utilized
    - _Requirements: 2.4, 2.5_
  
  - [x] 2.2 Debug find_cached_ranges() behavior
    - Run test with diagnostic logging
    - Identify why cached ranges aren't being found
    - Check for range boundary mismatches
    - Check for ETag mismatches
    - _Requirements: 2.4, 2.5_
  
  - [x] 2.3 Implement has_cached_ranges optimization
    - Added has_cached_ranges() method to CacheManager
    - Checks for cached metadata before doing HEAD request to S3
    - Returns (has_ranges, content_length) when metadata exists with size > 0
    - Updated http_proxy.rs to check has_cached_ranges first
    - Falls back to HEAD cache, then HEAD request to S3 if needed
    - Updated has_cached_ranges to accept any upload_state with content_length > 0
    - Added tests: test_has_cached_ranges_optimization, test_has_cached_ranges_no_metadata
    - _Requirements: 2.1, 2.2, 2.4, 2.5_

- [x] 3. Implement HEAD cache invalidation on PUT
  - [x] 3.1 Add invalidate_head_cache method to CacheManager
    - Implement method to remove HEAD cache file
    - Add error handling for file not found (not an error)
    - Add logging for invalidation with object key and reason
    - _Requirements: 3.1, 3.2, 4.1_
  
  - [x] 3.2 Call invalidate_head_cache in signed_put_handler
    - Add call after successful PUT caching
    - Handle errors gracefully (log warning, don't fail PUT)
    - Add logging for invalidation
    - _Requirements: 3.1, 4.1_
  
  - [x] 3.3 Call invalidate_head_cache in http_proxy PUT handler
    - Add call after successful PUT forwarding
    - Handle errors gracefully
    - _Requirements: 3.1, 4.1_
  
  - [ ]* 3.4 Write property test for HEAD cache invalidation
    - **Property 6: PUT invalidates HEAD cache**
    - **Validates: Requirements 3.1**
    - Generate random objects with HEAD cache
    - Perform PUT operation
    - Verify HEAD cache is invalidated

- [x] 4. Ensure object size is stored from all sources
  - [x] 4.1 Verify HEAD response caching stores content_length in object metadata
    - Updated store_head_cache_entry to create/update object metadata with content_length
    - Creates minimal metadata with upload_state=InProgress when no data cached
    - Updates existing metadata content_length if different
    - Added test: test_head_cache_stores_content_length_in_metadata
    - _Requirements: 1.1_
  
  - [x] 4.2 Ensure full object GET stores content_length in object metadata
    - Updated store_response_with_headers to create object metadata with content_length
    - Stores both old format (backward compatibility) and new format (optimization)
    - Sets upload_state=Complete for full GET responses
    - Added test: test_get_response_stores_content_length_in_metadata
    - _Requirements: 1.2_
  
  - [x] 4.3 Verify PUT stores content_length in object metadata
    - Confirmed store_write_cache_entry already stores content_length correctly
    - Uses store_full_object_as_range_new which creates proper ObjectMetadata
    - Sets upload_state=Complete for PUT operations
    - _Requirements: 1.3_
  
  - [x] 4.4 Ensure multipart upload completion stores content_length
    - Check that CompleteMultipartUpload stores final size
    - Add logging to confirm
    - _Requirements: 1.4_
  
  - [ ]* 4.5 Write property test for object size storage
    - **Property 1: Object size storage from multiple sources**
    - **Validates: Requirements 1.1, 1.2, 1.3, 1.4**
    - Generate random objects with various sizes
    - Cache via HEAD/GET/PUT/MPU
    - Verify metadata content_length matches actual size

- [ ] 5. Implement full object cache replacement of partial ranges
  - [x] 5.1 Add logic to detect and remove partial ranges when caching full object
    - Modify store_response or forward_get_head_to_s3_and_cache
    - Check for existing range files when caching full GET
    - Remove old range files before storing new full object
    - Update metadata to reflect full object
    - Add logging for range replacement
    - _Requirements: 2.9_
  
  - [ ]* 5.2 Write property test for range replacement
    - **Property 5: Full object cache replaces partial ranges**
    - **Validates: Requirements 2.9**
    - Generate random objects with partial ranges cached
    - Cache full object GET response
    - Verify partial ranges are replaced

- [-] 6. Implement ETag mismatch detection and invalidation
  - [x] 6.1 Add ETag comparison in find_cached_ranges
    - Compare cached range ETag with current object metadata ETag
    - Skip ranges with mismatched ETags (treat as missing)
    - Add logging for ETag mismatches
    - _Requirements: 3.3_
  
  - [x] 6.2 Add method to invalidate stale ranges
    - Create invalidate_stale_ranges method in CacheManager
    - Remove range files with mismatched ETags
    - Update metadata to remove stale range entries
    - _Requirements: 3.3_
  
  - [ ]* 6.3 Write property test for ETag mismatch invalidation
    - **Property 7: ETag mismatch invalidates cached ranges**
    - **Validates: Requirements 3.3**
    - Generate random objects with cached ranges
    - Update metadata with different ETag
    - Verify ranges are invalidated

- [ ] 7. Implement full object GET caching when size unknown
  - [x] 7.1 Ensure full object GET response is cached when size unknown
    - Verify forward_get_head_to_s3_and_cache caches response
    - Verify content_length is extracted and stored in metadata
    - Add logging
    - _Requirements: 2.8_
  
  - [ ]* 7.2 Write property test for full object caching
    - **Property 4: Full object GET caches response when size unknown**
    - **Validates: Requirements 2.8**
    - Generate random objects with no size in metadata
    - Perform full object GET
    - Verify response is cached with correct size

- [x] 8. Add comprehensive logging for cache operations
  - [x] 8.1 Add logging for HEAD cache invalidation
    - Log when HEAD cache is invalidated with object key and reason
    - _Requirements: 4.1_
  
  - [x] 8.2 Add logging for cached range hits
    - Log when cached ranges are found during full object GET
    - Include range details (start, end, size)
    - _Requirements: 4.2_
  
  - [x] 8.3 Add logging for complete cache hits
    - Log when full object is served entirely from cache
    - Include cache efficiency metrics
    - _Requirements: 4.3_

- [x] 9. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ]* 10. Write property test for cached range utilization
  - **Property 2: Cached ranges are utilized for full object GET**
  - **Validates: Requirements 2.4, 2.5**
  - Generate random objects with random cached ranges
  - Perform full object GET
  - Verify cached ranges served from cache, missing ranges from S3

- [ ]* 11. Write property test for complete cache hit
  - **Property 3: Complete cache hit requires no S3 requests**
  - **Validates: Requirements 2.6**
  - Generate random objects with all ranges cached
  - Perform full object GET
  - Verify zero S3 requests made

- [x] 12. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
