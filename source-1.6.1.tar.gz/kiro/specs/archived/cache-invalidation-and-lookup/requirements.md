# Requirements Document

## Introduction

This specification addresses two critical cache coordination issues in the S3 proxy that prevent optimal cache utilization. When clients perform full object GET requests after PUT operations, the proxy fails to leverage cached range data and stale HEAD metadata, resulting in unnecessary S3 requests and degraded performance.

## Glossary

- **Proxy**: The S3 proxy server that intercepts and caches S3 requests
- **Range Cache**: Disk-based storage of object byte ranges in the `ranges/` directory
- **HEAD Cache**: Cached metadata from S3 HEAD responses including ETag and Last-Modified
- **Full Object GET**: A GET request without a Range header requesting the entire object
- **Parallel Range Fetch**: Internal splitting of large objects into multiple concurrent range requests
- **Cache Invalidation**: Removing or marking cached data as stale when source data changes

## Requirements

### Requirement 1

**User Story:** As a proxy user, I want the proxy to track total object size from various sources, so that full object GET requests can utilize cached ranges.

#### Acceptance Criteria

1. WHEN the Proxy caches a HEAD response THEN the Proxy SHALL store the content_length in the object metadata
2. WHEN the Proxy caches a full object GET response THEN the Proxy SHALL store the total object size in the object metadata
3. WHEN the Proxy caches a PUT request THEN the Proxy SHALL store the uploaded object size in the object metadata
4. WHEN the Proxy caches a completed multipart upload THEN the Proxy SHALL store the final object size in the object metadata

### Requirement 2

**User Story:** As a proxy user, I want full object GET requests to utilize cached ranges when available, so that I don't fetch data from S3 that's already available locally.

#### Acceptance Criteria

1. WHEN the Proxy receives a full object GET request THEN the Proxy SHALL check if object size is stored in metadata
2. WHEN object size is known THEN the Proxy SHALL check if any ranges are cached for that object
3. WHEN cached ranges exist for a full object GET THEN the Proxy SHALL split the request into parallel range fetches
4. WHEN the Proxy splits a full object GET into parallel range fetches THEN the Proxy SHALL call find_cached_ranges for each range to identify cache hits
5. WHEN cached ranges are found THEN the Proxy SHALL serve those ranges from cache and only fetch missing ranges from S3
6. WHEN all ranges for a full object GET are cached THEN the Proxy SHALL serve the entire response from cache without additional S3 requests
7. WHEN the Proxy receives a full object GET request and no cached ranges exist THEN the Proxy SHALL forward the original full object request to S3
8. WHEN the Proxy receives a full object GET request and object size is NOT known THEN the Proxy SHALL forward the original full object request to S3 and cache the response
9. WHEN the Proxy caches a full object GET response and partial ranges already exist THEN the Proxy SHALL replace the existing cached ranges with the new full object data

### Requirement 3

**User Story:** As a proxy user, I want PUT operations to invalidate stale HEAD cache entries, so that subsequent requests receive accurate metadata reflecting the updated object.

#### Acceptance Criteria

1. WHEN the Proxy completes a PUT operation THEN the Proxy SHALL invalidate the HEAD cache entry for that object
2. WHEN the HEAD cache is invalidated for an object THEN the Proxy SHALL remove the cached metadata file from the head_cache directory
3. WHEN the Proxy detects an ETag mismatch between cached ranges and current object metadata THEN the Proxy SHALL invalidate the stale cached ranges

### Requirement 4

**User Story:** As a system operator, I want cache invalidation to be logged, so that I can verify correct cache coordination behavior.

#### Acceptance Criteria

1. WHEN the Proxy invalidates a HEAD cache entry THEN the Proxy SHALL log the invalidation with the object key and reason
2. WHEN the Proxy finds cached ranges during full object GET THEN the Proxy SHALL log the cache hit with range details
3. WHEN the Proxy serves a full object entirely from cache THEN the Proxy SHALL log a complete cache hit event
