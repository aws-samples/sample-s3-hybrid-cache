# Implementation Plan: Cache Size Tracking

- [x] 1. Create core data structures and configuration
  - Create `CacheSizeTracker` struct with atomic state
  - Create `CacheSizeConfig` struct with validation parameters
  - Create `CacheSizeMetrics` struct for metrics exposure
  - Create `Checkpoint`, `ValidationMetadata` structs for persistence
  - Add configuration fields to main `Config` struct
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 2. Implement hot path size updates
  - [x] 2.1 Implement atomic size increment/decrement
    - Add `update_size()` method with atomic operations
    - Ensure operation completes in < 10 microseconds
    - _Requirements: 1.1, 1.2, 1.3_
  
  - [x] 2.2 Implement delta log appending
    - Add `try_append_delta()` method with O_APPEND flag
    - Handle append failures gracefully (log warning, continue)
    - _Requirements: 1.4, 1.5_
  
  - [x] 2.3 Add `get_size()` method
    - Return current atomic size value
    - _Requirements: 9.1_

- [x] 3. Implement checkpoint system
  - [x] 3.1 Implement checkpoint writing
    - Create `write_checkpoint()` method
    - Use atomic file operations (write temp, rename)
    - Include size, timestamp, checkpoint count
    - Truncate delta log after successful checkpoint
    - _Requirements: 2.1, 2.2, 2.3, 2.4_
  
  - [x] 3.2 Implement checkpoint reading
    - Create `read_checkpoint()` method
    - Parse JSON checkpoint file
    - Handle missing/corrupted files gracefully
    - _Requirements: 3.1_
  
  - [x] 3.3 Implement checkpoint background task
    - Create `checkpoint_loop()` async task
    - Run every `checkpoint_interval` (default 5 minutes)
    - Handle errors and retry on next interval
    - _Requirements: 2.1, 2.5, 10.2_

- [x] 4. Implement startup recovery
  - [x] 4.1 Implement delta log reading
    - Create `read_delta_log()` method
    - Parse each line as signed integer
    - Sum all deltas
    - _Requirements: 3.2_
  
  - [x] 4.2 Implement recovery logic
    - Create `recover()` method
    - Read checkpoint + replay delta log
    - Initialize atomic size with recovered value
    - Handle missing checkpoint (start from zero)
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [x] 5. Implement validation scheduling
  - [x] 5.1 Implement validation metadata persistence
    - Create `read_validation_metadata()` method
    - Create `write_validation_metadata()` method
    - Store last validation timestamp, drift, scan duration
    - _Requirements: 4.5, 9.2, 9.3_
  
  - [x] 5.2 Implement startup validation check
    - Check last validation timestamp on startup
    - Determine if validation is needed (> 24 hours old)
    - _Requirements: 4.1, 4.2_
  
  - [x] 5.3 Implement jitter calculation
    - Generate random jitter between 0 and `validation_jitter_max`
    - Use `rand` crate for random number generation
    - _Requirements: 4.3_
  
  - [x] 5.4 Implement validation scheduling
    - Create `schedule_validation()` method
    - Apply jitter delay before starting validation
    - Run validation in background task
    - _Requirements: 4.3, 4.4_

- [x] 6. Implement distributed validation coordination
  - [x] 6.1 Implement validation lock
    - Create `try_acquire_validation_lock()` method
    - Use file locking with timeout (60 seconds)
    - Store lock file at `{cache_dir}/size_tracking/validation.lock`
    - _Requirements: 5.1, 5.2_
  
  - [x] 6.2 Implement lock release
    - Ensure lock is released after validation
    - Use RAII pattern (drop guard)
    - _Requirements: 5.4_
  
  - [x] 6.3 Handle lock acquisition failure
    - Skip validation if lock is held
    - Log info message about another instance validating
    - _Requirements: 5.2, 5.5_

- [x] 7. Implement metadata scanning
  - [x] 7.1 Implement metadata file discovery
    - Use `walkdir` crate to traverse cache directory
    - Filter for `.meta` files only
    - Collect all metadata file paths
    - _Requirements: 6.1_
  
  - [x] 7.2 Implement metadata size reading
    - Create `read_metadata_size()` method
    - Read and parse metadata JSON
    - Extract total size from ranges
    - Handle read/parse errors gracefully
    - _Requirements: 6.2, 6.5_
  
  - [x] 7.3 Implement parallel scanning
    - Use `rayon` crate for parallel iteration
    - Process metadata files across all CPU cores
    - Add progress logging every 1M files
    - Sum all metadata sizes
    - _Requirements: 6.3, 6.4, 10.4_
  
  - [x] 7.4 Implement validation performance limits
    - Ensure scan completes within 30 minutes for 100M files
    - Limit CPU usage to 50% if possible
    - _Requirements: 10.4, 10.5_

- [x] 7.5 Enhance validation scan with HEAD cache cleanup
  - [x] 7.5.1 Extend file discovery to include HEAD cache
    - Filter for both `.meta` and `.head` files
    - Create `CacheFile` enum to distinguish file types
    - _Requirements: 11.1_
  
  - [x] 7.5.2 Implement HEAD cache file scanning
    - Create `scan_head_cache_file()` method
    - Read and parse HEAD cache entry JSON
    - Check if entry has expired
    - Delete expired entries
    - Track deletion count and errors
    - _Requirements: 11.2, 11.3, 11.5_
  
  - [x] 7.5.3 Update scan result structure
    - Add `head_cache_expired` count to `ScanResult`
    - Add `head_cache_errors` count to `ScanResult`
    - _Requirements: 11.4_
  
  - [x] 7.5.4 Update validation metadata persistence
    - Include HEAD cache cleanup metrics in validation.json
    - _Requirements: 11.4_
  
  - [x] 7.5.5 Update validation logging
    - Log HEAD cache cleanup results
    - Log errors encountered during cleanup
    - _Requirements: 11.4, 11.5_

- [x] 8. Implement drift detection and reconciliation
  - [x] 8.1 Implement drift calculation
    - Compare scanned size to tracked size
    - Calculate absolute difference
    - _Requirements: 7.1_
  
  - [x] 8.2 Implement drift threshold check
    - Check if drift exceeds configured threshold (default 1GB)
    - Log warning if threshold exceeded
    - _Requirements: 7.2_
  
  - [x] 8.3 Implement reconciliation
    - Update tracked size to scanned size if drift exceeds threshold
    - Write new checkpoint with reconciled size
    - _Requirements: 7.3, 7.4_
  
  - [x] 8.4 Implement drift logging
    - Log drift at debug level if under threshold
    - Log drift at warning level if over threshold
    - _Requirements: 7.5_

- [x] 9. Implement metrics exposure
  - [x] 9.1 Implement `get_metrics()` method
    - Return `CacheSizeMetrics` struct
    - Include current size, timestamps, drift, counts
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_
  
  - [x] 9.2 Integrate with metrics system
    - Add cache size metrics to `/metrics` endpoint
    - Format as JSON
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 10. Implement initialization and shutdown
  - [x] 10.1 Implement `new()` constructor
    - Create size tracking directory structure
    - Recover from persistent state
    - Start background tasks (checkpoint, validation)
    - _Requirements: 3.1, 3.2, 3.3_
  
  - [x] 10.2 Implement `shutdown()` method
    - Stop background tasks gracefully
    - Write final checkpoint
    - Flush delta log
    - _Requirements: 2.1, 2.2_

- [x] 11. Integration with cache manager
  - [x] 11.1 Add CacheSizeTracker to CacheManager
    - Initialize tracker in CacheManager::new()
    - _Requirements: All_
  
  - [x] 11.2 Update cache write operations
    - Call `tracker.update_size(+bytes)` on cache writes
    - _Requirements: 1.1_
  
  - [x] 11.3 Update cache eviction operations
    - Call `tracker.update_size(-bytes)` on evictions
    - _Requirements: 1.2_
  
  - [x] 11.4 Expose metrics via CacheManager
    - Add method to get cache size metrics
    - _Requirements: 9.1_

- [x] 12. Implement lazy HEAD cache deletion
  - [x] 12.1 Update get_head_cache_entry() method
    - Add expiration check after reading entry
    - Delete file if expired
    - Return None for expired entries
    - Log deletion at debug level
    - Log errors at warning level
    - _Requirements: 12.1, 12.2, 12.3, 12.4, 12.5_
  
  - [x] 12.2 Add configuration option
    - Add `cleanup_head_cache` boolean to config
    - Default to true
    - _Requirements: 11.1_

- [x] 13. Fix actively_remove_cached_data bug and integrate GET cache expiration
  - [x] 13.1 Fix coordinate_cleanup() to check flag
    - Add early return if `actively_remove_cached_data` is false
    - Log that GET cache active expiration is disabled
    - Note: This only affects GET cache cleanup, not HEAD cache
    - _Requirements: 13.1, 13.2_
  
  - [x] 13.2 Integrate GET cache expiration with validation scan
    - Pass `actively_remove_cached_data` flag to scan_cache_with_cleanup()
    - Update scan_metadata_file() to accept actively_remove_get_cache parameter
    - Check GET cache expiration and delete if flag is true
    - HEAD cache cleanup always runs regardless of flag
    - _Requirements: 13.1, 13.3_
  
  - [x] 13.3 Implement multi-instance safety checks for GET cache
    - Call is_cache_entry_active() before GET cache deletion
    - Skip deletion if entry is actively being used
    - Track skipped entries in scan results
    - Note: HEAD cache doesn't need active-use checks (metadata-only)
    - _Requirements: 13.3, 13.4, 14.3_
  
  - [x] 13.4 Update ScanFileResult structure
    - Add cache_expired field (for GET cache)
    - Add cache_skipped field (for GET cache)
    - Add cache_error field (for GET cache)
    - Keep separate head_expired and head_error fields
    - _Requirements: 13.5_
  
  - [x] 13.5 Update validation metadata
    - Add cache_entries_expired count (GET cache)
    - Add cache_entries_skipped count (GET cache)
    - Add cache_expiration_errors count (GET cache)
    - Add active_expiration_enabled flag
    - Keep separate head_cache_expired and head_cache_errors counts
    - _Requirements: 13.5, 14.5_
  
  - [x] 13.6 Update validation logging
    - Log GET cache expiration results separately from HEAD cache
    - Log entries skipped due to active use
    - Log expiration errors for both HEAD and GET cache
    - Clarify in logs which cache type is being cleaned
    - _Requirements: 13.5, 14.5_

- [x] 13. Add dependencies
  - Add `rand` crate for jitter generation
  - Add `rayon` crate for parallel scanning
  - Add `walkdir` crate for directory traversal
  - Update Cargo.toml

- [x] 14. Write unit tests
  - Test checkpoint write and read
  - Test delta log append and replay
  - Test recovery logic
  - Test jitter calculation
  - Test drift detection
  - Test HEAD cache expiration detection
  - Test lazy HEAD cache deletion
  - _Requirements: All_

- [x] 15. Write integration tests
  - Test multi-instance validation coordination
  - Test full recovery cycle
  - Test drift reconciliation
  - Test startup validation scheduling
  - Test HEAD cache cleanup during validation
  - Test lazy HEAD cache deletion on read
  - _Requirements: 4.1, 4.2, 5.1, 5.2, 7.1, 7.2, 7.3, 11.1, 11.2, 11.3, 12.1, 12.2_

- [x] 16. Write performance tests
  - Test size update latency (< 10μs)
  - Test checkpoint overhead
  - Test validation scan duration
  - Test HEAD cache cleanup overhead
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [x] 17. Update documentation
  - Update CACHING.md with size tracking details
  - Add configuration examples
  - Document metrics format
  - Document HEAD cache cleanup behavior
  - Document lazy deletion vs periodic cleanup
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5, 9.1, 9.2, 9.3, 9.4, 9.5, 11.1, 12.1_
