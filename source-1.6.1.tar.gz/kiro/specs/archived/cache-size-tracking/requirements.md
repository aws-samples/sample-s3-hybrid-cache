# Requirements: Cache Size Tracking

## Introduction

This spec defines a scalable cache size tracking system for multi-instance deployments with shared disk cache. The system must handle large-scale caches (100M+ objects) while providing accurate metrics without impacting cache operation performance.

## Glossary

- **Cache Size**: Total bytes of cached data (metadata + range files)
- **Checkpoint**: Persistent snapshot of cache size at a point in time
- **Delta Log**: Append-only log of size changes since last checkpoint
- **Validation Scan**: Full metadata scan to verify tracked size accuracy
- **Jitter**: Random delay added to scheduled operations to prevent thundering herd

## Requirements

### Requirement 1: Incremental Size Tracking

**User Story:** As a proxy instance, I want to track cache size changes incrementally, so that I can provide real-time metrics without scanning the filesystem.

#### Acceptance Criteria

1. WHEN a cache write occurs THEN the system SHALL increment the tracked size by the bytes written
2. WHEN a cache eviction occurs THEN the system SHALL decrement the tracked size by the bytes evicted
3. WHEN size is updated THEN the system SHALL complete the update within 10 microseconds
4. WHEN size is updated THEN the system SHALL append the delta to a log file
5. WHEN the delta log is appended THEN the system SHALL use O_APPEND flag to avoid locks

### Requirement 2: Periodic Checkpointing

**User Story:** As a proxy instance, I want to periodically save the current cache size, so that I can recover quickly after a restart.

#### Acceptance Criteria

1. WHEN 5 minutes have elapsed since last checkpoint THEN the system SHALL write a new checkpoint
2. WHEN a checkpoint is written THEN the system SHALL include the total size and timestamp
3. WHEN a checkpoint is written THEN the system SHALL truncate the delta log
4. WHEN a checkpoint is written THEN the system SHALL use atomic file operations
5. WHEN checkpoint write fails THEN the system SHALL log the error and retry on next interval

### Requirement 3: Startup Recovery

**User Story:** As a proxy instance, I want to recover cache size on startup, so that metrics are immediately available.

#### Acceptance Criteria

1. WHEN the proxy starts THEN the system SHALL read the last checkpoint file
2. WHEN the checkpoint is read THEN the system SHALL replay all deltas from the log
3. WHEN recovery completes THEN the system SHALL initialize metrics with the recovered size
4. WHEN no checkpoint exists THEN the system SHALL initialize size to zero
5. WHEN recovery fails THEN the system SHALL log a warning and initialize to zero

### Requirement 4: Validation Scan Scheduling

**User Story:** As a system administrator, I want cache size to be validated once daily at a specific time, so that drift from crashes or external modifications is detected predictably.

#### Acceptance Criteria

1. WHEN the proxy starts THEN the system SHALL check the last validation timestamp
2. WHEN last validation is older than 24 hours THEN the system SHALL calculate the next scheduled validation time
3. WHEN calculating next validation time THEN the system SHALL use the configured time of day (default: midnight local time)
4. WHEN scheduling a validation THEN the system SHALL add random jitter between 0 and 1 hour
5. WHEN validation completes THEN the system SHALL update the last validation timestamp and schedule the next day's validation

### Requirement 5: Distributed Validation Coordination

**User Story:** As a multi-instance deployment, I want only one instance to perform validation at a time, so that we don't waste resources with duplicate scans.

#### Acceptance Criteria

1. WHEN starting a validation THEN the system SHALL attempt to acquire a global validation lock
2. WHEN the lock is held by another instance THEN the system SHALL skip validation
3. WHEN the lock is acquired THEN the system SHALL perform the metadata scan
4. WHEN validation completes THEN the system SHALL release the lock
5. WHEN validation fails THEN the system SHALL release the lock and log the error

### Requirement 6: Metadata-Based Validation

**User Story:** As a proxy instance, I want to validate cache size by scanning metadata files, so that I avoid the cost of stating billions of range files.

#### Acceptance Criteria

1. WHEN performing validation THEN the system SHALL scan only metadata files
2. WHEN scanning metadata THEN the system SHALL read size information from each file
3. WHEN scanning metadata THEN the system SHALL use parallel processing across CPU cores
4. WHEN scanning completes THEN the system SHALL sum all metadata sizes
5. WHEN scan encounters an error THEN the system SHALL log it and continue with remaining files

### Requirement 7: Drift Detection and Reconciliation

**User Story:** As a proxy instance, I want to detect when tracked size differs from actual size, so that I can correct the metrics.

#### Acceptance Criteria

1. WHEN validation completes THEN the system SHALL compare scanned size to tracked size
2. WHEN difference exceeds 1GB THEN the system SHALL log a warning with both values
3. WHEN difference exceeds 1GB THEN the system SHALL update tracked size to scanned size
4. WHEN size is reconciled THEN the system SHALL write a new checkpoint
5. WHEN difference is under 1GB THEN the system SHALL log the difference at debug level

### Requirement 8: Configuration

**User Story:** As a system administrator, I want to configure validation behavior, so that I can tune it for my deployment.

#### Acceptance Criteria

1. WHEN configuring THEN the system SHALL accept checkpoint_interval (default: 300 seconds)
2. WHEN configuring THEN the system SHALL accept validation_time_of_day in "HH:MM" format (default: "00:00" for midnight local time)
3. WHEN configuring THEN the system SHALL accept drift_threshold (default: 1GB)
4. WHEN configuring THEN the system SHALL accept validation_enabled (default: true)

### Requirement 9: Metrics Exposure

**User Story:** As a monitoring system, I want to access cache size metrics, so that I can track cache usage over time.

#### Acceptance Criteria

1. WHEN metrics are requested THEN the system SHALL return the current tracked size
2. WHEN metrics are requested THEN the system SHALL return the last validation timestamp
3. WHEN metrics are requested THEN the system SHALL return the last validation drift amount
4. WHEN metrics are requested THEN the system SHALL return the checkpoint count
5. WHEN metrics are requested THEN the system SHALL return the delta log size

### Requirement 10: Performance

**User Story:** As a proxy instance, I want size tracking to have minimal performance impact, so that cache operations remain fast.

#### Acceptance Criteria

1. WHEN updating size THEN the operation SHALL complete within 10 microseconds
2. WHEN checkpointing THEN the operation SHALL not block cache operations
3. WHEN validating THEN the operation SHALL not impact cache operation latency
4. WHEN validating THEN the operation SHALL use no more than 50% CPU
5. WHEN validating THEN the operation SHALL complete within 30 minutes for 100M objects

### Requirement 11: HEAD Cache Expiration Cleanup

**User Story:** As a proxy instance, I want expired HEAD cache entries to be deleted during validation scans, so that stale metadata doesn't accumulate on disk.

**Note:** HEAD cache cleanup always runs during validation, regardless of `actively_remove_cached_data` setting, because HEAD cache entries are metadata-only and safe to remove.

#### Acceptance Criteria

1. WHEN performing validation THEN the system SHALL always scan HEAD cache files in addition to metadata files
2. WHEN scanning a HEAD cache file THEN the system SHALL check if the entry has expired
3. WHEN a HEAD cache entry is expired THEN the system SHALL delete the file
4. WHEN HEAD cache cleanup completes THEN the system SHALL report the count of expired entries
5. WHEN HEAD cache cleanup encounters errors THEN the system SHALL log them and continue

### Requirement 12: Lazy HEAD Cache Deletion

**User Story:** As a proxy instance, I want frequently-accessed HEAD cache entries to be checked for expiration on read, so that expired entries are removed immediately without waiting for validation.

#### Acceptance Criteria

1. WHEN reading a HEAD cache entry THEN the system SHALL check if it has expired
2. WHEN a HEAD cache entry is expired on read THEN the system SHALL delete the file
3. WHEN a HEAD cache entry is expired on read THEN the system SHALL return None
4. WHEN HEAD cache deletion fails THEN the system SHALL log a warning and return None
5. WHEN HEAD cache deletion succeeds THEN the system SHALL log at debug level

### Requirement 13: Active GET Cache Expiration During Validation

**User Story:** As a system administrator, I want expired GET cache entries (metadata + ranges) to be actively removed during validation scans when enabled, so that stale data doesn't accumulate on disk.

**Note:** This requirement applies only to GET cache entries (actual cached data). HEAD cache cleanup (Requirement 11) always runs regardless of this setting.

#### Acceptance Criteria

1. WHEN `actively_remove_cached_data` is true AND validation runs THEN the system SHALL delete expired GET cache entries
2. WHEN `actively_remove_cached_data` is false THEN the system SHALL skip GET cache expiration cleanup
3. WHEN deleting expired GET cache entries THEN the system SHALL check if entries are actively being used
4. WHEN a GET cache entry is actively being used THEN the system SHALL skip deletion
5. WHEN GET cache expiration completes THEN the system SHALL report the count of deleted entries

### Requirement 14: Multi-Instance Cleanup Coordination

**User Story:** As a multi-instance deployment, I want only one instance to perform validation and cleanup at a time, so that we don't waste resources with duplicate work.

**Note:** This applies to all cleanup operations: size validation, HEAD cache cleanup, and GET cache expiration.

#### Acceptance Criteria

1. WHEN performing validation and cleanup THEN the system SHALL use the global validation lock
2. WHEN the validation lock is held by another instance THEN the system SHALL skip all cleanup operations
3. WHEN checking if a GET cache entry is active THEN the system SHALL verify no other instance is using it
4. WHEN validation and cleanup complete THEN the system SHALL release the lock
5. WHEN validation or cleanup encounters errors THEN the system SHALL release the lock and log errors
