# Design: Cache Size Tracking

## Overview

This design implements a scalable cache size tracking system that provides accurate metrics for multi-instance deployments with shared disk cache. The system uses incremental tracking with periodic validation to balance performance and accuracy.

## Architecture

### Component Overview

```
CacheSizeTracker
├── In-Memory State
│   ├── current_size: AtomicU64
│   ├── last_checkpoint: Mutex<Instant>
│   └── last_validation: Mutex<Instant>
│
├── Persistent State
│   ├── checkpoint.json (size + timestamp)
│   ├── delta.log (append-only size changes)
│   └── validation.json (last validation metadata)
│
└── Background Tasks
    ├── Checkpoint Task (every 5 min)
    └── Validation Task (daily with jitter)
```

### File Structure

```
{cache_dir}/
├── size_tracking/
│   ├── checkpoint.json      # Current size snapshot
│   ├── delta.log           # Append-only change log
│   ├── validation.json     # Last validation metadata
│   └── validation.lock     # Global validation lock
```

## Components and Interfaces

### CacheSizeTracker

```rust
pub struct CacheSizeTracker {
    // Configuration
    config: CacheSizeConfig,
    cache_dir: PathBuf,
    
    // In-memory state
    current_size: AtomicU64,
    last_checkpoint: Mutex<Instant>,
    last_validation: Mutex<Instant>,
    
    // File paths
    checkpoint_path: PathBuf,
    delta_log_path: PathBuf,
    validation_path: PathBuf,
    validation_lock_path: PathBuf,
    
    // Background task handles
    checkpoint_task: Option<JoinHandle<()>>,
    validation_task: Option<JoinHandle<()>>,
}

impl CacheSizeTracker {
    /// Create new tracker and recover from persistent state
    pub async fn new(cache_dir: PathBuf, config: CacheSizeConfig) -> Result<Self>;
    
    /// Update size (hot path - must be fast)
    pub fn update_size(&self, delta: i64);
    
    /// Get current tracked size
    pub fn get_size(&self) -> u64;
    
    /// Get metrics for monitoring
    pub async fn get_metrics(&self) -> CacheSizeMetrics;
    
    /// Shutdown and flush pending state
    pub async fn shutdown(&mut self) -> Result<()>;
}
```

### Configuration

```rust
pub struct CacheSizeConfig {
    /// Interval between checkpoints (default: 300s)
    pub checkpoint_interval: Duration,
    
    /// Time of day for daily validation scan in 24-hour format "HH:MM" (default: "00:00" = midnight local time)
    /// Examples: "00:00" (midnight), "03:30" (3:30 AM), "14:00" (2:00 PM)
    pub validation_time_of_day: String,
    
    /// Drift threshold for reconciliation (default: 1GB)
    pub drift_threshold: u64,
    
    /// Enable validation scans (default: true)
    pub validation_enabled: bool,
}
```

### Persistent State Formats

**checkpoint.json:**
```json
{
  "size_bytes": 627000000,
  "timestamp": "2025-12-04T18:14:11Z",
  "checkpoint_count": 42
}
```

**delta.log:**
```
+104857600
-52428800
+209715200
```

**validation.json:**
```json
{
  "last_validation": "2025-12-04T12:00:00Z",
  "scanned_size": 627000000,
  "tracked_size": 627500000,
  "drift_bytes": 500000,
  "scan_duration_ms": 1560000,
  "metadata_files_scanned": 100000000,
  "head_cache_expired": 1523,
  "head_cache_errors": 3,
  "cache_entries_expired": 45230,
  "cache_entries_skipped": 12,
  "cache_expiration_errors": 5,
  "active_expiration_enabled": true
}
```

## Data Models

### CacheSizeMetrics

```rust
pub struct CacheSizeMetrics {
    /// Current tracked size in bytes
    pub current_size: u64,
    
    /// Last checkpoint timestamp
    pub last_checkpoint: SystemTime,
    
    /// Last validation timestamp
    pub last_validation: Option<SystemTime>,
    
    /// Last validation drift in bytes
    pub last_validation_drift: Option<i64>,
    
    /// Number of checkpoints written
    pub checkpoint_count: u64,
    
    /// Current delta log size in bytes
    pub delta_log_size: u64,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Size Update Atomicity
*For any* cache operation, updating the tracked size and appending to the delta log should appear atomic from the perspective of recovery.
**Validates: Requirements 1.1, 1.2, 1.4**

### Property 2: Checkpoint Consistency
*For any* checkpoint operation, the checkpoint file and truncated delta log should represent the same total size.
**Validates: Requirements 2.1, 2.2, 2.3**

### Property 3: Recovery Correctness
*For any* startup recovery, checkpoint size + sum of delta log entries should equal the size before crash.
**Validates: Requirements 3.1, 3.2, 3.3**

### Property 4: Validation Exclusivity
*For any* time period, at most one instance should be performing a validation scan.
**Validates: Requirements 5.1, 5.2, 5.3**

### Property 5: Daily Validation Scheduling
*For any* 24-hour period, exactly one validation scan should occur globally across all instances, scheduled at a configured time (default: midnight local time) with jitter applied.
**Validates: Requirements 4.3**

### Property 6: Drift Detection Threshold
*For any* validation that detects drift exceeding the threshold, the tracked size should be updated to match the scanned size.
**Validates: Requirements 7.2, 7.3, 7.4**

### Property 7: Performance Bound
*For any* size update operation, the operation should complete within 10 microseconds.
**Validates: Requirements 10.1**

### Property 8: HEAD Cache Expiration Completeness
*For any* HEAD cache entry that is expired, it should be deleted either on next read (lazy) or during the next validation scan (periodic).
**Validates: Requirements 11.2, 11.3, 12.1, 12.2**

### Property 9: HEAD Cache Cleanup Resilience
*For any* HEAD cache cleanup error, the validation scan should continue processing remaining files.
**Validates: Requirements 11.5**

### Property 10: HEAD Cache Cleanup Always Runs
*For any* validation scan, HEAD cache cleanup should always execute regardless of `actively_remove_cached_data` setting.
**Validates: Requirements 11.1**

### Property 11: GET Cache Expiration Conditional Execution
*For any* validation scan, GET cache expiration cleanup should only execute when `actively_remove_cached_data` is true.
**Validates: Requirements 13.1, 13.2**

### Property 12: GET Cache Expiration Multi-Instance Safety
*For any* GET cache entry being deleted during active expiration, the system should verify no other instance is actively using it.
**Validates: Requirements 13.3, 13.4, 14.3**

## Implementation Details

### Hot Path: Size Updates

```rust
impl CacheSizeTracker {
    pub fn update_size(&self, delta: i64) {
        // Fast: atomic operation (nanoseconds)
        if delta > 0 {
            self.current_size.fetch_add(delta as u64, Ordering::Relaxed);
        } else {
            self.current_size.fetch_sub((-delta) as u64, Ordering::Relaxed);
        }
        
        // Fast: append to log with O_APPEND (microseconds)
        // Non-blocking - spawns task if needed
        if let Err(e) = self.try_append_delta(delta) {
            // Log error but don't block cache operation
            warn!("Failed to append delta to log: {}", e);
        }
    }
    
    fn try_append_delta(&self, delta: i64) -> Result<()> {
        use std::fs::OpenOptions;
        use std::io::Write;
        
        let mut file = OpenOptions::new()
            .create(true)
            .append(true)  // O_APPEND - atomic, no locks needed
            .open(&self.delta_log_path)?;
        
        writeln!(file, "{:+}", delta)?;
        Ok(())
    }
}
```

### Checkpoint Task

```rust
async fn checkpoint_loop(&self) {
    let mut interval = tokio::time::interval(self.config.checkpoint_interval);
    
    loop {
        interval.tick().await;
        
        if let Err(e) = self.write_checkpoint().await {
            error!("Checkpoint failed: {}", e);
            continue;
        }
        
        debug!("Checkpoint written successfully");
    }
}

async fn write_checkpoint(&self) -> Result<()> {
    let size = self.current_size.load(Ordering::Relaxed);
    let checkpoint_count = self.checkpoint_count.fetch_add(1, Ordering::Relaxed);
    
    let checkpoint = Checkpoint {
        size_bytes: size,
        timestamp: SystemTime::now(),
        checkpoint_count,
    };
    
    // Atomic write: write to temp file, then rename
    let temp_path = self.checkpoint_path.with_extension("tmp");
    let json = serde_json::to_string_pretty(&checkpoint)?;
    tokio::fs::write(&temp_path, json).await?;
    tokio::fs::rename(&temp_path, &self.checkpoint_path).await?;
    
    // Truncate delta log
    tokio::fs::write(&self.delta_log_path, "").await?;
    
    Ok(())
}
```

### Startup Recovery

```rust
async fn recover(&mut self) -> Result<u64> {
    // Read checkpoint
    let checkpoint = match self.read_checkpoint().await {
        Ok(cp) => cp,
        Err(e) => {
            warn!("No checkpoint found, starting from zero: {}", e);
            return Ok(0);
        }
    };
    
    // Replay delta log
    let deltas = self.read_delta_log().await?;
    let delta_sum: i64 = deltas.iter().sum();
    
    let recovered_size = (checkpoint.size_bytes as i64 + delta_sum).max(0) as u64;
    
    info!(
        "Recovered cache size: checkpoint={}, deltas={}, total={}",
        checkpoint.size_bytes, delta_sum, recovered_size
    );
    
    self.current_size.store(recovered_size, Ordering::Relaxed);
    Ok(recovered_size)
}
```

### Validation Scheduling with Daily Time and Jitter

The validation scan runs once per day globally (across all instances) at a configured time with fixed 1-hour jitter. This ensures:
1. Only one validation per 24-hour period (not per instance)
2. Predictable scheduling at a specific time of day (default: midnight local time)
3. Fixed 1-hour jitter prevents thundering herd when multiple instances start simultaneously

```rust
async fn schedule_next_validation(&self) {
    loop {
        // Calculate next scheduled validation time
        let next_validation_time = self.calculate_next_validation_time().await;
        
        // Calculate sleep duration until next validation
        let now = SystemTime::now();
        let sleep_duration = next_validation_time
            .duration_since(now)
            .unwrap_or(Duration::ZERO);
        
        info!(
            "Next validation scheduled for {:?} (in {} seconds)",
            next_validation_time,
            sleep_duration.as_secs()
        );
        
        // Sleep until scheduled time
        tokio::time::sleep(sleep_duration).await;
        
        // Attempt validation
        if let Err(e) = self.perform_validation().await {
            error!("Validation failed: {}", e);
        }
        
        // Loop to schedule next day's validation
    }
}

async fn calculate_next_validation_time(&self) -> SystemTime {
    use chrono::{Local, Timelike, Duration as ChronoDuration};
    use rand::Rng;
    
    // Parse configured time of day (e.g., "00:00" for midnight)
    let (target_hour, target_minute) = self.parse_time_of_day(&self.config.validation_time_of_day);
    
    // Get current local time
    let now = Local::now();
    
    // Calculate next occurrence of target time
    let mut next_time = now
        .with_hour(target_hour).unwrap()
        .with_minute(target_minute).unwrap()
        .with_second(0).unwrap()
        .with_nanosecond(0).unwrap();
    
    // If target time has already passed today, schedule for tomorrow
    if next_time <= now {
        next_time = next_time + ChronoDuration::days(1);
    }
    
    // Check if validation already ran today
    if let Ok(metadata) = self.read_validation_metadata().await {
        if let Some(last_validation) = metadata.last_validation {
            // Check if last validation was within the last 24 hours
            let elapsed = SystemTime::now()
                .duration_since(last_validation)
                .unwrap_or(Duration::MAX);
            
            if elapsed < Duration::from_secs(86400) {
                // Validation already ran today, schedule for tomorrow
                next_time = next_time + ChronoDuration::days(1);
                info!("Validation already ran today, scheduling for tomorrow");
            }
        }
    }
    
    // Add fixed 1-hour jitter to prevent thundering herd
    let jitter = {
        let mut rng = rand::thread_rng();
        Duration::from_secs(rng.gen_range(0..=3600))
    };
    
    // Convert to SystemTime and add jitter
    let next_system_time: SystemTime = next_time.into();
    next_system_time + jitter
}

fn parse_time_of_day(&self, time_str: &str) -> (u32, u32) {
    // Parse "HH:MM" format
    let parts: Vec<&str> = time_str.split(':').collect();
    if parts.len() != 2 {
        warn!("Invalid time format '{}', using midnight", time_str);
        return (0, 0);
    }
    
    let hour = parts[0].parse::<u32>().unwrap_or(0).min(23);
    let minute = parts[1].parse::<u32>().unwrap_or(0).min(59);
    
    (hour, minute)
}
```

### Validation with Global Lock

```rust
async fn perform_validation(&self) -> Result<()> {
    // Try to acquire global lock
    let lock = match self.try_acquire_validation_lock().await {
        Ok(lock) => lock,
        Err(e) => {
            info!("Another instance is validating, skipping: {}", e);
            return Ok(());
        }
    };
    
    info!("Starting cache size validation scan");
    let start = Instant::now();
    
    // Scan metadata files in parallel
    let scanned_size = self.scan_metadata_parallel().await?;
    let tracked_size = self.current_size.load(Ordering::Relaxed);
    let drift = scanned_size as i64 - tracked_size as i64;
    
    let duration = start.elapsed();
    info!(
        "Validation complete: scanned={}, tracked={}, drift={}, duration={:?}",
        scanned_size, tracked_size, drift, duration
    );
    
    // Check drift threshold
    if drift.abs() as u64 > self.config.drift_threshold {
        warn!(
            "Cache size drift detected: {} bytes (threshold: {})",
            drift, self.config.drift_threshold
        );
        
        // Reconcile
        self.current_size.store(scanned_size, Ordering::Relaxed);
        self.write_checkpoint().await?;
    }
    
    // Write validation metadata
    self.write_validation_metadata(scanned_size, tracked_size, drift, duration).await?;
    
    drop(lock); // Release lock
    Ok(())
}
```

### Combined Validation, HEAD Cache Cleanup, and Active GET Cache Expiration

The validation scan is enhanced to perform multiple cleanup operations in a single pass, amortizing the cost of directory traversal:
1. **Size validation**: Scan metadata files to verify tracked size
2. **HEAD cache cleanup**: Always delete expired HEAD cache entries (metadata-only, always safe)
3. **GET cache expiration** (if `actively_remove_cached_data` is enabled): Delete expired GET cache entries (metadata + ranges)

```rust
struct ScanResult {
    scanned_size: u64,
    tracked_size: u64,
    drift: i64,
    metadata_files_scanned: u64,
    head_cache_expired: u64,
    head_cache_errors: u64,
    cache_entries_expired: u64,      // Active expiration count
    cache_entries_skipped: u64,      // Entries skipped (actively being used)
    cache_expiration_errors: u64,    // Active expiration errors
    scan_duration: Duration,
}

async fn scan_cache_with_cleanup(&self, actively_remove_get_cache: bool) -> Result<ScanResult> {
    use rayon::prelude::*;
    use walkdir::WalkDir;
    
    let now = SystemTime::now();
    let tracked_size = self.current_size.load(Ordering::Relaxed);
    let start = Instant::now();
    
    // Collect all cache files (metadata + HEAD cache)
    let cache_files: Vec<CacheFile> = WalkDir::new(&self.cache_dir)
        .into_iter()
        .par_bridge()
        .filter_map(|e| e.ok())
        .filter_map(|e| {
            let path = e.path();
            let ext = path.extension()?.to_str()?;
            
            match ext {
                "meta" => Some(CacheFile::Metadata(path.to_path_buf())),
                "head" => Some(CacheFile::HeadCache(path.to_path_buf())),
                _ => None,
            }
        })
        .collect();
    
    info!("Found {} cache files to scan (active_get_cache_expiration={})", 
          cache_files.len(), actively_remove_get_cache);
    
    // Parallel scan with cleanup
    let results: Vec<ScanFileResult> = cache_files
        .par_iter()
        .enumerate()
        .filter_map(|(i, file)| {
            // Progress logging every 1M files
            if i % 1_000_000 == 0 && i > 0 {
                info!("Scanned {} / {} files", i, cache_files.len());
            }
            
            match file {
                CacheFile::Metadata(path) => {
                    self.scan_metadata_file(path, now, actively_remove_get_cache).ok()
                }
                CacheFile::HeadCache(path) => {
                    // HEAD cache cleanup always runs (metadata-only, always safe)
                    self.scan_head_cache_file(path, now).ok()
                }
            }
        })
        .collect();
    
    // Aggregate results
    let scanned_size = results.iter()
        .filter_map(|r| r.size)
        .sum();
    
    let head_cache_expired = results.iter()
        .filter(|r| r.head_expired)
        .count() as u64;
    
    let head_cache_errors = results.iter()
        .filter(|r| r.head_error.is_some())
        .count() as u64;
    
    let cache_entries_expired = results.iter()
        .filter(|r| r.cache_expired)
        .count() as u64;
    
    let cache_entries_skipped = results.iter()
        .filter(|r| r.cache_skipped)
        .count() as u64;
    
    let cache_expiration_errors = results.iter()
        .filter(|r| r.cache_error.is_some())
        .count() as u64;
    
    let metadata_files_scanned = results.iter()
        .filter(|r| r.size.is_some())
        .count() as u64;
    
    Ok(ScanResult {
        scanned_size,
        tracked_size,
        drift: scanned_size as i64 - tracked_size as i64,
        metadata_files_scanned,
        head_cache_expired,
        head_cache_errors,
        cache_entries_expired,
        cache_entries_skipped,
        cache_expiration_errors,
        scan_duration: start.elapsed(),
    })
}

enum CacheFile {
    Metadata(PathBuf),
    HeadCache(PathBuf),
}

struct ScanFileResult {
    size: Option<u64>,
    head_expired: bool,
    head_error: Option<String>,
    cache_expired: bool,
    cache_skipped: bool,
    cache_error: Option<String>,
}

fn scan_metadata_file(&self, path: &Path, now: SystemTime, actively_remove_get_cache: bool) -> Result<ScanFileResult> {
    let content = std::fs::read(path)?;
    let metadata: NewCacheMetadata = serde_json::from_slice(&content)?;
    
    let mut result = ScanFileResult {
        size: Some(metadata.calculate_total_size()),
        head_expired: false,
        head_error: None,
        cache_expired: false,
        cache_skipped: false,
        cache_error: None,
    };
    
    // Check if GET cache active expiration is enabled and entry is expired
    if actively_remove_get_cache && now > metadata.expires_at {
        debug!("GET cache entry expired during validation: {}", metadata.cache_key);
        
        // Check if entry is actively being used by another instance
        match self.is_cache_entry_active(&metadata.cache_key).await {
            Ok(is_active) => {
                if is_active {
                    debug!("Skipping deletion of {} - actively being used", metadata.cache_key);
                    result.cache_skipped = true;
                } else {
                    // Safe to delete
                    match self.invalidate_cache_hierarchy(&metadata.cache_key).await {
                        Ok(_) => {
                            result.cache_expired = true;
                            // Don't count size since we're deleting it
                            result.size = None;
                        }
                        Err(e) => {
                            warn!("Failed to delete expired GET cache entry {}: {}", metadata.cache_key, e);
                            result.cache_error = Some(e.to_string());
                        }
                    }
                }
            }
            Err(e) => {
                warn!("Failed to check if GET cache entry is active {}: {}", metadata.cache_key, e);
                result.cache_error = Some(e.to_string());
            }
        }
    }
    
    Ok(result)
}

fn scan_head_cache_file(&self, path: &Path, now: SystemTime) -> Result<ScanFileResult> {
    let content = std::fs::read_to_string(path)?;
    let head_entry: HeadCacheEntry = serde_json::from_str(&content)?;
    
    // Check if expired
    if now > head_entry.expires_at {
        debug!("HEAD cache entry expired during validation: {}", head_entry.cache_key);
        
        // Delete expired entry
        if let Err(e) = std::fs::remove_file(path) {
            warn!(
                "Failed to delete expired HEAD cache during validation: {} - {}",
                head_entry.cache_key, e
            );
            return Ok(ScanFileResult {
                size: None,
                head_expired: false,
                head_error: Some(e.to_string()),
                cache_expired: false,
                cache_skipped: false,
                cache_error: None,
            });
        }
        
        return Ok(ScanFileResult {
            size: None,
            head_expired: true,
            head_error: None,
            cache_expired: false,
            cache_skipped: false,
            cache_error: None,
        });
    }
    
    // Not expired, no size contribution (HEAD cache is metadata only)
    Ok(ScanFileResult {
        size: None,
        head_expired: false,
        head_error: None,
        cache_expired: false,
        cache_skipped: false,
        cache_error: None,
    })
}
```

### Active GET Cache Expiration Integration

**Bug Fix**: The `actively_remove_cached_data` configuration flag was previously stored but never checked, causing expired GET cache entries to always be removed during cleanup regardless of the setting. This integration fixes the bug and properly implements the flag's intended behavior.

**Scope**: This flag controls only GET cache entries (actual cached data: metadata + ranges). HEAD cache cleanup always runs during validation because HEAD entries are metadata-only and safe to remove.

**New Behavior**:
- When `actively_remove_cached_data = false`: Only lazy deletion on read for GET cache (minimal overhead)
- When `actively_remove_cached_data = true`: Lazy deletion + daily validation scan cleanup for GET cache
- HEAD cache cleanup: Always runs during validation regardless of this flag

The validation scan now performs GET cache expiration cleanup when enabled:

```rust
async fn perform_validation(&self) -> Result<ValidationResult> {
    // Try to acquire global lock
    let lock = match self.try_acquire_validation_lock().await {
        Ok(lock) => lock,
        Err(e) => {
            info!("Another instance is validating, skipping: {}", e);
            return Ok(ValidationResult::Skipped);
        }
    };
    
    info!("Starting cache validation scan");
    
    // Get actively_remove_cached_data flag from cache manager
    let actively_remove_get_cache = self.cache_manager.actively_remove_cached_data();
    
    // Scan with combined cleanup:
    // - Size validation (always)
    // - HEAD cache cleanup (always)
    // - GET cache expiration (only if actively_remove_get_cache is true)
    let scan_result = self.scan_cache_with_cleanup(actively_remove_get_cache).await?;
    
    // ... handle drift reconciliation ...
    // ... write validation metadata ...
    
    drop(lock);
    Ok(ValidationResult::Completed(scan_result))
}
```

**Multi-Instance Safety**: 
- All cleanup operations (size validation, HEAD cache, GET cache expiration) use the global validation lock
- HEAD cache cleanup is always safe (metadata-only, no active-use check needed)
- GET cache expiration checks if entries are actively being used before deletion
- Ensures safe operation in multi-instance deployments

### Lazy HEAD Cache Deletion

In addition to periodic cleanup during validation, HEAD cache entries are checked for expiration on every read operation:

```rust
// In cache.rs or disk_cache.rs
pub async fn get_head_cache_entry(&self, cache_key: &str) -> Result<Option<HeadCacheEntry>> {
    let head_cache_dir = self.cache_dir.join("head_cache");
    let sanitized_key = self.sanitize_cache_key(cache_key);
    let file_path = head_cache_dir.join(format!("{}.head", sanitized_key));
    
    if !file_path.exists() {
        return Ok(None);
    }
    
    let head_json = std::fs::read_to_string(&file_path)
        .map_err(|e| ProxyError::CacheError(format!("Failed to read HEAD cache: {}", e)))?;
    
    let head_entry: HeadCacheEntry = serde_json::from_str(&head_json)
        .map_err(|e| ProxyError::CacheError(format!("Failed to deserialize HEAD cache: {}", e)))?;
    
    // Lazy deletion: check expiration on read
    if SystemTime::now() > head_entry.expires_at {
        debug!("HEAD cache entry expired on read: {}", cache_key);
        
        // Delete immediately (best effort)
        if let Err(e) = std::fs::remove_file(&file_path) {
            warn!("Failed to delete expired HEAD cache entry {}: {}", cache_key, e);
        }
        
        return Ok(None);
    }
    
    Ok(Some(head_entry))
}
```

## Error Handling

- **Delta log append failures**: Log warning, continue (size will be corrected at next checkpoint or validation)
- **Checkpoint write failures**: Log error, retry on next interval
- **Validation lock acquisition failures**: Skip validation, another instance is handling it
- **Validation scan errors**: Log error for specific files, continue with remaining files
- **Recovery failures**: Log warning, initialize to zero

## Testing Strategy

### Unit Tests
- Checkpoint write and read
- Delta log append and replay
- Jitter calculation
- Drift detection logic

### Property Tests
- Size update atomicity (Property 1)
- Checkpoint consistency (Property 2)
- Recovery correctness (Property 3)
- Jitter distribution (Property 5)
- Performance bounds (Property 7)

### Integration Tests
- Multi-instance validation coordination (Property 4)
- Full recovery cycle
- Drift detection and reconciliation (Property 6)
- Startup validation scheduling

### Performance Tests
- Size update latency (< 10μs)
- Checkpoint overhead
- Validation scan duration (100M files)

## Configuration Example

```yaml
cache:
  size_tracking:
    checkpoint_interval: "300s"        # 5 minutes
    validation_time_of_day: "00:00"    # Daily validation at midnight local time (24-hour format "HH:MM")
                                       # Fixed 1-hour jitter is automatically applied
    drift_threshold: 1073741824        # 1GB
    validation_enabled: true
  
  # Controls GET cache expiration during validation
  # HEAD cache cleanup always runs during validation (metadata-only, always safe)
  actively_remove_cached_data: false   # false = lazy only, true = lazy + daily scan
```

## Metrics Exposure

```json
{
  "cache_size": {
    "current_bytes": 627000000,
    "last_checkpoint": "2025-12-04T18:14:11Z",
    "last_validation": "2025-12-04T12:00:00Z",
    "last_validation_drift_bytes": 500000,
    "checkpoint_count": 42,
    "delta_log_size_bytes": 1024,
    "head_cache_expired_last_validation": 1523,
    "head_cache_errors_last_validation": 3,
    "cache_entries_expired_last_validation": 45230,
    "cache_entries_skipped_last_validation": 12,
    "cache_expiration_errors_last_validation": 5,
    "active_expiration_enabled": true
  }
}
```
