# Requirements Document

## Introduction

Fix the zero-TTL (`get_ttl: "0s"`) caching behavior in S3 Proxy v1.5.0. The bucket-level-cache-settings feature added three bypass blocks in `http_proxy.rs` that skip cache lookup entirely when `get_ttl=0` or `head_ttl=0`. This defeats the conditional revalidation optimization — the proxy should use cached data to send `If-Modified-Since` headers, allowing S3 to return 304 Not Modified and save bandwidth.

The cache-write side is already correct: `expires_at = now + get_ttl` naturally produces `expires_at = now` when `get_ttl=0`. The fix removes the bypass blocks and lets the existing cache revalidation flow handle zero-TTL objects (they're always expired, so they always revalidate). One gap exists: the full-object GET path lacks expiration checking, so it also needs an expiration check added to match the range request path.

## Glossary

- **Proxy**: The S3 Proxy HTTP server that intercepts and caches S3 requests
- **Cache_Revalidation_Flow**: The existing code path in `http_proxy.rs` (~line 2718) that detects expired cached ranges via `check_range_expiration()`, injects `If-Modified-Since` headers, and handles 304/200/error responses from S3
- **Zero_TTL_Bypass**: The three code blocks in `http_proxy.rs` (~lines 1339, 1415, 1520) that skip cache lookup when `get_ttl` or `head_ttl` is zero, forwarding directly to S3
- **Full_Object_GET_Path**: The code path in `http_proxy.rs` (~line 1555) that handles GET requests without a Range header by checking `has_cached_ranges()` → `find_cached_ranges()` → `serve_full_object_from_cache()`. This path currently has no expiration checking.
- **Range_Request_Path**: The code path in `http_proxy.rs` (~line 2680) that handles GET requests with a Range header. This path already has expiration checking via `check_range_expiration()`.
- **Conditional_Validation**: HTTP mechanism where the proxy sends `If-Modified-Since` or `If-None-Match` headers to S3; S3 returns 304 (unchanged) or 200 (new data)
- **Download_Coordination**: Request coalescing where the first request for an uncached object fetches from S3 while concurrent requests wait and serve from cache
- **Resolved_Settings**: The per-request cache settings after bucket/prefix cascade resolution

## Requirements

### Requirement 1: Remove Zero-TTL Range Request Bypass

**User Story:** As a system operator, I want zero-TTL range requests to use the existing cache revalidation flow, so that cached data enables 304 bandwidth savings instead of always fetching full objects from S3.

#### Acceptance Criteria

1. WHEN a range request arrives for a bucket with `get_ttl=0s`, THE Proxy SHALL perform a normal cache lookup using the Range_Request_Path instead of bypassing the cache
2. WHEN cached range data exists and is expired (as zero-TTL data always is), THE Cache_Revalidation_Flow SHALL inject an `If-Modified-Since` header using the cached object's `Last-Modified` timestamp and send a conditional request to S3
3. WHEN S3 returns 304 Not Modified for a zero-TTL conditional range request, THE Proxy SHALL serve the cached range data to the client and refresh the range TTL (to `get_ttl`, which is 0, so it expires again immediately)
4. WHEN S3 returns 200 OK for a zero-TTL conditional range request, THE Proxy SHALL remove the stale cached range, cache the new data from S3, and serve it to the client
5. IF S3 returns an error (e.g., 403 Forbidden) for a zero-TTL conditional range request, THEN THE Proxy SHALL forward the error response to the client
6. WHEN no cached range data exists (cold cache) for a zero-TTL range request, THE Proxy SHALL fetch from S3, cache the response with `expires_at = now`, and serve it to the client

### Requirement 2: Remove Zero-TTL Full-Object GET Bypass and Add Expiration Checking

**User Story:** As a system operator, I want zero-TTL full-object GET requests to revalidate with S3 using cached data, so that unchanged objects are confirmed via 304 responses instead of re-downloaded.

#### Acceptance Criteria

1. WHEN a full-object GET request arrives for a bucket with `get_ttl=0s`, THE Proxy SHALL perform a normal cache lookup using the Full_Object_GET_Path instead of bypassing the cache
2. WHEN cached full-object data exists and is expired, THE Full_Object_GET_Path SHALL check expiration of cached ranges before serving and perform Conditional_Validation with S3 using `If-Modified-Since`
3. WHEN S3 returns 304 Not Modified for a zero-TTL conditional full-object request, THE Proxy SHALL serve the cached data to the client
4. WHEN S3 returns 200 OK for a zero-TTL conditional full-object request, THE Proxy SHALL cache the new data and serve it to the client
5. IF S3 returns an error for a zero-TTL conditional full-object request, THEN THE Proxy SHALL forward the error response to the client
6. WHEN no cached data exists (cold cache) for a zero-TTL full-object GET, THE Proxy SHALL fetch from S3 with Download_Coordination and cache the response with `expires_at = now`
7. WHEN Download_Coordination is active for a zero-TTL object, THE Proxy SHALL coalesce concurrent requests so only one fetches from S3

### Requirement 3: Remove Zero-TTL HEAD Bypass

**User Story:** As a system operator, I want zero-TTL HEAD requests to use the normal HEAD cache flow, so that HEAD metadata is revalidated through the existing expiration mechanism.

#### Acceptance Criteria

1. WHEN a HEAD request arrives for a bucket with `head_ttl=0s`, THE Proxy SHALL perform a normal HEAD cache lookup instead of bypassing the cache
2. WHEN cached HEAD metadata exists and `is_head_expired()` returns true (as it always does when `head_ttl=0`), THE Proxy SHALL forward the HEAD request to S3 and update the cache with the response

### Requirement 4: Preserve Existing Zero-TTL Invariants

**User Story:** As a system operator, I want the existing zero-TTL safety invariants to remain in place, so that RAM cache and metadata cache behavior is unchanged.

#### Acceptance Criteria

1. WHILE `get_ttl=0s` is configured for a bucket, THE Proxy SHALL exclude range data from the RAM cache (RAM cache bypasses revalidation and would serve stale data)
2. WHILE `get_ttl=0s` is configured for a bucket, THE Proxy SHALL continue storing entries in the metadata cache (metadata cache has its own refresh interval and is used for revalidation decisions)
3. THE Proxy SHALL store zero-TTL GET responses with `expires_at = now + 0 = now`, making them immediately expired
4. THE Proxy SHALL store zero-TTL HEAD responses with `head_expires_at = now + 0 = now`, making them immediately expired

### Requirement 5: Documentation Updates

**User Story:** As a system operator, I want documentation explaining the correct zero-TTL behavior and that settings apply at cache-write time, so that I understand the system's behavior.

#### Acceptance Criteria

1. THE Proxy documentation in `docs/CACHING.md` SHALL update the "Zero TTL Revalidation" section to describe the correct behavior: zero-TTL requests go through the normal cache flow with immediate expiration and conditional revalidation, not a separate bypass path
2. THE Proxy documentation in `docs/CACHING.md` SHALL state that bucket/prefix settings take effect at cache-write time and that objects cached before a settings change retain their original TTL until they expire naturally or are evicted
3. THE Proxy documentation in `docs/CONFIGURATION.md` SHALL include a note in the bucket-level cache settings section that settings apply at cache-write time

### Requirement 6: Version Bump and Changelog

**User Story:** As a system operator, I want the version bumped to 1.5.1 with a changelog entry, so that the fix is tracked.

#### Acceptance Criteria

1. THE `Cargo.toml` version field SHALL be updated to `"1.5.1"`
2. THE `CHANGELOG.md` SHALL contain a `[1.5.1]` entry describing the zero-TTL bypass removal, the addition of full-object GET expiration checking, and the correct revalidation behavior
