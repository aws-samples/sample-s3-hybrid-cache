# Implementation Plan: Zero-TTL Cache Workflow Fix

## Overview

Remove three zero-TTL bypass blocks in `http_proxy.rs`, add expiration checking to the full-object GET path, fix TTL refresh after 304 to use resolved per-bucket TTL, update documentation, and bump version to 1.5.1.

## Tasks

- [x] 1. Remove zero-TTL bypass blocks and pass resolved TTL to range handler
  - [x] 1.1 Remove the range request zero-TTL bypass block (~line 1335-1355 in `src/http_proxy.rs`)
    - Delete the `if resolved_settings.get_ttl == std::time::Duration::ZERO` block that forwards range requests directly to S3
    - The existing `check_range_expiration()` at ~line 2718 handles expired ranges
    - _Requirements: 1.1, 1.2_

  - [x] 1.2 Remove the HEAD request zero-TTL bypass block (~line 1410-1428 in `src/http_proxy.rs`)
    - Delete the `if resolved_settings.head_ttl == std::time::Duration::ZERO` block that forwards HEAD requests directly to S3
    - The existing `is_head_expired()` in `get_head_cache_entry_unified()` handles expired HEAD metadata
    - _Requirements: 3.1, 3.2_

  - [x] 1.3 Remove the full-object GET zero-TTL bypass block (~line 1514-1543 in `src/http_proxy.rs`)
    - Delete the `if resolved_settings.get_ttl == std::time::Duration::ZERO` block that forwards full-object GETs directly to S3
    - _Requirements: 2.1_

  - [x] 1.4 Add `resolved_get_ttl: std::time::Duration` parameter to `handle_range_request()`
    - Add the parameter to the function signature
    - Update the call site in `handle_get_head_request()` to pass `resolved_settings.get_ttl`
    - Change the TTL refresh after 304 (~line 2780) from `config.cache.get_ttl` to `resolved_get_ttl`
    - _Requirements: 1.3_

- [x] 2. Add expiration checking to full-object GET path
  - [x] 2.1 Add expiration check between `can_serve_from_cache` and `serve_full_object_from_cache()`
    - After `find_cached_ranges()` returns `can_serve_from_cache = true` (~line 1577)
    - Get disk_cache read lock, call `check_range_expiration()` on the first cached range (start=0)
    - If expired: drop lock, build validation headers with `If-Modified-Since`, send conditional request to S3
    - On 304: refresh TTL with `resolved_settings.get_ttl`, serve from cache via `serve_full_object_from_cache()`
    - On 200: remove stale range, forward to S3 with caching (fall through to `forward_get_head_with_coordination`)
    - On error/other status: remove stale range, forward to S3
    - If not expired: proceed to `serve_full_object_from_cache()` as before
    - Mirror the existing pattern from the range request path (~line 2718-2900)
    - _Requirements: 2.2, 2.3, 2.4, 2.5_

  - [x] 2.2 Write property test: expired data triggers conditional validation (Property 1)
    - **Property 1: Expired cached data triggers conditional validation**
    - Test that `check_range_expiration()` returns `Some(last_modified)` for any range where `expires_at < now`
    - Test that `check_range_expiration()` returns `None` for any range where `expires_at > now`
    - Generate random `Duration` values, create metadata with `expires_at = now - duration` and `expires_at = now + duration`
    - **Validates: Requirements 1.2, 2.2**

  - [x] 2.3 Write property test: TTL refresh uses resolved get_ttl (Property 2)
    - **Property 2: TTL refresh after 304 uses resolved per-bucket TTL**
    - Test that after calling `refresh_range_ttl(cache_key, start, end, resolved_ttl)`, the range's `expires_at` is approximately `now + resolved_ttl`
    - Generate random `Duration` values for `resolved_ttl` (including `Duration::ZERO`)
    - Verify the stored `expires_at` matches expected value within a small tolerance
    - **Validates: Requirements 1.3**

- [x] 3. Checkpoint - Verify bypass removal and expiration checking
  - Ensure all tests pass, ask the user if questions arise.
  - Run `cargo test` to verify existing tests still pass
  - Verify `tests/bucket_settings_property_test.rs` property tests pass (especially `prop_zero_ttl_forces_ram_cache_ineligible`)

- [x] 4. Write remaining property tests
  - [x] 4.1 Write property test: cache writes set expires_at based on resolved get_ttl (Property 3)
    - **Property 3: Cache writes set expires_at based on resolved get_ttl**
    - Test that for any `get_ttl` duration, stored ranges have `expires_at = now + get_ttl`
    - Generate random `Duration` values, store a range, read back metadata, verify `expires_at`
    - **Validates: Requirements 1.6, 4.3**

  - [x] 4.2 Write property test: HEAD expiration uses head_ttl correctly (Property 4)
    - **Property 4: HEAD expiration uses head_ttl correctly**
    - Test that for any `head_ttl` duration, stored HEAD entries have `head_expires_at = now + head_ttl`
    - Test that `is_head_expired()` returns true iff `head_expires_at < now`
    - Generate random `Duration` values and `SystemTime` values
    - **Validates: Requirements 3.2, 4.4**

  - [x] 4.3 Verify existing property test: zero TTL forces RAM cache ineligibility (Property 5)
    - **Property 5: Zero TTL forces RAM cache ineligibility**
    - Verify `prop_zero_ttl_forces_ram_cache_ineligible` in `tests/bucket_settings_property_test.rs` still passes
    - No new code needed — just confirm the existing test covers this property
    - **Validates: Requirements 4.1**

- [x] 5. Update documentation
  - [x] 5.1 Update `docs/CACHING.md` "Zero TTL Revalidation" section
    - Rewrite to describe correct behavior: zero-TTL requests go through normal cache flow with immediate expiration and conditional revalidation
    - Remove language about bypass paths or skipping cache lookup
    - Add "Settings Apply at Cache-Write Time" subsection explaining that settings take effect when data is written, not retroactively
    - _Requirements: 5.1, 5.2_

  - [x] 5.2 Update `docs/CONFIGURATION.md` bucket-level cache settings section
    - Add note that bucket/prefix settings apply at cache-write time
    - Objects cached before a settings change retain their original TTL until expiry or eviction
    - _Requirements: 5.3_

- [x] 6. Version bump
  - [x] 6.1 Update `Cargo.toml` version to `"1.5.1"`
    - _Requirements: 6.1_

  - [x] 6.2 Add `[1.5.1]` entry to `CHANGELOG.md`
    - Describe: zero-TTL bypass removal, full-object GET expiration checking added, TTL refresh after 304 uses resolved per-bucket TTL, documentation updates
    - _Requirements: 6.2_

- [x] 7. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
  - Run `cargo test` to verify all tests pass
  - Run `cargo build --release` to verify clean compilation

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Property tests validate universal correctness properties
- The existing `check_range_expiration` + conditional validation pattern in the range path (~line 2718-2900) serves as the template for the new full-object GET expiration check
- Property 5 is already tested by existing code — task 4.3 is verification only
