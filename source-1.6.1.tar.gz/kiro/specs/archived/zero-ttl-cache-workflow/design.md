# Design Document: Zero-TTL Cache Workflow Fix

## Overview

The v1.5.0 bucket-level-cache-settings feature added three bypass blocks in `http_proxy.rs` that skip cache lookup when `get_ttl=0` or `head_ttl=0`. This defeats conditional revalidation — the proxy should use cached data to send `If-Modified-Since` headers so S3 can return 304 Not Modified.

The fix has four parts:
1. Remove the three zero-TTL bypass blocks (range, HEAD, full-object GET)
2. Add expiration checking to the full-object GET path (it currently has none)
3. Fix TTL refresh after 304 to use resolved per-bucket TTL instead of global TTL
4. Documentation and version bump

## Architecture

The proxy's GET request handling has three code paths, each with different expiration behavior:

```
handle_get_head_request()
├── resolve_settings(path) → resolved_settings
├── [BYPASS] if get_ttl == ZERO → forward to S3          ← REMOVE
│
├── Range request (Range header present)
│   ├── [BYPASS] if get_ttl == ZERO → forward to S3      ← REMOVE
│   ├── find_cached_ranges()
│   ├── check_range_expiration() → If-Modified-Since      ← EXISTS, works
│   └── serve_range_from_cache() / forward to S3
│
├── HEAD request
│   ├── [BYPASS] if head_ttl == ZERO → forward to S3     ← REMOVE
│   ├── get_head_cache_entry_unified()
│   │   └── is_head_expired() → returns None if expired   ← EXISTS, works
│   └── serve HEAD / forward to S3
│
└── Full-object GET (no Range header)
    ├── has_cached_ranges()
    ├── find_cached_ranges(0, total_size-1)
    ├── [MISSING] no expiration check                     ← ADD
    └── serve_full_object_from_cache()
```

After the fix, all three paths use the same pattern: cache lookup → expiration check → conditional validation if expired → serve or fetch.

### TTL Refresh Bug

The existing revalidation code at ~line 2780 refreshes TTL after a 304 response using `config.cache.get_ttl` (global TTL) instead of the resolved per-bucket TTL. For zero-TTL buckets, this would refresh the range with the global TTL (e.g., 10 years), defeating the purpose. The fix passes `resolved_settings.get_ttl` instead.

Since `resolved_settings` is not currently available in `handle_range_request`, it must be passed as a parameter from the parent `handle_get_head_request` function.

## Components and Interfaces

### Changes to `http_proxy.rs`

#### 1. Remove bypass blocks (3 deletions)

Delete the three `if resolved_settings.get_ttl == std::time::Duration::ZERO` / `head_ttl == ZERO` blocks:

- **Range bypass** (~line 1335-1355): Remove the block that forwards range requests directly to S3 when `get_ttl=0`. The existing `check_range_expiration()` at ~line 2718 handles expired ranges.

- **HEAD bypass** (~line 1410-1428): Remove the block that forwards HEAD requests directly to S3 when `head_ttl=0`. The existing `is_head_expired()` check in `get_head_cache_entry_unified()` handles expired HEAD metadata.

- **Full-object GET bypass** (~line 1514-1543): Remove the block that forwards full-object GETs directly to S3 when `get_ttl=0`.

#### 2. Add expiration checking to full-object GET path (1 addition)

Insert expiration checking between `find_cached_ranges()` returning `can_serve_from_cache = true` and calling `serve_full_object_from_cache()`. The logic mirrors the range path's `check_range_expiration` block:

```
// After: Ok(overlap) if overlap.can_serve_from_cache =>
// Before: serve_full_object_from_cache()

1. Get disk_cache read lock
2. Call check_range_expiration(cache_key, 0, total_size-1) on first cached range
3. If expired (returns Some(last_modified)):
   a. Drop disk_cache lock
   b. Build validation headers with If-Modified-Since
   c. Send conditional request to S3
   d. If 304: refresh TTL with resolved_settings.get_ttl, serve from cache
   e. If 200: remove stale range, forward to S3 with caching
   f. If error/other: remove stale range, forward to S3
4. If not expired: proceed to serve_full_object_from_cache() as before
```

#### 3. Pass resolved_settings.get_ttl to handle_range_request (1 signature change)

Add a `resolved_get_ttl: std::time::Duration` parameter to `handle_range_request()`. Use it in the TTL refresh after 304 instead of `config.cache.get_ttl`.

Change at ~line 2780:
```rust
// Before:
config.cache.get_ttl,
// After:
resolved_get_ttl,
```

Also use `resolved_get_ttl` in the new full-object GET expiration check for TTL refresh after 304.

### Changes to `docs/CACHING.md`

Update the "Zero TTL Revalidation" section (~line 2017) to describe the correct behavior:
- Zero-TTL requests go through the normal cache flow
- Data is cached with `expires_at = now` (immediately expired)
- Every request finds expired data and triggers conditional revalidation
- Remove any language suggesting a separate bypass path

Add a new subsection "Settings Apply at Cache-Write Time" documenting:
- Bucket/prefix settings take effect when data is written to cache
- Changing settings does not retroactively change TTL of already-cached objects
- Objects cached before a settings change retain their original TTL until expiry or eviction

### Changes to `docs/CONFIGURATION.md`

Add a note in the "Bucket-Level Cache Settings" section stating that settings apply at cache-write time.

### Changes to `Cargo.toml` and `CHANGELOG.md`

- Bump version to `1.5.1`
- Add changelog entry describing the fix

## Data Models

No data model changes. The existing `NewCacheMetadata` with `expires_at` and `head_expires_at` fields already supports zero-TTL correctly. When `get_ttl=0`:
- `expires_at = now + Duration::ZERO = now` → `is_expired()` returns true
- `head_expires_at = now + Duration::ZERO = now` → `is_head_expired()` returns true

The `RangeSpec.expires_at` field in cached ranges works the same way.


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Expired cached data triggers conditional validation

*For any* cached range or full-object entry where `expires_at` is in the past, the proxy should perform conditional validation with S3 by injecting an `If-Modified-Since` header with the cached object's `Last-Modified` timestamp, rather than serving the stale data directly.

**Validates: Requirements 1.2, 2.2**

### Property 2: TTL refresh after 304 uses resolved per-bucket TTL

*For any* resolved `get_ttl` value (including zero), when S3 returns 304 Not Modified for a conditional validation request, the proxy should refresh the range's `expires_at` to `now + resolved_get_ttl`, not `now + config.cache.get_ttl` (global TTL).

**Validates: Requirements 1.3**

### Property 3: Cache writes set expires_at based on resolved get_ttl

*For any* GET response cached by the proxy, the stored `expires_at` should equal `now + resolved_get_ttl` where `resolved_get_ttl` is the effective TTL after bucket/prefix cascade resolution. When `get_ttl=0`, this means `expires_at = now` (immediately expired).

**Validates: Requirements 1.6, 4.3**

### Property 4: HEAD expiration uses head_ttl correctly

*For any* HEAD response cached by the proxy, the stored `head_expires_at` should equal `now + resolved_head_ttl`. For any cached HEAD entry, `is_head_expired()` should return true if and only if `head_expires_at < now`.

**Validates: Requirements 3.2, 4.4**

### Property 5: Zero TTL forces RAM cache ineligibility

*For any* resolved settings where `get_ttl` is zero (whether set at global, bucket, or prefix level), `ram_cache_eligible` in the resolved output must be false, regardless of the explicit `ram_cache_eligible` setting at any level.

**Validates: Requirements 4.1**

## Error Handling

No new error handling patterns are introduced. The existing conditional validation flow already handles:

- **304 Not Modified**: Serve cached data, refresh TTL
- **200 OK**: Remove stale range, cache new data, serve to client
- **403 Forbidden / other errors**: Forward error to client, remove stale cached range
- **Network errors**: Forward original request to S3, remove stale cached range

The full-object GET expiration check reuses the same error handling pattern from the range request path.

## Testing Strategy

### Property-Based Testing

The project already uses `quickcheck` (configured in `Cargo.toml`). Property tests should use `quickcheck_macros` for the `#[quickcheck]` attribute and run minimum 100 iterations.

Property 5 (zero TTL forces RAM cache ineligibility) is already tested in `tests/bucket_settings_property_test.rs` as `prop_zero_ttl_forces_ram_cache_ineligible`. Verify it still passes after the changes.

Properties 1-4 involve the interaction between cache metadata, expiration checking, and TTL refresh. These can be tested at the unit level by:
- Generating random `Duration` values for `get_ttl` / `head_ttl`
- Creating metadata with `expires_at = now + ttl`
- Verifying `is_expired()` / `is_head_expired()` returns the correct result
- Verifying TTL refresh produces `expires_at = now + resolved_ttl`

### Unit Tests

- Test that `check_range_expiration` returns `Some(last_modified)` when `expires_at` is in the past
- Test that `check_range_expiration` returns `None` when `expires_at` is in the future
- Test that `is_head_expired()` returns true when `head_expires_at` is in the past
- Test the new full-object GET expiration check with a mock expired range

### Integration Tests

- Zero-TTL range request with warm cache → verify conditional validation occurs (304 path)
- Zero-TTL full-object GET with warm cache → verify conditional validation occurs
- Zero-TTL HEAD with warm cache → verify revalidation occurs
- Zero-TTL cold cache → verify data is fetched and cached with `expires_at = now`
- Zero-TTL with download coordination → verify coalescing still works

### Existing Test Verification

- `tests/bucket_settings_property_test.rs` — all existing property tests should pass unchanged
- `tests/conditional_request_handling_test.rs` — existing conditional request tests should pass
- `tests/conditional_request_logging_test.rs` — existing logging tests should pass
