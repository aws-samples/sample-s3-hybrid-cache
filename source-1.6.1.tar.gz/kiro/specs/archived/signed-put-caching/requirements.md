# Requirements Document: Signed PUT Request Caching

## Introduction

Currently, AWS SigV4 signed PUT requests bypass the write cache to preserve signature integrity. This means that after uploading a file via PUT, the first GET request must fetch from S3 instead of serving from cache. This requirement addresses caching signed PUT requests efficiently while respecting cache capacity limits and maintaining signature integrity.

## Glossary

- **Signed PUT Request**: An HTTP PUT request with AWS Signature Version 4 authentication headers
- **AWS SigV4 Signed Headers**: Headers included in signature calculation, which typically include:
  - `Authorization` header containing the signature
  - `x-amz-date` or `Date` header (timestamp)
  - `x-amz-content-sha256` (payload hash)
  - `Host` header
  - Any headers listed in the `SignedHeaders` parameter of the Authorization header
  - The request body (payload) itself
- **Write Cache**: Cache storage for objects uploaded via PUT requests
- **Cache Capacity**: Maximum size limit for cached data on disk
- **Streaming Cache**: Writing data to cache while simultaneously forwarding to S3
- **Response Caching**: Caching object metadata after successful S3 response
- **ETag**: Entity tag returned by S3 that uniquely identifies object version
- **Content-Length**: Size of the request body in bytes
- **Canonical Request**: The standardized representation of the HTTP request used in SigV4 signature calculation

## Requirements

### Requirement 1: Efficient Signed PUT Caching

**User Story:** As a system operator, I want signed PUT requests to be cached efficiently, so that subsequent GET requests can be served from cache without requiring a full body read twice.

#### Acceptance Criteria

1. WHEN a signed PUT request is received, THEN the Proxy SHALL stream the request body to both S3 and cache simultaneously
2. WHEN streaming to cache, THEN the Proxy SHALL write data in chunks as it is received from the client
3. WHEN the S3 response is successful (200 OK), THEN the Proxy SHALL commit the cached data with metadata from the response
4. WHEN the S3 response is an error (4xx or 5xx), THEN the Proxy SHALL discard the cached data
5. WHEN streaming completes, THEN the Proxy SHALL have read the request body exactly once

### Requirement 2: Cache Capacity Management

**User Story:** As a system operator, I want PUT caching to respect cache capacity limits, so that the cache doesn't exceed available disk space.

#### Acceptance Criteria

1. WHEN receiving a PUT request with Content-Length, THEN the Proxy SHALL check if Content-Length fits within available cache capacity
2. WHEN Content-Length exceeds available cache capacity, THEN the Proxy SHALL forward the request without caching
3. WHEN Content-Length is not provided, THEN the Proxy SHALL stream to cache until either completion or cache capacity is reached
4. WHEN streaming without Content-Length exceeds cache capacity, THEN the Proxy SHALL discard the cached data and continue forwarding
5. WHEN cache capacity would be exceeded, THEN the Proxy SHALL log the bypass decision

### Requirement 3: Metadata Extraction and Storage

**User Story:** As a system operator, I want cached PUT data to include proper metadata, so that subsequent GET requests have correct ETags and headers.

#### Acceptance Criteria

1. WHEN S3 returns a successful response, THEN the Proxy SHALL extract ETag from response headers
2. WHEN S3 returns a successful response, THEN the Proxy SHALL extract Last-Modified from response headers
3. WHEN S3 returns a successful response, THEN the Proxy SHALL extract Content-Type from request headers
4. WHEN committing cached data, THEN the Proxy SHALL store metadata alongside the cached object
5. WHEN metadata is incomplete, THEN the Proxy SHALL still cache the object with available metadata

### Requirement 4: Atomic Cache Operations

**User Story:** As a system operator, I want PUT caching to be atomic, so that partial or failed uploads don't leave corrupted cache entries.

#### Acceptance Criteria

1. WHEN streaming to cache, THEN the Proxy SHALL write to a temporary file
2. WHEN S3 confirms success, THEN the Proxy SHALL atomically rename the temporary file to final location
3. WHEN S3 returns an error, THEN the Proxy SHALL delete the temporary file
4. WHEN the proxy crashes during upload, THEN temporary files SHALL be cleaned up on restart
5. WHEN cache commit fails, THEN the Proxy SHALL log the error but still return the S3 response to the client

### Requirement 5: Multipart Upload Handling

**User Story:** As a system operator, I want multipart uploads to be cached efficiently, so that large file uploads benefit from caching.

#### Acceptance Criteria

1. WHEN receiving an UploadPart request, THEN the Proxy SHALL cache the part data as a range file
2. WHEN caching a part, THEN the Proxy SHALL calculate the byte offset based on previously cached parts
3. WHEN receiving a CompleteMultipartUpload request, THEN the Proxy SHALL update metadata to reflect all cached parts as ranges
4. WHEN CompleteMultipartUpload succeeds, THEN the Proxy SHALL create object metadata linking all part ranges
5. WHEN CompleteMultipartUpload fails or is aborted, THEN the Proxy SHALL mark the upload as incomplete without deleting parts

### Requirement 6: Signature Preservation

**User Story:** As a system operator, I want AWS SigV4 signatures to remain valid, so that S3 accepts the forwarded requests.

#### Acceptance Criteria

1. WHEN forwarding a signed PUT, THEN the Proxy SHALL preserve all original headers exactly
2. WHEN forwarding a signed PUT, THEN the Proxy SHALL preserve the request body exactly
3. WHEN streaming to cache, THEN the Proxy SHALL not modify the request in any way
4. WHEN S3 validates the signature, THEN the signature SHALL match the original request
5. WHEN signature validation fails, THEN the Proxy SHALL discard cached data

### Requirement 7: Performance Optimization

**User Story:** As a system operator, I want PUT caching to have minimal performance overhead, so that upload speeds are not significantly impacted.

#### Acceptance Criteria

1. WHEN streaming to cache, THEN the Proxy SHALL use buffered I/O with appropriate buffer sizes
2. WHEN writing to cache, THEN the Proxy SHALL compress data if beneficial
3. WHEN streaming completes, THEN the total upload time SHALL not increase by more than 10%
4. WHEN cache writes are slow, THEN the Proxy SHALL not block the S3 upload
5. WHEN cache writes fail, THEN the Proxy SHALL continue forwarding to S3

### Requirement 8: Error Handling and Recovery

**User Story:** As a system operator, I want PUT caching to handle errors gracefully, so that upload failures don't corrupt the cache.

#### Acceptance Criteria

1. WHEN cache write fails, THEN the Proxy SHALL log the error and continue without caching
2. WHEN S3 returns an error, THEN the Proxy SHALL clean up any cached data
3. WHEN disk space is exhausted, THEN the Proxy SHALL stop caching and forward requests directly
4. WHEN temporary files exist on startup, THEN the Proxy SHALL clean them up
5. WHEN cache corruption is detected, THEN the Proxy SHALL delete the corrupted entry

### Requirement 9: Monitoring and Observability

**User Story:** As a system operator, I want visibility into PUT caching behavior, so that I can monitor cache effectiveness and troubleshoot issues.

#### Acceptance Criteria

1. WHEN a PUT is cached, THEN the Proxy SHALL log the cache operation with size and duration
2. WHEN a PUT bypasses cache, THEN the Proxy SHALL log the reason for bypass
3. WHEN cache writes fail, THEN the Proxy SHALL log detailed error information
4. WHEN cache capacity is reached, THEN the Proxy SHALL emit a metric
5. WHEN streaming completes, THEN the Proxy SHALL log the total bytes cached
