# Design Document: Signed PUT Request Caching

## Overview

This design implements efficient caching for AWS SigV4 signed PUT requests by streaming the request body simultaneously to both S3 and the local cache. The key innovation is reading the body exactly once while writing to two destinations, avoiding the performance penalty of double-reading large files.

## Architecture

### High-Level Flow

```
Client → Proxy → S3
         ↓
       Cache (streaming)
```

**Streaming Architecture:**
1. Client sends signed PUT request
2. Proxy creates a "tee" stream that splits the body
3. One stream goes to S3 (preserving signature)
4. Other stream goes to cache (temporary file)
5. On S3 success (200 OK): commit cache with metadata
6. On S3 failure: discard cached data

### Component Interaction

```
┌─────────────────────────────────────────────────────────────┐
│                     HTTP Proxy Handler                       │
│  - Detects signed PUT                                        │
│  - Checks cache capacity                                     │
│  - Creates streaming tee                                     │
└──────────────────┬──────────────────────────────────────────┘
                   │
         ┌─────────┴─────────┐
         │                   │
         ▼                   ▼
┌─────────────────┐  ┌──────────────────┐
│  S3 Forwarder   │  │  Cache Writer    │
│  - Raw HTTP     │  │  - Temp file     │
│  - Preserves    │  │  - Streaming     │
│    signature    │  │  - Compression   │
└────────┬────────┘  └────────┬─────────┘
         │                    │
         ▼                    ▼
    ┌────────┐          ┌──────────┐
    │   S3   │          │  Cache   │
    └────┬───┘          │  (temp)  │
         │              └──────────┘
         │ 200 OK
         ▼
    ┌──────────────────────────┐
    │  Commit Cache            │
    │  - Rename temp → final   │
    │  - Update metadata       │
    │  - Extract ETag          │
    └──────────────────────────┘
```

## Components and Interfaces

### 1. StreamingTee

**Purpose:** Split a single input stream into two output streams

```rust
struct StreamingTee {
    input: Box<dyn AsyncRead + Unpin>,
    output1: Box<dyn AsyncWrite + Unpin>, // To S3
    output2: Box<dyn AsyncWrite + Unpin>, // To cache
    buffer: Vec<u8>,
    bytes_written: u64,
}

impl StreamingTee {
    async fn stream_all(&mut self) -> Result<u64>;
    async fn stream_chunk(&mut self) -> Result<Option<usize>>;
}
```

**Key Features:**
- Reads from input once
- Writes to both outputs simultaneously
- Handles backpressure from either output
- Tracks total bytes streamed
- Fails fast if either output fails

### 2. CacheWriter

**Purpose:** Write streaming data to temporary cache file

```rust
struct CacheWriter {
    temp_file: File,
    temp_path: PathBuf,
    final_path: PathBuf,
    compressor: Option<Compressor>,
    bytes_written: u64,
    capacity_limit: Option<u64>,
}

impl CacheWriter {
    async fn write_chunk(&mut self, data: &[u8]) -> Result<()>;
    async fn commit(&mut self, metadata: ObjectMetadata) -> Result<()>;
    async fn discard(&mut self) -> Result<()>;
    fn check_capacity(&self) -> bool;
}
```

**Key Features:**
- Writes to `.tmp` file
- Optional compression (content-aware)
- Capacity checking
- Atomic commit (rename)
- Cleanup on discard

### 3. SignedPutHandler

**Purpose:** Orchestrate signed PUT caching

```rust
struct SignedPutHandler {
    cache_manager: Arc<CacheManager>,
    s3_client: Arc<S3Client>,
    config: CacheConfig,
}

impl SignedPutHandler {
    async fn handle_signed_put(
        &self,
        req: Request<Incoming>,
        cache_key: String,
    ) -> Result<Response<Full<Bytes>>>;
    
    fn should_cache(&self, content_length: Option<u64>) -> bool;
    async fn stream_to_both(&self, body: Incoming, cache_writer: &mut CacheWriter) -> Result<Bytes>;
    async fn extract_metadata(&self, response: &Response) -> ObjectMetadata;
}
```

## Data Models

### CachedPutMetadata

```rust
struct CachedPutMetadata {
    cache_key: String,
    etag: String,
    last_modified: String,
    content_type: Option<String>,
    content_length: u64,
    cached_at: SystemTime,
    compression: CompressionAlgorithm,
    compressed_size: u64,
}
```

### MultipartPutState

```rust
struct MultipartPutState {
    upload_id: String,
    parts: Vec<PartInfo>,
    total_size: u64,
    created_at: SystemTime,
}

struct PartInfo {
    part_number: u32,
    etag: String,
    size: u64,
    byte_offset: u64, // Calculated position in final object
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Single Body Read

*For any* signed PUT request, the request body SHALL be read exactly once from the client, regardless of whether caching succeeds or fails.

**Validates: Requirements 1.5**

### Property 2: Signature Preservation

*For any* signed PUT request, the data forwarded to S3 SHALL be byte-for-byte identical to the data received from the client.

**Validates: Requirements 6.2, 6.3**

### Property 3: Atomic Cache Commit

*For any* cached PUT, either the complete object with metadata exists in cache, or no cache entry exists (no partial entries).

**Validates: Requirements 4.2, 4.3**

### Property 4: Capacity Enforcement

*For any* PUT request, if Content-Length exceeds available cache capacity, the request SHALL be forwarded without caching.

**Validates: Requirements 2.2**

### Property 5: Streaming Capacity Check

*For any* PUT request without Content-Length, if bytes written exceed cache capacity during streaming, the cached data SHALL be discarded and forwarding SHALL continue.

**Validates: Requirements 2.4**

### Property 6: Metadata Consistency

*For any* successfully cached PUT, the cached metadata SHALL match the S3 response headers (ETag, Last-Modified).

**Validates: Requirements 3.1, 3.2**

### Property 7: Error Cleanup

*For any* PUT request where S3 returns an error status, any cached data SHALL be deleted.

**Validates: Requirements 4.3, 8.2**

### Property 8: Multipart Range Assembly

*For any* completed multipart upload, each cached part SHALL be stored as a range file with correct byte offsets.

**Validates: Requirements 5.1, 5.2**

### Property 9: Temporary File Cleanup

*For any* proxy restart, all temporary cache files (`.tmp` extension) SHALL be deleted.

**Validates: Requirements 4.4, 8.4**

### Property 10: Performance Overhead Bound

*For any* cached PUT request, the total upload time SHALL not exceed 110% of the time for an uncached PUT.

**Validates: Requirements 7.3**

## Error Handling

### Error Scenarios

| Error | Detection | Recovery | Cache State |
|-------|-----------|----------|-------------|
| S3 returns 4xx/5xx | Check response status | Discard cache, return error to client | Cleaned up |
| Cache write fails | I/O error during write | Continue forwarding to S3, log error | No cache entry |
| Disk full | Write returns ENOSPC | Stop caching, continue forwarding | Partial data discarded |
| Signature invalid | S3 returns 403 | Discard cache, return error | Cleaned up |
| Network timeout | Timeout during forward | Return error, discard cache | Cleaned up |
| Capacity exceeded | During streaming | Discard cache, continue forwarding | Cleaned up |

### Error Handling Strategy

1. **S3 is source of truth**: Always prioritize S3 response over cache
2. **Fail open**: If caching fails, continue without cache
3. **Clean up aggressively**: Delete partial/failed cache entries immediately
4. **Log everything**: Detailed error logging for troubleshooting
5. **Metrics**: Track cache failures for monitoring

## Testing Strategy

### Unit Tests

1. **StreamingTee Tests**
   - Single read, dual write
   - Backpressure handling
   - Error propagation
   - Byte counting accuracy

2. **CacheWriter Tests**
   - Temporary file creation
   - Atomic commit
   - Discard cleanup
   - Capacity checking
   - Compression integration

3. **Metadata Extraction Tests**
   - ETag parsing
   - Last-Modified parsing
   - Missing header handling

### Property-Based Tests

Using `quickcheck` framework with 100+ iterations per property:

1. **Property 1: Single Body Read**
   ```rust
   // Generate random body data
   // Stream through tee
   // Verify input read count == 1
   // Verify both outputs received same data
   ```

2. **Property 2: Signature Preservation**
   ```rust
   // Generate random signed request
   // Stream through proxy
   // Verify S3 received exact bytes
   ```

3. **Property 3: Atomic Cache Commit**
   ```rust
   // Generate random PUT scenarios (success/failure)
   // Check cache state after each
   // Verify no partial entries exist
   ```

4. **Property 6: Metadata Consistency**
   ```rust
   // Generate random S3 responses
   // Extract and cache metadata
   // Verify cached metadata matches response
   ```

5. **Property 8: Multipart Range Assembly**
   ```rust
   // Generate random multipart uploads
   // Cache parts
   // Verify byte offsets are correct
   // Verify no gaps or overlaps
   ```

### Integration Tests

1. **End-to-End PUT Caching**
   - Upload file via signed PUT
   - Verify cached
   - GET file
   - Verify served from cache

2. **Capacity Limit Enforcement**
   - Set small cache capacity
   - Upload large file
   - Verify bypassed cache
   - Verify still forwarded to S3

3. **Multipart Upload Caching**
   - Upload file in parts
   - Complete multipart
   - Verify all parts cached as ranges
   - GET file
   - Verify assembled correctly

4. **Error Recovery**
   - Simulate S3 errors
   - Verify cache cleaned up
   - Verify client receives error

5. **Concurrent PUTs**
   - Upload multiple files simultaneously
   - Verify all cached correctly
   - Verify no race conditions

### Performance Tests

1. **Streaming Overhead**
   - Measure upload time with/without caching
   - Verify < 10% overhead
   - Test with various file sizes

2. **Throughput**
   - Measure bytes/second with caching
   - Compare to direct S3 upload
   - Test with concurrent uploads

## Implementation Notes

### Streaming Implementation

Use Tokio's `AsyncRead` and `AsyncWrite` traits:

```rust
async fn stream_with_tee(
    input: impl AsyncRead,
    output1: impl AsyncWrite,
    output2: impl AsyncWrite,
) -> Result<u64> {
    let mut buffer = vec![0u8; 8192]; // 8KB buffer
    let mut total = 0u64;
    
    loop {
        let n = input.read(&mut buffer).await?;
        if n == 0 { break; }
        
        // Write to both outputs
        output1.write_all(&buffer[..n]).await?;
        output2.write_all(&buffer[..n]).await?;
        
        total += n as u64;
    }
    
    Ok(total)
}
```

### Capacity Checking

```rust
fn check_cache_capacity(
    content_length: Option<u64>,
    current_usage: u64,
    max_capacity: u64,
) -> CacheDecision {
    match content_length {
        Some(len) => {
            if current_usage + len > max_capacity {
                CacheDecision::Bypass
            } else {
                CacheDecision::Cache
            }
        }
        None => {
            // Stream and check during upload
            CacheDecision::StreamWithCapacityCheck
        }
    }
}
```

### Multipart Offset Calculation

```rust
fn calculate_part_offset(parts: &[PartInfo], part_number: u32) -> u64 {
    parts.iter()
        .filter(|p| p.part_number < part_number)
        .map(|p| p.size)
        .sum()
}
```

## Deployment Considerations

### Configuration

```yaml
cache:
  write_cache:
    enabled: true
    max_size: 10GB
    signed_put_caching: true
    streaming_buffer_size: 8192
    compression: auto
```

### Monitoring Metrics

- `signed_put_cached_total`: Counter of cached PUTs
- `signed_put_bypassed_total`: Counter of bypassed PUTs
- `signed_put_cache_failures_total`: Counter of cache failures
- `signed_put_bytes_cached`: Histogram of cached bytes
- `signed_put_streaming_duration`: Histogram of streaming time

### Logging

- `INFO`: Successful cache operations
- `WARN`: Cache bypassed (capacity, errors)
- `ERROR`: Cache failures, cleanup failures
- `DEBUG`: Streaming progress, metadata extraction

## Future Enhancements

1. **Parallel Streaming**: Write to cache and S3 in parallel threads
2. **Adaptive Buffering**: Adjust buffer size based on throughput
3. **Partial Caching**: Cache first N bytes for range requests
4. **Smart Eviction**: Prioritize keeping recently PUT objects
5. **Deduplication**: Detect duplicate uploads by content hash
