# Implementation Plan: Journal-Based Metadata Updates

## Overview

This implementation routes all cache-hit metadata updates through a journal system with RAM buffering, eliminating race conditions on shared storage. The implementation follows a bottom-up approach: data structures first, then core logic, then integration.

## Tasks

- [x] 1. Extend journal data structures
  - [x] 1.1 Add TtlRefresh and AccessUpdate to JournalOperation enum
    - Add new variants to `src/journal_manager.rs`
    - Add `new_ttl_secs: Option<u64>` and `access_increment: Option<u64>` fields to JournalEntry
    - Update serialization/deserialization
    - _Requirements: 1.4_
  - [x] 1.2 Write property test for JournalEntry serialization round-trip
    - **Property 4: Journal Entry Serialization Round-Trip**
    - Generate random JournalEntry instances with all operation types
    - Verify serialize → deserialize produces equivalent entry
    - _Requirements: 1.4_

- [x] 2. Implement lock acquisition with retry
  - [x] 2.1 Create LockConfig struct and acquire_lock_with_retry function
    - Add to `src/metadata_lock_manager.rs`
    - Implement exponential backoff with jitter
    - Add max_retries, initial_backoff, max_backoff, jitter_factor config
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.7_
  - [x] 2.2 Write property test for exponential backoff
    - **Property 3: Exponential Backoff with Jitter**
    - Verify backoff grows exponentially
    - Verify cap is respected
    - Verify jitter is within bounds
    - _Requirements: 3.2, 3.5, 3.7_

- [x] 3. Implement CacheHitUpdateBuffer
  - [x] 3.1 Create CacheHitUpdateBuffer struct
    - New file `src/cache_hit_update_buffer.rs`
    - RAM buffer with Vec<BufferedCacheHitUpdate>
    - record_ttl_refresh() and record_access_update() methods
    - Configurable flush_interval and max_buffer_size
    - _Requirements: 1.1, 1.2, 1.3_
  - [x] 3.2 Implement periodic flush to journal file
    - flush() method writes all buffered entries to instance journal
    - Single journal file per instance: `metadata/_journals/{instance_id}.journal`
    - Append-only writes (one JSON line per entry)
    - _Requirements: 1.1, 1.2, 1.3_
  - [x] 3.3 Write property test for journal routing
    - **Property 1: Journal Routing for Cache-Hit Updates**
    - Verify TTL refresh creates journal entry (not direct write)
    - Verify access update creates journal entry (not direct write)
    - _Requirements: 1.1, 1.2, 1.3_

- [x] 4. Enhance JournalConsolidator for new operations
  - [x] 4.1 Update apply_journal_entries to handle TtlRefresh and AccessUpdate
    - TtlRefresh: update expires_at field for specified range
    - AccessUpdate: increment access_count and update last_accessed
    - Apply entries in timestamp order
    - _Requirements: 1.5, 4.2, 4.3, 4.4_
  - [x] 4.2 Implement full-duration locking during consolidation
    - Use acquire_lock_with_retry for metadata file lock
    - Hold lock for entire read-modify-write cycle
    - Write metadata in-place (no tmp file)
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 4.1_
  - [x] 4.3 Update consolidation to read from single-file-per-instance journals
    - Read all `metadata/_journals/*.journal` files
    - Group entries by cache_key
    - Process each cache_key with proper locking
    - Truncate processed journal files via cleanup_instance_journals()
    - _Requirements: 4.5_
  - [x] 4.4 Write property test for consolidation ordering
    - **Property 6: Timestamp Ordering During Consolidation**
    - Generate out-of-order entries
    - Verify applied in timestamp order
    - _Requirements: 4.4_
  - [x] 4.5 Write property test for consolidation completeness
    - **Property 5: Consolidation Applies All Entry Types**
    - Generate entries of all types
    - Verify each type applied correctly
    - _Requirements: 1.5, 4.2, 4.3_

- [x] 5. Checkpoint - Ensure all tests pass
  - All 515 library tests pass
  - All integration tests pass
  - Property tests for journal routing, consolidation ordering, and completeness pass

- [x] 6. Modify DiskCacheManager to use journal for cache-hit updates
  - [x] 6.1 Update refresh_range_ttl to use CacheHitUpdateBuffer
    - In shared storage mode: buffer TTL refresh (no direct write)
    - In single instance mode: direct write (existing behavior)
    - _Requirements: 5.1, 5.4, 5.5_
  - [x] 6.2 Integrate CacheHitUpdateBuffer with DiskCacheManager
    - Add cache_hit_update_buffer field
    - Initialize in constructor when shared_storage enabled
    - Wire up in cache.rs during shared storage initialization
    - _Requirements: 5.3, 5.4_
  - [x] 6.3 Write property test for mode-dependent behavior
    - **Property 10: Single-Instance Direct Write Optimization**
    - Verify journal used in shared storage mode
    - Verify direct write in single instance mode
    - _Requirements: 5.4, 5.5_

- [x] 7. Remove legacy direct-write code paths
  - [x] 7.1 Remove direct metadata writes from cache-hit paths
    - refresh_range_ttl now routes to CacheHitUpdateBuffer in shared storage mode
    - Direct write only used in single instance mode (correct behavior)
    - _Requirements: 5.3, 6.3_
  - [x] 7.2 Clean up old per-object journal code
    - Updated JournalManager.get_all_entries_for_cache_key() to read from both:
      - Per-object journals (for Add/Update/Remove from HybridMetadataWriter)
      - Per-instance journals (for TtlRefresh/AccessUpdate from CacheHitUpdateBuffer)
    - Both journal patterns are needed and work together
    - _Requirements: 6.3_

- [x] 8. Wire up background tasks
  - [x] 8.1 Add periodic flush task for CacheHitUpdateBuffer
    - Spawn background task that calls flush() every 5 seconds
    - Added to main.rs alongside journal consolidation task
    - _Requirements: 1.1, 1.2, 1.3_
  - [x] 8.2 Update consolidation task to use new journal format
    - JournalManager.get_all_entries_for_cache_key() now reads from both journal types
    - Consolidation task already uses full-duration locking with retry
    - _Requirements: 4.1, 4.5_

- [x] 9. Checkpoint - Ensure all tests pass
  - All 516 library tests pass
  - All integration tests pass
  - All doc tests pass

- [x] 10. Integration testing
  - [x] 10.1 Write integration test for multi-instance contention
    - Spawn multiple tasks doing concurrent TTL refreshes
    - Verify no corruption
    - Verify all updates eventually applied
    - _Requirements: 2.1, 2.2, 3.1_
  - [x] 10.2 Write integration test for consolidation cleanup
    - **Property 7: Consolidation Cleanup Behavior**
    - Verify journal entries deleted on success
    - Verify journal entries remain on failure
    - _Requirements: 4.5, 4.6_
  - [x] 10.3 Fixed bug in resolve_conflicts that was overwriting ranges for TtlRefresh/AccessUpdate
    - TtlRefresh and AccessUpdate operations now skip conflict resolution
    - These operations are incremental updates, not full range replacements

- [x] 11. Final checkpoint - Ensure all tests pass
  - All 516 library tests pass
  - All 5 journal-based-metadata-updates integration tests pass
  - All doc tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 12. Version increment and documentation
  - [x] 12.1 Increment version to 0.7.0
    - Updated version in `Cargo.toml`
    - Updated CHANGELOG.md with new version and changes
  - [x] 12.2 Update CACHING.md documentation
    - Added "Journal-Based Metadata Updates (Shared Storage)" section
    - Documented RAM buffering strategy
    - Documented shared storage vs single instance behavior
    - Documented journal file format and consolidation process
  - [x] 12.3 Review and update all documentation in docs/
    - CACHING.md updated with comprehensive journal documentation
    - Table of contents updated with new section

- [x] 13. Consolidate and tidy tests and repo
  - [x] 13.1 Review and consolidate test files
    - All tests organized by module/feature
    - No duplicate or overlapping tests found
  - [x] 13.2 Clean up archived/old-or-reference directories
    - Reviewed - no changes needed
  - [x] 13.3 Remove any dead code or unused files
    - Removed unused `extract_object_key_from_journal_filename` and `url_decode` functions
    - Removed associated test for removed functions
    - Build now produces no warnings

- [x] 14. Final validation checkpoint
  - All 515 library tests pass
  - All 5 journal-based-metadata-updates integration tests pass
  - All 11 doc tests pass (3 ignored)
  - Build produces no warnings
  - Version updated to 0.7.0
  - CHANGELOG.md updated
  - CACHING.md documentation updated

## Notes

- All tasks are required for comprehensive testing
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
