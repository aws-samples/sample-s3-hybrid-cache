# Requirements Document

## Introduction

This specification addresses race conditions in metadata file updates when multiple proxy instances share storage (e.g., EFS, NFS, or any shared filesystem). The current implementation has multiple code paths that write to `.meta` files with inconsistent locking and atomic write patterns, causing corruption and failures on shared storage.

The solution routes all cache-hit metadata updates through the existing journal system, uses full-duration locking for direct writes, and implements backoff/retry for lock contention.

## Glossary

- **Metadata_File**: JSON file (`.meta`) containing object metadata and cached range information
- **Journal**: Per-instance append-only log file for metadata updates, consolidated periodically
- **Cache_Hit_Update**: Any metadata modification triggered by serving cached data (TTL refresh, access tracking)
- **Cache_Miss_Write**: Metadata creation/update when caching new data from S3
- **Lock_Manager**: Component that acquires/releases exclusive locks on metadata files
- **Consolidator**: Background process that applies journal entries to metadata files

## Requirements

### Requirement 1: Journal-Based Cache Hit Updates

**User Story:** As a system operator, I want all cache-hit metadata updates to go through the journal, so that multiple instances don't contend on the same metadata file during normal cache serving.

#### Acceptance Criteria

1. WHEN a cache hit triggers a TTL refresh, THE System SHALL write the update to the instance's journal instead of directly to the metadata file
2. WHEN a cache hit triggers an access count update, THE System SHALL write the update to the instance's journal instead of directly to the metadata file
3. WHEN a cache hit triggers a last_accessed timestamp update, THE System SHALL write the update to the instance's journal instead of directly to the metadata file
4. THE Journal SHALL support TTL_REFRESH operation type in addition to existing ADD/UPDATE/REMOVE operations
5. WHEN journal entries are consolidated, THE Consolidator SHALL apply TTL refresh operations to the metadata file

### Requirement 2: Full-Duration Locking for Direct Writes

**User Story:** As a system operator, I want metadata file writes to hold the lock for the entire read-modify-write cycle, so that concurrent writes don't corrupt the file.

#### Acceptance Criteria

1. WHEN writing to a metadata file directly, THE System SHALL acquire an exclusive lock before reading the file
2. WHILE holding the lock, THE System SHALL read, modify, and write the metadata file
3. WHEN the write completes, THE System SHALL release the lock
4. THE System SHALL NOT use temporary files with rename for metadata writes when a lock is held for the full duration
5. IF a write fails while holding the lock, THE System SHALL release the lock and return an error without corrupting the file

### Requirement 3: Lock Contention Handling with Backoff and Retry

**User Story:** As a system operator, I want instances to retry when they can't acquire a metadata lock, so that transient contention doesn't cause failures.

#### Acceptance Criteria

1. WHEN an instance cannot acquire a metadata lock, THE System SHALL wait and retry instead of failing immediately
2. THE System SHALL use exponential backoff between retry attempts
3. THE System SHALL retry up to a configurable maximum number of attempts (default: 5)
4. THE System SHALL use a configurable initial backoff duration (default: 50ms)
5. THE System SHALL use a configurable maximum backoff duration (default: 2 seconds)
6. IF all retry attempts fail, THE System SHALL log a warning and return an error
7. THE System SHALL add jitter to backoff durations to prevent thundering herd

### Requirement 4: Consolidation Improvements

**User Story:** As a system operator, I want the consolidation process to handle TTL refresh entries and use proper locking, so that journal entries are reliably applied to metadata files.

#### Acceptance Criteria

1. WHEN consolidating journal entries, THE Consolidator SHALL acquire an exclusive lock on the metadata file for the full duration
2. WHEN consolidating TTL_REFRESH entries, THE Consolidator SHALL update the expires_at field for the specified range
3. WHEN consolidating ACCESS entries, THE Consolidator SHALL update access_count and last_accessed fields
4. WHEN multiple journal entries exist for the same range, THE Consolidator SHALL apply them in timestamp order
5. WHEN consolidation completes successfully, THE Consolidator SHALL delete the processed journal entries
6. IF consolidation fails, THE Consolidator SHALL leave journal entries intact for retry

### Requirement 5: Remove Direct Metadata Writes from Cache Hit Paths

**User Story:** As a developer, I want a single code path for cache-hit metadata updates, so that the codebase is simpler and race conditions are eliminated.

#### Acceptance Criteria

1. THE refresh_range_ttl function SHALL write to the journal instead of directly to the metadata file
2. THE update_range_access function SHALL write to the journal instead of directly to the metadata file (already done via AccessTracker)
3. THE System SHALL NOT have any direct metadata file writes in cache-hit code paths
4. WHEN shared_storage mode is enabled, THE System SHALL route all cache-hit updates through the journal
5. WHEN shared_storage mode is disabled (single instance), THE System MAY use direct writes for performance

### Requirement 6: Clean Implementation

**User Story:** As a developer, I want a clean implementation without legacy compatibility code, so that the codebase is simpler and easier to maintain.

#### Acceptance Criteria

1. THE System SHALL NOT include backward compatibility code for old metadata formats
2. THE System SHALL assume caches are wiped on upgrade
3. THE System SHALL remove any legacy direct-write code paths from cache-hit operations
