# Design Document: Journal-Based Metadata Updates

## Overview

This design addresses race conditions in metadata file updates when multiple proxy instances share storage (e.g., EFS, NFS, or any shared filesystem). The current implementation has multiple code paths that write directly to `.meta` files during cache hits, causing corruption and failures on shared storage.

The solution:
1. Routes all cache-hit metadata updates through the existing journal system
2. Uses full-duration locking for direct metadata writes (no tmp+rename pattern)
3. Implements exponential backoff with retry for lock contention

## Architecture

### Current State (Problem)

```
┌─────────────────────────────────────────────────────────────────────┐
│                     Cache Hit Code Paths                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  refresh_range_ttl()  ──────────────────────┐                       │
│                                             │                       │
│  update_range_access() ─────────────────────┼──► Direct .meta write │
│  (via AccessTracker consolidation)          │    (race condition!)  │
│                                             │                       │
│  HybridMetadataWriter.write_metadata() ─────┘                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

Multiple instances writing to the same `.meta` file on shared storage causes:
- "Stale file handle" errors
- "EOF while parsing" (corrupted JSON)
- "Failed to rename metadata file: No such file or directory"

### Target State (Solution)

```
┌─────────────────────────────────────────────────────────────────────┐
│                     Cache Hit Code Paths                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  refresh_range_ttl()  ──────────────────────┐                       │
│                                             │                       │
│  update_range_access() ─────────────────────┼──► RAM Buffer         │
│  (via AccessTracker)                        │    (per-instance)     │
│                                             │                       │
│  update_last_accessed() ────────────────────┘                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                ▼ (periodic flush, every 5s)
┌─────────────────────────────────────────────────────────────────────┐
│                     Per-Instance Journal File                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  metadata/_journals/{instance_id}.journal                           │
│                                                                     │
│  - Single append-only log file per instance                         │
│  - Contains entries for all objects                                 │
│  - No cross-instance contention                                     │
│  - Batched writes reduce I/O                                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                ▼ (periodic consolidation, every 30s)
┌─────────────────────────────────────────────────────────────────────┐
│                     Journal Consolidation                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  For each unique cache_key in journal:                              │
│  1. Acquire exclusive lock on .meta file (with backoff/retry)       │
│  2. Read current metadata                                           │
│  3. Apply all journal entries for this object                       │
│  4. Write metadata (in-place, lock held)                            │
│  5. Release lock                                                    │
│  6. Mark entries as processed                                       │
│                                                                     │
│  After all objects processed:                                       │
│  7. Truncate/delete the journal file                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Journal File Strategy

**Single journal file per instance** (simplified from per-object journals):

```
metadata/_journals/
├── instance-a.journal    # All entries from instance A
└── instance-b.journal    # All entries from instance B
```

No lock needed in `_journals/` directory because:
- Each instance writes only to its own journal file
- Consolidation reads from all journal files (read-only, no contention)
- After consolidation, each instance truncates only its own journal

Benefits over per-object journals:
- **Simpler** - One file to manage per instance
- **Fewer files** - Reduces filesystem overhead on shared storage
- **Atomic flush** - All buffered entries written in single operation
- **Easier cleanup** - Truncate one file after consolidation

Journal entry format (one JSON line per entry):
```json
{"timestamp":"2026-01-03T12:00:00Z","cache_key":"bucket/object","range_start":0,"range_end":8388607,"operation":"TtlRefresh","new_ttl_secs":3600}
```

### RAM Buffering Strategy

Following the pattern established by `AccessTracker`, all cache-hit metadata updates are:

1. **Buffered in RAM** - Updates are collected in an in-memory buffer
2. **Flushed periodically** - Every 5 seconds (configurable) or when buffer reaches 10,000 entries
3. **Written to per-instance journal** - Each instance writes to its own journal file (no contention)
4. **Consolidated periodically** - Every 30 seconds, journal entries are applied to metadata files

This approach:
- Reduces disk I/O by ~99% (batching hundreds of updates into single writes)
- Eliminates cross-instance contention on journal writes
- Maintains durability through periodic flushes
- Allows graceful degradation (buffer can grow if flush fails)

### Behavior by Mode

#### Shared Storage Mode (enabled)

When `shared_storage: true` in config (multiple instances sharing cache):

```
Cache Hit → RAM Buffer → Journal File → Consolidation → Metadata File
                         (per-instance)  (with locking)
```

- All cache-hit updates go through journal
- Full-duration locking during consolidation
- Exponential backoff on lock contention
- No direct metadata writes from cache-hit paths

#### Single Instance Mode (disabled)

When `shared_storage: false` in config (single instance, no sharing):

```
Cache Hit → RAM Buffer → Direct Metadata Write
                         (no locking needed)
```

- Cache-hit updates still buffered in RAM (for I/O efficiency)
- Direct metadata writes (no journal overhead)
- No locking required (single writer)
- Better performance for single-instance deployments

The RAM buffering is used in both modes for I/O efficiency, but the journal and locking are only used in shared storage mode.

## Components and Interfaces

### 1. CacheHitUpdateBuffer (New Component)

RAM buffer for cache-hit metadata updates, following the AccessTracker pattern:

```rust
/// Buffered cache-hit update entry
#[derive(Debug, Clone)]
pub struct BufferedCacheHitUpdate {
    pub cache_key: String,
    pub range_start: u64,
    pub range_end: u64,
    pub update_type: CacheHitUpdateType,
    pub timestamp: SystemTime,
}

#[derive(Debug, Clone)]
pub enum CacheHitUpdateType {
    TtlRefresh { new_ttl: Duration },
    AccessUpdate { increment: u64 },
}

/// RAM buffer for cache-hit updates with periodic flush to journal
pub struct CacheHitUpdateBuffer {
    cache_dir: PathBuf,
    instance_id: String,
    /// RAM buffer for updates
    buffer: Arc<Mutex<Vec<BufferedCacheHitUpdate>>>,
    /// Last flush time
    last_flush: Arc<RwLock<Instant>>,
    /// Flush interval (default: 5 seconds)
    flush_interval: Duration,
    /// Maximum buffer size before forced flush
    max_buffer_size: usize,
    /// Journal manager for writing entries
    journal_manager: Arc<JournalManager>,
}

impl CacheHitUpdateBuffer {
    /// Record a TTL refresh (buffered in RAM)
    pub async fn record_ttl_refresh(
        &self,
        cache_key: &str,
        range_start: u64,
        range_end: u64,
        new_ttl: Duration,
    ) -> Result<()> {
        let entry = BufferedCacheHitUpdate {
            cache_key: cache_key.to_string(),
            range_start,
            range_end,
            update_type: CacheHitUpdateType::TtlRefresh { new_ttl },
            timestamp: SystemTime::now(),
        };
        
        self.add_to_buffer(entry).await?;
        self.maybe_flush().await
    }
    
    /// Flush buffer to journal files
    pub async fn flush(&self) -> Result<FlushResult> {
        let entries = {
            let mut buffer = self.buffer.lock().await;
            std::mem::take(&mut *buffer)
        };
        
        if entries.is_empty() {
            return Ok(FlushResult::default());
        }
        
        // Convert buffered entries to journal entries and write
        for entry in &entries {
            let journal_entry = self.to_journal_entry(entry);
            self.journal_manager
                .append_range_entry(&entry.cache_key, journal_entry)
                .await?;
        }
        
        Ok(FlushResult {
            entries_flushed: entries.len() as u64,
            ..Default::default()
        })
    }
}
```

### 2. Extended JournalOperation Enum

Add new operation types for cache-hit updates:

```rust
/// Types of journal operations
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum JournalOperation {
    Add,           // Existing: add new range
    Update,        // Existing: update range data
    Remove,        // Existing: remove range
    TtlRefresh,    // NEW: refresh TTL for a range
    AccessUpdate,  // NEW: update access count and last_accessed
}
```

### 3. Extended JournalEntry Structure

Add fields for TTL refresh and access updates:

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct JournalEntry {
    pub timestamp: SystemTime,
    pub instance_id: String,
    pub cache_key: String,
    pub range_spec: RangeSpec,
    pub operation: JournalOperation,
    pub range_file_path: String,
    pub metadata_version: u64,
    // NEW fields for cache-hit operations
    pub new_ttl: Option<Duration>,           // For TtlRefresh
    pub access_increment: Option<u64>,       // For AccessUpdate
}
```

### 4. LockWithRetry Trait

New trait for lock acquisition with exponential backoff:

```rust
pub struct LockConfig {
    pub max_retries: u32,           // Default: 5
    pub initial_backoff: Duration,  // Default: 50ms
    pub max_backoff: Duration,      // Default: 2s
    pub jitter_factor: f64,         // Default: 0.25 (±25%)
}

impl Default for LockConfig {
    fn default() -> Self {
        Self {
            max_retries: 5,
            initial_backoff: Duration::from_millis(50),
            max_backoff: Duration::from_secs(2),
            jitter_factor: 0.25,
        }
    }
}

/// Acquire lock with exponential backoff and jitter
pub async fn acquire_lock_with_retry(
    lock_path: &Path,
    config: &LockConfig,
) -> Result<File> {
    let mut attempt = 0;
    let mut backoff = config.initial_backoff;
    
    loop {
        match try_acquire_exclusive_lock(lock_path) {
            Ok(file) => return Ok(file),
            Err(_) if attempt < config.max_retries => {
                attempt += 1;
                let jitter = calculate_jitter(backoff, config.jitter_factor);
                tokio::time::sleep(backoff + jitter).await;
                backoff = std::cmp::min(backoff * 2, config.max_backoff);
            }
            Err(e) => {
                warn!(
                    "Failed to acquire lock after {} attempts: path={:?}, error={}",
                    attempt, lock_path, e
                );
                return Err(ProxyError::LockContention(format!(
                    "Lock acquisition failed after {} retries", attempt
                )));
            }
        }
    }
}
```

### 5. Modified DiskCacheManager Methods

#### refresh_range_ttl (Journal-Based)

```rust
/// Refresh range TTL via journal (no direct metadata write)
pub async fn refresh_range_ttl(
    &mut self,
    cache_key: &str,
    range_start: u64,
    range_end: u64,
    new_ttl: Duration,
) -> Result<()> {
    // In shared storage mode, write to journal
    if self.is_shared_storage_mode() {
        let entry = JournalEntry {
            timestamp: SystemTime::now(),
            instance_id: self.get_instance_id(),
            cache_key: cache_key.to_string(),
            range_spec: RangeSpec::placeholder(range_start, range_end),
            operation: JournalOperation::TtlRefresh,
            range_file_path: String::new(),
            metadata_version: 0,
            new_ttl: Some(new_ttl),
            access_increment: None,
        };
        
        return self.journal_manager
            .append_range_entry(cache_key, entry)
            .await;
    }
    
    // Single instance mode: direct write (existing behavior)
    self.refresh_range_ttl_direct(cache_key, range_start, range_end, new_ttl).await
}
```

### 6. Enhanced JournalConsolidator

#### Apply TTL Refresh Entries

```rust
fn apply_journal_entries(
    &self,
    metadata: &mut NewCacheMetadata,
    entries: &[JournalEntry],
) -> usize {
    let mut entries_applied = 0;

    for entry in entries {
        match entry.operation {
            JournalOperation::Add => { /* existing */ }
            JournalOperation::Update => { /* existing */ }
            JournalOperation::Remove => { /* existing */ }
            
            JournalOperation::TtlRefresh => {
                if let Some(new_ttl) = entry.new_ttl {
                    if let Some(range) = metadata.ranges.iter_mut().find(|r| {
                        r.start == entry.range_spec.start && r.end == entry.range_spec.end
                    }) {
                        range.refresh_ttl(new_ttl);
                        entries_applied += 1;
                    }
                }
            }
            
            JournalOperation::AccessUpdate => {
                if let Some(increment) = entry.access_increment {
                    if let Some(range) = metadata.ranges.iter_mut().find(|r| {
                        r.start == entry.range_spec.start && r.end == entry.range_spec.end
                    }) {
                        range.access_count += increment;
                        range.last_accessed = entry.timestamp;
                        entries_applied += 1;
                    }
                }
            }
        }
    }

    entries_applied
}
```

#### Full-Duration Locking for Consolidation

```rust
pub async fn consolidate_object(&self, cache_key: &str) -> Result<ConsolidationResult> {
    // Get all journal entries
    let all_entries = self.journal_manager
        .get_all_entries_for_cache_key(cache_key)
        .await?;

    if all_entries.is_empty() {
        return Ok(ConsolidationResult::success(cache_key.to_string(), 0, 0));
    }

    // Acquire lock with retry (full duration)
    let metadata_path = self.get_metadata_file_path(cache_key);
    let lock_path = metadata_path.with_extension("meta.lock");
    let lock_file = acquire_lock_with_retry(&lock_path, &self.lock_config).await?;

    // Read metadata (lock held)
    let mut metadata = self.load_or_create_metadata(cache_key).await?;

    // Apply all journal entries (lock held)
    let entries_consolidated = self.apply_journal_entries(&mut metadata, &all_entries);

    // Write metadata directly (no tmp file, lock held)
    let json = serde_json::to_string_pretty(&metadata)?;
    std::fs::write(&metadata_path, json)?;

    // Release lock
    drop(lock_file);

    // Clean up processed journal entries
    self.cleanup_processed_entries(cache_key, &all_entries).await?;

    Ok(ConsolidationResult::success(
        cache_key.to_string(),
        all_entries.len(),
        entries_consolidated,
    ))
}
```

## Data Models

### Journal Entry (Extended)

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct JournalEntry {
    /// When this entry was created
    pub timestamp: SystemTime,
    /// Instance that created this entry (hostname:pid)
    pub instance_id: String,
    /// Cache key (bucket/object)
    pub cache_key: String,
    /// Range specification (start/end for identification)
    pub range_spec: RangeSpec,
    /// Type of operation
    pub operation: JournalOperation,
    /// Path to range binary file (for Add/Update)
    pub range_file_path: String,
    /// Metadata version for conflict resolution
    pub metadata_version: u64,
    /// New TTL duration (for TtlRefresh operation)
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub new_ttl: Option<Duration>,
    /// Access count increment (for AccessUpdate operation)
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub access_increment: Option<u64>,
}
```

### Lock Configuration

```rust
#[derive(Debug, Clone)]
pub struct LockConfig {
    /// Maximum number of retry attempts
    pub max_retries: u32,
    /// Initial backoff duration
    pub initial_backoff: Duration,
    /// Maximum backoff duration
    pub max_backoff: Duration,
    /// Jitter factor (0.0 to 1.0)
    pub jitter_factor: f64,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*



### Property 1: Journal Routing for Cache-Hit Updates

*For any* cache-hit operation (TTL refresh, access count update, last_accessed update) in shared storage mode, the system shall create a journal entry rather than writing directly to the metadata file.

**Validates: Requirements 1.1, 1.2, 1.3, 5.1, 5.2, 5.3, 5.4**

### Property 2: Full-Duration Locking Invariant

*For any* direct metadata write operation, the exclusive lock shall be held from before the read operation until after the write operation completes. The lock shall never be released during the read-modify-write cycle.

**Validates: Requirements 2.1, 2.2, 2.3, 4.1**

### Property 3: Exponential Backoff with Jitter

*For any* lock acquisition attempt that fails, the retry delay shall be:
- At least `initial_backoff * 2^(attempt-1)` (exponential growth)
- At most `max_backoff` (capped)
- Include jitter within ±`jitter_factor` of the base delay
- Stop after `max_retries` attempts

**Validates: Requirements 3.1, 3.2, 3.3, 3.5, 3.7**

### Property 4: Journal Entry Serialization Round-Trip

*For any* valid JournalEntry (including new TtlRefresh and AccessUpdate operations), serializing to JSON and deserializing back shall produce an equivalent entry.

**Validates: Requirements 1.4, 6.1**

### Property 5: Consolidation Applies All Entry Types

*For any* set of journal entries (Add, Update, Remove, TtlRefresh, AccessUpdate), consolidation shall correctly apply each entry type:
- TtlRefresh: updates `expires_at` field for the specified range
- AccessUpdate: increments `access_count` and updates `last_accessed`
- Add/Update/Remove: existing behavior preserved

**Validates: Requirements 1.5, 4.2, 4.3**

### Property 6: Timestamp Ordering During Consolidation

*For any* set of journal entries for the same range, consolidation shall apply them in timestamp order (oldest first), ensuring the final state reflects the most recent operation.

**Validates: Requirements 4.4**

### Property 7: Consolidation Cleanup Behavior

*For any* consolidation operation:
- On success: all processed journal entries shall be deleted
- On failure: all journal entries shall remain intact for retry

**Validates: Requirements 4.5, 4.6**

### Property 8: In-Place Write with Error Recovery

*For any* metadata write with full-duration locking:
- No temporary files shall be created (no `.tmp` files)
- On write failure: the lock shall be released and the original file shall remain uncorrupted

**Validates: Requirements 2.4, 2.5**

### Property 9: Graceful Handling of Edge Cases

*For any* consolidation operation, journal entries referencing non-existent ranges (e.g., range was evicted) shall be handled gracefully (logged and skipped, not causing errors).

**Validates: Requirements 4.6**

### Property 10: Single-Instance Direct Write Optimization

*For any* cache-hit operation when shared_storage mode is disabled, the system may use direct metadata writes for performance (bypassing the journal).

**Validates: Requirements 5.5**

## Error Handling

### Lock Acquisition Failures

1. **Transient contention**: Retry with exponential backoff
2. **Persistent contention**: After max_retries, log warning and return `LockContention` error
3. **Stale locks**: Detect locks older than 60 seconds and break them (existing behavior)

### Journal Write Failures

1. **Directory creation failure**: Return error, operation fails
2. **File write failure**: Return error, no partial state
3. **Serialization failure**: Return error before any I/O

### Consolidation Failures

1. **Lock acquisition failure**: Skip this cache key, retry next cycle
2. **Metadata read failure**: Log warning, leave journal entries for retry
3. **Metadata write failure**: Log error, leave journal entries for retry
4. **Journal cleanup failure**: Log warning (non-fatal), entries may be reprocessed

### Backward Compatibility

**Not required.** Caches will be wiped on upgrade. This allows us to:
- Remove legacy code paths
- Simplify the implementation
- Not worry about old metadata formats

## Testing Strategy

### Unit Tests

- JournalOperation enum serialization/deserialization
- LockConfig default values
- Backoff calculation with jitter
- Journal entry creation for TTL refresh and access updates

### Property-Based Tests

Using `quickcheck` for property-based testing:

1. **Journal Entry Round-Trip** (Property 4)
   - Generate random JournalEntry instances
   - Serialize to JSON, deserialize back
   - Verify equality

2. **Exponential Backoff** (Property 3)
   - Generate random attempt counts and configs
   - Verify backoff grows exponentially
   - Verify cap is respected
   - Verify jitter is within bounds

3. **Consolidation Ordering** (Property 6)
   - Generate random journal entries with various timestamps
   - Verify entries are applied in timestamp order

4. **Consolidation Completeness** (Property 5)
   - Generate random metadata and journal entries
   - Verify all entry types are applied correctly

### Integration Tests

1. **Multi-instance contention simulation**
   - Spawn multiple tasks attempting concurrent TTL refreshes
   - Verify no corruption occurs
   - Verify all updates are eventually applied

2. **Shared storage mode toggle**
   - Verify journal routing when enabled
   - Verify direct writes when disabled

3. **Failure recovery**
   - Simulate write failures during consolidation
   - Verify journal entries remain for retry

### Test Configuration

- Property tests: minimum 100 iterations
- Integration tests: use tempfile for isolated cache directories
- Contention tests: 10+ concurrent tasks
