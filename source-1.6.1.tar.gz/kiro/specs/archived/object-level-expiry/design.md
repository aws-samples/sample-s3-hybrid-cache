# Design Document: Object-Level Expiry

## Overview

This design refactors cache expiration from per-range TTL tracking to object-level TTL tracking and fixes unsafe error handling in expiration checks. The core insight: expiration is about whether the S3 object changed, not whether individual byte ranges changed. All ranges of the same object share the same freshness state.

Two changes:
1. Move `expires_at` from `RangeSpec` to `NewCacheMetadata` as the authoritative expiry field, update all read/write paths accordingly.
2. Change `check_range_expiration` (and its call sites) so that metadata read failures are treated as "expired" rather than silently serving from cache.

The `NewCacheMetadata` struct already has an `expires_at` field, but it's currently set to a ~100-year sentinel value and ignored. The per-range `expires_at` on `RangeSpec` is the actual source of truth today. This refactor makes the object-level `expires_at` the real TTL and removes the per-range `expires_at` field entirely, along with `is_expired()`, `refresh_ttl()` on `RangeSpec`, and the legacy detection logic.

## Architecture

### Current Flow

```
Client Request → http_proxy.rs
  → find_cached_ranges() → overlap result
  → check_range_expiration(cache_key, range_start, range_end)
    → load metadata → find specific range → range.is_expired()
    → if expired: return Some(last_modified)
    → if not expired: return None
    → if Err: silently treated as "not expired" by if-let-Ok pattern
  → if expired: conditional validation (If-Modified-Since → S3)
    → 304: refresh_range_ttl(cache_key, range_start, range_end, ttl)
    → 200: invalidate + re-fetch
  → if not expired: serve from cache
```

### New Flow

```
Client Request → http_proxy.rs
  → find_cached_ranges() → overlap result
  → check_object_expiration(cache_key)
    → load metadata → metadata.expires_at < now
    → if expired: return Ok(Expired { last_modified })
    → if not expired: return Ok(Fresh)
    → if Err: return Ok(Expired { last_modified: None })  ← fail-safe
  → if expired: conditional validation (If-Modified-Since → S3)
    → 304: refresh_object_ttl(cache_key, ttl)
    → 200: invalidate + re-fetch
  → if not expired: serve from cache
```

### Key Architectural Decisions

1. The object-level `expires_at` on `NewCacheMetadata` becomes the authoritative TTL field.
2. `RangeSpec.expires_at` is removed entirely from the struct. The `is_expired()` and `refresh_ttl()` methods are also removed.
3. The `is_legacy_expiry()` method on `NewCacheMetadata` is removed — no legacy fallback logic.
4. Metadata read failures during expiration checks are treated as expired (fail-safe).
5. The `check_range_expiration` function is replaced by `check_object_expiration` which takes only a cache key.
6. TTL refresh after 304 updates `NewCacheMetadata.expires_at` instead of a specific range's `expires_at`.

## Components and Interfaces

### Modified: `NewCacheMetadata` (cache_types.rs)

New methods:
- `is_object_expired(&self) -> bool` — checks if `expires_at < now`.
- `refresh_object_ttl(&mut self, ttl: Duration)` — sets `expires_at = now + ttl`.

### Modified: `RangeSpec` (cache_types.rs)

- `new()` constructor: no longer takes a `ttl` parameter. The `expires_at` field is removed from the struct entirely.
- `is_expired()`: removed.
- `refresh_ttl()`: removed.

### Modified: `DiskCacheManager` (disk_cache.rs)

Replaced functions:
- `check_range_expiration(cache_key, range_start, range_end) -> Result<Option<String>>` → `check_object_expiration(cache_key) -> Result<ObjectExpirationResult>`
- `refresh_range_ttl(cache_key, range_start, range_end, ttl)` → `refresh_object_ttl(cache_key, ttl)`
- `refresh_range_ttl_direct(...)` → `refresh_object_ttl_direct(cache_key, ttl)`

### Modified: `CacheHitUpdateBuffer` (cache_hit_update_buffer.rs)

- `record_ttl_refresh()` signature changes: removes `range_start` and `range_end` parameters since TTL refresh is now object-level.
- `BufferedCacheHitUpdate` struct: `range_start` and `range_end` become optional (set to 0 for object-level TTL refresh).
- `CacheHitUpdateType::TtlRefresh` remains unchanged (still carries `new_ttl_secs`).

### Modified: `JournalConsolidator` (journal_consolidator.rs)

- `TtlRefresh` application logic: instead of finding a specific range and calling `range.refresh_ttl()`, it calls `metadata.refresh_object_ttl()` to set `metadata.expires_at = now + ttl`.

### Modified: `http_proxy.rs`

Both the range request path (~line 2844) and full-object GET path (~line 1510):
- Replace `check_range_expiration(cache_key, range.start, range.end)` with `check_object_expiration(cache_key)`
- Replace `if let Ok(Some(last_modified))` pattern with explicit match on `ObjectExpirationResult`
- On `Expired { last_modified: Some(lm) }`: proceed with conditional validation using `lm`
- On `Expired { last_modified: None }`: forward request unconditionally to S3 (no If-Modified-Since)
- Replace `refresh_range_ttl(...)` calls with `refresh_object_ttl(cache_key, ttl)`

### Modified: `store_range` / `store_full_object_as_range` (disk_cache.rs)

- When creating new `NewCacheMetadata`: set `expires_at = now + ttl`.
- When adding a range to existing metadata: update `expires_at = now + ttl` (refresh object expiry on every cache write).
- `RangeSpec::new()` no longer takes a `ttl` parameter and no longer has an `expires_at` field.

## Data Models

### NewCacheMetadata (updated)

```rust
pub struct NewCacheMetadata {
    pub cache_key: String,
    pub object_metadata: ObjectMetadata,
    pub ranges: Vec<RangeSpec>,
    pub created_at: SystemTime,
    pub expires_at: SystemTime,           // NOW the authoritative object-level TTL
    pub compression_info: CompressionInfo,
    #[serde(default)]
    pub head_expires_at: Option<SystemTime>,
    #[serde(default)]
    pub head_last_accessed: Option<SystemTime>,
    #[serde(default)]
    pub head_access_count: u64,
}
```

No structural change to the struct — the field already exists. The semantic change is that `expires_at` is now set to `now + resolved_get_ttl` instead of `now + ~100 years`.

### RangeSpec (updated)

```rust
pub struct RangeSpec {
    pub start: u64,
    pub end: u64,
    pub file_path: String,
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
    pub created_at: SystemTime,
    pub last_accessed: SystemTime,
    pub access_count: u64,
    #[serde(default)]
    pub frequency_score: u64,
}
```

The `expires_at` field is removed entirely. Old metadata files that contain `expires_at` in range entries will still deserialize correctly via `#[serde(default)]` or by ignoring unknown fields — but the field is no longer part of the struct.

### ObjectExpirationResult (new)

```rust
pub enum ObjectExpirationResult {
    Fresh,
    Expired { last_modified: Option<String> },
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Object-level expiration determines freshness

*For any* `NewCacheMetadata`:
- If `expires_at < now`, then `check_object_expiration` returns `Expired { last_modified: Some(object_metadata.last_modified) }`
- If `expires_at > now`, then `check_object_expiration` returns `Fresh`

**Validates: Requirements 1.2, 2.1, 2.2, 2.3**

### Property 2: Object TTL refresh sets expires_at correctly

*For any* TTL duration (including zero), calling `refresh_object_ttl(ttl)` on a `NewCacheMetadata` sets `expires_at` to approximately `now + ttl` (within a 1-second tolerance window).

**Validates: Requirements 1.3, 3.1**

### Property 3: Cache writes set object-level expires_at

*For any* `get_ttl` duration and any range parameters, when `store_range` is called, the resulting `NewCacheMetadata.expires_at` equals approximately `now + get_ttl`. This holds for both new metadata creation and adding ranges to existing metadata.

**Validates: Requirements 1.4, 4.1, 4.2, 4.3**

## Error Handling

### Metadata Read Failures

When `check_object_expiration` cannot read or deserialize metadata:
- Return `Expired { last_modified: None }` instead of propagating the error
- Log a warning with cache key and error details
- The call site in `http_proxy.rs` handles `last_modified: None` by forwarding the request to S3 without an `If-Modified-Since` header (unconditional forward)

This is the fail-safe default: if we can't verify freshness, don't serve potentially stale data.

### Metadata File Not Found

When the metadata file doesn't exist (e.g., deleted by eviction between `find_cached_ranges` and `check_object_expiration`):
- Return `Fresh` (no expiration check needed — the cache miss will be handled by the normal flow)
- This matches current behavior where missing metadata returns `Ok(None)`

Actually, on reflection: if metadata is missing but `find_cached_ranges` found ranges, something is inconsistent. Treating as `Expired { last_modified: None }` is safer — forward to S3 and let the response re-populate the cache.

### Lock Contention During TTL Refresh

When `refresh_object_ttl` cannot acquire the metadata lock:
- Skip the refresh (same as current behavior for `refresh_range_ttl`)
- The next request will re-check expiration and retry the refresh
- Log at debug level

## Testing Strategy

### Property-Based Testing

Library: `quickcheck` / `quickcheck_macros` (already used in the project).

Each property test runs a minimum of 100 iterations.

Tests to create/update:

1. **Update `tests/check_range_expiration_property_test.rs`** → rename to `tests/check_object_expiration_property_test.rs`
   - Property 1: Object-level expiration determines freshness
   - Tag: `Feature: object-level-expiry, Property 1: Object-level expiration determines freshness`

2. **Update `tests/cache_write_expires_at_property_test.rs`**
   - Property 3: Cache writes set object-level expires_at
   - Tag: `Feature: object-level-expiry, Property 3: Cache writes set object-level expires_at`

3. **New or update existing test for Property 2** (refresh_object_ttl)
   - Can be added to `tests/head_expiration_property_test.rs` or a new file
   - Tag: `Feature: object-level-expiry, Property 2: Object TTL refresh sets expires_at correctly`

### Unit Tests

- Metadata read failure → `Expired { last_modified: None }` (corrupted file, invalid JSON)
- Metadata deserialization failure → `Expired { last_modified: None }` (valid JSON, wrong schema)
- `RangeSpec::new()` no longer takes TTL, no longer has `expires_at` field
- `ObjectExpirationResult` enum usage in call sites
- Old metadata files with per-range `expires_at` still deserialize (serde ignores unknown fields)

### Existing Tests to Update

- `test_range_spec_new` — update for removed TTL parameter and removed `expires_at` field
- `test_range_spec_is_expired` — remove (method no longer exists)
- `test_range_spec_refresh_ttl` — remove (method no longer exists)
- `test_new_cache_metadata_serialization` — update `expires_at` from sentinel to real TTL
- `test_new_cache_metadata_with_multiple_ranges` — update `expires_at` from sentinel to real TTL
- Property tests in `cache_types.rs` (`prop_write_cache_metadata_round_trip`, etc.) — update to use new `RangeSpec::new()` signature and remove `expires_at` from `RangeSpec`
