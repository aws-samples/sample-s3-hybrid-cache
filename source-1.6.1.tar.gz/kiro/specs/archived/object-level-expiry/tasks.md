# Implementation Plan: Object-Level Expiry

## Overview

Refactor cache expiration from per-range to object-level, fix metadata read failure handling, and update all call sites. Implementation proceeds bottom-up: data model changes first, then cache layer, then proxy layer, with property tests alongside each step.

## Tasks

- [x] 1. Add object-level expiry methods to NewCacheMetadata and ObjectExpirationResult enum
  - [x] 1.1 Add `ObjectExpirationResult` enum to `src/cache_types.rs`
    - Define `Fresh` and `Expired { last_modified: Option<String> }` variants
    - _Requirements: 2.2, 2.3, 6.1, 6.2_
  - [x] 1.2 Add `is_legacy_expiry()` method to `NewCacheMetadata`
    - Returns true if `expires_at` is more than 50 years after `created_at`
    - _Requirements: 5.1_
  - [x] 1.3 Add `is_object_expired()` method to `NewCacheMetadata`
    - If legacy expiry: fall back to first range's `is_expired()`
    - If non-legacy: check `expires_at < now`
    - _Requirements: 1.2, 2.1, 5.1_
  - [x] 1.4 Add `refresh_object_ttl(&mut self, ttl: Duration)` method to `NewCacheMetadata`
    - Sets `expires_at = now + ttl`
    - _Requirements: 1.3, 3.1_
  - [x] 1.5 Update `RangeSpec::new()` to remove the `ttl` parameter
    - Set `expires_at = SystemTime::UNIX_EPOCH` for new ranges
    - Update all callers of `RangeSpec::new()` to remove the TTL argument
    - _Requirements: 1.5_
  - [x] 1.6 Update unit tests in `cache_types.rs` for the new methods and constructor
    - Update `test_range_spec_new`, `test_new_cache_metadata_serialization`, `test_new_cache_metadata_with_multiple_ranges`
    - Add unit tests for `is_legacy_expiry()`, `is_object_expired()`, `refresh_object_ttl()`
    - _Requirements: 1.2, 2.1, 5.1, 5.2_

- [x] 2. Remove per-range expiry from RangeSpec and simplify is_object_expired
  - [x] 2.1 Remove `expires_at` field from `RangeSpec` struct
    - Remove the field from the struct definition
    - Add `#[serde(deny_unknown_fields)]` or rely on serde's default behavior to ignore unknown fields during deserialization of old metadata
    - Update `RangeSpec::new()` to no longer set `expires_at`
    - Update all code that reads `range.expires_at`
    - _Requirements: 5.1_
  - [x] 2.2 Remove `is_expired()` method from `RangeSpec`
    - Remove the method entirely
    - Update any callers
    - _Requirements: 5.2_
  - [x] 2.3 Remove `refresh_ttl()` method from `RangeSpec`
    - Remove the method entirely
    - Update any callers
    - _Requirements: 5.3_
  - [x] 2.4 Remove `is_legacy_expiry()` method from `NewCacheMetadata`
    - Remove the method entirely
    - _Requirements: 5.4_
  - [x] 2.5 Simplify `is_object_expired()` on `NewCacheMetadata`
    - Remove legacy fallback logic — just check `self.expires_at < now`
    - _Requirements: 1.2, 2.1, 5.5_
  - [x] 2.6 Update unit tests for removed methods and simplified logic
    - Remove `test_range_spec_is_expired`, `test_range_spec_refresh_ttl`
    - Remove `is_legacy_expiry` tests
    - Update `is_object_expired` tests to remove legacy fallback cases
    - Update `test_range_spec_new` to verify no `expires_at` field
    - Update property tests in `cache_types.rs` that reference `RangeSpec.expires_at`
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 3. Implement `check_object_expiration` and `refresh_object_ttl` in DiskCacheManager
  - [x] 3.1 Add `check_object_expiration(cache_key) -> Result<ObjectExpirationResult>` to `DiskCacheManager`
    - Load metadata, check `expires_at < now`, return `Expired` or `Fresh`
    - On metadata read/parse error: log warning, return `Expired { last_modified: None }`
    - On metadata not found: return `Expired { last_modified: None }`
    - _Requirements: 1.2, 2.1, 2.2, 2.3, 6.1, 6.2, 6.3_
  - [x] 3.2 Add `refresh_object_ttl(cache_key, ttl)` and `refresh_object_ttl_direct(cache_key, ttl)` to `DiskCacheManager`
    - Load metadata, call `metadata.refresh_object_ttl(ttl)`, write back
    - Follow same locking pattern as existing `refresh_range_ttl_direct`
    - _Requirements: 1.3, 3.1, 3.2_
  - [x] 3.3 Update `store_range` to set object-level `expires_at = now + ttl`
    - When creating new metadata: set `expires_at = now + ttl` (replace ~100-year sentinel)
    - When updating existing metadata: set `expires_at = now + ttl`
    - _Requirements: 1.4, 4.1, 4.2, 4.3_
  - [x] 3.4 Write property test for object-level expiration check (Property 1)
    - **Property 1: Object-level expiration determines freshness**
    - Create `tests/check_object_expiration_property_test.rs`
    - For any metadata: expired → Expired, fresh → Fresh
    - **Validates: Requirements 1.2, 2.1, 2.2, 2.3**
  - [x] 3.5 Write property test for object TTL refresh (Property 2)
    - **Property 2: Object TTL refresh sets expires_at correctly**
    - For any TTL duration, refresh_object_ttl sets expires_at ≈ now + ttl
    - **Validates: Requirements 1.3, 3.1**
  - [x] 3.6 Update property test for cache writes (Property 3)
    - **Property 3: Cache writes set object-level expires_at**
    - Update `tests/cache_write_expires_at_property_test.rs` to verify object-level expires_at
    - **Validates: Requirements 1.4, 4.1, 4.2, 4.3**

- [x] 4. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Update CacheHitUpdateBuffer and JournalConsolidator for object-level TTL
  - [x] 5.1 Update `CacheHitUpdateBuffer::record_ttl_refresh()` to remove range parameters
    - Make `range_start` and `range_end` optional or set to 0 for object-level refresh
    - _Requirements: 3.2_
  - [x] 5.2 Update `JournalConsolidator` TtlRefresh application logic
    - Change from `range.refresh_ttl(ttl)` to `metadata.refresh_object_ttl(ttl)`
    - _Requirements: 1.3, 3.1_

- [x] 6. Update http_proxy.rs call sites
  - [x] 6.1 Update range request path expiration check (~line 2844)
    - Replace `check_range_expiration(cache_key, range.start, range.end)` with `check_object_expiration(cache_key)`
    - Replace `if let Ok(Some(last_modified))` with match on `ObjectExpirationResult`
    - Handle `Expired { last_modified: None }` by forwarding unconditionally to S3
    - Replace `refresh_range_ttl(...)` with `refresh_object_ttl(cache_key, ttl)`
    - _Requirements: 6.1, 6.4, 7.1, 7.3_
  - [x] 6.2 Update full-object GET path expiration check (~line 1510)
    - Same changes as 6.1 for the full-object GET path
    - _Requirements: 6.1, 6.4, 7.2, 7.3_

- [x] 7. Remove deprecated per-range expiration functions
  - [x] 7.1 Remove or deprecate `check_range_expiration`, `refresh_range_ttl`, `refresh_range_ttl_direct` from `DiskCacheManager`
    - Remove the old functions if no other callers remain
    - Update any remaining references
    - _Requirements: 2.4_
  - [x] 7.2 Clean up old property test file
    - Remove `tests/check_range_expiration_property_test.rs` (replaced by `check_object_expiration_property_test.rs`)
    - _Requirements: 2.2, 2.3_
  - [x] 7.3 Write unit tests for metadata read failure handling
    - Test corrupted metadata file → `Expired { last_modified: None }`
    - Test invalid JSON → `Expired { last_modified: None }`
    - **Validates: Requirements 6.1, 6.2**

- [x] 8. Update documentation
  - [x] 8.1 Update `docs/CACHING.md` to describe object-level expiration
    - Update the "Zero TTL Revalidation" section to reflect that expiration is checked at the object level, not per-range
    - Update any references to `check_range_expiration` to describe the new `check_object_expiration` behavior
    - Add note that metadata read failures during expiration checks are treated as expired for safety
    - _Requirements: 7.1, 7.2_

- [x] 9. Version bump
  - [x] 9.1 Update `Cargo.toml` version to `"1.5.2"`
  - [x] 9.2 Add `[1.5.2]` entry to `CHANGELOG.md`
    - Describe: object-level expiration replaces per-range expiration, per-range expires_at removed from RangeSpec, metadata read failures treated as expired (security fix)

- [x] 10. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
  - Run `cargo test` to verify all tests pass
  - Run `cargo build --release` to verify clean compilation

- [x] 11. Fix remaining ~100-year sentinel in metadata creation paths
  - [x] 11.1 Pass TTL through `write_range_metadata` → `load_or_create_metadata` in `hybrid_metadata_writer.rs`
    - Add `ttl: Duration` parameter to `write_range_metadata()`, `write_immediate_only()`, `write_hybrid()`, `write_empty_object_metadata()`, and `load_or_create_metadata()`
    - Set `expires_at = now + ttl` when creating new metadata instead of `now + ~100 years`
    - Fix `write_empty_object_metadata` which hardcodes `expires_at = now + 3600s` — use the TTL parameter instead
    - Update the call site in `disk_cache.rs` `store_range` to pass `ttl`
    - Update the call site in `orphaned_range_recovery.rs` to pass `Duration::ZERO` (safe default — force revalidation since original TTL is unknown)
    - Update stale comments ("Individual ranges have their own TTL")
    - _Requirements: 1.4, 4.1_
  - [x] 11.2 Pass TTL through journal entries to `journal_consolidator.rs` metadata creation
    - Add `object_ttl_secs: Option<u64>` field to `JournalEntry` in `src/journal_manager.rs` (with `#[serde(default)]` for backward compat with existing journal files)
    - Set `object_ttl_secs` when creating `Add` journal entries in `hybrid_metadata_writer.rs` — TTL comes from the new `ttl` parameter on `write_range_metadata`
    - In `journal_consolidator.rs` `load_or_create_metadata_for_consolidation`, use the TTL from the first `Add` journal entry: `expires_at = now + Duration::from_secs(entry.object_ttl_secs.unwrap_or(0))`
    - If no journal entry has `object_ttl_secs` (old journal files), fall back to `Duration::ZERO` (immediately expired, safe default)
    - Update stale comments
    - Also fix the test instances that use the sentinel
    - _Requirements: 1.4, 4.1, 6.1_
  - [x] 11.3 Update `add_or_update_range` comment in `hybrid_metadata_writer.rs`
    - Remove stale comment "Individual ranges have their own TTL"
    - _Requirements: 5.1_

- [x] 12. Clean up dead/misleading code
  - [x] 12.1 Rename `tests/refresh_range_ttl_property_test.rs` → `tests/refresh_object_ttl_property_test.rs`
    - File content already tests `refresh_object_ttl` but filename is misleading
  - [x] 12.2 Remove or update `is_shared_storage_mode()` on `DiskCacheManager`
    - This method returns `self.hybrid_metadata_writer.is_some()` but the hybrid writer is always set
    - Either remove the method or update callers to not branch on it
    - Check if any code paths depend on this returning false
  - [x] 12.3 Update stale comments in `disk_cache.rs` referencing "shared storage mode" vs "single instance mode"
    - The hybrid writer is always enabled — comments suggesting conditional behavior are misleading

- [x] 13. Version bump to 1.5.2 (re-bump after fixes)
  - [x] 13.1 Update `CHANGELOG.md` [1.5.2] entry to include the sentinel fix
  - Note: Cargo.toml already at 1.5.2, just update the changelog description

- [x] 14. Final checkpoint - Ensure all tests pass after fixes
  - Run `cargo test --release` to verify all tests pass
  - Run `cargo build --release` to verify clean compilation

## Notes

- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
- The `RangeSpec.expires_at` field is removed entirely — serde will ignore unknown fields when deserializing old metadata files
- Tasks 1.1–1.6 are already completed; task 2 cleans up the interim state (removes legacy code that 1.2, 1.3, 1.5 introduced)
