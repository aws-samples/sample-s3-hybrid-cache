# Requirements Document

## Introduction

This feature refactors cache expiration from per-range TTL tracking to object-level TTL tracking, and fixes unsafe error handling in expiration checks. Currently each `RangeSpec` has its own `expires_at` field, but expiration is conceptually about the object — either the object changed on S3 or it didn't. One range being "fresh" while another range of the same object is "stale" is semantically incorrect. Additionally, metadata read failures during expiration checks are silently treated as "not expired," which can serve stale or unauthorized data.

## Glossary

- **Proxy**: The S3 Proxy HTTP server that forwards requests between clients and S3
- **Cache_Metadata**: The `NewCacheMetadata` struct representing an object's cached state, including object metadata and a list of cached ranges
- **Range_Spec**: The `RangeSpec` struct representing a single cached byte range of an object, including its file path, compression info, and access tracking fields
- **Object_Expiry**: The `expires_at` field on `Cache_Metadata` that determines when the entire cached object needs revalidation against S3
- **Expiration_Check**: The `check_range_expiration()` function in `DiskCacheManager` that determines whether cached data needs conditional validation
- **Conditional_Validation**: An If-Modified-Since request to S3 to check whether cached data is still fresh (results in 304 Not Modified or 200 OK)
- **TTL_Refresh**: Updating the `expires_at` timestamp after a successful 304 Not Modified response from S3
- **Resolved_Get_TTL**: The per-bucket TTL duration resolved from configuration, used to compute `expires_at`

## Requirements

### Requirement 1: Move expires_at to object level

**User Story:** As a cache operator, I want expiration tracked at the object level rather than per-range, so that all ranges of the same object share a consistent freshness state.

#### Acceptance Criteria

1. THE Cache_Metadata SHALL contain an `expires_at` field representing the expiration time for the entire cached object
2. WHEN the Expiration_Check evaluates whether cached data is expired, THE Expiration_Check SHALL use the object-level `expires_at` from Cache_Metadata instead of per-range `expires_at` from Range_Spec
3. WHEN a Conditional_Validation returns 304 Not Modified, THE Proxy SHALL update the object-level `expires_at` on Cache_Metadata to `now + Resolved_Get_TTL`
4. WHEN the Proxy stores a new range via `store_range`, THE Proxy SHALL set the object-level `expires_at` on Cache_Metadata to `now + Resolved_Get_TTL`
5. THE Range_Spec SHALL retain `last_accessed`, `access_count`, and `frequency_score` fields for per-range eviction decisions

### Requirement 2: Simplify expiration check to use object-level expiry

**User Story:** As a developer, I want the expiration check to read the object-level `expires_at` instead of finding and checking a specific range, so that the logic is simpler and consistent across all request paths.

#### Acceptance Criteria

1. WHEN the Expiration_Check is called, THE Expiration_Check SHALL read Cache_Metadata and compare the object-level `expires_at` against the current time
2. WHEN the object-level `expires_at` is in the past, THE Expiration_Check SHALL return the `last_modified` value from Cache_Metadata to enable Conditional_Validation
3. WHEN the object-level `expires_at` is in the future, THE Expiration_Check SHALL return no expiration indication
4. THE Expiration_Check SHALL accept a cache key as input without requiring range start and end parameters

### Requirement 3: Update TTL refresh to operate at object level

**User Story:** As a cache operator, I want TTL refresh after 304 responses to update the object-level expiry, so that all ranges benefit from a single revalidation.

#### Acceptance Criteria

1. WHEN a TTL_Refresh is performed, THE Proxy SHALL set the object-level `expires_at` on Cache_Metadata to `now + Resolved_Get_TTL`
2. WHEN a TTL_Refresh is performed, THE Proxy SHALL not require range start and end parameters
3. THE TTL_Refresh SHALL update the `last_accessed` timestamp on the specific range that triggered the revalidation

### Requirement 4: Update cache write paths for object-level expiry

**User Story:** As a cache operator, I want cache writes to set the object-level expiry correctly, so that newly cached data has a proper TTL from the moment it is stored.

#### Acceptance Criteria

1. WHEN a new Cache_Metadata entry is created during `store_range`, THE Proxy SHALL set `expires_at` to `now + Resolved_Get_TTL`
2. WHEN a range is added to an existing Cache_Metadata entry, THE Proxy SHALL update `expires_at` to `now + Resolved_Get_TTL`
3. WHEN a full object is stored via `store_full_object_as_range`, THE Proxy SHALL set `expires_at` to `now + Resolved_Get_TTL`

### Requirement 5: Remove per-range expiry from RangeSpec

**User Story:** As a developer, I want the per-range `expires_at` field and its associated methods removed from Range_Spec entirely, so that the codebase has a single clear expiry model at the object level.

#### Acceptance Criteria

1. THE Range_Spec SHALL not contain an `expires_at` field
2. THE Range_Spec SHALL not contain an `is_expired()` method
3. THE Range_Spec SHALL not contain a `refresh_ttl()` method
4. THE Cache_Metadata SHALL not contain an `is_legacy_expiry()` method
5. WHEN the Expiration_Check evaluates whether cached data is expired, THE Expiration_Check SHALL check only the object-level `expires_at` on Cache_Metadata without any legacy fallback logic

### Requirement 6: Treat metadata read failures as expired

**User Story:** As a security-conscious operator, I want metadata read failures during expiration checks to be treated as expired, so that the proxy never serves potentially stale or unauthorized data when it cannot verify freshness.

#### Acceptance Criteria

1. IF the Expiration_Check encounters a metadata read error, THEN THE Proxy SHALL treat the cached data as expired and forward the request to S3
2. IF the Expiration_Check encounters a metadata deserialization error, THEN THE Proxy SHALL treat the cached data as expired and forward the request to S3
3. WHEN a metadata read failure causes the Proxy to treat data as expired, THE Proxy SHALL log a warning including the cache key and error details
4. WHEN the Proxy forwards a request to S3 due to a metadata read failure, THE Proxy SHALL use the same Conditional_Validation flow as a normal expiration (If-Modified-Since with the cached `last_modified` if available, or an unconditional forward if not)

### Requirement 7: Simplify expiration check call sites in http_proxy.rs

**User Story:** As a developer, I want the range request path and full-object GET path in `http_proxy.rs` to use a simplified expiration check that does not require selecting a specific range, so that the code is easier to maintain.

#### Acceptance Criteria

1. WHEN the range request path checks expiration, THE Proxy SHALL call the Expiration_Check with only the cache key, without selecting the first cached range
2. WHEN the full-object GET path checks expiration, THE Proxy SHALL call the Expiration_Check with only the cache key, without selecting the first cached range
3. WHEN the Expiration_Check returns an expiration indication due to either expiry or metadata read failure, THE Proxy SHALL proceed with Conditional_Validation or forward to S3
