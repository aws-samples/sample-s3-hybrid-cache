# Requirements Document

## Introduction

This specification defines the removal of legacy write cache storage code from the S3 Proxy codebase. The proxy currently has two parallel storage mechanisms for write-cached PUT data: a legacy `write_cache/` directory approach and a newer unified storage approach using `objects/` + `ranges/` directories. This creates confusion, potential bugs, and maintenance burden. The goal is to consolidate on the unified storage approach and remove all legacy code.

## Glossary

- **Legacy Storage**: The old approach storing write-cached data in `write_cache/{key}.cache` and `write_cache/{key}.meta` files
- **Unified Storage**: The new approach storing metadata in `objects/` with `is_write_cached` flag and data in `ranges/` directory
- **Write Cache**: Cache storage for PUT operations before they are accessed via GET
- **MPU**: Multipart Upload - S3 feature for uploading large objects in parts
- **Cache Key**: Unique identifier for cached objects (typically `bucket/object-key`)

## Requirements

### Requirement 1

**User Story:** As a developer, I want the codebase to use a single storage mechanism for write-cached data, so that the code is simpler and easier to maintain.

#### Acceptance Criteria

1. WHEN the Proxy stores write-cached PUT data THEN the Proxy SHALL use only the unified storage format (objects/ + ranges/)
2. WHEN the Proxy retrieves write-cached data THEN the Proxy SHALL read only from the unified storage format
3. THE Proxy SHALL NOT create or reference a `write_cache/` directory
4. THE Proxy SHALL NOT create or reference a `parts/` directory

### Requirement 2

**User Story:** As a developer, I want all legacy write cache functions removed from cache.rs, so that the codebase is cleaner.

#### Acceptance Criteria

1. THE Proxy SHALL NOT contain the function `get_write_cache_file_path()`
2. THE Proxy SHALL NOT contain the function `get_write_metadata_file_path()`
3. THE Proxy SHALL NOT contain the function `cleanup_stale_write_cache_on_startup()`
4. THE Proxy SHALL NOT contain the function `transition_write_cache_to_range_cache()`
5. THE Proxy SHALL NOT contain the function `cleanup_empty_write_cache_directories()`
6. THE Proxy SHALL NOT contain code that scans `write_cache/` directory for cleanup or eviction

### Requirement 3

**User Story:** As a developer, I want the signed_put_handler to use only the unified storage path, so that PUT caching is consistent.

#### Acceptance Criteria

1. WHEN signed_put_handler caches a PUT request THEN the handler SHALL use DiskCacheManager to store in unified format
2. THE signed_put_handler SHALL NOT contain fallback code that writes to `write_cache/` directory
3. THE signed_put_handler SHALL NOT use CacheWriter to write to `write_cache/` directory

### Requirement 4

**User Story:** As a developer, I want the permissions module to not create unused directories, so that the cache directory structure is clean.

#### Acceptance Criteria

1. WHEN write_cache_enabled is true THEN the PermissionValidator SHALL create only `mpus_in_progress/` subdirectory (in addition to base directories)
2. THE PermissionValidator SHALL NOT create `write_cache/` subdirectory
3. THE PermissionValidator SHALL NOT create `parts/` subdirectory

### Requirement 5

**User Story:** As a developer, I want tests updated to reflect the unified storage approach, so that tests validate current behavior.

#### Acceptance Criteria

1. WHEN tests verify write cache storage THEN tests SHALL check unified storage format (objects/ + ranges/)
2. THE test suite SHALL NOT contain tests that specifically test legacy `write_cache/` directory format
3. WHEN legacy-specific test files exist THEN those files SHALL be removed or rewritten

### Requirement 6

**User Story:** As a developer, I want the invalidate_write_cache_entry function to only clean unified storage, so that invalidation is consistent.

#### Acceptance Criteria

1. WHEN invalidating a write cache entry THEN the Proxy SHALL remove files only from objects/ and ranges/ directories
2. THE invalidate_write_cache_entry function SHALL NOT contain fallback code to clean `write_cache/` directory
