# Design Document

## Overview

This design describes the removal of legacy write cache storage code from the S3 Proxy. The proxy currently maintains two parallel storage mechanisms for write-cached PUT data, creating code complexity and potential inconsistencies. This refactoring consolidates on the unified storage approach where all cached data (read and write) uses the same `objects/` + `ranges/` directory structure.

## Architecture

### Current State (Before)

```
cache_dir/
├── objects/          # Metadata files (.meta) - NEW format
├── ranges/           # Data files (.bin) - NEW format
├── write_cache/      # LEGACY: {key}.cache + {key}.meta files
├── parts/            # UNUSED: Never actually used
├── mpus_in_progress/ # Multipart upload tracking
├── head_cache/       # HEAD request cache
└── locks/            # Coordination locks
```

### Target State (After)

```
cache_dir/
├── objects/          # All metadata files (.meta) with is_write_cached flag
├── ranges/           # All data files (.bin)
├── mpus_in_progress/ # Multipart upload tracking
├── head_cache/       # HEAD request cache
└── locks/            # Coordination locks
```

### Storage Format

Write-cached objects use the same format as read-cached objects:

**Metadata (objects/{sharded_path}.meta):**
```json
{
  "cache_key": "bucket/key",
  "object_metadata": {
    "is_write_cached": true,
    "write_cache_expires_at": "2024-12-16T20:00:00Z",
    "write_cache_last_accessed": "2024-12-15T20:00:00Z",
    ...
  },
  "ranges": [
    {
      "start": 0,
      "end": 1000,
      "file_path": "bucket/XX/YYY/key_0_1000.bin",
      "compressed_size": 800
    }
  ]
}
```

**Data (ranges/{sharded_path}.bin):**
- LZ4 compressed binary data

## Components and Interfaces

### Files to Modify

| File | Changes |
|------|---------|
| `src/cache.rs` | Remove legacy functions, remove fallback paths |
| `src/signed_put_handler.rs` | Remove CacheWriter fallback to write_cache/ |
| `src/permissions.rs` | Remove write_cache/ and parts/ creation (done) |

### Functions to Remove from cache.rs

1. `get_write_cache_file_path()` - Returns path to legacy write_cache/{key}.cache
2. `get_write_metadata_file_path()` - Returns path to legacy write_cache/{key}.meta
3. `cleanup_stale_write_cache_on_startup()` - Scans write_cache/ for stale files
4. `transition_write_cache_to_range_cache()` - Migrates from legacy to unified
5. `cleanup_empty_write_cache_directories()` - Cleans empty dirs in write_cache/
6. `store_write_entry_to_disk()` - Writes to legacy format
7. `atomic_write_write_cache_entry()` - Atomic write to legacy format
8. Legacy portions of `cleanup_expired_write_cache_entries()` - Scans write_cache/
9. Legacy portions of `enforce_write_cache_size_limits()` - Scans write_cache/
10. Legacy fallback in `invalidate_write_cache_entry()` - Cleans write_cache/
11. Legacy fallback in `get_write_cache_entry_from_disk()` - Reads write_cache/
12. `delete_write_cache_file()` - Deletes from legacy format

### Functions to Keep (use unified storage)

1. `store_put_as_write_cached_range()` - Stores via DiskCacheManager
2. `is_write_cached()` - Checks metadata is_write_cached flag
3. `refresh_write_cache_ttl()` - Updates metadata expiration
4. `check_and_invalidate_expired_write_cache()` - Checks unified metadata
5. `get_write_cache_capacity()` - Calculates capacity limits
6. `can_write_cache_accommodate()` - Checks capacity
7. `update_write_cache_size()` - Tracks size
8. `record_write_cache_hit()` - Statistics

### signed_put_handler.rs Changes

Remove the fallback blocks that use CacheWriter to write to `write_cache/`:

```rust
// REMOVE THIS PATTERN:
} else {
    // Fallback: Use old CacheWriter approach
    let cache_path = cache_dir.join("write_cache").join(&sanitized_key);
    let mut cache_writer = CacheWriter::new(...);
    ...
}
```

The primary path using `store_put_as_write_cached_range()` via DiskCacheManager remains.

### Test Files to Update/Remove

| File | Action |
|------|--------|
| `tests/delete_write_cache_test.rs` | Remove (tests legacy format) |
| `tests/write_cache_test.rs` | Update to test unified format |
| `tests/write_cache_transition_test.rs` | Remove (tests migration) |
| `tests/put_then_get_integration_test.rs` | Update assertions |
| `tests/test_write_cache_flag.rs` | Update assertions |
| `tests/temp_file_cleanup_test.rs` | Update directory creation |

## Data Models

No changes to data models. The unified storage format already exists and is used by the primary code path.



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property Reflection

After analyzing the acceptance criteria, most requirements are code structure requirements (function removal, directory removal) that are verified by code inspection rather than runtime testing. The testable properties focus on:

1. Storage location verification - data goes to unified format
2. Directory absence verification - legacy directories not created
3. Invalidation behavior - only unified storage cleaned

Properties 1.1, 1.2, 3.1, and 6.1 can be combined into a single comprehensive property about storage consistency.

### Properties

**Property 1: Unified storage consistency**

*For any* write-cached PUT operation, the cached data SHALL exist only in `objects/` (metadata) and `ranges/` (data) directories, and SHALL NOT exist in `write_cache/` directory.

**Validates: Requirements 1.1, 1.2, 3.1**

**Property 2: Directory structure correctness**

*For any* cache initialization with write_cache_enabled=true, the cache directory SHALL contain `mpus_in_progress/` but SHALL NOT contain `write_cache/` or `parts/` directories.

**Validates: Requirements 1.3, 1.4, 4.1, 4.2, 4.3**

**Property 3: Invalidation completeness**

*For any* write cache invalidation operation, files SHALL be removed only from `objects/` and `ranges/` directories, and no operations SHALL target `write_cache/` directory.

**Validates: Requirements 6.1**

## Error Handling

- If legacy `write_cache/` directory exists from previous versions, it is ignored (not scanned, not cleaned)
- Users who upgrade from older versions should manually delete `write_cache/` and `parts/` directories if they exist
- No migration path is provided - legacy data is orphaned

## Testing Strategy

### Dual Testing Approach

**Unit Tests:**
- Verify PermissionValidator creates correct directories
- Verify cache initialization doesn't create legacy directories

**Property-Based Tests:**
- Use `quickcheck` library (already in project)
- Configure minimum 100 iterations per property
- Tag tests with `**Feature: legacy-write-cache-removal, Property N: description**`

### Test Implementation

Property 1 (Unified storage consistency):
- Generate random cache keys and data
- Store via `store_put_as_write_cached_range()`
- Assert files exist in `objects/` and `ranges/`
- Assert `write_cache/` directory doesn't exist or is empty

Property 2 (Directory structure correctness):
- Initialize cache with write_cache_enabled=true
- Assert `mpus_in_progress/` exists
- Assert `write_cache/` doesn't exist
- Assert `parts/` doesn't exist

Property 3 (Invalidation completeness):
- Store write-cached data
- Invalidate entry
- Assert files removed from `objects/` and `ranges/`
- Assert no operations on `write_cache/`
