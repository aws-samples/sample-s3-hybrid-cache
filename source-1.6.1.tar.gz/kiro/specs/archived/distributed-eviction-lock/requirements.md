# Requirements Document: Distributed Cache Eviction Lock

## Introduction

When multiple S3 proxy instances share a cache volume, each instance independently monitors disk usage and triggers eviction when limits are exceeded. This causes race conditions where multiple instances simultaneously evict entries, leading to over-eviction, cache thrashing, and under-utilization of available capacity. This feature implements a distributed lock mechanism to ensure only one instance performs eviction at a time, coordinating capacity management across all instances.

## Glossary

- **Cache Eviction**: The process of removing cache entries to free disk space when capacity limits are exceeded
- **Distributed Lock**: A filesystem-based lock that coordinates exclusive access to eviction operations across multiple proxy instances
- **Global Eviction Lock**: A special lock file that grants one instance exclusive rights to perform cache eviction
- **Lock Timeout**: Maximum duration a lock can be held before it's considered stale and can be forcibly acquired
- **Lock Staleness**: A lock is stale when its holder has crashed or failed to release it within the timeout period
- **Eviction Coordinator**: The instance currently holding the global eviction lock
- **Cache Instance**: A single S3 proxy process that may share a cache volume with other instances

## Requirements

### Requirement 1: Global Eviction Lock Acquisition

**User Story:** As a cache instance, I want to acquire an exclusive eviction lock, so that only one instance performs eviction at a time.

#### Acceptance Criteria

1. WHEN a cache instance needs to perform eviction, THEN the cache instance SHALL attempt to acquire the global eviction lock before starting eviction
2. WHEN the global eviction lock is available, THEN the cache instance SHALL create a lock file with instance metadata and timestamp
3. WHEN the global eviction lock is already held by another instance, THEN the cache instance SHALL skip eviction and return immediately
4. WHEN acquiring the lock, THEN the cache instance SHALL write its instance ID, process ID, hostname, and acquisition timestamp to the lock file
5. THE cache instance SHALL use atomic file operations to prevent race conditions during lock acquisition

### Requirement 2: Lock Timeout and Staleness Detection

**User Story:** As a cache instance, I want to detect and recover from stale locks, so that eviction continues even if a lock holder crashes.

#### Acceptance Criteria

1. WHEN checking for an existing lock, THEN the cache instance SHALL read the lock file timestamp
2. WHEN the lock timestamp is older than the configured timeout, THEN the cache instance SHALL consider the lock stale
3. WHEN a lock is stale, THEN the cache instance SHALL forcibly acquire the lock by overwriting the lock file
4. THE cache instance SHALL use a default lock timeout of 60 seconds (1 minute)
5. THE cache instance SHALL log warnings when forcibly acquiring stale locks for monitoring

### Requirement 3: Lock Release

**User Story:** As a cache instance, I want to release the eviction lock after completing eviction, so that other instances can perform eviction when needed.

#### Acceptance Criteria

1. WHEN eviction completes successfully, THEN the cache instance SHALL release the global eviction lock
2. WHEN eviction fails with an error, THEN the cache instance SHALL release the global eviction lock
3. WHEN releasing the lock, THEN the cache instance SHALL verify it still owns the lock before deletion
4. WHEN the lock file does not exist during release, THEN the cache instance SHALL log a warning but continue normally
5. THE cache instance SHALL ensure lock release happens even during panic or unexpected termination using proper cleanup

### Requirement 4: Lock File Format

**User Story:** As a system operator, I want lock files to contain diagnostic information, so that I can troubleshoot eviction coordination issues.

#### Acceptance Criteria

1. THE global eviction lock file SHALL be stored at `{cache_dir}/locks/global_eviction.lock`
2. THE lock file SHALL contain JSON-formatted metadata
3. THE lock file SHALL include the instance ID field
4. THE lock file SHALL include the process ID field
5. THE lock file SHALL include the hostname field
6. THE lock file SHALL include the acquisition timestamp in RFC3339 format
7. THE lock file SHALL include the lock timeout duration in seconds

### Requirement 5: Eviction Coordination Flow

**User Story:** As a cache system, I want coordinated eviction across instances, so that cache capacity is managed efficiently without over-eviction.

#### Acceptance Criteria

1. WHEN disk cache exceeds the configured limit, THEN the cache instance SHALL attempt to acquire the global eviction lock
2. WHEN the lock is acquired successfully, THEN the cache instance SHALL proceed with eviction using the configured algorithm
3. WHEN the lock cannot be acquired, THEN the cache instance SHALL skip eviction and log the reason
4. WHEN eviction completes, THEN the cache instance SHALL release the lock immediately
5. THE cache instance SHALL ensure only one instance performs eviction at any given time across all instances

### Requirement 6: Configuration

**User Story:** As a system operator, I want to configure eviction lock behavior, so that I can tune coordination for my deployment.

#### Acceptance Criteria

1. THE system SHALL support a configurable lock timeout duration
2. THE system SHALL use a default lock timeout of 60 seconds if not configured
3. THE system SHALL support disabling distributed locking for single-instance deployments
4. THE system SHALL validate that lock timeout is between 30 and 3600 seconds
5. THE system SHALL log the configured lock timeout at startup

### Requirement 7: Metrics and Monitoring

**User Story:** As a system operator, I want metrics for eviction coordination, so that I can monitor lock contention and staleness.

#### Acceptance Criteria

1. THE system SHALL track the number of successful lock acquisitions
2. THE system SHALL track the number of failed lock acquisitions (lock held by another instance)
3. THE system SHALL track the number of stale locks forcibly acquired
4. THE system SHALL track the total time spent holding the eviction lock
5. THE system SHALL expose these metrics via the metrics endpoint

### Requirement 8: Error Handling

**User Story:** As a cache instance, I want robust error handling for lock operations, so that eviction continues despite filesystem issues.

#### Acceptance Criteria

1. WHEN lock file creation fails due to filesystem errors, THEN the cache instance SHALL log the error and skip eviction
2. WHEN lock file reading fails, THEN the cache instance SHALL treat the lock as unavailable and skip eviction
3. WHEN lock file deletion fails during release, THEN the cache instance SHALL log a warning but continue
4. WHEN lock metadata is corrupted or invalid, THEN the cache instance SHALL treat the lock as stale
5. THE system SHALL never crash or panic due to lock operation failures


### Requirement 10: Testing Requirements

**User Story:** As a developer, I want comprehensive tests for eviction coordination, so that I can ensure correctness across multiple instances.

#### Acceptance Criteria

1. THE system SHALL include unit tests for lock acquisition, release, and staleness detection
2. THE system SHALL include integration tests simulating multiple instances competing for the lock
3. THE system SHALL include tests for stale lock recovery scenarios
4. THE system SHALL include tests for lock release during error conditions
5. THE system SHALL include tests verifying only one instance evicts at a time

