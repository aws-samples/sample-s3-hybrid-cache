# Distributed Cache Eviction Lock

## Overview

Implements filesystem-based distributed locking to coordinate cache eviction across multiple S3 proxy instances sharing a cache volume. Prevents race conditions, over-eviction, and cache thrashing in multi-instance deployments.

## Problem Statement

When multiple proxy instances share a cache disk, each independently monitors disk usage and triggers eviction when limits are exceeded. This causes:

- **Race Conditions**: Multiple instances simultaneously detect "over limit" and all start evicting
- **Over-Eviction**: If 3 instances each see 11GB/10GB, they might each evict 1GB, resulting in 7GB total (under-utilized)
- **Cache Thrashing**: Instances may evict each other's recently cached entries
- **No Coordination**: All instances compete for the same total capacity without coordination

## Solution

Use a global eviction lock file (`{cache_dir}/locks/global_eviction.lock`) to ensure only one instance performs eviction at a time:

1. Instance detects cache over limit
2. Attempts to acquire global eviction lock
3. If acquired: performs eviction, then releases lock
4. If held by another: skips eviction (other instance is handling it)
5. Stale lock detection: forcibly acquire locks held longer than timeout (5 minutes default)

## Key Features

- **Mutual Exclusion**: Only one instance evicts at a time
- **Stale Lock Recovery**: Automatic recovery if lock holder crashes
- **Atomic Operations**: Race-free lock acquisition using filesystem atomicity
- **Backward Compatible**: Disabled by default, no breaking changes
- **Zero External Dependencies**: Uses only filesystem operations
- **Comprehensive Metrics**: Track lock contention, staleness, and coordination

## Files

- `requirements.md` - EARS-compliant requirements with acceptance criteria
- `design.md` - Detailed design with correctness properties and implementation
- `tasks.md` - Implementation task list with property-based test tasks

## Status

**Phase**: Requirements and Design Complete ✅

Ready for implementation. All requirements validated, design reviewed, and tasks defined.

## Quick Start

Once implemented, enable in configuration:

```yaml
cache:
  max_cache_size: 10737418240  # 10GB
  distributed_eviction:
    enabled: true
    lock_timeout_seconds: 300  # 5 minutes
```

## Related Specs

- `cache-key-simplification` - Simplified cache key format (completed)
- `range-storage-redesign` - New range storage architecture (completed)

