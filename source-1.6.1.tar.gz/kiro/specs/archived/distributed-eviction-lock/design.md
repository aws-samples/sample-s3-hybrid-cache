# Design Document: Distributed Cache Eviction Lock

## Overview

This design implements a distributed lock mechanism using filesystem-based coordination to ensure only one proxy instance performs cache eviction at a time when multiple instances share a cache volume. The solution uses atomic file operations and timeout-based staleness detection to provide mutual exclusion without requiring external coordination services.

## Prerequisites

### Access Tracking System (IMPLEMENTED)

Eviction relies on the `AccessTracker` system (`src/access_tracker.rs`) which provides per-range access statistics:

```
cache/
├── objects/xx/yyy/
│   ├── key.meta                           # Contains access_count, last_accessed per range
│   └── key_0-8388607.access.{instance_id} # Per-instance access log (append-only)
└── access_tracking/
    ├── HH-MM-00/{instance_id}/*.marker    # Time-bucketed markers for discovery
    └── consolidation.lock                  # Ensures single consolidator
```

**How it works:**
1. Range reads append timestamps to `.access.{instance_id}` files (non-blocking)
2. Background task consolidates access files into metadata every ~60s
3. Consolidation uses exclusive lock - only one instance consolidates at a time
4. Metadata `access_count` and `last_accessed` fields are updated atomically

**Integration with eviction:**
- `collect_cache_entries_for_eviction()` reads `.meta` files to get `access_count`/`last_accessed`
- Before eviction, should trigger consolidation to ensure recent accesses are reflected
- LRU uses `last_accessed`, LFU/TinyLFU uses `access_count`

## Architecture

### Current Problem

```
Instance 1: Detects 11GB/10GB → Starts evicting
Instance 2: Detects 11GB/10GB → Starts evicting  ← Race condition
Instance 3: Detects 11GB/10GB → Starts evicting  ← Over-eviction

Result: All 3 instances evict simultaneously, removing 3GB total
        Cache drops to 8GB (under-utilized)
```

### Proposed Solution

```
Instance 1: Detects 11GB/10GB → Acquires lock → Evicts 1GB → Releases lock
Instance 2: Detects 11GB/10GB → Lock held → Skips eviction
Instance 3: Detects 11GB/10GB → Lock held → Skips eviction

Result: Only Instance 1 evicts, cache drops to 10GB (optimal)
```

### Lock File Location

```
cache_dir/
└── locks/
    ├── global_eviction.lock    # NEW: Global eviction coordinator lock
    └── {cache_key}.lock         # Existing: Per-entry write locks
```

## Components and Interfaces

### 1. Global Eviction Lock Structure

```rust
/// Global eviction lock metadata
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GlobalEvictionLock {
    /// Unique identifier for this proxy instance
    pub instance_id: String,
    
    /// Process ID of the lock holder
    pub process_id: u32,
    
    /// Hostname of the machine holding the lock
    pub hostname: String,
    
    /// When the lock was acquired (RFC3339 format)
    pub acquired_at: SystemTime,
    
    /// Lock timeout duration in seconds
    pub timeout_seconds: u64,
}

impl GlobalEvictionLock {
    /// Check if this lock is stale based on current time
    pub fn is_stale(&self, now: SystemTime) -> bool {
        if let Ok(elapsed) = now.duration_since(self.acquired_at) {
            elapsed.as_secs() > self.timeout_seconds
        } else {
            true // If time went backwards, consider stale
        }
    }
    
    /// Get the expiration time for this lock
    pub fn expires_at(&self) -> SystemTime {
        self.acquired_at + Duration::from_secs(self.timeout_seconds)
    }
}
```

### 2. Lock Acquisition API

```rust
impl CacheManager {
    /// Try to acquire the global eviction lock
    /// Returns Ok(true) if lock acquired, Ok(false) if held by another instance
    pub async fn try_acquire_global_eviction_lock(&self) -> Result<bool> {
        let lock_file_path = self.get_global_eviction_lock_path();
        let now = SystemTime::now();
        
        // Check if lock file exists
        if lock_file_path.exists() {
            // Read existing lock
            match self.read_global_eviction_lock().await {
                Ok(existing_lock) => {
                    // Check if stale
                    if existing_lock.is_stale(now) {
                        warn!(
                            "Forcibly acquiring stale eviction lock held by instance {} (pid {}) since {:?}",
                            existing_lock.instance_id,
                            existing_lock.process_id,
                            existing_lock.acquired_at
                        );
                        // Overwrite stale lock
                        return self.write_global_eviction_lock(now).await;
                    } else {
                        // Lock is held by another instance
                        debug!(
                            "Eviction lock held by instance {} (expires in {:?})",
                            existing_lock.instance_id,
                            existing_lock.expires_at().duration_since(now).unwrap_or_default()
                        );
                        return Ok(false);
                    }
                }
                Err(e) => {
                    // Corrupted lock file, treat as stale
                    warn!("Corrupted eviction lock file, treating as stale: {}", e);
                    return self.write_global_eviction_lock(now).await;
                }
            }
        }
        
        // No lock exists, acquire it
        self.write_global_eviction_lock(now).await
    }
    
    /// Write global eviction lock file atomically
    async fn write_global_eviction_lock(&self, acquired_at: SystemTime) -> Result<bool> {
        let lock_file_path = self.get_global_eviction_lock_path();
        
        let lock = GlobalEvictionLock {
            instance_id: self.get_instance_id(),
            process_id: std::process::id(),
            hostname: hostname::get()
                .unwrap_or_else(|_| "unknown".into())
                .to_string_lossy()
                .to_string(),
            acquired_at,
            timeout_seconds: self.get_eviction_lock_timeout_seconds(),
        };
        
        let lock_json = serde_json::to_string_pretty(&lock)
            .map_err(|e| ProxyError::CacheError(format!("Failed to serialize lock: {}", e)))?;
        
        // Atomic write: write to temp file, then rename
        let temp_path = lock_file_path.with_extension("lock.tmp");
        std::fs::write(&temp_path, lock_json)
            .map_err(|e| ProxyError::CacheError(format!("Failed to write lock file: {}", e)))?;
        
        std::fs::rename(&temp_path, &lock_file_path)
            .map_err(|e| ProxyError::CacheError(format!("Failed to rename lock file: {}", e)))?;
        
        debug!("Acquired global eviction lock (timeout: {}s)", lock.timeout_seconds);
        Ok(true)
    }
    
    /// Release the global eviction lock
    pub async fn release_global_eviction_lock(&self) -> Result<()> {
        let lock_file_path = self.get_global_eviction_lock_path();
        
        if !lock_file_path.exists() {
            warn!("Eviction lock file does not exist during release");
            return Ok(());
        }
        
        // Verify we still own the lock before deleting
        match self.read_global_eviction_lock().await {
            Ok(existing_lock) => {
                if existing_lock.instance_id != self.get_instance_id() {
                    warn!(
                        "Not releasing eviction lock owned by another instance: {}",
                        existing_lock.instance_id
                    );
                    return Ok(());
                }
            }
            Err(e) => {
                warn!("Failed to read lock during release, deleting anyway: {}", e);
            }
        }
        
        // Delete lock file
        if let Err(e) = std::fs::remove_file(&lock_file_path) {
            warn!("Failed to delete eviction lock file: {}", e);
        } else {
            debug!("Released global eviction lock");
        }
        
        Ok(())
    }
    
    /// Read global eviction lock file
    async fn read_global_eviction_lock(&self) -> Result<GlobalEvictionLock> {
        let lock_file_path = self.get_global_eviction_lock_path();
        
        let lock_json = std::fs::read_to_string(&lock_file_path)
            .map_err(|e| ProxyError::CacheError(format!("Failed to read lock file: {}", e)))?;
        
        let lock: GlobalEvictionLock = serde_json::from_str(&lock_json)
            .map_err(|e| ProxyError::CacheError(format!("Failed to parse lock file: {}", e)))?;
        
        Ok(lock)
    }
    
    /// Get path to global eviction lock file
    fn get_global_eviction_lock_path(&self) -> PathBuf {
        self.cache_dir.join("locks").join("global_eviction.lock")
    }
    
    /// Get instance ID for this cache manager
    fn get_instance_id(&self) -> String {
        // Use hostname + PID as instance ID
        let hostname = hostname::get()
            .unwrap_or_else(|_| "unknown".into())
            .to_string_lossy()
            .to_string();
        format!("{}:{}", hostname, std::process::id())
    }
    
    /// Get eviction lock timeout in seconds
    fn get_eviction_lock_timeout_seconds(&self) -> u64 {
        // TODO: Make configurable, default to 300 seconds (5 minutes)
        300
    }
}
```

### 3. Integration with Eviction Flow

```rust
impl CacheManager {
    /// Enforce disk cache size limits with distributed coordination
    async fn enforce_disk_cache_limits(&self) -> Result<u64> {
        debug!("Enforcing disk cache size limits using {:?} algorithm", self.eviction_algorithm);
        
        // Calculate current disk cache size
        let current_size = self.calculate_disk_cache_size().await?;
        let max_size = {
            let inner = self.inner.lock().unwrap();
            inner.statistics.total_cache_size
        };

        if max_size == 0 || current_size <= max_size {
            return Ok(0);
        }

        info!("Disk cache over limit ({} bytes > {} bytes), attempting to acquire eviction lock", 
              current_size, max_size);

        // Try to acquire global eviction lock
        let lock_acquired = match self.try_acquire_global_eviction_lock().await {
            Ok(true) => true,
            Ok(false) => {
                debug!("Another instance is handling eviction, skipping");
                return Ok(0);
            }
            Err(e) => {
                warn!("Failed to acquire eviction lock, skipping eviction: {}", e);
                return Ok(0);
            }
        };

        // Ensure lock is released even if eviction fails
        let eviction_result = self.perform_eviction_with_lock(current_size, max_size).await;
        
        // Release lock
        if let Err(e) = self.release_global_eviction_lock().await {
            warn!("Failed to release eviction lock: {}", e);
        }
        
        eviction_result
    }
    
    /// Perform eviction while holding the lock
    async fn perform_eviction_with_lock(&self, current_size: u64, max_size: u64) -> Result<u64> {
        info!("Starting coordinated eviction (lock acquired)");
        
        // Consolidate access tracking data before eviction to ensure recent accesses are reflected
        if let Some(tracker) = self.get_access_tracker() {
            if let Err(e) = tracker.consolidate().await {
                warn!("Failed to consolidate access tracking before eviction: {}", e);
            }
        }
        
        let mut evicted_count = 0u64;

        // Target size after eviction (aim for 80% of limit)
        let target_size = (max_size as f32 * 0.8) as u64;
        let mut current_tracked_size = current_size;

        // Collect cache entries with their metadata for eviction
        // This reads .meta files which contain access_count and last_accessed from AccessTracker
        let mut cache_entries = self.collect_cache_entries_for_eviction().await?;

        // Sort entries based on the configured eviction algorithm
        // LRU: sort by last_accessed (oldest first)
        // LFU: sort by access_count (lowest first)
        // TinyLFU: combines frequency estimation with recency
        self.sort_entries_for_eviction(&mut cache_entries);

        // Evict entries until we reach target size
        for (cache_key, _, entry_size) in cache_entries {
            if current_tracked_size <= target_size {
                break;
            }

            // Try to evict this entry with per-entry coordination
            match self.coordinate_cache_eviction(&cache_key).await {
                Ok(true) => {
                    current_tracked_size = current_tracked_size.saturating_sub(entry_size);
                    evicted_count += 1;
                    debug!("Evicted cache entry: {} ({} bytes)", cache_key, entry_size);
                }
                Ok(false) => {
                    debug!("Could not evict cache entry (in use): {}", cache_key);
                }
                Err(e) => {
                    warn!("Failed to evict cache entry {}: {}", cache_key, e);
                }
            }
        }

        if evicted_count > 0 {
            info!("Coordinated eviction completed: {} entries evicted using {:?} algorithm", 
                  evicted_count, self.eviction_algorithm);
            
            // Update statistics
            let mut inner = self.inner.lock().unwrap();
            inner.statistics.evicted_entries += evicted_count;
        }

        Ok(evicted_count)
    }
    
    /// Collect cache entries with metadata for eviction decisions
    /// Reads .meta files from objects/ directory to get access_count and last_accessed
    async fn collect_cache_entries_for_eviction(&self) -> Result<Vec<(String, EvictionMetadata, u64)>> {
        let mut entries = Vec::new();
        let objects_dir = self.cache_dir.join("objects");
        
        // Walk the sharded directory structure: objects/{bucket}/{XX}/{YYY}/*.meta
        for bucket_entry in std::fs::read_dir(&objects_dir)? {
            let bucket_path = bucket_entry?.path();
            if !bucket_path.is_dir() { continue; }
            
            // Walk hash shards
            for shard1 in std::fs::read_dir(&bucket_path)?.filter_map(|e| e.ok()) {
                for shard2 in std::fs::read_dir(shard1.path())?.filter_map(|e| e.ok()) {
                    for meta_file in std::fs::read_dir(shard2.path())?.filter_map(|e| e.ok()) {
                        let path = meta_file.path();
                        if path.extension().map(|e| e == "meta").unwrap_or(false) {
                            if let Ok(metadata) = self.read_eviction_metadata(&path).await {
                                let cache_key = self.cache_key_from_meta_path(&path);
                                let size = metadata.total_size;
                                entries.push((cache_key, metadata, size));
                            }
                        }
                    }
                }
            }
        }
        
        Ok(entries)
    }
    
    /// Sort entries for eviction based on configured algorithm
    fn sort_entries_for_eviction(&self, entries: &mut Vec<(String, EvictionMetadata, u64)>) {
        match self.eviction_algorithm {
            CacheEvictionAlgorithm::LRU => {
                // Least Recently Used: sort by last_accessed ascending (oldest first)
                entries.sort_by(|a, b| a.1.last_accessed.cmp(&b.1.last_accessed));
            }
            CacheEvictionAlgorithm::LFU => {
                // Least Frequently Used: sort by access_count ascending (lowest first)
                entries.sort_by(|a, b| a.1.access_count.cmp(&b.1.access_count));
            }
            CacheEvictionAlgorithm::TinyLFU => {
                // TinyLFU: combine frequency and recency
                // Score = access_count * recency_weight
                entries.sort_by(|a, b| {
                    let score_a = self.calculate_tinylfu_score(&a.1);
                    let score_b = self.calculate_tinylfu_score(&b.1);
                    score_a.cmp(&score_b)
                });
            }
        }
    }
}
```

## Data Models

### Eviction Metadata (from AccessTracker)

```rust
/// Metadata used for eviction decisions
/// Populated from .meta files which are updated by AccessTracker consolidation
#[derive(Debug, Clone)]
pub struct EvictionMetadata {
    /// Total access count across all ranges (from AccessTracker)
    pub access_count: u64,
    /// Most recent access time across all ranges (from AccessTracker)
    pub last_accessed: SystemTime,
    /// Total size of all cached ranges
    pub total_size: u64,
    /// Time when the object was first cached
    pub created_at: SystemTime,
}
```

### Lock File Format

```json
{
  "instance_id": "proxy-host-1:12345",
  "process_id": 12345,
  "hostname": "proxy-host-1",
  "acquired_at": "2024-01-15T10:30:00Z",
  "timeout_seconds": 300
}
```

### Lock State Machine

```
┌─────────────┐
│  No Lock    │
│  (Initial)  │
└──────┬──────┘
       │
       │ try_acquire_lock()
       ▼
┌─────────────┐     timeout expires      ┌─────────────┐
│   Lock      │────────────────────────▶│   Stale     │
│  Available  │                          │    Lock     │
└──────┬──────┘                          └──────┬──────┘
       │                                        │
       │ write_lock()                           │ force_acquire()
       ▼                                        ▼
┌─────────────┐                          ┌─────────────┐
│    Lock     │                          │    Lock     │
│   Held by   │                          │   Held by   │
│    Self     │                          │    Self     │
└──────┬──────┘                          └──────┬──────┘
       │                                        │
       │ release_lock()                         │ release_lock()
       ▼                                        ▼
┌─────────────┐                          ┌─────────────┐
│  No Lock    │                          │  No Lock    │
└─────────────┘                          └─────────────┘
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Mutual Exclusion

*For any* two cache instances attempting eviction simultaneously, at most one SHALL successfully acquire the global eviction lock and proceed with eviction.

**Validates: Requirements 5.5, 1.3**

### Property 2: Lock Acquisition Precedes Eviction

*For any* eviction operation, the instance SHALL attempt to acquire the global eviction lock before starting to evict cache entries.

**Validates: Requirements 1.1, 5.1**

### Property 3: Lock File Completeness

*For any* successfully acquired lock, the lock file SHALL contain all required fields: instance_id, process_id, hostname, acquired_at, and timeout_seconds.

**Validates: Requirements 1.4, 4.3, 4.4, 4.5, 4.6, 4.7**

### Property 4: Stale Lock Recovery

*For any* lock file with a timestamp older than the configured timeout, an instance attempting acquisition SHALL treat it as stale and forcibly acquire it.

**Validates: Requirements 2.2, 2.3**

### Property 5: Lock Release After Eviction

*For any* eviction operation (successful or failed), the instance SHALL release the global eviction lock after completion.

**Validates: Requirements 3.1, 3.2, 5.4**

### Property 6: Ownership Verification on Release

*For any* lock release operation, the instance SHALL verify it owns the lock before deletion, and SHALL NOT delete locks owned by other instances.

**Validates: Requirements 3.3**

### Property 7: Atomic Lock Acquisition

*For any* two instances attempting to acquire the lock simultaneously, exactly one SHALL succeed due to atomic file operations.

**Validates: Requirements 1.5**

### Property 8: Lock Timeout Default

*For any* cache manager instance without explicit timeout configuration, the lock timeout SHALL default to 300 seconds.

**Validates: Requirements 2.4**

### Property 9: Eviction Skip on Lock Failure

*For any* instance that fails to acquire the eviction lock, it SHALL skip eviction and return immediately without evicting any entries.

**Validates: Requirements 1.3, 5.3**

### Property 10: Lock File Location Consistency

*For any* cache manager instance, the global eviction lock file SHALL be located at `{cache_dir}/locks/global_eviction.lock`.

**Validates: Requirements 4.1**

## Error Handling

### Lock Acquisition Failures

- **Filesystem errors**: Log error, skip eviction, continue normal operation
- **Corrupted lock file**: Treat as stale, forcibly acquire
- **Permission errors**: Log error, skip eviction, alert operator

### Lock Release Failures

- **Lock file missing**: Log warning, continue (already released by another process)
- **Permission errors**: Log warning, continue (will be cleaned up by timeout)
- **Ownership mismatch**: Log warning, don't delete (owned by another instance)

### Stale Lock Detection

- **Time went backwards**: Treat lock as stale (clock skew protection)
- **Timeout exceeded**: Forcibly acquire, log warning for monitoring
- **Process still running**: Timeout-based recovery (process may be hung)

## Testing Strategy

### Unit Tests

1. **Lock Acquisition**: Test acquiring lock when no lock exists
2. **Lock Contention**: Test acquiring lock when already held
3. **Stale Lock Detection**: Test with various timestamps and timeouts
4. **Lock Release**: Test releasing owned and unowned locks
5. **Atomic Operations**: Test concurrent acquisition attempts
6. **Error Handling**: Test filesystem errors, corrupted files

### Property-Based Tests

Using `quickcheck` with minimum 100 iterations:

1. **Property 1: Mutual Exclusion**
   - Spawn multiple threads attempting eviction
   - Verify only one acquires lock at a time
   - **Feature: distributed-eviction-lock, Property 1: Mutual Exclusion**

2. **Property 2: Lock Acquisition Precedes Eviction**
   - Trigger eviction with monitoring
   - Verify lock acquisition happens before any eviction
   - **Feature: distributed-eviction-lock, Property 2: Lock Acquisition Precedes Eviction**

3. **Property 3: Lock File Completeness**
   - Acquire locks with random instance data
   - Parse lock files and verify all fields present
   - **Feature: distributed-eviction-lock, Property 3: Lock File Completeness**

4. **Property 4: Stale Lock Recovery**
   - Create locks with random old timestamps
   - Verify they're detected as stale and forcibly acquired
   - **Feature: distributed-eviction-lock, Property 4: Stale Lock Recovery**

5. **Property 5: Lock Release After Eviction**
   - Perform evictions (successful and failed)
   - Verify lock is always released
   - **Feature: distributed-eviction-lock, Property 5: Lock Release After Eviction**

### Integration Tests

1. **Multi-Instance Coordination**: Simulate 3 instances competing for eviction
2. **Stale Lock Recovery**: Kill instance holding lock, verify recovery
3. **Backward Compatibility**: Test with and without distributed locking enabled
4. **Metrics Validation**: Verify metrics are updated correctly

## Performance Impact

### Expected Overhead

- **Lock acquisition**: ~1-5ms (filesystem operations)
- **Lock release**: ~1-5ms (filesystem operations)
- **Stale lock check**: ~1ms (file read + timestamp comparison)

### Optimization Strategies

1. **Fast path**: Check lock file modification time before reading contents
2. **Caching**: Cache lock timeout configuration to avoid repeated lookups
3. **Async I/O**: Use async filesystem operations to avoid blocking

## Configuration

### New Configuration Options

```yaml
cache:
  # Existing options...
  max_cache_size: 10737418240  # 10GB
  
  # NEW: Distributed eviction coordination
  distributed_eviction:
    enabled: true                    # Enable distributed lock coordination
    lock_timeout_seconds: 300        # 5 minutes (60-3600 valid range)
```

### Backward Compatibility

If `distributed_eviction` is not configured:
- Default to `enabled: false` for single-instance deployments
- Can be enabled without breaking changes
- Existing deployments continue working as before

## Metrics

### New Metrics

```rust
pub struct EvictionCoordinationMetrics {
    pub lock_acquisitions_successful: u64,
    pub lock_acquisitions_failed: u64,
    pub stale_locks_recovered: u64,
    pub total_lock_hold_time_ms: u64,
    pub evictions_coordinated: u64,
    pub evictions_skipped_lock_held: u64,
}
```

### Metrics Endpoint

```json
{
  "eviction_coordination": {
    "lock_acquisitions_successful": 42,
    "lock_acquisitions_failed": 15,
    "stale_locks_recovered": 2,
    "total_lock_hold_time_ms": 125000,
    "evictions_coordinated": 42,
    "evictions_skipped_lock_held": 15
  }
}
```

## Security Considerations

### Lock File Permissions

- Lock files inherit cache directory permissions
- No sensitive data in lock files (only instance metadata)
- Lock timeout prevents indefinite lock holding

### Denial of Service

- Stale lock timeout prevents one instance from blocking others indefinitely
- Failed lock acquisition doesn't crash the instance
- Multiple instances can continue serving requests even if eviction is blocked

## Future Enhancements

1. **Adaptive Timeout**: Adjust timeout based on eviction duration history
2. **Priority-Based Locking**: Allow certain instances to have priority for eviction
3. **Lock Metrics Dashboard**: Visualize lock contention and staleness
4. **Distributed Consensus**: Use etcd/consul for more robust coordination (if available)

