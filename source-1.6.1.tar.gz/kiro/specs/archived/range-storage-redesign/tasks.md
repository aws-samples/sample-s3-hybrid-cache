# Implementation Plan: Range Storage Architecture Redesign

- [x] 1. Create new data structures for separated storage
  - Create `RangeSpec` struct without data field
  - Create `CacheMetadata` struct for lightweight metadata
  - Create `ObjectMetadata` struct for object-level metadata
  - Update `CompressionInfo` to work with new structures
  - _Requirements: 1.1, 1.2, 5.1, 5.2, 5.3, 5.4, 5.5_

- [ ]* 1.1 Write property test for metadata size efficiency
  - **Property 1: Metadata Size Efficiency**
  - **Validates: Requirements 1.4**

- [x] 2. Implement file path generation and sanitization
  - Implement `get_metadata_file_path()` method
  - Implement `get_range_file_path()` method
  - Implement `sanitize_cache_key()` method with special character handling
  - Add tests for path generation edge cases
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5_

- [ ]* 2.1 Write property test for deterministic file paths
  - **Property 4: Deterministic File Paths**
  - **Validates: Requirements 6.2, 6.4**

- [x] 3. Implement atomic range storage operations
  - Implement `store_range()` method with atomic writes
  - Write range data to `.tmp` file then rename
  - Update metadata file atomically
  - Ensure both operations succeed or both fail
  - Add error handling for partial writes
  - _Requirements: 1.1, 3.1, 3.2, 3.4, 3.5_

- [ ]* 3.1 Write property test for atomic range storage
  - **Property 3: Atomic Range Storage**
  - **Validates: Requirements 3.1, 3.4**

- [ ]* 3.2 Write property test for concurrent write safety
  - **Property 9: Concurrent Write Safety**
  - **Validates: Requirements 3.3**

- [x] 4. Implement metadata read/write operations
  - Implement `get_metadata()` method
  - Implement `update_metadata()` method with atomic writes
  - Ensure metadata operations don't load range data
  - Add JSON serialization/deserialization
  - Add error handling for corrupted metadata
  - _Requirements: 1.3, 2.1, 8.1_

- [ ]* 4.1 Write property test for lazy loading
  - **Property 10: Lazy Loading**
  - **Validates: Requirements 2.5**

- [ ]* 4.2 Write property test for range data separation
  - **Property 2: Range Data Separation**
  - **Validates: Requirements 1.2**

- [x] 5. Implement range lookup and overlap detection
  - Implement `find_cached_ranges()` method
  - Implement range overlap detection algorithm
  - Optimize for common cases (exact match, full containment)
  - Return all overlapping range specs
  - _Requirements: 2.2, 2.4_

- [ ]* 5.1 Write property test for range overlap detection
  - **Property 8: Range Overlap Detection**
  - **Validates: Requirements 2.4**

- [ ]* 5.2 Write property test for metadata lookup performance
  - **Property 6: Metadata Lookup Performance**
  - **Validates: Requirements 2.3**

- [x] 6. Implement range data loading
  - Implement `load_range_data()` method
  - Read binary data from range file
  - Handle decompression if needed
  - Add error handling for missing files
  - _Requirements: 2.2, 8.2_

- [x] 7. Implement full object as range handling
  - Update full object storage to use range 0-N
  - Update full object retrieval to use range operations
  - Ensure no special casing for full objects
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

- [ ]* 7.1 Write property test for full object as range
  - **Property 5: Full Object as Range**
  - **Validates: Requirements 4.1, 4.2**

- [x] 8. Implement cache cleanup and deletion
  - Implement `delete_cache_entry()` method for full object deletion
  - Implement `delete_ranges()` method for partial range eviction
  - Delete metadata file (only when all ranges deleted)
  - Delete all associated range binary files
  - Prevent orphaned files
  - Add cleanup for partial writes (`.tmp` files)
  - **CRITICAL**: Must read metadata file to get list of all `.bin` files before deletion
  - **CRITICAL**: Never delete metadata file unless all associated `.bin` files are also deleted
  - **CRITICAL**: Support partial eviction - delete specific ranges, update metadata, keep other ranges
  - **CRITICAL**: Use atomic operations - if any `.bin` file deletion fails, log warning but continue
  - **OPTIMIZATION**: Batch range deletions - when deleting multiple ranges from same object, update metadata once
  - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [ ]* 8.1 Write property test for no orphaned files
  - **Property 7: No Orphaned Files**
  - **Validates: Requirements 7.3**

- [x] 9. Update RangeHandler integration
  - Update `RangeHandler` to use new storage methods
  - Replace old `Range` struct usage with `RangeSpec`
  - Update range caching logic
  - Update range serving logic
  - Ensure backward compatibility during transition
  - _Requirements: All_

- [x] 10. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 11. Add error handling and recovery
  - Handle corrupted metadata files
  - Handle missing range binary files
  - Handle disk space exhaustion
  - Handle inconsistent metadata
  - Add metrics for error conditions
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 12. Update metrics and monitoring
  - Add `cache_metadata_parse_duration_seconds` histogram
  - Add `cache_metadata_file_size_bytes` gauge
  - Add `cache_range_file_count` gauge
  - Add `cache_range_load_duration_seconds` histogram
  - Add corruption and recovery metrics
  - Update existing cache metrics
  - _Requirements: 8.5_

- [x] 13. Update cache statistics calculation
  - Update `get_cache_statistics()` to sum metadata + range files
  - Update entry counting to count metadata files
  - Update size calculations
  - Add breakdown by range count
  - **CRITICAL**: Update `calculate_disk_cache_size()` in cache.rs to count new file types:
    - Currently only counts `.cache` files
    - Must also count `.meta` files (in objects/ directory)
    - Must also count `.bin` files (in ranges/ directory)
    - Must also count `.lock` files for accurate tracking
  - **CRITICAL**: Ensure `enforce_disk_cache_limits()` works with new architecture:
    - When evicting, must delete metadata AND all associated range files
    - Use the new `delete_cache_entry()` method from task 8
    - Never orphan `.bin` files by deleting only `.meta` files
  - **CRITICAL**: Update `collect_cache_entries_for_eviction()` to:
    - Identify cache entries by `.meta` files (not `.cache` files)
    - Calculate entry size as: metadata file + sum of all associated `.bin` files
    - Read metadata to get list of range files for accurate size calculation
    - Support granular eviction: return individual ranges as eviction candidates (not just full objects)
    - Enable eviction algorithm to choose: evict full object OR evict specific ranges
  - **OPTIMIZATION**: Implement batch eviction for ranges from same object:
    - Group ranges by cache_key when building eviction list
    - Delete all selected `.bin` files for an object
    - Update `.meta` file once (single atomic write) instead of per-range
    - Reduces I/O and improves eviction performance
  - _Requirements: All_

- [x] 14. Add comprehensive logging
  - Log metadata operations
  - Log range storage operations
  - Log error conditions and recovery
  - Log performance metrics
  - _Requirements: All_

- [ ]* 15. Write integration tests
  - Test AWS CLI CRT parallel range requests
  - Test cache hit performance (<100ms for 10MB)
  - Test concurrent access patterns
  - Test cache cleanup
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [ ]* 16. Run performance benchmarks
  - Benchmark metadata parse time (10, 100, 1000, 10000 ranges)
  - Benchmark range lookup time
  - Benchmark concurrent read throughput
  - Benchmark concurrent write throughput
  - Compare memory usage vs old architecture
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 17. Final checkpoint - Verify all requirements met
  - Ensure all tests pass, ask the user if questions arise.
