# Requirements Document: Range Storage Architecture Redesign

## Introduction

The current range caching implementation stores range data within JSON metadata files, causing severe performance issues when many ranges are cached. A single metadata file can grow to 126MB+ and take seconds to parse, defeating the purpose of caching. This redesign separates range data from metadata, storing each range in its own binary file while maintaining a lightweight metadata index.

## Glossary

- **Cache System**: The S3 proxy's caching layer that stores S3 object data locally
- **Range**: A contiguous byte sequence from an S3 object, specified by start and end offsets
- **Metadata File**: A JSON file containing object metadata and an index of cached ranges
- **Range Binary File**: A file containing the raw bytes for a specific cached range
- **Object Version**: A unique version of an S3 object identified by ETag and Last-Modified
- **Cache Entry**: The combination of metadata file and associated range binary files for an object
- **Range Spec**: A specification of a range's start offset, end offset, and storage location

## Requirements

### Requirement 1: Separate Range Data from Metadata

**User Story:** As a cache system, I want to store range data separately from metadata, so that metadata files remain small and fast to parse.

#### Acceptance Criteria

1. WHEN the Cache System stores a range, THEN the Cache System SHALL write the range bytes to a separate binary file
2. WHEN the Cache System stores a range, THEN the Cache System SHALL record the range specification in the metadata file without including the range data
3. WHEN the Cache System reads metadata, THEN the Cache System SHALL parse only the metadata JSON without loading range data
4. THE Cache System SHALL maintain metadata files under 100KB regardless of the number of cached ranges
5. THE Cache System SHALL store range binary files in a dedicated ranges directory separate from metadata files

### Requirement 2: Efficient Range Lookup

**User Story:** As a cache system, I want to quickly determine which ranges are cached, so that I can serve requests efficiently.

#### Acceptance Criteria

1. WHEN the Cache System receives a range request, THEN the Cache System SHALL read only the metadata file to determine available ranges
2. WHEN the Cache System identifies overlapping cached ranges, THEN the Cache System SHALL load only the necessary range binary files
3. THE Cache System SHALL complete range availability checks in under 10 milliseconds for objects with hundreds of cached ranges
4. WHEN multiple ranges overlap a request, THEN the Cache System SHALL identify all overlapping ranges in a single metadata read
5. THE Cache System SHALL avoid loading range data until it is needed to serve a response

### Requirement 3: Atomic Range Storage

**User Story:** As a cache system, I want to store ranges atomically, so that concurrent requests don't corrupt cache data.

#### Acceptance Criteria

1. WHEN the Cache System writes a range binary file, THEN the Cache System SHALL use atomic file operations to prevent partial writes
2. WHEN the Cache System updates the metadata file, THEN the Cache System SHALL use atomic file operations to prevent corruption
3. WHEN multiple requests cache different ranges concurrently, THEN the Cache System SHALL prevent lost updates to the metadata file (all ranges must be recorded)
4. WHEN a range write fails, THEN the Cache System SHALL leave the cache in a consistent state without orphaned files
5. THE Cache System SHALL ensure that a range is only visible in metadata after its binary file is successfully written

### Requirement 4: Unified Object and Range Handling

**User Story:** As a cache system, I want to treat full objects as ranges, so that I have a consistent storage model.

#### Acceptance Criteria

1. WHEN the Cache System caches a full object, THEN the Cache System SHALL store it as a range from 0 to content-length
2. WHEN the Cache System serves a full object request, THEN the Cache System SHALL treat it as a range request for bytes 0-N
3. THE Cache System SHALL use the same storage format for full objects and partial ranges
4. WHEN the Cache System has a full object cached, THEN the Cache System SHALL serve any range request from that single range file
5. THE Cache System SHALL not distinguish between "full object" and "range" cache entries in its storage model

### Requirement 5: Metadata File Structure

**User Story:** As a cache system, I want a well-defined metadata structure, so that I can efficiently track cached ranges.

#### Acceptance Criteria

1. THE Cache System SHALL store one metadata file per unique object version (ETag + Last-Modified)
2. WHEN the Cache System creates a metadata file, THEN the Cache System SHALL include object metadata (ETag, Last-Modified, Content-Length, Content-Type)
3. WHEN the Cache System creates a metadata file, THEN the Cache System SHALL include a ranges array with start, end, and file path for each cached range
4. WHEN the Cache System creates a metadata file, THEN the Cache System SHALL include cache expiration timestamps
5. THE Cache System SHALL serialize metadata files as compact JSON without embedded binary data

### Requirement 6: Range Binary File Naming

**User Story:** As a cache system, I want predictable range file names, so that I can locate and manage range files efficiently.

#### Acceptance Criteria

1. WHEN the Cache System creates a range binary file, THEN the Cache System SHALL name it using the pattern: `{sanitized_cache_key}_{start}-{end}.bin`
2. WHEN the Cache System sanitizes a cache key, THEN the Cache System SHALL replace special characters with safe alternatives
3. THE Cache System SHALL ensure range binary file names are unique within the ranges directory
4. WHEN the Cache System needs to locate a range file, THEN the Cache System SHALL derive the file path from the metadata range spec
5. THE Cache System SHALL store all range binary files in a flat directory structure under `cache_dir/ranges/`

### Requirement 7: Cache Cleanup and Expiration

**User Story:** As a cache system, I want to clean up expired ranges efficiently, so that disk space is reclaimed properly.

#### Acceptance Criteria

1. WHEN the Cache System expires a cache entry, THEN the Cache System SHALL delete the metadata file and all associated range binary files
2. WHEN the Cache System deletes a metadata file, THEN the Cache System SHALL identify all range binary files from the ranges array
3. THE Cache System SHALL prevent orphaned range binary files when cache entries are deleted
4. WHEN the Cache System performs cache cleanup, THEN the Cache System SHALL remove both metadata and range files for expired entries
5. THE Cache System SHALL log warnings for any orphaned range files discovered during cleanup

### Requirement 8: Error Handling and Recovery

**User Story:** As a cache system, I want robust error handling, so that cache corruption doesn't cause proxy failures.

#### Acceptance Criteria

1. WHEN the Cache System encounters a corrupted metadata file, THEN the Cache System SHALL log an error and treat the entry as a cache miss
2. WHEN the Cache System cannot read a range binary file, THEN the Cache System SHALL fetch the range from S3 and attempt to recache it
3. WHEN the Cache System finds a metadata file without corresponding range files, THEN the Cache System SHALL treat missing ranges as uncached
4. WHEN the Cache System detects inconsistencies, THEN the Cache System SHALL continue serving requests without crashing
5. THE Cache System SHALL provide metrics for cache corruption and recovery events

### Requirement 9: Performance Requirements

**User Story:** As a cache system, I want excellent performance, so that caching provides significant speed improvements.

#### Acceptance Criteria

1. WHEN the Cache System serves a cached range, THEN the Cache System SHALL complete the request in under 100 milliseconds for ranges up to 10MB
2. WHEN the Cache System checks for cached ranges, THEN the Cache System SHALL complete metadata parsing in under 10 milliseconds
3. THE Cache System SHALL support concurrent range reads without lock contention
4. WHEN the Cache System writes ranges concurrently, THEN the Cache System SHALL achieve at least 80% of single-threaded write throughput
5. THE Cache System SHALL maintain sub-second response times for range requests even with thousands of cached ranges per object

### Requirement 10: Resource Scalability

**User Story:** As a system operator, I want the proxy to scale efficiently across different deployment sizes, so that I can run it on anything from a laptop to a large distributed cluster.

#### Acceptance Criteria

1. WHEN the Cache System runs on a laptop deployment, THEN the Cache System SHALL consume less than 500MB RAM, utilize 1-2 CPU cores, and operate within 10GB disk space
2. WHEN the Cache System runs on a small server deployment, THEN the Cache System SHALL scale to utilize up to 16GB RAM, 8 CPU cores, and 1TB disk space
3. WHEN the Cache System runs on a large server deployment, THEN the Cache System SHALL scale to utilize up to 64GB RAM, 24 CPU cores, and 100TB disk space
4. WHEN the Cache System runs in a scale-out deployment, THEN the Cache System SHALL coordinate across 2-20 instances sharing 1PB disk storage
5. THE Cache System SHALL automatically adjust resource usage based on available system resources without manual tuning
6. THE Cache System SHALL maintain consistent performance characteristics across all deployment sizes
7. WHEN the Cache System operates in a multi-instance deployment, THEN the Cache System SHALL coordinate cache operations to prevent conflicts and duplication
8. THE Cache System SHALL provide configuration options to limit resource consumption for each deployment size
