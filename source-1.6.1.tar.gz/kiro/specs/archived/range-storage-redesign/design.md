# Design Document: Range Storage Architecture Redesign

## Overview

This design addresses a critical performance issue in the current range caching implementation where range data is stored within JSON metadata files, causing them to grow to 126MB+ and take seconds to parse. The redesign separates range data from metadata, storing each range in its own binary file while maintaining a lightweight metadata index.

The new architecture treats all cached data uniformly as ranges (including full objects), eliminates the distinction between "full object" and "range" cache entries, and enables efficient concurrent access to cached ranges without lock contention or metadata bloat.

## Architecture

### Current Architecture Problems

1. **Metadata Bloat**: Range data (`Vec<u8>`) is stored in the `Range` struct within JSON metadata files
2. **Parse Performance**: 126MB JSON files take seconds to deserialize
3. **Memory Pressure**: Loading metadata requires loading all range data into memory
4. **Write Conflicts**: Updating metadata requires rewriting the entire file
5. **Inefficient Lookups**: Must parse entire metadata file to check which ranges exist

### New Architecture

```
cache_dir/
  objects/
    {sanitized_key}.meta          # Lightweight JSON metadata
  ranges/
    {sanitized_key}_0-8388607.bin      # Raw range bytes
    {sanitized_key}_8388608-16777215.bin
    {sanitized_key}_16777216-25165823.bin
```

### Key Principles

1. **Everything is a Range**: Full objects are stored as range 0-N, no special cases
2. **Separate Data from Metadata**: Range bytes live in `.bin` files, metadata in `.meta` files
3. **Atomic Operations**: Each range writes to its own file, preventing conflicts
4. **Lazy Loading**: Load only the metadata and range files needed for each request
5. **Single Source of Truth**: One `.meta` file per object tracks all cached ranges

## Components and Interfaces

### 1. Metadata File Structure

```rust
/// Lightweight metadata file (objects/{key}.meta)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheMetadata {
    pub cache_key: String,
    pub object_metadata: ObjectMetadata,
    pub ranges: Vec<RangeSpec>,
    pub created_at: SystemTime,
    pub expires_at: SystemTime,
    pub compression_info: CompressionInfo,
}

/// Object-level metadata
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectMetadata {
    pub etag: String,
    pub last_modified: String,
    pub content_length: u64,
    pub content_type: Option<String>,
    pub version_id: Option<String>,
}

/// Range specification (no data, just pointers)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RangeSpec {
    pub start: u64,
    pub end: u64,
    pub file_path: String,  // Relative path to .bin file
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
}
```

### 2. Range Binary Files

- **Location**: `cache_dir/ranges/{sanitized_key}_{start}-{end}.bin`
- **Format**: Raw bytes (optionally compressed)
- **Naming**: Deterministic based on cache key and range boundaries
- **Atomicity**: Written to `.tmp` file then renamed

### 3. Metadata File Locking

To prevent lost updates during concurrent range storage operations, metadata updates use file-based locking:

- **Lock File**: `cache_dir/objects/{sanitized_key}.meta.lock`
- **Lock Type**: Exclusive (write) lock using `fs2::FileExt::lock_exclusive()`
- **Lock Scope**: Held during entire metadata update operation:
  1. Read existing metadata
  2. Modify metadata in memory (add/update range spec)
  3. Write to temporary file
  4. Atomic rename
- **Lock Release**: Automatic on success or error (via explicit unlock or file close)

**Why Both Locking AND Write-to-Temp?**
- **File Locking**: Prevents lost updates from concurrent modifications (isolation)
- **Write-to-Temp-Then-Rename**: Prevents corruption from crashes/partial writes (atomicity)

Both mechanisms are necessary for correct concurrent operation.

### 4. Cache Manager Interface

```rust
impl CacheManager {
    /// Store a range (including full objects as range 0-N)
    /// Uses file locking to prevent lost updates during concurrent writes
    pub async fn store_range(
        &self,
        cache_key: &str,
        start: u64,
        end: u64,
        data: &[u8],
        object_metadata: ObjectMetadata,
    ) -> Result<()>;
    
    /// Find which cached ranges overlap with requested range
    pub async fn find_cached_ranges(
        &self,
        cache_key: &str,
        requested_start: u64,
        requested_end: u64,
    ) -> Result<Vec<RangeSpec>>;
    
    /// Load range data from binary file
    pub async fn load_range_data(
        &self,
        range_spec: &RangeSpec,
    ) -> Result<Vec<u8>>;
    
    /// Get metadata without loading range data
    pub async fn get_metadata(
        &self,
        cache_key: &str,
    ) -> Result<Option<CacheMetadata>>;
    
    /// Delete cache entry (metadata + all range files)
    pub async fn delete_cache_entry(
        &self,
        cache_key: &str,
    ) -> Result<()>;
}
```

### 5. File Path Generation

```rust
impl CacheManager {
    /// Generate metadata file path
    fn get_metadata_file_path(&self, cache_key: &str) -> PathBuf {
        let sanitized = self.sanitize_cache_key(cache_key);
        self.cache_dir.join("objects").join(format!("{}.meta", sanitized))
    }
    
    /// Generate range binary file path
    fn get_range_file_path(&self, cache_key: &str, start: u64, end: u64) -> PathBuf {
        let sanitized = self.sanitize_cache_key(cache_key);
        self.cache_dir.join("ranges").join(format!("{}_{}-{}.bin", sanitized, start, end))
    }
    
    /// Sanitize cache key for filesystem
    fn sanitize_cache_key(&self, cache_key: &str) -> String {
        cache_key
            .replace(':', "_colon_")
            .replace('/', "_slash_")
            .replace('?', "_question_")
            .replace('&', "_amp_")
            .replace('=', "_eq_")
    }
}
```

## Data Models

### Current Range Struct (To Be Replaced)

```rust
pub struct Range {
    pub start: u64,
    pub end: u64,
    pub data: Vec<u8>,  // ❌ This causes metadata bloat
    pub version_id: Option<String>,
    pub etag: String,
    pub last_modified: String,
    pub compression_algorithm: CompressionAlgorithm,
}
```

### New Range Spec (Metadata Only)

```rust
pub struct RangeSpec {
    pub start: u64,
    pub end: u64,
    pub file_path: String,  // ✅ Pointer to .bin file
    pub compression_algorithm: CompressionAlgorithm,
    pub compressed_size: u64,
    pub uncompressed_size: u64,
}
```

### Read Flow

```
Request: GET /bucket/object bytes=0-8388607
    ↓
1. Check metadata: objects/host_bucket_object.meta
    ↓
2. Find overlapping ranges in metadata.ranges[]
    ↓
3. Load only needed .bin files:
   - ranges/host_bucket_object_0-8388607.bin
    ↓
4. Decompress if needed
    ↓
5. Serve response
```

### Write Flow (with Locking)

```
Store range: bytes=0-8388607
    ↓
1. Compress range data
    ↓
2. Write to: ranges/host_bucket_object_0-8388607.bin.tmp
    ↓
3. Atomic rename: .bin.tmp → .bin
    ↓
4. Acquire exclusive lock: objects/host_bucket_object.meta.lock
    ↓
5. Read existing metadata (or create new)
    ↓
6. Add/update range spec in metadata.ranges[]
    ↓
7. Write to: objects/host_bucket_object.meta.tmp
    ↓
8. Atomic rename: .meta.tmp → .meta
    ↓
9. Release lock
    ↓
Done (both range file and metadata updated atomically)
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Metadata Size Efficiency

*For any* cache entry, the metadata file size SHALL be O(n) where n is the number of ranges, with each range spec consuming approximately 150-200 bytes in JSON format. For practical limits: 100 ranges ≈ 20KB, 1000 ranges ≈ 200KB, 10000 ranges ≈ 2MB.

**Validates: Requirements 1.4**

**Rationale**: A `RangeSpec` in JSON contains:
- `start`: ~10 bytes ("1234567890")
- `end`: ~10 bytes
- `file_path`: ~80 bytes (sanitized key + range)
- `compression_algorithm`: ~10 bytes
- `compressed_size`: ~10 bytes
- `uncompressed_size`: ~10 bytes
- JSON overhead: ~30 bytes (quotes, commas, braces)
Total: ~150-200 bytes per range

This is a 1000x improvement over storing range data in metadata (which was ~1.26MB per range for 10MB ranges).

### Property 2: Range Data Separation

*For any* stored range, the range bytes SHALL NOT appear in the metadata JSON file.

**Validates: Requirements 1.2**

### Property 3: Atomic Range Storage

*For any* range write operation, either both the binary file and metadata entry exist, or neither exists (no partial state).

**Validates: Requirements 3.1, 3.4**

### Property 4: Deterministic File Paths

*For any* cache key and range boundaries, the generated file path SHALL be identical across multiple invocations.

**Validates: Requirements 6.2, 6.4**

### Property 5: Full Object as Range

*For any* full object request, the cached data SHALL be stored as a single range from 0 to content-length.

**Validates: Requirements 4.1, 4.2**

### Property 6: Metadata Lookup Performance

*For any* cache entry with up to 1000 cached ranges, checking range availability SHALL complete in under 10 milliseconds. For entries with 10000+ ranges, lookup time SHALL scale linearly (O(n)) and remain under 100 milliseconds.

**Validates: Requirements 2.3**

**Rationale**: Parsing 200KB of JSON and iterating through 1000 range specs should take <10ms on modern hardware. For extreme cases (10000 ranges = 2MB JSON), we accept up to 100ms as this is still 20x faster than the current 2+ second parse times.

### Property 7: No Orphaned Files

*For any* cache entry deletion, all associated range binary files SHALL be deleted along with the metadata file.

**Validates: Requirements 7.3**

### Property 8: Range Overlap Detection

*For any* requested range and set of cached ranges, the system SHALL correctly identify all overlapping cached ranges.

**Validates: Requirements 2.4**

### Property 9: Concurrent Write Safety

*For any* two concurrent range write operations with different range boundaries, neither operation SHALL corrupt the other's data.

**Validates: Requirements 3.3**

### Property 10: Lazy Loading

*For any* metadata read operation, range binary data SHALL NOT be loaded into memory.

**Validates: Requirements 2.5**

## Error Handling

### Corrupted Metadata File

- **Detection**: JSON parse failure
- **Recovery**: Log error, treat as cache miss, delete corrupted file
- **Metric**: `cache_corruption_metadata_total`

### Missing Range Binary File

- **Detection**: File not found when loading range data
- **Recovery**: Fetch range from S3, attempt to recache
- **Metric**: `cache_corruption_missing_range_total`

### Partial Write Failure

- **Detection**: `.tmp` file exists without corresponding final file
- **Recovery**: Delete `.tmp` file during cleanup
- **Metric**: `cache_partial_write_cleanup_total`

### Disk Space Exhaustion

- **Detection**: Write operation fails with "No space left on device"
- **Recovery**: Trigger emergency cache eviction, retry write
- **Metric**: `cache_disk_full_events_total`

### Inconsistent Metadata

- **Detection**: Metadata references range file that doesn't exist
- **Recovery**: Remove range spec from metadata, continue serving other ranges
- **Metric**: `cache_inconsistency_fixed_total`

## Testing Strategy

### Unit Tests

1. **Metadata Serialization**: Verify metadata files serialize/deserialize correctly
2. **File Path Generation**: Test sanitization and path generation
3. **Range Overlap Detection**: Test various overlap scenarios
4. **Atomic Write Operations**: Verify tmp file creation and rename
5. **Error Recovery**: Test handling of corrupted files

### Property-Based Tests

The testing strategy uses property-based testing (PBT) to verify correctness properties across a wide range of inputs. We'll use the `proptest` crate for Rust.

**Configuration**:
- Minimum 100 iterations per property test
- Each test tagged with format: `**Feature: range-storage-redesign, Property {N}: {description}**`

**Property Tests**:

1. **Property 1: Metadata Size Efficiency**
   - Generate random cache entries with 1-10000 ranges
   - Serialize to JSON
   - Assert size ≈ n * 200 bytes (within 20% tolerance)
   - Assert 100 ranges < 25KB, 1000 ranges < 250KB, 10000 ranges < 2.5MB

2. **Property 2: Range Data Separation**
   - Generate random ranges with data
   - Store using new architecture
   - Parse metadata JSON
   - Assert no binary data in JSON

3. **Property 3: Atomic Range Storage**
   - Store range
   - Check both .meta and .bin exist or neither exists
   - Never partial state

4. **Property 4: Deterministic File Paths**
   - Generate random cache keys and ranges
   - Call path generation multiple times
   - Assert identical paths

5. **Property 5: Full Object as Range**
   - Store full objects
   - Verify stored as range 0-N
   - Verify retrievable as full object or any sub-range

6. **Property 6: Metadata Lookup Performance**
   - Create entries with 1-1000 ranges
   - Time metadata read operations
   - Assert < 10ms for ≤1000 ranges
   - Create entries with 10000 ranges
   - Assert < 100ms for 10000 ranges

7. **Property 7: No Orphaned Files**
   - Store multiple ranges
   - Delete cache entry
   - Assert no .bin files remain

8. **Property 8: Range Overlap Detection**
   - Generate random cached ranges
   - Generate random requested range
   - Verify all overlaps detected correctly

9. **Property 9: Concurrent Write Safety**
   - Spawn concurrent writes for different ranges
   - Verify all ranges stored correctly
   - No corruption

10. **Property 10: Lazy Loading**
    - Read metadata
    - Monitor memory usage
    - Assert range data not loaded

### Integration Tests

1. **AWS CLI Compatibility**: Test with AWS CLI CRT parallel range requests
2. **Cache Hit Performance**: Verify <100ms for 10MB cached ranges
3. **Concurrent Access**: Multiple clients requesting overlapping ranges
4. **Cache Cleanup**: Verify expired entries and orphaned files removed
5. **Migration**: Test transition from old to new format (if needed)

### Performance Benchmarks

1. **Metadata Parse Time**: Measure with 10, 100, 1000 ranges
2. **Range Lookup Time**: Measure overlap detection performance
3. **Concurrent Read Throughput**: Multiple clients reading different ranges
4. **Concurrent Write Throughput**: Multiple clients caching different ranges
5. **Memory Usage**: Compare old vs new architecture

## Implementation Notes

### Phase 1: New Storage Layer

1. Implement new `RangeSpec` struct
2. Implement `CacheMetadata` struct
3. Implement file path generation and sanitization
4. Implement atomic range storage (write to .tmp, rename)
5. Implement metadata read/write operations

### Phase 2: Range Operations

1. Implement `store_range()` method
2. Implement `find_cached_ranges()` method
3. Implement `load_range_data()` method
4. Implement range overlap detection
5. Implement concurrent write safety

### Phase 3: Integration

1. Update `RangeHandler` to use new storage
2. Update cache cleanup to handle new format
3. Update metrics and monitoring
4. Update cache statistics calculation
5. Add logging for new operations

### Phase 4: Testing & Validation

1. Implement property-based tests
2. Run performance benchmarks
3. Test with AWS CLI
4. Validate cache hit rates
5. Stress test concurrent access

### Backward Compatibility

Since we're removing Requirement 8 (migration), we'll implement a clean cutover:

1. **Clear Cache on Upgrade**: Document that cache will be cleared on upgrade
2. **Version Detection**: Add version marker to new metadata format
3. **Graceful Degradation**: If old format detected, log warning and treat as cache miss

### Critical Implementation Requirements

#### Disk Usage Tracking

The existing `CacheManager::calculate_disk_cache_size()` method in `cache.rs` currently only counts files with `.cache` extension. This **must** be updated to include:

- `.meta` files (metadata in `objects/` directory)
- `.bin` files (range data in `ranges/` directory)  
- `.lock` files (for accurate tracking)

**Without this update, the new range storage will consume untracked disk space, cache limits will be ineffective, and the system could fill the disk without triggering eviction.**

#### Cache Eviction with New Architecture

The existing `CacheManager::enforce_disk_cache_limits()` and `collect_cache_entries_for_eviction()` methods must be updated:

1. **Entry Identification**: Identify cache entries by `.meta` files (not `.cache` files)
2. **Size Calculation**: Calculate entry size as metadata file + sum of all associated `.bin` files
3. **Granular vs Full Eviction**: Support two eviction strategies:
   - **Full Object Eviction**: Delete entire cache entry (metadata + all ranges) - use `delete_cache_entry()`
   - **Partial Range Eviction**: Delete only specific ranges while keeping others:
     - Delete selected `.bin` files
     - Update `.meta` file to remove evicted ranges from the ranges array
     - Keep metadata file if any ranges remain
     - Only delete metadata file when last range is evicted
4. **Batch Optimization**: When evicting multiple ranges from same object:
   - Collect all ranges to evict for that object
   - Delete all `.bin` files first
   - Update `.meta` file once (single atomic write) to remove all evicted ranges
   - Reduces metadata file writes and improves performance
5. **Atomic Operations**: 
   - **Never delete metadata without deleting associated range files** (prevents orphaned data)
   - **Never leave orphaned `.bin` files** (always update metadata to reflect deletions)
   - If any `.bin` file deletion fails, log warning but continue (best effort cleanup)
   - If metadata update fails after deleting `.bin` files, log error (creates orphans but preserves cache consistency)

#### File Deletion Order

**Critical**: Always delete in this order:
1. Read `.meta` file to get list of all `.bin` files
2. Delete all `.bin` files (best effort - log failures but continue)
3. Delete `.meta` file last (only after attempting to delete all range files)

This ensures we never have orphaned `.bin` files without metadata pointing to them.

## Performance Targets

| Metric | Current | Target | Improvement |
|--------|---------|--------|-------------|
| Metadata parse time (100 ranges) | ~2000ms | <10ms | 200x |
| Metadata file size (100 ranges) | ~126MB | <25KB | 5000x |
| Metadata file size (1000 ranges) | ~1.26GB | <250KB | 5000x |
| Metadata file size (10000 ranges) | ~12.6GB | <2.5MB | 5000x |
| Cache hit latency (10MB) | ~2400ms | <100ms | 24x |
| Concurrent write throughput | Low (lock contention) | High (no contention) | 10x+ |
| Memory usage (metadata) | ~126MB | <250KB | 500x |

## Monitoring and Metrics

### New Metrics

- `cache_metadata_parse_duration_seconds`: Histogram of metadata parse times
- `cache_metadata_file_size_bytes`: Gauge of metadata file sizes
- `cache_range_file_count`: Gauge of range binary files per object
- `cache_range_load_duration_seconds`: Histogram of range data load times
- `cache_corruption_metadata_total`: Counter of corrupted metadata files
- `cache_corruption_missing_range_total`: Counter of missing range files
- `cache_inconsistency_fixed_total`: Counter of fixed inconsistencies
- `cache_orphaned_files_cleaned_total`: Counter of orphaned files removed

### Existing Metrics to Update

- `cache_hits_total`: Continue tracking
- `cache_misses_total`: Continue tracking
- `cache_size_bytes`: Update to sum metadata + range files
- `cache_entries_total`: Count metadata files

## Security Considerations

1. **Path Traversal**: Sanitize cache keys to prevent directory traversal attacks
2. **Disk Space**: Implement quotas to prevent disk exhaustion
3. **File Permissions**: Set appropriate permissions on cache files (0600)
4. **Symlink Attacks**: Verify files are regular files, not symlinks
5. **Race Conditions**: Use atomic operations to prevent TOCTOU vulnerabilities

## Eviction Strategies

### Full Object vs Granular Range Eviction

The new architecture enables two eviction approaches:

#### Full Object Eviction
- **When**: Object has few ranges (≤3) or aggressive cleanup needed
- **How**: Delete entire cache entry (metadata + all ranges)
- **Pros**: Simple, single metadata deletion, no metadata churn
- **Cons**: Loses all cached data for object, even frequently accessed ranges

#### Granular Range Eviction
- **When**: Object has many ranges (>3) and want to preserve partial cache
- **How**: Delete specific cold ranges, update metadata, keep hot ranges
- **Pros**: Preserves frequently accessed ranges, better cache hit rate
- **Cons**: More complex, requires metadata updates

#### Hybrid Approach (Recommended)

```
For each object being considered for eviction:
  if ranges.len() <= 3:
    evict_full_object()  // Avoid metadata churn
  else:
    identify_cold_ranges()  // Based on LRU/LFU
    batch_delete_ranges()   // Single metadata update
```

### Batch Optimization

When evicting multiple ranges:

```
// Group ranges by object
ranges_by_object = group_by_cache_key(ranges_to_evict)

for (cache_key, ranges) in ranges_by_object:
  delete_ranges(cache_key, ranges)  // Single metadata update per object
```

**Performance Impact**:
- Without batching: 100 ranges from 10 objects = 100 metadata writes
- With batching: 100 ranges from 10 objects = 10 metadata writes
- 10x reduction in I/O operations

### Eviction Algorithm Integration

The existing eviction algorithms (LRU, LFU, TinyLFU) can work at two levels:

1. **Object-level**: Rank entire cache entries for eviction
2. **Range-level**: Rank individual ranges within objects for eviction

**Recommendation**: Use range-level eviction for objects with >3 ranges, object-level for others.

## Future Enhancements

1. **Range Merging**: Automatically merge adjacent ranges to reduce file count
2. **Compression Optimization**: Per-range compression based on content type
3. **Tiered Storage**: Hot ranges in RAM, warm on SSD, cold on HDD
4. **Distributed Cache**: Share range metadata across proxy instances
5. **Smart Prefetching**: Predict and prefetch likely-needed ranges
6. **Adaptive Eviction**: Automatically choose between full object and granular range eviction based on access patterns
