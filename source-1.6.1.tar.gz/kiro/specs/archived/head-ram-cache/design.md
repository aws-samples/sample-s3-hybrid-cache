# HEAD RAM Cache Design Document

## Overview

This design extends the existing RAM cache system to support HEAD request caching, providing faster metadata access by leveraging in-memory storage. The implementation follows the established patterns used for GET request caching while accounting for the unique characteristics of HEAD requests (metadata-only, no ranges, simpler cache keys).

The design integrates HEAD caching into the existing two-tier cache architecture (RAM + disk) while maintaining backward compatibility with the current disk-based HEAD cache system. HEAD requests will benefit from sub-millisecond response times when served from RAM cache, significantly improving metadata query performance.

## Architecture

### Current State
- HEAD requests are cached only on disk in a separate `head_cache/` directory
- GET requests use both RAM cache and disk cache with range support
- RAM cache uses complex cache keys with range information for GET requests
- Access tracking and coherency systems exist for GET cache synchronization

### Target State
- HEAD requests will use both RAM cache and disk cache
- HEAD RAM cache entries use simple cache keys (no range suffixes)
- Simplified access tracking for HEAD entries (no range information)
- Unified cache management across both GET and HEAD request types
- Backward compatibility maintained with existing disk HEAD cache

### Integration Points
1. **HTTP Proxy Layer**: Modify HEAD request handling to check RAM cache first
2. **Cache Manager**: Extend with HEAD-specific RAM cache methods
3. **RAM Cache**: Add HEAD entry support with simplified key handling
4. **Access Tracking**: Implement HEAD-specific access statistics
5. **Metrics System**: Include HEAD entries in RAM cache statistics

## Components and Interfaces

### 1. HeadRamCacheEntry Structure
```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HeadRamCacheEntry {
    pub cache_key: String,
    pub headers: HashMap<String, String>,
    pub metadata: CacheMetadata,
    pub created_at: SystemTime,
    pub last_accessed: SystemTime,
    pub access_count: u64,
    pub expires_at: SystemTime,
}
```

### 2. CacheManager Extensions
```rust
impl CacheManager {
    // HEAD RAM cache operations
    pub async fn get_head_from_ram_cache(&self, cache_key: &str) -> Result<Option<HeadRamCacheEntry>>;
    pub async fn store_head_in_ram_cache(&self, entry: HeadRamCacheEntry) -> Result<()>;
    pub async fn remove_head_from_ram_cache(&self, cache_key: &str) -> Result<()>;
    
    // Unified HEAD cache operations (RAM + disk)
    pub async fn get_head_cache_entry_unified(&self, cache_key: &str) -> Result<Option<HeadCacheEntry>>;
    pub async fn store_head_cache_entry_unified(&self, cache_key: &str, headers: HashMap<String, String>, metadata: CacheMetadata) -> Result<()>;
    pub async fn invalidate_head_cache_entry_unified(&self, cache_key: &str) -> Result<()>;
}
```

### 3. RAM Cache Extensions
```rust
impl RamCache {
    // HEAD-specific methods
    pub fn get_head(&mut self, cache_key: &str) -> Option<HeadRamCacheEntry>;
    pub fn put_head(&mut self, entry: HeadRamCacheEntry) -> Result<()>;
    pub fn remove_head(&mut self, cache_key: &str) -> Option<HeadRamCacheEntry>;
    
    // Unified TTL-aware eviction for both GET and HEAD entries
    pub fn find_expired_entries(&self) -> Vec<String>;
    pub fn evict_expired_entries(&mut self) -> Result<u64>;
    
    // Unified invalidation across cache types
    pub fn invalidate_entry(&mut self, cache_key: &str) -> Result<()>;
    
    // HEAD access tracking (simplified - no ranges)
    pub fn record_head_access(&mut self, cache_key: &str);
    pub fn should_verify_head(&self, cache_key: &str) -> bool;
    pub fn record_head_verification(&mut self, cache_key: &str);
}
```

### 4. Access Tracking for HEAD Entries
```rust
#[derive(Debug, Clone)]
pub struct HeadAccessStats {
    pub access_count_delta: u64,
    pub last_accessed: SystemTime,
}

#[derive(Debug, Clone)]
pub struct HeadPendingUpdate {
    pub cache_key: String,
    pub access_stats: HeadAccessStats,
    pub first_access: SystemTime,
}
```

## Data Models

### Cache Key Format
- **GET requests**: `path:range:start:end` (existing)
- **HEAD requests**: `path` (simple, no range suffix)

### Memory Layout
```rust
// RAM cache storage separation
pub struct RamCacheInner {
    // Existing GET cache entries (with ranges)
    pub entries: HashMap<String, RamCacheEntry>,
    
    // New HEAD cache entries (no ranges)
    pub head_entries: HashMap<String, HeadRamCacheEntry>,
    
    // Unified tracking structures
    pub lru_order: VecDeque<String>,  // Contains both GET and HEAD keys
    pub tinylfu_window: VecDeque<String>,
    pub tinylfu_frequencies: HashMap<String, u64>,
    
    // Separate access tracking for HEAD entries
    pub head_access_tracker: HeadAccessTracker,
}
```

### Size Calculation
HEAD entries are typically small (headers only), so compression is not applied:
```rust
fn calculate_head_entry_size(entry: &HeadRamCacheEntry) -> u64 {
    let base_size = std::mem::size_of::<HeadRamCacheEntry>() as u64;
    let key_size = entry.cache_key.len() as u64;
    let headers_size: u64 = entry.headers.iter()
        .map(|(k, v)| k.len() + v.len())
        .sum::<usize>() as u64;
    let metadata_size = std::mem::size_of::<CacheMetadata>() as u64;
    
    base_size + key_size + headers_size + metadata_size
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: RAM cache priority for HEAD requests
*For any* HEAD request to a cached object, the system should check RAM cache before checking disk cache
**Validates: Requirements 1.1**

### Property 2: Dual storage for HEAD responses
*For any* HEAD response received from S3, the system should store the response in both RAM cache and disk HEAD cache
**Validates: Requirements 1.2**

### Property 3: RAM cache hit serves without disk access
*For any* HEAD cache entry that exists in RAM, the system should return cached headers without accessing disk
**Validates: Requirements 1.3**

### Property 4: Eviction preserves disk cache
*For any* HEAD cache entry evicted from RAM, the entry should remain available in disk HEAD cache
**Validates: Requirements 1.4**

### Property 5: Graceful RAM cache disable fallback
*For any* system configuration with RAM cache disabled, HEAD requests should continue working using disk HEAD cache
**Validates: Requirements 1.5**

### Property 6: Unified TTL-aware eviction priority
*For any* RAM cache at capacity, expired entries (both GET and HEAD) should be evicted first, then non-expired entries using the configured eviction algorithm (LRU or TinyLFU)
**Validates: Requirements 2.1, 2.2**

### Property 7: TTL expiration behavior
*For any* HEAD cache entry with expired TTL, the system should remove it from RAM cache and return cache miss
**Validates: Requirements 2.2**

### Property 8: TTL consistency across layers
*For any* HEAD TTL configuration, both RAM and disk HEAD cache entries should have the same expiration time
**Validates: Requirements 2.3**

### Property 9: Path-specific TTL application
*For any* TTL override configuration, HEAD cache entries should use path-specific TTL values in RAM cache
**Validates: Requirements 2.4**

### Property 10: Statistics inclusion
*For any* cache statistics request, HEAD entries should be included in RAM cache metrics
**Validates: Requirements 2.5**

### Property 11: Dual invalidation
*For any* cache invalidation trigger, HEAD entries should be removed from both RAM and disk caches
**Validates: Requirements 3.1**

### Property 12: Statistics calculation accuracy
*For any* cache statistics collection, HEAD entries should be counted in RAM cache size and hit rate calculations
**Validates: Requirements 3.2**

### Property 13: Maintenance operation inclusion
*For any* cache maintenance run, HEAD entries should be included in eviction and cleanup operations
**Validates: Requirements 3.3**

### Property 14: Cache coherency verification
*For any* cache coherency check, HEAD entries should be verified between RAM and disk caches
**Validates: Requirements 3.4**

### Property 15: Cache miss fallback behavior
*For any* HEAD request that misses RAM cache, the system should check disk cache and log the cache layer used
**Validates: Requirements 4.2**

### Property 16: Separate hit rate tracking
*For any* cache hit rate calculation, HEAD cache hit rates should be tracked separately for RAM and disk layers
**Validates: Requirements 4.4**

### Property 17: Memory usage inclusion
*For any* memory usage monitoring, HEAD entries should be included in RAM cache utilization metrics
**Validates: Requirements 4.5**

### Property 18: Dual persistence behavior
*For any* HEAD RAM cache enabled configuration, the system should continue writing to disk HEAD cache for persistence
**Validates: Requirements 5.1**

### Property 19: Disable fallback behavior
*For any* HEAD RAM cache disabled configuration, the system should fall back to disk HEAD cache without errors
**Validates: Requirements 5.2**

### Property 20: Backward compatibility
*For any* existing HEAD cache files, the system should continue reading them when RAM cache misses
**Validates: Requirements 5.3**

### Property 21: Unified invalidation
*For any* HEAD cache invalidation, both RAM and disk HEAD cache entries should be invalidated
**Validates: Requirements 5.4**

### Property 22: TTL refresh synchronization
*For any* HEAD cache TTL refresh, both RAM and disk HEAD cache entries should be updated
**Validates: Requirements 5.5**

### Property 23: Essential data storage
*For any* HEAD entry stored in RAM, only essential metadata and headers should be stored
**Validates: Requirements 6.1**

### Property 24: No compression application
*For any* HEAD entry storage, compression should not be applied since HEAD responses are typically small
**Validates: Requirements 6.2**

### Property 25: Direct header retrieval
*For any* HEAD entry retrieved from RAM, headers should be returned directly without decompression
**Validates: Requirements 6.3**

### Property 26: Memory accounting accuracy
*For any* HEAD entry eviction, actual entry size should be accounted for in memory calculations
**Validates: Requirements 6.4**

### Property 27: Overhead inclusion in utilization
*For any* memory usage calculation, HEAD entry overhead should be included in RAM cache utilization
**Validates: Requirements 6.5**

### Property 28: Access statistics recording
*For any* HEAD entry accessed in RAM cache, access statistics should be recorded for disk metadata updates
**Validates: Requirements 7.1**

### Property 29: Flush threshold behavior
*For any* HEAD cache access tracking that reaches flush threshold, disk HEAD cache metadata should be updated with access counts
**Validates: Requirements 7.2**

### Property 30: Eviction flush behavior
*For any* HEAD entry evicted from RAM, pending access statistics should be flushed to disk cache
**Validates: Requirements 7.3**

### Property 31: Periodic flush behavior
*For any* periodic flush interval occurrence, disk HEAD cache should be batch updated with accumulated access statistics
**Validates: Requirements 7.4**

### Property 32: Coherency verification matching
*For any* cache coherency verification run, HEAD entries between RAM and disk caches should be verified to match
**Validates: Requirements 7.5**

### Property 33: Conditional header bypass
*For any* HEAD request containing conditional headers, the system should bypass RAM cache and forward to S3 with cache management
**Validates: Requirements 8.2**

### Property 34: Normal caching for HeadObject
*For any* HEAD request for HeadObject operation, the system should use RAM cache following normal caching logic
**Validates: Requirements 8.3**

### Property 35: Bypass metrics inclusion
*For any* cache bypass metrics collection, HEAD request bypasses should be included in the statistics
**Validates: Requirements 8.4**

### Property 36: Bypass logging information
*For any* HEAD request logging, the log should indicate whether cache was bypassed and the reason
**Validates: Requirements 8.5**

### Property 37: Simple cache key format
*For any* HEAD entry stored in RAM, cache keys should not contain range suffixes
**Validates: Requirements 9.1**

### Property 38: Range-free access tracking
*For any* HEAD cache access tracking, access statistics should be recorded without range information
**Validates: Requirements 9.2**

### Property 39: No range parsing for HEAD keys
*For any* HEAD cache key processing, the system should not attempt to parse range information
**Validates: Requirements 9.3**

### Property 40: Appropriate metadata updates
*For any* HEAD access statistics flush, disk HEAD cache metadata should be updated appropriately
**Validates: Requirements 9.4**

### Property 41: Range-free coherency verification
*For any* HEAD cache coherency verification, HEAD entries should be compared without range validation
**Validates: Requirements 9.5**

### Property 42: Log message consolidation
*For any* HEAD cache operations, related log messages should be combined into single entries where possible
**Validates: Requirements 10.1**

### Property 43: Cache layer and timing in logs
*For any* HEAD cache hit/miss logging, the log should include cache layer (RAM/disk) and response time
**Validates: Requirements 10.3**

### Property 44: Error context logging
*For any* HEAD cache error occurrence, the system should log the error with context and fallback action taken
**Validates: Requirements 10.4**

### Property 45: Dual layer hit rate logging
*For any* HEAD cache statistics logging, hit rates for both RAM and disk layers should be included
**Validates: Requirements 10.5**

### Property 46: Graceful RAM cache failure fallback
*For any* RAM cache operation failure, the system should fall back to disk HEAD cache gracefully
**Validates: Requirements 11.1**

### Property 47: Serialization error handling
*For any* HEAD entry serialization failure, the system should log the error and continue with disk cache
**Validates: Requirements 11.2**

### Property 48: Eviction failure retry
*For any* RAM cache eviction failure, the system should retry with alternative eviction candidates
**Validates: Requirements 11.3**

### Property 49: Corruption handling
*For any* HEAD cache corruption detection, the system should invalidate the entry and fetch fresh data
**Validates: Requirements 11.4**

### Property 50: Unified cache invalidation
*For any* cache invalidation trigger, entries should be removed from RAM cache (both GET and HEAD), disk cache, and HEAD cache
**Validates: Requirements 11.1**

### Property 51: GET entry expiration priority
*For any* expired GET entries in RAM cache, they should be prioritized for eviction along with expired HEAD entries
**Validates: Requirements 11.2**

### Property 52: Complete invalidation coverage
*For any* cache key invalidation, no stale entries should remain in any cache layer
**Validates: Requirements 11.3**

### Property 53: Operation-triggered invalidation
*For any* PUT or DELETE operation, all related cache entries should be invalidated across all layers
**Validates: Requirements 11.4**

### Property 54: Corruption-triggered invalidation
*For any* cache corruption detection, entries should be invalidated from all cache layers and fresh data fetched
**Validates: Requirements 11.5**

### Property 55: Memory allocation failure handling
*For any* memory allocation failure, the system should skip RAM caching and use disk cache only
**Validates: Requirements 12.5**

## Error Handling

### RAM Cache Failures
1. **Storage Failures**: Fall back to disk HEAD cache gracefully
2. **Eviction Failures**: Try expired entries first, then retry with alternative candidates, log errors
3. **Serialization Failures**: Log error, continue with disk cache operation
4. **Memory Allocation Failures**: Skip RAM caching, use disk cache only

### Unified TTL-Aware Eviction Strategy
```rust
pub fn evict_entry_with_ttl_priority(&mut self) -> Result<()> {
    let now = SystemTime::now();
    
    // First, try to evict any expired entries (GET or HEAD)
    if let Ok(evicted_count) = self.evict_expired_entries() {
        if evicted_count > 0 {
            return Ok(());
        }
    }
    
    // If no expired entries, use normal eviction algorithm
    self.evict_entry()
}
```

### Comprehensive Invalidation Strategy
```rust
impl CacheManager {
    pub async fn invalidate_cache_unified(&self, cache_key: &str) -> Result<()> {
        // 1. Remove from RAM cache (both GET and HEAD entries)
        if self.ram_cache_enabled {
            let mut inner = self.inner.lock().unwrap();
            if let Some(ram_cache) = &mut inner.ram_cache {
                ram_cache.invalidate_entry(cache_key)?;
            }
        }
        
        // 2. Remove from disk cache (metadata + ranges)
        self.invalidate_disk_cache(cache_key).await?;
        
        // 3. Remove from HEAD cache (disk)
        self.invalidate_head_cache_entry(cache_key).await?;
        
        Ok(())
    }
}
```

### Cache Coherency Issues
1. **Corruption Detection**: Invalidate corrupted entries, fetch fresh from S3
2. **Verification Failures**: Log inconsistencies, prefer disk cache data
3. **Access Tracking Errors**: Continue operation, log tracking failures

### Fallback Strategy
```rust
async fn get_head_with_fallback(&self, cache_key: &str) -> Result<Option<HeadCacheEntry>> {
    // Try RAM cache first
    match self.get_head_from_ram_cache(cache_key).await {
        Ok(Some(entry)) => return Ok(Some(self.convert_head_ram_to_disk_entry(entry))),
        Ok(None) => {}, // Cache miss, try disk
        Err(e) => {
            warn!("RAM cache error for HEAD {}: {}, falling back to disk", cache_key, e);
        }
    }
    
    // Fall back to disk cache
    self.get_head_cache_entry(cache_key).await
}
```

## Testing Strategy

### Unit Testing Approach
- Test HEAD cache entry creation and validation
- Test cache key format (no range suffixes)
- Test TTL application and expiration
- Test eviction algorithm behavior with HEAD entries
- Test error handling and fallback scenarios
- Test access tracking without range information
- Test memory calculation accuracy

### Property-Based Testing Approach
The system will use **quickcheck** for property-based testing with a minimum of 100 iterations per property. Each property-based test will be tagged with a comment referencing the corresponding correctness property from this design document using the format: `**Feature: head-ram-cache, Property {number}: {property_text}**`

Key property test areas:
- Cache hit/miss behavior consistency
- TTL expiration and refresh behavior
- Eviction algorithm correctness
- Dual cache layer synchronization
- Access tracking accuracy
- Error handling and fallback behavior
- Memory usage calculations
- Log message format and content

### Integration Testing
- Test HEAD request flow through HTTP proxy
- Test cache coherency between RAM and disk layers
- Test metrics collection and reporting
- Test distributed cache coordination
- Test backward compatibility with existing disk cache files

### Performance Testing
- Measure HEAD request response times (RAM vs disk)
- Test memory usage efficiency
- Validate sub-millisecond response times for RAM cache hits
- Test cache capacity and eviction performance