# Design Document

## Overview

This design implements true HTTP connection keepalive (persistent connections) for the S3 proxy's communication with S3 endpoints. The current implementation creates a new TCP connection and performs a full TLS handshake for every request, incurring 150-300ms of overhead. This design eliminates that overhead by maintaining a pool of persistent HTTP connections that can be reused across multiple requests.

The implementation will use Hyper 1.0's connection pooling capabilities through a custom connector that integrates with the existing connection pool manager for load balancing and health monitoring.

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        S3Client                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │         Hyper Client with Connection Pool              │ │
│  │  ┌──────────────────────────────────────────────────┐  │ │
│  │  │      Custom HTTPS Connector                      │  │ │
│  │  │  - Integrates with ConnectionPoolManager         │  │ │
│  │  │  - Handles TLS with tokio-rustls                 │  │ │
│  │  │  - Provides IP selection for load balancing      │  │ │
│  │  └──────────────────────────────────────────────────┘  │ │
│  │                                                          │ │
│  │  Connection Pool (per IP address):                      │ │
│  │  ┌────────┐ ┌────────┐ ┌────────┐                      │ │
│  │  │ Conn 1 │ │ Conn 2 │ │ Conn 3 │ ... (up to max)      │ │
│  │  │ Idle   │ │ Active │ │ Idle   │                      │ │
│  │  └────────┘ └────────┘ └────────┘                      │ │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │      ConnectionPoolManager (existing)                  │ │
│  │  - IP selection and load balancing                     │ │
│  │  - DNS resolution and refresh                          │ │
│  │  - Health metrics tracking                             │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### Connection Lifecycle

```
┌─────────────┐
│   Request   │
└──────┬──────┘
       │
       v
┌─────────────────────────────────────┐
│ Select IP via ConnectionPoolManager │
└──────┬──────────────────────────────┘
       │
       v
┌─────────────────────────────────────┐
│ Get connection from Hyper pool      │
│ (creates new if none available)     │
└──────┬──────────────────────────────┘
       │
       v
┌─────────────────────────────────────┐
│ Send request over connection        │
└──────┬──────────────────────────────┘
       │
       v
┌─────────────────────────────────────┐
│ Read response (streaming or buffer) │
└──────┬──────────────────────────────┘
       │
       v
┌─────────────────────────────────────┐
│ Return connection to pool (idle)    │
│ - Starts idle timeout timer         │
│ - Updates last_used timestamp       │
└──────┬──────────────────────────────┘
       │
       v
┌─────────────────────────────────────┐
│ Connection remains idle until:      │
│ - Reused for next request           │
│ - Idle timeout expires               │
│ - Max lifetime reached              │
│ - Remote endpoint closes it         │
└─────────────────────────────────────┘
```

## Components and Interfaces

### 1. S3Client Modifications

**Current State:**
- Creates new TCP + TLS connection per request
- Uses manual connection management
- No connection reuse

**New State:**
- Uses `hyper::Client` with connection pooling
- Delegates connection management to Hyper
- Integrates with existing `ConnectionPoolManager` for IP selection

**Key Changes:**
```rust
pub struct S3Client {
    // Replace manual connection management with Hyper client
    client: hyper::Client<CustomHttpsConnector, Full<Bytes>>,
    pool_manager: Arc<Mutex<ConnectionPoolManager>>,
    request_timeout: Duration,
    max_retries: usize,
}
```

### 2. CustomHttpsConnector

**Purpose:** Bridge between Hyper's connection pooling and our existing connection pool manager.

**Responsibilities:**
- Implement `hyper::service::Service<Uri>` trait
- Consult `ConnectionPoolManager` for IP selection
- Establish TLS connections using `tokio-rustls`
- Return connections that Hyper can pool

**Interface:**
```rust
pub struct CustomHttpsConnector {
    pool_manager: Arc<Mutex<ConnectionPoolManager>>,
    tls_connector: TlsConnector,
    dns_resolver: TokioAsyncResolver,
}

impl Service<Uri> for CustomHttpsConnector {
    type Response = TokioIo<TlsStream<TcpStream>>;
    type Error = ProxyError;
    type Future = Pin<Box<dyn Future<Output = Result<Self::Response>>>>;
    
    fn call(&mut self, uri: Uri) -> Self::Future {
        // 1. Extract hostname from URI
        // 2. Consult ConnectionPoolManager for IP selection
        // 3. Establish TCP connection to selected IP
        // 4. Perform TLS handshake
        // 5. Return wrapped connection
    }
}
```

### 3. ConnectionPoolConfig

**Purpose:** Configuration structure for connection keepalive settings.

**Structure:**
```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConnectionPoolConfig {
    /// Enable connection keepalive (default: true)
    pub enabled: bool,
    
    /// Idle timeout for unused connections (default: 30s)
    pub idle_timeout: Duration,
    
    /// Maximum idle connections per IP (default: 1)
    pub max_idle_per_host: usize,
    
    /// Maximum connection lifetime (default: 300s)
    pub max_lifetime: Duration,
    
    /// Connection pool check interval (default: 10s)
    pub pool_check_interval: Duration,
}
```

### 4. ConnectionPoolMetrics

**Purpose:** Track connection pool performance and behavior.

**Structure:**
```rust
#[derive(Debug, Clone, Default)]
pub struct ConnectionPoolMetrics {
    /// Total connections created per endpoint
    pub connections_created: HashMap<String, u64>,
    
    /// Total connection reuses per endpoint
    pub connections_reused: HashMap<String, u64>,
    
    /// Current idle connections per endpoint
    pub idle_connections: HashMap<String, usize>,
    
    /// Connections closed due to idle timeout
    pub idle_timeout_closures: u64,
    
    /// Connections closed due to max lifetime
    pub lifetime_closures: u64,
    
    /// Connections closed due to errors
    pub error_closures: u64,
}
```

## Data Models

### Connection State Tracking

Hyper manages connection state internally, but we need to track additional metadata:

```rust
/// Metadata for tracking connection usage
#[derive(Debug, Clone)]
pub struct ConnectionMetadata {
    /// Unique connection identifier
    pub id: String,
    
    /// IP address this connection is bound to
    pub ip_address: IpAddr,
    
    /// When the connection was created
    pub created_at: SystemTime,
    
    /// When the connection was last used
    pub last_used: SystemTime,
    
    /// Number of requests served by this connection
    pub request_count: u64,
    
    /// Whether connection is currently active
    pub is_active: bool,
}
```

### Configuration Integration

Add to existing `ProxyConfig`:

```rust
pub struct ProxyConfig {
    // ... existing fields ...
    
    /// Connection pool configuration
    #[serde(default)]
    pub connection_pool: ConnectionPoolConfig,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Connection Reuse
*For any* sequence of requests to the same S3 endpoint, after the first request completes, subsequent requests should reuse existing connections rather than creating new ones (verified by tracking connection creation events)
**Validates: Requirements 1.1, 1.2, 1.3, 1.5**

### Property 2: Idle Timeout Enforcement
*For any* connection that remains idle, if the time since last use exceeds the configured idle timeout, the connection should be closed and removed from the pool
**Validates: Requirements 2.1, 2.4**

### Property 3: Max Idle Connections Limit
*For any* endpoint, the number of idle connections should never exceed the configured maximum; when the limit is reached, the least recently used connection should be evicted before adding a new one
**Validates: Requirements 3.1, 3.4, 3.5**

### Property 4: Max Lifetime Enforcement
*For any* connection, if the time since creation exceeds the configured max lifetime, the connection should be closed after completing any in-flight request
**Validates: Requirements 4.1, 4.4, 4.5**

### Property 5: Connection Error Recovery
*For any* connection that fails during a request, the connection should be removed from the pool, a new connection should be created, and the request should be retried without counting against the retry limit
**Validates: Requirements 5.1, 5.2, 5.3, 5.4, 5.5**

### Property 6: Latency Reduction
*For any* endpoint, the average latency of requests 2-N should be measurably lower than the latency of the first request (which includes TCP + TLS handshake overhead)
**Validates: Requirements 1.4**

### Property 7: Metrics Accuracy
*For any* sequence of requests, the connection pool metrics (connections created, reused, idle count, timeout closures, lifetime closures) should accurately reflect the actual connection pool operations
**Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5**

### Property 8: Per-IP Pool Isolation
*For any* endpoint with multiple resolved IP addresses, connections to each IP should be managed in separate pools, and returning a connection should place it in the pool for its specific IP address
**Validates: Requirements 8.1, 8.3**

### Property 9: Load Balancing Integration
*For any* request, the IP address selection should use the existing ConnectionPoolManager load balancing logic, and connection pool operations should not interfere with load distribution
**Validates: Requirements 8.2**

### Property 10: DNS Refresh Handling
*For any* DNS refresh event, new IP addresses should get new connection pools, and removed IP addresses should have all their connections closed
**Validates: Requirements 8.4, 8.5**

### Property 11: Streaming Connection Lifecycle
*For any* streaming response, the connection should remain active for the entire stream duration, be returned to the pool on successful completion, and be closed on interruption or error
**Validates: Requirements 9.1, 9.2, 9.3, 9.4**

### Property 12: Concurrent Streaming Independence
*For any* set of concurrent streaming responses, each connection should be managed independently without interference
**Validates: Requirements 9.5**

### Property 13: Non-Blocking Pool Maintenance
*For any* idle connection check operation, request processing should continue without blocking or delays
**Validates: Requirements 2.5**

## Error Handling

### Connection Errors

**Scenario:** Connection fails during request
**Handling:**
1. Remove connection from pool
2. Log error at warn level with connection details
3. Create new connection
4. Retry request without counting against retry limit
5. Update error metrics

**Scenario:** Connection closed by remote endpoint
**Handling:**
1. Detect closure on next use attempt
2. Remove connection from pool
3. Log at debug level
4. Create new connection automatically
5. Update error metrics

**Scenario:** Stale connection reuse attempt
**Handling:**
1. Detect error when attempting to send request
2. Remove stale connection
3. Get fresh connection from pool
4. Retry transparently
5. Update error metrics

### Timeout Errors

**Scenario:** Idle timeout expires
**Handling:**
1. Close connection gracefully
2. Remove from pool
3. Log at debug level
4. Update timeout metrics

**Scenario:** Max lifetime reached
**Handling:**
1. Wait for in-flight request to complete
2. Close connection gracefully
3. Remove from pool
4. Log at debug level
5. Update lifetime metrics

### Configuration Errors

**Scenario:** Invalid configuration values
**Handling:**
1. Validate on startup
2. Log error with specific validation failure
3. Fall back to default values
4. Continue startup with defaults

## Testing Strategy

### Unit Tests

1. **Configuration Parsing**
   - Test valid configuration values
   - Test invalid values with error handling
   - Test default value application
   - Test configuration disable flag

2. **Connection Metadata Tracking**
   - Test timestamp updates
   - Test request count increments
   - Test active/idle state transitions

3. **Metrics Collection**
   - Test metric increments
   - Test metric accuracy
   - Test per-endpoint isolation

### Property-Based Tests

1. **Property 1: Connection Reuse**
   - Generate: Random sequences of requests to same endpoint
   - Verify: Connection creation count equals 1 (or max_idle_per_host)
   - Verify: Subsequent requests show connection reuse

2. **Property 2: Idle Timeout Enforcement**
   - Generate: Random idle periods and timeout values
   - Verify: Connections idle beyond timeout are closed
   - Verify: Connections idle within timeout remain open

3. **Property 3: Max Idle Connections Limit**
   - Generate: Random number of connections exceeding limit
   - Verify: Pool never exceeds max_idle_per_host
   - Verify: LRU connection is evicted when limit reached

4. **Property 4: Max Lifetime Enforcement**
   - Generate: Random connection lifetimes and max_lifetime values
   - Verify: Connections exceeding max_lifetime are closed
   - Verify: In-flight requests complete before closure

5. **Property 5: Connection Error Recovery**
   - Generate: Random connection failures during requests
   - Verify: Failed connections are removed
   - Verify: Requests are retried with new connections
   - Verify: Retry count is not incremented

6. **Property 6: Latency Reduction**
   - Generate: Sequences of requests to same endpoint
   - Measure: First request latency vs subsequent requests
   - Verify: Subsequent requests show 100-200ms reduction

7. **Property 7: Metrics Accuracy**
   - Generate: Random sequences of requests and connection events
   - Verify: All metrics match actual operations performed

8. **Property 8: Per-IP Pool Isolation**
   - Generate: Requests to endpoints with multiple IPs
   - Verify: Each IP has separate connection pool
   - Verify: Connections return to correct IP pool

9. **Property 9: Load Balancing Integration**
   - Generate: Requests with different priorities and sizes
   - Verify: IP selection follows existing load balancing rules
   - Verify: Connection reuse doesn't break load distribution

10. **Property 10: DNS Refresh Handling**
    - Generate: DNS refresh events with IP changes
    - Verify: New IPs get new pools
    - Verify: Removed IPs have connections closed

11. **Property 11: Streaming Connection Lifecycle**
    - Generate: Streaming responses of various sizes
    - Verify: Connections stay active during streaming
    - Verify: Connections return to pool after completion
    - Verify: Connections close on errors

12. **Property 12: Concurrent Streaming Independence**
    - Generate: Multiple concurrent streaming responses
    - Verify: Each connection managed independently
    - Verify: No interference between streams

13. **Property 13: Non-Blocking Pool Maintenance**
    - Generate: Concurrent requests during pool maintenance
    - Verify: Requests complete without delays
    - Verify: Pool maintenance doesn't block request path

### Integration Tests

1. **End-to-End Connection Reuse**
   - Start proxy with connection keepalive enabled
   - Send multiple requests to same S3 endpoint
   - Verify latency reduction on subsequent requests
   - Verify metrics show connection reuse

2. **Idle Timeout Integration**
   - Configure short idle timeout (10s)
   - Send request and wait for timeout
   - Verify connection is closed
   - Verify next request creates new connection

3. **Max Lifetime Integration**
   - Configure short max lifetime (60s)
   - Keep connection active with periodic requests
   - Wait for lifetime to expire
   - Verify connection is closed after in-flight request

4. **Load Balancing Integration**
   - Configure endpoint with multiple IPs
   - Send requests with different priorities
   - Verify connections distributed across IPs
   - Verify connection reuse per IP

5. **Streaming Integration**
   - Request large file (>10MB) with streaming
   - Verify connection stays active during stream
   - Verify connection returned to pool after completion
   - Verify subsequent request reuses connection

### Performance Tests

1. **Latency Improvement**
   - Measure: First request latency (with handshakes)
   - Measure: Subsequent request latency (reused connection)
   - Verify: 100-200ms improvement on subsequent requests

2. **Throughput Improvement**
   - Measure: Requests per second without keepalive
   - Measure: Requests per second with keepalive
   - Verify: 30-50% throughput improvement

3. **Memory Usage**
   - Monitor: Memory usage with various max_idle_per_host values
   - Verify: Memory usage scales linearly with connection count
   - Verify: Idle timeout prevents unbounded growth

4. **Connection Churn**
   - Monitor: Connection creation rate over time
   - Verify: Creation rate drops after initial warmup
   - Verify: Idle timeout and max lifetime cause periodic churn

## Implementation Notes

### Hyper 1.0 Connection Pooling

Hyper 1.0 provides built-in connection pooling through the `Client` type:

```rust
use hyper::client::Client;
use hyper_util::client::legacy::Client as LegacyClient;
use hyper_util::rt::TokioExecutor;

let client = LegacyClient::builder(TokioExecutor::new())
    .pool_idle_timeout(Duration::from_secs(30))
    .pool_max_idle_per_host(1)  // Default: 1 connection per IP
    .build(custom_connector);
```

### Custom Connector Implementation

The connector must implement `tower::Service<Uri>`:

```rust
impl Service<Uri> for CustomHttpsConnector {
    type Response = TokioIo<TlsStream<TcpStream>>;
    type Error = ProxyError;
    type Future = Pin<Box<dyn Future<Output = Result<Self::Response>> + Send>>;
    
    fn poll_ready(&mut self, _cx: &mut Context<'_>) -> Poll<Result<()>> {
        Poll::Ready(Ok(()))
    }
    
    fn call(&mut self, uri: Uri) -> Self::Future {
        let pool_manager = Arc::clone(&self.pool_manager);
        let tls_connector = self.tls_connector.clone();
        
        Box::pin(async move {
            // 1. Extract hostname
            let hostname = uri.host().ok_or(...)?;
            
            // 2. Get IP from ConnectionPoolManager
            let mut pm = pool_manager.lock().await;
            let connection = pm.get_connection(hostname, None).await?;
            let ip = connection.ip_address;
            drop(pm);
            
            // 3. Establish TCP connection
            let tcp = TcpStream::connect((ip, 443)).await?;
            
            // 4. Perform TLS handshake
            let server_name = ServerName::try_from(hostname)?;
            let tls = tls_connector.connect(server_name, tcp).await?;
            
            // 5. Return wrapped connection
            Ok(TokioIo::new(tls))
        })
    }
}
```

### Integration with Existing Code

**Minimal Changes Required:**
1. Replace manual connection creation in `S3Client::try_forward_request`
2. Use `client.request()` instead of manual HTTP handshake
3. Remove manual connection release (Hyper handles it)
4. Keep existing retry logic and error handling

**Preserved Functionality:**
- Connection pool manager for IP selection
- Load balancing logic
- Health metrics tracking
- DNS refresh
- Retry logic
- Streaming support

### Configuration Example

```yaml
connection_pool:
  enabled: true
  idle_timeout: "30s"
  max_idle_per_host: 1  # Default: 1 connection per IP
  max_lifetime: "300s"
  pool_check_interval: "10s"
```

### Metrics Integration

Add to existing metrics endpoint:

```
# Connection pool metrics
s3_proxy_connections_created_total{endpoint="s3.amazonaws.com"} 15
s3_proxy_connections_reused_total{endpoint="s3.amazonaws.com"} 142
s3_proxy_connections_idle{endpoint="s3.amazonaws.com"} 8
s3_proxy_connections_closed_idle_timeout_total 3
s3_proxy_connections_closed_max_lifetime_total 2
s3_proxy_connections_closed_error_total 1
```

### Logging Examples

```
DEBUG Connection reused: id=conn-abc123 ip=52.216.1.1 endpoint=s3.amazonaws.com request_count=5
DEBUG Connection closed (idle timeout): id=conn-def456 ip=52.216.1.2 idle_duration=35s
DEBUG Connection closed (max lifetime): id=conn-ghi789 ip=52.216.1.3 lifetime=305s
WARN Connection error: id=conn-jkl012 ip=52.216.1.4 error="connection reset by peer"
```

## Dependencies

### New Dependencies

Add to `Cargo.toml`:

```toml
# Connection pooling support
hyper-util = { version = "0.1", features = ["client", "client-legacy", "http1", "tokio"] }
tower = "0.4"
```

### Existing Dependencies

- `hyper` 1.0 - Already present, provides connection pooling
- `tokio-rustls` - Already present, provides TLS
- `tokio` - Already present, provides async runtime

## Migration Strategy

### Phase 1: Implementation
1. Add `ConnectionPoolConfig` to configuration
2. Implement `CustomHttpsConnector`
3. Modify `S3Client` to use Hyper client
4. Add connection pool metrics

### Phase 2: Testing
1. Add unit tests for new components
2. Add property-based tests for correctness properties
3. Add integration tests for end-to-end behavior
4. Run performance tests to verify improvements

### Phase 3: Deployment
1. Deploy with keepalive disabled by default
2. Enable in staging environment
3. Monitor metrics and performance
4. Enable in production after validation

### Rollback Plan

If issues arise:
1. Set `connection_pool.enabled: false` in configuration
2. Restart proxy
3. System reverts to creating new connections per request
4. No data loss or cache corruption

## Performance Expectations

### Latency Improvements

- **First request**: 250-350ms (includes TCP + TLS handshake)
- **Subsequent requests**: 100-150ms (connection reused)
- **Improvement**: 150-200ms reduction (60-70% faster)

### Throughput Improvements

- **Without keepalive**: ~50 requests/second per connection
- **With keepalive**: ~75-100 requests/second per connection
- **Improvement**: 50-100% throughput increase

### Resource Usage

- **Memory**: ~50KB per idle connection
- **File descriptors**: 1 per connection
- **With 1 idle connection per IP (default)**: ~50KB memory, 1 FD per IP
- **Minimal overhead** for significant performance gains

## Security Considerations

### TLS Certificate Validation

- Maintain existing certificate validation
- Use system root certificates
- Validate on every new connection
- Reused connections already validated

### Connection Hijacking

- Connections bound to specific IP addresses
- TLS provides encryption and authentication
- No additional risk from connection reuse

### Resource Exhaustion

- Max idle connections limit prevents unbounded growth
- Idle timeout prevents resource leaks
- Max lifetime handles stale connections
- Monitoring via metrics

## Future Enhancements

### HTTP/2 Support

- Hyper supports HTTP/2 connection pooling
- S3 supports HTTP/2
- Could multiplex multiple requests over single connection
- Further latency and throughput improvements

### Adaptive Pool Sizing

- Dynamically adjust max_idle_per_host based on load
- Increase during high traffic
- Decrease during low traffic
- Optimize resource usage

### Connection Warming

- Pre-establish connections to frequently accessed endpoints
- Reduce first-request latency
- Triggered by cache warmup or predictive logic

### Advanced Health Checks

- Periodic health checks on idle connections
- Detect stale connections proactively
- Remove before use attempt
- Reduce error rate
