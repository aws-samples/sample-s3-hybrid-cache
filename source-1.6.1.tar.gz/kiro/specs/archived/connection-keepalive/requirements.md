# Requirements Document

## Introduction

This specification defines the requirements for implementing true HTTP connection keepalive (persistent connections) between the S3 proxy and S3 endpoints. Currently, the proxy creates a new TCP connection and performs a full TLS handshake for every request, incurring 150-300ms of overhead per request. This feature will enable connection reuse to eliminate this overhead for subsequent requests.

## Glossary

- **S3Client**: The HTTP client module responsible for forwarding requests to S3 endpoints
- **Connection Pool**: A collection of persistent HTTP connections that can be reused across multiple requests
- **Idle Connection**: A connection that is not currently processing a request but remains open for reuse
- **Connection Keepalive**: The practice of maintaining open HTTP connections between requests to avoid reconnection overhead
- **TLS Handshake**: The cryptographic negotiation process required to establish a secure HTTPS connection
- **Idle Timeout**: The duration an unused connection remains open before being closed
- **Max Idle Connections**: The maximum number of idle connections maintained per S3 endpoint

## Requirements

### Requirement 1

**User Story:** As a proxy operator, I want the proxy to reuse HTTP connections to S3 endpoints, so that subsequent requests avoid TCP and TLS handshake overhead.

#### Acceptance Criteria

1. WHEN the S3Client forwards a request to an S3 endpoint THEN the system SHALL reuse an existing idle connection if one is available
2. WHEN no idle connection exists for an S3 endpoint THEN the system SHALL create a new connection and add it to the pool
3. WHEN a connection completes a request THEN the system SHALL return the connection to the idle pool for reuse
4. WHEN measuring request latency THEN subsequent requests to the same endpoint SHALL show reduced latency compared to the first request
5. WHERE connection reuse is enabled THEN the system SHALL eliminate TCP handshake and TLS handshake overhead for subsequent requests

### Requirement 2

**User Story:** As a proxy operator, I want idle connections to be automatically closed after a timeout period, so that the proxy does not waste resources on unused connections.

#### Acceptance Criteria

1. WHEN a connection remains idle for longer than the configured timeout THEN the system SHALL close the connection and remove it from the pool
2. WHEN the idle timeout is configured THEN the system SHALL support timeout values between 10 seconds and 300 seconds
3. WHEN no idle timeout is configured THEN the system SHALL use a default timeout of 30 seconds
4. WHEN a connection is closed due to idle timeout THEN the system SHALL log the closure at debug level
5. WHEN the system checks for idle connections THEN the system SHALL perform this check periodically without blocking request processing

### Requirement 3

**User Story:** As a proxy operator, I want to limit the number of idle connections per S3 endpoint, so that the proxy does not consume excessive memory or file descriptors.

#### Acceptance Criteria

1. WHEN the number of idle connections for an endpoint reaches the configured maximum THEN the system SHALL close the least recently used connection before adding a new one
2. WHEN the max idle connections limit is configured THEN the system SHALL support values between 1 and 50 connections per endpoint
3. WHEN no max idle connections limit is configured THEN the system SHALL use a default of 5 connections per endpoint
4. WHEN closing an LRU connection THEN the system SHALL gracefully close the connection and log the action at debug level
5. WHEN tracking connection usage THEN the system SHALL maintain timestamps for last use to enable LRU eviction

### Requirement 4

**User Story:** As a proxy operator, I want connections to be automatically closed after a maximum lifetime, so that the proxy handles DNS changes and connection staleness.

#### Acceptance Criteria

1. WHEN a connection has been open for longer than the configured max lifetime THEN the system SHALL close the connection even if it is still in use
2. WHEN the max connection lifetime is configured THEN the system SHALL support lifetime values between 60 seconds and 3600 seconds
3. WHEN no max connection lifetime is configured THEN the system SHALL use a default lifetime of 60 seconds
4. WHEN a connection reaches its max lifetime THEN the system SHALL close it gracefully after completing any in-flight request
5. WHEN closing a connection due to max lifetime THEN the system SHALL log the closure at debug level

### Requirement 5

**User Story:** As a proxy operator, I want the connection pool to handle connection errors gracefully, so that failed connections do not impact request reliability.

#### Acceptance Criteria

1. WHEN a connection fails during a request THEN the system SHALL remove the connection from the pool and create a new connection
2. WHEN a connection is closed by the remote endpoint THEN the system SHALL detect the closure and remove the connection from the pool
3. WHEN attempting to reuse a connection that has been closed THEN the system SHALL detect the error and retry with a new connection
4. WHEN a connection error occurs THEN the system SHALL log the error at warn level with connection details
5. WHEN retrying after a connection error THEN the system SHALL not count the retry against the request retry limit

### Requirement 6

**User Story:** As a proxy operator, I want connection pool metrics to be exposed, so that I can monitor connection reuse effectiveness.

#### Acceptance Criteria

1. WHEN metrics are collected THEN the system SHALL track the total number of connections created per endpoint
2. WHEN metrics are collected THEN the system SHALL track the number of connection reuses per endpoint
3. WHEN metrics are collected THEN the system SHALL track the current number of idle connections per endpoint
4. WHEN metrics are collected THEN the system SHALL track the number of connections closed due to idle timeout
5. WHEN metrics are collected THEN the system SHALL track the number of connections closed due to max lifetime

### Requirement 7

**User Story:** As a proxy operator, I want connection keepalive settings to be configurable, so that I can tune the behavior for my deployment environment.

#### Acceptance Criteria

1. WHEN the proxy starts THEN the system SHALL read connection keepalive settings from the configuration file
2. WHERE connection keepalive is configured THEN the system SHALL support configuring idle timeout duration
3. WHERE connection keepalive is configured THEN the system SHALL support configuring max idle connections per endpoint
4. WHERE connection keepalive is configured THEN the system SHALL support configuring max connection lifetime
5. WHERE connection keepalive is configured THEN the system SHALL support disabling connection keepalive entirely

### Requirement 8

**User Story:** As a proxy operator, I want connection keepalive to work correctly with the existing connection pool load balancing, so that requests are distributed across multiple S3 IP addresses.

#### Acceptance Criteria

1. WHEN multiple IP addresses are resolved for an S3 endpoint THEN the system SHALL maintain separate connection pools for each IP address
2. WHEN selecting a connection for a request THEN the system SHALL use the existing load balancing logic to choose the target IP address
3. WHEN a connection is returned to the pool THEN the system SHALL return it to the pool for the specific IP address it is connected to
4. WHEN DNS refresh adds new IP addresses THEN the system SHALL create new connection pools for the new IP addresses
5. WHEN DNS refresh removes IP addresses THEN the system SHALL close all connections to the removed IP addresses

### Requirement 9

**User Story:** As a proxy operator, I want connection keepalive to support streaming responses, so that large file downloads benefit from connection reuse.

#### Acceptance Criteria

1. WHEN a streaming response is in progress THEN the system SHALL keep the connection active until the stream completes
2. WHEN a streaming response completes successfully THEN the system SHALL return the connection to the idle pool
3. WHEN a streaming response is interrupted THEN the system SHALL close the connection and remove it from the pool
4. WHEN a streaming response encounters an error THEN the system SHALL close the connection and log the error
5. WHEN multiple streaming responses are active THEN the system SHALL manage each connection independently

### Requirement 10

**User Story:** As a developer, I want connection keepalive to be tested with property-based tests, so that edge cases and race conditions are discovered.

#### Acceptance Criteria

1. WHEN testing connection reuse THEN the system SHALL verify that subsequent requests to the same endpoint reuse connections
2. WHEN testing idle timeout THEN the system SHALL verify that connections are closed after the configured timeout
3. WHEN testing max idle connections THEN the system SHALL verify that the pool does not exceed the configured limit
4. WHEN testing connection errors THEN the system SHALL verify that failed connections are removed and replaced
5. WHEN testing concurrent requests THEN the system SHALL verify that connection pool operations are thread-safe
