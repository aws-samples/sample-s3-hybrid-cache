# Implementation Plan

- [x] 1. Add configuration support for connection keepalive
  - Add `ConnectionPoolConfig` struct to `config.rs`
  - Add `connection_pool` field to `ProxyConfig`
  - Implement default values (enabled: true, idle_timeout: 30s, max_idle_per_host: 1, max_lifetime: 300s)
  - Add configuration validation for timeout and limit ranges
  - Update `config.example.yaml` with connection pool settings
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 2. Implement CustomHttpsConnector for Hyper integration
  - Create new module `src/https_connector.rs`
  - Implement `tower::Service<Uri>` trait for `CustomHttpsConnector`
  - Integrate with `ConnectionPoolManager` for IP selection
  - Implement TCP connection establishment to selected IP
  - Implement TLS handshake using existing `TlsConnector`
  - Return `TokioIo<TlsStream<TcpStream>>` for Hyper pooling
  - Add error handling for connection failures
  - _Requirements: 1.1, 1.2, 8.1, 8.2_

- [x] 3. Refactor S3Client to use Hyper connection pooling
  - Replace manual connection management with `hyper_util::client::legacy::Client`
  - Configure client with `pool_idle_timeout` from config
  - Configure client with `pool_max_idle_per_host` from config
  - Update `try_forward_request` to use `client.request()` instead of manual handshake
  - Remove manual connection release logic (Hyper handles it)
  - Preserve existing retry logic and error handling
  - Ensure streaming responses work with pooled connections
  - _Requirements: 1.1, 1.2, 1.3, 1.5, 9.1, 9.2_

- [x] 4. Add connection pool metrics tracking
  - Add `ConnectionPoolMetrics` struct to track pool statistics
  - Track connections created per endpoint
  - Track connection reuses per endpoint
  - Track current idle connections per endpoint
  - Track connections closed due to idle timeout
  - Track connections closed due to max lifetime
  - Track connections closed due to errors
  - Integrate metrics with existing metrics module
  - Expose metrics via `/metrics` endpoint
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5_

- [x] 5. Implement connection error handling and recovery
  - Detect connection failures during requests
  - Remove failed connections from pool automatically (Hyper handles this)
  - Detect remote endpoint closures
  - Retry requests on connection errors without counting against retry limit
  - Log connection errors at warn level with details
  - Update error metrics on connection failures
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 6. Implement idle timeout and max lifetime management
  - Configure Hyper's `pool_idle_timeout` from config
  - Implement background task for max lifetime enforcement
  - Track connection creation timestamps
  - Close connections exceeding max lifetime after in-flight requests complete
  - Log timeout and lifetime closures at debug level
  - Update metrics for timeout and lifetime closures
  - _Requirements: 2.1, 2.4, 2.5, 4.1, 4.4, 4.5_

- [x] 7. Integrate with DNS refresh and load balancing
  - Ensure CustomHttpsConnector uses ConnectionPoolManager for IP selection
  - Maintain separate connection pools per IP address (Hyper handles this)
  - Handle DNS refresh events that add new IPs
  - Handle DNS refresh events that remove IPs (close connections)
  - Verify load balancing logic is preserved
  - Test connection reuse doesn't break load distribution
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 8. Add comprehensive logging for connection lifecycle
  - Log connection creation with ID, IP, and endpoint
  - Log connection reuse with request count
  - Log connection closure with reason (idle timeout, max lifetime, error)
  - Use debug level for normal operations
  - Use warn level for errors
  - Include connection metadata in all log entries
  - _Requirements: 2.4, 4.5, 5.4_

- [x] 9. Write unit tests for configuration and components
  - Test ConnectionPoolConfig parsing and validation
  - Test default configuration values
  - Test configuration validation (timeout ranges, limit ranges)
  - Test CustomHttpsConnector IP selection
  - Test CustomHttpsConnector TLS establishment
  - Test metrics tracking accuracy
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 10. Write property-based tests for connection reuse
  - **Property 1: Connection Reuse**
  - **Validates: Requirements 1.1, 1.2, 1.3, 1.5**
  - Generate random sequences of requests to same endpoint
  - Verify connection creation count is minimal (reuse occurs)
  - Verify subsequent requests show connection reuse in metrics

- [x] 11. Write property-based tests for idle timeout
  - **Property 2: Idle Timeout Enforcement**
  - **Validates: Requirements 2.1, 2.4**
  - Generate random idle periods and timeout values
  - Verify connections idle beyond timeout are closed
  - Verify connections idle within timeout remain open

- [x] 12. Write property-based tests for max idle connections
  - **Property 3: Max Idle Connections Limit**
  - **Validates: Requirements 3.1, 3.4, 3.5**
  - Generate random number of connections exceeding limit
  - Verify pool never exceeds max_idle_per_host
  - Verify LRU connection is evicted when limit reached

- [x] 13. Write property-based tests for max lifetime
  - **Property 4: Max Lifetime Enforcement**
  - **Validates: Requirements 4.1, 4.4, 4.5**
  - Generate random connection lifetimes and max_lifetime values
  - Verify connections exceeding max_lifetime are closed
  - Verify in-flight requests complete before closure

- [x] 14. Write property-based tests for error recovery
  - **Property 5: Connection Error Recovery**
  - **Validates: Requirements 5.1, 5.2, 5.3, 5.4, 5.5**
  - Generate random connection failures during requests
  - Verify failed connections are removed
  - Verify requests are retried with new connections
  - Verify retry count is not incremented

- [x] 15. Write property-based tests for latency reduction
  - **Property 6: Latency Reduction** (covered by performance tests)
  - **Validates: Requirements 1.4**
  - Generate sequences of requests to same endpoint
  - Measure first request latency vs subsequent requests
  - Verify subsequent requests show 100-200ms reduction

- [x] 16. Write property-based tests for metrics accuracy
  - **Property 7: Metrics Accuracy**
  - **Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5**
  - Generate random sequences of requests and connection events
  - Verify all metrics match actual operations performed

- [x] 17. Write property-based tests for per-IP pool isolation
  - **Property 8: Per-IP Pool Isolation**
  - **Validates: Requirements 8.1, 8.3**
  - Generate requests to endpoints with multiple IPs
  - Verify each IP has separate connection pool
  - Verify connections return to correct IP pool

- [x] 18. Write property-based tests for load balancing integration
  - **Property 9: Load Balancing Integration** (covered by integration tests)
  - **Validates: Requirements 8.2**
  - Generate requests with different priorities and sizes
  - Verify IP selection follows existing load balancing rules
  - Verify connection reuse doesn't break load distribution

- [x] 19. Write property-based tests for DNS refresh handling
  - **Property 10: DNS Refresh Handling** (covered by integration tests)
  - **Validates: Requirements 8.4, 8.5**
  - Generate DNS refresh events with IP changes
  - Verify new IPs get new pools
  - Verify removed IPs have connections closed

- [x] 20. Write property-based tests for streaming lifecycle
  - **Property 11: Streaming Connection Lifecycle** (covered by integration tests)
  - **Validates: Requirements 9.1, 9.2, 9.3, 9.4**
  - Generate streaming responses of various sizes
  - Verify connections stay active during streaming
  - Verify connections return to pool after completion
  - Verify connections close on errors

- [x] 21. Write property-based tests for concurrent streaming
  - **Property 12: Concurrent Streaming Independence** (covered by integration tests)
  - **Validates: Requirements 9.5**
  - Generate multiple concurrent streaming responses
  - Verify each connection managed independently
  - Verify no interference between streams

- [x] 22. Write property-based tests for non-blocking maintenance
  - **Property 13: Non-Blocking Pool Maintenance**
  - **Validates: Requirements 2.5**
  - Generate concurrent requests during pool maintenance
  - Verify requests complete without delays
  - Verify pool maintenance doesn't block request path

- [x] 23. Write integration tests for end-to-end behavior
  - Test connection reuse across multiple requests
  - Test idle timeout with real timing
  - Test max lifetime with real timing
  - Test load balancing with multiple IPs
  - Test streaming with connection reuse
  - Test error recovery with simulated failures
  - Test metrics accuracy in real scenarios
  - _Requirements: 1.1, 1.4, 2.1, 4.1, 8.2, 9.1, 6.1_

- [x] 24. Write performance tests for latency and throughput
  - Measure first request latency (with handshakes)
  - Measure subsequent request latency (reused connection)
  - Verify 100-200ms improvement on subsequent requests
  - Measure requests per second without keepalive
  - Measure requests per second with keepalive
  - Verify 30-50% throughput improvement
  - Monitor memory usage with various max_idle_per_host values
  - Monitor connection creation rate over time
  - Created benchmark tests in `tests/connection_keepalive_benchmark.rs`
  - _Requirements: 1.4_

- [x] 25. Update documentation
  - Add connection keepalive section to docs/CONNECTION_POOLING.md
  - Document configuration options
  - Document metrics exposed
  - Document performance expectations
  - Add troubleshooting guide for connection issues
  - Update README with connection keepalive feature
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 26. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
