# Requirements: Correct GET Part Behaviour

## Overview

Fix multipart upload part caching, improve range request handling for signed requests, and add per-instance request coalescing. This spec consolidates three related efforts:

1. **Part caching fixes** — Replace uniform part size assumption with per-part storage, remove request delays, filter parts during CompleteMultipartUpload
2. **Smart range caching** — Handle signed vs unsigned Range headers correctly, selectively cache only missing portions
3. **Concurrent range downloads** — Coalesce duplicate S3 fetches for the same resource using broadcast channels

## Problem Statement

### GET Part Issues

1. **Incorrect size inference**: The code assumes all parts (except the last) have uniform size, storing only `part_size` in metadata. S3 allows parts to vary in size (5MB to 5GB each).

2. **Unnecessary request delays**: When multipart metadata is missing, the proxy delays requests (up to 15 seconds with 503 responses) hoping another request will populate the metadata. This is wrong - we should just forward to S3.

3. **Missing per-part size storage**: Part sizes are not stored individually, so even after a successful part request, subsequent requests for the same part cannot be served from cache.

### CompleteMultipartUpload Issues

4. **Parts not filtered by request**: The proxy uses ALL cached parts instead of only the parts specified in the CompleteMultipartUpload request body XML. S3 allows clients to upload parts 1,2,3,4,5 but complete with only parts 1,3,5.

5. **Incorrect object size**: Using all cached parts causes wrong object size, wrong byte offsets, and corrupted data served to clients.

6. **Orphaned part files**: Parts not included in the final object are not cleaned up.

### Signed Range Issues

7. **Signed Range headers cannot be modified**: AWS SDKs may include the Range header in SigV4 signatures. The proxy cannot modify signed Range headers without invalidating the signature.

8. **Redundant cache writes**: The signed range path caches the entire response range even when portions are already cached, wasting disk I/O.

### Concurrent Request Issues

9. **Duplicate S3 fetches**: When multiple requests hit the proxy for the same uncached object or range, each independently fetches from S3, wasting bandwidth and increasing DTO costs.

10. **Cache size tracking drift**: Duplicate journal entries from concurrent fetches contribute to cache size tracking inaccuracy.

## User Stories

### 1. Remove Uniform Part Size Assumption

**As a** proxy operator
**I want** the proxy to handle variable-sized multipart parts correctly
**So that** part requests work correctly regardless of how the object was uploaded

#### Acceptance Criteria

1.1. Remove `part_size: Option<u64>` field from ObjectMetadata (single uniform size assumption)
1.2. Add `part_ranges: HashMap<u32, (u64, u64)>` field to ObjectMetadata to store byte range per part
1.3. Update part lookup to use direct range lookup instead of calculation
1.4. Maintain backward compatibility with existing cached metadata (treat missing part_ranges as cache miss)

### 2. Remove Request Delay Behaviour

**As a** client application
**I want** part requests to be forwarded immediately to S3 when not cached
**So that** I don't experience unnecessary latency

#### Acceptance Criteria

2.1. Remove `handle_missing_multipart_metadata` function and its delay/503 logic
2.2. Remove `active_part_fetches` tracking map and `ActivePartFetch` struct
2.3. Remove `register_part_fetch`, `complete_part_fetch`, `fail_part_fetch` methods
2.4. When part metadata is missing, immediately return cache miss (forward to S3)
2.5. Remove deferred count tracking and 5-second sleep logic

### 3. Store Part Sizes from GET Responses

**As a** proxy operator
**I want** part sizes to be recorded when parts are fetched from S3
**So that** subsequent requests for the same part can be served from cache

#### Acceptance Criteria

3.1. When a GET with `partNumber` returns from S3, extract byte range from Content-Range header
3.2. Store the byte range in the object's metadata (`part_ranges` map)
3.3. Store the part data as a range file using the byte offsets from S3
3.4. Update `lookup_part` to use stored part ranges for cache lookups

### 4. Parse CompleteMultipartUpload Request Body

**As a** cache system
**I want** to parse the CompleteMultipartUpload request body
**So that** I know which parts the client wants to include in the final object

#### Acceptance Criteria

4.1. Parse the XML request body before forwarding to S3
4.2. Extract the list of (PartNumber, ETag) pairs from the request
4.3. If request body is empty or malformed, skip cache finalization and log warning
4.4. Store the parts list for use after S3 responds

### 5. Filter Cached Parts by Request

**As a** cache system
**I want** to use only the parts specified in the request when building the final cached object
**So that** the cached object matches what S3 returns

#### Acceptance Criteria

5.1. Use only parts listed in the CompleteMultipartUpload request body
5.2. Do not include cached parts that are not in the request parts list
5.3. Calculate byte offsets using only the filtered parts in part-number order
5.4. If a requested part is not cached locally, skip cache finalization

### 6. Delete Unreferenced Parts

**As a** cache system
**I want** to clean up cached parts not included in the final object
**So that** disk space is not wasted on orphaned files

#### Acceptance Criteria

6.1. Identify parts cached but not in the CompleteMultipartUpload request
6.2. Delete range files for unreferenced parts from disk
6.3. Log the cleanup with part numbers
6.4. If deletion fails, log warning but continue with finalization

### 7. Record Part Sizes on CompleteMultipartUpload

**As a** proxy operator
**I want** part sizes to be recorded when multipart uploads complete
**So that** subsequent GET requests with `partNumber` can be served from cache

#### Acceptance Criteria

7.1. Calculate byte ranges from the filtered parts list (cumulative offsets)
7.2. Store byte ranges in the completed object's metadata (`part_ranges` map)
7.3. Store `parts_count` in metadata for validation

### 8. Update Part Cache Lookup

**As a** proxy operator
**I want** part cache lookups to use stored per-part sizes
**So that** cached parts can be served correctly

#### Acceptance Criteria

8.1. Modify `lookup_part` to look up byte range directly from `part_ranges`
8.2. If part is not in `part_ranges`, return cache miss (don't delay)
8.3. Use the stored (start, end) tuple directly for range file lookup
8.4. Validate that requested part number exists in `part_ranges`

### 9. ETag Validation During CompleteMultipartUpload

**As a** cache system
**I want** to validate that cached part ETags match the request ETags
**So that** stale or corrupted cached data is not used

#### Acceptance Criteria

9.1. Compare the ETag in the CompleteMultipartUpload request XML against the cached part ETag
9.2. If ETags don't match for any part, skip cache finalization for that upload
9.3. Log the ETag mismatch with part number and both ETags
9.4. Still forward the request to S3 (only skip caching, not the operation)

### 10. Dynamic Range Signature Detection [IMPLEMENTED]

**As a** cache system
**I want** to dynamically detect whether the Range header is included in the SigV4 signature
**So that** I can choose the optimal caching strategy

#### Acceptance Criteria

10.1. Parse the SignedHeaders component of the SigV4 Authorization header to determine if Range is signed
10.2. If `range` is listed in SignedHeaders, classify as Signed_Range
10.3. If `range` is NOT listed in SignedHeaders, classify as Unsigned_Range
10.4. Unsigned requests (no Authorization header) classify any Range header as Unsigned_Range
10.5. Log the detected signature type at debug level

### 11. Unsigned Range Optimization [IMPLEMENTED]

**As a** cache system
**I want** to modify unsigned Range headers to fetch only missing portions
**So that** I minimize bandwidth and improve performance

#### Acceptance Criteria

11.1. When a request has an Unsigned_Range and partial cache coverage, modify the Range header to request only missing ranges from S3
11.2. When full cache coverage exists, serve entirely from cache without contacting S3
11.3. Cache the response and assemble the complete requested range for the client
11.4. Maintain existing range consolidation behavior for Unsigned_Range requests

### 12. Signed Range Handling [PARTIALLY IMPLEMENTED]

**As a** cache system
**I want** to handle signed Range headers correctly
**So that** I maintain compatibility while still benefiting from caching

#### Acceptance Criteria

12.1. Forward signed Range requests to S3 unchanged
12.2. Stream the response to the client without buffering
12.3. When caching, identify and store only the missing ranges (portions not already cached) — currently stores entire response range
12.4. When the response is entirely covered by existing cache, skip caching entirely
12.5. Never modify the Range header for Signed_Range requests

### 13. Cache Only Missing Portions of Signed Range Responses [NOT IMPLEMENTED]

**As a** cache system
**I want** to store only the missing portions of a signed range S3 response
**So that** I minimize disk usage and avoid redundant writes

#### Acceptance Criteria

13.1. When caching a response that has missing ranges, extract and store only the bytes corresponding to missing ranges
13.2. When the response is entirely covered by existing cache, skip caching entirely
13.3. Create separate cache files for each contiguous missing range
13.4. Update metadata to reflect the newly cached ranges

### 14. ETag Mismatch Handling for Cached Ranges [NOT IMPLEMENTED]

**As a** cache system
**I want** to invalidate stale cached ranges when the object has changed
**So that** clients always receive consistent data

#### Acceptance Criteria

14.1. When `store_range()` detects an ETag mismatch, invalidate existing cached ranges for that object
14.2. Allow the new data to be cached on the next request
14.3. Log the ETag mismatch and invalidation

### 15. In-Flight Fetch Registration

**As a** proxy operator
**I want** the first cache-miss request for a given resource to register as the fetcher
**So that** subsequent requests can wait instead of issuing duplicate S3 fetches

#### Acceptance Criteria

15.1. When a cache-miss occurs and no in-flight fetch exists for the flight key, register the request as the fetcher and return a broadcast sender
15.2. When a cache-miss occurs and an in-flight fetch already exists, return a broadcast receiver for the waiter to subscribe to
15.3. Use the exact byte range to construct the flight key so that different ranges proceed independently
15.4. Full-object GET and range GET for the same object are independent flight keys

### 16. Fetcher Completion Notification

**As a** proxy operator
**I want** the fetcher to notify all waiters when the S3 fetch completes
**So that** waiters can serve the response from cache

#### Acceptance Criteria

16.1. When the fetcher completes successfully, broadcast a success notification to all waiters
16.2. When the fetcher encounters an error, broadcast the error to all waiters
16.3. When the fetcher completes (success or failure), remove the flight key entry from the tracker

### 17. Waiter Behavior

**As a** proxy operator
**I want** waiting requests to serve from cache after the fetcher completes
**So that** clients receive responses without redundant S3 fetches

#### Acceptance Criteria

17.1. When a waiter receives a success notification, serve the response from disk cache
17.2. When a waiter receives an error notification, fall back to its own S3 fetch
17.3. When a waiter does not receive a notification within the wait timeout, fall back to its own S3 fetch
17.4. When falling back, proceed with normal cache-miss handling

### 18. Download Coordination Configuration

**As a** proxy operator
**I want** to configure the download coordination behavior
**So that** I can tune it for my deployment

#### Acceptance Criteria

18.1. Support a `download_coordination` section under the `cache` configuration
18.2. Support an `enabled` boolean field (default: true)
18.3. Support a `wait_timeout_secs` integer field (default: 30)
18.4. When `enabled` is false, skip in-flight tracking and handle every cache-miss independently
18.5. Clamp `wait_timeout_secs` to 5-120 range and log a warning if out of bounds

### 19. Coalescing Metrics

**As a** proxy operator
**I want** metrics on download coalescing
**So that** I can monitor the effectiveness of request deduplication

#### Acceptance Criteria

19.1. Include `download_coalesce_waits_total` counter
19.2. Include `download_coalesce_cache_hits_total` counter
19.3. Include `download_coalesce_timeouts_total` counter
19.4. Include `download_coalesce_s3_fetches_saved_total` counter
19.5. Include `download_coalesce_wait_duration_seconds` histogram

### 20. In-Flight Tracker Cleanup and Safety

**As a** proxy operator
**I want** the in-flight tracker to clean up properly under all conditions
**So that** stale entries do not accumulate or block future requests

#### Acceptance Criteria

20.1. If the fetcher task panics or is cancelled, remove the flight key entry
20.2. When the broadcast sender is dropped, waiters detect channel closure and fall back
20.3. Use concurrent-safe data structures (DashMap) for simultaneous access from multiple Tokio tasks

### 21. Update Documentation

**As a** developer
**I want** documentation to accurately reflect the caching behavior
**So that** I understand how the system works

#### Acceptance Criteria

21.1. Document the dynamic Range signature detection behavior
21.2. Document when Range headers can be modified vs forwarded unchanged
21.3. Update CACHING.md to reflect dual-mode range handling and download coalescing
21.4. Remove the TODO in `config.rs` that suggests removing range modification functionality

## Out of Scope

- Cross-instance coordination for part fetches or download coalescing (each instance operates independently; NFS lock-based coordination is a future phase)
- Prefetching part metadata from S3
- Stream-sharing between fetcher and waiters (waiters use wait-then-serve from disk cache)
- Coalescing for PUT/write operations or HEAD requests

## Technical Notes

### Current Metadata Structure (to be changed)

```rust
pub struct ObjectMetadata {
    pub parts_count: Option<u32>,
    pub part_size: Option<u64>,  // REMOVE - assumes uniform size
    // ...
}
```

### Target Metadata Structure

```rust
pub struct ObjectMetadata {
    pub parts_count: Option<u32>,
    pub part_ranges: HashMap<u32, (u64, u64)>,  // NEW - byte range per part
    // Remove: pub part_size: Option<u64>,
    // ...
}
```

### Byte Range Storage

Each part's byte range is stored directly as (start, end):
- Part 1: (0, 10485759)
- Part 2: (10485760, 15728639)
- Part 3: (15728640, 24117247)

### CompleteMultipartUpload Request Body Format

```xml
<CompleteMultipartUpload>
  <Part>
    <PartNumber>1</PartNumber>
    <ETag>"a54357aff0632cce46d942af68356b38"</ETag>
  </Part>
  <Part>
    <PartNumber>3</PartNumber>
    <ETag>"0c78aef83f66abc1fa1e8477f296d394"</ETag>
  </Part>
</CompleteMultipartUpload>
```

### Flight Key Format

| Request Type | Flight Key Format | Example |
|---|---|---|
| Full object GET | `"{cache_key}"` | `"my-bucket/path/to/file.txt"` |
| Range request | `"{cache_key}:{start}-{end}"` | `"my-bucket/path/to/file.txt:0-8388607"` |
| Part number request | `"{cache_key}:part{N}"` | `"my-bucket/path/to/file.txt:part2"` |

### Glossary

- **Signed_Range**: A Range header included in the SigV4 signature (cannot be modified)
- **Unsigned_Range**: A Range header NOT included in the SigV4 signature (can be modified)
- **InFlight_Tracker**: Component that tracks in-progress S3 fetches and coordinates waiting requests
- **Flight_Key**: String identifying a unique in-progress fetch
- **Fetcher**: First request for a given Flight_Key that performs the actual S3 fetch
- **Waiter**: Subsequent request that subscribes to the Fetcher's broadcast channel
- **Wait_Timeout**: Maximum duration a Waiter blocks before falling back (default: 30 seconds)

### Test Scenarios

1. Upload parts 1, 2, 3; complete with parts 1, 2, 3 (all parts) - should work as before
2. Upload parts 1, 2, 3; complete with parts 1, 3 (skip part 2) - part 2 should be deleted
3. Upload parts 1, 3, 5; complete with parts 1, 3, 5 (non-contiguous) - should work
4. Upload parts 1, 2; complete with parts 1, 2, 3 (missing part 3) - should skip caching
5. GET with partNumber after CompleteMultipartUpload - should serve from cache
6. GET with partNumber for object not uploaded through proxy - should cache on first fetch
7. Concurrent GET requests for same uncached object - only one S3 fetch
8. Waiter timeout - falls back to own S3 fetch
9. Signed range request - forwarded unchanged, response cached
10. Unsigned range request with partial cache - only missing ranges fetched
