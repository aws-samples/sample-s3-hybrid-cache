# Design: Correct GET Part Behaviour

## Overview

This design addresses multipart upload part caching issues by:
1. Replacing uniform part size assumption with per-part size storage
2. Removing unnecessary request delay behavior
3. Properly filtering parts during CompleteMultipartUpload
4. Enabling cache hits for subsequent part requests

## Architecture Changes

### When Do We Calculate vs Use S3's Response?

**Key principle**: We calculate byte ranges for cache lookup and file naming. S3's response tells us the actual data.

| Scenario | Byte Range Source | Usage |
|----------|------------------|-------|
| UploadPart | Part size from request body | Store as `_part{N}_0-{size-1}.bin` |
| CompleteMultipartUpload | Calculate from part sizes | Rename to `_{start}-{end}.bin` |
| GET partNumber (cache hit) | Calculate from part_sizes | Look up `_{start}-{end}.bin` file |
| GET partNumber (cache miss) | S3's Content-Range header | Store range file, update part_sizes |

**File naming during upload vs after completion:**
- During upload: `_part2_0-5242879.bin` (part number + local offset within part)
- After completion: `_10485760-15728639.bin` (actual byte range in final object)

**Flow for objects uploaded through proxy:**
1. UploadPart stores `_part1_0-10485759.bin`, `_part2_0-5242879.bin`, etc.
2. CompleteMultipartUpload calculates cumulative offsets and renames files
3. Stores `part_sizes = {1: 10485760, 2: 5242880, ...}` in metadata
4. GET ?partNumber=2 → calculate range (10485760-15728639), find cached file

**Flow for external objects (not uploaded through proxy):**
1. First GET ?partNumber=2 → cache miss, forward to S3
2. S3 returns `Content-Range: bytes 10485760-15728639/24117248`
3. Store as `_10485760-15728639.bin` using S3's offsets
4. Store `part_sizes[2] = 5242880` in metadata
5. Second GET ?partNumber=2 → calculate range from part_sizes, find cached file

### Data Structure Changes

#### ObjectMetadata (cache_types.rs)

Remove:
```rust
pub part_size: Option<u64>,  // REMOVE - assumes uniform size
```

Add:
```rust
/// Maps part number to (start_offset, end_offset) byte range
/// Example: {1: (0, 10485759), 2: (10485760, 15728639), 3: (15728640, 24117247)}
#[serde(default)]
pub part_ranges: HashMap<u32, (u64, u64)>,
```

The `parts_count` field is retained for validation.

#### Remove ActivePartFetch (cache.rs)

Remove the entire `ActivePartFetch` struct and related fields:
- `active_part_fetches: Arc<Mutex<HashMap<String, ActivePartFetch>>>`
- `handle_missing_multipart_metadata()` function
- `register_part_fetch()`, `complete_part_fetch()`, `fail_part_fetch()` methods

### Component Changes

#### 1. cache_types.rs - ObjectMetadata

```rust
pub struct ObjectMetadata {
    // ... existing fields ...
    
    #[serde(default)]
    pub parts_count: Option<u32>,
    
    // REMOVE: pub part_size: Option<u64>,
    
    // NEW: Per-part byte range storage (start, end)
    #[serde(default)]
    pub part_ranges: HashMap<u32, (u64, u64)>,
    
    // ... rest of fields ...
}
```

#### 2. cache.rs - Part Range Lookup

Replace `calculate_part_range` with simple lookup:

```rust
/// Look up byte range for a part from stored part_ranges.
/// 
/// # Returns
/// - Ok((start, end)) if part exists in part_ranges
/// - Err if part not found
///
/// # Example
/// ```
/// // part_ranges = {1: (0, 10485759), 2: (10485760, 15728639)}
/// assert_eq!(get_part_range(2, &part_ranges), Ok((10485760, 15728639)));
/// ```
pub fn get_part_range(
    part_number: u32,
    part_ranges: &HashMap<u32, (u64, u64)>,
) -> Result<(u64, u64)> {
    part_ranges.get(&part_number)
        .copied()
        .ok_or_else(|| ProxyError::InvalidRequest(
            format!("Part {} not found in part_ranges", part_number)
        ))
}
```

No calculation needed - just a direct lookup.
```

#### 3. cache.rs - lookup_part Simplification

Remove delay logic, use direct range lookup:

```rust
pub async fn lookup_part(
    &self,
    cache_key: &str,
    part_number: u32,
) -> Result<Option<CachedPartResponse>> {
    // Load metadata
    let metadata = match self.get_metadata_from_disk(cache_key).await {
        Ok(Some(m)) => m,
        Ok(None) | Err(_) => return Ok(None),  // Cache miss, no delay
    };
    
    // Check if part range is known
    let (start, end) = match metadata.object_metadata.part_ranges.get(&part_number) {
        Some(&range) => range,
        None => return Ok(None),  // Part not found, cache miss
    };
    
    // Look up cached range data using the stored byte range
    // ... existing range lookup logic ...
}
```

#### 4. signed_put_handler.rs - CompleteMultipartUpload Parsing

Add XML parsing for CompleteMultipartUpload request body:

```rust
#[derive(Debug)]
struct RequestedPart {
    part_number: u32,
    etag: String,
}

fn parse_complete_mpu_request(body: &[u8]) -> Result<Vec<RequestedPart>> {
    let body_str = std::str::from_utf8(body)
        .map_err(|e| ProxyError::InvalidRequest(format!("Invalid UTF-8: {}", e)))?;
    
    let mut parts = Vec::new();
    
    // Simple XML parsing - find all <Part> elements
    for part_match in body_str.split("<Part>").skip(1) {
        if let Some(end_idx) = part_match.find("</Part>") {
            let part_xml = &part_match[..end_idx];
            
            // Extract PartNumber
            let part_number = extract_xml_value(part_xml, "PartNumber")?
                .parse::<u32>()
                .map_err(|e| ProxyError::InvalidRequest(format!("Invalid PartNumber: {}", e)))?;
            
            // Extract ETag
            let etag = extract_xml_value(part_xml, "ETag")?;
            
            parts.push(RequestedPart { part_number, etag });
        }
    }
    
    Ok(parts)
}

fn extract_xml_value(xml: &str, tag: &str) -> Result<String> {
    let start_tag = format!("<{}>", tag);
    let end_tag = format!("</{}>", tag);
    
    let start = xml.find(&start_tag)
        .ok_or_else(|| ProxyError::InvalidRequest(format!("Missing <{}>", tag)))?
        + start_tag.len();
    let end = xml.find(&end_tag)
        .ok_or_else(|| ProxyError::InvalidRequest(format!("Missing </{}>", tag)))?;
    
    Ok(xml[start..end].trim().to_string())
}
```

#### 5. signed_put_handler.rs - Filter Parts and Store Sizes

Modify `finalize_multipart_upload` to filter parts and store sizes:

```rust
async fn finalize_multipart_upload(
    &self,
    cache_key: &str,
    upload_id: &str,
    requested_parts: &[RequestedPart],
    s3_etag: &str,
    content_length: u64,
) -> Result<()> {
    // Load upload tracker
    let tracker = self.load_upload_tracker(upload_id).await?;
    
    // Build set of requested part numbers
    let requested_part_numbers: HashSet<u32> = requested_parts
        .iter()
        .map(|p| p.part_number)
        .collect();
    
    // Filter cached parts to only those in request
    let mut filtered_parts: Vec<&CachedPartInfo> = tracker.parts
        .iter()
        .filter(|p| requested_part_numbers.contains(&p.part_number))
        .collect();
    filtered_parts.sort_by_key(|p| p.part_number);
    
    // Check all requested parts are cached and ETags match
    for rp in requested_parts {
        match filtered_parts.iter().find(|p| p.part_number == rp.part_number) {
            None => {
                warn!("Requested part {} not cached, skipping cache finalization", rp.part_number);
                return Ok(());
            }
            Some(cached_part) => {
                // Normalize ETags for comparison (remove quotes if present)
                let request_etag = rp.etag.trim_matches('"');
                let cached_etag = cached_part.etag.trim_matches('"');
                
                if request_etag != cached_etag {
                    warn!(
                        "ETag mismatch for part {}: request='{}', cached='{}', skipping cache finalization",
                        rp.part_number, request_etag, cached_etag
                    );
                    return Ok(());
                }
            }
        }
    }
    
    // Build part_ranges map from filtered parts
    let mut part_ranges: HashMap<u32, (u64, u64)> = HashMap::new();
    let mut current_offset: u64 = 0;
    for part in &filtered_parts {
        let start = current_offset;
        let end = current_offset + part.size - 1;
        part_ranges.insert(part.part_number, (start, end));
        current_offset += part.size;
    }
    
    // Identify and delete unreferenced parts
    let unreferenced: Vec<&CachedPartInfo> = tracker.parts
        .iter()
        .filter(|p| !requested_part_numbers.contains(&p.part_number))
        .collect();
    
    for part in &unreferenced {
        if let Err(e) = self.delete_part_range_file(&part.range_file_path).await {
            warn!("Failed to delete unreferenced part {}: {}", part.part_number, e);
        } else {
            info!("Deleted unreferenced part {} for upload {}", part.part_number, upload_id);
        }
    }
    
    // Create object metadata with part_ranges
    let object_metadata = ObjectMetadata {
        etag: s3_etag.to_string(),
        content_length,
        parts_count: Some(filtered_parts.len() as u32),
        part_ranges,
        // ... other fields ...
    };
    
    // Save metadata and create range specs
    // ... existing finalization logic ...
}
```

#### 6. http_proxy.rs - Store Part Size from GET Response

When handling GET with partNumber response from S3:

```rust
// After receiving S3 response for GET with partNumber
if let Some(part_number) = query_part_number {
    // Parse Content-Range header: "bytes 0-1048575/10485760"
    if let Some(content_range) = response.headers().get("content-range") {
        if let Ok(range_str) = content_range.to_str() {
            if let Some((start, end, _total)) = parse_content_range(range_str) {
                // Update metadata with this part's byte range
                if let Ok(Some(mut metadata)) = cache.get_metadata_from_disk(&cache_key).await {
                    metadata.object_metadata.part_ranges.insert(part_number, (start, end));
                    
                    // Also update parts_count if we learn it from x-amz-mp-parts-count
                    if let Some(count_header) = response.headers().get("x-amz-mp-parts-count") {
                        if let Ok(count) = count_header.to_str().unwrap_or("0").parse::<u32>() {
                            metadata.object_metadata.parts_count = Some(count);
                        }
                    }
                    
                    cache.save_metadata(&cache_key, &metadata).await?;
                }
            }
        }
    }
}
```

## Sequence Diagrams

### GET with partNumber (Cache Miss → Cache Hit)

```
Client          Proxy           S3
  |               |              |
  |--GET ?partNumber=2---------->|
  |               |              |
  |  lookup_part(key, 2)         |
  |  part_ranges empty → miss    |
  |               |              |
  |               |--GET-------->|
  |               |<--200--------|
  |               |              |
  |  parse Content-Range         |
  |  store part_ranges[2]=(s,e)  |
  |  store range file            |
  |               |              |
  |<--200------------------------|
  |               |              |
  |--GET ?partNumber=2---------->|
  |               |              |
  |  lookup_part(key, 2)         |
  |  part_ranges[2] exists       |
  |  direct lookup, serve        |
  |               |              |
  |<--200 (from cache)-----------|
```

### CompleteMultipartUpload with Filtered Parts

```
Client          Proxy           S3
  |               |              |
  |--CompleteMPU(parts 1,3)----->|
  |               |              |
  |  parse XML: [1, 3]           |
  |  buffer request body         |
  |               |              |
  |               |--CompleteMPU>|
  |               |<--200--------|
  |               |              |
  |  filter cached parts         |
  |  delete part 2 (unreferenced)|
  |  build part_ranges           |
  |  save metadata               |
  |               |              |
  |<--200------------------------|
```

## Correctness Properties

### Property 1: Part Range Lookup Returns Stored Values
**Validates: Requirements 1.3, 8.1**

For any part_ranges map and part_number:
- If part exists in map, lookup returns the exact stored (start, end) tuple
- If part doesn't exist, lookup returns error

```rust
#[quickcheck]
fn prop_part_range_lookup(part_ranges: Vec<(u32, u64, u64)>, target_part: u32) -> TestResult {
    // Build map from valid entries
    let ranges: HashMap<u32, (u64, u64)> = part_ranges.into_iter()
        .filter(|(pn, s, e)| *pn > 0 && *s <= *e)
        .map(|(pn, s, e)| (pn, (s, e)))
        .collect();
    
    if ranges.is_empty() {
        return TestResult::discard();
    }
    
    let result = get_part_range(target_part, &ranges);
    
    match (ranges.get(&target_part), result) {
        (Some(&expected), Ok(actual)) => TestResult::from_bool(expected == actual),
        (None, Err(_)) => TestResult::passed(),
        _ => TestResult::failed(),
    }
}
```

### Property 2: Part Filtering Preserves Only Requested Parts
**Validates: Requirements 5.1, 5.2**

For any set of cached parts and requested parts:
- The filtered result contains only parts in the requested set
- No unrequested parts appear in the result

```rust
#[quickcheck]
fn prop_part_filtering(cached: Vec<u32>, requested: Vec<u32>) -> TestResult {
    let cached_set: HashSet<u32> = cached.into_iter().filter(|&p| p > 0).collect();
    let requested_set: HashSet<u32> = requested.into_iter().filter(|&p| p > 0).collect();
    
    if cached_set.is_empty() || requested_set.is_empty() {
        return TestResult::discard();
    }
    
    let filtered: HashSet<u32> = cached_set.intersection(&requested_set).copied().collect();
    
    // All filtered parts must be in requested set
    let all_requested = filtered.iter().all(|p| requested_set.contains(p));
    // No unrequested parts in filtered
    let no_unrequested = filtered.iter().all(|p| requested_set.contains(p));
    
    TestResult::from_bool(all_requested && no_unrequested)
}
```

### Property 3: Content-Range Parsing Extracts Correct Size
**Validates: Requirement 3.1**

For any valid Content-Range header:
- The extracted size equals end - start + 1

```rust
#[quickcheck]
fn prop_content_range_parsing(start: u64, size: u64, total: u64) -> TestResult {
    if size == 0 || start + size > total {
        return TestResult::discard();
    }
    
    let end = start + size - 1;
    let header = format!("bytes {}-{}/{}", start, end, total);
    
    let (parsed_start, parsed_end, parsed_total) = parse_content_range(&header).unwrap();
    let parsed_size = parsed_end - parsed_start + 1;
    
    TestResult::from_bool(
        parsed_start == start &&
        parsed_end == end &&
        parsed_total == total &&
        parsed_size == size
    )
}
```

### Property 4: Part Ranges Build Correctly from Sizes
**Validates: Requirement 7.1**

When building part_ranges from part sizes, cumulative offsets are calculated correctly.

```rust
#[quickcheck]
fn prop_part_ranges_build(sizes: Vec<u64>) -> TestResult {
    let sizes: Vec<u64> = sizes.into_iter().filter(|&s| s > 0).collect();
    if sizes.is_empty() {
        return TestResult::discard();
    }
    
    // Build part_ranges like finalize_multipart_upload does
    let mut part_ranges: HashMap<u32, (u64, u64)> = HashMap::new();
    let mut current_offset: u64 = 0;
    for (i, &size) in sizes.iter().enumerate() {
        let part_num = (i + 1) as u32;
        let start = current_offset;
        let end = current_offset + size - 1;
        part_ranges.insert(part_num, (start, end));
        current_offset += size;
    }
    
    // Verify each part's range
    for (i, &size) in sizes.iter().enumerate() {
        let part_num = (i + 1) as u32;
        let (start, end) = part_ranges[&part_num];
        
        // Start should be sum of all preceding sizes
        let expected_start: u64 = sizes[..i].iter().sum();
        let expected_end = expected_start + size - 1;
        
        if start != expected_start || end != expected_end {
            return TestResult::failed();
        }
    }
    
    TestResult::passed()
}
```

### Property 5: ETag Validation Rejects Mismatches
**Validates: Requirement 9.1, 9.2**

When cached ETag differs from request ETag, cache finalization is skipped.

```rust
#[quickcheck]
fn prop_etag_validation(cached_etag: String, request_etag: String) -> TestResult {
    // Normalize ETags (remove quotes)
    let cached = cached_etag.trim_matches('"');
    let request = request_etag.trim_matches('"');
    
    if cached.is_empty() || request.is_empty() {
        return TestResult::discard();
    }
    
    let should_skip = cached != request;
    
    // Simulate validation logic
    let validation_result = if cached == request {
        "proceed"
    } else {
        "skip"
    };
    
    TestResult::from_bool(
        (should_skip && validation_result == "skip") ||
        (!should_skip && validation_result == "proceed")
    )
}
```

## Testing Strategy

### Unit Tests
- Direct part range lookup from `part_ranges` map
- XML parsing for CompleteMultipartUpload request body
- Content-Range header parsing
- Part filtering logic
- Part ranges building from sizes

### Integration Tests
- GET with partNumber for object uploaded via proxy (CompleteMultipartUpload path)
- GET with partNumber for object not uploaded via proxy (learn ranges from S3)
- CompleteMultipartUpload with subset of uploaded parts
- Cache hit on second GET with same partNumber

### Property-Based Tests
- Part range lookup returns stored values
- Part filtering preserves only requested parts
- Content-Range parsing extracts correct values
- Part ranges build correctly from sizes

## Migration

### Backward Compatibility

Existing cached metadata with `part_size` field will be handled:
1. If `part_ranges` is empty and `part_size` exists, treat as cache miss for part requests
2. The old `part_size` field will be ignored (serde default handles missing fields)
3. New metadata will only use `part_ranges`

No migration script needed - cache misses will naturally repopulate with new format.

## Files to Modify

1. `src/cache_types.rs` - Add `part_ranges` field, remove `part_size`
2. `src/cache.rs` - Simplify `lookup_part` to use direct lookup, remove delay logic
3. `src/signed_put_handler.rs` - Add XML parsing, filter parts, build and store ranges
4. `src/http_proxy.rs` - Store part range from GET response
5. `tests/part_number_caching_integration_test.rs` - Update tests
6. `tests/part_number_caching_property_test.rs` - Add new property tests
