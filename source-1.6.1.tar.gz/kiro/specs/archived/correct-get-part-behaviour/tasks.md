# Implementation Plan: Correct GET Part Behaviour

## Overview

Implement part caching fixes, in-flight request coalescing, and smart range caching improvements. Tasks are ordered so each builds on the previous: data model changes first, then behavior changes, then new modules, then integration and cleanup.

## Tasks

- [x] 1. Update ObjectMetadata data structure
  - [x] 1.1 Add `part_ranges: HashMap<u32, (u64, u64)>` field to `ObjectMetadata` in `src/cache_types.rs`
    - Add `#[serde(default)]` attribute for backward compatibility
    - Add `use std::collections::HashMap;` if not already imported
    - _Requirements: 1.2_
  - [x] 1.2 Remove `part_size: Option<u64>` field from `ObjectMetadata`
    - Search all usages across the codebase and update or remove them
    - _Requirements: 1.1_
  - [x] 1.3 Update `ObjectMetadata` constructors and `Default` impl
    - Add `part_ranges: HashMap::new()` to all constructors
    - Update `Default` impl to include `part_ranges`
    - _Requirements: 1.2_
  - [x] 1.4 Add unit tests for `ObjectMetadata` serialization with `part_ranges`
    - Test serialization roundtrip with populated `part_ranges`
    - Test deserialization of old format (missing `part_ranges`) defaults to empty `HashMap`
    - _Requirements: 1.4_

- [x] 2. Remove request delay behaviour
  - [x] 2.1 Remove `ActivePartFetch` struct and `active_part_fetches` field from `src/cache.rs`
    - Remove the struct definition, the `DashMap` field, and all imports only used by them
    - _Requirements: 2.1, 2.2_
  - [x] 2.2 Remove `handle_missing_multipart_metadata` function and delay/503 logic
    - Remove the function and the 5-second sleep / deferred count tracking
    - _Requirements: 2.1, 2.5_
  - [x] 2.3 Remove `register_part_fetch`, `complete_part_fetch`, `fail_part_fetch` methods
    - _Requirements: 2.3_
  - [x] 2.4 Remove callers of the removed methods in `src/http_proxy.rs`
    - Update call sites to simply proceed with cache miss → forward to S3
    - _Requirements: 2.4, 2.6_

- [x] 3. Simplify part cache lookup
  - [x] 3.1 Update `lookup_part` in `src/cache.rs` to use direct `part_ranges` lookup
    - Replace calculation logic with `metadata.object_metadata.part_ranges.get(&part_number)`
    - Return `Ok(None)` immediately if part not in map (no delay)
    - _Requirements: 8.1, 8.2, 8.3, 8.4_
  - [x] 3.2 Remove or replace `calculate_part_range` function
    - Remove if no other callers remain; otherwise update to use `part_ranges`
    - _Requirements: 1.3_
  - [x] 3.3 Remove any remaining references to old `part_size` field in lookup logic
    - _Requirements: 1.1_

- [x] 4. Checkpoint — Part lookup refactoring
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Parse CompleteMultipartUpload request body
  - [x] 5.1 Add `RequestedPart` struct in `src/signed_put_handler.rs`
    - Fields: `part_number: u32`, `etag: String`
    - _Requirements: 4.2_
  - [x] 5.2 Implement `parse_complete_mpu_request(body: &[u8]) -> Result<Vec<RequestedPart>>`
    - Parse XML to extract `<Part>` elements with `<PartNumber>` and `<ETag>`
    - Return error on malformed XML; handle empty body gracefully
    - _Requirements: 4.1, 4.2, 4.3_
  - [x] 5.3 Implement `extract_xml_value(xml: &str, tag: &str) -> Result<String>` helper
    - _Requirements: 4.2_
  - [x] 5.4 Add unit tests for XML parsing
    - Test valid XML with multiple parts, empty XML, malformed XML, missing fields
    - _Requirements: 4.1, 4.2, 4.3_

- [x] 6. Filter parts, validate ETags, and build part ranges during CompleteMultipartUpload
  - [x] 6.1 Update `handle_complete_multipart_upload` to buffer and parse request body before forwarding
    - Buffer the request body, parse to get requested parts list, forward original body to S3
    - _Requirements: 4.1, 4.4, 5.1_
  - [x] 6.2 Implement part filtering logic in `finalize_multipart_upload`
    - Accept `requested_parts: &[RequestedPart]`, build `HashSet` of requested part numbers
    - Filter cached parts to only those in request, sort by part number
    - _Requirements: 5.1, 5.2, 5.3_
  - [x] 6.3 Implement ETag validation
    - Compare request ETag with cached ETag (normalize by removing quotes)
    - Skip cache finalization on mismatch, log warning with part number and both ETags
    - Still forward request to S3 regardless
    - _Requirements: 9.1, 9.2, 9.3, 9.4_
  - [x] 6.4 Implement part_ranges building from filtered parts
    - Calculate cumulative byte offsets from filtered parts in part-number order
    - Build `HashMap<u32, (u64, u64)>` with (start, end) for each part
    - Store `part_ranges` and `parts_count` in completed object's metadata
    - _Requirements: 7.1, 7.2, 7.3_
  - [x] 6.5 Implement unreferenced part cleanup
    - Identify cached parts not in requested parts list
    - Delete range files for unreferenced parts, log each deletion
    - Handle deletion failures gracefully (log warning, continue)
    - _Requirements: 6.1, 6.2, 6.3, 6.4_
  - [x] 6.6 Add unit tests for part filtering, ETag validation, and part_ranges building
    - Test filtering with subset of parts, contiguous and non-contiguous parts
    - Test ETag match and mismatch scenarios
    - Test cumulative offset calculation with variable-sized parts
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 7.1, 9.1, 9.2_

- [x] 7. Store part range from GET response
  - [x] 7.1 Add `parse_content_range(header: &str) -> Option<(u64, u64, u64)>` helper in `src/http_proxy.rs`
    - Parse `bytes start-end/total` format, return `(start, end, total)`
    - _Requirements: 3.1_
  - [x] 7.2 Update GET with `partNumber` response handling in `src/http_proxy.rs`
    - Extract `Content-Range` header from S3 response
    - Parse to get `(start, end)`, store in `metadata.object_metadata.part_ranges`
    - Update `parts_count` from `x-amz-mp-parts-count` header if present
    - Save updated metadata to disk
    - _Requirements: 3.1, 3.2, 3.3, 3.4_
  - [x] 7.3 Add unit tests for Content-Range parsing
    - Test valid headers, missing headers, malformed headers
    - _Requirements: 3.1_

- [x] 8. Checkpoint — Part caching complete
  - Ensure all tests pass, ask the user if questions arise.

- [x] 9. Property-based tests for part caching
  - [x] 9.1 (PBT) Property test: part range lookup returns stored values
    - **Property 1: Part Range Lookup Returns Stored Values**
    - *For any* `part_ranges` map and part number, if the part exists in the map, lookup returns the exact stored `(start, end)` tuple; if the part doesn't exist, lookup returns `None`
    - **Validates: Requirements 1.3, 8.1**
  - [x] 9.2 (PBT) Property test: part filtering preserves only requested parts
    - **Property 2: Part Filtering Preserves Only Requested Parts**
    - *For any* set of cached parts and requested parts, the filtered result contains exactly the intersection
    - **Validates: Requirements 5.1, 5.2**
  - [x] 9.3 (PBT) Property test: Content-Range parsing extracts correct values
    - **Property 3: Content-Range Parsing Extracts Correct Size**
    - *For any* valid Content-Range header string `bytes {start}-{end}/{total}`, the parsed size equals `end - start + 1`
    - **Validates: Requirement 3.1**
  - [x] 9.4 (PBT) Property test: part_ranges building from sizes
    - **Property 4: Part Ranges Build Correctly from Sizes**
    - *For any* ordered list of part sizes, cumulative offsets produce contiguous non-overlapping ranges where each range length equals the part size
    - **Validates: Requirement 7.1**
  - [x] 9.5 (PBT) Property test: ETag validation rejects mismatches
    - **Property 5: ETag Validation Rejects Mismatches**
    - *For any* pair of distinct ETags, comparing them causes cache finalization to be skipped; for any identical pair (with or without surrounding quotes), finalization proceeds
    - **Validates: Requirements 9.1, 9.2**

- [x] 10. Implement InFlightTracker module
  - [x] 10.1 Create `src/inflight_tracker.rs` with `InFlightTracker` struct
    - Use `DashMap<String, broadcast::Sender<FetchResult>>` for pending fetches
    - Implement `new()`, `try_register(flight_key) -> FetchRole`, `in_flight_count()`
    - Implement `make_range_key()`, `make_full_key()`, `make_part_key()` static methods
    - _Requirements: 15.1, 15.2, 15.3, 15.4_
  - [x] 10.2 Implement `FetchGuard` with RAII cleanup
    - `complete_success()` — broadcast `Ok(())`, remove entry from `DashMap`
    - `complete_error(error)` — broadcast `Err(error)`, remove entry
    - `Drop` impl — remove entry if not already completed (safety net for panics/cancellation)
    - _Requirements: 16.1, 16.2, 16.3, 20.1, 20.2_
  - [x] 10.3 Implement `FetchRole` enum: `Fetcher(FetchGuard)` / `Waiter(broadcast::Receiver<FetchResult>)`
    - _Requirements: 15.1, 15.2_
  - [x] 10.4 Add `mod inflight_tracker;` to `src/main.rs`
    - _Requirements: 15.1_
  - [x] 10.5 Add unit tests for InFlightTracker
    - Test first register returns `Fetcher`, second returns `Waiter`
    - Test `complete_success` removes entry and notifies waiters
    - Test `Drop` without complete removes entry
    - Test waiter detects channel closure on fetcher drop
    - _Requirements: 15.1, 15.2, 16.1, 16.2, 16.3, 20.1, 20.2_

- [x] 11. Add download coordination configuration
  - [x] 11.1 Add `DownloadCoordinationConfig` struct to `src/config.rs`
    - `enabled: bool` (default: `true`), `wait_timeout_secs: u64` (default: 30)
    - Clamp `wait_timeout_secs` to 5–120 range, log warning if out of bounds
    - _Requirements: 18.1, 18.2, 18.3, 18.5_
  - [x] 11.2 Add `download_coordination` field to `CacheConfig` with `#[serde(default)]`
    - _Requirements: 18.1_
  - [x] 11.3 Update `config.example.yaml` with `download_coordination` section
    - _Requirements: 18.1_
  - [x] 11.4 Add unit tests for config parsing and clamping
    - Test defaults, valid values, out-of-bounds clamping
    - _Requirements: 18.2, 18.3, 18.5_

- [x] 12. Integrate InFlightTracker into HttpProxy
  - [x] 12.1 Add `inflight_tracker: Arc<InFlightTracker>` field to `HttpProxy` and initialize in `new()`
    - _Requirements: 15.1, 20.3_
  - [x] 12.2 Integrate tracker for full-object GET cache misses
    - Before `forward_get_head_to_s3_and_cache`, call `try_register` with full key
    - Fetcher path: forward to S3, cache, call `guard.complete_success()`
    - Waiter path: wait with timeout, serve from cache or fall back
    - _Requirements: 15.1, 15.2, 15.4, 17.1, 17.2, 17.3, 17.4_
  - [x] 12.3 Integrate tracker for range request cache misses
    - Before `forward_range_request_to_s3` or `forward_signed_range_request`, call `try_register` with range key
    - Same fetcher/waiter pattern
    - _Requirements: 15.3, 17.1, 17.2, 17.3, 17.4_
  - [x] 12.4 Integrate tracker for part-number cache misses
    - Before forwarding part GET to S3, call `try_register` with part key
    - Same fetcher/waiter pattern
    - _Requirements: 15.3, 17.1, 17.2, 17.3, 17.4_
  - [x] 12.5 Respect `download_coordination.enabled` config flag
    - When disabled, skip tracker and handle every cache miss independently
    - _Requirements: 18.4_

- [x] 13. Add coalescing metrics
  - [x] 13.1 Add `CoalescingMetrics` struct to `src/metrics.rs`
    - Fields: `waits_total`, `cache_hits_total`, `timeouts_total`, `s3_fetches_saved_total`
    - `wait_duration_sum_ms`, `wait_duration_count`
    - _Requirements: 19.1, 19.2, 19.3, 19.4, 19.5_
  - [x] 13.2 Add recording methods to `MetricsManager`
    - `record_coalesce_wait()`, `record_coalesce_cache_hit()`, `record_coalesce_timeout()`
    - `record_coalesce_s3_fetch_saved()`, `record_coalesce_wait_duration(duration)`
    - _Requirements: 19.1, 19.2, 19.3, 19.4, 19.5_
  - [x] 13.3 Instrument waiter/fetcher paths in `HttpProxy` with metric calls
    - Record wait on waiter entry, cache hit on successful serve, timeout on fallback, fetch saved on waiter success
    - _Requirements: 19.1, 19.2, 19.3, 19.4, 19.5_
  - [x] 13.4 Expose metrics through `/metrics` endpoint and OTLP export
    - _Requirements: 19.1, 19.2, 19.3, 19.4, 19.5_

- [x] 14. Checkpoint — InFlightTracker and coalescing complete
  - Ensure all tests pass, ask the user if questions arise.

- [x] 15. Property-based tests for InFlightTracker
  - [x] 15.1 (PBT) Property test: InFlightTracker registration determinism
    - **Property 6: InFlightTracker Registration Determinism**
    - *For any* flight key string, the first call to `try_register` returns `Fetcher`; all subsequent calls before completion return `Waiter`
    - **Validates: Requirements 15.1, 15.2**
  - [x] 15.2 (PBT) Property test: FetchGuard cleanup on drop
    - **Property 7: FetchGuard Cleanup on Drop**
    - *For any* flight key, when a `FetchGuard` is dropped without calling `complete_success` or `complete_error`, the flight key is removed from the tracker and a new `try_register` returns `Fetcher`
    - **Validates: Requirement 20.1**

- [x] 16. Smart range caching improvements
  - [x] 16.1 Remove the TODO in `src/config.rs` (~line 874) suggesting removal of range modification
    - Replace with comment referencing dual-mode design (signed vs unsigned ranges)
    - _Requirements: 21.4_
  - [x] 16.2 Add ETag mismatch invalidation in `store_range()`
    - When ETag mismatch detected, invalidate existing cached ranges for that object
    - Allow new data to be cached on next request
    - Log the mismatch and invalidation
    - _Requirements: 14.1, 14.2, 14.3_

- [~] 17. Integration tests (requires S3 access - skipped for now)
  - [~] 17.1 Integration test: GET `partNumber` after `CompleteMultipartUpload`
    - Upload parts via proxy, complete multipart upload, GET with `partNumber` should hit cache
    - _Requirements: 3.4, 7.2, 8.1_
  - [~] 17.2 Integration test: GET `partNumber` for external object (not uploaded through proxy)
    - First GET misses cache and fetches from S3; second GET hits cache
    - _Requirements: 3.1, 3.2, 3.3, 3.4_
  - [~] 17.3 Integration test: `CompleteMultipartUpload` with subset of parts
    - Upload parts 1, 2, 3; complete with parts 1, 3; verify part 2 deleted
    - _Requirements: 5.1, 5.2, 6.1, 6.2_
  - [~] 17.4 Integration test: ETag mismatch skips caching
    - Upload part with one ETag, complete with different ETag, verify cache finalization skipped
    - _Requirements: 9.1, 9.2_
  - [~] 17.5 Integration test: concurrent GET requests coalesced
    - Two concurrent requests for same uncached object; verify only one S3 fetch; both clients get correct response
    - _Requirements: 15.1, 15.2, 16.1, 17.1_
  - [~] 17.6 Integration test: waiter timeout falls back
    - Simulate slow fetcher exceeding `wait_timeout`; verify waiter falls back to own S3 fetch
    - _Requirements: 17.3_
  - [~] 17.7 Integration test: fetcher error notifies waiters
    - Fetcher encounters S3 error; verify waiters fall back to own S3 fetch
    - _Requirements: 16.2, 17.2_

- [x] 18. Cleanup and documentation
  - [x] 18.1 Remove any remaining references to old `part_size` field across the codebase
    - _Requirements: 1.1_
  - [x] 18.2 Update code comments to reflect new `part_ranges` approach
    - _Requirements: 1.2_
  - [x] 18.3 Run full test suite and fix any regressions
  - [x] 18.4 Update `CHANGELOG.md`
    - Document removal of request delay behavior, new `part_ranges` storage, `CompleteMultipartUpload` filtering, ETag validation, download coalescing, smart range caching improvements
  - [x] 18.5 Update `docs/CACHING.md` with part caching, download coalescing, and dual-mode range handling
    - _Requirements: 21.1, 21.2, 21.3_

- [x] 19. Final checkpoint
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
- Unit tests validate specific examples and edge cases
- The InFlightTracker replaces the old `ActivePartFetch` delay mechanism entirely