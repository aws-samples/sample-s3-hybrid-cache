# Design: Logging Reductions, Consolidation Performance & Documentation (v1.1.38)

## Overview

This design covers three categories of changes:

**A. Logging Reductions** — Change 8 high-volume INFO log sites to DEBUG level. These logs fire per-chunk, per-entry, or per-key during normal operations, producing hundreds to thousands of lines per consolidation cycle or download.

**B. Performance Improvements** — Increase `KEY_CONCURRENCY_LIMIT` from 4 to 8, batch eviction journal writes by cache key, and remove the dead `calculate_size_delta()` function along with its tests.

**C. Documentation Audit** — Update `docs/CACHING.md`, `docs/ARCHITECTURE.md`, and `docs/CONFIGURATION.md` to accurately reflect accumulator-based size tracking.

## Architecture

No architectural changes. All modifications are within existing modules:

- `src/disk_cache.rs` — Log level change (1 site)
- `src/journal_consolidator.rs` — Log level changes (7 sites), constant change, function removal, test removal
- `src/journal_manager.rs` — New batch append method
- `tests/journal_size_tracking_property_test.rs` — Remove `calculate_size_delta` property test and import
- `docs/CACHING.md`, `docs/ARCHITECTURE.md`, `docs/CONFIGURATION.md` — Text corrections

## Components and Interfaces

### A. Logging Reductions

All changes are `info!` → `debug!` macro swaps at specific call sites. No interface changes.

| Log Message | File | Line(s) | Volume |
|---|---|---|---|
| "Range stored (hybrid)" | `disk_cache.rs` | 1170 | ~640/5GB download |
| "SIZE_TRACK: Add COUNTED/SKIPPED" | `journal_consolidator.rs` | 508-519 | thousands/cycle |
| "SIZE_TRACK: Remove COUNTED" | `journal_consolidator.rs` | 529 | thousands/cycle |
| "Object metadata journal consolidation completed" | `journal_consolidator.rs` | 2341 | per-key/cycle |
| "Removing journal entry for evicted range" | `journal_consolidator.rs` | 2610 | 1,400+/eviction |
| "Removing stale journal entry" | `journal_consolidator.rs` | 2637 | per-stale-entry |
| "Atomic size subtract" | `journal_consolidator.rs` | 1478 | per-eviction-call |
| "Atomic size add" | `journal_consolidator.rs` | 1662 | per-add-call |
| "Atomic size add (non-blocking)" | `journal_consolidator.rs` | 1790 | per-add-call |

Logs that remain at INFO:
- "SIZE_TRACK: calculate_size_delta summary" (line 542) — retained until function removal in part B
- `SizeAccumulator::flush()` and `collect_and_apply_deltas()` — per-cycle summaries

### B1. KEY_CONCURRENCY_LIMIT Change

Single constant change:

```rust
// Before
const KEY_CONCURRENCY_LIMIT: usize = 4;

// After
const KEY_CONCURRENCY_LIMIT: usize = 8;
```

No interface changes. The existing `buffer_unordered(KEY_CONCURRENCY_LIMIT)` call in `run_consolidation_cycle()` automatically uses the new value.

### B2. Batch Eviction Journal Writes

New method on `JournalManager`:

```rust
impl JournalManager {
    /// Append multiple journal entries for a single cache key in one file operation.
    /// Serializes all entries, acquires the append mutex once, and writes them
    /// in a single read-modify-write cycle.
    pub async fn append_range_entries_batch(
        &self,
        cache_key: &str,
        entries: Vec<JournalEntry>,
    ) -> Result<()>;
}
```

Modified `write_eviction_journal_entries()` in `JournalConsolidator`:

```rust
// Before: one append_range_entry() call per evicted range
for (cache_key, range_start, range_end, size, bin_file_path) in evicted_ranges {
    // ... build entry ...
    self.journal_manager.append_range_entry(&cache_key, journal_entry).await;
}

// After: group by cache_key, one batch call per key
let mut grouped: HashMap<String, Vec<JournalEntry>> = HashMap::new();
for (cache_key, range_start, range_end, size, bin_file_path) in evicted_ranges {
    // ... build entry ...
    grouped.entry(cache_key).or_default().push(journal_entry);
}
for (cache_key, entries) in grouped {
    self.journal_manager.append_range_entries_batch(&cache_key, entries).await;
}
```

The batch method follows the same locking pattern as `append_range_entry()`:
1. Serialize all entries to JSON lines before acquiring locks
2. Acquire the append mutex once
3. Try file lock (non-blocking), fall back to fresh journal if busy
4. Read existing content, append all serialized entries, write atomically
5. Release locks

Journal file format is unchanged — one JSON object per line. The batch method simply appends multiple lines in a single write.

### B3. Remove calculate_size_delta() and Related Dead Code

Remove the following:
- `pub fn calculate_size_delta(entries: &[JournalEntry]) -> (i64, i64)` function (~60 lines)
- Helper function `create_journal_entry_with_size()` — only used by `calculate_size_delta` tests
- `ConsolidationResult::success_with_size_delta()` constructor — defined but never called anywhere
- 12 unit tests: `test_calculate_size_delta_*` (lines 4343-4582)
- Property test `prop_calculate_size_delta_correctness` in `tests/journal_size_tracking_property_test.rs`
- The `calculate_size_delta` import in `tests/journal_size_tracking_property_test.rs`
- The `pub use` export in `lib.rs` (if present)

Stale comments to clean up:
- Line 2285: "calculate_size_delta() is no longer called here" — simplify since function no longer exists
- Line 813: "This is what calculate_size_delta uses" — remove stale reference

Additionally, `ConsolidationResult.size_delta` and `write_cache_delta` fields are always set to 0 in `consolidate_object()`. The accumulation variables `_total_size_delta` and `_total_write_cache_delta` in `run_consolidation_cycle()` are prefixed with `_` (unused). These fields could be removed from `ConsolidationResult`, but that's a larger refactor — for now, just remove the dead `success_with_size_delta()` constructor and clean up comments.

### C. Documentation Updates

**`docs/CACHING.md`** — Eviction Triggers section (around line 3209):
- Change "Consolidator processes journal entries and calculates size delta" to describe the accumulator-based approach: consolidator collects per-instance delta files and sums them into size_state.json

**`docs/ARCHITECTURE.md`**:
- Verify module organization table matches actual `src/` contents (check for missing modules like `cache_validator.rs`, `capacity_manager.rs`, `background_recovery.rs`, `orphaned_range_recovery.rs`, `log_sampler.rs`, `performance_logger.rs`, `presigned_url.rs`, `signed_put_handler.rs`, `signed_request_proxy.rs`, `https_connector.rs`, `dashboard.rs`, `streaming_tee.rs`, `write_cache_manager.rs`)
- Verify the "Buffered Logging and Accumulator-Based Size Tracking" section is accurate

**`docs/CONFIGURATION.md`** — Cache Size Tracking section (around line 624):
- Change "calculates size deltas from journal entries" to describe accumulator-based tracking
- Change "Size deltas are calculated from Add/Remove operations in journal entries" to describe in-memory accumulator flushing to delta files
- Remove "journal entries are processed directly" from deprecated options

## Data Models

No data model changes. Journal entry format (`JournalEntry`) is unchanged. The batch append method writes the same JSON-per-line format.


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

Most changes in this feature are static code modifications (log level swaps, constant changes, code removal, documentation edits) that are verified by the compiler or by inspection. The one behavioral change that benefits from property-based testing is the new batch append method.

### Property 1: Batch append equivalence

*For any* list of valid `JournalEntry` objects for a given cache key, calling `append_range_entries_batch(cache_key, entries)` on an empty journal SHALL produce identical file content to calling `append_range_entry(cache_key, entry)` sequentially for each entry on a separate empty journal.

This is a round-trip / equivalence property: the batch path and the sequential path must produce the same output.

**Validates: Requirements 7.2, 7.4**

## Error Handling

### Batch Append Failures

When `append_range_entries_batch()` fails for a cache key (file I/O error, lock contention):
- `write_eviction_journal_entries()` logs a warning with the cache key and error
- Processing continues with remaining cache keys
- The eviction itself already completed (`.bin` files deleted, accumulator decremented) — the journal entries are for metadata cleanup only
- Orphan recovery handles any stale metadata entries from missed journal writes

### calculate_size_delta Removal

No error handling changes. The function is dead code — removing it has no runtime impact. The comment at line 2285 confirming it's not called will be simplified.

### Log Level Changes

No error handling changes. Debug-level logs are still emitted and visible when `RUST_LOG=debug` is set.

## Testing Strategy

### Approach

This feature is primarily static code changes. Testing focuses on:

1. **Compilation** — `cargo build --release` verifies all code removal and log level changes compile
2. **Existing test suite** — `cargo test --release` verifies no regressions from constant change or code removal
3. **Property test** — One new property test for batch append equivalence
4. **Manual verification** — Run proxy with `RUST_LOG=debug` to confirm demoted logs appear at debug level

### Property-Based Testing

Library: `quickcheck` (already used in the project)

Configuration: minimum 100 iterations per property test.

**Property 1 test**: Generate random lists of `JournalEntry` objects (varying operation types, sizes, cache keys). Write them via batch method and via sequential method to separate temp directories. Assert file contents are byte-identical.

Tag: **Feature: logging-and-consolidation-perf, Property 1: Batch append equivalence**

### Unit Tests

- Test `append_range_entries_batch()` with empty entries list (no-op)
- Test `append_range_entries_batch()` with single entry (equivalent to `append_range_entry()`)
- Test `write_eviction_journal_entries()` with entries spanning multiple cache keys (verify grouping)

### Regression Testing

- Run full test suite (`cargo test --release`) after removing `calculate_size_delta()` and its tests
- Verify the remaining property tests in `tests/journal_size_tracking_property_test.rs` still pass
- Verify the `KEY_CONCURRENCY_LIMIT = 8` change doesn't break any existing consolidation tests
