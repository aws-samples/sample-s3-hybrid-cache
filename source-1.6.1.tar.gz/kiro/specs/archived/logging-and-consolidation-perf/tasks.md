# Implementation Plan: Logging Reductions, Consolidation Performance & Documentation (v1.1.38)

## Overview

Changes grouped by dependency: logging reductions first (reduces noise during testing), then performance improvements, then dead code removal, then documentation audit, then version bump. Rust is the implementation language; property tests use `quickcheck`.

## Tasks

- [x] 1. Logging reductions — change INFO to debug!
  - [x] 1.1 Change "Range stored (hybrid)" from `info!` to `debug!` in `src/disk_cache.rs` (line 1170)
    - _Requirements: 1.1_
  - [x] 1.2 Change "SIZE_TRACK: Add COUNTED", "SIZE_TRACK: Add SKIPPED", and "SIZE_TRACK: Remove COUNTED" from `info!` to `debug!` in `src/journal_consolidator.rs` (lines 508-529). Keep the summary line at INFO (line 542).
    - _Requirements: 2.1, 2.2, 2.3_
  - [x] 1.3 Change "Object metadata journal consolidation completed" from `info!` to `debug!` in `src/journal_consolidator.rs` (line 2341)
    - _Requirements: 3.1_
  - [x] 1.4 Change "Removing journal entry for evicted range" and "Removing stale journal entry" from `info!` to `debug!` in `src/journal_consolidator.rs` (lines 2610, 2637)
    - _Requirements: 4.1, 4.2_
  - [x] 1.5 Change "Atomic size subtract", "Atomic size add", and "Atomic size add (non-blocking)" from `info!` to `debug!` in `src/journal_consolidator.rs` (lines 1478, 1662, 1790)
    - _Requirements: 5.1, 5.2, 5.3_

- [x] 2. Increase KEY_CONCURRENCY_LIMIT
  - [x] 2.1 Change `const KEY_CONCURRENCY_LIMIT: usize = 4` to `8` in `src/journal_consolidator.rs` (line 24)
    - _Requirements: 6.1_

- [x] 3. Batch eviction journal writes
  - [x] 3.1 Add `append_range_entries_batch()` method to `JournalManager` in `src/journal_manager.rs`
    - Accepts `cache_key: &str` and `entries: Vec<JournalEntry>`
    - Serializes all entries to JSON lines before acquiring locks
    - Acquires append mutex once, does single read-modify-write cycle
    - Same lock/fallback pattern as `append_range_entry()`
    - _Requirements: 7.2, 7.4_
  - [x] 3.2 Modify `write_eviction_journal_entries()` in `src/journal_consolidator.rs` to group entries by cache_key using a HashMap, then call `append_range_entries_batch()` per key
    - On batch failure for a key, log warning and continue with remaining keys
    - Remove stale comment at line 813 ("This is what calculate_size_delta uses")
    - _Requirements: 7.1, 7.3_
  - [x] 3.3 Write property test for batch append equivalence
    - **Property 1: Batch append equivalence**
    - **Validates: Requirements 7.2, 7.4**

- [x] 4. Checkpoint — verify all tests pass
  - Run `cargo test --release` and ensure all existing tests pass with the logging, concurrency, and batching changes.

- [x] 5. Remove calculate_size_delta and related dead code
  - [x] 5.1 Remove `calculate_size_delta()` function from `src/journal_consolidator.rs` (lines ~462-548)
    - _Requirements: 8.1_
  - [x] 5.2 Remove `ConsolidationResult::success_with_size_delta()` constructor (dead code — never called)
    - _Requirements: 8.1_
  - [x] 5.3 Remove `create_journal_entry_with_size()` helper and all 12 `test_calculate_size_delta_*` unit tests from `src/journal_consolidator.rs` (lines ~4308-4582)
    - _Requirements: 8.3_
  - [x] 5.4 Remove `prop_calculate_size_delta_correctness` property test and the `calculate_size_delta` import from `tests/journal_size_tracking_property_test.rs`
    - _Requirements: 8.4, 8.5_
  - [x] 5.5 Remove `pub use` of `calculate_size_delta` from `src/lib.rs` (if present). Clean up stale comments referencing `calculate_size_delta` at lines 2285 and 813.
    - _Requirements: 8.2, 8.6_

- [x] 6. Checkpoint — verify compilation and tests after dead code removal
  - Run `cargo build --release` and `cargo test --release`. Ensure remaining property tests in `tests/journal_size_tracking_property_test.rs` still pass.

- [x] 7. Documentation audit
  - [x] 7.1 Update `docs/CACHING.md` eviction triggers section (around line 3209) — change "processes journal entries and calculates size delta" to describe accumulator-based approach
    - _Requirements: 9.1_
  - [x] 7.2 Update `docs/ARCHITECTURE.md` module organization table to match actual `src/` contents (add missing modules: `cache_validator.rs`, `capacity_manager.rs`, `background_recovery.rs`, `orphaned_range_recovery.rs`, `log_sampler.rs`, `performance_logger.rs`, `presigned_url.rs`, `signed_put_handler.rs`, `signed_request_proxy.rs`, `https_connector.rs`, `dashboard.rs`, `streaming_tee.rs`, `write_cache_manager.rs`; remove any that no longer exist)
    - _Requirements: 9.2, 9.3_
  - [x] 7.3 Update `docs/CONFIGURATION.md` "Cache Size Tracking Configuration" section (around line 624) — change "calculates size deltas from journal entries" to describe accumulator-based tracking with per-instance delta files
    - _Requirements: 9.4_
  - [x] 7.4 Search all docs for remaining references to `calculate_size_delta()` as active code and update or remove them
    - _Requirements: 9.5_

- [x] 8. Version bump and changelog
  - [x] 8.1 Update `Cargo.toml` version to `1.1.38`
    - _Requirements: 10.1_
  - [x] 8.2 Add v1.1.38 entry to `CHANGELOG.md` describing: logging reductions (9 log sites demoted to debug), KEY_CONCURRENCY_LIMIT 4→8, batched eviction journal writes, calculate_size_delta removal, documentation updates
    - _Requirements: 10.2_
  - [x] 8.3 Commit: `git add -A && git commit -m "v1.1.38: Logging reductions, consolidation perf, dead code removal, doc updates"`

- [x] 9. Final checkpoint — ensure all tests pass
  - Run `cargo test --release`. Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Log level changes are verified by compilation (macro swap) and optionally by running with `RUST_LOG=debug`
- The batch append property test validates the only behavioral change in this feature
- Dead code removal in task 5 depends on task 1 completing first (the SIZE_TRACK log level changes in `calculate_size_delta` become moot once the function is removed, but doing logging changes first keeps the intermediate state compilable)
