# Requirements: Logging Reductions, Consolidation Performance & Documentation (v1.1.38)

## Introduction

Three categories of improvements for v1.1.38: reduce high-volume INFO logging that overwhelms production logs during active downloads and consolidation, improve consolidation performance through increased concurrency and batched eviction journal writes, and remove the legacy `calculate_size_delta()` function that is no longer called in the consolidation path. Additionally, audit documentation to ensure accuracy with the current accumulator-based size tracking implementation.

## Glossary

- **Consolidation_Cycle**: The periodic background task in `JournalConsolidator::run_consolidation_cycle()` that runs every 5 seconds, collects accumulator deltas, processes journal entries per cache key, and triggers eviction.
- **KEY_CONCURRENCY_LIMIT**: Constant in `journal_consolidator.rs` controlling how many cache keys are processed concurrently during a Consolidation_Cycle. Currently 4.
- **SizeAccumulator**: In-memory `AtomicI64` tracking cache size deltas at write/eviction time. The authoritative source of truth for cache size (0.04% accuracy vs filesystem).
- **calculate_size_delta**: Legacy function that computed size deltas from journal entries. No longer called in the consolidation path since the accumulator-based approach replaced it. Still exists in the codebase with per-entry SIZE_TRACK INFO logs.
- **write_eviction_journal_entries**: Function that writes Remove journal entries for evicted ranges. Currently writes one `append_range_entry()` call per evicted range.
- **JournalManager**: Component managing per-instance journal files, providing `append_range_entry()` for writing individual journal entries.

## Requirements

### Requirement 1: Reduce Per-Chunk Range Storage Logging

**User Story:** As a proxy operator, I want per-chunk range storage logs reduced to DEBUG level, so that downloading a 5 GB file does not produce ~640 INFO lines from 8 MiB chunk writes.

#### Acceptance Criteria

1. WHEN a range chunk is stored in hybrid mode, THE DiskCache SHALL log the "Range stored (hybrid)" message at DEBUG level instead of INFO level
   - _Location: `src/disk_cache.rs` line 1170_

### Requirement 2: Reduce Per-Entry SIZE_TRACK Logging in calculate_size_delta

**User Story:** As a proxy operator, I want per-entry SIZE_TRACK logs reduced to DEBUG level, so that consolidation cycles processing thousands of journal entries do not flood INFO logs.

#### Acceptance Criteria

1. WHEN `calculate_size_delta()` processes an Add entry, THE function SHALL log "SIZE_TRACK: Add COUNTED" and "SIZE_TRACK: Add SKIPPED" at DEBUG level instead of INFO level
2. WHEN `calculate_size_delta()` processes a Remove entry, THE function SHALL log "SIZE_TRACK: Remove COUNTED" at DEBUG level instead of INFO level
3. THE "SIZE_TRACK: calculate_size_delta summary" log line SHALL remain at INFO level
   - _Location: `src/journal_consolidator.rs` lines 508-542_

### Requirement 3: Reduce Per-Key Consolidation Completion Logging

**User Story:** As a proxy operator, I want per-key consolidation completion logs reduced to DEBUG level, so that consolidation cycles with many keys do not produce excessive INFO output.

#### Acceptance Criteria

1. WHEN `consolidate_object()` completes for a cache key, THE JournalConsolidator SHALL log "Object metadata journal consolidation completed" at DEBUG level instead of INFO level
   - _Location: `src/journal_consolidator.rs` line 2341_

### Requirement 4: Reduce Per-Entry Journal Cleanup Logging

**User Story:** As a proxy operator, I want per-entry journal cleanup logs reduced to DEBUG level, so that eviction cycles removing 1,400+ entries do not flood INFO logs.

#### Acceptance Criteria

1. WHEN a journal entry is removed for an evicted range, THE JournalConsolidator SHALL log "Removing journal entry for evicted range" at DEBUG level instead of INFO level
2. WHEN a stale journal entry is removed, THE JournalConsolidator SHALL log "Removing stale journal entry" at DEBUG level instead of INFO level
   - _Location: `src/journal_consolidator.rs` lines 2610, 2637_

### Requirement 5: Reduce Legacy Atomic Size Operation Logging

**User Story:** As a proxy operator, I want legacy direct-update size operation logs reduced to DEBUG level, so that atomic size add/subtract operations do not produce INFO noise.

#### Acceptance Criteria

1. THE `atomic_subtract_size()` function SHALL log "Atomic size subtract" at DEBUG level instead of INFO level
   - _Location: `src/journal_consolidator.rs` line 1478_
2. THE `atomic_add_size()` function SHALL log "Atomic size add" at DEBUG level instead of INFO level
   - _Location: `src/journal_consolidator.rs` line 1662_
3. THE `atomic_add_size_non_blocking()` function SHALL log "Atomic size add (non-blocking)" at DEBUG level instead of INFO level
   - _Location: `src/journal_consolidator.rs` line 1790_

### Requirement 6: Increase Key Concurrency Limit

**User Story:** As a proxy operator, I want consolidation to process more cache keys concurrently, so that consolidation cycles complete faster when many keys have few entries each.

#### Acceptance Criteria

1. THE `KEY_CONCURRENCY_LIMIT` constant SHALL be changed from 4 to 8
   - _Location: `src/journal_consolidator.rs` line 24_

### Requirement 7: Batch Eviction Journal Writes

**User Story:** As a proxy operator, I want eviction journal writes batched by cache key, so that writing 1,401 Remove entries does not require 1,401 separate `append_range_entry()` calls.

#### Acceptance Criteria

1. WHEN `write_eviction_journal_entries()` receives evicted ranges, THE function SHALL group entries by cache_key before writing
2. WHEN writing grouped entries, THE JournalManager SHALL provide a batch append method that writes all entries for a cache key in a single file operation
3. WHEN a batch write fails for a cache key, THE function SHALL log a warning and continue with remaining cache keys
4. THE batch approach SHALL produce journal entries identical in format to individual `append_range_entry()` calls (one JSON object per line)

### Requirement 8: Remove Legacy calculate_size_delta Function

**User Story:** As a proxy operator, I want the unused `calculate_size_delta()` function removed from the codebase, so that dead code and its per-entry SIZE_TRACK logging are eliminated.

#### Acceptance Criteria

1. THE `calculate_size_delta()` function SHALL be removed from `src/journal_consolidator.rs`
2. THE `pub` export of `calculate_size_delta` from `lib.rs` SHALL be removed (if present)
3. THE ~12 unit tests for `calculate_size_delta` (`test_calculate_size_delta_*` at lines 4343-4582) SHALL be removed from `src/journal_consolidator.rs`
4. THE property-based test `prop_calculate_size_delta_correctness` in `tests/journal_size_tracking_property_test.rs` SHALL be removed
5. THE `use` import of `calculate_size_delta` in `tests/journal_size_tracking_property_test.rs` SHALL be removed
6. WHEN `calculate_size_delta` is removed, THE remaining code SHALL compile without errors

### Requirement 9: Documentation Audit

**User Story:** As a proxy operator, I want documentation to accurately reflect the current accumulator-based size tracking implementation, so that docs do not describe the superseded journal-based approach.

#### Acceptance Criteria

1. THE `docs/CACHING.md` eviction triggers section SHALL describe accumulator-based size tracking instead of "processes journal entries and calculates size delta"
2. THE `docs/ARCHITECTURE.md` module organization table SHALL match the actual contents of `src/`
3. THE `docs/ARCHITECTURE.md` "Buffered Logging and Accumulator-Based Size Tracking" section SHALL accurately describe the current implementation
4. THE `docs/CONFIGURATION.md` "Cache Size Tracking Configuration" section SHALL describe the accumulator-based approach instead of "calculates size deltas from journal entries"
5. IF any documentation references `calculate_size_delta()` as active code, THE documentation SHALL be updated to remove those references

### Requirement 10: Version and Changelog

**User Story:** As a proxy operator, I want the version bumped and changelog updated for v1.1.38.

#### Acceptance Criteria

1. THE `Cargo.toml` version SHALL be updated to `1.1.38`
2. THE `CHANGELOG.md` SHALL contain a v1.1.38 entry describing the logging reductions, performance improvements, dead code removal, and documentation updates
