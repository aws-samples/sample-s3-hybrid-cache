# Tasks: Eviction Over-Eviction Fix

## Task 1: Implement `flush_and_apply_accumulator` on `JournalConsolidator`

- [x] 1.1 Add `flush_and_apply_accumulator` method to `JournalConsolidator` in `src/journal_consolidator.rs`
  - Atomically swap `size_accumulator.delta` and `size_accumulator.write_cache_delta` to 0
  - If both captured values are 0, return `Ok(())` immediately (no disk I/O)
  - Call `self.atomic_update_size_delta(delta, wc_delta)` to apply directly to `size_state.json`
  - On success: return `Ok(())` — no delta file written, accumulator stays at 0
  - On failure: restore both values via `fetch_add` on the atomics, log warning, return error
  - Add doc comment explaining why this lives on `JournalConsolidator` (borrow conflict avoidance)
- [x] 1.2 Add `size_accumulator()` public accessor if not already present (needed for tests)

## Task 2: Update `enforce_disk_cache_limits_internal` to use `flush_and_apply_accumulator`

- [x] 2.1 In `src/cache.rs`, replace `consolidator.size_accumulator().flush()` with `consolidator.flush_and_apply_accumulator()` in `enforce_disk_cache_limits_internal`
  - This is the post-eviction flush at ~line 4273
  - The call already has `consolidator` from `self.journal_consolidator.read().await.as_ref()`
  - Update the log message and error message to reference `flush_and_apply_accumulator`

## Task 3: Update `evict_if_needed` for consistency with consolidation-path eviction

- [x] 3.1 Replace hardcoded `0.95` trigger threshold with configurable `self.eviction_trigger_percent`
  - Change `(max_size as f64 * 0.95) as u64` to `(max_size as f64 * (self.eviction_trigger_percent as f64 / 100.0)) as u64`
  - Update the debug log message to show the configured percentage
- [x] 3.2 After acquiring the eviction lock, re-read `size_state.json` via `get_current_size()` and skip eviction if size is at or below `max_size`
  - Follow the same pattern as `enforce_disk_cache_limits_internal` (lines 4220-4248)
  - Record lock hold time and release lock before returning if skipping
- [x] 3.3 After eviction completes, call `consolidator.flush_and_apply_accumulator()` before releasing the eviction lock
  - Add the same `if let Some(consolidator)` pattern used in `enforce_disk_cache_limits_internal`
  - Log warning on failure but do not propagate error (match error handling in design)

## Task 4: Property-based tests for `flush_and_apply_accumulator`

- [x] 4.1 (PBT) Property 2: `flush_and_apply_accumulator` atomically transfers delta to `size_state.json`
  - Generate random `(delta, wc_delta)` pairs via quickcheck
  - Create a `JournalConsolidator` backed by a temp directory with initial `size_state.json`
  - Set deltas on the accumulator, call `flush_and_apply_accumulator`
  - Assert: accumulator deltas are 0, `size_state.json` total_size changed by delta, write_cache_size changed by wc_delta, no delta files in `size_tracking/`
  - Tag: `Feature: eviction-over-eviction-fix, Property 2`
  - **Validates: Requirements 2.3, 3.2**
- [x] 4.2 (PBT) Property 3: No double-subtraction across eviction and consolidation
  - Generate random deltas, call `flush_and_apply_accumulator`, then run `collect_and_apply_deltas`
  - Assert: `collect_and_apply_deltas` returns `(0, 0)` — no delta files to process
  - Tag: `Feature: eviction-over-eviction-fix, Property 3`
  - **Validates: Requirements 3.1, 3.3**
- [x] 4.3 (PBT) Property 5: Error recovery restores accumulator values
  - Generate random deltas, call `flush_and_apply_accumulator` with a consolidator whose `size_state.json` path is unwritable (read-only dir)
  - Assert: accumulator values are restored to pre-call values
  - Tag: `Feature: eviction-over-eviction-fix, Property 5`
  - **Validates: Requirements 2.4, 5.1, 5.2**
- [x] 4.4 (PBT) Property 6: Configurable trigger percent
  - Generate random `(eviction_trigger_percent, max_cache_size, current_size)` tuples
  - Verify the trigger threshold calculation matches `max_size * percent / 100`
  - Tag: `Feature: eviction-over-eviction-fix, Property 6`
  - **Validates: Requirements 1.4**

## Task 5: Unit tests for eviction path changes

- [x] 5.1 Unit test: `flush_and_apply_accumulator` with both deltas at zero returns immediately without disk I/O
- [x] 5.2 Unit test: `flush_and_apply_accumulator` with only `write_cache_delta` non-zero applies correctly
- [x] 5.3 Unit test: Concurrent `flush()` and `flush_and_apply_accumulator` — verify no delta is lost
  - Spawn two tasks: one calling `flush()`, one calling `flush_and_apply_accumulator()`
  - Verify the sum of applied deltas equals the original accumulator value

## Task 6: Update documentation

- [x] 6.1 Update `docs/CACHING.md` "Distributed Eviction Coordination" → "Eviction Triggers" subsection
  - Current text says consolidator collects delta files and sums them into `size_state.json`
  - Add that both eviction paths now update `size_state.json` directly under the eviction lock via `flush_and_apply_accumulator`, so the next lock holder reads accurate post-eviction size
  - Update the "How It Works" flow diagram to show `size_state.json` is updated before lock release
- [x] 6.2 Update `docs/CACHING.md` "Distributed Eviction Coordination" → "Behavior in Multi-Instance Scenarios"
  - Current text implies size is only visible after the next consolidation cycle ("5 seconds later")
  - Update to reflect that post-eviction size is visible immediately via `size_state.json`

## Task 7: Version bump and CHANGELOG

- [x] 7.1 Bump version in `Cargo.toml` from `1.1.40` to `1.1.41`
- [x] 7.2 Add `[1.1.41]` entry to `CHANGELOG.md` with:
  - Fix: Over-eviction race condition where sequential evictions read stale `size_state.json`, causing cache to drop to ~37% instead of target 80%. Both eviction paths now update `size_state.json` directly under the eviction lock. Write-path eviction (`evict_if_needed`) now re-reads size after lock acquisition and uses configurable trigger threshold.
- [x] 7.3 Commit version bump: `git add Cargo.toml CHANGELOG.md && git commit -m "v1.1.40: Fix over-eviction race condition"`

## Task 8: Build verification

- [x] 8.1 Run `cargo build` to verify no compilation errors
- [x] 8.2 Run `cargo test` to verify all existing tests still pass alongside new tests
