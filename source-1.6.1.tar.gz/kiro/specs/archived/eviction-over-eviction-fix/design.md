# Design Document: Eviction Over-Eviction Fix

## Overview

This fix addresses a race condition where sequential eviction runs read stale `size_state.json`, causing the cache to drop to ~37% instead of the target 80%. The core change introduces a `flush_and_apply_accumulator` method on `JournalConsolidator` that atomically swaps the in-memory delta and applies it directly to `size_state.json` (bypassing delta files), and updates both eviction paths to use it under the eviction lock.

The fix has two parts:
1. Make `evict_if_needed` (Path 2) consistent with `enforce_disk_cache_limits_internal` (Path 1): re-read size after lock, use configurable threshold.
2. In both paths, call `flush_and_apply_accumulator` instead of `flush()` after eviction, so `size_state.json` is updated before the eviction lock is released.

## Architecture

### Current Flow (Buggy)

```mermaid
sequenceDiagram
    participant A as Instance A (eviction)
    participant Lock as global_eviction.lock
    participant SS as size_state.json
    participant DF as Delta Files
    participant C as Consolidation Cycle

    A->>SS: read size (1.42 GiB)
    A->>Lock: acquire flock
    A->>A: evict 230 MiB
    A->>DF: flush accumulator (delta file: -230 MiB)
    A->>Lock: release flock
    Note over SS: Still shows 1.42 GiB!

    participant B as Instance B (eviction)
    B->>SS: read size (1.42 GiB — stale!)
    B->>Lock: acquire flock
    B->>B: evict 230 MiB (unnecessary)
    B->>Lock: release flock

    C->>DF: collect_and_apply_deltas (reads & deletes delta files)
    C->>SS: atomic_update_size_delta (finally updates)
```

### Fixed Flow

```mermaid
sequenceDiagram
    participant A as Instance A (eviction)
    participant Lock as global_eviction.lock
    participant SS as size_state.json
    participant C as Consolidation Cycle

    A->>SS: read size (1.42 GiB)
    A->>Lock: acquire flock
    A->>SS: re-read size (1.42 GiB, confirmed)
    A->>A: evict 230 MiB
    A->>SS: flush_and_apply_accumulator (swap accum → apply -230 MiB directly)
    Note over SS: Now shows 1.19 GiB
    A->>Lock: release flock

    participant B as Instance B (eviction)
    B->>SS: read size (1.19 GiB)
    B->>Lock: acquire flock
    B->>SS: re-read size (1.19 GiB — accurate!)
    Note over B: 1.19 GiB < trigger threshold, skip eviction
    B->>Lock: release flock
```

## Components and Interfaces

### Modified Components

#### 1. `JournalConsolidator` (src/journal_consolidator.rs)

New method on `JournalConsolidator` (not `SizeAccumulator`):

```rust
/// Atomically swap the SizeAccumulator's deltas to zero and apply them directly
/// to size_state.json. Bypasses delta files entirely — no file written, no
/// double-subtraction risk. On failure, restores the swapped values.
///
/// This method lives on JournalConsolidator (not SizeAccumulator) because it
/// needs access to both the accumulator and atomic_update_size_delta(). Placing
/// it on SizeAccumulator would require passing &JournalConsolidator, creating
/// an awkward borrow when called as consolidator.size_accumulator().flush_and_apply(consolidator).
pub async fn flush_and_apply_accumulator(&self) -> Result<()>
```

Behavior:
- Atomically swap `size_accumulator.delta` and `size_accumulator.write_cache_delta` to 0 (same as `SizeAccumulator::flush()`)
- If both are 0, return `Ok(())` immediately
- Call `self.atomic_update_size_delta(delta, wc_delta)`
- On success: done (no delta file written, accumulator is 0)
- On failure: restore both values via `fetch_add`, log warning, return error

This method reuses the existing `atomic_update_size_delta` which already acquires `size_state.lock` for safe read-modify-write of `size_state.json`.

The method is on `JournalConsolidator` to avoid borrow conflicts: the call site in `cache.rs` already has `consolidator` from `self.journal_consolidator.read().await.as_ref()`, so calling `consolidator.flush_and_apply_accumulator()` is clean.

#### 2. `CacheManager::evict_if_needed` (src/cache.rs)

Changes:
- After acquiring eviction lock, re-read `get_current_size()` and skip if under `max_size`
- Replace hardcoded `0.95` with `self.eviction_trigger_percent as f64 / 100.0`
- After eviction, call `flush_and_apply_accumulator` on the consolidator instead of nothing
- Structure the lock-hold section to match `enforce_disk_cache_limits_internal`

#### 3. `CacheManager::enforce_disk_cache_limits_internal` (src/cache.rs)

Changes:
- Replace `consolidator.size_accumulator().flush()` with `consolidator.flush_and_apply_accumulator()`
- This ensures `size_state.json` is updated before releasing the eviction lock (currently it only flushes to a delta file)

### Unchanged Components

- `collect_and_apply_deltas()` — no changes. It reads and deletes delta files. Since `flush_and_apply_accumulator` writes no delta files, there's nothing for it to double-count.
- `atomic_update_size_delta()` — no changes. Called by `flush_and_apply_accumulator` as-is.
- `run_consolidation_cycle()` — no changes. Its flush at cycle start still uses `flush()` (appropriate for the consolidation path where deltas are collected immediately after).
- `perform_eviction_with_lock()` — no changes. The accumulator subtract calls remain the same.

## Data Models

No new data structures. The existing `SizeState`, `SizeAccumulator`, and delta file format are unchanged.

The key data flow change:

| Path | Before | After |
|------|--------|-------|
| Eviction delta | Accumulator → delta file → (wait for consolidation) → size_state.json | Accumulator → size_state.json directly |
| Normal write delta | Accumulator → delta file → consolidation → size_state.json | Unchanged |


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Post-lock re-read determines eviction decision

*For any* eviction attempt via `evict_if_needed`, and any cache size value present in `size_state.json` at the time the eviction lock is acquired, the eviction decision (proceed or skip) uses the post-lock size value, not the pre-lock value. If the post-lock size is at or below `max_size`, eviction is skipped.

**Validates: Requirements 1.1, 1.2**

### Property 2: flush_and_apply_accumulator atomically transfers delta to size_state.json

*For any* non-zero delta values `(d, wc_d)` in the SizeAccumulator, calling `flush_and_apply_accumulator` results in: (a) the in-memory accumulator deltas are zero, (b) `size_state.json` total_size changed by `d` and write_cache_size changed by `wc_d`, and (c) no delta file was written to the `size_tracking/` directory.

**Validates: Requirements 2.3, 3.2**

### Property 3: No double-subtraction across eviction and consolidation

*For any* eviction that frees `N` bytes, followed by a consolidation cycle, the net change to `size_state.json` total_size from the eviction is exactly `-N` (not `-2N`). Equivalently: `flush_and_apply_accumulator` produces no delta file, so `collect_and_apply_deltas` in the subsequent consolidation cycle finds no eviction-related delta to process.

**Validates: Requirements 3.1, 3.3**

### Property 4: size_state.json reflects post-eviction size before lock release

*For any* eviction (via either `evict_if_needed` or `enforce_disk_cache_limits_internal`) that frees `N` bytes from a cache of size `S`, after the eviction method returns, `size_state.json` total_size is approximately `S - N` (within tolerance of concurrent writes by other operations).

**Validates: Requirements 2.1, 4.1**

### Property 5: Error recovery restores accumulator values

*For any* `flush_and_apply_accumulator` call where `atomic_update_size_delta` fails, the SizeAccumulator's in-memory delta values are restored to their pre-call values. A subsequent successful `flush_and_apply_accumulator` call applies the full accumulated delta.

**Validates: Requirements 2.4, 5.1, 5.2**

### Property 6: Configurable trigger percent

*For any* `eviction_trigger_percent` value `P` and `max_cache_size` value `M`, `evict_if_needed` triggers eviction when `current_size + required_space > M * P / 100`, not when `current_size + required_space > M * 0.95`.

**Validates: Requirements 1.4**

## Error Handling

| Scenario | Behavior |
|----------|----------|
| `flush_and_apply_accumulator` fails (disk I/O error on `size_state.json`) | Restore accumulator values via `fetch_add`. Log warning. Eviction result still returned to caller. Delta will be applied on next `flush_and_apply_accumulator` or `flush` + consolidation cycle. |
| `get_current_size()` fails after lock acquisition | Fall back to pre-lock size value (same as current `enforce_disk_cache_limits_internal` behavior). |
| Eviction lock acquisition fails in `evict_if_needed` | Return error (existing behavior, unchanged). |
| `flush_and_apply_accumulator` called with zero deltas | Return `Ok(())` immediately, no disk I/O. |

The error handling preserves the existing invariant: size tracking errors are logged but do not block eviction completion or lock release. The accumulator's restore-on-failure pattern (already used by `flush()`) ensures no delta is silently lost.

## Testing Strategy

### Property-Based Testing

Use the `quickcheck` crate (already a dev-dependency in the project) for property-based tests. Each property test runs a minimum of 100 iterations.

Property tests focus on `JournalConsolidator::flush_and_apply_accumulator` since it's the new core method and can be tested in isolation with a real `JournalConsolidator` instance backed by a temp directory.

- **Property 2** (flush_and_apply_accumulator atomicity): Generate random `(delta, wc_delta)` pairs, set them on a SizeAccumulator, call `flush_and_apply_accumulator`, verify accumulator is zero, `size_state.json` reflects the delta, and no delta files exist.
- **Property 3** (no double-subtraction): Generate random deltas, call `flush_and_apply_accumulator`, then run `collect_and_apply_deltas`, verify the second call returns `(0, 0)`.
- **Property 5** (error recovery): Generate random deltas, call `flush_and_apply_accumulator` with a consolidator whose `size_state.json` path is unwritable, verify accumulator values are restored.
- **Property 6** (configurable trigger percent): Generate random `(eviction_trigger_percent, max_cache_size, current_size)` tuples, verify the trigger threshold calculation matches `max_size * percent / 100`.

### Unit Tests

Unit tests cover specific examples and edge cases:

- **Property 1** (post-lock re-read): Test that `evict_if_needed` skips eviction when `size_state.json` is updated between the initial read and the post-lock read. (Requires setting up size_state.json with a value under the threshold before the post-lock read.)
- **Property 4** (size_state.json updated after eviction): Integration-style test that runs eviction end-to-end and verifies `size_state.json` reflects the freed bytes.
- **Edge case**: `flush_and_apply_accumulator` with both deltas at zero returns immediately.
- **Edge case**: `flush_and_apply_accumulator` with only `write_cache_delta` non-zero.
- **Edge case**: Concurrent `flush()` (from consolidation cycle start) and `flush_and_apply_accumulator` (from eviction) — verify no delta is lost.

### Test Configuration

- Property-based tests: `quickcheck` with `#[quickcheck]` attribute, minimum 100 iterations (default is 100)
- Each property test tagged with: `Feature: eviction-over-eviction-fix, Property N: <property_text>`
- Tests located in `src/journal_consolidator.rs` (for `flush_and_apply_accumulator` unit/property tests) and `src/cache.rs` (for eviction path integration tests)
