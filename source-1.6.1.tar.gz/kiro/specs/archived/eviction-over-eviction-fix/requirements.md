# Requirements Document

## Introduction

Fix over-eviction in the disk cache eviction system. When the cache fills during download bursts, multiple sequential eviction runs read stale `size_state.json` data, causing the cache to drop to ~37% instead of the target 80%. The root cause is that `size_state.json` is not updated until the next consolidation cycle (every ~5s), so sequential evictions each believe the cache is still full and evict redundantly.

Two issues compound the problem:
1. The write-path eviction (`evict_if_needed`) does not re-read size after acquiring the eviction lock, does not flush the accumulator after eviction, and hardcodes the 0.95 trigger threshold.
2. Neither eviction path updates `size_state.json` before releasing the eviction lock, so the next lock holder reads stale data.

## Glossary

- **SizeAccumulator**: In-memory `AtomicI64` per instance that tracks net size changes (adds on range write, subtracts on eviction). Flushed to delta files on disk.
- **Delta_File**: JSON file written by `SizeAccumulator::flush()` to `size_tracking/delta_{instance}_{seq}.json`. Contains the net size change since last flush.
- **size_state.json**: On-disk file containing the authoritative total cache size. Updated by `atomic_update_size_delta()` during consolidation cycles.
- **Consolidation_Cycle**: Periodic process (~5s) that collects delta files, applies them to `size_state.json`, consolidates journal entries, and triggers eviction if needed.
- **Eviction_Lock**: File-based lock (`global_eviction.lock`) using `flock` that serializes eviction across instances. Prevents concurrent eviction but not sequential evictions reading stale data.
- **size_state.lock**: File-based lock serializing read-modify-write access to `size_state.json`, used by `atomic_update_size_delta()`.
- **Consolidation_Lock**: File-based lock (`global_consolidation.lock`) serializing consolidation cycles across instances.
- **evict_if_needed**: Write-path eviction method (Path 2) called from `http_proxy.rs` and `range_handler.rs` after caching a response.
- **enforce_disk_cache_limits_internal**: Consolidation-path eviction method (Path 1) called from the consolidation loop.
- **flush_and_apply_accumulator**: New method on `JournalConsolidator` to atomically swap the accumulator delta and apply it directly to `size_state.json`, bypassing delta files to avoid double-subtraction.
- **Eviction_Trigger_Percent**: Configurable threshold (default 95%) at which eviction is triggered.
- **Eviction_Target_Percent**: Configurable target (default 80%) to which eviction reduces cache size.

## Requirements

### Requirement 1: Write-path eviction consistency with consolidation-path eviction

**User Story:** As a system operator, I want the write-path eviction (`evict_if_needed`) to behave consistently with the consolidation-path eviction (`enforce_disk_cache_limits_internal`), so that both paths have the same safeguards against stale data.

#### Acceptance Criteria

1. WHEN `evict_if_needed` acquires the Eviction_Lock, THE Eviction_System SHALL re-read `size_state.json` via `get_current_size()` before proceeding with eviction.
2. WHEN `evict_if_needed` re-reads the cache size after acquiring the Eviction_Lock and the size is at or below `max_size`, THE Eviction_System SHALL release the Eviction_Lock and skip eviction.
3. WHEN `evict_if_needed` completes eviction, THE Eviction_System SHALL flush the SizeAccumulator before releasing the Eviction_Lock.
4. WHEN `evict_if_needed` evaluates the eviction trigger threshold, THE Eviction_System SHALL use the configurable `eviction_trigger_percent` instead of a hardcoded 0.95 value.

### Requirement 2: Post-eviction size_state.json update under lock

**User Story:** As a system operator, I want `size_state.json` to reflect the post-eviction cache size before the eviction lock is released, so that the next eviction lock holder reads accurate size data and does not over-evict.

#### Acceptance Criteria

1. WHEN eviction completes and the SizeAccumulator has been flushed, THE Eviction_System SHALL update `size_state.json` with the eviction delta before releasing the Eviction_Lock.
2. WHEN the Eviction_System updates `size_state.json` after eviction, THE Eviction_System SHALL use a method that bypasses delta files to prevent double-subtraction by the next Consolidation_Cycle.
3. WHEN `flush_and_apply_accumulator` is called, THE JournalConsolidator SHALL atomically swap both SizeAccumulator delta and write_cache_delta to zero and apply the captured values directly to `size_state.json` via `atomic_update_size_delta()`.
4. IF `atomic_update_size_delta()` fails during `flush_and_apply_accumulator`, THEN THE JournalConsolidator SHALL restore the swapped delta values to the in-memory accumulators so the delta is not lost.
5. WHEN `flush_and_apply_accumulator` captures zero for both deltas, THE JournalConsolidator SHALL return immediately without calling `atomic_update_size_delta()`.

### Requirement 3: No double-subtraction of eviction deltas

**User Story:** As a system operator, I want the eviction size delta to be applied exactly once to `size_state.json`, so that the cache size tracking remains accurate.

#### Acceptance Criteria

1. WHEN `flush_and_apply_accumulator` applies the eviction delta directly to `size_state.json`, THE Eviction_System SHALL NOT write a delta file for the same delta, preventing the Consolidation_Cycle from applying the delta a second time.
2. WHEN `flush_and_apply_accumulator` succeeds, THE SizeAccumulator SHALL have both in-memory deltas at zero and no corresponding delta file on disk.
3. WHEN a Consolidation_Cycle runs after `flush_and_apply_accumulator` has completed, THE Consolidation_Cycle SHALL NOT find or process any delta related to the eviction that was already applied by `flush_and_apply_accumulator`.

### Requirement 4: Consolidation-path eviction uses flush_and_apply

**User Story:** As a system operator, I want the consolidation-path eviction (`enforce_disk_cache_limits_internal`) to also use `flush_and_apply` instead of the current `flush()` call, so that both eviction paths update `size_state.json` before releasing the lock.

#### Acceptance Criteria

1. WHEN `enforce_disk_cache_limits_internal` completes eviction, THE Eviction_System SHALL call `flush_and_apply_accumulator` instead of `SizeAccumulator::flush()` to update `size_state.json` before releasing the Eviction_Lock.
2. WHEN `enforce_disk_cache_limits_internal` calls `flush_and_apply_accumulator`, THE Eviction_System SHALL call it on the JournalConsolidator instance.

### Requirement 5: Error resilience

**User Story:** As a system operator, I want the eviction system to handle errors in the new `flush_and_apply` path gracefully, so that a failure does not cause size tracking drift.

#### Acceptance Criteria

1. IF `flush_and_apply_accumulator` fails to update `size_state.json`, THEN THE JournalConsolidator SHALL restore the delta values to the in-memory accumulators and log a warning.
2. WHEN the restored delta values are present in the SizeAccumulator, THE next `flush()` or `flush_and_apply_accumulator` call SHALL include the restored values, ensuring the delta is eventually applied.
3. IF `flush_and_apply_accumulator` fails, THEN THE Eviction_System SHALL continue with lock release and return the eviction result without propagating the error to the caller.
