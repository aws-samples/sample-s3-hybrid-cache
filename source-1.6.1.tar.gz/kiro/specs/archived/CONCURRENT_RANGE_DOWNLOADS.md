# Concurrent Range Downloads

## Problem

When multiple requests hit the proxy for the same uncached S3 object or range,
each request independently fetches from S3 and writes to cache. This wastes S3
bandwidth, increases DTO costs, and creates duplicate journal entries that
contribute to size tracking drift.

Two distinct scopes:
1. **Intra-instance**: Multiple requests on the same proxy instance
2. **Cross-instance**: Multiple proxy instances fetching the same range

## Current Behavior

### Intra-Instance

No request coalescing for regular GET or range requests. N concurrent cache misses
for the same object produce N parallel S3 fetches, N TeeStream pipelines, and N
cache writes. The last atomic rename wins; no data corruption, but wasted work.



### Cross-Instance

Each instance operates independently. No mechanism to detect that another instance
is currently downloading the same range. Both downloads complete; the second
atomic rename overwrites the first on NFS.

## Proposed Solution: Two-Layer Coordination

### Layer 1: Per-Instance Request Coalescing (Priority)

Generalize the `ActivePartFetch` pattern to all cache-miss fetches using
`tokio::sync::broadcast`.

```rust
struct InFlightTracker {
    // Key: "{cache_key}:{start}-{end}" for range requests, "{cache_key}" for full objects
    pending: DashMap<String, broadcast::Sender<Result<(), String>>>,
}
```

#### Algorithm

```
fn handle_cache_miss(cache_key, range):
    flight_key = format!("{}:{}-{}", cache_key, range.start, range.end)

    // Try to register as the fetcher
    match in_flight.entry(flight_key):
        Vacant(entry):
            // First request — register and proceed to S3
            let (tx, _) = broadcast::channel(1)
            entry.insert(tx.clone())
            result = fetch_from_s3_and_cache(cache_key, range)
            tx.send(result)  // notify all waiters
            in_flight.remove(flight_key)
            return result

        Occupied(entry):
            // Another request is already fetching — subscribe and wait
            let mut rx = entry.get().subscribe()
            match timeout(WAIT_TIMEOUT, rx.recv()):
                Ok(Ok(())) => serve_from_cache(cache_key, range)
                Ok(Err(_)) | Err(Elapsed) =>
                    // Fetcher failed or timed out — fall back to own S3 fetch
                    fetch_from_s3_and_cache(cache_key, range)
```

#### Key Design Decisions

**Wait-then-serve vs stream-sharing**: Waiters wait for caching to complete, then
serve from disk cache. This is simpler than sharing the in-flight stream via
broadcast channels (which would require chunk-level fan-out, backpressure handling,
and partial-failure recovery). The latency cost for waiters is acceptable — they
wait for the full range to be cached, but avoid an S3 round-trip entirely.

**Timeout**: Waiters use a configurable timeout (default: 30s). If the fetcher
takes longer (large file, slow S3), waiters fall back to their own S3 fetch.
This prevents indefinite blocking if the fetcher crashes or hangs.

**Range granularity**: Track at the exact range level. Two requests for different
ranges of the same object proceed independently. A full-object GET and a range
GET for the same object also proceed independently (they produce different cache
entries).

**Cleanup on fetcher failure**: If the fetcher errors, it broadcasts the error.
Waiters receive the error and fall back to their own S3 fetch. The `DashMap` entry
is removed regardless of success/failure.

#### Replaces ActivePartFetch

The current `ActivePartFetch` mechanism (503 + sleep + retry) can be replaced by
this generalized approach. Instead of returning 503 to the client and forcing a
retry, waiters subscribe to the broadcast channel and get notified when the fetch
completes. This is better for clients (no retry loop) and more efficient (no
wasted round-trips).

### Layer 2: Cross-Instance Coordination (Optional, Phase 2)

Use lock files on shared storage to coordinate across instances.

#### Lock File Design

```
cache_dir/locks/downloads/{sanitized_cache_key}_{start}-{end}.lock
```

Lock file contents (JSON):
```json
{
  "instance_id": "proxy-1",
  "started_at": "2026-01-30T10:00:00Z",
  "range_start": 0,
  "range_end": 8388607,
  "pid": 12345
}
```

#### Algorithm

```
fn handle_cache_miss_with_cross_instance(cache_key, start, end):
    lock_path = get_download_lock_path(cache_key, start, end)

    if try_acquire_lock(lock_path):
        # We're the downloader
        try:
            write_lock_metadata(lock_path, instance_id, now())
            result = download_from_s3_and_cache(cache_key, start, end)
            return result
        finally:
            release_lock(lock_path)
            remove_lock_file(lock_path)
    else:
        # Another instance is downloading — poll for completion
        return wait_for_download_or_fallback(cache_key, start, end, lock_path)

fn wait_for_download_or_fallback(cache_key, start, end, lock_path):
    deadline = now() + DOWNLOAD_WAIT_TIMEOUT
    poll_interval = 500ms

    while now() < deadline:
        if range_exists_in_cache(cache_key, start, end):
            return serve_from_cache(cache_key, start, end)

        if is_lock_stale(lock_path, STALE_THRESHOLD):
            if try_acquire_lock(lock_path):
                return download_from_s3_and_cache(cache_key, start, end)

        sleep(poll_interval)

    # Timeout: fall back to independent download
    return download_from_s3_and_cache(cache_key, start, end)
```

#### Edge Cases

**Downloader crashes**: Lock file remains with stale timestamp. Waiting instances
detect staleness after `stale_lock_secs` and take over. Partial temp file from
crashed instance is cleaned up by existing temp file cleanup.

**NFS lock reliability**: Use `flock()` for advisory locking. Lock metadata
provides backup staleness detection if flock fails. Non-blocking `try_lock_exclusive()`
prevents deadlocks.

**Very large downloads**: `wait_timeout_secs` may need to be longer for multi-GB
files. Could make timeout proportional to expected download time based on
Content-Length.

**Thundering herd on completion**: Many instances waiting for same range. When
download completes, all poll and find the cached range simultaneously. Cache
lookup is read-only, so this is safe (just extra I/O). Jitter on poll intervals
spreads load.

## Configuration

```yaml
cache:
  download_coordination:
    enabled: true                # Enable per-instance coalescing (Layer 1)
    wait_timeout_secs: 30        # Max time waiters block before falling back to S3
    cross_instance_enabled: false # Enable cross-instance lock coordination (Layer 2)
    stale_lock_secs: 60          # Consider cross-instance lock stale after this
    poll_interval_ms: 500        # Cross-instance poll interval
```

## Impact on Size Tracking

Per-instance coalescing directly reduces duplicate journal entries. If only one
request per instance fetches and caches a given range, there's one journal entry
per instance instead of potentially dozens. This doesn't eliminate cross-instance
duplicates but significantly reduces drift magnitude.

Cross-instance coordination (Layer 2) further reduces duplicates to at most one
journal entry total per range.

## Implementation Phases

### Phase 1: Per-Instance Request Coalescing

- Add `InFlightTracker` using `DashMap<String, broadcast::Sender<...>>`
- Integrate into cache-miss path in `http_proxy.rs`
- Replace `ActivePartFetch` with generalized mechanism
- Add metrics: coalesce_waits, coalesce_hits, coalesce_timeouts
- Default: enabled

Files to modify:
1. New: `src/inflight_tracker.rs` — `InFlightTracker` struct and logic
2. `src/http_proxy.rs` — Check tracker before S3 fetch, notify on completion
3. `src/cache.rs` — Remove `ActivePartFetch`, `active_part_fetches` field
4. `src/config.rs` — Add `download_coordination` config section
5. `src/metrics.rs` — Add coalescing metrics
6. `Cargo.toml` — Add `dashmap` dependency (if not already present)

### Phase 2: Cross-Instance Coordination

- Add NFS lock-based coordination for cross-instance dedup
- Poll-and-wait loop with stale lock detection
- Default: disabled (opt-in)

Additional files:
1. New: `src/download_coordinator.rs` — Lock management and wait logic
2. `src/disk_cache.rs` — Lock file path helpers

### Phase 3: Metrics and Observability

- `download_coalesce_waits_total` — requests that waited for an in-flight fetch
- `download_coalesce_cache_hits_total` — requests served from cache after waiting
- `download_coalesce_timeouts_total` — requests that timed out and fetched independently
- `download_coalesce_stale_takeovers_total` — stale cross-instance locks taken over
- `download_coalesce_wait_duration_seconds` — histogram of wait times
- `download_coalesce_s3_fetches_saved_total` — S3 fetches avoided by coalescing

## Trade-offs

| Aspect | Current | Layer 1 (per-instance) | Layer 1 + 2 (cross-instance) |
|--------|---------|------------------------|------------------------------|
| S3 bandwidth | N×M fetches (N instances, M concurrent) | N fetches (1 per instance) | 1 fetch total |
| Latency (waiters) | Immediate S3 request | Wait up to timeout, then cache | Wait up to timeout, then cache |
| Complexity | Simple | Moderate (broadcast channels) | High (NFS locks + polling) |
| Failure modes | None | Fetcher crash → waiters fall back | Stale locks, NFS issues |
| NFS dependency | Minimal | None (in-memory only) | Lock files on shared storage |
| Size tracking impact | Many duplicate journal entries | Reduced duplicates | Minimal duplicates |

## Recommendation

Implement Phase 1 first. Per-instance coalescing eliminates the most common case
(multiple concurrent clients hitting the same instance) with no NFS dependency and
moderate complexity. For a 3-instance deployment handling 20 concurrent requests
for the same object, this reduces S3 fetches from 60 to 3.

Phase 2 (cross-instance) reduces those 3 fetches to 1, but adds NFS lock
management complexity. Worth implementing only if S3 bandwidth savings justify
the added failure modes. At 2-4 instances, the marginal benefit is small.

## Related Analysis

See `docs/CONSENSUS_AND_SIZE_TRACKING_ANALYSIS.md` for evaluation of etcd, Raft,
and Redis as alternatives to NFS-based coordination. Conclusion: external
coordination services are not justified at current deployment scale (2-4 instances).
