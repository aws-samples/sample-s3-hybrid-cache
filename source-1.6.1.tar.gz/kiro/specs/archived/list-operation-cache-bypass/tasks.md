# Implementation Plan

- [x] 1. Implement query parameter detection function
  - Create `should_bypass_cache()` function in `http_proxy.rs` that examines request path and query parameters
  - Return tuple of (should_bypass: bool, operation_type: Option<String>, reason: Option<String>)
  - Detect root path "/" for ListBuckets operation (applies to both GET and HEAD)
  - Detect LIST operation parameters: list-type, delimiter, versions, uploads
  - Detect metadata operation parameters: acl, attributes, legal-hold, object-lock, retention, tagging, torrent
  - Detect partNumber parameter for GetObjectPart operation
  - Return false for GetObject requests (no non-cacheable parameters)
  - Note: Function is used for GET requests; HEAD requests have separate logic (only root path bypasses)
  - _Requirements: 1.1, 1.2, 2.1, 3.1, 4.1, 5.1, 6.1-6.7, 7.1-7.5_

- [ ]* 1.1 Write property test for detection function
  - **Property 1: LIST query parameters trigger bypass**
  - **Validates: Requirements 1.1, 1.2, 2.1, 3.1**

- [ ]* 1.2 Write property test for metadata parameters
  - **Property 2: Metadata query parameters trigger bypass**
  - **Validates: Requirements 6.1-6.7**

- [ ]* 1.3 Write property test for partNumber parameter
  - **Property 3: PartNumber parameter triggers bypass**
  - **Validates: Requirements 5.1**

- [ ]* 1.4 Write property test for root path
  - **Property 4: Root path triggers bypass**
  - **Validates: Requirements 4.1**

- [ ]* 1.5 Write property test for reason string
  - **Property 5: Detection function returns reason string**
  - **Validates: Requirements 7.2**

- [ ]* 1.6 Write property test for GetObject requests
  - **Property 6: GetObject requests do not trigger bypass**
  - **Validates: Requirements 7.5**

- [ ]* 1.7 Write property test for versionId parameter
  - **Property 7: VersionId alone does not trigger bypass**
  - **Validates: Requirements 10.7**

- [x] 2. Integrate detection into request handler
  - Parse query parameters from request URI in main request handler
  - For HEAD requests: Only root path "/" triggers bypass (HeadBucket), all other HEAD requests are cached (HeadObject)
  - For GET requests: Call `should_bypass_cache()` with full detection logic
  - If bypass is needed, skip cache operations and forward directly to S3
  - If cacheable, proceed with existing cache pipeline
  - _Requirements: 7.1, 7.4, 9.1-9.5_

- [x] 3. Add structured logging for cache bypass
  - Log at INFO level when cache bypass is triggered
  - Include operation type, reason, method, path, and query parameters in log
  - Log HeadBucket operations (HEAD to root path) as "ListBuckets"
  - Do not log for GetObject requests (cacheable)
  - _Requirements: 8.1-8.5_

- [ ]* 3.1 Write property test for bypass logging
  - **Property 9: Bypass logging includes operation type**
  - **Validates: Requirements 1.3, 2.2, 3.2, 4.2, 5.2, 6.8, 8.3**

- [ ]* 3.2 Write property test for logging reason
  - **Property 10: Bypass logging includes reason**
  - **Validates: Requirements 8.4**

- [ ]* 3.3 Write property test for logging request details
  - **Property 11: Bypass logging includes request details**
  - **Validates: Requirements 8.2**

- [ ]* 3.4 Write property test for GetObject logging
  - **Property 12: GetObject requests do not generate bypass logs**
  - **Validates: Requirements 8.5**

- [x] 4. Ensure bypass requests are not cached
  - Verify that bypassed requests skip all cache storage operations
  - Ensure responses are returned directly without caching
  - _Requirements: 1.4, 2.3, 3.3, 4.3, 5.3, 6.9_

- [ ]* 4.1 Write property test for cache state
  - **Property 8: Bypass requests are not cached**
  - **Validates: Requirements 1.4, 2.3, 3.3, 4.3, 5.3, 6.9**

- [x] 5. Implement error passthrough for bypass requests
  - Ensure S3 error responses are returned without modification
  - Do not apply any cache-related error handling to bypassed requests
  - _Requirements: 1.5, 2.4, 3.4, 4.4, 5.4, 6.10_

- [ ]* 5.1 Write property test for error passthrough
  - **Property 13: Error responses are passed through**
  - **Validates: Requirements 1.5, 2.4, 3.4, 4.4, 5.4, 6.10**

- [ ]* 6. Write unit tests for detection function
  - Test each LIST parameter individually (list-type, delimiter, versions, uploads)
  - Test each metadata parameter individually (acl, attributes, legal-hold, object-lock, retention, tagging, torrent)
  - Test partNumber parameter
  - Test root path detection
  - Test versionId parameter alone (should NOT trigger bypass)
  - Test combinations of query parameters
  - Test GetObject requests without bypass triggers
  - Test edge cases (empty path, malformed parameters)
  - Test HEAD requests (HEAD to root path bypasses, HEAD to objects are cached)
  - _Requirements: 10.1-10.9_

- [ ]* 7. Write integration tests
  - Test end-to-end LIST operations through proxy
  - Test end-to-end metadata operations through proxy
  - Test mixed cacheable and non-cacheable requests
  - Verify cache only stores GetObject responses
  - Verify correct responses for all operation types
  - Test error scenarios for non-cacheable operations
  - _Requirements: All_

- [x] 8. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
