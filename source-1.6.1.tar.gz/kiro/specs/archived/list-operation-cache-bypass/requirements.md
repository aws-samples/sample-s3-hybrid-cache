# Requirements Document

## Introduction

The S3 Proxy currently caches all GET and HEAD requests indiscriminately. However, only GetObject and HeadObject operations should be cached, as they retrieve immutable object data and metadata. All other S3 operations (ListObjects, ListObjectVersions, ListMultipartUploads, ListBuckets/HeadBucket, GetObjectAcl, GetObjectAttributes, GetObjectLegalHold, GetObjectLockConfiguration, GetObjectRetention, GetObjectTagging, GetObjectTorrent, and part-number requests) return dynamic metadata or lists that change frequently and should not be cached. This feature will implement intelligent request detection to bypass the cache for non-GetObject/non-HeadObject operations, ensuring clients always receive fresh data while maintaining cache benefits for GetObject and HeadObject requests.

## Glossary

- **S3_Proxy**: The HTTP/HTTPS proxy server that forwards requests to S3 endpoints
- **GetObject**: The only S3 GET operation that should be cached - retrieves immutable object data
- **Non_GetObject_Operation**: Any S3 GET operation other than GetObject that returns dynamic data
- **Query_Parameter**: URL query string parameters that indicate the type of S3 operation
- **Cache_Bypass**: The process of forwarding a request directly to S3 without checking or storing in cache
- **ListObjects**: S3 operation to list objects in a bucket (indicated by list-type or delimiter query parameters)
- **ListObjectVersions**: S3 operation to list object versions (indicated by versions query parameter)
- **ListMultipartUploads**: S3 operation to list in-progress multipart uploads (indicated by uploads query parameter)
- **ListBuckets**: S3 operation to list all buckets (GET or HEAD request to root path /)
- **HeadObject**: S3 HEAD operation to retrieve object metadata (HEAD request to object path) - should be cached
- **HeadBucket**: S3 HEAD operation to check bucket existence (HEAD request to root path /) - should NOT be cached, treated as ListBuckets
- **GetObjectAcl**: S3 operation to retrieve object ACL (indicated by acl query parameter)
- **GetObjectAttributes**: S3 operation to retrieve object attributes (indicated by attributes query parameter)
- **GetObjectLegalHold**: S3 operation to retrieve legal hold status (indicated by legal-hold query parameter)
- **GetObjectLockConfiguration**: S3 operation to retrieve object lock configuration (indicated by object-lock query parameter)
- **GetObjectRetention**: S3 operation to retrieve retention settings (indicated by retention query parameter)
- **GetObjectTagging**: S3 operation to retrieve object tags (indicated by tagging query parameter)
- **GetObjectTorrent**: S3 operation to retrieve torrent file (indicated by torrent query parameter)
- **PartNumber_Request**: GET request with partNumber query parameter to retrieve a specific part of a multipart object
- **Request_Path**: The URI path component of the HTTP request
- **S3_Endpoint**: The target S3 or S3-compatible storage service

## Requirements

### Requirement 1

**User Story:** As a client, I want S3 ListObjects operations to bypass the cache, so that I always receive the current list of objects in a bucket.

#### Acceptance Criteria

1. WHEN a GET request includes a list-type query parameter THEN the S3_Proxy SHALL bypass the cache entirely and forward the request directly to the S3_Endpoint
2. WHEN a GET request includes a delimiter query parameter without list-type THEN the S3_Proxy SHALL bypass the cache entirely and forward the request directly to the S3_Endpoint
3. WHEN bypassing cache for ListObjects operations THEN the S3_Proxy SHALL log the operation type as "ListObjects" and the reason as "list operation - always fetch fresh data"
4. WHEN a ListObjects request is processed THEN the S3_Proxy SHALL return the S3_Endpoint response directly to the client without storing it in cache
5. WHEN a ListObjects request fails THEN the S3_Proxy SHALL return the S3_Endpoint error response to the client without any cache-related modifications

### Requirement 2

**User Story:** As a client, I want S3 ListObjectVersions operations to bypass the cache, so that I always receive the current list of object versions.

#### Acceptance Criteria

1. WHEN a GET request includes a versions query parameter THEN the S3_Proxy SHALL bypass the cache entirely and forward the request directly to the S3_Endpoint
2. WHEN bypassing cache for ListObjectVersions operations THEN the S3_Proxy SHALL log the operation type as "ListObjectVersions" and the reason as "list operation - always fetch fresh data"
3. WHEN a ListObjectVersions request is processed THEN the S3_Proxy SHALL return the S3_Endpoint response directly to the client without storing it in cache
4. WHEN a ListObjectVersions request fails THEN the S3_Proxy SHALL return the S3_Endpoint error response to the client without any cache-related modifications

### Requirement 3

**User Story:** As a client, I want S3 ListMultipartUploads operations to bypass the cache, so that I always receive the current list of in-progress multipart uploads.

#### Acceptance Criteria

1. WHEN a GET request includes an uploads query parameter THEN the S3_Proxy SHALL bypass the cache entirely and forward the request directly to the S3_Endpoint
2. WHEN bypassing cache for ListMultipartUploads operations THEN the S3_Proxy SHALL log the operation type as "ListMultipartUploads" and the reason as "list operation - always fetch fresh data"
3. WHEN a ListMultipartUploads request is processed THEN the S3_Proxy SHALL return the S3_Endpoint response directly to the client without storing it in cache
4. WHEN a ListMultipartUploads request fails THEN the S3_Proxy SHALL return the S3_Endpoint error response to the client without any cache-related modifications

### Requirement 4

**User Story:** As a client, I want S3 ListBuckets and HeadBucket operations to bypass the cache, so that I always receive the current bucket information.

#### Acceptance Criteria

1. WHEN a GET or HEAD request is to the root path (/) THEN the S3_Proxy SHALL bypass the cache entirely and forward the request directly to the S3_Endpoint
2. WHEN bypassing cache for ListBuckets or HeadBucket operations THEN the S3_Proxy SHALL log the operation type as "ListBuckets" and the reason as "list operation - always fetch fresh data"
3. WHEN a ListBuckets or HeadBucket request is processed THEN the S3_Proxy SHALL return the S3_Endpoint response directly to the client without storing it in cache
4. WHEN a ListBuckets or HeadBucket request fails THEN the S3_Proxy SHALL return the S3_Endpoint error response to the client without any cache-related modifications

### Requirement 5

**User Story:** As a client, I want GET requests with partNumber to bypass the cache, so that I can retrieve specific parts of multipart objects without cache interference.

#### Acceptance Criteria

1. WHEN a GET request includes a partNumber query parameter THEN the S3_Proxy SHALL bypass the cache entirely and forward the request directly to the S3_Endpoint
2. WHEN bypassing cache for partNumber requests THEN the S3_Proxy SHALL log the operation type as "GetObjectPart" and the reason as "part-number requests are rarely used and not cached"
3. WHEN a partNumber request is processed THEN the S3_Proxy SHALL return the S3_Endpoint response directly to the client without storing it in cache
4. WHEN a partNumber request fails THEN the S3_Proxy SHALL return the S3_Endpoint error response to the client without any cache-related modifications

### Requirement 6

**User Story:** As a client, I want S3 metadata retrieval operations to bypass the cache, so that I always receive current object metadata, ACLs, tags, and attributes.

#### Acceptance Criteria

1. WHEN a GET request includes an acl query parameter THEN the S3_Proxy SHALL bypass the cache and forward the request directly to the S3_Endpoint
2. WHEN a GET request includes an attributes query parameter THEN the S3_Proxy SHALL bypass the cache and forward the request directly to the S3_Endpoint
3. WHEN a GET request includes a legal-hold query parameter THEN the S3_Proxy SHALL bypass the cache and forward the request directly to the S3_Endpoint
4. WHEN a GET request includes an object-lock query parameter THEN the S3_Proxy SHALL bypass the cache and forward the request directly to the S3_Endpoint
5. WHEN a GET request includes a retention query parameter THEN the S3_Proxy SHALL bypass the cache and forward the request directly to the S3_Endpoint
6. WHEN a GET request includes a tagging query parameter THEN the S3_Proxy SHALL bypass the cache and forward the request directly to the S3_Endpoint
7. WHEN a GET request includes a torrent query parameter THEN the S3_Proxy SHALL bypass the cache and forward the request directly to the S3_Endpoint
8. WHEN bypassing cache for metadata operations THEN the S3_Proxy SHALL log the specific operation type (GetObjectAcl, GetObjectTagging, etc.) and reason "metadata operation - always fetch fresh data"
9. WHEN a metadata operation request is processed THEN the S3_Proxy SHALL return the S3_Endpoint response directly to the client without storing it in cache
10. WHEN a metadata operation request fails THEN the S3_Proxy SHALL return the S3_Endpoint error response to the client without any cache-related modifications

### Requirement 7

**User Story:** As a developer, I want a centralized function to detect non-cacheable requests, so that the detection logic is maintainable and consistent.

#### Acceptance Criteria

1. WHEN evaluating a request for caching THEN the S3_Proxy SHALL use a single centralized function to determine if the request should bypass cache
2. WHEN the detection function identifies a non-cacheable request THEN it SHALL return both a boolean flag and a descriptive reason string
3. WHEN adding new non-cacheable request types THEN developers SHALL only need to modify the centralized detection function
4. WHEN the detection function is called THEN it SHALL examine the request path and query parameters to make the determination
5. WHEN the detection function identifies a cacheable request THEN it SHALL return false with an empty reason string

### Requirement 8

**User Story:** As a system administrator, I want clear logging for cache bypass decisions, so that I can monitor and troubleshoot proxy behavior.

#### Acceptance Criteria

1. WHEN a request bypasses cache THEN the S3_Proxy SHALL log at INFO level with the operation type and reason
2. WHEN logging cache bypass THEN the log entry SHALL include the request method, path, and query parameters
3. WHEN logging cache bypass THEN the log entry SHALL include the detected operation type (ListObjects, ListBuckets, etc.)
4. WHEN logging cache bypass THEN the log entry SHALL include the reason for bypass
5. WHEN a request is cacheable THEN the S3_Proxy SHALL NOT log cache bypass information to avoid log noise

### Requirement 9

**User Story:** As a client, I want HeadObject operations to be cached while HeadBucket operations bypass the cache, so that I benefit from cached object metadata while always receiving fresh bucket information.

#### Acceptance Criteria

1. WHEN a HEAD request is to an object path (not root path) THEN the S3_Proxy SHALL cache the response using the existing HEAD cache
2. WHEN a HEAD request is to the root path (/) THEN the S3_Proxy SHALL bypass the cache and forward the request directly to the S3_Endpoint
3. WHEN bypassing cache for HeadBucket operations THEN the S3_Proxy SHALL log the operation type as "ListBuckets" and the reason as "list operation - always fetch fresh data"
4. WHEN a HeadBucket request is processed THEN the S3_Proxy SHALL return the S3_Endpoint response directly to the client without storing it in cache
5. WHEN a HeadObject request is processed THEN the S3_Proxy SHALL cache the response for future HEAD requests to the same object

### Requirement 10

**User Story:** As a developer, I want comprehensive tests for non-GetObject operation detection, so that I can ensure the feature works correctly across all scenarios.

#### Acceptance Criteria

1. WHEN testing LIST operation detection THEN tests SHALL verify detection of list-type, delimiter, versions, and uploads query parameters
2. WHEN testing metadata operation detection THEN tests SHALL verify detection of acl, attributes, legal-hold, object-lock, retention, tagging, and torrent query parameters
3. WHEN testing root path detection THEN tests SHALL verify detection of root path (/) for ListBuckets
4. WHEN testing partNumber detection THEN tests SHALL verify detection of partNumber query parameter
5. WHEN testing with GetObject requests THEN tests SHALL verify that requests without any non-cacheable query parameters are NOT detected as non-cacheable
6. WHEN testing with multiple query parameters THEN tests SHALL verify that presence of any non-cacheable parameter triggers bypass
7. WHEN testing with versionId parameter alone THEN tests SHALL verify that versionId does NOT trigger bypass (it's part of GetObject)
8. WHEN testing with Range header alone THEN tests SHALL verify that Range header does NOT trigger bypass (it's part of GetObject)
9. WHEN testing HEAD requests THEN tests SHALL verify that HEAD to root path bypasses cache while HEAD to object paths are cached
