# Design Document

## Overview

This feature adds intelligent request detection to the S3 Proxy to identify and bypass cache for all S3 GET operations except GetObject, and all HEAD operations except HeadObject. According to the AWS S3 API, only GetObject and HeadObject retrieve immutable object data and metadata that benefit from caching. All other operations (LIST operations, metadata retrieval, ACL queries, tagging, attributes, HeadBucket, etc.) return dynamic data that changes frequently and should always be fetched fresh from S3. The implementation will add a centralized detection function that examines request paths and query parameters to determine if a request is cacheable (GetObject/HeadObject) or non-cacheable (all other operations).

## Architecture

The cache bypass detection will be implemented as a pure function that analyzes HTTP requests before they enter the caching pipeline. This function will be called early in the request handling flow, immediately after request parsing and before any cache lookups.

### Request Flow with Cache Bypass Detection

```
Client Request
    ↓
Parse HTTP Request
    ↓
Detect Non-Cacheable Request ← NEW
    ↓
    ├─ Non-Cacheable? → Forward to S3 → Return Response
    │                    (bypass cache)
    └─ Cacheable? → Existing Cache Pipeline
                    (check cache, fetch if needed, store)
```

### Integration Points

1. **http_proxy.rs**: Main request handler will call detection function before cache operations
2. **Query Parameter Parsing**: Extract and analyze URL query parameters
3. **Path Analysis**: Check request path for special cases (root path for ListBuckets)
4. **Logging**: Add structured logging for cache bypass decisions

## Components and Interfaces

### Detection Function

```rust
/// Determines if a request should bypass cache based on S3 operation type
/// 
/// Returns (should_bypass, operation_type, reason)
fn should_bypass_cache(
    method: &Method,
    path: &str,
    query_params: &HashMap<String, String>
) -> (bool, Option<String>, Option<String>)
```

**Parameters:**
- `method`: HTTP method (GET, HEAD, etc.)
- `path`: Request URI path
- `query_params`: Parsed query string parameters

**Returns:**
- `should_bypass`: Boolean indicating if cache should be bypassed
- `operation_type`: Optional string describing the operation (e.g., "ListObjects", "GetObjectPart")
- `reason`: Optional string explaining why cache was bypassed

### Detection Logic

The function will check for non-cacheable indicators in this order:

**For HEAD requests:**
1. **Root Path Check**: If path is "/" → HeadBucket/ListBuckets operation (non-cacheable)
2. **Otherwise**: HeadObject operation (cacheable)

**For GET requests:**
1. **Root Path Check**: If path is "/" → ListBuckets operation (non-cacheable)
2. **Query Parameter Checks** (any of these indicates non-GetObject operation):
   - **LIST Operations**:
     - `list-type` → ListObjects operation
     - `delimiter` → ListObjects operation
     - `versions` → ListObjectVersions operation
     - `uploads` → ListMultipartUploads operation
   - **Metadata Operations**:
     - `acl` → GetObjectAcl operation
     - `attributes` → GetObjectAttributes operation
     - `legal-hold` → GetObjectLegalHold operation
     - `object-lock` → GetObjectLockConfiguration operation
     - `retention` → GetObjectRetention operation
     - `tagging` → GetObjectTagging operation
     - `torrent` → GetObjectTorrent operation
   - **Part Operations**:
     - `partNumber` → GetObjectPart operation
3. **Default**: If none of the above → GetObject operation (cacheable)

**Note**: The `versionId` query parameter does NOT trigger bypass - it's part of GetObject and should be cached. Similarly, the `Range` header does not trigger bypass.

### Modified Request Handler

The main request handler in `http_proxy.rs` will be modified to:

1. Parse query parameters from request URI
2. Determine if bypass is needed:
   - For HEAD requests: Only root path "/" triggers bypass (HeadBucket)
   - For GET requests: Call `should_bypass_cache()` function with full detection logic
3. If bypass is needed:
   - Log the operation type and reason at INFO level
   - Forward request directly to S3
   - Return response without caching
4. Otherwise, proceed with existing cache pipeline:
   - HeadObject requests use HEAD cache
   - GetObject requests use GET cache with range support

## Data Models

### Query Parameter Map

```rust
type QueryParams = HashMap<String, String>;
```

Parsed from the request URI query string. Keys are parameter names, values are parameter values.

### Cache Bypass Result

```rust
struct CacheBypassResult {
    should_bypass: bool,
    operation_type: Option<String>,
    reason: Option<String>,
}
```

Encapsulates the detection result with operation metadata for logging.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: LIST query parameters trigger bypass

*For any* GET request containing query parameters `list-type`, `delimiter`, `versions`, or `uploads`, the detection function should return `should_bypass=true` with an appropriate operation type
**Validates: Requirements 1.1, 1.2, 2.1, 3.1**

### Property 2: Metadata query parameters trigger bypass

*For any* GET request containing query parameters `acl`, `attributes`, `legal-hold`, `object-lock`, `retention`, `tagging`, or `torrent`, the detection function should return `should_bypass=true` with an appropriate operation type
**Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7**

### Property 3: PartNumber parameter triggers bypass

*For any* GET request containing the `partNumber` query parameter, the detection function should return `should_bypass=true` with operation type "GetObjectPart"
**Validates: Requirements 5.1**

### Property 4: Root path triggers bypass

*For any* GET request to path "/", the detection function should return `should_bypass=true` with operation type "ListBuckets"
**Validates: Requirements 4.1**

### Property 5: Detection function returns reason string

*For any* request that triggers cache bypass, the detection function should return a non-empty reason string explaining why
**Validates: Requirements 7.2**

### Property 6: GetObject requests do not trigger bypass

*For any* GET request without non-cacheable query parameters and not to root path, the detection function should return `should_bypass=false` with empty operation type and reason
**Validates: Requirements 7.5**

### Property 7: VersionId alone does not trigger bypass

*For any* GET request with only `versionId` query parameter, the detection function should return `should_bypass=false` because versionId is part of GetObject
**Validates: Requirements 9.7**

### Property 8: Bypass requests are not cached

*For any* request that triggers cache bypass, after processing the request, the cache should not contain any entry for that request
**Validates: Requirements 1.4, 2.3, 3.3, 4.3, 5.3, 6.9**

### Property 9: Bypass logging includes operation type

*For any* request that triggers cache bypass, the log output should contain the detected operation type
**Validates: Requirements 1.3, 2.2, 3.2, 4.2, 5.2, 6.8, 8.3**

### Property 10: Bypass logging includes reason

*For any* request that triggers cache bypass, the log output should contain the reason string
**Validates: Requirements 8.4**

### Property 11: Bypass logging includes request details

*For any* request that triggers cache bypass, the log output should contain the request method, path, and query parameters
**Validates: Requirements 8.2**

### Property 12: GetObject requests do not generate bypass logs

*For any* GetObject request (cacheable), the log output should not contain cache bypass messages
**Validates: Requirements 8.5**

### Property 13: Error responses are passed through

*For any* non-cacheable request that results in an error from S3, the proxy should return the error response without modification
**Validates: Requirements 1.5, 2.4, 3.4, 4.4, 5.4, 6.10**

## Error Handling

### Query Parameter Parsing Errors

If query parameter parsing fails, the request should be treated as cacheable (fail-safe behavior). This ensures that parsing errors don't prevent normal caching operations.

### S3 Request Errors

When bypassing cache, S3 errors should be returned directly to the client without any cache-related error handling or modifications. The proxy acts as a transparent forwarder for non-cacheable requests.

### Logging Errors

If logging fails during cache bypass, the request should still be processed normally. Logging failures should not affect request handling.

## Testing Strategy

### Unit Tests

1. **Detection Function Tests**:
   - Test each LIST query parameter individually (list-type, delimiter, versions, uploads)
   - Test each metadata query parameter individually (acl, attributes, legal-hold, object-lock, retention, tagging, torrent)
   - Test partNumber parameter
   - Test root path detection
   - Test versionId parameter alone (should NOT trigger bypass)
   - Test combinations of query parameters
   - Test GetObject requests without bypass triggers
   - Test edge cases (empty path, malformed parameters)

2. **Query Parameter Parsing Tests**:
   - Test various query string formats
   - Test URL encoding/decoding
   - Test multiple parameters
   - Test parameters with and without values

### Property-Based Tests

Using the `quickcheck` framework, we will implement property tests for:

1. **Properties 1-7**: Detection function behavior across random request inputs
2. **Property 8**: Cache state verification after bypass
3. **Properties 9-12**: Log content verification
4. **Property 13**: Error passthrough behavior

Each property test will run a minimum of 100 iterations with randomly generated:
- Request paths (including root path)
- Query parameter combinations
- HTTP methods
- S3 response scenarios (success and error)

### Integration Tests

1. **End-to-End LIST Operation Tests**:
   - Send actual LIST requests through the proxy
   - Verify responses match S3 directly
   - Verify cache remains empty
   - Verify logs contain expected entries

2. **Mixed Request Tests**:
   - Alternate between cacheable and non-cacheable requests
   - Verify cache only stores cacheable requests
   - Verify correct responses for both types

3. **Error Scenario Tests**:
   - Test S3 errors for LIST operations
   - Verify error responses are passed through
   - Verify no cache entries are created

### Test Organization

- Unit tests: Inline with source code in `http_proxy.rs`
- Property-based tests: New file `tests/list_operation_bypass_test.rs`
- Integration tests: Add to existing `tests/integration_test.rs`

## Implementation Notes

### Performance Considerations

- Detection function should be O(1) for query parameter lookups using HashMap
- Path comparison for root path is O(1)
- No regex or complex string matching needed
- Minimal overhead added to request processing

### Backward Compatibility

This feature only adds new behavior for previously uncached operations. Existing cached GET requests will continue to work identically. No breaking changes to configuration or API.

### Configuration

No new configuration options are needed. The detection logic is based on S3 API semantics and should always be active.

### Logging Format

Cache bypass logs will use structured logging with these fields:
- `level`: INFO
- `message`: "Bypassing cache for {operation_type}"
- `method`: HTTP method
- `path`: Request path
- `query_params`: Query parameter string
- `operation_type`: Detected operation (ListObjects, GetObjectAcl, etc.)
- `reason`: Explanation for bypass

Example log entries:
```
INFO Bypassing cache for ListObjects method=GET path=/my-bucket/ query_params="list-type=2&prefix=photos/" operation_type=ListObjects reason="list operation - always fetch fresh data"

INFO Bypassing cache for GetObjectAcl method=GET path=/my-bucket/photo.jpg query_params="acl" operation_type=GetObjectAcl reason="metadata operation - always fetch fresh data"

INFO Bypassing cache for GetObjectTagging method=GET path=/my-bucket/document.pdf query_params="tagging" operation_type=GetObjectTagging reason="metadata operation - always fetch fresh data"
```

## Future Enhancements

### Potential Extensions

1. **Configurable Bypass Rules**: Allow administrators to configure additional query parameters or paths that should bypass cache
2. **Bypass Metrics**: Track cache bypass rate and operation types in metrics
3. **Selective LIST Caching**: For specific use cases, allow short-TTL caching of LIST results
4. **POST Request Handling**: Extend detection to POST requests for S3 operations that use POST method

These enhancements are not part of the current scope but could be added in future iterations based on user needs.
