# Implementation Plan

- [x] 1. Add write cache to range cache transition method in CacheManager
  - Create `transition_write_cache_to_range_cache()` method in `src/cache.rs`
  - Read write cache entry using existing `get_write_cache_entry()`
  - Store data as range using `disk_cache.store_range()`
  - Create object metadata with full range (0-size)
  - Delete write cache file after successful range storage
  - Add comprehensive logging for each step
  - Handle errors gracefully (keep write cache on failure)
  - _Requirements: 1.1, 1.2, 1.3, 2.1, 2.2, 2.3, 3.1, 3.2, 3.3_

- [x] 2. Update spawn_cache_write_task to call transition after S3 success
  - Locate the S3 success handling code in `spawn_cache_write_task()`
  - After `cache_writer.commit()` succeeds, call transition method
  - Pass cache_manager to the transition call
  - Log transition start and completion
  - Handle transition errors (log but don't fail the PUT)
  - _Requirements: 1.1, 1.5, 3.1, 3.4_

- [x] 3. Add startup cleanup for stale write cache files
  - Create `cleanup_stale_write_cache_on_startup()` method in `src/cache.rs`
  - Scan write_cache directory recursively
  - Check file modification time against PUT_TTL
  - Delete files older than PUT_TTL
  - Log each deletion with file path and age
  - Call this method in CacheManager initialization
  - _Requirements: 2.4, 3.4_

- [x] 4. Add helper method to delete write cache files
  - Create `delete_write_cache_file()` method in `src/cache.rs`
  - Construct write cache file path from cache key
  - Delete the file using `tokio::fs::remove_file()`
  - Handle file-not-found gracefully (already deleted)
  - Log deletion success or failure
  - _Requirements: 1.3, 2.3, 3.3_

- [x] 5. Write integration test for PUT then GET workflow
  - Create test that PUTs a file through the proxy
  - Wait for background task completion (small delay)
  - GET the same file
  - Verify cache hit (check logs or metrics)
  - Verify correct data returned
  - Verify write cache file is gone
  - Verify range cache file exists
  - _Requirements: 1.1, 1.5_

- [x] 6. Write unit test for transition method
  - Create write cache entry in test
  - Call `transition_write_cache_to_range_cache()`
  - Verify range cache file created
  - Verify metadata file created with correct range
  - Verify write cache file deleted
  - Verify compression info preserved
  - _Requirements: 1.1, 1.2, 1.3, 4.1, 4.2_

- [x] 7. Write test for startup cleanup
  - Create old write cache files (modify timestamps)
  - Create recent write cache files
  - Call `cleanup_stale_write_cache_on_startup()`
  - Verify old files deleted
  - Verify recent files remain
  - _Requirements: 2.4_

- [x] 8. Write test for transition error handling
  - Mock range cache write to fail
  - Call transition
  - Verify write cache file still exists
  - Verify error logged
  - Verify no range cache file created
  - _Requirements: 2.2, 2.4, 3.4_

- [x] 9. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
