# Design Document

## Overview

This design implements automatic transition of write cache data to range cache after S3 confirms successful PUT requests. Currently, write cache files remain isolated in `tmp/cache/write_cache/` and are invisible to GET requests. This fix ensures that after S3 returns 200 OK, the data is moved to the permanent range cache where it can be served to subsequent GET requests.

## Architecture

### Current Flow (Buggy)
```
PUT /bucket/file.zip
  ↓
[Background Task]
  ↓
Write to: tmp/cache/write_cache/bucket/file.zip
  ↓
Wait for S3 result
  ↓
S3 returns 200 OK
  ↓
Commit to write cache ✓
  ↓
[END] ❌ File stays in write_cache/

GET /bucket/file.zip
  ↓
Check RAM cache → Miss
  ↓
Check disk cache (objects/ranges) → Miss
  ↓
Fetch from S3 ❌
```

### Fixed Flow
```
PUT /bucket/file.zip
  ↓
[Background Task]
  ↓
Write to: tmp/cache/write_cache/bucket/file.zip
  ↓
Wait for S3 result
  ↓
S3 returns 200 OK
  ↓
Commit to write cache ✓
  ↓
[NEW] Transition to range cache:
  - Read write cache file
  - Store as range: ranges/{key}_0-{size}.bin
  - Create metadata: objects/{key}.meta
  - Delete write cache file
  ↓
[END] ✓ Data in range cache

GET /bucket/file.zip
  ↓
Check RAM cache → Miss
  ↓
Check disk cache → HIT ✓
  ↓
Serve from cache
```

## Components and Interfaces

### Modified Component: `spawn_cache_write_task`

Location: `src/signed_put_handler.rs`

**Current behavior:**
```rust
if status.is_success() {
    // Commit to write cache
    cache_writer.commit(metadata).await?;
    // [BUG] Stops here
}
```

**New behavior:**
```rust
if status.is_success() {
    // Commit to write cache
    cache_writer.commit(metadata).await?;
    
    // [FIX] Transition to range cache
    if let Some(cache_mgr) = &cache_manager {
        cache_mgr.transition_write_cache_to_range_cache(&cache_key).await?;
    }
}
```

### New Method: `transition_write_cache_to_range_cache`

Location: `src/cache.rs`

```rust
pub async fn transition_write_cache_to_range_cache(&self, cache_key: &str) -> Result<()> {
    // 1. Read write cache entry
    let write_entry = self.get_write_cache_entry(cache_key).await?;
    
    // 2. Store as range 0-N
    let size = write_entry.body.len();
    self.disk_cache.store_range(cache_key, 0, size - 1, &write_entry.body).await?;
    
    // 3. Create object metadata
    let metadata = NewCacheMetadata {
        ranges: vec![ByteRange { start: 0, end: size - 1 }],
        total_size: Some(size),
        compression_info: write_entry.compression_info,
        // ... other fields
    };
    self.store_metadata(cache_key, metadata).await?;
    
    // 4. Delete write cache file
    self.delete_write_cache_file(cache_key).await?;
    
    Ok(())
}
```

## Data Models

### Write Cache Entry
```rust
struct WriteCacheEntry {
    cache_key: String,
    body: Bytes,              // Actual data
    headers: HashMap<String, String>,
    metadata: ObjectMetadata,
    compression_info: Option<CompressionInfo>,
    created_at: SystemTime,
    put_ttl_expires_at: SystemTime,
    last_accessed: SystemTime,
}
```

### Range Cache Storage
```rust
// File: tmp/cache/ranges/{cache_key}_0-{size-1}.bin
// Contains: Raw bytes (possibly compressed)

// File: tmp/cache/objects/{cache_key}.meta
struct NewCacheMetadata {
    ranges: Vec<ByteRange>,           // [0-{size-1}]
    total_size: Option<u64>,          // Full object size
    etag: Option<String>,
    last_modified: Option<SystemTime>,
    content_type: Option<String>,
    compression_info: Option<CompressionInfo>,
    created_at: SystemTime,
    last_accessed: SystemTime,
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Data availability after PUT

*For any* successful PUT request (S3 returns 200), a subsequent GET request for the same object SHALL find the data in the cache without fetching from S3.

**Validates: Requirements 1.1, 1.5**

### Property 2: Atomic transition

*For any* write cache transition, the data SHALL exist in at least one location (write cache OR range cache) at all times during the transition.

**Validates: Requirements 2.1, 2.2**

### Property 3: Write-before-delete ordering

*For any* write cache transition, the range cache file SHALL be successfully written before the write cache file is deleted.

**Validates: Requirements 2.1, 2.2, 2.3**

### Property 4: Compression preservation

*For any* write cache entry with compression information, the transitioned range cache entry SHALL preserve the same compression algorithm and metadata.

**Validates: Requirements 4.1, 4.2, 4.3**

### Property 5: Idempotent transition

*For any* cache key, calling transition multiple times SHALL produce the same result as calling it once (either all succeed or all fail consistently).

**Validates: Requirements 5.2, 5.5**

### Property 6: No data loss on failure

*For any* transition that fails at any step, the original write cache data SHALL remain accessible until PUT_TTL expires.

**Validates: Requirements 2.2, 2.4**

## Error Handling

### Transition Failure Scenarios

1. **Write cache file not found**
   - Log warning: "Write cache file missing for transition"
   - Return Ok (already transitioned or expired)
   - No action needed

2. **Range cache write fails**
   - Log error with cache key and error details
   - Keep write cache file intact
   - Return error
   - Write cache will be cleaned up at PUT_TTL expiration

3. **Metadata creation fails**
   - Log error
   - Keep write cache file
   - Attempt to delete orphaned range file
   - Return error

4. **Write cache deletion fails**
   - Log warning (not critical)
   - Range cache is already created
   - Return Ok (transition succeeded)
   - Write cache will be cleaned up at PUT_TTL expiration

### Race Condition Handling

1. **Concurrent GET during transition**
   - GET checks range cache first
   - If not found, fetches from S3
   - No corruption possible

2. **Concurrent PUT for same object**
   - Each PUT has its own background task
   - Last PUT wins (overwrites range cache)
   - Old range cache data is replaced

3. **Transition already in progress**
   - Second transition attempt finds write cache missing
   - Returns Ok (already transitioned)
   - No duplicate work

## Testing Strategy

### Unit Tests

1. **Successful transition test**
   - Create write cache entry
   - Call transition
   - Verify range cache file exists
   - Verify metadata file exists
   - Verify write cache file deleted
   - Verify GET request finds data

2. **Compression preservation test**
   - Create compressed write cache entry
   - Call transition
   - Verify range cache has compression metadata
   - Verify data can be decompressed correctly

3. **Missing write cache test**
   - Call transition with non-existent cache key
   - Verify returns Ok (no error)
   - Verify no range cache created

4. **Partial failure test**
   - Mock range cache write to fail
   - Call transition
   - Verify write cache file still exists
   - Verify error returned

### Integration Tests

1. **PUT then GET test**
   - PUT a file through proxy
   - Wait for background task completion
   - GET the same file
   - Verify cache hit (not fetched from S3)
   - Verify correct data returned

2. **Multiple PUTs test**
   - PUT file A
   - PUT file B
   - GET file A → cache hit
   - GET file B → cache hit

3. **PUT overwrite test**
   - PUT file with content "v1"
   - GET file → returns "v1"
   - PUT same file with content "v2"
   - GET file → returns "v2" (not "v1")

### Property-Based Tests

Use `quickcheck` crate with minimum 100 iterations per property.

## Implementation Notes

### Performance Considerations

1. **File I/O**: Transition involves reading write cache file and writing range cache file
   - For large files, this is disk-to-disk copy
   - Happens in background task, doesn't block client response
   - Consider using `tokio::fs::copy` for efficiency

2. **Memory usage**: Write cache data is already in memory (Bytes)
   - No additional memory allocation needed
   - Bytes::clone() is cheap (reference counted)

3. **Timing**: Transition happens after S3 confirms success
   - Client already received response
   - No impact on client latency

### Startup Cleanup

On cache manager initialization, scan write cache directory for stale files:

```rust
pub async fn cleanup_stale_write_cache_on_startup(&self) -> Result<()> {
    let write_cache_dir = self.cache_dir.join("write_cache");
    let now = SystemTime::now();
    
    // Scan all write cache files
    for entry in walk_dir(&write_cache_dir).await? {
        if let Ok(metadata) = entry.metadata().await {
            let age = now.duration_since(metadata.modified()?)?;
            
            // Remove files older than PUT_TTL
            if age > self.put_ttl {
                tokio::fs::remove_file(entry.path()).await?;
                info!("Removed stale write cache file: {:?}, age={:?}", entry.path(), age);
            }
        }
    }
    
    Ok(())
}
```

This ensures:
- Stale write cache files from crashes/restarts are cleaned up
- No manual intervention needed
- Happens once at startup, minimal performance impact

### Backward Compatibility

- Existing write cache files will be cleaned up at startup if older than PUT_TTL
- New PUTs will transition correctly
- No migration needed for recent write cache files
- GET requests will continue to work (fetch from S3 if cache miss)

### Logging

All log messages should include:
- Cache key
- File sizes (write cache, range cache)
- Transition duration
- Success/failure status
- Error details if failed

Example:
```
INFO: Transitioning write cache to range cache: cache_key=/bucket/file.zip, size=761 bytes
INFO: Range cache stored: cache_key=/bucket/file.zip, range=0-760
INFO: Write cache deleted: cache_key=/bucket/file.zip
INFO: Transition completed: cache_key=/bucket/file.zip, duration=5ms
```
