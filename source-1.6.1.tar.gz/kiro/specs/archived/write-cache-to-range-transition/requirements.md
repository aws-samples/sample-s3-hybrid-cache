# Requirements Document

## Introduction

This specification addresses a critical bug where successfully uploaded files via regular PUT requests remain in the write cache directory and are invisible to subsequent GET requests. When S3 confirms a PUT with 200 OK, the cached data should be transitioned from the temporary write cache to the permanent range cache, making it available for GET requests.

## Glossary

- **Write Cache**: Temporary storage location (`tmp/cache/write_cache/`) where PUT request data is initially cached during upload
- **Range Cache**: Permanent storage location (`tmp/cache/ranges/`) where object data is stored as byte ranges for serving GET requests
- **Object Metadata**: Metadata file (`tmp/cache/objects/*.meta`) that tracks which ranges are cached for an object
- **Cache Transition**: The process of moving data from write cache to range cache after S3 confirms successful upload
- **PUT_TTL**: Time-to-live for write cache entries
- **GET_TTL**: Time-to-live for range cache entries (typically much longer than PUT_TTL)

## Requirements

### Requirement 1

**User Story:** As a system caching PUT requests, I want to transition write cache data to range cache after S3 confirms success, so that subsequent GET requests can use the cached data.

#### Acceptance Criteria

1. WHEN S3 returns 200 OK for a PUT request THEN the system SHALL move the write cache data to the range cache
2. WHEN transitioning write cache to range cache THEN the system SHALL create object metadata tracking the full object as range 0-N
3. WHEN the transition completes successfully THEN the system SHALL delete the write cache file
4. WHEN the transition fails THEN the system SHALL leave the write cache file intact and log the error
5. WHEN a GET request arrives after successful PUT THEN the system SHALL find the data in the range cache

### Requirement 2

**User Story:** As a system operator, I want write cache transitions to be atomic, so that data is not lost during the transition process.

#### Acceptance Criteria

1. WHEN transitioning write cache data THEN the system SHALL write to range cache before deleting from write cache
2. WHEN range cache write fails THEN the system SHALL keep the write cache file and log the error
3. WHEN range cache write succeeds but write cache deletion fails THEN the system SHALL log a warning but consider the transition successful
4. WHEN the system crashes during transition THEN the write cache file SHALL remain until PUT_TTL expires
5. WHEN both write cache and range cache exist for the same object THEN the system SHALL prefer the range cache

### Requirement 3

**User Story:** As a developer debugging cache issues, I want detailed logging of write cache transitions, so that I can verify correct behavior.

#### Acceptance Criteria

1. WHEN a write cache transition starts THEN the system SHALL log the cache key and file size
2. WHEN range cache storage succeeds THEN the system SHALL log the range created (0-N)
3. WHEN write cache deletion succeeds THEN the system SHALL log the transition completion
4. WHEN any step fails THEN the system SHALL log the error with context
5. WHEN transition completes THEN the system SHALL log the total transition time

### Requirement 4

**User Story:** As a system managing cache storage, I want write cache transitions to preserve compression information, so that cached data maintains its compression state.

#### Acceptance Criteria

1. WHEN transitioning compressed write cache data THEN the system SHALL preserve the compression algorithm metadata
2. WHEN storing to range cache THEN the system SHALL include compression information in object metadata
3. WHEN serving from range cache THEN the system SHALL use the preserved compression information
4. WHEN write cache data is uncompressed THEN the system SHALL store it as uncompressed in range cache
5. WHEN compression information is missing THEN the system SHALL default to uncompressed

### Requirement 5

**User Story:** As a system handling concurrent requests, I want write cache transitions to handle race conditions, so that concurrent PUTs and GETs don't cause data corruption.

#### Acceptance Criteria

1. WHEN a GET request arrives during write cache transition THEN the system SHALL either serve from write cache or fetch from S3
2. WHEN multiple PUT requests for the same object occur THEN the system SHALL handle each transition independently
3. WHEN a PUT overwrites an existing cached object THEN the system SHALL invalidate old range cache data before transition
4. WHEN transition is in progress and another PUT arrives THEN the system SHALL not interfere with the ongoing transition
5. WHEN range cache already exists for an object THEN the system SHALL overwrite it with new PUT data

### Requirement 6

**User Story:** As a system tracking cache metrics, I want write cache transitions to update cache statistics, so that monitoring reflects actual cache usage.

#### Acceptance Criteria

1. WHEN write cache transitions to range cache THEN the system SHALL update cache size statistics
2. WHEN transition completes THEN the system SHALL record the transition in metrics
3. WHEN transition fails THEN the system SHALL record the failure in metrics
4. WHEN write cache is deleted THEN the system SHALL decrement write cache size statistics
5. WHEN range cache is created THEN the system SHALL increment range cache size statistics
