# Requirements Document

## Introduction

This document specifies the requirements for the Bucket-Level Cache Settings feature, which allows per-bucket configuration overrides stored as optional JSON files within each bucket's metadata folder. This enables fine-grained control over caching behavior without modifying the global YAML configuration, supporting use cases where different buckets have different caching requirements (e.g., static assets vs. frequently-updated data).

## Glossary

- **Proxy**: The S3 caching proxy server that handles HTTP requests
- **Cache_Manager**: The component responsible for storing and retrieving cached S3 data
- **Bucket_Settings**: A JSON configuration file stored at `cache_dir/metadata/{bucket}/_settings.json`
- **Global_Config**: The main YAML configuration file loaded at proxy startup
- **Settings_Cascade**: The precedence order for configuration: Global_Config → Bucket_Settings → Prefix_Settings
- **Prefix_Settings**: Optional per-prefix overrides within a Bucket_Settings file
- **Hot_Reload**: The ability to apply configuration changes without restarting the proxy

## Design Decisions

### Per-Bucket Cache Size Limits (Excluded)

Per-bucket `max_cache_size` quotas were considered and intentionally excluded from this spec. The feature requires per-bucket size tracking, which introduces significant complexity in multi-instance deployments:

- The global size tracker (`SizeAccumulator`) works across instances by flushing deltas to shared-storage delta files, which the consolidating instance collects and sums into `size_state.json`. Per-bucket tracking would need the same shared-storage coordination — either per-bucket delta files or per-bucket fields in existing delta files.
- An in-memory-only tracker (no persistence) breaks multi-instance correctness: instance A writes data to bucket X, but instance B (which wins the consolidation lock) has no visibility into bucket X's size and cannot enforce its quota.
- Additional complexity: stampede dedup coordination, two distinct subtract call sites that must stay in sync, bucket-scoped eviction filtering, and initialization scan changes.

Global eviction (LRU/TinyLFU) handles space management adequately — infrequently accessed bucket data is naturally evicted first. Per-bucket quotas can be added as a follow-up spec if a concrete need arises.

## Requirements

### Requirement 1: Settings File Location and Format

**User Story:** As an operator, I want to place a JSON configuration file for each bucket, so that I can configure caching behavior per-bucket without modifying the global config.

#### Acceptance Criteria

1. THE Proxy SHALL look for bucket settings at `cache_dir/metadata/{bucket}/_settings.json`
2. WHEN a Bucket_Settings file exists and contains valid JSON, THE Proxy SHALL parse and apply the settings
3. WHEN a Bucket_Settings file does not exist, THE Proxy SHALL use Global_Config values for that bucket
4. WHEN a Bucket_Settings file contains invalid JSON, THE Proxy SHALL log an error and use Global_Config values for that bucket
5. THE Proxy SHALL support the following fields in Bucket_Settings: `get_ttl`, `head_ttl`, `put_ttl`, `read_cache_enabled`, `write_cache_enabled`, `compression_enabled`, `ram_cache_eligible`, and `prefix_overrides`

### Requirement 2: TTL Override Settings

**User Story:** As an operator, I want to configure different TTL values per bucket, so that frequently-updated buckets can have shorter cache lifetimes than static asset buckets.

#### Acceptance Criteria

1. WHEN a Bucket_Settings file specifies `get_ttl`, THE Proxy SHALL use that value instead of Global_Config `get_ttl` for objects in that bucket
2. WHEN a Bucket_Settings file specifies `head_ttl`, THE Proxy SHALL use that value instead of Global_Config `head_ttl` for objects in that bucket
3. WHEN a Bucket_Settings file specifies `put_ttl`, THE Proxy SHALL use that value instead of Global_Config `put_ttl` for objects in that bucket
4. WHEN a Bucket_Settings file omits a TTL field, THE Proxy SHALL use the Global_Config value for that TTL type
5. THE Proxy SHALL accept TTL values in human-readable format (e.g., "0s", "30s", "5m", "1h", "7d")
6. WHEN `get_ttl` is set to "0s" for a bucket or prefix, THE Proxy SHALL cache GET responses but treat them as immediately expired — every subsequent request triggers conditional revalidation with S3 (If-Modified-Since / If-None-Match)
7. WHEN `get_ttl` is "0s" and S3 returns 304 Not Modified during revalidation, THE Proxy SHALL serve the cached data without re-downloading (saving data transfer)
8. WHEN `get_ttl` is "0s", THE Proxy SHALL NOT store range data in RAM cache for matching objects (RAM cache serves stale data without revalidation)
9. WHEN `head_ttl` is set to "0s", THE Proxy SHALL cache HEAD responses but revalidate with S3 on every request

### Requirement 3: Read Cache Control

**User Story:** As an operator, I want to enable or disable read caching per bucket or prefix, so that I can skip disk caching for data that should always be fetched fresh from S3 (e.g., rapidly-changing metadata prefixes).

#### Acceptance Criteria

1. WHEN a Bucket_Settings file specifies `read_cache_enabled: false`, THE Proxy SHALL NOT cache GET responses on disk for objects in that bucket
2. WHEN a Bucket_Settings file specifies `read_cache_enabled: true`, THE Proxy SHALL cache GET responses on disk for objects in that bucket
3. WHEN a Bucket_Settings file omits `read_cache_enabled`, THE Proxy SHALL use the Global_Config `read_cache_enabled` value (default: `true`)
4. WHEN read caching is disabled for a bucket or prefix, THE Proxy SHALL still forward GET requests to S3 and stream responses to the client
5. WHEN read caching is disabled, THE Proxy SHALL NOT store range data in RAM cache for matching objects
6. WHEN read caching is disabled, THE Proxy SHALL NOT store metadata in the RAM metadata cache for matching objects
7. WHEN read caching is disabled, THE Proxy SHALL still allow write caching for PUT operations (if `write_cache_enabled` is true)

### Requirement 4: Write Cache Control

**User Story:** As an operator, I want to enable or disable write caching per bucket, so that I can optimize for different workloads (e.g., disable write cache for buckets with large objects that are rarely re-read).

#### Acceptance Criteria

1. WHEN a Bucket_Settings file specifies `write_cache_enabled: false`, THE Proxy SHALL skip write caching for PUT operations to that bucket
2. WHEN a Bucket_Settings file specifies `write_cache_enabled: true`, THE Proxy SHALL enable write caching for PUT operations to that bucket
3. WHEN a Bucket_Settings file omits `write_cache_enabled`, THE Proxy SHALL use the Global_Config `write_cache_enabled` value
4. WHEN write caching is disabled for a bucket, THE Proxy SHALL still forward PUT requests to S3 successfully

### Requirement 5: Compression Settings

**User Story:** As an operator, I want to control compression per bucket, so that I can disable compression for buckets containing already-compressed data (e.g., images, videos).

#### Acceptance Criteria

1. WHEN a Bucket_Settings file specifies `compression_enabled: false`, THE Proxy SHALL store cached data uncompressed for that bucket
2. WHEN a Bucket_Settings file specifies `compression_enabled: true`, THE Proxy SHALL apply compression to cached data for that bucket
3. WHEN a Bucket_Settings file omits `compression_enabled`, THE Proxy SHALL use the Global_Config compression setting

### Requirement 6: RAM Cache Eligibility and Invalidation

**User Story:** As an operator, I want to control which buckets can use RAM cache, so that I can reserve RAM cache for high-priority, frequently-accessed buckets and ensure stale data is not served after overwrites.

#### Acceptance Criteria

1. WHEN a Bucket_Settings file specifies `ram_cache_eligible: false`, THE Proxy SHALL not store data from that bucket in RAM cache
2. WHEN a Bucket_Settings file specifies `ram_cache_eligible: true`, THE Proxy SHALL allow data from that bucket to be stored in RAM cache
3. WHEN a Bucket_Settings file omits `ram_cache_eligible`, THE Proxy SHALL default to `true` (eligible for RAM cache)
4. WHEN RAM cache is disabled for a bucket, THE Proxy SHALL still serve requests from disk cache
5. WHEN `get_ttl` is "0s" for a bucket or prefix, THE Proxy SHALL NOT store range data in RAM cache for matching objects (RAM cache bypasses revalidation and would serve stale data)
6. WHEN `get_ttl` is "0s", THE Proxy SHALL still store metadata in the RAM metadata cache (metadata cache has its own refresh interval and is used for revalidation decisions)
7. WHEN a PUT overwrites an object, THE Proxy SHALL invalidate all RAM cache entries for that cache key, including all range data entries (prefix-based invalidation of `{cache_key}:range:*`)
8. WHEN a PUT overwrites an object, THE Proxy SHALL invalidate the RAM metadata cache entry for that cache key so subsequent requests read fresh metadata from disk
9. WHEN a PUT overwrites an object on one proxy instance, other instances SHALL serve fresh data after their RAM metadata cache refresh interval expires (default 5 seconds)

### Requirement 7: Prefix-Level Overrides

**User Story:** As an operator, I want to configure different settings for different prefixes within a bucket, so that I can have fine-grained control (e.g., `/temp/` with short TTL, `/static/` with long TTL).

#### Acceptance Criteria

1. THE Proxy SHALL support a `prefix_overrides` array in Bucket_Settings containing prefix-specific configurations
2. WHEN a request path matches a prefix in `prefix_overrides`, THE Proxy SHALL use the prefix settings instead of bucket-level settings
3. WHEN multiple prefixes match a request path, THE Proxy SHALL use the longest (most specific) matching prefix
4. WHEN no prefix matches, THE Proxy SHALL use the bucket-level settings
5. THE Proxy SHALL support the same fields in prefix overrides as in bucket settings: `get_ttl`, `head_ttl`, `put_ttl`, `read_cache_enabled`, `write_cache_enabled`, `compression_enabled`, `ram_cache_eligible`
6. WHEN a prefix override sets `get_ttl` to "0s", THE Proxy SHALL cache data on disk but revalidate with S3 on every request, and SHALL NOT store range data in RAM cache for matching objects

### Requirement 8: Settings Cascade and Precedence

**User Story:** As an operator, I want a clear precedence order for settings, so that I can predict which configuration will be applied.

#### Acceptance Criteria

1. THE Proxy SHALL apply settings in this precedence order (highest to lowest): Prefix_Settings → Bucket_Settings → Global_Config
2. WHEN a setting is not specified at a higher precedence level, THE Proxy SHALL fall back to the next lower level
3. THE Proxy SHALL log which settings source is being used when debug logging is enabled

### Requirement 9: Lazy Reload of Settings

**User Story:** As an operator, I want settings changes to take effect without restarting the proxy, so that I can adjust caching behavior dynamically.

#### Acceptance Criteria

1. THE Proxy SHALL cache loaded Bucket_Settings in RAM with a timestamp of when they were loaded
2. WHEN a request arrives for a bucket AND the cached settings are older than the configured staleness threshold (default 60 seconds), THE Proxy SHALL re-read the Bucket_Settings file from disk
3. WHEN a request arrives for a bucket AND the cached settings are fresher than the staleness threshold, THE Proxy SHALL use the cached settings without disk I/O
4. WHEN a Bucket_Settings file is modified on disk, THE Proxy SHALL apply the changes on the next request after the staleness threshold expires
5. THE Proxy SHALL support a configuration option `cache.bucket_settings_staleness_threshold` to control how long cached settings are considered fresh (default: 60 seconds)
6. IF a Bucket_Settings file becomes invalid after a reload, THEN THE Proxy SHALL log an error and continue using the previously valid settings
7. WHEN a Bucket_Settings file is successfully reloaded with changes, THE Proxy SHALL log the event at info level

### Requirement 10: Settings Validation

**User Story:** As an operator, I want the proxy to validate bucket settings, so that configuration errors are caught early.

#### Acceptance Criteria

1. WHEN a Bucket_Settings file is loaded, THE Proxy SHALL validate all field values
2. IF a TTL value is negative, THEN THE Proxy SHALL reject the settings and log an error
3. IF a TTL value is zero, THE Proxy SHALL treat it as "no caching" for that TTL type (valid setting)
4. IF a `prefix_overrides` entry has an empty or invalid prefix, THEN THE Proxy SHALL reject that entry and log a warning
5. WHEN validation fails, THE Proxy SHALL use Global_Config values and log which fields were invalid

### Requirement 11: Metrics and Observability

**User Story:** As an operator, I want to monitor per-bucket cache behavior, so that I can verify settings are applied correctly and tune them.

#### Acceptance Criteria

1. THE Proxy SHALL expose per-bucket cache metrics: `bucket_cache_hit_count`, `bucket_cache_miss_count` (only for buckets with `_settings.json`)
2. THE Proxy SHALL include bucket name as a label/dimension in per-bucket metrics
3. THE Proxy SHALL log resolved settings source (Global/Bucket/Prefix) at debug level for each request

### Requirement 12: Settings File Schema

**User Story:** As an operator, I want a well-documented JSON schema for bucket settings, so that I can create valid configuration files.

#### Acceptance Criteria

1. THE Proxy SHALL document the complete JSON schema for Bucket_Settings files
2. THE Proxy SHALL provide example Bucket_Settings files in documentation
3. THE Proxy SHALL support optional `$schema` field in Bucket_Settings for IDE validation support
