# Implementation Plan: Bucket-Level Cache Settings

## Overview

Implement per-bucket and per-prefix cache configuration via `_settings.json` files with lazy reload, settings cascade resolution, and integration into the existing cache manager. Remove the existing YAML `ttl_overrides` mechanism.

## Tasks

- [x] 1. Create `BucketSettings` data model and parsing
  - [x] 1.1 Create `src/bucket_settings.rs` with `BucketSettings`, `PrefixOverride`, `ResolvedSettings`, `GlobalDefaults`, and `SettingsSource` structs
    - Implement `Deserialize`/`Serialize` for `BucketSettings` and `PrefixOverride`
    - Add `deserialize_optional_duration` using existing `parse_duration` from `config.rs`
    - Add `$schema` field support (serde rename, skip_serializing_if)
    - Include `read_cache_enabled: Option<bool>` in both `BucketSettings` and `PrefixOverride`
    - _Requirements: 1.1, 1.2, 1.5, 2.5, 3.1, 3.2, 3.3, 7.1, 7.5, 12.3_

  - [x] 1.2 Write property test: BucketSettings round-trip serialization
    - **Property 1: BucketSettings round-trip serialization**
    - Generate arbitrary `BucketSettings` with random field combinations, serialize to JSON, deserialize back, assert equivalence
    - **Validates: Requirements 1.2, 1.5, 7.1, 7.5, 12.3**

  - [x] 1.3 Implement `validate()` function for `BucketSettings`
    - Reject negative TTL values (Duration parsing already handles this, but validate post-parse)
    - Reject empty or invalid prefixes in `prefix_overrides`
    - Return `Vec<String>` of validation errors
    - _Requirements: 10.1, 10.2, 10.3, 10.4_

  - [x] 1.4 Write property test: Validation rejects invalid field values
    - **Property 8: Validation rejects invalid field values**
    - Generate `BucketSettings` with at least one invalid field, assert `validate()` returns non-empty errors
    - **Validates: Requirements 10.1, 10.2, 10.4**

- [x] 2. Implement `BucketSettingsManager` with cascade resolution
  - [x] 2.1 Create `BucketSettingsManager` struct with cache, staleness threshold, and global defaults
    - `RwLock<HashMap<String, CachedBucketSettings>>` for cached settings
    - `Mutex<HashMap<String, Arc<Mutex<()>>>>` for single-flight reload coordination
    - `extract_bucket(path)` to parse bucket name from cache key (split on first `/`)
    - _Requirements: 9.1, 9.5_

  - [x] 2.2 Implement `resolve()` method with full cascade logic
    - Check cache freshness against staleness threshold
    - Single-flight reload from disk when stale (only one thread reads, others wait)
    - Cascade: find longest matching prefix → bucket settings → global defaults
    - Enforce zero TTL → RAM cache ineligible override after cascade
    - Enforce read_cache_enabled=false → RAM cache ineligible override after cascade
    - Return `ResolvedSettings` with `SettingsSource` for debug logging
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.6, 2.8, 3.1, 3.2, 3.3, 3.5, 3.6, 4.1, 4.2, 4.3, 5.1, 5.2, 5.3, 6.1, 6.2, 6.3, 6.5, 7.2, 7.3, 7.4, 7.6, 8.1, 8.2, 8.3, 9.2, 9.3_

  - [x] 2.3 Implement error recovery in `resolve()`
    - On invalid JSON: log error, use previous valid settings or global defaults
    - On file not found: cache "no settings" marker with timestamp
    - On invalid fields after reload: log error, keep previous valid settings
    - _Requirements: 1.3, 1.4, 9.6, 10.5_

  - [x] 2.4 Write property test: Settings cascade resolution
    - **Property 2: Settings cascade resolution**
    - Generate arbitrary `(GlobalDefaults, BucketSettings, PrefixOverride, path)` tuples
    - Assert each field in resolved output matches the most specific level that defines it
    - **Validates: Requirements 2.1, 2.2, 2.3, 2.4, 3.1, 3.2, 3.3, 4.1, 4.2, 4.3, 5.1, 5.2, 5.3, 6.1, 6.2, 6.3, 7.2, 7.4, 8.1, 8.2**

  - [x] 2.5 Write property test: Zero TTL forces RAM cache ineligibility
    - **Property 3: Zero TTL forces RAM cache ineligibility**
    - Generate settings where `get_ttl` is zero at any level, assert `ram_cache_eligible` is false in resolved output
    - **Validates: Requirements 2.8, 6.5, 7.6**

  - [x] 2.6 Write property test: Read cache disabled forces RAM cache ineligibility
    - **Property 4: Read cache disabled forces RAM cache ineligibility**
    - Generate settings where `read_cache_enabled` is false at any level, assert `ram_cache_eligible` is false in resolved output
    - **Validates: Requirements 3.5, 3.6**

  - [x] 2.7 Write property test: Longest prefix match
    - **Property 6: Longest prefix match**
    - Generate overlapping prefixes, assert the longest matching prefix wins
    - **Validates: Requirements 7.3**

  - [x] 2.8 Write property test: Error recovery on invalid settings
    - **Property 5: Error recovery on invalid settings**
    - Load valid settings, then replace with invalid JSON, assert resolve returns previous valid settings
    - **Validates: Requirements 1.4, 9.6, 10.5**

  - [x] 2.9 Write property test: Staleness threshold triggers reload
    - **Property 7: Staleness threshold triggers reload**
    - Load settings, modify file on disk, advance past threshold, assert resolve returns updated values
    - **Validates: Requirements 9.2, 9.4**

- [x] 3. Checkpoint
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Remove `ttl_overrides` and integrate `BucketSettingsManager` into `CacheManager`
  - [x] 4.1 Remove `TtlOverride` struct and `ttl_overrides` field from `CacheConfig`
    - Remove `find_ttl_override` from `CacheManager`
    - Remove `ttl_overrides` field from `CacheManagerInner` / constructor
    - Update any tests that reference `ttl_overrides`
    - _Requirements: Risk 2 (design)_

  - [x] 4.2 Add `BucketSettingsManager` to `CacheManager`
    - Store as `Arc<BucketSettingsManager>` in `CacheManager`
    - Initialize from `CacheConfig` global defaults and `bucket_settings_staleness_threshold`
    - Add `bucket_settings_staleness_threshold` field to `CacheConfig` (default 60s)
    - Add `read_cache_enabled` field to `CacheConfig` (default true) — allows disabling read caching globally so only allowlisted buckets are cached
    - _Requirements: 3.3, 9.5_

  - [x] 4.3 Replace `get_effective_get_ttl`, `get_effective_head_ttl`, `get_effective_put_ttl`
    - Change signatures to `async fn` (resolve is async due to RwLock)
    - Call `self.bucket_settings_manager.resolve(bucket, path)` and return the appropriate TTL
    - Update all call sites in `http_proxy.rs`, `range_handler.rs`, `cache.rs`
    - _Requirements: 2.1, 2.2, 2.3, 2.4_

  - [x] 4.4 Integrate read cache control into GET request path
    - In `http_proxy.rs` GET handling, resolve settings before cache lookup
    - When `resolved.read_cache_enabled` is false, skip cache lookup and cache write — stream directly from S3
    - When `resolved.read_cache_enabled` is false, skip RAM cache promotion and metadata cache storage
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

  - [x] 4.5 Integrate RAM cache eligibility check into `promote_range_to_ram_cache`
    - Before promoting, resolve settings for the cache key's bucket/path
    - Skip promotion if `resolved.ram_cache_eligible` is false
    - _Requirements: 6.1, 6.5, 2.8_

  - [x] 4.6 Integrate write cache control into PUT handling
    - In `handle_put_request` and `store_put_as_write_cached_range`, resolve settings
    - Use `resolved.write_cache_enabled` instead of global `is_write_caching_enabled()`
    - Use `resolved.put_ttl` instead of global `put_ttl`
    - _Requirements: 4.1, 4.2, 4.3, 4.4_

  - [x] 4.7 Integrate compression control
    - In `compress_cache_entry` and `compress_range_data`, resolve settings for the cache key
    - Use `resolved.compression_enabled` instead of global compression config
    - _Requirements: 5.1, 5.2, 5.3_

- [x] 5. Checkpoint
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Per-bucket metrics and dashboard
  - [x] 6.1 Add per-bucket metrics to `MetricsManager`
    - `bucket_cache_hit_count`, `bucket_cache_miss_count` with bucket label
    - Only emit for buckets with `_settings.json`
    - Update hit/miss recording in `http_proxy.rs` to include bucket dimension
    - _Requirements: 11.1, 11.2_

  - [x] 6.2 Add `/api/bucket-stats` endpoint to dashboard
    - Return `BucketStatsResponse` with per-bucket hit/miss stats and resolved settings summary
    - Source bucket list from `BucketSettingsManager`
    - _Requirements: 11.1, 11.3_

  - [x] 6.3 Add bucket stats table to dashboard HTML/JS
    - Sortable table with columns: Bucket, Hits, Misses, Hit Rate, GET TTL, Read Cache, Write Cache, RAM Cache
    - Show top 20 by default with "Show all" toggle
    - Text filter for bucket name search
    - Expandable rows showing full resolved settings and prefix overrides
    - Only render when at least one bucket has custom settings
    - _Requirements: 11.1, 11.2_

- [x] 7. Zero TTL revalidation behavior
  - [x] 7.1 Implement zero TTL revalidation in GET request path
    - When `resolved.get_ttl` is zero, treat cached data as immediately expired
    - Send conditional request to S3 (If-Modified-Since / If-None-Match)
    - On 304: serve cached data (bandwidth savings)
    - On 200: update cache with new data
    - Applies to both GET-cached and write-cached data
    - _Requirements: 2.6, 2.7, 2.9_

  - [x] 7.2 Ensure zero TTL metadata cache behavior
    - Metadata cache continues to store entries for zero-TTL objects (metadata cache has its own refresh interval)
    - RAM range cache does NOT store entries for zero-TTL objects (handled by 4.5)
    - _Requirements: 6.6_

- [x] 8. Documentation, version bump, and dashboard rename
  - [x] 8.1 Create JSON schema file and example `_settings.json` files
    - Full schema with field descriptions, types, and valid ranges
    - Example: static assets bucket (long TTL, compression on)
    - Example: frequently-updated bucket (short TTL, no RAM cache)
    - Example: zero TTL authentication bucket (get_ttl=0s)
    - Example: no-cache prefix (read_cache_enabled=false)
    - Example: allowlist pattern (global read_cache_enabled=false, bucket override=true)
    - Example: bucket with prefix overrides
    - _Requirements: 12.1, 12.2, 12.3_

  - [x] 8.2 Update existing documentation
    - `docs/CONFIGURATION.md`: Add `cache.read_cache_enabled` and `cache.bucket_settings_staleness_threshold` global config fields, document `_settings.json` file format and location, document settings cascade (Prefix → Bucket → Global)
    - `docs/CACHING.md`: Document per-bucket/prefix cache control (read_cache_enabled, write_cache_enabled, ram_cache_eligible), zero TTL revalidation behavior, read cache disabled behavior
    - `docs/DASHBOARD.md`: Document new bucket stats table and `/api/bucket-stats` endpoint
    - `config/config.example.yaml`: Add `read_cache_enabled` and `bucket_settings_staleness_threshold` fields with comments
    - `README.md`: Add bucket-level cache settings to feature list

  - [x] 8.3 Rename dashboard title to "S3 Hybrid Cache"
    - Update `<title>` and `<h1>` in `src/dashboard.rs` HTML template
    - Update dashboard module doc comment
    - Update `tests/dashboard_integration_test.rs` and `tests/dashboard_property_test.rs` assertions

  - [x] 8.4 Version bump to 1.5.0
    - Update `Cargo.toml` version from 1.4.5 to 1.5.0
    - Add CHANGELOG.md entry for v1.5.0 with bucket-level cache settings summary
    - `git add Cargo.toml CHANGELOG.md && git commit -m "v1.5.0: Bucket-level cache settings"`

- [x] 9. Final checkpoint
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
- The existing `ttl_overrides` YAML mechanism is removed entirely (not deprecated)
- Per-bucket cache size limits (`max_cache_size`) are intentionally excluded — multi-instance size tracking requires shared-storage coordination that adds significant complexity for limited value. Global eviction handles space management.
