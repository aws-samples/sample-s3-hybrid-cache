# Design Document: Bucket-Level Cache Settings

## Overview

This feature adds per-bucket and per-prefix cache configuration via JSON files stored at `cache_dir/metadata/{bucket}/_settings.json`. It introduces a settings cascade (Prefix → Bucket → Global) that replaces the existing YAML-based `ttl_overrides` mechanism with a more flexible, hot-reloadable system.

The design integrates into the existing `CacheManager` by adding a `BucketSettingsManager` that lazily loads, caches, and resolves settings. All existing cache operations (GET/HEAD/PUT TTL lookup, RAM cache promotion, read/write cache decisions, compression) are modified to consult resolved settings instead of global config directly.

## Architecture

```mermaid
graph TD
    subgraph "Request Path"
        A[HTTP Request] --> B[http_proxy.rs]
        B --> C[CacheManager]
    end

    subgraph "Settings Resolution"
        C --> D[BucketSettingsManager]
        D --> E{Cached & Fresh?}
        E -->|Yes| F[Return Cached Settings]
        E -->|No| G[Read _settings.json from disk]
        G --> H[Parse & Validate]
        H -->|Valid| I[Cache in RAM with timestamp]
        H -->|Invalid| J[Log error, use previous/global]
        I --> K[Resolve: Prefix → Bucket → Global]
        F --> K
        J --> K
        K --> L[ResolvedSettings]
    end

    subgraph "Consumers"
        L --> M[TTL Lookup]
        L --> N[RAM Cache Eligibility]
        L --> O[Read Cache Decision]
        L --> P[Write Cache Decision]
        L --> Q[Compression Decision]
    end
```

The `BucketSettingsManager` sits between the request path and the `CacheManager`'s operational decisions. It is a shared, thread-safe component (`Arc<BucketSettingsManager>`) that all request handlers access.

## Components and Interfaces

### BucketSettings (Data Model)

```rust
/// Per-bucket settings loaded from _settings.json
/// All fields are optional — omitted fields fall back to global config.
#[derive(Debug, Clone, Deserialize, Serialize, Default)]
pub struct BucketSettings {
    /// Optional JSON schema reference for IDE validation
    #[serde(rename = "$schema", skip_serializing_if = "Option::is_none")]
    pub schema: Option<String>,

    /// GET response TTL override (e.g., "0s", "30s", "5m", "1h", "7d")
    #[serde(default, deserialize_with = "deserialize_optional_duration")]
    pub get_ttl: Option<Duration>,

    /// HEAD response TTL override
    #[serde(default, deserialize_with = "deserialize_optional_duration")]
    pub head_ttl: Option<Duration>,

    /// PUT write-cache TTL override
    #[serde(default, deserialize_with = "deserialize_optional_duration")]
    pub put_ttl: Option<Duration>,

    /// Enable/disable read caching for GET responses
    pub read_cache_enabled: Option<bool>,

    /// Enable/disable write-through caching for PUT operations
    pub write_cache_enabled: Option<bool>,

    /// Enable/disable LZ4 compression for cached data
    pub compression_enabled: Option<bool>,

    /// Whether range data from this bucket can be stored in RAM cache
    pub ram_cache_eligible: Option<bool>,

    /// Per-prefix overrides within this bucket
    #[serde(default)]
    pub prefix_overrides: Vec<PrefixOverride>,
}
```

### PrefixOverride (Data Model)

```rust
/// Per-prefix settings override within a bucket
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct PrefixOverride {
    /// Prefix path (e.g., "/temp/", "/static/assets/")
    pub prefix: String,

    #[serde(default, deserialize_with = "deserialize_optional_duration")]
    pub get_ttl: Option<Duration>,

    #[serde(default, deserialize_with = "deserialize_optional_duration")]
    pub head_ttl: Option<Duration>,

    #[serde(default, deserialize_with = "deserialize_optional_duration")]
    pub put_ttl: Option<Duration>,

    pub read_cache_enabled: Option<bool>,
    pub write_cache_enabled: Option<bool>,
    pub compression_enabled: Option<bool>,
    pub ram_cache_eligible: Option<bool>,
}
```

### ResolvedSettings (Data Model)

```rust
/// Fully resolved settings for a specific bucket+path combination.
/// Every field has a concrete value (no Options) after cascade resolution.
#[derive(Debug, Clone)]
pub struct ResolvedSettings {
    pub get_ttl: Duration,
    pub head_ttl: Duration,
    pub put_ttl: Duration,
    pub read_cache_enabled: bool,
    pub write_cache_enabled: bool,
    pub compression_enabled: bool,
    pub ram_cache_eligible: bool,
    /// Source of each setting for debug logging
    pub source: SettingsSource,
}

#[derive(Debug, Clone)]
pub enum SettingsSource {
    Global,
    Bucket(String),
    Prefix(String, String),  // (bucket, prefix)
}
```

### BucketSettingsManager

```rust
/// Thread-safe manager for loading, caching, and resolving bucket settings.
/// Lazily loads settings from disk on first access, then caches with staleness threshold.
pub struct BucketSettingsManager {
    cache_dir: PathBuf,
    /// Cached settings per bucket: bucket_name -> (BucketSettings, loaded_at)
    cache: RwLock<HashMap<String, CachedBucketSettings>>,
    /// Staleness threshold — settings older than this trigger a re-read from disk
    staleness_threshold: Duration,
    /// Global config values used as fallback
    global_config: GlobalDefaults,
}

struct CachedBucketSettings {
    settings: BucketSettings,
    loaded_at: Instant,
    /// Previous valid settings, kept as fallback if reload produces invalid JSON
    previous_valid: Option<BucketSettings>,
}

/// Global config defaults extracted from CacheConfig at startup
#[derive(Debug, Clone)]
pub struct GlobalDefaults {
    pub get_ttl: Duration,
    pub head_ttl: Duration,
    pub put_ttl: Duration,
    pub read_cache_enabled: bool,
    pub write_cache_enabled: bool,
    pub compression_enabled: bool,
    pub ram_cache_enabled: bool,
}
```

### BucketSettingsManager Methods

```rust
impl BucketSettingsManager {
    /// Create a new manager with global defaults and staleness threshold.
    pub fn new(
        cache_dir: PathBuf,
        global_config: GlobalDefaults,
        staleness_threshold: Duration,
    ) -> Self;

    /// Resolve settings for a given bucket and object path.
    /// Handles the full cascade: Prefix → Bucket → Global.
    /// Lazily loads/reloads settings from disk as needed.
    pub async fn resolve(&self, bucket: &str, path: &str) -> ResolvedSettings;

    /// Extract bucket name from a cache key or request path.
    /// Cache keys have the form "/{bucket}/{key}" or "{bucket}/{key}".
    pub fn extract_bucket(path: &str) -> Option<&str>;

    /// Force reload settings for a specific bucket (used in tests).
    pub async fn reload(&self, bucket: &str) -> Result<()>;

    /// Validate a BucketSettings struct. Returns list of validation errors.
    pub fn validate(settings: &BucketSettings) -> Vec<String>;
}
```

### Integration Points

The `BucketSettingsManager` is stored as `Arc<BucketSettingsManager>` in `CacheManager` (or `CacheManagerInner`). The following existing methods are modified to use resolved settings:

| Existing Method | Change |
|---|---|
| `get_effective_get_ttl(path)` | Call `settings_manager.resolve(bucket, path).get_ttl` instead of `find_ttl_override` |
| `get_effective_head_ttl(path)` | Same pattern for `head_ttl` |
| `get_effective_put_ttl(path)` | Same pattern for `put_ttl` |
| `promote_range_to_ram_cache(...)` | Check `resolved.ram_cache_eligible`, `resolved.read_cache_enabled`, and `resolved.get_ttl.is_zero()` before promoting |
| `store_range(...)` / cache write path | Check `resolved.read_cache_enabled` before caching GET response data |
| `is_write_caching_enabled()` | Add path-aware variant that checks `resolved.write_cache_enabled` |
| `compress_cache_entry(...)` | Check `resolved.compression_enabled` before compressing |
| `store_put_as_write_cached_range(...)` | Use resolved `put_ttl` and `write_cache_enabled` |

### Settings File Path Convention

Settings files live at: `{cache_dir}/metadata/{bucket}/_settings.json`

The `metadata/{bucket}/` directory already exists in the current architecture (it holds `NewCacheMetadata` JSON files for cached objects). The `_settings.json` filename uses a leading underscore to avoid collision with S3 object keys (S3 keys starting with `_` are valid but the proxy controls this namespace within its metadata directory).


## Data Models

### _settings.json Example

```json
{
  "$schema": "https://example.com/bucket-settings-schema.json",
  "get_ttl": "5m",
  "head_ttl": "30s",
  "put_ttl": "1h",
  "read_cache_enabled": true,
  "write_cache_enabled": true,
  "compression_enabled": false,
  "ram_cache_eligible": true,
  "prefix_overrides": [
    {
      "prefix": "/temp/",
      "get_ttl": "0s",
      "ram_cache_eligible": false
    },
    {
      "prefix": "/volatile/",
      "read_cache_enabled": false
    },
    {
      "prefix": "/static/assets/",
      "get_ttl": "7d",
      "compression_enabled": true
    }
  ]
}
```

### Settings Cascade Resolution

Resolution follows a three-level cascade for each field independently:

```
For each setting field:
  1. Check matching PrefixOverride (longest prefix match)
  2. If not set at prefix level, check BucketSettings
  3. If not set at bucket level, use GlobalDefaults
```

### Duration Parsing

Reuse the existing `parse_duration` function from `src/config.rs` which already supports: `"0s"`, `"30s"`, `"5m"`, `"1h"`, `"7d"`, `"100ms"`.

### Validation Rules

| Field | Valid Range | On Invalid |
|---|---|---|
| `get_ttl` | >= 0s | Reject settings, log error, use fallback |
| `head_ttl` | >= 0s | Reject settings, log error, use fallback |
| `put_ttl` | >= 0s | Reject settings, log error, use fallback |
| `prefix_overrides[].prefix` | Non-empty, starts with "/" | Skip invalid entry, log warning |
| `read_cache_enabled` | bool | Standard JSON parsing |
| `write_cache_enabled` | bool | Standard JSON parsing |
| `compression_enabled` | bool | Standard JSON parsing |
| `ram_cache_eligible` | bool | Standard JSON parsing |

When validation fails for the entire file, the manager falls back to the previously loaded valid settings for that bucket. If no previous valid settings exist, it falls back to global config.

### Read Cache Disabled Behavior

When `read_cache_enabled` is `false` (at bucket or prefix level), the proxy skips all caching for GET responses:

- GET response data is NOT written to disk cache
- Range data is NOT promoted to RAM cache
- Metadata is NOT stored in the RAM metadata cache
- The request is forwarded to S3 and streamed directly to the client
- Write caching for PUT operations is independent — `write_cache_enabled` controls that separately

This is enforced in the GET request path in `http_proxy.rs`. When `resolved.read_cache_enabled` is false, the proxy bypasses the cache lookup and cache-write paths entirely, behaving as a pure pass-through for that bucket/prefix.

After cascade resolution, `read_cache_enabled: false` also forces:
```rust
if !resolved.read_cache_enabled {
    resolved.ram_cache_eligible = false;
}
```

### Zero TTL + RAM Cache Exclusion Logic

When `get_ttl` is `"0s"` (either at bucket or prefix level), the resolved settings set `ram_cache_eligible = false` for that scope, regardless of the explicit `ram_cache_eligible` setting. This is because RAM cache serves data without revalidation, which would bypass the zero-TTL "always revalidate" semantics.

This is enforced during cascade resolution in `BucketSettingsManager::resolve()`:

```rust
// After cascade resolution:
if resolved.get_ttl == Duration::ZERO {
    resolved.ram_cache_eligible = false;
}
if !resolved.read_cache_enabled {
    resolved.ram_cache_eligible = false;
}
```

### Lazy Reload Mechanism

```mermaid
sequenceDiagram
    participant R as Request Handler
    participant BSM as BucketSettingsManager
    participant Disk as _settings.json

    R->>BSM: resolve("my-bucket", "/path/to/key")
    BSM->>BSM: Check cache for "my-bucket"
    alt Not cached or stale (age > threshold)
        BSM->>Disk: Read _settings.json
        alt Valid JSON
            BSM->>BSM: Validate fields
            alt Validation passes
                BSM->>BSM: Store in cache with timestamp
            else Validation fails
                BSM->>BSM: Log error, keep previous valid
            end
        else File not found
            BSM->>BSM: Cache "no settings" with timestamp
        else Invalid JSON
            BSM->>BSM: Log error, keep previous valid
        end
    end
    BSM->>BSM: Cascade: Prefix → Bucket → Global
    BSM-->>R: ResolvedSettings
```

The staleness check uses `Instant::now()` vs `loaded_at` to avoid system clock issues. The default staleness threshold is 60 seconds, configurable via `cache.bucket_settings_staleness_threshold` in the global YAML config.

When a bucket has no `_settings.json` file, the manager caches a "no settings" marker with a timestamp. This avoids repeated disk reads for buckets without custom settings. The marker is still subject to the staleness threshold, so a newly created settings file will be picked up within the threshold window.

### Metrics

Per-bucket metrics are only emitted for buckets that have a `_settings.json` file. Buckets using global defaults produce no per-bucket metrics (they are covered by existing aggregate metrics). This limits label cardinality — if 500 buckets exist but only 5 have custom settings, only 5 sets of per-bucket metrics are emitted.

Per-bucket metrics use the bucket name as a label dimension:

| Metric | Type | Condition | Description |
|---|---|---|---|
| `bucket_cache_hit_count` | Counter | Has `_settings.json` | Cache hits for this bucket |
| `bucket_cache_miss_count` | Counter | Has `_settings.json` | Cache misses for this bucket |

These are exposed through the existing metrics infrastructure (`src/metrics.rs`) and OTLP export.


## Correctness Properties

### Property 1: BucketSettings round-trip serialization

*For any* valid `BucketSettings` struct (with arbitrary valid field values, including prefix overrides), serializing to JSON and then deserializing back should produce an equivalent struct.

**Validates: Requirements 1.2, 1.5, 7.1, 7.5, 12.3**

### Property 2: Settings cascade resolution

*For any* combination of `GlobalDefaults`, `BucketSettings`, and `PrefixOverride` values, and *for any* request path, the `resolve()` function should return:
- The prefix-level value when the path matches a prefix and that prefix specifies the field
- The bucket-level value when no matching prefix specifies the field but the bucket does
- The global-level value when neither prefix nor bucket specifies the field

This must hold independently for each field (`get_ttl`, `head_ttl`, `put_ttl`, `read_cache_enabled`, `write_cache_enabled`, `compression_enabled`, `ram_cache_eligible`).

**Validates: Requirements 2.1, 2.2, 2.3, 2.4, 3.1, 3.2, 3.3, 4.1, 4.2, 4.3, 5.1, 5.2, 5.3, 6.1, 6.2, 6.3, 7.2, 7.4, 8.1, 8.2**

### Property 3: Zero TTL forces RAM cache ineligibility

*For any* resolved settings where `get_ttl` is zero (whether set at bucket level or prefix level), `ram_cache_eligible` in the resolved output must be `false`, regardless of the explicit `ram_cache_eligible` setting at any level.

**Validates: Requirements 2.8, 6.5, 7.6**

### Property 4: Read cache disabled forces RAM cache ineligibility

*For any* resolved settings where `read_cache_enabled` is false (whether set at bucket level or prefix level), `ram_cache_eligible` in the resolved output must be `false`, regardless of the explicit `ram_cache_eligible` setting at any level.

**Validates: Requirements 3.5, 3.6**

### Property 5: Error recovery on invalid settings

*For any* previously valid `BucketSettings` cached for a bucket, if the settings file is replaced with invalid JSON (or JSON with invalid field values), the `resolve()` function should return settings equivalent to the previously valid settings (not global defaults, and not the invalid values).

When no previous valid settings exist, `resolve()` should return global defaults.

**Validates: Requirements 1.4, 9.6, 10.5**

### Property 6: Longest prefix match

*For any* set of prefix overrides where multiple prefixes match a given path, the `resolve()` function should use the settings from the longest (most specific) matching prefix. Specifically: if prefix A is a proper prefix of prefix B, and both match the path, then B's settings should take precedence.

**Validates: Requirements 7.3**

### Property 7: Staleness threshold triggers reload

*For any* bucket with cached settings, if the settings file is modified on disk and the staleness threshold has elapsed since the last load, the next `resolve()` call should return settings reflecting the updated file contents.

**Validates: Requirements 9.2, 9.4**

### Property 8: Validation rejects invalid field values

*For any* `BucketSettings` struct containing at least one invalid field value (negative TTL, empty prefix in prefix_overrides), the `validate()` function should return a non-empty list of errors.

**Validates: Requirements 10.1, 10.2, 10.4**

### Dashboard Integration

The existing dashboard (`src/dashboard.rs`) gains a per-bucket summary table below the aggregate stats. This table is only rendered when at least one bucket has a `_settings.json` file.

**API endpoint**: `GET /api/bucket-stats`

```rust
#[derive(Serialize)]
pub struct BucketStatsResponse {
    pub buckets: Vec<BucketStatsEntry>,
}

#[derive(Serialize)]
pub struct BucketStatsEntry {
    pub bucket: String,
    pub hit_count: u64,
    pub miss_count: u64,
    pub hit_rate: f64,
    pub settings: ResolvedSettingsSummary,
}

#[derive(Serialize)]
pub struct ResolvedSettingsSummary {
    pub get_ttl: String,
    pub head_ttl: String,
    pub put_ttl: String,
    pub read_cache_enabled: bool,
    pub write_cache_enabled: bool,
    pub compression_enabled: bool,
    pub ram_cache_eligible: bool,
    pub prefix_override_count: usize,
}
```

**Dashboard UI**: A table with columns: Bucket, Hits, Misses, Hit Rate, GET TTL, Read Cache, Write Cache, RAM Cache. All columns are sortable. Default sort: hit count descending.

Shows top 20 buckets by default. A "Show all N buckets" link expands the full list. A text filter above the table allows filtering by bucket name substring (client-side).

Clicking a row expands to show the full resolved settings and prefix overrides for that bucket.

The bucket list is sourced from `BucketSettingsManager`'s cache — no extra disk scanning.

## Risks and Design Decisions

### Risk 1: Concurrent reload thundering herd

When the staleness threshold expires, multiple concurrent requests for the same bucket could all attempt to reload from disk simultaneously. The design uses a single-flight pattern (similar to `metadata_cache.rs`'s `get_or_load` with pending locks): only one thread performs the disk read, others wait on a per-bucket `Mutex`. This avoids redundant I/O and ensures consistent state.

```rust
struct CachedBucketSettings {
    settings: BucketSettings,
    loaded_at: Instant,
    previous_valid: Option<BucketSettings>,
}

// In BucketSettingsManager:
cache: RwLock<HashMap<String, CachedBucketSettings>>,
pending_loads: Mutex<HashMap<String, Arc<Mutex<()>>>>,  // single-flight coordination
```

### Risk 2: Removal of `ttl_overrides`

The existing YAML `ttl_overrides` in `CacheConfig` is removed entirely. The new `BucketSettings` system replaces it completely.

1. Remove the `ttl_overrides` field from `CacheConfig` and the `TtlOverride` struct
2. Remove `find_ttl_override` from `CacheManager`
3. Replace `get_effective_get_ttl`, `get_effective_head_ttl`, `get_effective_put_ttl` to use `BucketSettingsManager::resolve()` instead
4. If the YAML config still contains `ttl_overrides`, serde will ignore unknown fields (or we can add a startup warning)

### Risk 3: Zero TTL + write cache interaction

When `get_ttl` is "0s", the purpose is to ensure every request is authenticated by S3 (SigV4 validation). This means:

- Every GET request triggers a conditional request to S3 (If-Modified-Since / If-None-Match), regardless of how the data was cached
- Write-cached PUT data is still subject to revalidation on subsequent GET — the cache serves as a bandwidth optimization (304 saves re-download) but does not bypass authentication
- `put_ttl` controls how long the write-cached data is retained on disk, but does not exempt it from GET revalidation when `get_ttl=0`

**Decision**: When `get_ttl=0`, all GET requests revalidate with S3, including for write-cached objects. The `is_write_cached` flag does not override zero-TTL revalidation semantics.

### Risk 4: Partial file reads on shared storage

On EFS/NFS, an operator modifying `_settings.json` while a proxy instance reads it could produce a partial read. `std::fs::read_to_string` reads the entire file into memory atomically from the application's perspective. If the file is being written non-atomically, the read could get a truncated or mixed version.

**Mitigation**: The JSON parser will reject malformed content, triggering the error recovery path (use previous valid settings). Operators should use atomic write patterns (write to temp file, rename) for settings updates. This is documented in the schema documentation (Requirement 12).

### Risk 5: Read cache disabled + existing cached data

When `read_cache_enabled` is changed from `true` to `false` for a bucket/prefix, existing cached data for that scope remains on disk. The proxy does not proactively delete it. However:

- New GET requests bypass the cache entirely (no reads, no writes)
- Existing cached data is subject to normal TTL expiration and global eviction
- If `read_cache_enabled` is later re-enabled, stale cached data may be served until TTL expires

**Decision**: No proactive cache purge on settings change. This keeps the implementation simple and avoids expensive directory walks. Operators who need immediate purge can manually delete the cached data.

## Error Handling

| Scenario | Behavior |
|---|---|
| `_settings.json` not found | Cache "no settings" marker; use global defaults. No error logged. |
| `_settings.json` contains invalid JSON | Log error with bucket name and parse error. Use previous valid settings or global defaults. |
| `_settings.json` has valid JSON but invalid field values | Log error listing invalid fields. Use previous valid settings or global defaults. |
| `_settings.json` becomes invalid after previously being valid | Log error. Continue using the previously cached valid settings. |
| Disk I/O error reading `_settings.json` | Log warning. Use previous valid settings or global defaults. Retry on next staleness expiry. |
| `prefix_overrides` entry has empty/invalid prefix | Log warning for that entry. Skip the invalid entry but apply remaining valid entries. |

## Testing Strategy

### Property-Based Testing

Use the `quickcheck` crate (already a dev-dependency in this project) for property-based tests. Each property test runs a minimum of 100 iterations.

Generators needed:
- `ArbitraryBucketSettings`: Generates random `BucketSettings` with valid field values, random subsets of fields set to `Some`/`None`, and 0-5 prefix overrides
- `ArbitraryGlobalDefaults`: Generates random `GlobalDefaults` with valid durations and booleans
- `ArbitraryPrefixOverride`: Generates random prefix strings and optional field values
- `ArbitraryResolveInput`: Generates a `(GlobalDefaults, BucketSettings, path)` tuple for cascade testing

Each property test is tagged with: `Feature: bucket-level-cache-settings, Property N: {title}`

### Unit Tests

Unit tests cover specific examples and edge cases:
- Zero-length prefix matching
- Prefix with trailing slash vs without
- Empty `prefix_overrides` array
- All fields omitted (empty JSON `{}`)
- `$schema` field present and ignored during resolution
- Duration edge cases: "0s", "0ms", maximum values
- `read_cache_enabled: false` skips disk and RAM cache
- `read_cache_enabled: false` does not affect write caching
- Concurrent access to `BucketSettingsManager` (multiple resolve calls)
- File disappearing between staleness check and read

### Integration Tests

- End-to-end: create `_settings.json`, make requests, verify TTL/compression/RAM cache behavior matches settings
- Hot reload: modify `_settings.json` while proxy is running, verify new settings take effect after threshold
- Multi-bucket: configure different settings for different buckets, verify isolation
- Read cache disabled: verify GET requests bypass cache entirely when `read_cache_enabled: false`
