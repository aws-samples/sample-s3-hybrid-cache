# Requirements Document

## Introduction

This feature implements range-based disk cache eviction where each cached range is treated as an independent eviction candidate with equal weight. The system evicts individual ranges based on LRU/TinyLFU algorithms, and only removes the object metadata file when all ranges for that object have been evicted.

This spec covers capacity-based eviction (triggered when cache exceeds size limits), not TTL-based expiration. TTL expiration (controlled by `actively_remove_cached_data` config) is a separate mechanism that removes entries when they expire regardless of cache capacity.

## Glossary

- **Range**: A contiguous byte range of an S3 object stored as a `.bin` file in the cache
- **Object_Metadata**: A `.meta` file containing metadata about an object and its cached ranges
- **Eviction_Candidate**: A single range that can be independently selected for eviction
- **Cache_Manager**: The component responsible for cache operations including eviction
- **Disk_Cache_Manager**: The component managing disk-based cache storage
- **Access_Tracker**: Component tracking access statistics (last_accessed, access_count) for ranges

## Requirements

### Requirement 1: Range-Level Eviction Candidates

**User Story:** As a cache operator, I want each cached range to be an independent eviction candidate, so that frequently accessed ranges are retained even if other ranges of the same object are evicted.

#### Acceptance Criteria

1. WHEN collecting eviction candidates, THE Cache_Manager SHALL treat each range as an independent candidate regardless of how many ranges the object has
2. WHEN calculating eviction priority for LRU mode, THE Cache_Manager SHALL use each range's individual last_accessed timestamp
3. WHEN calculating eviction priority for TinyLFU mode, THE Cache_Manager SHALL use each range's individual access_count and last_accessed values
4. THE Cache_Manager SHALL NOT use aggregate object-level access statistics for eviction decisions
5. WHEN an object has multiple ranges, THE Cache_Manager SHALL allow evicting any subset of those ranges independently

### Requirement 2: Individual Range Eviction

**User Story:** As a cache operator, I want to evict individual ranges without affecting other ranges of the same object, so that cache space is freed incrementally.

#### Acceptance Criteria

1. WHEN evicting a single range, THE Disk_Cache_Manager SHALL delete only the corresponding `.bin` file
2. WHEN evicting a single range, THE Disk_Cache_Manager SHALL update the Object_Metadata to remove the evicted range from the ranges list
3. WHEN evicting a single range, THE Disk_Cache_Manager SHALL NOT delete other `.bin` files belonging to the same object
4. WHEN evicting a single range, THE Disk_Cache_Manager SHALL update the cache size tracker to reflect the freed space
5. IF the range `.bin` file deletion fails, THEN THE Disk_Cache_Manager SHALL log a warning and continue with metadata update

### Requirement 3: Metadata Cleanup on Full Object Eviction

**User Story:** As a cache operator, I want the object metadata file removed only when all ranges are evicted, so that partial cache entries remain usable.

#### Acceptance Criteria

1. WHEN all ranges of an object have been evicted, THE Disk_Cache_Manager SHALL delete the Object_Metadata file
2. WHEN at least one range remains cached, THE Disk_Cache_Manager SHALL preserve the Object_Metadata file
3. WHEN deleting the Object_Metadata file, THE Disk_Cache_Manager SHALL also delete any associated lock files
4. THE Disk_Cache_Manager SHALL verify the ranges list is empty before deleting the Object_Metadata file

### Requirement 4: Directory Cleanup

**User Story:** As a cache operator, I want empty cache directories cleaned up after eviction, so that the filesystem remains organized.

#### Acceptance Criteria

1. WHEN a range `.bin` file is deleted, THE Disk_Cache_Manager SHALL check if the parent directory is empty
2. WHEN a directory becomes empty after file deletion, THE Disk_Cache_Manager SHALL remove the empty directory
3. THE Disk_Cache_Manager SHALL recursively clean up empty parent directories up to the cache type root (objects/ or ranges/)
4. IF directory deletion fails, THEN THE Disk_Cache_Manager SHALL log a warning and continue without failing the eviction
5. THE Disk_Cache_Manager SHALL NOT delete the cache type root directories (objects/, ranges/)

### Requirement 5: Eviction Coordination

**User Story:** As a cache operator running multiple proxy instances, I want range eviction to be coordinated, so that concurrent evictions don't corrupt cache state.

#### Acceptance Criteria

1. WHEN evicting a range, THE Cache_Manager SHALL acquire a write lock on the object before modifying metadata
2. WHEN updating Object_Metadata after range eviction, THE Disk_Cache_Manager SHALL use atomic write operations (write to temp file, then rename)
3. WHEN the global eviction lock is held, THE Cache_Manager SHALL complete range evictions before releasing the lock
4. IF metadata update fails after range file deletion, THEN THE Disk_Cache_Manager SHALL log a warning (orphaned range will be cleaned up by validation scan)

### Requirement 6: Cache Size Tracking Integration

**User Story:** As a cache operator, I want accurate cache size tracking after range evictions, so that eviction triggers at the correct thresholds.

#### Acceptance Criteria

1. WHEN a range is evicted, THE Cache_Manager SHALL decrement the tracked cache size by the range's file size
2. WHEN the Object_Metadata file is deleted, THE Cache_Manager SHALL decrement the tracked cache size by the metadata file size
3. THE Cache_Manager SHALL update the size tracker before releasing eviction locks
4. WHEN calculating eviction target, THE Cache_Manager SHALL account for individual range sizes

### Requirement 7: Eviction Logging

**User Story:** As a cache operator, I want detailed logging of range evictions, so that I can monitor and debug cache behavior.

#### Acceptance Criteria

1. WHEN evicting a range, THE Cache_Manager SHALL log the cache_key, range start/end, and freed bytes
2. WHEN deleting an Object_Metadata file, THE Cache_Manager SHALL log the cache_key and reason (all ranges evicted)
3. WHEN cleaning up empty directories, THE Cache_Manager SHALL log the directory path at debug level
4. IF eviction fails, THEN THE Cache_Manager SHALL log the error with cache_key and failure reason
