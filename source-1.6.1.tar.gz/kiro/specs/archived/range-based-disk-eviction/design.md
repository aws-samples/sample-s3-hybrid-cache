# Design Document: Range-Based Disk Cache Eviction

## Overview

This design implements range-based disk cache eviction where each cached range is treated as an independent eviction candidate with equal weight. The key changes are:

1. Remove the arbitrary threshold (currently 3 ranges) that determines full-object vs granular eviction
2. Implement `evict_single_range()` to delete individual ranges and update metadata
3. Clean up metadata files only when all ranges are evicted
4. Recursively clean up empty directories after eviction

## Architecture

The eviction flow changes from object-level to range-level with batching for efficiency:

```
New Flow:
  collect_range_candidates() → sort by algorithm → group by object
                                                 → batch evict ranges per object
                                                 → batch cleanup directories
```

### Efficiency Considerations

For large-scale eviction (e.g., 10,000 ranges):

1. **Batch per object**: When multiple ranges from the same object are evicted, perform one metadata read-modify-write cycle instead of N cycles.

2. **Deferred directory cleanup**: Collect all deleted file paths during eviction, then batch cleanup empty directories at the end.

3. **Single lock per object**: Acquire lock once per object, evict all selected ranges, release lock.

```rust
// Efficient eviction flow
let candidates = collect_range_candidates();  // O(n) scan
sort_range_candidates(&mut candidates);       // O(n log n)

// Group by object for batching
let grouped = group_by_cache_key(candidates); // O(n)

let mut deleted_paths = Vec::new();
for (cache_key, ranges_to_evict) in grouped {
    // One lock, one metadata read, batch delete, one metadata write
    let paths = batch_evict_ranges(&cache_key, &ranges_to_evict)?;
    deleted_paths.extend(paths);
    
    if freed_bytes >= target { break; }
}

// Batch directory cleanup at end
batch_cleanup_directories(&deleted_paths);
```

## Components and Interfaces

### Modified: CacheManager

```rust
impl CacheManager {
    /// Collect all ranges as independent eviction candidates
    pub async fn collect_range_candidates_for_eviction(
        &self,
    ) -> Result<Vec<RangeEvictionCandidate>> {
        // Traverse all .meta files
        // For each range in metadata, create a separate candidate
        // Include range-specific last_accessed and access_count
    }

    /// Sort range candidates based on eviction algorithm
    fn sort_range_candidates(&self, candidates: &mut Vec<RangeEvictionCandidate>) {
        match self.eviction_algorithm {
            CacheEvictionAlgorithm::LRU => {
                candidates.sort_by_key(|c| c.last_accessed);
            }
            CacheEvictionAlgorithm::TinyLFU => {
                candidates.sort_by(|a, b| {
                    self.calculate_tinylfu_score(a).cmp(&self.calculate_tinylfu_score(b))
                });
            }
        }
    }

    /// Group sorted candidates by cache_key for batch processing
    /// Preserves eviction order within each group
    fn group_candidates_by_object(
        &self,
        candidates: Vec<RangeEvictionCandidate>,
        target_bytes: u64,
    ) -> Vec<(String, Vec<RangeEvictionCandidate>)> {
        // Take candidates until target_bytes reached
        // Group by cache_key while preserving priority order
    }

    /// Batch evict ranges from a single object
    /// One lock acquisition, one metadata read/write cycle
    pub async fn batch_evict_ranges(
        &self,
        cache_key: &str,
        ranges: &[RangeEvictionCandidate],
    ) -> Result<(u64, Vec<PathBuf>)> {
        // 1. Acquire write lock on object (once)
        // 2. Read metadata (once)
        // 3. Delete all range .bin files, collect paths
        // 4. Update metadata to remove all evicted ranges (once)
        // 5. If no ranges left, delete metadata file
        // 6. Update size tracker
        // 7. Release lock
        // Returns (bytes_freed, deleted_paths)
    }

    /// Batch cleanup empty directories after all evictions complete
    fn batch_cleanup_directories(&self, deleted_paths: &[PathBuf]) {
        // Collect unique parent directories
        // Sort by depth (deepest first)
        // Remove empty directories bottom-up
    }
}
```

### New: RangeEvictionCandidate

```rust
/// Represents a single range as an eviction candidate
#[derive(Debug, Clone)]
pub struct RangeEvictionCandidate {
    /// Object cache key
    pub cache_key: String,
    /// Range start byte
    pub range_start: u64,
    /// Range end byte
    pub range_end: u64,
    /// Last access time for this specific range
    pub last_accessed: SystemTime,
    /// Size of the range .bin file in bytes
    pub size: u64,
    /// Access count for this specific range (for TinyLFU)
    pub access_count: u64,
    /// Path to the .bin file
    pub bin_file_path: PathBuf,
    /// Path to the .meta file (for metadata updates)
    pub meta_file_path: PathBuf,
}
```

### Modified: DiskCacheManager

```rust
impl DiskCacheManager {
    /// Batch delete multiple ranges from a single object
    /// Returns (bytes_freed, all_ranges_evicted, deleted_paths)
    pub async fn batch_delete_ranges(
        &self,
        cache_key: &str,
        ranges_to_delete: &[(u64, u64)],  // (start, end) pairs
    ) -> Result<(u64, bool, Vec<PathBuf>)> {
        // 1. Read current metadata (once)
        // 2. Delete all specified range .bin files, collect paths
        // 3. Remove all deleted ranges from metadata.ranges
        // 4. If ranges is empty:
        //    - Delete metadata file, add to paths
        //    - Delete lock files
        //    - Return (bytes_freed, true, paths)
        // 5. Else:
        //    - Atomic write updated metadata (once)
        //    - Return (bytes_freed, false, paths)
    }

    /// Batch clean up empty directories
    /// Processes all paths, removes empty directories bottom-up
    pub fn batch_cleanup_empty_directories(&self, deleted_paths: &[PathBuf]) -> Result<()> {
        let cache_type_roots = ["objects", "ranges"];
        
        // Collect unique parent directories
        let mut dirs_to_check: HashSet<PathBuf> = deleted_paths
            .iter()
            .filter_map(|p| p.parent().map(|d| d.to_path_buf()))
            .collect();
        
        // Sort by depth (deepest first) for bottom-up cleanup
        let mut dirs: Vec<_> = dirs_to_check.into_iter().collect();
        dirs.sort_by(|a, b| b.components().count().cmp(&a.components().count()));
        
        for dir in dirs {
            // Stop at cache type root
            if cache_type_roots.iter().any(|root| dir.ends_with(root)) {
                continue;
            }
            
            if Self::is_directory_empty(&dir)? {
                if let Err(e) = std::fs::remove_dir(&dir) {
                    debug!("Failed to remove empty directory {:?}: {}", dir, e);
                }
            }
        }
        Ok(())
    }
}
```

## Data Models

### Existing: NewCacheMetadata (unchanged)

The existing `NewCacheMetadata` structure already supports per-range access tracking:

```rust
pub struct NewCacheMetadata {
    pub cache_key: String,
    pub object_metadata: ObjectMetadata,
    pub ranges: Vec<RangeSpec>,  // Each range has its own last_accessed and access_count
    pub created_at: SystemTime,
    pub expires_at: SystemTime,
}

pub struct RangeSpec {
    pub start: u64,
    pub end: u64,
    pub file_path: String,
    pub compressed: bool,
    pub compression_algorithm: CompressionAlgorithm,
    pub original_size: u64,
    pub compressed_size: u64,
    pub checksum: Option<String>,
    pub last_accessed: SystemTime,  // Per-range access time
    pub access_count: u64,          // Per-range access count
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Range Independence

*For any* object with N ranges (N ≥ 1), collecting eviction candidates SHALL produce exactly N independent candidates, one for each range.

**Validates: Requirements 1.1, 1.5**

### Property 2: LRU Ordering by Range

*For any* set of range candidates in LRU mode, the eviction order SHALL be sorted by each range's individual `last_accessed` timestamp (oldest first), regardless of which object the range belongs to.

**Validates: Requirements 1.2**

### Property 3: TinyLFU Scoring by Range

*For any* set of range candidates in TinyLFU mode, the eviction score SHALL be calculated using each range's individual `access_count` and `last_accessed` values, not aggregate object values.

**Validates: Requirements 1.3**

### Property 4: Single Range Deletion Isolation

*For any* object with multiple ranges, evicting one range SHALL delete only that range's `.bin` file while preserving all other `.bin` files belonging to the same object.

**Validates: Requirements 2.1, 2.3**

### Property 5: Metadata Update After Range Eviction

*For any* range eviction, the object's metadata SHALL be updated to remove exactly the evicted range from the ranges list, preserving all other ranges.

**Validates: Requirements 2.2**

### Property 6: Cache Size Tracking Accuracy

*For any* range eviction, the cache size tracker SHALL be decremented by exactly the size of the evicted range file (and metadata file size if all ranges evicted).

**Validates: Requirements 2.4, 6.1, 6.2**

### Property 7: Metadata Cleanup Condition

*For any* object, the metadata file SHALL be deleted if and only if all ranges have been evicted (ranges list is empty).

**Validates: Requirements 3.1, 3.2, 3.4**

### Property 8: Directory Cleanup

*For any* file deletion that leaves a directory empty, that directory and any empty parent directories SHALL be removed up to (but not including) the cache type root directories.

**Validates: Requirements 4.2, 4.3, 4.5**

### Property 9: Lock Coordination

*For any* range eviction that modifies metadata, a write lock SHALL be held on the object from before metadata read until after metadata write completes.

**Validates: Requirements 5.1, 5.3**

## Error Handling

| Error Condition | Handling |
|----------------|----------|
| Range .bin file deletion fails | Log warning, continue with metadata update |
| Metadata update fails after .bin deletion | Log warning, orphaned range cleaned by validation scan |
| Directory deletion fails | Log debug, continue without failing eviction |
| Lock acquisition fails | Skip this range, select alternative candidate |
| Metadata read fails | Skip this object's ranges, continue with others |

## Testing Strategy

### Unit Tests

- Test `collect_range_candidates_for_eviction()` returns correct number of candidates
- Test `sort_range_candidates()` for both LRU and TinyLFU modes
- Test `delete_single_range()` updates metadata correctly
- Test `cleanup_empty_directories()` removes correct directories
- Test error handling for each failure scenario

### Property-Based Tests

Using `quickcheck` with minimum 100 iterations per property:

1. **Range Independence Property**: Generate random objects with 1-10 ranges, verify candidate count equals total range count
2. **LRU Ordering Property**: Generate ranges with random timestamps, verify sort order matches timestamp order
3. **TinyLFU Scoring Property**: Generate ranges with random access stats, verify score calculation uses individual values
4. **Single Range Deletion Property**: Create multi-range object, evict one, verify others remain
5. **Metadata Update Property**: Evict range, verify metadata reflects removal
6. **Size Tracking Property**: Track size before/after eviction, verify delta matches range size
7. **Metadata Cleanup Property**: Evict all ranges, verify metadata deleted; evict partial, verify metadata preserved
8. **Directory Cleanup Property**: Create nested directories, delete file, verify empty dirs removed
9. **Lock Coordination Property**: Verify lock file exists during metadata modification

### Integration Tests

- End-to-end eviction with multiple objects and ranges
- Concurrent eviction from multiple instances (shared storage mode)
- Eviction under memory pressure with large cache
