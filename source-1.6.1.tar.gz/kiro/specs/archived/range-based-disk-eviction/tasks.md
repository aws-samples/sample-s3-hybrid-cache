# Implementation Plan: Range-Based Disk Cache Eviction

## Overview

This implementation converts disk cache eviction from object-level to range-level, treating each cached range as an independent eviction candidate with equal weight.

## Tasks

- [x] 1. Add RangeEvictionCandidate struct
  - Create new struct in `src/cache.rs` to represent a single range as eviction candidate
  - Include: cache_key, range_start, range_end, last_accessed, size, access_count, bin_file_path, meta_file_path
  - _Requirements: 1.1_

- [x] 2. Implement range candidate collection
  - [x] 2.1 Create `collect_range_candidates_for_eviction()` method in CacheManager
    - Traverse all .meta files in objects/ directory
    - For each range in metadata, create a RangeEvictionCandidate
    - Use per-range last_accessed and access_count from RangeSpec
    - _Requirements: 1.1, 1.2, 1.3_

  - [x] 2.2 Write property test for range independence
    - **Property 1: Range Independence**
    - **Validates: Requirements 1.1, 1.5**

- [x] 3. Implement range-level sorting
  - [x] 3.1 Create `sort_range_candidates()` method in CacheManager
    - LRU mode: sort by individual range last_accessed (oldest first)
    - TinyLFU mode: sort by individual range TinyLFU score
    - _Requirements: 1.2, 1.3_

  - [x] 3.2 Write property test for LRU ordering
    - **Property 2: LRU Ordering by Range**
    - **Validates: Requirements 1.2**

  - [x] 3.3 Write property test for TinyLFU scoring
    - **Property 3: TinyLFU Scoring by Range**
    - **Validates: Requirements 1.3**

- [x] 4. Implement batch range eviction in DiskCacheManager
  - [x] 4.1 Create `batch_delete_ranges()` method
    - Read current metadata (once per object)
    - Delete all specified range .bin files, collect paths
    - Remove all deleted ranges from metadata.ranges list
    - Atomic write updated metadata (once per object)
    - Return (bytes_freed, all_ranges_evicted, deleted_paths)
    - _Requirements: 2.1, 2.2, 2.3, 2.5_

  - [x] 4.2 Write property test for single range deletion isolation
    - **Property 4: Single Range Deletion Isolation**
    - **Validates: Requirements 2.1, 2.3**

  - [x] 4.3 Write property test for metadata update
    - **Property 5: Metadata Update After Range Eviction**
    - **Validates: Requirements 2.2**

- [x] 5. Implement metadata cleanup on full eviction
  - [x] 5.1 Extend `batch_delete_ranges()` to handle full object cleanup
    - When ranges list becomes empty, delete metadata file
    - Delete associated lock files
    - Add metadata path to deleted_paths for directory cleanup
    - _Requirements: 3.1, 3.2, 3.3, 3.4_

  - [x] 5.2 Write property test for metadata cleanup condition
    - **Property 7: Metadata Cleanup Condition**
    - **Validates: Requirements 3.1, 3.2, 3.4**

- [x] 6. Implement batch directory cleanup
  - [x] 6.1 Create `batch_cleanup_empty_directories()` method in DiskCacheManager
    - Collect unique parent directories from all deleted paths
    - Sort by depth (deepest first) for bottom-up cleanup
    - Remove empty directories, stop at cache type root
    - Log warnings on failure, don't fail eviction
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

  - [x] 6.2 Write property test for directory cleanup
    - **Property 8: Directory Cleanup**
    - **Validates: Requirements 4.2, 4.3, 4.5**

- [x] 7. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 8. Implement batch_evict_ranges in CacheManager
  - [x] 8.1 Create `group_candidates_by_object()` method
    - Group sorted candidates by cache_key
    - Preserve eviction priority order within groups
    - Stop when target bytes reached
    - _Requirements: 1.1, 6.4_

  - [x] 8.2 Create `batch_evict_ranges()` method
    - Acquire write lock on object (once per object)
    - Call DiskCacheManager.batch_delete_ranges()
    - Update cache size tracker
    - Release lock
    - Log eviction details
    - Return (bytes_freed, deleted_paths)
    - _Requirements: 5.1, 5.2, 5.3, 6.1, 6.2, 6.3, 7.1, 7.2_

  - [x] 8.3 Write property test for cache size tracking
    - **Property 6: Cache Size Tracking Accuracy**
    - **Validates: Requirements 2.4, 6.1, 6.2**

  - [x] 8.4 Write property test for lock coordination
    - **Property 9: Lock Coordination**
    - **Validates: Requirements 5.1, 5.3**

- [x] 9. Update perform_eviction_with_lock to use batched range-level eviction
  - [x] 9.1 Replace object-level eviction with batched range-level
    - Call collect_range_candidates_for_eviction()
    - Call sort_range_candidates()
    - Call group_candidates_by_object() with target bytes
    - For each object group, call batch_evict_ranges()
    - Collect all deleted_paths
    - Call batch_cleanup_empty_directories() once at end
    - Remove the arbitrary 3-range threshold logic
    - _Requirements: 1.1, 1.4, 1.5, 6.4_

- [x] 10. Update eviction logging
  - [x] 10.1 Add detailed logging for range eviction
    - Log (INFO) number of entire keys, ranges, and freed bytes (KiB/MiB/GiB) on eviction as summary
    - Log metadata deletion with reason
    - Log directory cleanup at debug level
    - Log errors with cache_key and failure reason
    - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [x] 11. Unify eviction systems
  - [x] 11.1 Update `evict_if_needed()` to use range-based eviction
    - Replace call to legacy `perform_eviction()` with `perform_eviction_with_lock()`
    - Adapt parameters (space_to_free vs current_size/max_size)
    - _Requirements: 1.1, 1.4, 1.5_

  - [x] 11.2 Remove legacy eviction code
    - Remove `EvictionCandidate` struct
    - Remove `scan_all_ranges()` method
    - Remove `scan_all_ranges_recursive()` method
    - Remove legacy `perform_eviction()` method
    - _Requirements: Code cleanup_

  - [x] 11.3 Update eviction tests
    - Update `tests/eviction_buffer_test.rs` to work with unified eviction
    - Verify on-demand eviction uses range-based approach
    - _Requirements: 1.1, 1.4, 1.5_

- [x] 12. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
  - update documentation. think carefully about what should be added, removed or updated and in which section
  

## Notes

- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
