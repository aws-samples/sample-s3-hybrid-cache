# Design: Consolidation Performance & Eviction Coordination (v1.1.37)

## Overview

Four independent changes:

1. **Parallel key processing** — Process up to 4 cache keys concurrently in `run_consolidation_cycle()` using `buffer_unordered(4)`.
2. **Re-read size after eviction lock** — `enforce_disk_cache_limits_internal()` re-reads `current_size` after acquiring the global eviction lock, skipping eviction if no longer needed.
3. **Immediate flush after eviction** — Call `size_accumulator.flush()` after eviction completes but before releasing the global eviction lock.
4. **Reduce log verbosity** — Change `SIZE_ACCUM add/subtract` from INFO to DEBUG.

## Architecture

### Change 1: Parallel Key Processing

Current flow in `run_consolidation_cycle()`:
```
for cache_key in cache_keys.iter().take(max_keys_per_run) {
    match self.consolidate_object(cache_key).await { ... }
}
```

New flow:
```
let key_futures: Vec<_> = cache_keys.iter()
    .take(max_keys_per_run)
    .map(|cache_key| async move {
        (cache_key.clone(), self.consolidate_object(cache_key).await)
    })
    .collect();

let results: Vec<_> = stream::iter(key_futures)
    .buffer_unordered(KEY_CONCURRENCY_LIMIT)
    .collect()
    .await;

for (cache_key, result) in results { ... }
```

Each `consolidate_object()` acquires its own per-key lock via `lock_manager.acquire_lock(cache_key)`. These are independent flock-based locks on different files, so concurrent acquisition is safe. The global consolidation lock is held by the caller for the entire cycle — this doesn't change.

`KEY_CONCURRENCY_LIMIT = 4` is conservative. Higher values would increase NFS I/O pressure. The bottleneck is NFS latency variance, not throughput — 4 concurrent keys means a single slow NFS operation doesn't block the other 3.

### Change 2: Re-read Size After Eviction Lock

Current flow in `enforce_disk_cache_limits_internal()`:
```
let current_size = consolidator.get_current_size().await;  // reads size_state.json
// ... check if over limit ...
let _lock = self.try_acquire_global_eviction_lock().await?;  // may wait
self.perform_eviction_with_lock(current_size, max_size, ...).await  // uses stale current_size
```

New flow:
```
let current_size = consolidator.get_current_size().await;  // pre-check (optimization)
// ... check if over limit ...
let _lock = self.try_acquire_global_eviction_lock().await?;

// Re-read after acquiring lock — previous eviction may have freed space
let current_size = consolidator.get_current_size().await;
if current_size <= max_size {
    info!("Cache no longer over limit after acquiring eviction lock (size={}), skipping", current_size);
    self.release_global_eviction_lock().await?;
    return Ok(0);
}

self.perform_eviction_with_lock(current_size, max_size, ...).await
```

The pre-lock check remains as an optimization — if the cache is under the limit, we skip the lock attempt entirely. The post-lock re-read catches the case where another instance evicted between our pre-check and lock acquisition.

### Change 3: Immediate Flush After Eviction

Current flow in `enforce_disk_cache_limits_internal()`:
```
let eviction_result = self.perform_eviction_with_lock(...).await;
// ... log ...
self.release_global_eviction_lock().await?;  // release lock
// subtract delta sits in accumulator until next consolidation cycle flushes it
```

New flow:
```
let eviction_result = self.perform_eviction_with_lock(...).await;

// Flush accumulator subtract delta to disk BEFORE releasing eviction lock
// This ensures the next instance to check size_state sees the correct post-eviction value
if let Ok(bytes_freed) = &eviction_result {
    if *bytes_freed > 0 {
        if let Some(consolidator) = self.journal_consolidator.read().await.as_ref() {
            if let Err(e) = consolidator.size_accumulator().flush().await {
                warn!("Failed to flush accumulator after eviction: {}", e);
            }
        }
    }
}

self.release_global_eviction_lock().await?;
```

The flush writes a new delta file (append-only, per v1.1.36). The next consolidation cycle on any instance will collect this file and apply it to `size_state.json`. Combined with Change 2, the next instance to attempt eviction will:
1. Acquire the eviction lock (serialized)
2. Re-read size_state (which now reflects the previous eviction's delta, once consolidated)
3. Potentially skip eviction if no longer needed

There's still a window where the delta file exists but hasn't been collected by the consolidator. The re-read in Change 2 reads `size_state.json`, not the delta files. For the re-read to see the correct value, a consolidation cycle must run between the flush and the re-read. Given the 5-second consolidation interval and the fact that eviction takes 35-90 seconds, at least one consolidation cycle will run during that window.

### Change 4: Log Level Reduction

```rust
// Before
pub fn add(&self, compressed_size: u64) {
    self.delta.fetch_add(compressed_size as i64, Ordering::Relaxed);
    info!("SIZE_ACCUM add: +{} bytes, instance={}", compressed_size, self.instance_id);
}

// After
pub fn add(&self, compressed_size: u64) {
    self.delta.fetch_add(compressed_size as i64, Ordering::Relaxed);
    debug!("SIZE_ACCUM add: +{} bytes, instance={}", compressed_size, self.instance_id);
}
```

Same change for `subtract()`. No functional impact.

## Error Handling

| Scenario | Behavior |
|----------|----------|
| `consolidate_object()` fails for one key during parallel processing | Log warning, continue with remaining keys |
| Re-read of size_state fails after eviction lock acquired | Fall back to pre-lock size value, proceed with eviction |
| Accumulator flush fails after eviction | Log warning, release lock, return eviction result (delta stays in memory, will be flushed next cycle) |

## Testing Strategy

### Unit Tests

- **Parallel key processing**: Test `run_consolidation_cycle()` with multiple cache keys. Verify all keys are processed and results aggregated correctly. Verify `max_keys_per_run` limit is respected.
- **Re-read after lock**: Test `enforce_disk_cache_limits_internal()` where size drops below max between pre-check and lock acquisition. Verify eviction is skipped.
- **Immediate flush**: Test that `flush()` is called after eviction completes. Verify delta file is written.
- **Log levels**: Verify `add()` and `subtract()` log at DEBUG. Verify `flush()` logs at INFO.
