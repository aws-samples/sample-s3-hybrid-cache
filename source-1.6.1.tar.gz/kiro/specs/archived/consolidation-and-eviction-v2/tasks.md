# Implementation Plan: Consolidation Performance & Eviction Coordination (v1.1.37)

## Overview

Four independent improvements implemented incrementally. Changes 2 and 3 are in the same file and function, so they're grouped. Change 4 is trivial and done first to reduce noise during testing.

## Tasks

- [x] 1. Reduce SIZE_ACCUM add/subtract log level to DEBUG
  - [x] 1.1 Change `info!` to `debug!` in `SizeAccumulator::add()` in `src/journal_consolidator.rs` (line ~302)
    - _Requirements: 4.1_
  - [x] 1.2 Change `info!` to `debug!` in `SizeAccumulator::subtract()` in `src/journal_consolidator.rs` (line ~315)
    - _Requirements: 4.2_
  - [x] 1.3 Verify `flush()`, `collect_and_apply_deltas()` logging remains at INFO
    - _Requirements: 4.3, 4.4_

- [x] 2. Re-read size after eviction lock + immediate flush after eviction
  - [x] 2.1 In `CacheManager::enforce_disk_cache_limits_internal()` in `src/cache.rs`, after `try_acquire_global_eviction_lock()` succeeds, re-read `current_size` from the consolidator
    - If `current_size <= max_size`, log at INFO, release lock, return `Ok(0)`
    - Pass the re-read `current_size` to `perform_eviction_with_lock()`
    - Keep the pre-lock size check as an optimization (no change to existing early return)
    - _Requirements: 2.1, 2.2, 2.3, 2.4_
  - [x] 2.2 In `CacheManager::enforce_disk_cache_limits_internal()` in `src/cache.rs`, after `perform_eviction_with_lock()` returns with `bytes_freed > 0`, call `consolidator.size_accumulator().flush().await` BEFORE `release_global_eviction_lock()`
    - On flush failure, log warning and continue (don't fail the eviction)
    - _Requirements: 3.1, 3.2, 3.3_

- [x] 3. Parallel cache key processing in consolidation
  - [x] 3.1 Add `const KEY_CONCURRENCY_LIMIT: usize = 4;` in `src/journal_consolidator.rs`
    - _Requirements: 1.6_
  - [x] 3.2 In `JournalConsolidator::run_consolidation_cycle()`, replace the sequential `for cache_key in cache_keys.iter().take(max_keys_per_run)` loop with parallel processing
    - Collect futures for each key's `consolidate_object()` call
    - Use `stream::iter(futures).buffer_unordered(KEY_CONCURRENCY_LIMIT).collect().await`
    - Aggregate results (total_entries_consolidated, _total_size_delta, all_consolidated_entries, keys_processed) in a sequential loop after all futures complete
    - Handle errors per-key: log warning, continue with remaining keys
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

- [x] 4. Run tests and verify
  - All 573 unit tests pass. 14 pre-existing failures in distributed_eviction_lock_error_handling_test (unrelated).

- [x] 5. Version bump and documentation
  - [x] 5.1 Update `Cargo.toml` version to `1.1.37`
    - _Requirements: 5.1_
  - [x] 5.2 Add v1.1.37 entry to `CHANGELOG.md`
    - _Requirements: 5.2_
  - [x] 5.3 Commit: `git add -A && git commit -m "v1.1.37: Parallel consolidation, eviction coordination, log verbosity"`
