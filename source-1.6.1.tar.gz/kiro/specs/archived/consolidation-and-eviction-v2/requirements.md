# Requirements: Consolidation Performance & Eviction Coordination (v1.1.37)

## Introduction

Four improvements to consolidation performance, eviction coordination, and logging verbosity. Addresses the v1.1.36 over-eviction problem (cache dropped to 62% of max despite 80% target) and consolidation cycles taking 7-62 seconds during active downloads.

## Glossary

- **Consolidation_Cycle**: The periodic task in `JournalConsolidator::run_consolidation_cycle()` that runs every 5 seconds, collects accumulator deltas, processes journal entries per cache key, and triggers eviction.
- **Global_Consolidation_Lock**: flock-based lock preventing multiple instances from running Consolidation_Cycle simultaneously.
- **Global_Eviction_Lock**: flock-based lock (`locks/global_eviction.lock`) preventing multiple instances from running eviction simultaneously. Already implemented in `CacheManager::try_acquire_global_eviction_lock()`.
- **Key_Processing**: The per-cache-key work in `consolidate_object()`: acquire per-key lock, read journal entries, validate, load metadata, apply entries, write metadata, release lock.
- **SizeAccumulator**: In-memory `AtomicI64` tracking cache size deltas, flushed to delta files every consolidation cycle.

## Requirements

### Requirement 1: Parallel Cache Key Processing in Consolidation

**User Story:** As a proxy operator, I want consolidation to process multiple cache keys concurrently, so that NFS latency spikes on individual keys don't block the entire consolidation cycle.

#### Acceptance Criteria

1. WHEN `run_consolidation_cycle()` processes cache keys, THE function SHALL process up to KEY_CONCURRENCY_LIMIT (4) keys concurrently using `futures::stream::buffer_unordered`
2. WHEN processing keys concurrently, each key's `consolidate_object()` call SHALL acquire its own per-key lock independently (no change to locking semantics)
3. WHEN a concurrent `consolidate_object()` call fails, THE function SHALL log a warning and continue processing remaining keys
4. THE aggregation of results (entries_consolidated, size_delta, consolidated_entries) SHALL happen after all concurrent work completes
5. THE `max_keys_per_run` limit SHALL still be respected (applied before parallelization)
6. `KEY_CONCURRENCY_LIMIT` SHALL be defined as a constant (4) in `journal_consolidator.rs`

### Requirement 2: Re-read Size State After Acquiring Eviction Lock

**User Story:** As a proxy operator, I want eviction to use a fresh size reading after acquiring the global eviction lock, so that eviction decisions reflect other instances' recent evictions.

#### Acceptance Criteria

1. WHEN `enforce_disk_cache_limits_internal()` acquires the global eviction lock, THE function SHALL re-read `current_size` from the consolidator AFTER lock acquisition
2. WHEN the re-read `current_size` is at or below `max_size`, THE function SHALL release the lock and return 0 (no eviction needed)
3. THE `perform_eviction_with_lock()` call SHALL use the re-read `current_size`, not the pre-lock value
4. THE pre-lock size check SHALL remain as an optimization to avoid unnecessary lock attempts

### Requirement 3: Immediate Accumulator Flush After Eviction

**User Story:** As a proxy operator, I want eviction subtract deltas to be flushed to disk immediately after eviction completes, so that the next instance to check size sees the correct post-eviction value.

#### Acceptance Criteria

1. WHEN `enforce_disk_cache_limits_internal()` completes eviction (bytes_freed > 0), THE function SHALL call `size_accumulator.flush()` BEFORE releasing the global eviction lock
2. WHEN the flush fails, THE function SHALL log a warning but still release the lock and return the eviction result
3. THE flush SHALL happen after `perform_eviction_with_lock()` returns (which includes all subtract operations and journal writes)

### Requirement 4: Reduce SIZE_ACCUM Add/Subtract Log Level

**User Story:** As a proxy operator, I want per-operation size accumulator logs reduced to DEBUG level, so that INFO logs are not overwhelmed during active downloads.

#### Acceptance Criteria

1. THE `SizeAccumulator::add()` method SHALL log at DEBUG level instead of INFO
2. THE `SizeAccumulator::subtract()` method SHALL log at DEBUG level instead of INFO
3. THE `SizeAccumulator::flush()` method SHALL remain at INFO level
4. THE `SizeAccumulator::collect_and_apply_deltas()` logging SHALL remain at INFO level
5. THE `SizeAccumulator::add_write_cache()` and `subtract_write_cache()` methods SHALL remain unchanged (no logging)

### Requirement 5: Version and Documentation Updates

**User Story:** As a proxy operator, I want the version bumped and changelog updated.

#### Acceptance Criteria

1. THE `Cargo.toml` version SHALL be updated to `1.1.37`
2. THE `CHANGELOG.md` SHALL contain a v1.1.37 entry describing the four improvements
