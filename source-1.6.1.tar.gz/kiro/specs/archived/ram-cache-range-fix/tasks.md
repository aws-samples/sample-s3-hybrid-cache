# Implementation Plan: RAM Cache Range Fix

## Overview

Fix the RAM cache to work correctly for range requests by adding two new methods to `CacheManager` (`get_range_from_ram_cache`, `promote_range_to_ram_cache`), modifying the streaming path in `HttpProxy::serve_range_from_cache()` to use them, and adding property-based tests to verify correctness.

## Tasks

- [x] 1. Add `get_range_from_ram_cache` and `promote_range_to_ram_cache` to CacheManager
  - [x] 1.1 Implement `get_range_from_ram_cache(&self, cache_key: &str, start: u64, end: u64) -> Option<Vec<u8>>` in `src/cache.rs`
    - Construct `range_cache_key` as `format!("{}:range:{}:{}", cache_key, start, end)`
    - Lock `inner`, call `ram_cache.get(&range_cache_key)` (records hit/miss internally)
    - On hit: decompress if `compressed`, call `update_ram_cache_hit_statistics()`, return `Some(data)`
    - On miss: return `None`
    - If RAM cache disabled, return `None` immediately
    - _Requirements: 1.1, 1.2, 3.1, 3.2, 3.3_
  - [x] 1.2 Implement `promote_range_to_ram_cache(&self, cache_key: &str, start: u64, end: u64, data: &[u8], etag: String)` in `src/cache.rs`
    - Construct `range_cache_key` as `format!("{}:range:{}:{}", cache_key, start, end)`
    - Check `data.len() as u64 > max_ram_cache_size` — if so, log debug and return
    - Create `RamCacheEntry` with range_cache_key, data, etag, content_length = data.len()
    - Lock `inner`, call `ram_cache.put(entry, compression_handler)`
    - If RAM cache disabled, return immediately
    - _Requirements: 2.1, 2.2, 2.3, 5.1, 5.2_
  - [x] 1.3 Write property test: Range RAM cache round-trip
    - **Property 1: Range RAM cache round-trip**
    - **Validates: Requirements 1.1, 1.2, 1.3**
    - Generate random (cache_key, start, end, data) tuples
    - Call `promote_range_to_ram_cache`, then `get_range_from_ram_cache`
    - Assert returned data equals original
  - [x] 1.4 Write property test: Promotion preserves metadata
    - **Property 2: Promotion preserves metadata**
    - **Validates: Requirements 2.1, 2.2, 2.3**
    - Generate random (cache_key, start, end, data, etag) tuples
    - Promote, then inspect the RamCacheEntry stored under the range key
    - Assert etag and content_length match
  - [x] 1.5 Write property test: Hit and miss counting accuracy
    - **Property 3: Hit and miss counting accuracy**
    - **Validates: Requirements 3.2, 3.3, 4.1, 4.2, 4.3, 4.4**
    - Generate random sequences of promote + get operations
    - Track expected hits/misses, compare with `get_ram_cache_stats()`
  - [x] 1.6 Write property test: RAM cache size invariant
    - **Property 4: RAM cache size invariant**
    - **Validates: Requirements 2.4, 5.1, 5.3**
    - Generate random sequences of promotions with varying data sizes
    - Assert `current_size <= max_size` after each operation

- [x] 2. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Modify streaming path to use RAM cache
  - [x] 3.1 Modify `serve_range_from_cache()` in `src/http_proxy.rs` to check RAM cache before streaming decision
    - Before the `use_streaming` check, call `cache_manager.get_range_from_ram_cache(cache_key, range_spec.start, range_spec.end)`
    - On RAM hit: build a buffered 206 response with the returned data (same pattern as `serve_range_from_cache_buffered`), log `"GET RAM range cache HIT"`, update statistics, return early
    - On RAM miss: continue to existing streaming/buffered decision logic
    - Remove the `is_range_in_ram_cache()` call from the `use_streaming` condition — it's no longer needed since we check RAM cache upfront
    - _Requirements: 3.1, 3.2, 3.3, 4.1, 4.2_
  - [x] 3.2 Add RAM cache promotion after disk streaming completes in `serve_range_from_cache()`
    - In the streaming task that reads chunks from disk, if `range_size <= max_ram_cache_size`: allocate a `Vec<u8>` buffer, collect chunks as they stream
    - After the streaming task completes successfully, spawn an async task to call `promote_range_to_ram_cache()` with the collected buffer
    - Pass `max_ram_cache_size` from config into the streaming scope
    - Extract etag from `disk_range_spec` for the promotion call
    - _Requirements: 2.2, 5.1, 5.2_
  - [x] 3.3 Write unit tests for streaming path RAM cache integration
    - Test: range in RAM cache → served from RAM, no disk streaming
    - Test: range not in RAM, streamed from disk → promoted to RAM afterward
    - Test: range larger than max_ram_cache_size → not promoted
    - _Requirements: 3.1, 2.2, 5.2_

- [x] 4. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Documentation updates
  - [x] 5.1 Update `docs/CACHING.md` — in the RAM cache and range request sections, document that the streaming path now serves from and promotes to RAM cache
  - [x] 5.2 Update `docs/ARCHITECTURE.md` — if it references the two-tier cache or streaming path, note that both paths now use RAM cache for ranges
  - [x] 5.3 Update `CHANGELOG.md` — add `[1.1.44]` entry under `### Fixed` describing the RAM cache range fix (streaming path now checks/promotes RAM cache, dashboard stats now reflect both paths)

- [x] 6. Version bump and commit
  - [x] 6.1 Bump version in `Cargo.toml` from `1.1.43` to `1.1.44`
  - [x] 6.2 Run `cargo build` to verify `Cargo.lock` updates cleanly
  - [x] 6.3 Commit: `git add Cargo.toml Cargo.lock CHANGELOG.md && git commit -m "v1.1.44: RAM cache range fix — streaming path serves from and promotes to RAM cache"`
