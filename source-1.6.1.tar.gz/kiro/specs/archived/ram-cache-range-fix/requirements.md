# Requirements Document

## Introduction

The RAM cache (in-memory LRU/TinyLFU cache) is broken for range requests, which are the dominant traffic pattern. Range lookups use the key format `{cache_key}:range:{start}:{end}`, but entries are stored under the plain `cache_key`. This means range requests never hit RAM cache. Additionally, the streaming path (ranges >= 1 MiB) bypasses RAM cache entirely, and range data served from disk is never promoted to RAM. Dashboard statistics only reflect the buffered path, making the streaming path invisible.

This fix aligns RAM cache storage keys with lookup keys, adds RAM cache serving and promotion for both streaming and buffered paths, and corrects dashboard statistics.

## Glossary

- **RAM_Cache**: The per-instance in-memory LRU/TinyLFU cache (`RamCache` struct in `ram_cache.rs`) that stores `RamCacheEntry` objects keyed by string
- **Range_Cache_Key**: A string in the format `{cache_key}:range:{start}:{end}` that uniquely identifies a specific byte range of an object
- **Plain_Cache_Key**: A string in the format `{bucket}/{path/to/object}` that identifies an object without range information
- **Streaming_Path**: The code path in `serve_range_from_cache()` that streams range data from disk in 512 KiB chunks for ranges >= `disk_streaming_threshold` (default 1 MiB)
- **Buffered_Path**: The code path in `serve_range_from_cache_buffered()` that loads entire range data into memory before responding, used for small ranges and RAM cache hits
- **Promotion**: The act of copying range data from disk cache into RAM_Cache after a disk cache hit, so subsequent requests are served from memory
- **CacheManager**: The unified cache manager (`cache.rs`) coordinating RAM and disk cache tiers
- **Dashboard**: The HTTP endpoint serving cache statistics including RAM_Cache hit rate, hits, misses, size, and evictions

## Requirements

### Requirement 1: Range-Specific RAM Cache Key Alignment

**User Story:** As a system operator, I want range data stored in RAM_Cache under the Range_Cache_Key so that subsequent range lookups actually find the cached data.

#### Acceptance Criteria

1. WHEN CacheManager stores range data in RAM_Cache, THE CacheManager SHALL use the Range_Cache_Key format `{cache_key}:range:{start}:{end}` as the storage key
2. WHEN CacheManager looks up range data in RAM_Cache, THE CacheManager SHALL use the same Range_Cache_Key format `{cache_key}:range:{start}:{end}` as the lookup key
3. WHEN a range is stored and then looked up with matching cache_key, start, and end values, THE RAM_Cache SHALL return the stored data (round-trip consistency)

### Requirement 2: RAM Cache Promotion from Disk for Range Requests

**User Story:** As a system operator, I want range data promoted to RAM_Cache after disk cache hits so that repeated requests for the same range are served from memory instead of disk.

#### Acceptance Criteria

1. WHEN the Buffered_Path serves a range from disk cache, THE CacheManager SHALL promote that range data to RAM_Cache under the Range_Cache_Key
2. WHEN the Streaming_Path serves a range from disk cache, THE CacheManager SHALL promote that range data to RAM_Cache under the Range_Cache_Key
3. WHEN promoting range data to RAM_Cache, THE CacheManager SHALL store the data with correct metadata including etag and content_length from the disk cache entry
4. IF RAM_Cache is full when promoting range data, THEN THE RAM_Cache SHALL evict entries according to the configured eviction algorithm (LRU or TinyLFU) to make room

### Requirement 3: RAM Cache Serving in the Streaming Path

**User Story:** As a system operator, I want the streaming path to serve range data from RAM_Cache when available so that hot ranges avoid disk I/O entirely.

#### Acceptance Criteria

1. WHEN the Streaming_Path handles a range request and the range data exists in RAM_Cache, THE Streaming_Path SHALL serve the data from RAM_Cache instead of streaming from disk
2. WHEN the Streaming_Path serves data from RAM_Cache, THE CacheManager SHALL record the access as a RAM cache hit in statistics
3. WHEN the Streaming_Path checks RAM_Cache and the range is not present, THE CacheManager SHALL record the access as a RAM cache miss in statistics

### Requirement 4: Accurate Dashboard Statistics for Range Requests

**User Story:** As a system operator, I want the dashboard to accurately reflect RAM_Cache usage across both streaming and buffered paths so that I can monitor cache effectiveness.

#### Acceptance Criteria

1. WHEN the Streaming_Path serves a range from RAM_Cache, THE CacheManager SHALL increment the RAM_Cache hit counter
2. WHEN the Streaming_Path serves a range from disk (RAM_Cache miss), THE CacheManager SHALL increment the RAM_Cache miss counter
3. WHEN the Buffered_Path serves a range from RAM_Cache, THE CacheManager SHALL increment the RAM_Cache hit counter
4. WHEN the Buffered_Path serves a range from disk (RAM_Cache miss), THE CacheManager SHALL increment the RAM_Cache miss counter
5. THE Dashboard SHALL display RAM_Cache hit rate computed from hits and misses across both Streaming_Path and Buffered_Path

### Requirement 5: Memory Pressure Management

**User Story:** As a system operator, I want RAM_Cache to handle large range entries gracefully so that a few large ranges do not starve the cache for other entries.

#### Acceptance Criteria

1. WHEN promoting a range to RAM_Cache, THE CacheManager SHALL respect the configured `max_ram_cache_size` limit by evicting entries as needed before insertion
2. WHEN a single range exceeds `max_ram_cache_size`, THE CacheManager SHALL skip RAM_Cache promotion for that range and log a debug message
3. THE RAM_Cache SHALL maintain accurate `current_size` tracking as range entries are added and evicted
