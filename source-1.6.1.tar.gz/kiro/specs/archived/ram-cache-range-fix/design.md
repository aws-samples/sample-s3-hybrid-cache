# Design Document: RAM Cache Range Fix

## Overview

The RAM cache is broken for range requests because the streaming path (ranges >= 1 MiB, the dominant traffic pattern) completely bypasses RAM cache — it never reads from RAM, never promotes disk hits to RAM, and never records hits/misses. The buffered path (ranges < 1 MiB) works correctly via `load_range_data_with_cache()`, which already uses the correct `{cache_key}:range:{start}:{end}` key format for both lookup and promotion.

The fix focuses on the streaming path in `serve_range_from_cache()`:
1. Before streaming from disk, attempt to serve the range from RAM cache
2. After streaming from disk, promote the range data to RAM cache
3. Record hit/miss statistics for all RAM cache lookups

The buffered path requires no changes — `load_range_data_with_cache()` already handles RAM cache correctly.

## Architecture

The current two-tier cache hierarchy (RAM → Disk) is correct in design but incomplete in implementation. The fix completes the RAM tier for the streaming path without changing the disk cache or streaming architecture.

```mermaid
flowchart TD
    A[Range Request] --> B{Range >= streaming threshold?}
    B -->|No| C[Buffered Path - already works]
    B -->|Yes| D{Range in RAM cache?}
    D -->|Hit| E[Serve from RAM as buffered response]
    D -->|Miss| F[Stream from disk]
    F --> G{Range size <= max_ram_cache_size?}
    G -->|Yes| H[Promote: read streamed data + store in RAM]
    G -->|No| I[Skip promotion, log debug]
    C --> J[load_range_data_with_cache handles RAM lookup + promotion]
```

## Components and Interfaces

### Modified Components

#### 1. `CacheManager` (`src/cache.rs`)

New public method:

```rust
/// Load range data from RAM cache, returning the decompressed data if found.
/// Records hit/miss statistics. Returns None on miss.
pub fn get_range_from_ram_cache(
    &self,
    cache_key: &str,
    start: u64,
    end: u64,
) -> Option<Vec<u8>>
```

This method:
- Constructs the `range_cache_key` as `{cache_key}:range:{start}:{end}`
- Calls `ram_cache.get(&range_cache_key)` (which updates hit/miss counters internally)
- Decompresses data if compressed
- Calls `update_ram_cache_hit_statistics()` on hit
- Returns `None` on miss (miss already counted by `ram_cache.get()`)

New public method:

```rust
/// Promote range data to RAM cache after a disk cache hit.
/// Skips promotion if the data exceeds max_ram_cache_size.
pub fn promote_range_to_ram_cache(
    &self,
    cache_key: &str,
    start: u64,
    end: u64,
    data: &[u8],
    etag: String,
)
```

This method:
- Constructs the `range_cache_key` as `{cache_key}:range:{start}:{end}`
- Checks if `data.len() > max_ram_cache_size` — if so, logs debug and returns
- Creates a `RamCacheEntry` with the range_cache_key and data
- Calls `ram_cache.put()` which handles eviction automatically

#### 2. `HttpProxy::serve_range_from_cache()` (`src/http_proxy.rs`)

Modified to:
1. Before the streaming/buffered decision, check RAM cache via `get_range_from_ram_cache()`
2. On RAM hit: serve the data as a buffered response (same as current buffered path), skip disk streaming entirely
3. On RAM miss + streaming path: after successfully streaming from disk, collect the streamed data and call `promote_range_to_ram_cache()` asynchronously
4. Remove the `is_range_in_ram_cache()` / `contains()` check that currently gates the streaming decision — replace with the actual `get_range_from_ram_cache()` call that returns data

#### 3. Dashboard statistics (`src/dashboard.rs`)

No changes needed. The dashboard already reads from `RamCacheStats` which gets its hit/miss counts from `RamCache.get()`. Once the streaming path calls `get_range_from_ram_cache()` (which calls `ram_cache.get()`), the counters will be updated automatically.

### Unchanged Components

- `load_range_data_with_cache()` — already correct for the buffered path
- `RamCache` struct — already supports range keys, hit/miss counting, eviction
- `store_in_ram_cache()` — only used for full-object entries, not affected
- `promote_to_ram_cache()` — only used for full-object disk hits, not affected
- Disk cache and streaming infrastructure — untouched

## Data Models

No new data structures. The existing `RamCacheEntry` stores range data with the `cache_key` field set to the range-specific key format.

```rust
// Existing struct, no changes
pub struct RamCacheEntry {
    pub cache_key: String,           // Will be "{cache_key}:range:{start}:{end}" for ranges
    pub data: Vec<u8>,               // Range data (compressed by RamCache.put())
    pub metadata: CacheMetadata,     // etag, content_length, etc.
    pub created_at: SystemTime,
    pub last_accessed: SystemTime,
    pub access_count: u64,
    pub compressed: bool,
    pub compression_algorithm: CompressionAlgorithm,
}
```

### Streaming Path Promotion Strategy

For the streaming path, the data is streamed in 512 KiB chunks to the client. To promote to RAM cache, we collect the chunks into a buffer during streaming. This is acceptable because:
- The streaming path already buffers the full range in the disk read task
- The promotion buffer is temporary and freed after `ram_cache.put()`
- Ranges that exceed `max_ram_cache_size` are skipped entirely (no buffer allocated)

```rust
// In the streaming task, collect chunks for RAM promotion
let mut promotion_buffer: Option<Vec<u8>> = if range_size <= max_ram_cache_size {
    Some(Vec::with_capacity(range_size as usize))
} else {
    None
};

// While streaming chunks to client:
if let Some(ref mut buf) = promotion_buffer {
    buf.extend_from_slice(&chunk);
}

// After streaming completes:
if let Some(buffer) = promotion_buffer {
    cache_manager.promote_range_to_ram_cache(
        cache_key, start, end, &buffer, etag,
    );
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Range RAM cache round-trip

*For any* valid cache_key (non-empty string), start offset, end offset (where start <= end), and range data (non-empty byte vector), storing the range in RAM cache via `promote_range_to_ram_cache` and then looking it up via `get_range_from_ram_cache` with the same cache_key, start, and end should return data equal to the original.

**Validates: Requirements 1.1, 1.2, 1.3**

### Property 2: Promotion preserves metadata

*For any* valid cache_key, start, end, data, and etag string, after promoting range data to RAM cache, the `RamCacheEntry` stored under the range key should have `metadata.etag` equal to the provided etag and `metadata.content_length` equal to `data.len()`.

**Validates: Requirements 2.1, 2.2, 2.3**

### Property 3: Hit and miss counting accuracy

*For any* sequence of `get_range_from_ram_cache` calls (some for keys that exist in RAM, some for keys that don't), the RAM cache `hit_count` should equal the number of calls that returned `Some`, and `miss_count` should equal the number of calls that returned `None`.

**Validates: Requirements 3.2, 3.3, 4.1, 4.2, 4.3, 4.4**

### Property 4: RAM cache size invariant

*For any* sequence of `promote_range_to_ram_cache` calls with varying data sizes, the RAM cache `current_size` should never exceed `max_ram_cache_size` after each operation completes.

**Validates: Requirements 2.4, 5.1, 5.3**

## Error Handling

| Scenario | Handling |
|---|---|
| RAM cache disabled (`ram_cache_enabled = false`) | All new methods return `None` / no-op silently |
| Decompression failure on RAM cache hit | Log error, return `None` (fall through to disk) |
| Range data exceeds `max_ram_cache_size` | Skip promotion, log debug message, no error |
| Lock contention on `inner.lock()` | Uses existing `Mutex` — blocks briefly, same as current behavior |
| Promotion fails (eviction error) | Log warning, continue serving from disk — promotion is best-effort |

## Testing Strategy

### Property-Based Testing

Use the `quickcheck` crate (already a dependency) with minimum 100 iterations per property.

Each property test creates a `CacheManager` with RAM cache enabled and a small `max_ram_cache_size` (e.g., 1 MiB) to exercise eviction paths.

- **Property 1** (round-trip): Generate random `(String, u64, u64, Vec<u8>)` tuples, promote, then get. Assert data equality.
  - Tag: `Feature: ram-cache-range-fix, Property 1: Range RAM cache round-trip`
- **Property 2** (metadata): Generate random `(String, u64, u64, Vec<u8>, String)` tuples, promote, then inspect the stored entry's metadata.
  - Tag: `Feature: ram-cache-range-fix, Property 2: Promotion preserves metadata`
- **Property 3** (hit/miss counting): Generate a random sequence of promote + get operations, track expected hits/misses, compare with `RamCacheStats`.
  - Tag: `Feature: ram-cache-range-fix, Property 3: Hit and miss counting accuracy`
- **Property 4** (size invariant): Generate random sequences of promotions with varying sizes, assert `current_size <= max_size` after each.
  - Tag: `Feature: ram-cache-range-fix, Property 4: RAM cache size invariant`

### Unit Tests

- Edge case: promote a range exactly equal to `max_ram_cache_size` — should succeed
- Edge case: promote a range larger than `max_ram_cache_size` — should be skipped
- Edge case: promote with RAM cache disabled — should no-op
- Edge case: `get_range_from_ram_cache` with RAM cache disabled — should return `None`
- Verify `is_range_in_ram_cache` is no longer called in the streaming path (code review / grep)

### Integration Testing

- Store a range on disk, trigger the streaming path, verify the range appears in RAM cache afterward
- Store a range in RAM cache, trigger the streaming path, verify the response comes from RAM (check log output for "RAM" tier indicator)
- Verify dashboard stats reflect hits/misses from both paths after a sequence of requests
