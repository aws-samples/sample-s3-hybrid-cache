# Design Document: Eviction Performance

## Overview

Three independent improvements to eviction performance in the S3 Proxy:

1. **Decouple eviction from consolidation** — Spawn eviction as a `tokio::spawn` task instead of awaiting it inline. An `AtomicBool` guard prevents concurrent spawns. The consolidation cycle releases the global lock immediately.
2. **Parallel NFS deletes** — Replace sequential `std::fs::remove_file` with concurrent `tokio::fs::remove_file` using `FuturesUnordered`. Two levels: parallel file deletes within each object (32 concurrent), and parallel object processing across objects (8 concurrent).
3. **Early exit check** — Break out of the eviction loop once `total_bytes_freed >= bytes_to_free`.

All changes are in existing files. No new modules or dependencies required (`futures = "0.3"`, `std::sync::atomic::AtomicBool`, and `quickcheck` are already available).

## Architecture

```mermaid
sequenceDiagram
    participant CC as Consolidation Cycle
    participant MTE as maybe_trigger_eviction()
    participant EG as AtomicBool Guard
    participant ET as Eviction Task (spawned)
    participant PEW as perform_eviction_with_lock()
    participant BDR as batch_delete_ranges()

    CC->>MTE: Check if eviction needed
    MTE->>EG: compare_exchange(false, true)
    alt Guard was false
        MTE->>ET: tokio::spawn(eviction)
        MTE-->>CC: return (true, 0)
        CC->>CC: Release global lock, cycle complete
        ET->>PEW: Run eviction
        PEW->>PEW: Early exit check per object
        par Object parallelism (8 concurrent)
            PEW->>BDR: Object A
            PEW->>BDR: Object B
        end
        BDR->>BDR: Parallel file deletes (32 concurrent)
        ET->>EG: store(false)
    else Guard was true
        MTE-->>CC: return (false, 0) — skip
    end
```

## Components and Interfaces

### Component 1: Eviction Guard (`AtomicBool` on `JournalConsolidator`)

New field on `JournalConsolidator`:

```rust
pub struct JournalConsolidator {
    // ... existing fields ...
    /// Guard to prevent concurrent eviction spawns
    eviction_in_progress: AtomicBool,
}
```

Initialized to `false` in `JournalConsolidator::new()`.

The guard uses `compare_exchange(false, true, SeqCst, SeqCst)` to atomically check-and-set. This matches the existing pattern in `logging.rs` (`flush_in_progress`) and `cache_hit_update_buffer.rs`.

### Component 2: Modified `maybe_trigger_eviction()`

Current signature:
```rust
async fn maybe_trigger_eviction(&self, known_size: Option<u64>) -> (bool, u64)
```

New behavior:
- Check `eviction_in_progress.compare_exchange(false, true, SeqCst, SeqCst)` — if it fails, return `(false, 0)`
- Obtain `Arc<CacheManager>` from the weak reference (same as current code)
- Clone the `Arc<CacheManager>` and the `AtomicBool` reference for the spawned task
- `tokio::spawn` the eviction task, which:
  1. Calls `cache_manager.enforce_disk_cache_limits_skip_consolidation().await`
  2. Logs result (bytes freed or error)
  3. Resets `eviction_in_progress.store(false, SeqCst)` in all paths (success, error, panic via `scopeguard`)
- Return `(true, 0)` immediately

Since `JournalConsolidator` is not `'static` (it's behind `&self`), the spawned task needs owned data. The `AtomicBool` must be wrapped in `Arc` so it can be moved into the spawned future. Change the field type to `Arc<AtomicBool>`.

```rust
pub struct JournalConsolidator {
    // ... existing fields ...
    eviction_in_progress: Arc<AtomicBool>,
}
```

The spawned task closure captures:
- `Arc<CacheManager>` (cloned from the weak upgrade)
- `Arc<AtomicBool>` (cloned from `self.eviction_in_progress`)

```rust
async fn maybe_trigger_eviction(&self, known_size: Option<u64>) -> (bool, u64) {
    if self.config.max_cache_size == 0 {
        return (false, 0);
    }

    let current_size = match known_size {
        Some(size) => size,
        None => self.get_current_size().await,
    };

    let trigger_threshold = (self.config.max_cache_size as f64
        * (self.config.eviction_trigger_percent as f64 / 100.0)) as u64;

    if current_size <= trigger_threshold {
        return (false, 0);
    }

    // Check if eviction is already running
    if self.eviction_in_progress
        .compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst)
        .is_err()
    {
        debug!("Eviction already in progress, skipping");
        return (false, 0);
    }

    // Get cache manager reference
    let cache_manager = {
        let guard = match self.cache_manager.lock() {
            Ok(g) => g,
            Err(e) => {
                warn!("Failed to acquire cache_manager lock for eviction: {}", e);
                self.eviction_in_progress.store(false, Ordering::SeqCst);
                return (false, 0);
            }
        };
        match guard.as_ref().and_then(|weak| weak.upgrade()) {
            Some(cm) => cm,
            None => {
                debug!("Cache manager not available, skipping eviction");
                self.eviction_in_progress.store(false, Ordering::SeqCst);
                return (false, 0);
            }
        }
    };

    let eviction_flag = self.eviction_in_progress.clone();

    debug!(
        "Spawning eviction task: current_size={}, trigger_threshold={}, max_size={}",
        current_size, trigger_threshold, self.config.max_cache_size
    );

    tokio::spawn(async move {
        let _guard = scopeguard::guard((), |_| {
            eviction_flag.store(false, Ordering::SeqCst);
        });

        match cache_manager.enforce_disk_cache_limits_skip_consolidation().await {
            Ok(bytes_freed) => {
                if bytes_freed > 0 {
                    info!("Background eviction completed: bytes_freed={}", bytes_freed);
                }
            }
            Err(e) => {
                warn!("Background eviction failed: {}", e);
            }
        }
    });

    (true, 0)
}
```

### Component 3: Parallel File Deletes in `batch_delete_ranges()`

Replace the sequential loop over `metadata.ranges` with a concurrent approach:

```rust
use futures::stream::{FuturesUnordered, StreamExt};

// Collect delete tasks
let mut delete_futures = FuturesUnordered::new();

for range_spec in &metadata.ranges {
    let range_key = (range_spec.start, range_spec.end);
    if ranges_set.contains(&range_key) {
        let range_file_path = self.get_new_range_file_path(
            cache_key, range_spec.start, range_spec.end,
        );
        let start = range_spec.start;
        let end = range_spec.end;
        let cache_key_owned = cache_key.to_string();

        delete_futures.push(async move {
            let file_size = match tokio::fs::metadata(&range_file_path).await {
                Ok(meta) => meta.len(),
                Err(e) => {
                    warn!(
                        "Failed to get file size: key={}, range={}-{}, error={}",
                        cache_key_owned, start, end, e
                    );
                    0
                }
            };

            let deleted = match tokio::fs::remove_file(&range_file_path).await {
                Ok(()) => true,
                Err(e) => {
                    warn!(
                        "[RANGE_EVICTION] Failed to delete: key={}, range={}-{}, error={}",
                        cache_key_owned, start, end, e
                    );
                    false
                }
            };

            (range_key, file_size, deleted, range_file_path)
        });
    }
}

// Process up to FILE_CONCURRENCY_LIMIT (32) at a time
let mut bytes_freed: u64 = 0;
let mut deleted_paths: Vec<PathBuf> = Vec::new();
let mut ranges_deleted: Vec<(u64, u64)> = Vec::new();

while let Some((range_key, file_size, deleted, path)) = delete_futures.next().await {
    if deleted {
        bytes_freed += file_size;
        deleted_paths.push(path);
    }
    ranges_deleted.push(range_key);
}
```

Note: `FuturesUnordered` runs all futures concurrently without a built-in limit. For the concurrency limit of 32, use `futures::stream::iter(...).buffer_unordered(32)` instead:

```rust
use futures::stream::{self, StreamExt};

let delete_tasks: Vec<_> = metadata.ranges.iter()
    .filter(|r| ranges_set.contains(&(r.start, r.end)))
    .map(|range_spec| {
        let path = self.get_new_range_file_path(cache_key, range_spec.start, range_spec.end);
        let key = (range_spec.start, range_spec.end);
        let ck = cache_key.to_string();
        async move {
            let file_size = tokio::fs::metadata(&path).await.map(|m| m.len()).unwrap_or(0);
            let deleted = tokio::fs::remove_file(&path).await.is_ok();
            if !deleted {
                warn!("[RANGE_EVICTION] Failed to delete: key={}, range={}-{}", ck, key.0, key.1);
            }
            (key, file_size, deleted, path)
        }
    })
    .collect();

let results: Vec<_> = stream::iter(delete_tasks)
    .buffer_unordered(32)
    .collect()
    .await;
```

The per-object metadata lock is held for the entire operation (acquired before, released after). Only the file I/O within the lock is parallelized.

### Component 4: Parallel Object Processing in `perform_eviction_with_lock()`

Replace the sequential `for (cache_key, ranges) in &grouped_candidates` loop with concurrent processing:

```rust
use futures::stream::{self, StreamExt};

let object_results: Vec<_> = stream::iter(grouped_candidates.iter())
    .map(|(cache_key, ranges)| {
        let self_ref = &self;
        async move {
            if self_ref.is_cache_entry_active(cache_key).await.unwrap_or(false) {
                debug!("Cache entry {} is active, skipping", cache_key);
                return None;
            }
            match self_ref.batch_evict_ranges(cache_key, ranges).await {
                Ok((bytes_freed, deleted_paths)) => {
                    Some((cache_key.clone(), ranges.clone(), bytes_freed, deleted_paths))
                }
                Err(e) => {
                    warn!("[EVICTION_ERROR] Failed: cache_key={}, error={}", cache_key, e);
                    None
                }
            }
        }
    })
    .buffer_unordered(8)
    .collect()
    .await;

// Aggregate results
for result in object_results.into_iter().flatten() {
    let (cache_key, ranges, bytes_freed, deleted_paths) = result;
    total_bytes_freed += bytes_freed;
    total_ranges_evicted += ranges.len() as u64;
    // ... collect evicted_ranges_for_journal, check metadata deletion, etc.
}
```

Each object acquires its own per-object lock file (via `batch_evict_ranges` → `acquire_write_lock_with_timeout`), so there is no contention between objects being processed concurrently.

### Component 5: Early Exit Check

Add a check at the top of the eviction loop before processing each object:

```rust
for (cache_key, ranges) in &grouped_candidates {
    if total_bytes_freed >= bytes_to_free {
        debug!(
            "Early exit: freed {} >= target {}, skipping remaining objects",
            total_bytes_freed, bytes_to_free
        );
        break;
    }
    // ... existing eviction logic
}
```

With parallel object processing (Component 4), the early exit becomes a filter applied before spawning new work. Since `buffer_unordered` processes items as they arrive, we can track `total_bytes_freed` in the aggregation phase and simply stop collecting once the target is met. However, since objects are processed concurrently, some extra work may happen. This is acceptable — the early exit is a minor optimization.

For simplicity, apply the early exit check in the sequential aggregation loop after parallel processing completes. The parallel processing handles at most `Object_Concurrency_Limit` objects at a time, so the overshoot is bounded.

## Data Models

### Modified Structs

**`JournalConsolidator`** — add one field:
```rust
eviction_in_progress: Arc<AtomicBool>,
```

**`ConsolidationCycleResult`** — no structural changes. The `eviction_triggered` field means "eviction was spawned" and `bytes_evicted` is `0` when eviction runs asynchronously (the actual bytes freed are logged by the spawned task).

### Constants

```rust
/// Maximum concurrent file deletes within a single batch_delete_ranges() call
const FILE_CONCURRENCY_LIMIT: usize = 32;

/// Maximum concurrent objects processed in perform_eviction_with_lock()
const OBJECT_CONCURRENCY_LIMIT: usize = 8;
```

These are defined as module-level constants in `disk_cache.rs` and `cache.rs` respectively.



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Eviction guard prevents concurrent spawns

*For any* sequence of `maybe_trigger_eviction()` calls where the `eviction_in_progress` flag is already `true`, the function should return `(false, 0)` without spawning a new task, regardless of cache size or trigger threshold.

**Validates: Requirements 1.4**

### Property 2: Eviction result aggregation preserves totals

*For any* collection of per-object eviction results `[(bytes_freed_i, ranges_i, paths_i)]`, the aggregated `total_bytes_freed` should equal the sum of all `bytes_freed_i`, `total_ranges_evicted` should equal the sum of all `ranges_i.len()`, and `evicted_ranges_for_journal` should contain exactly the union of all per-object evicted ranges.

**Validates: Requirements 3.3**

### Property 3: Early exit respects bytes_to_free target

*For any* ordered sequence of objects with known `bytes_freed` values and a `bytes_to_free` target, the eviction loop should process objects until `total_bytes_freed >= bytes_to_free`, then stop. The number of objects processed should be the minimum needed to reach the target.

**Validates: Requirements 4.1, 4.2**

## Error Handling

| Scenario | Behavior |
|----------|----------|
| `compare_exchange` fails on eviction guard | Return `(false, 0)`, skip eviction spawn |
| Cache manager weak reference expired | Reset guard to `false`, return `(false, 0)` |
| Spawned eviction task panics | `scopeguard` resets guard to `false` on drop |
| Spawned eviction task returns `Err` | Log at `warn` level, guard reset via `scopeguard` |
| Individual file delete fails in `batch_delete_ranges()` | Log warning, continue with remaining files, mark range for metadata removal |
| `tokio::fs::metadata` fails for file size | Use `0` as file size, proceed with delete |
| Object-level `batch_evict_ranges` fails | Log warning, continue with remaining objects |
| Lock acquisition timeout for per-object lock | Return error for that object, other objects unaffected |

## Testing Strategy

### Property-Based Tests (quickcheck)

Each correctness property is implemented as a single `quickcheck` test with minimum 100 iterations.

- **Property 1**: Generate random `AtomicBool` states (true/false) and random cache sizes. When guard is `true`, verify the function returns `(false, 0)`. When guard is `false` and cache is over threshold, verify it returns `(true, 0)` and sets the guard.
  - Tag: **Feature: eviction-performance, Property 1: Eviction guard prevents concurrent spawns**

- **Property 2**: Generate random vectors of `(u64, usize, Vec<PathBuf>)` tuples representing per-object results. Aggregate them and verify the sums match.
  - Tag: **Feature: eviction-performance, Property 2: Eviction result aggregation preserves totals**

- **Property 3**: Generate random vectors of `u64` values (bytes freed per object) and a random `u64` target. Simulate the early exit loop and verify: (a) total freed >= target, (b) removing the last processed object would make total < target.
  - Tag: **Feature: eviction-performance, Property 3: Early exit respects bytes_to_free target**

### Unit Tests

- **Eviction decoupling**: Test that `maybe_trigger_eviction` returns immediately when guard is set. Test that after spawning, the guard is `true`. Test that after the spawned task completes, the guard is `false`.
- **Parallel deletes**: Test `batch_delete_ranges` with a mix of existing and missing files. Verify correct `bytes_freed` and that all existing files are deleted.
- **Parallel objects**: Test `perform_eviction_with_lock` with multiple objects. Verify all objects are processed and results aggregated correctly.
- **Early exit**: Test with grouped candidates where the first object frees enough bytes. Verify remaining objects are not processed.

### PBT Library

`quickcheck = "1.0"` and `quickcheck_macros = "1.0"` (already dev-dependencies in `Cargo.toml`).
