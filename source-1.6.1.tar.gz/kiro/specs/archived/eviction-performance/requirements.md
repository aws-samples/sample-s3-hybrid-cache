# Requirements Document

## Introduction

Improve eviction performance in the S3 Proxy (v1.1.35) by addressing three problems observed in v1.1.34 testing: eviction blocks the consolidation cycle for 100+ seconds, sequential NFS file deletes are slow (~10-50ms each), and the eviction loop lacks an early exit check. The changes decouple eviction from consolidation via `tokio::spawn`, parallelize file deletes and object processing, and add an early exit optimization.

## Glossary

- **Consolidation_Cycle**: The periodic task in `JournalConsolidator::run_consolidation_cycle()` that runs every 5 seconds, collects accumulator deltas, processes journal entries, and triggers eviction. Holds the global consolidation lock for its duration.
- **Global_Consolidation_Lock**: An flock-based lock file (`locks/global_consolidation.lock`) that prevents multiple proxy instances from running Consolidation_Cycle simultaneously.
- **Eviction_Task**: The background task that runs `perform_eviction_with_lock()` to free disk cache space when usage exceeds the trigger threshold.
- **Eviction_Guard**: An `AtomicBool` flag on `JournalConsolidator` that prevents multiple concurrent Eviction_Task spawns. Set to `true` before spawning, reset to `false` when the Eviction_Task completes.
- **Batch_Delete**: The operation in `DiskCacheManager::batch_delete_ranges()` that deletes range `.bin` files and updates the `.meta` file for a single cache object.
- **Object_Concurrency_Limit**: The maximum number of cache objects processed concurrently during eviction (8).
- **File_Concurrency_Limit**: The maximum number of `.bin` file deletes executed concurrently within a single Batch_Delete operation (32).

## Requirements

### Requirement 1: Decouple Eviction from Consolidation

**User Story:** As a proxy operator, I want eviction to run as a separate background task, so that the consolidation cycle completes quickly and releases the global lock without waiting for eviction to finish.

#### Acceptance Criteria

1. WHEN the Consolidation_Cycle determines that cache usage exceeds the eviction trigger threshold, THE `maybe_trigger_eviction()` function SHALL spawn the Eviction_Task as a detached `tokio::spawn` task and return immediately
2. WHEN `maybe_trigger_eviction()` spawns an Eviction_Task, THE function SHALL set the Eviction_Guard to `true` before spawning
3. WHEN the Eviction_Task completes (success or failure), THE Eviction_Task SHALL reset the Eviction_Guard to `false`
4. WHEN `maybe_trigger_eviction()` is called and the Eviction_Guard is already `true`, THE function SHALL skip spawning and return immediately
5. THE Eviction_Guard SHALL be an `AtomicBool` field on `JournalConsolidator` using `Ordering::SeqCst` for both load and store operations
6. WHEN the Eviction_Task is spawned, THE `ConsolidationCycleResult` SHALL set `eviction_triggered` to `true` and `bytes_evicted` to `0`
7. WHEN the Eviction_Task fails, THE Eviction_Task SHALL log the error at `warn` level and reset the Eviction_Guard to `false`

### Requirement 2: Parallel File Deletes Within Batch_Delete

**User Story:** As a proxy operator, I want range file deletes to execute concurrently within each object's Batch_Delete, so that NFS latency does not cause sequential 10-50ms delays per file.

#### Acceptance Criteria

1. WHEN `batch_delete_ranges()` deletes range `.bin` files, THE function SHALL use `tokio::fs::remove_file` (async) instead of `std::fs::remove_file` (sync)
2. WHEN `batch_delete_ranges()` deletes multiple range files, THE function SHALL execute deletes concurrently using `futures::stream::FuturesUnordered` with a concurrency limit of File_Concurrency_Limit (32)
3. WHEN `batch_delete_ranges()` retrieves file sizes before deletion, THE function SHALL use `tokio::fs::metadata` (async) instead of `std::fs::metadata` (sync)
4. WHEN a concurrent file delete fails, THE function SHALL log a warning and continue processing remaining files
5. THE per-object metadata lock SHALL remain held for the entire Batch_Delete operation — files are deleted in parallel, then metadata is updated once after all deletes complete

### Requirement 3: Parallel Object Processing During Eviction

**User Story:** As a proxy operator, I want multiple cache objects to be evicted concurrently, so that the total eviction wall-clock time is reduced when evicting ranges across many objects.

#### Acceptance Criteria

1. WHEN `perform_eviction_with_lock()` processes grouped eviction candidates, THE function SHALL process multiple objects concurrently using `futures::stream::buffer_unordered` with Object_Concurrency_Limit (8)
2. WHEN processing objects concurrently, each object's Batch_Delete SHALL acquire its own per-object lock file independently
3. WHEN all concurrent object evictions complete, THE function SHALL aggregate `bytes_freed`, `deleted_paths`, and `evicted_ranges_for_journal` from all objects
4. WHEN a concurrent object eviction fails, THE function SHALL log a warning and continue processing remaining objects
5. THE accumulator subtract operations and journal entry collection SHALL happen after each object's Batch_Delete completes, collected into shared vectors after all objects finish

### Requirement 4: Early Exit Check in Eviction Loop

**User Story:** As a proxy operator, I want eviction to stop processing objects once enough bytes have been freed, so that unnecessary file deletes are avoided when actual file sizes exceed compressed_size estimates.

#### Acceptance Criteria

1. WHEN `perform_eviction_with_lock()` iterates over grouped eviction candidates, THE function SHALL check `total_bytes_freed >= bytes_to_free` before processing each object
2. WHEN `total_bytes_freed >= bytes_to_free`, THE function SHALL skip remaining objects and proceed to the accumulator subtract and journal entry phase
3. THE early exit check SHALL use the `bytes_to_free` value calculated at the start of `perform_eviction_with_lock()`

### Requirement 5: Version and Documentation Updates

**User Story:** As a proxy operator, I want the version bumped and changelog updated, so that the release is properly tracked.

#### Acceptance Criteria

1. THE `Cargo.toml` version SHALL be updated from `1.1.34` to `1.1.35`
2. THE `CHANGELOG.md` SHALL contain a v1.1.35 entry describing the three eviction performance improvements
3. THE `docs/size_tracking_part3.md` SHALL be updated with implementation status for the three proposed fixes
