# Implementation Plan: Eviction Performance

## Overview

Three independent eviction performance improvements implemented incrementally: decouple eviction from consolidation (highest priority), parallel NFS deletes, and early exit check. Each change is self-contained and testable.

## Tasks

- [x] 1. Decouple eviction from consolidation
  - [x] 1.1 Add `eviction_in_progress: Arc<AtomicBool>` field to `JournalConsolidator` struct in `src/journal_consolidator.rs`
    - Add `use std::sync::atomic::{AtomicBool, Ordering};` import (AtomicBool not yet imported in this file)
    - Add `eviction_in_progress: Arc<AtomicBool>` field to the struct
    - Initialize to `Arc::new(AtomicBool::new(false))` in `JournalConsolidator::new()`
    - _Requirements: 1.5_

  - [x] 1.2 Rewrite `maybe_trigger_eviction()` in `src/journal_consolidator.rs` to spawn eviction as a detached task
    - Check `eviction_in_progress.compare_exchange(false, true, SeqCst, SeqCst)` — if fails, return `(false, 0)`
    - Clone `Arc<CacheManager>` from weak reference and `Arc<AtomicBool>` for the spawned closure
    - `tokio::spawn` the eviction task with `scopeguard::guard` to reset the flag on all exit paths
    - Return `(true, 0)` immediately after spawning
    - Reset guard to `false` on early exits (lock failure, weak reference expired)
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.6, 1.7_

  - [x] 1.3 Write property test for eviction guard (Property 1)
    - **Property 1: Eviction guard prevents concurrent spawns**
    - Generate random `bool` states for the guard and random `u64` cache sizes. When guard is `true`, verify the function skips. When guard is `false` and over threshold, verify it returns `(true, 0)`.
    - **Validates: Requirements 1.4**

  - [x] 1.4 Write unit tests for eviction decoupling
    - Test `maybe_trigger_eviction` returns `(false, 0)` when guard is already `true`
    - Test `maybe_trigger_eviction` returns `(true, 0)` when over threshold and guard is `false`
    - Test guard is `true` immediately after spawn, `false` after task completes
    - _Requirements: 1.1, 1.2, 1.3, 1.6_

- [x] 2. Checkpoint - Verify eviction decoupling
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Parallel file deletes in `batch_delete_ranges()`
  - [x] 3.1 Convert sequential file deletes to parallel in `DiskCacheManager::batch_delete_ranges()` in `src/disk_cache.rs`
    - Add `use futures::stream::{self, StreamExt};` import
    - Replace the sequential `for range_spec in &metadata.ranges` loop that does `std::fs::metadata` + `std::fs::remove_file` with `stream::iter(...).buffer_unordered(32)` using `tokio::fs::metadata` and `tokio::fs::remove_file`
    - Collect results into `bytes_freed`, `deleted_paths`, `ranges_deleted` vectors after all futures complete
    - Keep the per-object metadata lock held for the entire operation (no change to lock acquire/release)
    - Define `const FILE_CONCURRENCY_LIMIT: usize = 32;` at module level in `disk_cache.rs`
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

  - [x] 3.2 Write unit tests for parallel file deletes
    - Test `batch_delete_ranges` with multiple range files — verify all deleted and bytes_freed correct
    - Test with some missing files — verify warning logged, remaining files still deleted
    - _Requirements: 2.1, 2.4_

- [x] 4. Parallel object processing in `perform_eviction_with_lock()`
  - [x] 4.1 Convert sequential object loop to parallel in `CacheManager::perform_eviction_with_lock()` in `src/cache.rs`
    - Add `use futures::stream::{self, StreamExt};` import
    - Replace the sequential `for (cache_key, ranges) in &grouped_candidates` loop with `stream::iter(...).buffer_unordered(8)`
    - Each concurrent task calls `is_cache_entry_active` and `batch_evict_ranges` for one object
    - Collect per-object results, then aggregate `total_bytes_freed`, `total_ranges_evicted`, `evicted_ranges_for_journal`, `all_deleted_paths` in a sequential loop after all futures complete
    - Define `const OBJECT_CONCURRENCY_LIMIT: usize = 8;` at module level in `cache.rs`
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

  - [x] 4.2 Write property test for eviction result aggregation (Property 2)
    - **Property 2: Eviction result aggregation preserves totals**
    - Generate random vectors of `(u64, usize)` tuples (bytes_freed, range_count). Aggregate and verify sums match.
    - **Validates: Requirements 3.3**

- [x] 5. Checkpoint - Verify parallel processing
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Early exit check in eviction loop
  - [x] 6.1 Add early exit check in `perform_eviction_with_lock()` in `src/cache.rs`
    - In the aggregation loop (after parallel object processing completes), add `if total_bytes_freed >= bytes_to_free { break; }` before processing each object result
    - Log at debug level when early exit triggers
    - _Requirements: 4.1, 4.2, 4.3_

  - [x] 6.2 Write property test for early exit (Property 3)
    - **Property 3: Early exit respects bytes_to_free target**
    - Generate random vectors of `u64` (bytes freed per object) and a random `u64` target. Simulate the loop and verify: total freed >= target, and removing the last object would make total < target.
    - **Validates: Requirements 4.1, 4.2**

  - [x] 6.3 Write unit test for early exit
    - Test with grouped candidates where first object frees enough — verify remaining objects skipped
    - _Requirements: 4.1, 4.2_

- [x] 7. Version bump and documentation
  - [x] 7.1 Update `Cargo.toml` version from `1.1.34` to `1.1.35`
    - _Requirements: 5.1_

  - [x] 7.2 Add v1.1.35 entry to `CHANGELOG.md`
    - Describe the three eviction performance improvements: decoupled eviction, parallel NFS deletes, early exit check
    - _Requirements: 5.2_

  - [x] 7.3 Update `docs/size_tracking_part3.md` with implementation status
    - Add a section noting the three proposed fixes from the "Eviction Performance and Over-Eviction Analysis" section have been implemented in v1.1.35
    - _Requirements: 5.3_

- [x] 8. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- The three core changes (tasks 1, 3, 4/6) are independent and can be implemented in any order
- `futures = "0.3"` and `quickcheck = "1.0"` are already in Cargo.toml — no new dependencies
- Property tests validate universal correctness properties; unit tests validate specific examples and edge cases
