# HTTPS_PROXY Caching Limitation

## Summary

The S3 proxy cannot cache HTTPS traffic routed via `HTTPS_PROXY` without implementing TLS interception (MITM). This document explains why, and what would be required to support it in the future.

HTTPS_PROXY traffic continues to use the existing TCP passthrough mode — the proxy relays encrypted bytes without inspection. This preserves end-to-end encryption but provides no caching benefit.

## How HTTPS_PROXY Works

When a client sets `HTTPS_PROXY=http://proxy-host:443` (or `https://proxy-host:443`), the following sequence occurs:

### Step 1: Client connects to proxy

The client establishes a TCP connection to the proxy. If the HTTPS_PROXY URL uses `https://`, the client first does a TLS handshake with the proxy using the proxy's hostname. This outer TLS connection encrypts the client-to-proxy channel.

### Step 2: Client sends CONNECT request

Over the (optionally encrypted) connection to the proxy, the client sends a plaintext HTTP CONNECT request:

```
CONNECT s3.eu-west-1.amazonaws.com:443 HTTP/1.1
Host: s3.eu-west-1.amazonaws.com:443
```

This tells the proxy to establish a TCP tunnel to the target host.

### Step 3: Proxy responds 200

The proxy responds with `200 Connection Established`, indicating the tunnel is ready. At this point, the proxy is acting as a transparent TCP relay.

### Step 4: Client does inner TLS handshake with the target

This is the critical step. The client initiates a **second** TLS handshake **through the tunnel**. The client believes it is talking directly to `s3.eu-west-1.amazonaws.com` and expects to receive a valid certificate for that hostname.

```
Client                    Proxy (tunnel)              S3
  |                           |                        |
  |--- TLS ClientHello ------>|--- relay bytes ------->|
  |    SNI: s3.eu-west-1...   |                        |
  |<-- TLS ServerHello -------|<-- relay bytes ---------|
  |    cert: *.amazonaws.com  |                        |
  |--- TLS Finished --------->|--- relay bytes ------->|
  |<-- TLS Finished ----------|<-- relay bytes ---------|
  |                           |                        |
  |== encrypted HTTP ========>|== relay bytes ========>|
  |   GET /bucket/key         |   (opaque to proxy)   |
```

In passthrough mode, the proxy relays these TLS handshake bytes without inspection. The client validates S3's real certificate, the TLS session is established end-to-end, and all subsequent HTTP traffic is encrypted. The proxy sees only opaque bytes — it cannot read the request path, headers, or response body. No caching is possible.

## Why the Proxy Cannot Simply Read the Decrypted Traffic

The inner TLS handshake is between the client and S3. The proxy does not possess S3's private key and cannot decrypt the traffic. The proxy is just a byte relay at this point.

## What TLS Termination Would Require

For the proxy to cache HTTPS_PROXY traffic, it would need to **intercept** the inner TLS handshake — answering the client's TLS ClientHello instead of relaying it to S3. This is commonly called TLS interception or MITM (man-in-the-middle) proxying.

### The Certificate Problem

When the client sends a TLS ClientHello with SNI `s3.eu-west-1.amazonaws.com`, it expects a certificate valid for that hostname. The proxy cannot:

- Use S3's real certificate (it doesn't have S3's private key)
- Use a certificate for the proxy's own hostname (SNI mismatch — client rejects it)
- Use a wildcard `*.amazonaws.com` certificate (not obtainable from a public CA, and doesn't cover S3-compatible services like MinIO)

### The Solution: Dynamic Certificate Generation

The standard approach (used by mitmproxy, Charles Proxy, Fiddler) is:

1. Operator generates a custom Certificate Authority (CA)
2. Operator installs the CA certificate in the client's trust store
3. When the proxy intercepts a CONNECT tunnel, it extracts the SNI hostname from the client's TLS ClientHello
4. The proxy dynamically generates a certificate for that hostname, signed by the custom CA
5. The client accepts the certificate because it trusts the CA
6. The proxy decrypts the traffic, applies caching, and forwards to S3 over a separate HTTPS connection

### Implementation Requirements

- Dynamic certificate generation per SNI hostname (the `rcgen` crate supports this)
- In-memory certificate cache (keyed by hostname) to avoid regenerating on every connection
- Configuration for CA certificate and CA private key paths
- Client-side trust store setup (installing the CA cert on every client machine)

### Flow with TLS Termination

```
Client                    Proxy                        S3
  |                           |                        |
  |--- CONNECT s3.region:443->|                        |
  |<-- 200 Connected ---------|                        |
  |                           |                        |
  |--- TLS ClientHello ------>|                        |
  |    SNI: s3.region.aws     |                        |
  |                           | (generate cert for     |
  |                           |  s3.region.aws,        |
  |                           |  signed by custom CA)  |
  |<-- TLS ServerHello -------|                        |
  |    cert: s3.region.aws    |                        |
  |    (signed by custom CA)  |                        |
  |--- TLS Finished --------->|                        |
  |<-- TLS Finished ----------|                        |
  |                           |                        |
  |-- GET /bucket/key ------->| (plaintext, cacheable) |
  |   Host: s3.region.aws     |                        |
  |   Authorization: AWS4-... |                        |
  |                           |--- check cache         |
  |                           |--- GET /bucket/key --->|
  |                           |<-- 200 OK + body ------|
  |                           |--- store in cache      |
  |<-- 200 OK + body ---------|                        |
```

## Why This Is Deferred

1. **Complexity**: Dynamic cert generation, SNI extraction from raw TLS bytes, and certificate caching add significant implementation surface
2. **Operational burden**: Every client machine must install and trust the custom CA — this is a deployment and security policy decision
3. **HTTP_PROXY covers the primary use case**: On private networks where the proxy is co-located with clients, the unencrypted client-to-proxy leg of HTTP_PROXY is acceptable, and full caching works without any certificate infrastructure
4. **Security implications**: TLS interception is a sensitive capability that requires careful implementation to avoid introducing vulnerabilities

## Current Behavior

HTTPS_PROXY traffic uses TCP passthrough (existing behavior). The proxy relays encrypted bytes between client and S3 without inspection. No caching occurs, but end-to-end encryption is preserved and no certificate configuration is needed.

## Client Configuration (Current)

```bash
export HTTP_PROXY=http://proxy-host:80    # Cached (this spec)
export HTTPS_PROXY=http://proxy-host:443  # TCP passthrough, no caching
export NO_PROXY=169.254.169.254           # Exclude IMDS
```

Clients wanting cached access should use HTTP endpoints:
```bash
aws s3 cp s3://bucket/key ./local --endpoint-url http://s3.eu-west-1.amazonaws.com
```

Or use `HTTP_PROXY` which automatically routes HTTP traffic through the proxy with caching.
