# Requirements: HTTP Proxy Protocol Support

## Introduction

This feature adds standard HTTP forward proxy support to the S3 proxy, enabling clients to route S3 traffic through the proxy using the `HTTP_PROXY` environment variable. This eliminates the need for DNS routing or `/etc/hosts` manipulation on client machines.

When `HTTP_PROXY=http://proxy-host:80` is set, the AWS CLI sends plain HTTP requests to the proxy using absolute URIs. The proxy inspects the request, applies caching logic, and forwards to S3 over HTTPS. The SigV4 signature remains valid because the client signs against the real S3 hostname (in the `Host` header), which the proxy preserves when forwarding.

### Scope: HTTP_PROXY Only

This spec covers HTTP_PROXY mode only. HTTPS_PROXY with TLS termination (enabling caching for HTTPS traffic) is explicitly out of scope. See `https-proxy-limitation.md` in this directory for a detailed explanation of why HTTPS_PROXY caching requires TLS interception (dynamic certificate generation) and is deferred to a future iteration.

Without TLS termination, HTTPS_PROXY traffic continues to use the existing TCP passthrough mode (no caching). HTTP_PROXY provides full caching capability — the only trade-off is that the client-to-proxy leg is unencrypted, which is acceptable on private networks where the proxy is co-located with clients.

## Background: How HTTP_PROXY Works

When `HTTP_PROXY=http://proxy-host:port` is set, the AWS CLI sends plain HTTP requests to the proxy using absolute URIs:

```
GET http://s3.eu-west-1.amazonaws.com/bucket/key HTTP/1.1
Host: s3.eu-west-1.amazonaws.com
Authorization: AWS4-HMAC-SHA256 Credential=.../SignedHeaders=host;...
```

The proxy receives the full target URL in the request line. It extracts the target host from the URI authority, strips the scheme and authority to get the path, and processes the request through the existing caching pipeline. When forwarding to S3, the proxy uses HTTPS and preserves the original `Host` and `Authorization` headers so the SigV4 signature remains valid.

### SigV4 Compatibility

SigV4 signs the `Host` header using the hostname from the request endpoint. When using `HTTP_PROXY`, the AWS CLI sets `Host: s3.eu-west-1.amazonaws.com` (the real S3 hostname), not the proxy hostname. The proxy preserves this header when forwarding, so S3 validates the signature successfully.

This is different from `--endpoint-url http://proxy-ip:80`, where the signature would be computed against `Host: proxy-ip` and S3 would reject it.

## Glossary

- **HTTP_PROXY mode**: Client sends plain HTTP requests with absolute URIs to the proxy
- **Absolute URI**: Full URL in the request line, e.g., `GET http://s3.amazonaws.com/bucket/key`
- **Target_Host**: The hostname extracted from the absolute URI's authority component
- **Direct mode**: Existing behavior where clients use DNS/hosts routing and send relative URIs

## Requirements

### Requirement 1: Absolute URI Detection and Host Extraction

**User Story:** As a developer, I want to set `HTTP_PROXY=http://proxy-host:80` so that S3 traffic is routed through the proxy and cached without any DNS configuration.

#### Acceptance Criteria

1. WHEN a client sends a request with an absolute URI (e.g., `GET http://s3.amazonaws.com/bucket/key`), THE proxy SHALL detect it as an HTTP proxy protocol request
2. WHEN processing an HTTP proxy request, THE proxy SHALL extract Target_Host from the absolute URI's authority component
3. WHEN processing an HTTP proxy request, THE proxy SHALL extract the path and query string from the absolute URI for cache key generation and downstream processing
4. WHEN a request URI is relative (no scheme/authority), THE proxy SHALL process it using existing direct mode behavior (Host header extraction)

### Requirement 2: Request Forwarding and Signature Preservation

**User Story:** As a developer, I want proxy requests forwarded to S3 with my SigV4 signature intact, so that authentication works transparently.

#### Acceptance Criteria

1. WHEN forwarding an HTTP proxy request to S3, THE proxy SHALL connect to Target_Host over HTTPS
2. WHEN forwarding an HTTP proxy request to S3, THE proxy SHALL preserve all original headers including the `Authorization` header byte-for-byte
3. WHEN forwarding an HTTP proxy request to S3, THE proxy SHALL preserve the original `Host` header value
4. WHEN forwarding to S3 fails, THE proxy SHALL return HTTP 502 Bad Gateway with a descriptive error

### Requirement 3: Cache Integration

**User Story:** As a developer, I want proxy requests to use the same cache as direct requests, so that objects cached via one method are served via the other.

#### Acceptance Criteria

1. WHEN an HTTP proxy request targets a cached object, THE proxy SHALL serve from cache
2. WHEN an HTTP proxy request targets an uncached object, THE proxy SHALL fetch from S3 over HTTPS and cache the response
3. WHEN generating a cache key for an HTTP proxy request, THE proxy SHALL use the path component of the absolute URI (identical to direct request cache key generation)
4. Cache keys SHALL be identical for the same object path regardless of whether the request arrived via HTTP_PROXY or direct mode

### Requirement 4: Request Method Support

**User Story:** As a developer, I want all S3 operations to work through HTTP_PROXY, so that I can use the full AWS CLI feature set.

#### Acceptance Criteria

1. THE proxy SHALL support GET requests via HTTP_PROXY with caching
2. THE proxy SHALL support HEAD requests via HTTP_PROXY with caching
3. THE proxy SHALL support PUT requests via HTTP_PROXY with write-through caching
4. THE proxy SHALL support POST requests via HTTP_PROXY (multipart uploads, forwarded without caching)
5. THE proxy SHALL support DELETE requests via HTTP_PROXY with cache invalidation

### Requirement 5: Target Host Compatibility

**User Story:** As a developer, I want HTTP_PROXY to work with any S3-compatible endpoint, so that I can use regional endpoints, dualstack, access points, and third-party S3-compatible services.

#### Acceptance Criteria

1. THE proxy SHALL accept any hostname as Target_Host extracted from the absolute URI
2. THE proxy SHALL preserve the original Target_Host when forwarding to the upstream server
3. THE proxy SHALL resolve Target_Host via DNS for upstream HTTPS connections

### Requirement 6: Logging and Observability

**User Story:** As a system administrator, I want proxy requests logged clearly, so that I can distinguish them from direct requests and troubleshoot issues.

#### Acceptance Criteria

1. THE proxy SHALL log HTTP proxy request detection with method, Target_Host, and path at debug level
2. THE proxy SHALL include cache hit/miss status in access logs for proxy requests (same as direct requests)
3. THE proxy SHALL record proxy requests in metrics (same counters as direct requests)

### Requirement 7: Performance

**User Story:** As a developer, I want HTTP_PROXY requests to perform identically to direct requests after host extraction.

#### Acceptance Criteria

1. THE proxy SHALL reuse the existing caching pipeline for proxy requests (no separate code path after host/URI extraction)
2. THE proxy SHALL use the same connection pooling, streaming, and compression logic for proxy requests

### Requirement 8: Documentation

**User Story:** As a developer or operator, I want documentation that explains how to use HTTP_PROXY with the proxy, so that I can configure clients correctly.

#### Acceptance Criteria

1. README.md SHALL document HTTP_PROXY as a supported routing method alongside DNS-based routing
2. docs/GETTING_STARTED.md SHALL include HTTP_PROXY client configuration instructions (setting the environment variable, NO_PROXY for IMDS)
3. docs/GETTING_STARTED.md SHALL explain when to use HTTP_PROXY vs DNS routing (single-instance simplicity vs multi-instance HA)
4. docs/CONFIGURATION.md SHALL document any new configuration options related to HTTP_PROXY support
