# Implementation Plan

- [x] 1. Write bug condition exploration test
  - **Property 1: Fault Condition** — Access Point Cache Key Collision
  - **CRITICAL**: This test MUST FAIL on unfixed code — failure confirms the bug exists
  - **DO NOT attempt to fix the test or the code when it fails**
  - **NOTE**: This test encodes the expected behavior — it will validate the fix when it passes after implementation
  - **GOAL**: Surface counterexamples that demonstrate cache key collisions for access point requests
  - **Scoped PBT Approach**: Use `quickcheck` to generate random access point names, account IDs, MRAP aliases, and object paths
  - Test that `generate_cache_key(path)` produces identical keys for different regional AP hosts with the same path (collision)
  - Test that `generate_cache_key(path)` produces identical keys for different MRAP hosts with the same path (collision)
  - Test that regional AP and MRAP requests with the same path produce identical keys (cross-type collision)
  - The test assertions should match Expected Behavior: cache keys SHOULD be uniquely prefixed per access point, but on unfixed code they are NOT
  - Create test file `tests/cache_key_access_point_test.rs`
  - Run test on UNFIXED code
  - **EXPECTED OUTCOME**: Test FAILS (this is correct — it proves the bug exists)
  - Document counterexamples found: all AP/MRAP requests with same path produce identical cache key `{path_without_leading_slash}`
  - Mark task complete when test is written, run, and failure is documented
  - _Requirements: 1.1, 1.3, 1.4, 1.6, 1.7_

- [x] 2. Write preservation property tests (BEFORE implementing fix)
  - **Property 2: Preservation** — Regular Request Cache Keys Unchanged
  - **IMPORTANT**: Follow observation-first methodology
  - Observe: `generate_cache_key("/my-bucket/data/file.txt")` returns `my-bucket/data/file.txt` on unfixed code
  - Observe: `generate_cache_key("/key")` returns `key` on unfixed code
  - Write property-based test with `quickcheck`: for all hosts NOT matching `*.s3-accesspoint.*.amazonaws.com` or `*.accesspoint.s3-global.amazonaws.com`, `generate_cache_key(path)` returns `normalize_cache_key(path)` (path with leading slash stripped)
  - Include path-style hosts (`s3.{region}.amazonaws.com`) and virtual-hosted hosts (`{bucket}.s3.{region}.amazonaws.com`)
  - Add to `tests/cache_key_access_point_test.rs`
  - Run tests on UNFIXED code
  - **EXPECTED OUTCOME**: Tests PASS (this confirms baseline behavior to preserve)
  - Mark task complete when tests are written, run, and passing on unfixed code
  - _Requirements: 3.1, 3.2, 3.3, 3.4_

- [x] 3. Implement core fix in `src/cache.rs`

  - [x] 3.1 Add `extract_access_point_prefix` function
    - Add `pub fn extract_access_point_prefix(host: &str) -> Option<String>` to `src/cache.rs`
    - Return `Some("{name}-{account_id}")` for hosts matching `*.s3-accesspoint.*.amazonaws.com`
    - Return `Some("{mrap_alias}")` for hosts matching `*.accesspoint.s3-global.amazonaws.com`
    - Return `None` for all other hosts
    - _Bug_Condition: isBugCondition(input) where host matches AP or MRAP pattern_
    - _Expected_Behavior: extract unique prefix from Host header for cache key namespacing_
    - _Requirements: 2.1, 2.4_

  - [x] 3.2 Modify `generate_cache_key` and related functions to accept `host: Option<&str>`
    - Add `host: Option<&str>` parameter to `generate_cache_key`
    - When host is provided and `extract_access_point_prefix` returns a prefix, produce `{prefix}/{normalized_path}`
    - When no prefix is extracted, behavior is identical to current implementation
    - Propagate `host` parameter through `generate_part_cache_key`, `generate_range_cache_key`, `generate_cache_key_with_params`, `generate_cache_key_from_params`
    - Update internal call sites within `src/cache.rs` that call these functions
    - _Bug_Condition: isBugCondition(input) where host matches AP or MRAP pattern AND cache key lacks prefix_
    - _Expected_Behavior: generate_cache_key(path, Some(host)) produces "{prefix}/{normalized_path}" for AP/MRAP hosts_
    - _Preservation: generate_cache_key(path, Some(host)) produces same result as original for non-AP hosts_
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 3.1, 3.2, 3.3, 3.4_

- [x] 4. Update call sites in `src/http_proxy.rs`
  - Update all ~15 calls to `generate_cache_key`, `generate_part_cache_key`, `generate_range_cache_key`, `generate_cache_key_with_params`, `generate_cache_key_from_params` to pass `Some(&host)`
  - The `host` variable is already in scope at all call sites (from `validate_host_header`)
  - No changes to request forwarding logic — only cache key generation is affected
  - _Preservation: S3 request forwarding continues to use `https://{host}{path}` without modification_
  - _Requirements: 2.1, 2.4, 3.5, 3.6_

- [x] 5. Write unit tests for `extract_access_point_prefix`
  - Test regional AP host: `my-ap-123456789012.s3-accesspoint.us-east-1.amazonaws.com` → `Some("my-ap-123456789012")`
  - Test MRAP host: `mfzwi23gnjvgw.accesspoint.s3-global.amazonaws.com` → `Some("mfzwi23gnjvgw")`
  - Test path-style host: `s3.us-east-1.amazonaws.com` → `None`
  - Test virtual-hosted host: `my-bucket.s3.us-east-1.amazonaws.com` → `None`
  - Test edge cases: empty string, no dots, partial matches
  - Add to `tests/cache_key_access_point_test.rs`
  - _Requirements: 2.1, 2.4, 3.1, 3.2_

- [x] 6. Verify fix checking and preservation tests pass

  - [x] 6.1 Verify bug condition exploration test now passes
    - **Property 1: Expected Behavior** — Access Point Cache Keys Are Uniquely Prefixed
    - **IMPORTANT**: Re-run the SAME test from task 1 — do NOT write a new test
    - The test from task 1 encodes the expected behavior: AP/MRAP requests produce uniquely prefixed cache keys
    - Update test to call `generate_cache_key(path, Some(host))` with the new signature
    - Run bug condition exploration test from step 1
    - **EXPECTED OUTCOME**: Test PASSES (confirms bug is fixed)
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7_

  - [x] 6.2 Verify preservation tests still pass
    - **Property 2: Preservation** — Regular Request Cache Keys Unchanged
    - **IMPORTANT**: Re-run the SAME tests from task 2 — do NOT write new tests
    - Update tests to call `generate_cache_key(path, Some(host))` with the new signature
    - Run preservation property tests from step 2
    - **EXPECTED OUTCOME**: Tests PASS (confirms no regressions)
    - Confirm all tests still pass after fix
    - _Requirements: 3.1, 3.2, 3.3, 3.4_

- [x] 7. Update documentation

  - [x] 7.1 Update `docs/CACHING.md` with access point cache key documentation
    - Add section describing access point and MRAP cache key prefixing
    - Include examples: regional AP host → `{name}-{account_id}/{key}`, MRAP host → `{mrap_alias}/{key}`
    - Document that regular path-style and virtual-hosted requests are unaffected
    - _Requirements: 2.8_

  - [x] 7.2 Update `docs/GETTING_STARTED.md` with access point and MRAP DNS and endpoint requirements
    - Add a new subsection under "Configure DNS Routing" for access point and MRAP usage
    - **Document the endpoint-url requirement**: Unlike regular bucket requests where `AWS_ENDPOINT_URL_S3` transparently routes all traffic, access point requests require `--endpoint-url` per command. The AWS SDK resolves access point ARNs to their own hostnames (e.g., `{name}-{account}.s3-accesspoint.{region}.amazonaws.com`), bypassing `AWS_ENDPOINT_URL_S3`.
    - **Document the simplified endpoint-url approach**: The `--endpoint-url` does NOT need the full access-point-specific hostname. The base regional endpoint works: `--endpoint-url http://s3-accesspoint.{region}.amazonaws.com`. The SDK resolves the ARN from the S3 URI, constructs the correct Host header (e.g., `{name}-{account}.s3-accesspoint.{region}.amazonaws.com`), and uses the `--endpoint-url` only as the connection target. This means one endpoint URL works for ALL access points in a region.
    - Add access point and MRAP entries to the hosts file example (Option A):
      - Regional AP: individual entries per access point `{name}-{account_id}.s3-accesspoint.{region}.amazonaws.com` (hosts files don't support wildcards)
      - MRAP: individual entries per MRAP `{mrap_alias}.accesspoint.s3-global.amazonaws.com`
    - Add access point and MRAP DNS zone configuration to the Route 53 example (Option B):
      - Regional AP zone: `s3-accesspoint.{region}.amazonaws.com` with wildcard CNAME `*.s3-accesspoint.{region}.amazonaws.com`
      - MRAP zone: `accesspoint.s3-global.amazonaws.com` with wildcard CNAME `*.accesspoint.s3-global.amazonaws.com`
    - Note that MRAP requires a single global zone (not per-region) since the endpoint is `s3-global.amazonaws.com`
    - Include example AWS CLI commands showing the simplified `--endpoint-url` usage:
      - `aws s3 cp s3://arn:aws:s3:eu-west-1:123456789012:accesspoint/my-ap/bigfiles/5GB ~/tmp/ --region eu-west-1 --endpoint-url http://s3-accesspoint.eu-west-1.amazonaws.com`
    - Note: the ARN in the S3 URI provides the SDK with all info needed to build the correct Host header and SigV4 signature; the `--endpoint-url` only controls where the HTTP connection goes
    - _Requirements: 2.8_

- [x] 8. Version bump and CHANGELOG
  - Bump version from 1.5.3 to 1.6.0 in `Cargo.toml`
  - Add changelog entry in `CHANGELOG.md` describing the access point and MRAP cache key fix
  - _Requirements: 2.9_

- [x] 9. Checkpoint — Ensure all tests pass
  - Run `cargo test` to verify all tests pass
  - Ensure no regressions in existing test suite
  - Ask the user if questions arise
