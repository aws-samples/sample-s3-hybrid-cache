# Access Point Cache Key Fix — Bugfix Design

## Overview

The S3 proxy generates cache keys from the request path only, ignoring the Host header. For S3 Access Point and MRAP requests, the path contains only the object key (e.g., `/bigfiles/5GB`) without any bucket or access-point identifier. This causes cache key collisions between different access points and between access points and regular bucket requests.

The fix adds a function to extract an access point prefix from the Host header and prepends it to the cache key. Regular (non-access-point) requests are unaffected — their cache keys remain path-only.

## Glossary

- **Bug_Condition (C)**: The request arrives via an S3 Access Point or MRAP (Host header matches an access point pattern), causing the cache key to lack a unique prefix
- **Property (P)**: Cache keys for access point requests are prefixed with the access point identifier, making them unique per endpoint
- **Preservation**: Regular path-style and virtual-hosted-style requests continue to generate cache keys from the path only, with no prefix
- **Regional AP**: S3 Access Point with Host pattern `{name}-{account_id}.s3-accesspoint.{region}.amazonaws.com`
- **MRAP**: Multi-Region Access Point with Host pattern `{mrap_alias}.accesspoint.s3-global.amazonaws.com`
- **`generate_cache_key(path)`**: Static method on `CacheManager` in `src/cache.rs` that produces a cache key by stripping the leading slash from the path
- **`normalize_cache_key(path)`**: Function in `src/disk_cache.rs` that strips the leading slash from a cache key string

## Bug Details

### Fault Condition

The bug manifests when a request arrives through an S3 Access Point (regional or MRAP) and the proxy generates a cache key using only the request path. Since access point requests carry the endpoint identity in the Host header (not the path), the resulting cache key is ambiguous — it matches any other request with the same object path regardless of origin.

**Formal Specification:**
```
FUNCTION isBugCondition(input)
  INPUT: input of type { host: String, path: String }
  OUTPUT: boolean

  LET isRegionalAP = host MATCHES "*.s3-accesspoint.*.amazonaws.com"
  LET isMRAP = host MATCHES "*.accesspoint.s3-global.amazonaws.com"

  RETURN (isRegionalAP OR isMRAP)
         AND generate_cache_key(path) does NOT contain access point identifier from host
END FUNCTION
```

### Examples

- Regional AP request: Host=`my-ap-123456789012.s3-accesspoint.us-east-1.amazonaws.com`, path=`/data/file.txt` → current key: `data/file.txt`, expected key: `my-ap-123456789012/data/file.txt`
- MRAP request: Host=`mfzwi23gnjvgw.accesspoint.s3-global.amazonaws.com`, path=`/data/file.txt` → current key: `data/file.txt`, expected key: `mfzwi23gnjvgw/data/file.txt`
- Two different regional APs requesting `/data/file.txt` → current: both get key `data/file.txt` (collision), expected: distinct keys `ap1-111111111111/data/file.txt` and `ap2-222222222222/data/file.txt`
- Regular path-style request: Host=`s3.us-east-1.amazonaws.com`, path=`/my-bucket/data/file.txt` → key: `my-bucket/data/file.txt` (unchanged)

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- Regular path-style requests (`s3.{region}.amazonaws.com`) generate cache keys from path only: `{bucket}/{key}`
- Regular virtual-hosted-style requests (`{bucket}.s3.{region}.amazonaws.com`) generate cache keys using existing logic
- PUT, DELETE, and other write operations use the same cache key derivation as GET/HEAD for consistent invalidation
- Range and part cache key suffixes (`:range:{start}-{end}`, `:part:{n}`) continue to work identically for non-AP requests
- S3 request forwarding constructs `https://{host}{path}` without modification — no changes to `s3_client.rs`

**Scope:**
All inputs where the Host header does NOT match an access point or MRAP pattern are completely unaffected by this fix. This includes:
- Path-style S3 requests
- Virtual-hosted-style S3 requests
- Any non-S3 host patterns

## Hypothesized Root Cause

The root cause is straightforward: `CacheManager::generate_cache_key(path)` only receives the request path and calls `normalize_cache_key(path)` which strips the leading slash. It has no awareness of the Host header.

For regular S3 requests, the path already contains the bucket name (path-style: `/{bucket}/{key}`) or the bucket is implicit in the virtual-hosted domain and the path contains `/{key}` where the first segment is typically unique enough. But for access point requests, the path is just `/{object_key}` — the access point identity lives entirely in the Host header and is never incorporated into the cache key.

1. **Missing Host Context**: `generate_cache_key` accepts only `path: &str` — it has no `host` parameter and cannot distinguish between different access points
2. **All Call Sites Pass Path Only**: All ~15 call sites in `http_proxy.rs` and internal calls in `cache.rs` pass only the path, never the host
3. **No Access Point Detection**: There is no function anywhere in the codebase that parses the Host header to detect access point patterns or extract identifiers

## Correctness Properties

Property 1: Fault Condition — Access Point Cache Keys Are Uniquely Prefixed

_For any_ request where the Host header matches a regional access point pattern (`*.s3-accesspoint.*.amazonaws.com`) or MRAP pattern (`*.accesspoint.s3-global.amazonaws.com`), the fixed `generate_cache_key` function SHALL produce a cache key prefixed with the access point identifier extracted from the Host header, such that different access points with the same object path produce distinct cache keys.

**Validates: Requirements 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7**

Property 2: Preservation — Regular Request Cache Keys Unchanged

_For any_ request where the Host header does NOT match an access point or MRAP pattern (including regular path-style and virtual-hosted-style S3 hosts), the fixed `generate_cache_key` function SHALL produce the same cache key as the original function, preserving existing cache key generation behavior.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4**

## Fix Implementation

### Changes Required

Assuming our root cause analysis is correct:

**File**: `src/cache.rs`

**Function**: `CacheManager::generate_cache_key` and related functions

**Specific Changes**:

1. **Add `extract_access_point_prefix(host: &str) -> Option<String>` function**: A new standalone function (or associated function on `CacheManager`) that parses the Host header and returns:
   - `Some("{name}-{account_id}")` for regional AP hosts matching `*.s3-accesspoint.*.amazonaws.com`
   - `Some("{mrap_alias}")` for MRAP hosts matching `*.accesspoint.s3-global.amazonaws.com`
   - `None` for all other hosts (regular path-style, virtual-hosted, etc.)

2. **Modify `generate_cache_key(path, host)` signature**: Add an optional `host` parameter (e.g., `host: Option<&str>`) so callers can pass the Host header. When `host` is provided and `extract_access_point_prefix` returns a prefix, prepend it to the normalized path: `{prefix}/{normalized_path}`. When no prefix is extracted, behavior is identical to the current implementation.

3. **Propagate host through `generate_part_cache_key`, `generate_range_cache_key`, `generate_cache_key_with_params`, `generate_cache_key_from_params`**: Add the same optional `host` parameter to all cache key generation functions so the prefix is consistently applied.

4. **Update all call sites in `src/http_proxy.rs`**: All ~11 calls to `CacheManager::generate_cache_key(path)` already have `host` available in scope (from `validate_host_header`). Update each to pass `Some(host.as_str())` or `Some(&host)`.

5. **Update internal call sites in `src/cache.rs`**: Several internal methods call `generate_cache_key(path)` — update these to accept and pass through the host parameter.

**File**: `docs/CACHING.md`

6. **Document access point cache key prefixing**: Add a section describing how access point and MRAP hosts result in prefixed cache keys, with examples of both patterns.

**File**: `Cargo.toml`, `CHANGELOG.md`

7. **Version bump**: Update version from 1.5.3 to 1.6.0 and add changelog entry.

## Testing Strategy

### Validation Approach

The testing strategy follows a two-phase approach: first, surface counterexamples that demonstrate the bug on unfixed code, then verify the fix works correctly and preserves existing behavior.

### Exploratory Fault Condition Checking

**Goal**: Surface counterexamples that demonstrate the bug BEFORE implementing the fix. Confirm that `generate_cache_key` produces identical keys for different access points with the same path.

**Test Plan**: Write unit tests that call `generate_cache_key` with paths that would come from access point requests and verify the keys collide. Run on UNFIXED code to confirm the bug.

**Test Cases**:
1. **Regional AP Collision Test**: Call `generate_cache_key("/data/file.txt")` for two different regional AP hosts — keys will be identical on unfixed code (both `data/file.txt`)
2. **MRAP Collision Test**: Call `generate_cache_key("/data/file.txt")` for two different MRAP hosts — keys will be identical on unfixed code
3. **Cross-Type Collision Test**: Call `generate_cache_key("/data/file.txt")` for a regional AP and an MRAP — keys will be identical on unfixed code
4. **AP vs Regular Collision Test**: Call `generate_cache_key("/bucket/data/file.txt")` for a regular host and `generate_cache_key("/data/file.txt")` for an AP where the AP prefix + path would differ — demonstrates the ambiguity

**Expected Counterexamples**:
- All access point requests with the same object path produce identical cache keys regardless of which access point they come from
- Cause: `generate_cache_key` ignores the Host header entirely

### Fix Checking

**Goal**: Verify that for all inputs where the bug condition holds, the fixed function produces uniquely prefixed cache keys.

**Pseudocode:**
```
FOR ALL input WHERE isBugCondition(input) DO
  result := generate_cache_key_fixed(input.path, Some(input.host))
  prefix := extract_access_point_prefix(input.host)
  ASSERT result STARTS WITH prefix
  ASSERT result == format!("{}/{}", prefix, normalize_cache_key(input.path))
END FOR
```

### Preservation Checking

**Goal**: Verify that for all inputs where the bug condition does NOT hold, the fixed function produces the same result as the original function.

**Pseudocode:**
```
FOR ALL input WHERE NOT isBugCondition(input) DO
  ASSERT generate_cache_key_original(input.path) == generate_cache_key_fixed(input.path, Some(input.host))
END FOR
```

**Testing Approach**: Property-based testing is recommended for preservation checking because:
- It generates many host/path combinations automatically across the input domain
- It catches edge cases in host pattern matching that manual tests might miss
- It provides strong guarantees that non-AP behavior is unchanged

**Test Plan**: Observe behavior on UNFIXED code for regular hosts, then write property-based tests capturing that behavior.

**Test Cases**:
1. **Path-Style Preservation**: For any host matching `s3.{region}.amazonaws.com` and any path, verify cache key equals `normalize_cache_key(path)` (no prefix added)
2. **Virtual-Hosted Preservation**: For any host matching `{bucket}.s3.{region}.amazonaws.com` and any path, verify cache key equals `normalize_cache_key(path)` (no prefix added)
3. **Range/Part Key Preservation**: For non-AP hosts, verify `generate_range_cache_key` and `generate_part_cache_key` produce identical results to the original

### Unit Tests

- Test `extract_access_point_prefix` with regional AP hosts, MRAP hosts, regular hosts, and edge cases
- Test `generate_cache_key` with host parameter for each host pattern
- Test that range and part cache key functions correctly propagate the prefix

### Property-Based Tests

- Generate random access point identifiers and object paths, verify cache keys are uniquely prefixed
- Generate random regular S3 hosts and paths, verify cache keys match original behavior
- Generate pairs of different access points with same path, verify distinct cache keys

### Integration Tests

- End-to-end test with regional AP host header through the HTTP proxy handler chain
- End-to-end test with MRAP host header through the HTTP proxy handler chain
- Test cache invalidation (PUT/DELETE) uses the same prefixed key as GET/HEAD for AP requests
