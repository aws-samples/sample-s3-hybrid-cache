# Bugfix Requirements Document

## Introduction

The S3 proxy generates incorrect cache keys for requests made through S3 Access Points, including both regional access points and Multi-Region Access Points (MRAP). These access point requests use virtual-hosted style where the access point identifier is in the Host header and the path contains only the object key. The proxy's `generate_cache_key()` uses the request path directly, which for access point requests lacks the bucket/access-point prefix. This causes phantom bucket directories in the cache, duplicate cache entries for the same object, and potential cross-access-point data collisions.

Regional access points use Host pattern `{name}-{account}.s3-accesspoint.{region}.amazonaws.com`. MRAP endpoints use a global Host pattern `{mrap_alias}.accesspoint.s3-global.amazonaws.com`, where `mrap_alias` is an opaque string assigned by AWS (e.g., `mfzwi23gnjvgw`). Both suffer from the same cache key bug.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN a request arrives via a regional S3 Access Point (Host header matches `*.s3-accesspoint.*.amazonaws.com`) with path `/bigfiles/5GB` THEN the system generates cache key `bigfiles/5GB`, treating the first path segment `bigfiles` as the bucket name

1.2 WHEN the same object is accessed via both a regular bucket request and a regional access point request THEN the system creates two separate cache entries under different keys (e.g., `egummett-testing-source-1/bigfiles/5GB` vs `bigfiles/5GB`), failing to share cached data

1.3 WHEN two different regional access points on different buckets both request the same object path (e.g., `/data/file.txt`) THEN the system generates identical cache keys (`data/file.txt`), potentially serving data from the wrong bucket

1.4 WHEN a request arrives via a Multi-Region Access Point (Host header matches `*.accesspoint.s3-global.amazonaws.com`) with path `/bigfiles/5GB` THEN the system generates cache key `bigfiles/5GB`, treating the first path segment as the bucket name

1.5 WHEN the same object is accessed via both a regular bucket request and an MRAP request THEN the system creates two separate cache entries under different keys, failing to share cached data

1.6 WHEN two different MRAPs request the same object path (e.g., `/data/file.txt`) THEN the system generates identical cache keys (`data/file.txt`), potentially serving data from the wrong MRAP

1.7 WHEN a regional access point and an MRAP both request the same object path THEN the system generates identical cache keys, potentially serving cross-endpoint data

1.8 WHEN the caching documentation (docs/CACHING.md) describes cache key generation THEN the documentation does not mention access point or MRAP host-based key prefixing

1.9 WHEN the project version is 1.5.3 THEN the version does not reflect the access point and MRAP cache key fix

### Expected Behavior (Correct)

2.1 WHEN a request arrives via a regional S3 Access Point (Host header matches `*.s3-accesspoint.*.amazonaws.com`) with path `/bigfiles/5GB` THEN the system SHALL prefix the cache key with the access point identifier extracted from the Host header, producing a unique cache key that does not collide with regular bucket paths

2.2 WHEN the same object is accessed via both a regular bucket request and a regional access point request THEN the system SHALL generate distinct cache keys for each access method, each correctly scoped to its origin

2.3 WHEN two different regional access points on different buckets both request the same object path (e.g., `/data/file.txt`) THEN the system SHALL generate distinct cache keys for each access point, preventing cross-access-point data serving

2.4 WHEN a request arrives via a Multi-Region Access Point (Host header matches `*.accesspoint.s3-global.amazonaws.com`) with path `/bigfiles/5GB` THEN the system SHALL prefix the cache key with the MRAP alias extracted from the Host header, producing a unique cache key that does not collide with regular bucket paths or regional access point keys

2.5 WHEN the same object is accessed via both a regular bucket request and an MRAP request THEN the system SHALL generate distinct cache keys for each access method, each correctly scoped to its origin

2.6 WHEN two different MRAPs request the same object path (e.g., `/data/file.txt`) THEN the system SHALL generate distinct cache keys for each MRAP, preventing cross-MRAP data serving

2.7 WHEN a regional access point and an MRAP both request the same object path THEN the system SHALL generate distinct cache keys for each endpoint type, preventing cross-endpoint data serving

2.8 WHEN the caching documentation (docs/CACHING.md) describes cache key generation THEN the documentation SHALL be updated to describe access point and MRAP host-based cache key prefixing, including examples of both endpoint formats. WHEN the getting started documentation (docs/GETTING_STARTED.md) describes DNS routing and client configuration THEN the documentation SHALL be updated to describe access point routing through the proxy, including: (a) the requirement for `--endpoint-url` on each access point request since `AWS_ENDPOINT_URL_S3` does not apply to access point ARN resolution, (b) the simplified endpoint approach where `--endpoint-url http://s3-accesspoint.{region}.amazonaws.com` works for all access points in a region (the SDK resolves the ARN and sets the correct Host header, using the endpoint-url only as the connection target), (c) hosts file entries for individual access points, and (d) DNS wildcard zones for `s3-accesspoint.{region}.amazonaws.com` and `accesspoint.s3-global.amazonaws.com`

2.9 WHEN the access point and MRAP cache key fix is applied THEN the project version SHALL be bumped from 1.5.3 to 1.6.0 in Cargo.toml and CHANGELOG.md SHALL be updated with a description of the fix

### Unchanged Behavior (Regression Prevention)

3.1 WHEN a request arrives via regular path-style S3 access (Host is `s3.{region}.amazonaws.com`, path is `/{bucket}/{key}`) THEN the system SHALL CONTINUE TO generate cache key `{bucket}/{key}` from the path

3.2 WHEN a request arrives via regular virtual-hosted-style S3 access (Host is `{bucket}.s3.{region}.amazonaws.com`, path is `/{key}`) THEN the system SHALL CONTINUE TO generate cache keys using the existing logic

3.3 WHEN cache key generation is used for PUT, DELETE, or other write operations THEN the system SHALL CONTINUE TO use the same cache key derivation logic as GET/HEAD so that cache invalidation remains consistent

3.4 WHEN range requests or multipart requests are made via regular (non-access-point) paths THEN the system SHALL CONTINUE TO generate range/part cache keys correctly using the existing suffix format

3.5 WHEN MRAP requests are forwarded to S3 THEN the system SHALL CONTINUE TO reconstruct the upstream URL as `https://{host}{path}` without modification to the forwarding logic

3.6 WHEN regional access point requests are forwarded to S3 THEN the system SHALL CONTINUE TO reconstruct the upstream URL as `https://{host}{path}` without modification to the forwarding logic