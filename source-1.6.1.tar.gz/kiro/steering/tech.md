---
inclusion: fileMatch
fileMatchPattern: "**/*.rs,Cargo.toml,Cargo.lock"
---

# Technology Stack

## Language & Runtime

- **Rust 2021 Edition**: High-performance systems programming
- **Tokio**: Async runtime for concurrent networking
- **Hyper 1.0**: HTTP server and client implementation

## Core Dependencies

If the dependencies change, update LICENSE_COMPLIANCE.md in nonpublic/

### Networking & HTTP
- `hyper` (1.0) - HTTP server/client with full features
- `hyper-util` (0.1) - HTTP utilities
- `http-body-util` (0.1) - HTTP body handling and streaming
- `tokio-rustls` (0.26) - TLS support
- `trust-dns-resolver` (0.23) - DNS resolution
- `futures` (0.3) - Stream utilities for async streaming

### Serialization & Configuration
- `serde` (1.0) - Serialization framework with derive macros
- `serde_json` (1.0) - JSON support
- `serde_yaml` (0.9) - YAML configuration files
- `clap` (4.0) - CLI argument parsing with derive macros

### Caching & Storage
- `lz4_flex` (0.11) - Fast LZ4 compression
- `fs2` (0.4) - File locking for shared cache coordination
- `rand` (0.8) - Random number generation for cache size tracking
- `rayon` (1.8) - Parallel iteration for cache directory scanning
- `walkdir` (2.4) - Recursive directory traversal for cache size calculation

### Observability
- `tracing` (0.1) - Structured logging
- `tracing-subscriber` (0.3) - Log formatting with env-filter and chrono
- `tracing-appender` (0.2) - Log file rotation
- `opentelemetry` (0.24) - OTLP metrics export
- `opentelemetry_sdk` (0.24) - Metrics SDK
- `opentelemetry-otlp` (0.17) - OTLP HTTP protocol with reqwest

### Testing
- `quickcheck` (1.0) - Property-based testing framework
- `quickcheck_macros` (1.0) - Derive macros for property tests
- `tempfile` (3.0) - Temporary file handling in tests
- `tokio-test` (0.4) - Tokio testing utilities

## Build System

**Cargo** - Rust's package manager and build tool

### Common Commands

**Always use `--release` flag** - Debug builds are slow and memory-intensive.

```bash
# Build release binary
cargo build --release

# Run all tests (always use --release)
cargo test --release

# Run with configuration
cargo run --release -- -c config.yaml

# Check for compilation errors (always use --release)
cargo check --release

# Run specific example
cargo run --release --example compression_demo
```

### Build Artifacts

- Binary: `target/release/s3-proxy`
- Examples: `target/release/examples/`

### Target Folder Maintenance

**Keep the target folder clean.** Cargo accumulates build artifacts aggressively.

```bash
# Check target folder size
du -sh target/

# Clean everything except release binary
cargo clean
cargo build --release
```

## Configuration System

Three-layer configuration with precedence:
1. YAML configuration file (base)
2. Environment variables (override)
3. Command-line arguments (highest priority)

### Duration Format

Supports human-readable duration strings:
- Seconds: `"30s"`, `"60sec"`, `"120seconds"`
- Minutes: `"5m"`, `"10min"`, `"30minutes"`
- Hours: `"1h"`, `"2hr"`, `"24hours"`
- Milliseconds: `"500ms"`, `"1000millis"`

### Path Expansion

Configuration paths support tilde expansion (`~/cache` → `/home/user/cache`)

## Testing

### Test Organization

- Unit tests: Inline with source files (`#[cfg(test)]`)
- Integration tests: `tests/` directory
- Examples: `examples/` directory for demonstrations

### Test Execution

**Always use `--release` flag** - Debug builds consume too much memory and get killed by the OS (SIGKILL).

```bash
# All tests (always use --release)
cargo test --release

# Specific test file
cargo test --release --test integration_test

# Single-threaded (if needed for debugging)
cargo test --release -- --test-threads=1
```

## Logging

- **Access Logs**: S3-compatible format in `/logs/access`
- **Application Logs**: Structured tracing logs in `/logs/app/{hostname}/`
- **Log Rotation**: Daily rotation with hostname identification
