# Product Overview

S3 Proxy is a high-performance HTTP/HTTPS proxy server for Amazon S3 and S3-compatible storage services with intelligent caching, range-aware request handling, and comprehensive logging.

## Core Purpose

Acts as a transparent forwarder between clients and S3, providing:
- Multi-tier caching (RAM + disk) to accelerate S3 access
- Streaming response architecture for large files (eliminates buffering)
- LZ4 compression with content-aware detection
- Range request optimization for large files
- Connection pooling with IP load balancing
- Write-through caching for PUT operations
- Multi-instance shared cache coordination

## Key Characteristics

- **Transparent Forwarder**: Proxy only responds to client requests and cannot initiate requests to S3 (no AWS credentials, cannot sign requests)
- **AWS SigV4 Compatible**: Designed to handle AWS CLI signed requests while providing intelligent caching
- **Production-Ready**: All core features implemented and tested with comprehensive test suite
- **Dual Protocol Support**: HTTP (port 80) with caching and HTTPS (port 443) with TCP passthrough
- **Observability**: S3-compatible access logs, application logs, health checks, metrics, and OTLP export

## Deployment Model

- Requires hosts file routing to intercept S3 traffic
- HTTP endpoint URLs force traffic through port 80 for caching
- HTTPS mode: TCP passthrough (direct tunneling without TLS termination)
- Supports multi-instance scale-out with shared cache volumes (EFS/NFS)
