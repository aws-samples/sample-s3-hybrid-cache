# General Development Guidance

## Implementation and Deployment Approval

**CRITICAL**: Do not implement code changes or deploy to production without explicit user approval.

When investigating issues or proposing fixes:
1. **Analyze** the problem and gather evidence
2. **Propose** a solution with explanation of why it should work
3. **Wait** for user approval before implementing
4. **Wait** for user approval before deploying

Only proceed with implementation/deployment when the user explicitly asks (e.g., "go ahead", "implement it", "deploy it").

## Git Authentication

If `git push` fails with `Permission denied (publickey)`, run the following command interactively (it requires user input), then retry the push:

```bash
mwinit -f -k ~/.ssh/id_rsa_gitlab.pub -c ~/.ssh/id_rsa_gitlab-cert.pub
```

## Related Steering Files

These files are automatically included when working on relevant code:

- **#[[file:.kiro/steering/tech.md]]** - Rust, Cargo, dependencies (included when editing `.rs` or `Cargo.toml`)
- **#[[file:.kiro/steering/structure.md]]** - Module layout and responsibilities (included when editing `src/`)
- **#[[file:.kiro/steering/testing.md]]** - Testing guidelines and AWS CLI usage (included when editing `tests/`)
- **#[[file:.kiro/steering/deployment-learnings.md]]** - Deployment procedures (included when editing `nonpublic/deploy/`)
- **#[[file:.kiro/steering/proxy-restart-command.md]]** - Proxy restart command (use `#proxy-restart-command` to include)

## User Interaction Principles

### Critical: Do Not Assume User Correctness

**The user is not always correct.** Do not assume user statements are accurate or state that they are correct unless you have independently verified the information.

#### Guidelines:

1. **Verify Before Agreeing**: When a user makes a technical claim, verify it against:
   - Documentation
   - Code inspection
   - Testing
   - Known facts about the system

2. **Use Neutral Language**: Instead of saying "You're right", "You're absolutely right", "You're correct", or "That's correct", use:
   - "That matches what I see in the code"
   - "The documentation confirms this behavior"
   - "Testing shows this is the case"
   - "Let me verify that..."

3. **Question Assumptions**: If something seems incorrect or unclear:
   - Ask clarifying questions
   - Suggest testing to verify
   - Check relevant documentation or code
   - Propose alternative explanations

4. **Acknowledge When Uncertain**: If you cannot verify a user's claim:
   - "I'd need to check that to be sure"
   - "Let me investigate this further"
   - "That's worth testing to confirm"

## Documentation Standards

### Writing Principles

All documentation must be:
- **Concise**: Use minimal words to convey maximum information
- **Clear**: Avoid ambiguity, use precise technical language
- **Complete**: Cover all necessary information without gaps
- **Direct**: No embellishment, flowery language, or unnecessary elaboration

#### Guidelines:

1. **Structure First**: Lead with the most important information
2. **Use Active Voice**: "The cache stores data" not "Data is stored by the cache"
3. **Eliminate Redundancy**: Don't repeat the same information in different words
4. **Focus on Facts**: State what the system does, not what it "aims to do" or "tries to do"
5. **Use Concrete Examples**: Show actual code, commands, or configurations when helpful

### Avoid Status Indicators

Do not use status markers like "✅ COMPLETE", "Status: IMPLEMENTED", or similar indicators in documentation.

## Command Examples

### Never Use cd with Made-Up Paths

Do not prefix commands with `cd /path/to/project &&` or similar constructs.

### Always Use --no-cli-pager for AWS CLI

When using AWS CLI commands, always include `--no-cli-pager` to prevent interactive pager behavior.

### Put Comments After Commands, Not Before

When providing shell commands with explanatory comments, place the comment after the command on the same line using `#`. This allows commands to be safely copied and run autonomously.

**Correct:**
```bash
aws s3 ls s3://bucket-name/ --no-cli-pager  # List bucket contents
cargo build --release  # Build optimized binary
```

**Incorrect:**
```bash
# List bucket contents
aws s3 ls s3://bucket-name/ --no-cli-pager
# Build optimized binary
cargo build --release
```

## Git Operations

### NEVER Revert Without Stashing First

**CRITICAL**: Never use `git checkout -- <file>` or `git restore <file>` to discard uncommitted changes without first stashing them.

**ALWAYS stash before any revert operation:**

```bash
git stash push -m "backup before revert"
git checkout -- src/file.rs
```

### Commit on Version Bump

**ALWAYS commit when updating version and CHANGELOG:**

```bash
git add Cargo.toml CHANGELOG.md
git commit -m "v1.X.Y: Brief description of changes"
```

### Re-read CHANGELOG Before Version Bump

**ALWAYS re-read `CHANGELOG.md` and `Cargo.toml` immediately before bumping the version.** Other changes may have been committed since you last read them, and writing a stale version or duplicating an entry will cause errors.

A version bump means the version number MUST increase. If the current version is already the target version (e.g., from a previous bump in the same session), increment to the next patch/minor/major as appropriate. Never "bump" to the same version.

## Shell Command Restrictions

### Never Use Inline Python/Ruby/Perl Scripts in Bash

Do not pass multi-line scripts to `python3 -c`, `ruby -e`, or similar interpreters via bash commands. The terminal gets stuck on these. Instead, write the script to a file using `fsWrite` and then execute the file.

**Correct:**
```
# Write script to file first
fsWrite("tmp/script.py", script_content)
# Then execute
executeBash("python3 tmp/script.py")
```

**Incorrect:**
```
executeBash("python3 -c 'import json\n...'")  # Terminal gets stuck
```

## Security Scanning

### Update .gitleaksignore When Modifying Code

When modifying code that contains example AWS credentials (like `AKIAIOSFODNN7EXAMPLE`), update `.gitleaksignore` to suppress false positive findings.
