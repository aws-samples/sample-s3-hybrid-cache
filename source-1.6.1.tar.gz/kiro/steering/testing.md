---
inclusion: fileMatch
fileMatchPattern: "tests/**/*.rs"
---

# Testing Guidelines

## Testing the Proxy

### DO NOT use curl for testing
- The proxy requires AWS SigV4 signed requests
- curl cannot generate proper AWS signatures
- curl requests will fail with authentication errors

### Use AWS CLI instead
Always use the AWS CLI for testing proxy functionality:

```bash
# Download a file through the proxy
aws s3 cp s3://bucket-name/path/to/file.txt ./local-file.txt

# List bucket contents
aws s3 ls s3://bucket-name/

# Sync directories
aws s3 sync s3://bucket-name/prefix/ ./local-dir/
```

### Why AWS CLI is Required
1. The proxy is a transparent forwarder that requires valid AWS signatures
2. AWS CLI automatically signs all requests with SigV4
3. The proxy validates and forwards these signed requests to S3
4. Without proper signatures, requests are rejected

### Testing Cache Behavior
To test cache hits and performance:

```bash
# First request (cache miss, fetches from S3)
time aws s3 cp s3://bucket/large-file.zip ./test1.zip

# Second request (cache hit, served from cache)
time aws s3 cp s3://bucket/large-file.zip ./test2.zip

# Check logs for "RAM cache HIT" or "Disk cache HIT" messages
```

## Testing Header Consistency

### Comparing Proxy vs Direct S3 Responses
Use `aws s3api` commands to compare headers between proxy and direct S3:

```bash
# Test through proxy (HTTP)
aws s3api get-object --bucket bucket-name --key path/to/file.txt \
  --endpoint http://s3.eu-west-1.amazonaws.com ~/output.txt

# Test direct to S3 (HTTPS bypasses proxy)
aws s3api get-object --bucket bucket-name --key path/to/file.txt \
  --endpoint https://s3.eu-west-1.amazonaws.com ~/output.txt
```

### Testing PUT then GET Flow
Test that headers from PUT operations are returned on subsequent GETs:

```bash
# Single-part upload
aws s3api put-object --bucket bucket-name --key test.txt \
  --endpoint http://s3.eu-west-1.amazonaws.com --body ./local-file.txt

# GET should return same headers as PUT response
aws s3api get-object --bucket bucket-name --key test.txt \
  --endpoint http://s3.eu-west-1.amazonaws.com ~/output.txt
```

### Inspecting Cache Metadata
View stored cache metadata to debug header issues:

```bash
# Find cache metadata files
find ./tmp/cache/metadata -name "*.meta" -exec cat {} \;

# Check specific object metadata
cat ./tmp/cache/metadata/bucket-name/XX/YYY/object-key.meta | jq .
```

## Cache Management for Testing

### Clearing Cache
When testing cache-related changes, clear the cache before restarting:

```bash
# Clear entire cache directory
sudo rm -rf ./tmp/cache/*

# Or clear specific object
sudo rm -f ./tmp/cache/metadata/bucket-name/XX/YYY/object-key.meta
sudo rm -f ./tmp/cache/ranges/bucket-name%2Fobject-key_*.bin
```

### Prompting User for Restart
When code changes require testing with a fresh cache:
1. Build the new code: `cargo build --release`
2. Ask user: "The proxy needs to be restarted with cache cleared. Would you like me to provide the commands, or would you prefer to do it yourself?"
3. If user wants commands:
   ```bash
   # Stop proxy (Ctrl+C in terminal running it)
   sudo rm -rf ./tmp/cache/*
   sudo cargo run --release -- -c config/config.example.yaml
   ```

## Header Storage Guidelines

### Store Original Headers Only
Cache metadata should store original `x-amz-*` headers as received from S3:
- **DO**: Store `x-amz-server-side-encryption: AES256`
- **DON'T**: Store normalized `ServerSideEncryption: AES256`

### Header Flow
1. S3 returns: `x-amz-server-side-encryption: AES256`
2. Proxy stores in cache: `x-amz-server-side-encryption: AES256`
3. Proxy returns to client: `x-amz-server-side-encryption: AES256`
4. AWS CLI displays: `ServerSideEncryption: AES256`

## Testing Guidelines (from tech.md)

**Write Caching Tests:**
- Do not test write caching features unless write caching is part of the change
- Write caching is a complete feature and enabled by default
- Only include write cache tests when the change directly modifies write caching functionality

**Read Caching Tests:**
- Read caching tests remain required for all changes that affect caching behavior
- Always test GET and HEAD operations when modifying cache logic
- Range request handling tests are required for changes affecting range operations
- Cache invalidation tests are required when modifying cache consistency logic
