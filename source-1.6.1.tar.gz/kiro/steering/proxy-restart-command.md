---
inclusion: manual
---

# Proxy Restart Command

When the user asks to "restart the proxy", always use this command:

```bash
sudo cargo run --release -- -c config/config.example.yaml
```

This runs the proxy:
- With sudo (required for ports 80/443)
- In release mode (optimized)
- Using config/config.example.yaml
- In foreground (not as daemon, not to /dev/null)

The proxy will run until Ctrl+C is pressed.

If kiro needs to restart the proxy, it will ask the user whether to do so. The user may prefer to do it themselves.
