---
inclusion: manual
---

# Probe Scan Handling

Guidance for handling Probe security scan findings during version bumps and releases.

## Probe Overview

Probe is an AWS internal SAST tool that bundles multiple open-source scanners (bandit, cfn-nag, checkov, gitleaks, semgrep) and runs on every GitLab push.

## Filtering Findings

When reviewing Probe scan exports:

1. **Ignore nonpublic/ directory**: All findings in `nonpublic/` can be ignored (deployment scripts, test utilities, performance tests)
2. **Focus on src/, examples/, docs/, config/**: These are the production/public code paths

## Common False Positives

### Example AWS Credentials

Semgrep flags example AWS credentials like `AKIAIOSFODNN7EXAMPLE` used in:
- Test code (`src/signed_request_proxy.rs`)
- Example programs (`examples/presigned_url_demo.rs`)
- Documentation (`archived/docs/`, `.kiro/specs/`)
- Steering files (`.kiro/steering/general-guidance.md`)

**Suppression**: Use `.semgrepignore` to exclude files with intentional example credentials.

### Gitleaks in .gitleaksignore

Gitleaks and semgrep both flag example patterns in `.gitleaksignore` itself. This is expected and can be ignored or suppressed via `.semgrepignore`.

### Intentional Unsafe Rust

Semgrep flags `unsafe` blocks in performance-critical code:
- `src/metadata_lock_manager.rs` - Lock-free atomic operations
- `src/cache_initialization_coordinator.rs` - Shared memory coordination
- `src/tcp_proxy.rs` - Zero-copy TCP forwarding
- `src/https_connector.rs` - Low-level socket operations

These are intentional, audited, and necessary for performance. Document safety invariants in comments if adding new unsafe blocks.

## Suppression Files

- `.gitleaksignore` - Suppresses gitleaks findings (secrets scanner)
- `.semgrepignore` - Suppresses semgrep findings (pattern-based SAST)
- Inline comments - Use `# nosemgrep: rule-id` or `# nosec` for tool-specific suppressions

## Pre-Release Checklist

Before version bump:
1. Export latest Probe scan from GitLab
2. Filter out `nonpublic/` findings: `grep -v "nonpublic/" scan.csv`
3. Review remaining findings for actual security issues
4. Update suppression files if new false positives appear
5. Document any new intentional unsafe blocks
