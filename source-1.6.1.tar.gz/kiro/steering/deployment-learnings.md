---
inclusion: fileMatch
fileMatchPattern: "nonpublic/deploy/**,tmp/ssm-commands/**"
---

# Deployment Learnings

## Git Authentication

If git returns "permission denied" errors, run the following command interactively (it requires user input to complete):

```bash
mwinit -f -k ~/.ssh/id_rsa_gitlab.pub -c ~/.ssh/id_rsa_gitlab-cert.pub
```

## Critical Requirements

### Root Privileges Required
- **S3 proxy MUST run as root** to bind to ports 80 and 443
- Service failures with status 203/EXEC or 1/FAILURE often indicate permission issues
- Always use `sudo` when running the proxy binary directly
- SystemD service automatically runs as root when properly configured

### DNS Routing Conflicts
- Hosted zones for S3 endpoints can conflict with AWS CLI S3 access during deployment
- **Solution**: Use S3 dualstack endpoints (`https://s3.dualstack.region.amazonaws.com`) to bypass DNS routing and use presigned URLs for deployment file transfers
- **Critical**: Always specify `--region` flag when using AWS CLI with deployment bucket to avoid redirect errors

### Configuration Requirements
- **FIXED**: Proxy now uses sensible defaults for missing config fields
- **Critical field resolved**: `server.max_concurrent_requests` defaults to 200 if not specified
- Config validation happens at startup, not runtime
- Minimal config files now work - only essential paths (cache_dir, log dirs) required
- All config structs have Default implementations with production-ready values

### NFS/EFS Mount Requirements for Multi-Instance Deployments
- **CRITICAL**: For reliable multi-instance cache coordination, EFS/NFS MUST be mounted with `lookupcache=pos`
- **Why**: NFS clients cache directory entry lookups. Without this option, instances cache "file not found" results and don't see files created by other instances, causing 40%+ cache miss rate on repeat downloads
- **Why `pos` not `none`**: `lookupcache=none` disables all lookup caching which degrades cache hit performance. `lookupcache=pos` caches positive lookups (file exists) but not negative lookups (file not found), giving both good performance and immediate visibility of new files.
- **Mount command**: Use direct NFS4 mount to support lookupcache option
- **Example /etc/fstab**:
  ```
  fs-XXXXX.efs.region.amazonaws.com:/ /mnt/efs nfs4 nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2,noresvport,lookupcache=pos,_netdev 0 0
  ```

### NFS Log File Clearing
- **CRITICAL**: Do NOT use `rm -rf` to clear log files while the proxy is running
- **Why**: NFS performs a "silly rename" when deleting files that are still open
- **Correct approach**: Either restart the proxy after clearing logs, or truncate instead of delete

### Cache Clearing Must Include Size Tracking
- **CRITICAL**: When clearing the cache, you MUST also clear the `size_tracking/` directory
- **Why**: The `size_state.json` file tracks total cache size. If you clear cache files but not this file, the proxy will report incorrect size (e.g., 1.5GB tracked vs 0 bytes actual)
- **Correct approach**: Clear the entire cache directory including all subdirectories:
  ```bash
  sudo rm -rf /mnt/efs/cache/*
  ```
- **If size_state.json was not cleared**: Stop proxy, delete `size_tracking/size_state.json`, restart proxy. The proxy will recalculate size on next validation scan.

## Timestamp Interpretation

### Always Compare Timestamps to Current System Time
When reviewing logs, SSM command output, or any timestamped data, always check the current system time to understand the temporal context:

```bash
# Get current UTC time (matches AWS log timestamps)
date -u '+%Y-%m-%d %H:%M:%S UTC'

# Get current local time with timezone
date '+%Y-%m-%d %H:%M:%S %Z'
```

**Why this matters:**
- Log timestamps without context can be misleading - a "recent" log entry might be hours or days old
- SSM command output includes timestamps that need comparison to current time to determine if they reflect current state
- Cache state, eviction events, and consolidation logs are only meaningful when you know how old they are
- Instance health checks and service status are point-in-time snapshots

**When interpreting timestamps:**
1. First establish current time: `date -u`
2. Compare log/output timestamps to current time
3. Consider timezone differences (AWS logs typically use UTC)
4. Determine if the data reflects current state or historical state

**Example workflow:**
```bash
# Check current time first
echo "Current time: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"

# Then check logs - compare timestamps to current time above
aws ssm send-command --region us-west-2 --instance-ids i-INSTANCE1 \
  --document-name "AWS-RunShellScript" \
  --parameters '{"commands":["date -u","journalctl -u s3-proxy --since \"5 minutes ago\" --no-pager | tail -20"]}' \
  --output text --query 'Command.CommandId' --no-cli-pager
```

## Pre-Deployment Checks

### Check Instance State Before Starting
Before beginning any deployment, verify instances are running and accessible:

```bash
# Check instance state
aws ec2 describe-instances --region us-west-2 --instance-ids i-INSTANCE1 i-INSTANCE2 \
  --query 'Reservations[].Instances[].[InstanceId,State.Name,PrivateIpAddress]' --output table --no-cli-pager

# Verify SSM connectivity
aws ssm describe-instance-information --region us-west-2 \
  --filters "Key=InstanceIds,Values=i-INSTANCE1,i-INSTANCE2" \
  --query 'InstanceInformationList[].[InstanceId,PingStatus,LastPingDateTime]' --output table --no-cli-pager
```

If instances are stopped, start them:
```bash
aws ec2 start-instances --region us-west-2 --instance-ids i-INSTANCE1 i-INSTANCE2 --no-cli-pager
```

### Troubleshooting Connectivity Failures
If SSM commands fail or you cannot reach the proxy after deployment:

1. **Check your current IP against security group rules**:
```bash
# Get your current IP
MY_IP=$(curl -s https://checkip.amazonaws.com)
echo "Your IP: $MY_IP"

# List security group rules (replace sg-xxxxx with actual security group ID)
aws ec2 describe-security-groups --region us-west-2 --group-ids sg-xxxxx \
  --query 'SecurityGroups[].IpPermissions[?FromPort==`80`].IpRanges[].CidrIp' --output text --no-cli-pager

# Check if your IP is authorized
aws ec2 describe-security-groups --region us-west-2 --group-ids sg-xxxxx \
  --query "SecurityGroups[].IpPermissions[?FromPort==\`80\`].IpRanges[?contains(CidrIp, '$MY_IP')]" --output text --no-cli-pager
```

2. **If your IP is not in the security group**, add it (see IP Address Management section below)

3. **Verify proxy is listening** (via SSM if direct connection fails):
```bash
aws ssm send-command --region us-west-2 --instance-ids i-INSTANCE1 \
  --document-name "AWS-RunShellScript" \
  --parameters '{"commands":["ss -tlnp | grep -E \":(80|443|8080|8081)\"","systemctl status s3-proxy --no-pager"]}' \
  --output text --query 'Command.CommandId' --no-cli-pager
```

## Successful Deployment Process

### SSM Send-Command Method (Recommended)
Use `aws ssm send-command` with JSON parameters file - this method doesn't disconnect shells and allows parallel deployment to multiple instances.

1. Create source archive and upload to S3:
```bash
tar --exclude='./target' --exclude='./.git' --exclude='./tmp' --exclude='./*.tar.gz' -czf source-VERSION.tar.gz -C . .
aws s3 cp source-VERSION.tar.gz s3://s3-proxy-deployment-temp/ --region us-west-2 --endpoint-url https://s3.dualstack.us-west-2.amazonaws.com
```

2. Generate presigned URL:
```bash
aws s3 presign s3://s3-proxy-deployment-temp/source-VERSION.tar.gz --expires-in 3600 --region us-west-2 --endpoint-url https://s3.dualstack.us-west-2.amazonaws.com
```

3. Create JSON parameters file (`tmp/ssm-commands/deploy-cmd.json`):
```json
{
  "commands": [
    "sudo systemctl stop s3-proxy || true",
    "sudo rm -rf /mnt/efs/cache/*",
    "cd /opt/s3-proxy && sudo rm -rf * .* 2>/dev/null || true",
    "cd /opt/s3-proxy && sudo curl -sL -o source.tar.gz 'PRESIGNED_URL_HERE'",
    "cd /opt/s3-proxy && sudo tar -xzf source.tar.gz",
    "export PATH=/home/ec2-user/.cargo/bin:/root/.cargo/bin:$PATH && cd /opt/s3-proxy && cargo build --release 2>&1 | tail -20",
    "sudo cp /opt/s3-proxy/target/release/s3-proxy /usr/local/bin/s3-proxy",
    "sudo chmod +x /usr/local/bin/s3-proxy",
    "/usr/local/bin/s3-proxy --version",
    "sudo systemctl start s3-proxy",
    "sleep 3",
    "curl -s http://localhost:8080/health"
  ]
}
```

4. Deploy to instances:
```bash
aws ssm send-command --region us-west-2 --instance-ids i-INSTANCE1 i-INSTANCE2 \
  --document-name "AWS-RunShellScript" --parameters file://$HOME/tmp/ssm-commands/deploy-cmd.json \
  --timeout-seconds 600 --output text --query 'Command.CommandId' --no-cli-pager
```

5. Check results (wait ~2 minutes for build):
```bash
aws ssm get-command-invocation --region us-west-2 --command-id COMMAND_ID \
  --instance-id i-INSTANCE --query '[Status,StandardOutputContent]' --output text --no-cli-pager
```

### Service Management
- **SystemD integration**: Use `systemctl` for production service management
- **Health verification**: Test both health endpoint (port 8080) and dashboard (port 8081)
- **Log monitoring**: Check `journalctl -u s3-proxy` for startup errors
- **Binary path consistency**: Ensure systemd service ExecStart matches actual binary location
- **Service file updates**: Run `systemctl daemon-reload` after modifying service files

## Common Failure Patterns

### Build Failures
- **"Hello, world!" output**: Indicates stub binary, not real proxy
- **Missing modules**: Incomplete source code extraction
- **Cargo not found**: PATH environment not set correctly

### Runtime Failures
- **Status 203/EXEC**: Binary cannot execute (permissions or missing file)
- **Status 1/FAILURE**: Configuration error or missing required directories
- **Port binding errors**: Not running as root

## IP Address Management

### Checking Current IP Address
```bash
curl -s https://checkip.amazonaws.com
```

### Updating Security Groups
When your IP address changes, update security group rules for proxy access:
```bash
NEW_IP=$(curl -s https://checkip.amazonaws.com)
aws ec2 revoke-security-group-ingress --region us-west-2 --group-id sg-xxxxx --protocol tcp --port 80 --cidr OLD_IP/32
aws ec2 authorize-security-group-ingress --region us-west-2 --group-id sg-xxxxx --protocol tcp --port 80 --cidr $NEW_IP/32
```

## Best Practices

### Temporary File Organization
Store SSM command JSON files in the project's `tmp/ssm-commands/` folder.

### Monitoring
- **Health checks**: Verify both proxy functionality and dashboard access
- **Service status**: Check SystemD service status after deployment
- **Log verification**: Confirm startup logs show successful initialization
- **Version verification**: Use `--version` flag to confirm correct binary version after deployment
