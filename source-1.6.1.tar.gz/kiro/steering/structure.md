---
inclusion: fileMatch
fileMatchPattern: "src/**/*.rs"
---

# Project Structure

## Source Code Organization

```
src/
├── lib.rs              # Library entry point, module declarations
├── main.rs             # Application entry point, server initialization
├── cache.rs            # Unified cache manager (RAM + disk + coordination)
├── cache_types.rs      # Cache data structures and types
├── cache_writer.rs     # Async cache writer for streaming responses
├── cache_hit_update_buffer.rs  # RAM buffer for cache-hit metadata updates (journal system)
├── cache_size_tracker.rs       # Cache size tracking (delegates to consolidator)
├── cache_initialization_coordinator.rs  # Coordinated cache initialization
├── disk_cache.rs       # Disk cache implementation with streaming support
├── ram_cache.rs        # RAM cache implementation for range data
├── metadata_cache.rs   # RAM cache for NewCacheMetadata objects
├── journal_manager.rs  # Journal file management for atomic metadata updates
├── journal_consolidator.rs  # Background consolidation + size tracking + eviction triggering
├── metadata_lock_manager.rs # Lock management for shared storage coordination
├── hybrid_metadata_writer.rs # Journal-based metadata writes (always enabled)
├── compression.rs      # LZ4 compression/decompression
├── config.rs           # Configuration loading (YAML, env, CLI)
├── connection_pool.rs  # HTTP connection pooling and load balancing
├── error.rs            # Error types and Result definitions
├── http_proxy.rs       # HTTP proxy server with streaming and caching
├── https_proxy.rs      # HTTPS proxy (passthrough mode)
├── tcp_proxy.rs        # TCP passthrough for HTTPS
├── tls.rs              # TLS certificate management
├── s3_client.rs        # S3 client with streaming response support
├── range_handler.rs    # Range request handling and merging
├── streaming_tee.rs    # TeeStream for simultaneous streaming and caching
├── tee_stream.rs       # Stream wrapper for cloning data to cache
├── logging.rs          # Access and application logging
├── health.rs           # Health check endpoints
├── metrics.rs          # Metrics collection and export
├── otlp.rs             # OpenTelemetry Protocol metrics export
├── shutdown.rs         # Graceful shutdown coordination
└── permissions.rs      # Directory permission validation
```

## Module Responsibilities

### Core Proxy Modules
- **main.rs**: Server startup, component initialization, task spawning
- **http_proxy.rs**: HTTP request handling, caching logic, S3 forwarding
- **https_proxy.rs**: HTTPS passthrough mode implementation
- **tcp_proxy.rs**: TCP-level proxying for HTTPS passthrough

### Caching System
- **cache.rs**: Unified cache manager coordinating RAM and disk tiers
- **ram_cache.rs**: In-memory LRU/LFU/TinyLFU cache for range data
- **metadata_cache.rs**: RAM cache for NewCacheMetadata objects (reduces disk I/O)
- **disk_cache.rs**: File-based cache with compression, locking, and streaming support
- **cache_types.rs**: Shared cache data structures
- **cache_writer.rs**: Async cache writer for background caching during streaming
- **compression.rs**: LZ4 compression with content-aware detection

### Journal System (Shared Storage)
- **cache_hit_update_buffer.rs**: RAM buffer for cache-hit metadata updates
- **journal_manager.rs**: Per-instance journal file management
- **journal_consolidator.rs**: Background consolidation of journal entries + size tracking + eviction triggering
- **metadata_lock_manager.rs**: Lock acquisition with retry for shared storage
- **hybrid_metadata_writer.rs**: Journal-based metadata writes (always enabled)

### Streaming
- **tee_stream.rs**: TeeStream wrapper for simultaneous streaming to client and caching
- **streaming_tee.rs**: Additional streaming utilities for response handling

### Infrastructure
- **config.rs**: Three-layer configuration (file, env, CLI)
- **connection_pool.rs**: Connection reuse, DNS refresh, health monitoring
- **range_handler.rs**: Byte range parsing, merging, validation
- **logging.rs**: Dual logging (access + application)
- **error.rs**: Centralized error handling with `ProxyError` type

### Observability
- **health.rs**: Health check HTTP endpoint
- **metrics.rs**: Metrics collection and HTTP endpoint
- **otlp.rs**: OpenTelemetry Protocol export to CloudWatch/Prometheus

## Cache Directory Structure

```
cache_dir/
├── metadata/                   # Sharded metadata files (.meta)
│   └── {bucket}/{XX}/{YYY}/{object}.meta
│   └── _journals/              # Per-instance journal files
│       └── {instance_id}.journal
├── ranges/                     # Sharded range data files (.bin)
│   └── {bucket}/{XX}/{YYY}/{object}_{start}-{end}.bin
├── mpus_in_progress/           # Multipart uploads in progress
├── locks/                      # Coordination locks
│   └── global_eviction.lock
└── size_tracking/              # Cache size tracking files
    ├── size_state.json
    └── validation.json
```

**Sharding Architecture**: 
- Object key is hashed using BLAKE3, first 5 hex digits create directory structure
- Path format: `{bucket}/{XX}/{YYY}/{sanitized_object_key}{suffix}`

## Code Conventions

### Error Handling
- Use `Result<T>` type alias from `error.rs`
- Return `ProxyError` variants for all errors
- Use `?` operator for error propagation
- Log errors with `tracing::error!` before returning

### Async Patterns
- All I/O operations are async with Tokio
- Use `tokio::spawn` for concurrent tasks
- Use `Arc<RwLock<T>>` for shared mutable state
- Use `tokio::select!` for concurrent task coordination

### Logging
- Use `tracing` macros: `info!`, `debug!`, `warn!`, `error!`
- Structured logging with key-value pairs
