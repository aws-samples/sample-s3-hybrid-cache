//! Cache Size Tracking Performance Tests
//!
//! NOTE: Many tests in this file have been removed or simplified because
//! size tracking is now handled by JournalConsolidator through journal entries.
//! See the journal-based-size-tracking spec for details.
//!
//! The remaining tests focus on:
//! - Checkpoint read performance
//! - Metadata file creation performance
//! - Validation lock contention

use s3_proxy::cache::CacheManager;
use s3_proxy::cache_types::{CompressionInfo, NewCacheMetadata, ObjectMetadata};
use std::sync::Arc;
use std::time::{Duration, Instant, SystemTime};
use tempfile::TempDir;

/// Helper to create a test cache manager with size tracking
async fn create_test_cache_manager(cache_dir: std::path::PathBuf) -> Arc<CacheManager> {
    let cache_manager = Arc::new(CacheManager::new_with_all_ttls(
        cache_dir,
        false, // RAM cache disabled for simplicity
        0,
        s3_proxy::cache::CacheEvictionAlgorithm::LRU,
        1024,
        true,
        Duration::from_secs(3600),
        Duration::from_secs(3600),
        Duration::from_secs(3600),
        false, // actively_remove_cached_data
    ));

    // Must call create_configured_disk_cache_manager() to set up the JournalConsolidator
    let _disk_cache = cache_manager.create_configured_disk_cache_manager();

    cache_manager.initialize().await.unwrap();
    cache_manager.set_cache_manager_in_tracker().await;

    cache_manager
}

/// Helper to create mock metadata files for validation testing
async fn create_mock_metadata_files(
    cache_dir: &std::path::Path,
    count: usize,
    size_per_file: u64,
) -> Result<(), Box<dyn std::error::Error>> {
    use std::fs;

    // Create metadata directory structure
    let metadata_dir = cache_dir.join("metadata").join("test-bucket");
    fs::create_dir_all(&metadata_dir)?;

    for i in 0..count {
        // Create sharded directory structure (first 2 chars of hash)
        let shard = format!("{:02x}", i % 256);
        let subshard = format!("{:03x}", i % 4096);
        let shard_dir = metadata_dir.join(&shard).join(&subshard);
        fs::create_dir_all(&shard_dir)?;

        // Create metadata file
        let object_metadata = ObjectMetadata::new(
            format!("etag-{}", i),
            "Wed, 21 Oct 2015 07:28:00 GMT".to_string(),
            size_per_file,
            Some("application/octet-stream".to_string()),
        );

        let metadata = NewCacheMetadata {
            cache_key: format!("test-key-{}", i),
            object_metadata,
            ranges: vec![],
            created_at: SystemTime::now(),
            expires_at: SystemTime::now() + Duration::from_secs(3600),
            compression_info: CompressionInfo::default(),
            ..Default::default()
        };

        let metadata_path = shard_dir.join(format!("test-key-{}.meta", i));
        let json = serde_json::to_string(&metadata)?;
        fs::write(metadata_path, json)?;
    }

    Ok(())
}

#[tokio::test]
async fn test_metadata_file_creation_performance() {
    // Test the performance of creating metadata files (simulates cache write operations)
    // This indirectly tests validation scan performance by creating realistic test data

    let temp_dir = TempDir::new().unwrap();
    let cache_dir = temp_dir.path().to_path_buf();

    let _cache_manager = create_test_cache_manager(cache_dir.clone()).await;

    // Create 1000 mock metadata files (scaled down from 100M for test speed)
    let file_count = 1000;
    let size_per_file = 1024 * 1024; // 1MB per file

    let start = Instant::now();
    create_mock_metadata_files(cache_dir.as_path(), file_count, size_per_file)
        .await
        .unwrap();
    let creation_duration = start.elapsed();

    println!("Metadata file creation performance:");
    println!("  Files created: {}", file_count);
    println!("  Creation duration: {:?}", creation_duration);
    println!(
        "  Files per second: {:.0}",
        file_count as f64 / creation_duration.as_secs_f64()
    );

    // File creation should be reasonably fast (< 10 seconds for 1000 files)
    assert!(
        creation_duration < Duration::from_secs(10),
        "Metadata file creation took too long: {:?}",
        creation_duration
    );
}

#[tokio::test]
#[ignore = "Flaky performance test - file lock release timing varies by OS"]
async fn test_validation_lock_contention() {
    // Test validation lock performance under contention

    let temp_dir = TempDir::new().unwrap();
    let cache_dir = temp_dir.path().to_path_buf();

    // Create first cache manager and acquire lock
    let cache_manager1 = create_test_cache_manager(cache_dir.clone()).await;
    let tracker1 = cache_manager1.get_size_tracker().await.unwrap();

    let start = Instant::now();
    let lock1 = tracker1.try_acquire_validation_lock().await;
    let lock1_duration = start.elapsed();

    assert!(lock1.is_ok(), "First instance should acquire lock");
    println!("Validation lock contention test:");
    println!("  First lock acquisition: {:?}", lock1_duration);

    // Try to acquire from second instance (should fail)
    let cache_manager2 = create_test_cache_manager(cache_dir.clone()).await;
    let tracker2 = cache_manager2.get_size_tracker().await.unwrap();

    let start = Instant::now();
    let lock2 = tracker2.try_acquire_validation_lock().await;
    let lock2_duration = start.elapsed();

    assert!(
        lock2.is_err(),
        "Second instance should not acquire lock while first holds it"
    );
    println!("  Second lock attempt (should fail): {:?}", lock2_duration);

    // Release first lock
    drop(lock1);

    // Now second instance should be able to acquire
    let start = Instant::now();
    let lock2_retry = tracker2.try_acquire_validation_lock().await;
    let lock2_retry_duration = start.elapsed();

    assert!(
        lock2_retry.is_ok(),
        "Second instance should acquire lock after first releases"
    );
    println!(
        "  Second lock acquisition after release: {:?}",
        lock2_retry_duration
    );

    // All operations should be fast
    assert!(
        lock1_duration < Duration::from_millis(100),
        "Lock acquisition took too long: {:?}",
        lock1_duration
    );

    println!("  ✓ Validation lock provides proper mutual exclusion");
}

// NOTE: The following tests have been removed because they relied on update_size()
// which has been removed as part of the journal-based-size-tracking migration:
// - test_size_update_latency
// - test_checkpoint_overhead
// - test_checkpoint_read_performance
// - test_concurrent_operations_performance
// - test_delta_log_append_performance
// - test_recovery_performance
// - test_concurrent_checkpoint_and_updates
//
// Size tracking is now handled by JournalConsolidator through journal entries.
// See the journal-based-size-tracking spec for the new architecture.
