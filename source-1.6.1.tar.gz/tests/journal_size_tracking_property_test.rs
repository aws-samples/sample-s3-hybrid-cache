//! Property-Based Tests for Journal-Based Size Tracking
//!
//! This module contains property-based tests using quickcheck to verify the correctness
//! properties defined in the journal-based-size-tracking design document.
//!
//! Properties tested:
//! - Property 1: Size consistency - tracked size equals sum of range files
//! - Property 2: Eviction triggering - eviction within 5s when over capacity
//! - Property 3: Multi-instance consistency - all instances see same size
//! - Property 4: Crash recovery - size recovers within validation threshold
//! - Property 5: No double counting - entries counted exactly once

use quickcheck::TestResult;
use quickcheck_macros::quickcheck;
use s3_proxy::cache_types::RangeSpec;
use s3_proxy::compression::CompressionAlgorithm;
use s3_proxy::journal_consolidator::{ConsolidationConfig, JournalConsolidator, SizeState};
use s3_proxy::journal_manager::{JournalEntry, JournalManager, JournalOperation};
use s3_proxy::metadata_lock_manager::MetadataLockManager;
use std::sync::Arc;
use std::time::{Duration, SystemTime};
use tempfile::TempDir;

// ============================================================================
// Test Helpers
// ============================================================================

/// Helper to create a test consolidator with size tracking
async fn create_test_consolidator(
    cache_dir: std::path::PathBuf,
    max_cache_size: u64,
) -> Arc<JournalConsolidator> {
    // Ensure required directories exist
    std::fs::create_dir_all(cache_dir.join("metadata/_journals")).unwrap();
    std::fs::create_dir_all(cache_dir.join("size_tracking")).unwrap();
    std::fs::create_dir_all(cache_dir.join("locks")).unwrap();
    std::fs::create_dir_all(cache_dir.join("ranges")).unwrap();

    let journal_manager = Arc::new(JournalManager::new(
        cache_dir.clone(),
        "test-instance".to_string(),
    ));
    let lock_manager = Arc::new(MetadataLockManager::new(
        cache_dir.clone(),
        Duration::from_secs(30),
        3,
    ));
    let consolidation_config = ConsolidationConfig {
        interval: Duration::from_secs(5),
        size_threshold: 1024 * 1024,
        entry_count_threshold: 100,
        max_keys_per_run: 50,
        max_cache_size,
        eviction_trigger_percent: 95,
        eviction_target_percent: 80,
        stale_entry_timeout_secs: 300,
        consolidation_cycle_timeout: Duration::from_secs(30),
    };
    let consolidator = Arc::new(JournalConsolidator::new(
        cache_dir,
        journal_manager,
        lock_manager,
        consolidation_config,
    ));
    consolidator.initialize().await.unwrap();
    consolidator
}

/// Helper to create a test RangeSpec
fn create_test_range_spec(start: u64, end: u64, compressed_size: u64) -> RangeSpec {
    let now = SystemTime::now();
    RangeSpec {
        start,
        end,
        file_path: format!("test_{}_{}.bin", start, end),
        compression_algorithm: CompressionAlgorithm::Lz4,
        compressed_size,
        uncompressed_size: compressed_size,
        created_at: now,
        last_accessed: now,
        access_count: 1,
        frequency_score: 1,
    }
}

/// Helper to create a test journal entry
fn create_test_journal_entry(
    cache_key: &str,
    start: u64,
    end: u64,
    compressed_size: u64,
    operation: JournalOperation,
    instance_id: &str,
) -> JournalEntry {
    JournalEntry {
        timestamp: SystemTime::now(),
        instance_id: instance_id.to_string(),
        cache_key: cache_key.to_string(),
        range_spec: create_test_range_spec(start, end, compressed_size),
        operation,
        range_file_path: format!("ranges/test_{}_{}.bin", start, end),
        metadata_version: 1,
        new_ttl_secs: None,
        object_ttl_secs: None,
        access_increment: None,
        object_metadata: None,
        metadata_written: false,
    }
}

/// Helper to write a journal entry to a journal file
async fn write_journal_entry(cache_dir: &std::path::Path, entry: &JournalEntry) {
    let journal_path = cache_dir
        .join("metadata")
        .join("_journals")
        .join(format!("{}.journal", entry.instance_id));

    let json = serde_json::to_string(entry).unwrap();
    let content = if journal_path.exists() {
        let existing = tokio::fs::read_to_string(&journal_path).await.unwrap();
        format!("{}\n{}", existing.trim(), json)
    } else {
        json
    };
    tokio::fs::write(&journal_path, content).await.unwrap();
}

/// Helper to create a range file on disk
async fn create_range_file(
    cache_dir: &std::path::Path,
    cache_key: &str,
    start: u64,
    end: u64,
    size: u64,
) {
    let range_base_dir = cache_dir.join("ranges");
    let range_path = s3_proxy::disk_cache::get_sharded_path(
        &range_base_dir,
        cache_key,
        &format!("_{}-{}.bin", start, end),
    )
    .unwrap();

    if let Some(parent) = range_path.parent() {
        tokio::fs::create_dir_all(parent).await.unwrap();
    }

    // Create a file with the specified size
    let data = vec![0u8; size as usize];
    tokio::fs::write(&range_path, data).await.unwrap();
}

// ============================================================================
// Property 1: Size Consistency
// ============================================================================

/// **Feature: journal-based-size-tracking, Property 1: Size Consistency**
///
/// *For any* sequence of Add/Remove operations, the tracked size equals the sum
/// of all range file sizes on disk.
///
/// **Validates: Requirements 1.1, 1.2, 4.1**
#[quickcheck]
fn prop_size_consistency_add_operations(sizes: Vec<u16>) -> TestResult {
    // Filter invalid inputs
    if sizes.is_empty() || sizes.len() > 20 {
        return TestResult::discard();
    }

    // Filter out zero sizes
    let sizes: Vec<u16> = sizes.into_iter().filter(|&s| s > 0).collect();
    if sizes.is_empty() {
        return TestResult::discard();
    }

    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        let consolidator = create_test_consolidator(cache_dir.clone(), 0).await;

        // Create journal entries for Add operations
        let mut expected_total_size: u64 = 0;
        let mut offset: u64 = 0;

        for (i, size) in sizes.iter().enumerate() {
            let size = *size as u64;
            let cache_key = format!("test-bucket/object-{}", i);
            let start = offset;
            let end = offset + size - 1;

            let entry = create_test_journal_entry(
                &cache_key,
                start,
                end,
                size,
                JournalOperation::Add,
                "test-instance",
            );

            write_journal_entry(&cache_dir, &entry).await;
            create_range_file(&cache_dir, &cache_key, start, end, size).await;

            expected_total_size += size;
            offset += size;
        }

        // Run consolidation cycle
        let result = consolidator.run_consolidation_cycle().await.unwrap();

        // Property: tracked size equals sum of range file sizes
        if result.current_size != expected_total_size {
            return TestResult::error(format!(
                "Size mismatch: tracked={}, expected={}",
                result.current_size, expected_total_size
            ));
        }

        // Verify size state matches
        let size_state = consolidator.get_size_state().await;
        if size_state.total_size != expected_total_size {
            return TestResult::error(format!(
                "Size state mismatch: state={}, expected={}",
                size_state.total_size, expected_total_size
            ));
        }

        TestResult::passed()
    })
}

/// **Feature: journal-based-size-tracking, Property 1: Size Consistency (Add/Remove)**
///
/// *For any* sequence of Add followed by Remove operations, the tracked size
/// correctly reflects the net change.
///
/// **Validates: Requirements 1.1, 1.2, 4.1**
#[quickcheck]
fn prop_size_consistency_add_remove_operations(
    add_sizes: Vec<u16>,
    remove_indices: Vec<u8>,
) -> TestResult {
    // Filter invalid inputs
    if add_sizes.is_empty() || add_sizes.len() > 10 {
        return TestResult::discard();
    }

    // Filter out zero sizes
    let add_sizes: Vec<u16> = add_sizes.into_iter().filter(|&s| s > 0).collect();
    if add_sizes.is_empty() {
        return TestResult::discard();
    }

    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        let consolidator = create_test_consolidator(cache_dir.clone(), 0).await;

        // First, add all entries
        let mut entries_info: Vec<(String, u64, u64, u64)> = Vec::new();
        let mut offset: u64 = 0;

        for (i, size) in add_sizes.iter().enumerate() {
            let size = *size as u64;
            let cache_key = format!("test-bucket/object-{}", i);
            let start = offset;
            let end = offset + size - 1;

            let entry = create_test_journal_entry(
                &cache_key,
                start,
                end,
                size,
                JournalOperation::Add,
                "test-instance",
            );

            write_journal_entry(&cache_dir, &entry).await;
            create_range_file(&cache_dir, &cache_key, start, end, size).await;

            entries_info.push((cache_key, start, end, size));
            offset += size;
        }

        // Run first consolidation
        let _ = consolidator.run_consolidation_cycle().await.unwrap();

        // Now remove some entries
        let mut removed_size: u64 = 0;
        let mut removed_indices: std::collections::HashSet<usize> =
            std::collections::HashSet::new();

        for idx in remove_indices.iter() {
            let idx = (*idx as usize) % entries_info.len();
            if removed_indices.contains(&idx) {
                continue;
            }
            removed_indices.insert(idx);

            let (cache_key, start, end, size) = &entries_info[idx];
            let entry = create_test_journal_entry(
                cache_key,
                *start,
                *end,
                *size,
                JournalOperation::Remove,
                "test-instance",
            );

            write_journal_entry(&cache_dir, &entry).await;
            removed_size += size;
        }

        // Run second consolidation
        let result = consolidator.run_consolidation_cycle().await.unwrap();

        // Calculate expected size
        let total_added: u64 = add_sizes.iter().map(|&s| s as u64).sum();
        let expected_size = total_added - removed_size;

        // Property: tracked size equals sum of remaining range file sizes
        if result.current_size != expected_size {
            return TestResult::error(format!(
                "Size mismatch after removes: tracked={}, expected={}, added={}, removed={}",
                result.current_size, expected_size, total_added, removed_size
            ));
        }

        TestResult::passed()
    })
}

// ============================================================================
// Property 2: Eviction Triggering
// ============================================================================

/// **Feature: journal-based-size-tracking, Property 2: Eviction Triggering**
///
/// *If* total_size > max_cache_size after consolidation, eviction is triggered
/// within one consolidation cycle (5s).
///
/// **Validates: Requirements 2.1, 2.2**
#[quickcheck]
fn prop_eviction_triggering_threshold(max_cache_kb: u8, data_kb: u8) -> TestResult {
    // Filter invalid inputs - ensure we have meaningful test cases
    if max_cache_kb == 0 || data_kb == 0 {
        return TestResult::discard();
    }

    let max_cache_size = (max_cache_kb as u64) * 1024;
    let data_size = (data_kb as u64) * 1024;

    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        // Create consolidator with specified max cache size
        let consolidator = create_test_consolidator(cache_dir.clone(), max_cache_size).await;

        // Create journal entry with specified data size
        let cache_key = "test-bucket/eviction-test-object";
        let entry = create_test_journal_entry(
            cache_key,
            0,
            data_size - 1,
            data_size,
            JournalOperation::Add,
            "test-instance",
        );

        write_journal_entry(&cache_dir, &entry).await;
        create_range_file(&cache_dir, cache_key, 0, data_size - 1, data_size).await;

        // Run consolidation cycle
        let result = consolidator.run_consolidation_cycle().await.unwrap();

        // Property: if size exceeds max, eviction should be triggered
        // Note: Without a CacheManager connected, eviction won't actually run,
        // but we verify the size tracking and threshold detection work correctly
        let should_trigger_eviction = data_size > max_cache_size;

        // Verify size is tracked correctly
        if result.current_size != data_size {
            return TestResult::error(format!(
                "Size tracking failed: tracked={}, expected={}",
                result.current_size, data_size
            ));
        }

        // Verify the consolidator correctly identifies when eviction is needed
        // (The actual eviction requires a CacheManager, which we don't have in this test)
        if should_trigger_eviction {
            // Size exceeds max - eviction should have been attempted
            // Since no CacheManager is connected, eviction_triggered will be false
            // but we can verify the size tracking is correct
            if result.current_size <= max_cache_size {
                return TestResult::error(format!(
                    "Size should exceed max: current={}, max={}",
                    result.current_size, max_cache_size
                ));
            }
        }

        TestResult::passed()
    })
}

/// **Feature: journal-based-size-tracking, Property 2: Eviction Triggering (No False Positives)**
///
/// *If* total_size <= max_cache_size after consolidation, eviction should NOT
/// be triggered.
///
/// **Validates: Requirements 2.1, 2.2**
#[quickcheck]
fn prop_eviction_no_false_positives(data_kb: u8) -> TestResult {
    // Filter invalid inputs
    if data_kb == 0 {
        return TestResult::discard();
    }

    let data_size = (data_kb as u64) * 1024;
    // Set max cache size to be larger than data size
    let max_cache_size = data_size * 2;

    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        let consolidator = create_test_consolidator(cache_dir.clone(), max_cache_size).await;

        // Create journal entry with data size less than max
        let cache_key = "test-bucket/no-eviction-test-object";
        let entry = create_test_journal_entry(
            cache_key,
            0,
            data_size - 1,
            data_size,
            JournalOperation::Add,
            "test-instance",
        );

        write_journal_entry(&cache_dir, &entry).await;
        create_range_file(&cache_dir, cache_key, 0, data_size - 1, data_size).await;

        // Run consolidation cycle
        let result = consolidator.run_consolidation_cycle().await.unwrap();

        // Property: eviction should NOT be triggered when under capacity
        if result.eviction_triggered {
            return TestResult::error(format!(
                "Eviction triggered when under capacity: current={}, max={}",
                result.current_size, max_cache_size
            ));
        }

        // Verify size is correct
        if result.current_size != data_size {
            return TestResult::error(format!(
                "Size mismatch: tracked={}, expected={}",
                result.current_size, data_size
            ));
        }

        TestResult::passed()
    })
}

// ============================================================================
// Property 3: Multi-Instance Consistency
// ============================================================================

/// **Feature: journal-based-size-tracking, Property 3: Multi-Instance Consistency**
///
/// *All* instances reading size_state.json see the same total_size value
/// (eventual consistency within 5s).
///
/// **Validates: Requirements 7.4, 7.5**
#[quickcheck]
fn prop_multi_instance_consistency(sizes: Vec<u16>) -> TestResult {
    // Filter invalid inputs
    if sizes.is_empty() || sizes.len() > 10 {
        return TestResult::discard();
    }

    // Filter out zero sizes
    let sizes: Vec<u16> = sizes.into_iter().filter(|&s| s > 0).collect();
    if sizes.is_empty() {
        return TestResult::discard();
    }

    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        // Create first consolidator (instance 1)
        let consolidator1 = create_test_consolidator(cache_dir.clone(), 0).await;

        // Add data via instance 1
        let mut expected_total_size: u64 = 0;
        let mut offset: u64 = 0;

        for (i, size) in sizes.iter().enumerate() {
            let size = *size as u64;
            let cache_key = format!("test-bucket/multi-instance-object-{}", i);
            let start = offset;
            let end = offset + size - 1;

            let entry = create_test_journal_entry(
                &cache_key,
                start,
                end,
                size,
                JournalOperation::Add,
                "instance-1",
            );

            write_journal_entry(&cache_dir, &entry).await;
            create_range_file(&cache_dir, &cache_key, start, end, size).await;

            expected_total_size += size;
            offset += size;
        }

        // Run consolidation on instance 1
        let _result1 = consolidator1.run_consolidation_cycle().await.unwrap();

        // Create second consolidator (instance 2) - simulates another instance
        // reading the shared size_state.json
        let consolidator2 = create_test_consolidator(cache_dir.clone(), 0).await;

        // Property: both instances should see the same size
        let size1 = consolidator1.get_current_size().await;
        let size2 = consolidator2.get_current_size().await;

        if size1 != size2 {
            return TestResult::error(format!(
                "Multi-instance size mismatch: instance1={}, instance2={}",
                size1, size2
            ));
        }

        if size1 != expected_total_size {
            return TestResult::error(format!(
                "Size mismatch with expected: actual={}, expected={}",
                size1, expected_total_size
            ));
        }

        // Verify size state is consistent
        let state1 = consolidator1.get_size_state().await;
        let state2 = consolidator2.get_size_state().await;

        if state1.total_size != state2.total_size {
            return TestResult::error(format!(
                "Size state mismatch: state1={}, state2={}",
                state1.total_size, state2.total_size
            ));
        }

        TestResult::passed()
    })
}

/// **Feature: journal-based-size-tracking, Property 3: Multi-Instance Consistency (Shared State)**
///
/// *For any* size state persisted by one instance, another instance reading
/// the same file should see identical values.
///
/// **Validates: Requirements 7.4, 7.5**
#[quickcheck]
fn prop_multi_instance_shared_state_persistence(
    total_size: u32,
    write_cache_size: u16,
    consolidation_count: u16,
) -> TestResult {
    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        // Create required directories
        std::fs::create_dir_all(cache_dir.join("size_tracking")).unwrap();
        std::fs::create_dir_all(cache_dir.join("metadata/_journals")).unwrap();
        std::fs::create_dir_all(cache_dir.join("locks")).unwrap();

        // Create a size state file (simulating instance 1 writing it)
        let original_state = SizeState {
            total_size: total_size as u64,
            write_cache_size: write_cache_size as u64,
            last_consolidation: SystemTime::now(),
            consolidation_count: consolidation_count as u64,
            last_updated_by: "instance-1:12345".to_string(),
        };

        let size_state_path = cache_dir.join("size_tracking").join("size_state.json");
        let json = serde_json::to_string_pretty(&original_state).unwrap();
        tokio::fs::write(&size_state_path, json).await.unwrap();

        // Create a new consolidator (simulating instance 2 reading the state)
        let consolidator = create_test_consolidator(cache_dir.clone(), 0).await;

        // Property: instance 2 should see the same values as instance 1 wrote
        let loaded_state = consolidator.get_size_state().await;

        if loaded_state.total_size != original_state.total_size {
            return TestResult::error(format!(
                "Total size mismatch: loaded={}, original={}",
                loaded_state.total_size, original_state.total_size
            ));
        }

        if loaded_state.write_cache_size != original_state.write_cache_size {
            return TestResult::error(format!(
                "Write cache size mismatch: loaded={}, original={}",
                loaded_state.write_cache_size, original_state.write_cache_size
            ));
        }

        if loaded_state.consolidation_count != original_state.consolidation_count {
            return TestResult::error(format!(
                "Consolidation count mismatch: loaded={}, original={}",
                loaded_state.consolidation_count, original_state.consolidation_count
            ));
        }

        if loaded_state.last_updated_by != original_state.last_updated_by {
            return TestResult::error(format!(
                "Last updated by mismatch: loaded={}, original={}",
                loaded_state.last_updated_by, original_state.last_updated_by
            ));
        }

        TestResult::passed()
    })
}

// ============================================================================
// Property 4: Crash Recovery
// ============================================================================

/// **Feature: journal-based-size-tracking, Property 4: Crash Recovery**
///
/// *After* a crash and restart, size_state recovers to within validation
/// threshold of actual disk usage.
///
/// **Validates: Requirements 1.4, 4.4**
#[quickcheck]
fn prop_crash_recovery_size_state(
    total_size: u32,
    write_cache_size: u16,
    consolidation_count: u16,
) -> TestResult {
    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        // Create required directories
        std::fs::create_dir_all(cache_dir.join("size_tracking")).unwrap();
        std::fs::create_dir_all(cache_dir.join("metadata/_journals")).unwrap();
        std::fs::create_dir_all(cache_dir.join("locks")).unwrap();

        // Simulate a previous run by writing a size_state.json file
        let previous_state = SizeState {
            total_size: total_size as u64,
            write_cache_size: write_cache_size as u64,
            last_consolidation: SystemTime::now() - Duration::from_secs(60),
            consolidation_count: consolidation_count as u64,
            last_updated_by: "previous-instance:12345".to_string(),
        };

        let size_state_path = cache_dir.join("size_tracking").join("size_state.json");
        let json = serde_json::to_string_pretty(&previous_state).unwrap();
        tokio::fs::write(&size_state_path, json).await.unwrap();

        // Create a new consolidator (simulating restart after crash)
        let consolidator = create_test_consolidator(cache_dir.clone(), 0).await;

        // Property: size state should be recovered from disk
        let recovered_state = consolidator.get_size_state().await;

        if recovered_state.total_size != previous_state.total_size {
            return TestResult::error(format!(
                "Total size not recovered: recovered={}, expected={}",
                recovered_state.total_size, previous_state.total_size
            ));
        }

        if recovered_state.write_cache_size != previous_state.write_cache_size {
            return TestResult::error(format!(
                "Write cache size not recovered: recovered={}, expected={}",
                recovered_state.write_cache_size, previous_state.write_cache_size
            ));
        }

        if recovered_state.consolidation_count != previous_state.consolidation_count {
            return TestResult::error(format!(
                "Consolidation count not recovered: recovered={}, expected={}",
                recovered_state.consolidation_count, previous_state.consolidation_count
            ));
        }

        // Verify get_current_size() returns recovered value
        if consolidator.get_current_size().await != previous_state.total_size {
            return TestResult::error(format!(
                "get_current_size() mismatch: actual={}, expected={}",
                consolidator.get_current_size().await,
                previous_state.total_size
            ));
        }

        TestResult::passed()
    })
}

/// **Feature: journal-based-size-tracking, Property 4: Crash Recovery (Fresh Start)**
///
/// *On* startup with missing size state, system starts with default (zero) values.
///
/// **Validates: Requirements 1.4, 4.4**
#[quickcheck]
fn prop_crash_recovery_fresh_start(_seed: u8) -> TestResult {
    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        // Create consolidator without any existing size_state.json
        let consolidator = create_test_consolidator(cache_dir.clone(), 0).await;

        // Property: size state should start at default values
        let size_state = consolidator.get_size_state().await;

        if size_state.total_size != 0 {
            return TestResult::error(format!(
                "Total size should be 0 for fresh start: actual={}",
                size_state.total_size
            ));
        }

        if size_state.write_cache_size != 0 {
            return TestResult::error(format!(
                "Write cache size should be 0 for fresh start: actual={}",
                size_state.write_cache_size
            ));
        }

        if size_state.consolidation_count != 0 {
            return TestResult::error(format!(
                "Consolidation count should be 0 for fresh start: actual={}",
                size_state.consolidation_count
            ));
        }

        TestResult::passed()
    })
}

/// **Feature: journal-based-size-tracking, Property 4: Crash Recovery (Validation Correction)**
///
/// *After* validation scan, size state is corrected to match actual filesystem size.
///
/// **Validates: Requirements 4.1, 4.2, 4.3**
#[quickcheck]
fn prop_crash_recovery_validation_correction(
    _initial_size: u32,
    correct_size: u32,
    write_cache_size: u16,
) -> TestResult {
    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        let consolidator = create_test_consolidator(cache_dir.clone(), 0).await;

        // Set an initial (potentially incorrect) size
        // We'll use update_size_from_validation to correct it
        let correct_size = correct_size as u64;
        let write_cache_size = write_cache_size as u64;

        // Update size from validation (simulating what CacheSizeTracker does after a scan)
        consolidator
            .update_size_from_validation(correct_size, Some(write_cache_size))
            .await;

        // Property: size should be corrected by validation
        let size_state = consolidator.get_size_state().await;

        if size_state.total_size != correct_size {
            return TestResult::error(format!(
                "Total size not corrected: actual={}, expected={}",
                size_state.total_size, correct_size
            ));
        }

        if size_state.write_cache_size != write_cache_size {
            return TestResult::error(format!(
                "Write cache size not corrected: actual={}, expected={}",
                size_state.write_cache_size, write_cache_size
            ));
        }

        // Verify the corrected size is persisted
        let size_state_path = cache_dir.join("size_tracking").join("size_state.json");
        let persisted_content = tokio::fs::read_to_string(&size_state_path).await.unwrap();
        let persisted_state: SizeState = serde_json::from_str(&persisted_content).unwrap();

        if persisted_state.total_size != correct_size {
            return TestResult::error(format!(
                "Persisted size not corrected: actual={}, expected={}",
                persisted_state.total_size, correct_size
            ));
        }

        TestResult::passed()
    })
}

// ============================================================================
// Property 5: No Double Counting
// ============================================================================

/// **Feature: journal-based-size-tracking, Property 5: No Double Counting**
///
/// *A* journal entry is counted toward size exactly once, even if consolidation
/// is interrupted and retried.
///
/// **Validates: Requirements 1.1, 5.1**
#[quickcheck]
fn prop_no_double_counting_single_entry(size: u16) -> TestResult {
    // Filter invalid inputs
    if size == 0 {
        return TestResult::discard();
    }

    let size = size as u64;

    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        let consolidator = create_test_consolidator(cache_dir.clone(), 0).await;

        // Create a single journal entry
        let cache_key = "test-bucket/no-double-count-object";
        let entry = create_test_journal_entry(
            cache_key,
            0,
            size - 1,
            size,
            JournalOperation::Add,
            "test-instance",
        );

        write_journal_entry(&cache_dir, &entry).await;
        create_range_file(&cache_dir, cache_key, 0, size - 1, size).await;

        // Run consolidation cycle
        let result1 = consolidator.run_consolidation_cycle().await.unwrap();

        // Verify size is correct after first consolidation
        if result1.current_size != size {
            return TestResult::error(format!(
                "Size mismatch after first consolidation: actual={}, expected={}",
                result1.current_size, size
            ));
        }

        // Run consolidation again (simulating retry)
        let result2 = consolidator.run_consolidation_cycle().await.unwrap();

        // Property: size should NOT increase (entry should not be double-counted)
        if result2.current_size != size {
            return TestResult::error(format!(
                "Double counting detected: size after retry={}, expected={}",
                result2.current_size, size
            ));
        }

        // Verify size delta is 0 for the second consolidation
        if result2.size_delta != 0 {
            return TestResult::error(format!(
                "Non-zero size delta on retry: delta={}",
                result2.size_delta
            ));
        }

        TestResult::passed()
    })
}

/// **Feature: journal-based-size-tracking, Property 5: No Double Counting (Multiple Entries)**
///
/// *For any* sequence of journal entries, each entry is counted exactly once
/// across multiple consolidation cycles.
///
/// **Validates: Requirements 1.1, 5.1**
#[quickcheck]
fn prop_no_double_counting_multiple_entries(sizes: Vec<u16>) -> TestResult {
    // Filter invalid inputs
    if sizes.is_empty() || sizes.len() > 10 {
        return TestResult::discard();
    }

    // Filter out zero sizes
    let sizes: Vec<u16> = sizes.into_iter().filter(|&s| s > 0).collect();
    if sizes.is_empty() {
        return TestResult::discard();
    }

    let rt = tokio::runtime::Runtime::new().unwrap();

    rt.block_on(async {
        let temp_dir = TempDir::new().unwrap();
        let cache_dir = temp_dir.path().to_path_buf();

        let consolidator = create_test_consolidator(cache_dir.clone(), 0).await;

        // Create multiple journal entries
        let mut expected_total_size: u64 = 0;
        let mut offset: u64 = 0;

        for (i, size) in sizes.iter().enumerate() {
            let size = *size as u64;
            let cache_key = format!("test-bucket/no-double-count-object-{}", i);
            let start = offset;
            let end = offset + size - 1;

            let entry = create_test_journal_entry(
                &cache_key,
                start,
                end,
                size,
                JournalOperation::Add,
                "test-instance",
            );

            write_journal_entry(&cache_dir, &entry).await;
            create_range_file(&cache_dir, &cache_key, start, end, size).await;

            expected_total_size += size;
            offset += size;
        }

        // Run first consolidation cycle
        let result1 = consolidator.run_consolidation_cycle().await.unwrap();

        if result1.current_size != expected_total_size {
            return TestResult::error(format!(
                "Size mismatch after first consolidation: actual={}, expected={}",
                result1.current_size, expected_total_size
            ));
        }

        // Run multiple additional consolidation cycles
        for cycle in 2..=5 {
            let result = consolidator.run_consolidation_cycle().await.unwrap();

            // Property: size should remain constant (no double counting)
            if result.current_size != expected_total_size {
                return TestResult::error(format!(
                    "Double counting detected in cycle {}: size={}, expected={}",
                    cycle, result.current_size, expected_total_size
                ));
            }

            // Size delta should be 0 for subsequent cycles
            if result.size_delta != 0 {
                return TestResult::error(format!(
                    "Non-zero size delta in cycle {}: delta={}",
                    cycle, result.size_delta
                ));
            }
        }

        TestResult::passed()
    })
}
