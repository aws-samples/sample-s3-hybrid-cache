/// Real-world integration test for cache lookup with actual S3 proxy
///
/// This test:
/// 1. Starts the S3 proxy with sudo on port 80
/// 2. Clears relevant GET and HEAD cache files
/// 3. Downloads a 100MB file from S3 using AWS CLI
/// 4. Verifies the first download completes correctly
/// 5. Downloads the same file again
/// 6. Confirms 100% cache hit with no range merging mismatches
///
/// Requirements:
/// - sudo access (for port 80)
/// - AWS CLI installed and configured
/// - Access to s3://egummett-testing-source-1/bigfiles/100MB
///
/// Run with: sudo -E cargo test --test real_world_cache_test -- --nocapture
use std::fs;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::time::Duration;
use tempfile::TempDir;

const TEST_BUCKET: &str = "egummett-testing-source-1";
const TEST_OBJECT: &str = "bigfiles/100MB";
const S3_ENDPOINT: &str = "http://s3.eu-west-1.amazonaws.com";
const PROXY_PORT: u16 = 80;
const PROXY_HEALTH_PORT: u16 = 8080;

/// Test configuration for the proxy
struct ProxyTestConfig {
    cache_dir: PathBuf,
    config_file: PathBuf,
    download_dir: PathBuf,
}

impl ProxyTestConfig {
    fn new(temp_dir: &TempDir) -> Self {
        let cache_dir = temp_dir.path().join("cache");
        let config_file = temp_dir.path().join("test-config.yaml");
        let download_dir = temp_dir.path().join("downloads");

        fs::create_dir_all(&cache_dir).expect("Failed to create cache dir");
        fs::create_dir_all(&download_dir).expect("Failed to create download dir");

        Self {
            cache_dir,
            config_file,
            download_dir,
        }
    }

    fn write_config(&self) {
        let config = format!(
            r#"
server:
  http_port: {}
  https_port: 443
  https_mode: "passthrough"
  max_concurrent_requests: 200
  request_timeout: "300s"

cache:
  cache_dir: "{}"
  max_cache_size: 10737418240  # 10GB
  ram_cache_enabled: false
  eviction_algorithm: "tinylfu"
  write_cache_enabled: false
  get_ttl: "315360000s"  # ~10 years
  head_ttl: "60s"
  actively_remove_cached_data: false
  range_merge_gap_threshold: 262144  # 256KB
  eviction_buffer_percent: 5
  shared_storage:
    enabled: true
    lock_timeout: "60s"

logging:
  access_log_dir: "{}/logs/access"
  app_log_dir: "{}/logs/app"
  access_log_enabled: true
  access_log_mode: "all"
  log_level: "debug"

health:
  enabled: true
  endpoint: "/health"
  port: {}
  check_interval: "30s"

metrics:
  enabled: true
  endpoint: "/metrics"
  port: 9090
  collection_interval: "60s"
  include_cache_stats: true
  include_compression_stats: true
  include_connection_stats: true

connection_pool:
  max_connections_per_ip: 10
  dns_refresh_interval: "60s"
  connection_timeout: "10s"
  idle_timeout: "60s"

compression:
  enabled: true
  threshold: 4096
  preferred_algorithm: "lz4"
  content_aware: true
"#,
            PROXY_PORT,
            self.cache_dir.display(),
            self.cache_dir.display(),
            self.cache_dir.display(),
            PROXY_HEALTH_PORT,
        );

        fs::write(&self.config_file, config).expect("Failed to write config file");
    }

    fn get_cache_key(&self) -> String {
        format!("{}/{}", TEST_BUCKET, TEST_OBJECT)
    }

    fn clear_cache_for_object(&self) {
        let cache_key = self.get_cache_key();
        println!("\n=== Clearing cache for object: {} ===", cache_key);

        // Clear GET cache (metadata and ranges directories)
        let metadata_dir = self.cache_dir.join("metadata");
        let ranges_dir = self.cache_dir.join("ranges");

        for dir in [metadata_dir, ranges_dir] {
            if dir.exists() {
                if let Err(e) = fs::remove_dir_all(&dir) {
                    println!("Warning: Failed to remove {}: {}", dir.display(), e);
                } else {
                    println!("✓ Cleared: {}", dir.display());
                }
                // Recreate the directory
                fs::create_dir_all(&dir).expect("Failed to recreate cache directory");
            }
        }

        println!("✓ Cache cleared successfully");
    }
}

/// Start the S3 proxy server
fn start_proxy(config: &ProxyTestConfig) -> std::process::Child {
    println!("\n=== Starting S3 Proxy ===");
    println!("Config file: {}", config.config_file.display());
    println!("Cache dir: {}", config.cache_dir.display());
    println!("Port: {}", PROXY_PORT);

    // Build the proxy binary first
    println!("\n=== Building proxy binary ===");
    let build_status = Command::new("cargo")
        .args(["build", "--release"])
        .status()
        .expect("Failed to build proxy");

    assert!(build_status.success(), "Failed to build proxy binary");
    println!("✓ Proxy binary built successfully");

    // Start the proxy with sudo
    let proxy_binary = PathBuf::from("target/release/s3-proxy");
    assert!(
        proxy_binary.exists(),
        "Proxy binary not found at {:?}",
        proxy_binary
    );

    println!("\n=== Launching proxy with sudo ===");
    let child = Command::new("sudo")
        .arg("-E") // Preserve environment
        .arg(proxy_binary)
        .arg("-c")
        .arg(&config.config_file)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("Failed to start proxy");

    println!("✓ Proxy started with PID: {}", child.id());

    child
}

/// Wait for proxy to be ready by checking health endpoint
fn wait_for_proxy_ready(max_wait_secs: u64) -> bool {
    println!("\n=== Waiting for proxy to be ready ===");
    let start = std::time::Instant::now();
    let health_url = format!("http://localhost:{}/health", PROXY_HEALTH_PORT);

    while start.elapsed().as_secs() < max_wait_secs {
        match ureq::get(&health_url)
            .timeout(Duration::from_secs(2))
            .call()
        {
            Ok(response) => {
                if response.status() == 200 {
                    println!("✓ Proxy is ready (took {:?})", start.elapsed());
                    return true;
                }
            }
            Err(_) => {
                // Not ready yet, continue waiting
            }
        }
        std::thread::sleep(Duration::from_millis(500));
    }

    println!(
        "✗ Proxy failed to become ready within {} seconds",
        max_wait_secs
    );
    false
}

/// Download file using AWS CLI
fn download_with_aws_cli(config: &ProxyTestConfig, attempt: u32) -> Result<(), String> {
    println!("\n=== Download Attempt {} ===", attempt);

    let s3_uri = format!("s3://{}/{}", TEST_BUCKET, TEST_OBJECT);
    let output_file = config
        .download_dir
        .join(format!("100MB_attempt_{}", attempt));

    println!("Source: {}", s3_uri);
    println!("Destination: {}", output_file.display());
    println!("Endpoint: {}", S3_ENDPOINT);

    let output = Command::new("aws")
        .args([
            "s3",
            "cp",
            &s3_uri,
            output_file.to_str().unwrap(),
            "--endpoint-url",
            S3_ENDPOINT,
        ])
        .output()
        .map_err(|e| format!("Failed to execute aws cli: {}", e))?;

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(format!("AWS CLI failed: {}", stderr));
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    println!("AWS CLI output: {}", stdout);

    // Verify file was downloaded
    if !output_file.exists() {
        return Err(format!("Downloaded file not found at {:?}", output_file));
    }

    let file_size = fs::metadata(&output_file)
        .map_err(|e| format!("Failed to get file metadata: {}", e))?
        .len();

    println!("✓ Download completed successfully");
    println!(
        "✓ File size: {} bytes ({:.2} MB)",
        file_size,
        file_size as f64 / 1_048_576.0
    );

    Ok(())
}

/// Analyze proxy logs for cache behavior
fn analyze_proxy_logs(config: &ProxyTestConfig, attempt: u32) -> CacheAnalysis {
    println!("\n=== Analyzing Proxy Logs (Attempt {}) ===", attempt);

    let app_log_dir = config.cache_dir.join("logs/app");
    let mut analysis = CacheAnalysis::default();

    if !app_log_dir.exists() {
        println!(
            "Warning: App log directory not found: {}",
            app_log_dir.display()
        );
        return analysis;
    }

    // Read all log files
    if let Ok(entries) = fs::read_dir(&app_log_dir) {
        for entry in entries.flatten() {
            if let Ok(content) = fs::read_to_string(entry.path()) {
                for line in content.lines() {
                    // Look for cache-related log entries
                    if line.contains("[RANGE_OVERLAP]") {
                        if line.contains("result=exact_match") {
                            analysis.exact_matches += 1;
                        } else if line.contains("result=partial_overlap") {
                            analysis.partial_overlaps += 1;
                        } else if line.contains("result=no_overlap") {
                            analysis.no_overlaps += 1;
                        }
                    }

                    if line.contains("[RANGE_MERGE]") {
                        analysis.range_merges += 1;
                        if line.contains("mismatch") || line.contains("error") {
                            analysis.merge_errors += 1;
                        }
                    }

                    if line.contains("cache_hit") {
                        analysis.cache_hits += 1;
                    }

                    if line.contains("cache_miss") {
                        analysis.cache_misses += 1;
                    }

                    if line.contains("S3 request") || line.contains("Fetching from S3") {
                        analysis.s3_requests += 1;
                    }
                }
            }
        }
    }

    println!("Cache Hits: {}", analysis.cache_hits);
    println!("Cache Misses: {}", analysis.cache_misses);
    println!("S3 Requests: {}", analysis.s3_requests);
    println!("Exact Matches: {}", analysis.exact_matches);
    println!("Partial Overlaps: {}", analysis.partial_overlaps);
    println!("No Overlaps: {}", analysis.no_overlaps);
    println!("Range Merges: {}", analysis.range_merges);
    println!("Merge Errors: {}", analysis.merge_errors);

    analysis
}

#[derive(Default, Debug)]
struct CacheAnalysis {
    cache_hits: usize,
    cache_misses: usize,
    s3_requests: usize,
    exact_matches: usize,
    partial_overlaps: usize,
    no_overlaps: usize,
    range_merges: usize,
    merge_errors: usize,
}

impl CacheAnalysis {
    fn cache_hit_rate(&self) -> f64 {
        let total = self.cache_hits + self.cache_misses;
        if total == 0 {
            0.0
        } else {
            (self.cache_hits as f64 / total as f64) * 100.0
        }
    }
}

#[test]
#[ignore] // Requires sudo and AWS credentials
fn test_real_world_cache_with_100mb_file() {
    // Check if running with sudo
    let euid = unsafe { libc::geteuid() };
    if euid != 0 {
        panic!("This test requires sudo. Run with: sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored");
    }

    println!("\n╔════════════════════════════════════════════════════════════╗");
    println!("║  Real-World S3 Proxy Cache Test - 100MB File Download     ║");
    println!("╚════════════════════════════════════════════════════════════╝");

    // Setup test environment
    let temp_dir = TempDir::new().expect("Failed to create temp dir");
    let config = ProxyTestConfig::new(&temp_dir);
    config.write_config();

    // Clear cache before starting
    config.clear_cache_for_object();

    // Start proxy
    let mut proxy_process = start_proxy(&config);

    // Wait for proxy to be ready
    assert!(
        wait_for_proxy_ready(30),
        "Proxy failed to start within 30 seconds"
    );

    // Give proxy a moment to fully initialize
    std::thread::sleep(Duration::from_secs(2));

    // First download - should be cache miss
    println!("\n╔════════════════════════════════════════════════════════════╗");
    println!("║  FIRST DOWNLOAD - Expected: Cache Miss, S3 Fetch          ║");
    println!("╚════════════════════════════════════════════════════════════╝");

    match download_with_aws_cli(&config, 1) {
        Ok(_) => println!("✓ First download completed successfully"),
        Err(e) => {
            // Kill proxy before panicking
            let _ = Command::new("sudo")
                .args(["kill", &proxy_process.id().to_string()])
                .status();
            panic!("First download failed: {}", e);
        }
    }

    // Analyze first download
    let first_analysis = analyze_proxy_logs(&config, 1);

    // Verify first download was a cache miss
    assert!(
        first_analysis.s3_requests > 0,
        "First download should have made S3 requests, but found 0"
    );

    println!("\n✓ First download verified: Cache miss with S3 fetch");

    // Wait a moment for cache to settle
    std::thread::sleep(Duration::from_secs(2));

    // Second download - should be 100% cache hit
    println!("\n╔════════════════════════════════════════════════════════════╗");
    println!("║  SECOND DOWNLOAD - Expected: 100% Cache Hit, No S3        ║");
    println!("╚════════════════════════════════════════════════════════════╝");

    match download_with_aws_cli(&config, 2) {
        Ok(_) => println!("✓ Second download completed successfully"),
        Err(e) => {
            // Kill proxy before panicking
            let _ = Command::new("sudo")
                .args(["kill", &proxy_process.id().to_string()])
                .status();
            panic!("Second download failed: {}", e);
        }
    }

    // Analyze second download
    let second_analysis = analyze_proxy_logs(&config, 2);

    // Calculate cache hit rate
    let cache_hit_rate = second_analysis.cache_hit_rate();
    println!("\n=== Cache Performance Summary ===");
    println!("Cache Hit Rate: {:.2}%", cache_hit_rate);

    // Verify 100% cache hit (or very close)
    assert!(
        cache_hit_rate >= 99.0,
        "Expected ~100% cache hit rate on second download, got {:.2}%",
        cache_hit_rate
    );

    // Verify no range merge errors
    assert_eq!(
        second_analysis.merge_errors, 0,
        "Found {} range merge errors on second download",
        second_analysis.merge_errors
    );

    // Verify no additional S3 requests on second download
    let new_s3_requests = second_analysis.s3_requests - first_analysis.s3_requests;
    assert_eq!(
        new_s3_requests, 0,
        "Second download should not make S3 requests, but made {}",
        new_s3_requests
    );

    println!("\n✓ Second download verified: 100% cache hit, no S3 requests");
    println!("✓ No range merge errors detected");

    // Verify downloaded files are identical
    let file1 = config.download_dir.join("100MB_attempt_1");
    let file2 = config.download_dir.join("100MB_attempt_2");

    let size1 = fs::metadata(&file1).unwrap().len();
    let size2 = fs::metadata(&file2).unwrap().len();

    assert_eq!(
        size1, size2,
        "Downloaded files have different sizes: {} vs {}",
        size1, size2
    );

    println!(
        "\n✓ Both downloads produced identical file sizes: {} bytes",
        size1
    );

    // Cleanup: Kill proxy
    println!("\n=== Cleaning up ===");
    let kill_status = Command::new("sudo")
        .args(["kill", &proxy_process.id().to_string()])
        .status()
        .expect("Failed to kill proxy");

    if kill_status.success() {
        println!("✓ Proxy stopped successfully");
    }

    // Wait for process to exit
    let _ = proxy_process.wait();

    println!("\n╔════════════════════════════════════════════════════════════╗");
    println!("║  TEST PASSED - Cache working correctly with 100MB file    ║");
    println!("╚════════════════════════════════════════════════════════════╝");
}

#[test]
#[ignore] // Requires sudo and AWS credentials
fn test_real_world_cache_with_range_requests() {
    // Check if running with sudo
    let euid = unsafe { libc::geteuid() };
    if euid != 0 {
        panic!("This test requires sudo. Run with: sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored");
    }

    println!("\n╔════════════════════════════════════════════════════════════╗");
    println!("║  Real-World S3 Proxy Cache Test - Range Requests          ║");
    println!("╚════════════════════════════════════════════════════════════╝");

    // Setup test environment
    let temp_dir = TempDir::new().expect("Failed to create temp dir");
    let config = ProxyTestConfig::new(&temp_dir);
    config.write_config();

    // Clear cache before starting
    config.clear_cache_for_object();

    // Start proxy
    let mut proxy_process = start_proxy(&config);

    // Wait for proxy to be ready
    assert!(
        wait_for_proxy_ready(30),
        "Proxy failed to start within 30 seconds"
    );

    std::thread::sleep(Duration::from_secs(2));

    // Download with range request (first 10MB)
    println!("\n=== Downloading first 10MB with range request ===");
    let output_file = config.download_dir.join("100MB_range_0_10MB");

    let output = Command::new("aws")
        .args([
            "s3api",
            "get-object",
            "--bucket",
            TEST_BUCKET,
            "--key",
            TEST_OBJECT,
            "--range",
            "bytes=0-10485759", // First 10MB
            "--endpoint-url",
            S3_ENDPOINT,
            output_file.to_str().unwrap(),
        ])
        .output()
        .expect("Failed to execute aws cli");

    assert!(output.status.success(), "Range request failed");
    println!("✓ First 10MB downloaded");

    std::thread::sleep(Duration::from_secs(2));

    // Download full file - should use cached range + fetch rest
    println!("\n=== Downloading full file (should use cached 10MB) ===");
    match download_with_aws_cli(&config, 1) {
        Ok(_) => println!("✓ Full file download completed"),
        Err(e) => {
            let _ = Command::new("sudo")
                .args(["kill", &proxy_process.id().to_string()])
                .status();
            panic!("Full file download failed: {}", e);
        }
    }

    // Analyze logs
    let analysis = analyze_proxy_logs(&config, 1);

    // Should have some cache hits (the first 10MB) and some misses (the rest)
    assert!(
        analysis.cache_hits > 0,
        "Expected cache hits for first 10MB, got 0"
    );

    println!("\n✓ Cache correctly used for first 10MB");
    println!("✓ Fetched remaining data from S3");

    // Cleanup
    let _ = Command::new("sudo")
        .args(["kill", &proxy_process.id().to_string()])
        .status();
    let _ = proxy_process.wait();

    println!("\n╔════════════════════════════════════════════════════════════╗");
    println!("║  TEST PASSED - Range request caching working correctly    ║");
    println!("╚════════════════════════════════════════════════════════════╝");
}
