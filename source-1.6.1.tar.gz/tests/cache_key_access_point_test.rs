//! Property-based tests for access point cache key collision bug
//!
//! **Property 1: Fault Condition** — Access Point Cache Key Collision
//!
//! The current `generate_cache_key(path)` ignores the Host header entirely.
//! For access point requests (regional AP and MRAP), the path contains only the
//! object key (e.g., `/data/file.txt`) without any access-point identifier.
//! This causes cache key collisions between different access points.
//!
//! These tests encode the EXPECTED (correct) behavior: cache keys SHOULD be
//! uniquely prefixed per access point. On unfixed code, these assertions FAIL,
//! proving the bug exists.
//!
//! **Validates: Requirements 1.1, 1.3, 1.4, 1.6, 1.7**

use quickcheck::{Arbitrary, Gen, QuickCheck, TestResult};
use s3_proxy::cache::CacheManager;

// ============================================================================
// Generators
// ============================================================================

/// A random S3 object path (e.g., "/data/file.txt", "/deep/nested/object.bin")
#[derive(Debug, Clone)]
struct ObjectPath(String);

impl Arbitrary for ObjectPath {
    fn arbitrary(g: &mut Gen) -> Self {
        let depth = 1 + (u8::arbitrary(g) % 4) as usize; // 1-4 segments
        let segments: Vec<String> = (0..depth)
            .map(|_| {
                let len = 1 + (u8::arbitrary(g) % 12) as usize;
                let chars: String = (0..len)
                    .map(|_| {
                        let idx = u8::arbitrary(g) % 36;
                        if idx < 26 {
                            (b'a' + idx) as char
                        } else {
                            (b'0' + idx - 26) as char
                        }
                    })
                    .collect();
                chars
            })
            .collect();
        ObjectPath(format!("/{}", segments.join("/")))
    }
}

/// A random regional access point name (lowercase alphanumeric + hyphens, 3-50 chars)
#[derive(Debug, Clone)]
struct ApName(String);

impl Arbitrary for ApName {
    fn arbitrary(g: &mut Gen) -> Self {
        let len = 3 + (u8::arbitrary(g) % 20) as usize;
        let name: String = (0..len)
            .map(|_| {
                let idx = u8::arbitrary(g) % 37;
                if idx < 26 {
                    (b'a' + idx) as char
                } else if idx < 36 {
                    (b'0' + idx - 26) as char
                } else {
                    '-'
                }
            })
            .collect();
        ApName(name)
    }
}

/// A random 12-digit AWS account ID
#[derive(Debug, Clone)]
struct AccountId(String);

impl Arbitrary for AccountId {
    fn arbitrary(g: &mut Gen) -> Self {
        let digits: String = (0..12)
            .map(|_| {
                let d = u8::arbitrary(g) % 10;
                (b'0' + d) as char
            })
            .collect();
        AccountId(digits)
    }
}

/// A random MRAP alias (lowercase alphanumeric, typically 13 chars)
#[derive(Debug, Clone)]
struct MrapAlias(String);

impl Arbitrary for MrapAlias {
    fn arbitrary(g: &mut Gen) -> Self {
        let len = 8 + (u8::arbitrary(g) % 10) as usize;
        let alias: String = (0..len)
            .map(|_| {
                let idx = u8::arbitrary(g) % 36;
                if idx < 26 {
                    (b'a' + idx) as char
                } else {
                    (b'0' + idx - 26) as char
                }
            })
            .collect();
        MrapAlias(alias)
    }
}

/// A random AWS region
#[derive(Debug, Clone)]
struct AwsRegion(String);

impl Arbitrary for AwsRegion {
    fn arbitrary(g: &mut Gen) -> Self {
        let regions = [
            "us-east-1",
            "us-west-2",
            "eu-west-1",
            "eu-central-1",
            "ap-southeast-1",
            "ap-northeast-1",
        ];
        let idx = u8::arbitrary(g) as usize % regions.len();
        AwsRegion(regions[idx].to_string())
    }
}

// ============================================================================
// Helper: build host strings
// ============================================================================

fn regional_ap_host(name: &str, account_id: &str, region: &str) -> String {
    format!(
        "{}-{}.s3-accesspoint.{}.amazonaws.com",
        name, account_id, region
    )
}

fn mrap_host(alias: &str) -> String {
    format!("{}.accesspoint.s3-global.amazonaws.com", alias)
}

// ============================================================================
// Property 1a: Two different regional APs with the same path SHOULD produce
// different cache keys. On unfixed code they produce identical keys (collision).
// **Validates: Requirements 1.1, 1.3**
// ============================================================================

fn prop_regional_ap_collision(
    ap1_name: ApName,
    ap1_account: AccountId,
    ap2_name: ApName,
    ap2_account: AccountId,
    region: AwsRegion,
    path: ObjectPath,
) -> TestResult {
    let host1 = regional_ap_host(&ap1_name.0, &ap1_account.0, &region.0);
    let host2 = regional_ap_host(&ap2_name.0, &ap2_account.0, &region.0);

    // Skip if the two hosts happen to be identical
    if host1 == host2 {
        return TestResult::discard();
    }

    let key1 = CacheManager::generate_cache_key(&path.0, Some(&host1));
    let key2 = CacheManager::generate_cache_key(&path.0, Some(&host2));

    // Expected behavior: different AP hosts with same path SHOULD produce different keys
    TestResult::from_bool(key1 != key2)
}

#[test]
fn test_regional_ap_cache_key_collision() {
    QuickCheck::new().tests(100).quickcheck(
        prop_regional_ap_collision
            as fn(ApName, AccountId, ApName, AccountId, AwsRegion, ObjectPath) -> TestResult,
    );
}

// ============================================================================
// Property 1b: Two different MRAPs with the same path SHOULD produce
// different cache keys. On unfixed code they produce identical keys (collision).
// **Validates: Requirements 1.4, 1.6**
// ============================================================================

fn prop_mrap_collision(
    alias1: MrapAlias,
    alias2: MrapAlias,
    path: ObjectPath,
) -> TestResult {
    let host1 = mrap_host(&alias1.0);
    let host2 = mrap_host(&alias2.0);

    // Skip if the two hosts happen to be identical
    if host1 == host2 {
        return TestResult::discard();
    }

    let key1 = CacheManager::generate_cache_key(&path.0, Some(&host1));
    let key2 = CacheManager::generate_cache_key(&path.0, Some(&host2));

    // Expected behavior: different MRAP hosts with same path SHOULD produce different keys
    TestResult::from_bool(key1 != key2)
}

#[test]
fn test_mrap_cache_key_collision() {
    QuickCheck::new()
        .tests(100)
        .quickcheck(prop_mrap_collision as fn(MrapAlias, MrapAlias, ObjectPath) -> TestResult);
}

// ============================================================================
// Property 1c: A regional AP and an MRAP with the same path SHOULD produce
// different cache keys. On unfixed code they produce identical keys (collision).
// **Validates: Requirements 1.7**
// ============================================================================

fn prop_cross_type_collision(
    ap_name: ApName,
    ap_account: AccountId,
    region: AwsRegion,
    mrap_alias: MrapAlias,
    path: ObjectPath,
) -> TestResult {
    let ap_host = regional_ap_host(&ap_name.0, &ap_account.0, &region.0);
    let mrap_h = mrap_host(&mrap_alias.0);

    let key_ap = CacheManager::generate_cache_key(&path.0, Some(&ap_host));
    let key_mrap = CacheManager::generate_cache_key(&path.0, Some(&mrap_h));

    // Expected behavior: regional AP and MRAP with same path SHOULD produce different keys
    TestResult::from_bool(key_ap != key_mrap)
}

#[test]
fn test_cross_type_cache_key_collision() {
    QuickCheck::new().tests(100).quickcheck(
        prop_cross_type_collision
            as fn(ApName, AccountId, AwsRegion, MrapAlias, ObjectPath) -> TestResult,
    );
}

// ============================================================================
// Property 2: Preservation — Regular Request Cache Keys Unchanged
//
// For all hosts NOT matching access point or MRAP patterns, the current
// `generate_cache_key(path)` returns `normalize_cache_key(path)` (path with
// leading slash stripped). These tests capture that baseline behavior on
// unfixed code so we can verify it is preserved after the fix.
//
// **Validates: Requirements 3.1, 3.2, 3.3, 3.4**
// ============================================================================

use s3_proxy::disk_cache::normalize_cache_key;

/// A random S3 bucket name (lowercase alphanumeric + hyphens, 3-20 chars)
#[derive(Debug, Clone)]
struct BucketName(String);

impl Arbitrary for BucketName {
    fn arbitrary(g: &mut Gen) -> Self {
        let len = 3 + (u8::arbitrary(g) % 18) as usize;
        let name: String = (0..len)
            .map(|_| {
                let idx = u8::arbitrary(g) % 37;
                if idx < 26 {
                    (b'a' + idx) as char
                } else if idx < 36 {
                    (b'0' + idx - 26) as char
                } else {
                    '-'
                }
            })
            .collect();
        BucketName(name)
    }
}

// ============================================================================
// Property 2a: Path-style S3 hosts — cache key equals normalize_cache_key(path)
//
// For hosts matching `s3.{region}.amazonaws.com`, the cache key for any path
// is simply the path with the leading slash stripped.
//
// **Validates: Requirements 3.1**
// ============================================================================

fn prop_path_style_preservation(region: AwsRegion, bucket: BucketName, path: ObjectPath) -> TestResult {
    let host = format!("s3.{}.amazonaws.com", region.0);

    // Build a path-style path: /{bucket}/{object_path_without_leading_slash}
    let object_part = path.0.strip_prefix('/').unwrap_or(&path.0);
    let full_path = format!("/{}/{}", bucket.0, object_part);

    let cache_key = CacheManager::generate_cache_key(&full_path, Some(&host));
    let expected = normalize_cache_key(&full_path);

    TestResult::from_bool(cache_key == expected)
}

#[test]
fn test_path_style_cache_key_preservation() {
    QuickCheck::new().tests(200).quickcheck(
        prop_path_style_preservation as fn(AwsRegion, BucketName, ObjectPath) -> TestResult,
    );
}

// ============================================================================
// Property 2b: Virtual-hosted-style S3 hosts — cache key equals
// normalize_cache_key(path)
//
// For hosts matching `{bucket}.s3.{region}.amazonaws.com`, the cache key for
// any path is simply the path with the leading slash stripped.
//
// **Validates: Requirements 3.2**
// ============================================================================

fn prop_virtual_hosted_preservation(
    region: AwsRegion,
    bucket: BucketName,
    path: ObjectPath,
) -> TestResult {
    let host = format!("{}.s3.{}.amazonaws.com", bucket.0, region.0);

    // Virtual-hosted path is just the object key (e.g., /data/file.txt)
    let cache_key = CacheManager::generate_cache_key(&path.0, Some(&host));
    let expected = normalize_cache_key(&path.0);

    TestResult::from_bool(cache_key == expected)
}

#[test]
fn test_virtual_hosted_cache_key_preservation() {
    QuickCheck::new().tests(200).quickcheck(
        prop_virtual_hosted_preservation as fn(AwsRegion, BucketName, ObjectPath) -> TestResult,
    );
}

// ============================================================================
// Property 2c: Range/part cache keys for non-AP hosts — range and part suffixes
// are appended to normalize_cache_key(path) without any prefix.
//
// **Validates: Requirements 3.3, 3.4**
// ============================================================================

fn prop_range_part_preservation(
    region: AwsRegion,
    bucket: BucketName,
    path: ObjectPath,
) -> TestResult {
    let host = format!("s3.{}.amazonaws.com", region.0);

    let object_part = path.0.strip_prefix('/').unwrap_or(&path.0);
    let full_path = format!("/{}/{}", bucket.0, object_part);
    let normalized = normalize_cache_key(&full_path);

    // Part cache key should be "{normalized}:part:{n}"
    let part_key = CacheManager::generate_part_cache_key(&full_path, 1, Some(&host));
    let expected_part = format!("{}:part:1", normalized);

    // Range cache key should be "{normalized}:range:{start}-{end}"
    let range_key = CacheManager::generate_range_cache_key(&full_path, 0, 1024, Some(&host));
    let expected_range = format!("{}:range:0-1024", normalized);

    TestResult::from_bool(part_key == expected_part && range_key == expected_range)
}

#[test]
fn test_range_part_cache_key_preservation() {
    QuickCheck::new().tests(200).quickcheck(
        prop_range_part_preservation as fn(AwsRegion, BucketName, ObjectPath) -> TestResult,
    );
}

// ============================================================================
// Unit tests for `extract_access_point_prefix`
//
// **Validates: Requirements 2.1, 2.4, 3.1, 3.2**
// ============================================================================

use s3_proxy::cache::extract_access_point_prefix;

#[test]
fn test_extract_regional_ap_prefix() {
    let host = "my-ap-123456789012.s3-accesspoint.us-east-1.amazonaws.com";
    assert_eq!(
        extract_access_point_prefix(host),
        Some("my-ap-123456789012".to_string())
    );
}

#[test]
fn test_extract_mrap_prefix() {
    let host = "mfzwi23gnjvgw.accesspoint.s3-global.amazonaws.com";
    assert_eq!(
        extract_access_point_prefix(host),
        Some("mfzwi23gnjvgw".to_string())
    );
}

#[test]
fn test_extract_path_style_host_returns_none() {
    let host = "s3.us-east-1.amazonaws.com";
    assert_eq!(extract_access_point_prefix(host), None);
}

#[test]
fn test_extract_virtual_hosted_host_returns_none() {
    let host = "my-bucket.s3.us-east-1.amazonaws.com";
    assert_eq!(extract_access_point_prefix(host), None);
}

#[test]
fn test_extract_empty_string_returns_none() {
    assert_eq!(extract_access_point_prefix(""), None);
}

#[test]
fn test_extract_no_dots_returns_none() {
    assert_eq!(extract_access_point_prefix("localhost"), None);
}

#[test]
fn test_extract_partial_match_s3_accesspoint_no_prefix() {
    // Host is exactly the suffix with no prefix before it
    let host = ".s3-accesspoint.us-east-1.amazonaws.com";
    assert_eq!(extract_access_point_prefix(host), None);
}

#[test]
fn test_extract_partial_match_mrap_no_alias() {
    // Host is exactly the suffix with no alias before it
    let host = ".accesspoint.s3-global.amazonaws.com";
    assert_eq!(extract_access_point_prefix(host), None);
}

#[test]
fn test_extract_bare_accesspoint_suffix_returns_none() {
    // Just the suffix, no leading dot or prefix
    let host = "accesspoint.s3-global.amazonaws.com";
    assert_eq!(extract_access_point_prefix(host), None);
}

#[test]
fn test_extract_regional_ap_different_region() {
    let host = "data-ap-999888777666.s3-accesspoint.eu-west-1.amazonaws.com";
    assert_eq!(
        extract_access_point_prefix(host),
        Some("data-ap-999888777666".to_string())
    );
}
