import csv, os, glob, json

def load_durations(results_dir):
    files = glob.glob(os.path.join(results_dir, "**", "*.csv"), recursive=True)
    durations = []
    errors = 0
    total_bytes = 0
    for f in files:
        with open(f, encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                d = int(row.get("duration_ms", 0))
                durations.append(d)
                total_bytes += int(row.get("size_bytes", 0))
                if row.get("status") == "error":
                    errors += 1
    return durations, errors, total_bytes, len(files)

def histogram(durations, label):
    buckets = [
        (0, 100, "0-100ms"),
        (100, 250, "100-250ms"),
        (250, 500, "250-500ms"),
        (500, 750, "500-750ms"),
        (750, 1000, "750ms-1s"),
        (1000, 2000, "1-2s"),
        (2000, 5000, "2-5s"),
        (5000, 10000, "5-10s"),
        (10000, 30000, "10-30s"),
        (30000, 999999, "30s+"),
    ]
    n = len(durations)
    if n == 0:
        print(f"{label}: No data")
        return

    durations.sort()
    p50 = durations[n // 2]
    p90 = durations[int(n * 0.9)]
    p95 = durations[int(n * 0.95)]
    p99 = durations[int(n * 0.99)]
    avg = sum(durations) / n

    print(f"\n{'='*70}")
    print(f"  {label}")
    print(f"{'='*70}")
    print(f"  Downloads: {n}  |  Avg: {avg:.0f}ms  |  P50: {p50}ms  |  P90: {p90}ms  |  P95: {p95}ms  |  P99: {p99}ms")
    print(f"  Min: {durations[0]}ms  |  Max: {durations[-1]}ms")
    print()
    print(f"  {'Bucket':<12} {'Count':>7} {'Pct':>7} {'Bar'}")
    print(f"  {'-'*12} {'-'*7} {'-'*7} {'-'*40}")
    for lo, hi, name in buckets:
        count = sum(1 for d in durations if lo <= d < hi)
        pct = count / n * 100
        bar = '#' * int(pct / 2)
        if count > 0:
            print(f"  {name:<12} {count:>7} {pct:>6.1f}% {bar}")

def load_metrics_v2(label):
    metrics_dir = "nonpublic/test-platform/results/metrics"
    totals = {}
    keys_to_sum = ["hits", "misses", "size_bytes", "evictions"]

    for inst in ["i-0c2dc9618325b3ac8", "i-07e18a197171fc9ee", "i-0f441137c0c3d2a98"]:
        path = os.path.join(metrics_dir, f"{label}-{inst}.json")
        if not os.path.exists(path):
            continue
        try:
            data = json.loads(open(path, encoding="utf-8").read())
        except:
            continue

        # RAM cache
        ram = data.get("ram_cache", {})
        totals.setdefault("ram_hits", 0)
        totals["ram_hits"] += ram.get("hits", 0)
        totals.setdefault("ram_misses", 0)
        totals["ram_misses"] += ram.get("misses", 0)

        # Disk cache
        disk = data.get("disk_cache", {})
        totals.setdefault("disk_hits", 0)
        totals["disk_hits"] += disk.get("hits", 0)
        totals.setdefault("disk_misses", 0)
        totals["disk_misses"] += disk.get("misses", 0)

        # Overall
        overall = data.get("overall", {})
        totals.setdefault("total_requests", 0)
        totals["total_requests"] += overall.get("total_requests", 0)
        totals.setdefault("s3_saved_bytes", 0)
        totals["s3_saved_bytes"] += overall.get("s3_transfer_saved_bytes", 0)

    total_req = totals.get("total_requests", 0)
    ram_hits = totals.get("ram_hits", 0)
    ram_misses = totals.get("ram_misses", 0)
    disk_hits = totals.get("disk_hits", 0)
    disk_misses = totals.get("disk_misses", 0)
    s3_saved = totals.get("s3_saved_bytes", 0)

    # Cache misses = requests that went to S3
    total_lookups = ram_hits + ram_misses
    cache_hit_rate = (ram_hits + disk_hits) / total_lookups * 100 if total_lookups > 0 else 0

    print(f"\n  Proxy Metrics (sum across 3 proxies):")
    print(f"    Total requests: {total_req}")
    print(f"    RAM cache:  hits={ram_hits}  misses={ram_misses}  hit_rate={ram_hits/(ram_hits+ram_misses)*100 if (ram_hits+ram_misses)>0 else 0:.1f}%")
    print(f"    Disk cache: hits={disk_hits}  misses={disk_misses}  hit_rate={disk_hits/(disk_hits+disk_misses)*100 if (disk_hits+disk_misses)>0 else 0:.1f}%")
    print(f"    S3 transfer saved: {s3_saved/1e9:.1f} GB")
    print(f"    Estimated S3 fetches (disk misses): {disk_misses}")

# Standard TTL (re-run with clean metrics)
durations, errors, total_bytes, instances = load_durations("nonpublic/test-platform/results/stampede-20260217-185630")
histogram(durations, "STANDARD TTL (via proxy, ~10yr TTL)")
print(f"  Errors: {errors}  |  Total data: {total_bytes/1e9:.1f} GB  |  Instances: {instances}")
load_metrics_v2("standard-ttl-v2")

# Zero TTL (clean re-run with valid JSON settings and proper metrics)
durations, errors, total_bytes, instances = load_durations("nonpublic/test-platform/results/stampede-zerottl-20260217-193928")
histogram(durations, "ZERO TTL (via proxy, get_ttl=0s, revalidation)")
print(f"  Errors: {errors}  |  Total data: {total_bytes/1e9:.1f} GB  |  Instances: {instances}")
load_metrics_v2("zero-ttl-v4")

# Direct to S3
durations, errors, total_bytes, instances = load_durations("nonpublic/test-platform/results/stampede-direct-20260217-184633")
histogram(durations, "DIRECT TO S3 (no proxy, dualstack endpoint)")
print(f"  Errors: {errors}  |  Total data: {total_bytes/1e9:.1f} GB  |  Instances: {instances}")
