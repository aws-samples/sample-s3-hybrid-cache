import csv

findings = {"ERROR": [], "WARNING": [], "INFO": []}

with open("ProbeScanExport-cbea0202-8463-44ea-8c52-92b300e3fe35-main-20260217.csv", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        sev = row.get("Severity", "INFO")
        findings.setdefault(sev, []).append(row)

for sev in ["ERROR", "WARNING", "INFO"]:
    items = findings.get(sev, [])
    print(f"\n=== {sev} ({len(items)}) ===")
    # Group by tool + rule
    groups = {}
    for item in items:
        key = f"{item['Job Name']}: {item['Message'][:80]}"
        groups.setdefault(key, []).append(item['File Name'])
    for key, files in sorted(groups.items()):
        print(f"  {key}")
        if len(files) <= 3:
            for f in files:
                print(f"    - {f}")
        else:
            print(f"    ({len(files)} files)")
