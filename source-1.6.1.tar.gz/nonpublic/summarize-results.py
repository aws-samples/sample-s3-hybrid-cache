import csv, os, glob

def summarize(results_dir, label):
    files = glob.glob(os.path.join(results_dir, "**", "*.csv"), recursive=True)
    total_files = 0
    total_bytes = 0
    total_duration_ms = 0
    errors = 0
    durations = []
    
    for f in files:
        with open(f, encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                total_files += 1
                total_bytes += int(row.get("size_bytes", 0))
                d = int(row.get("duration_ms", 0))
                total_duration_ms += d
                durations.append(d)
                if row.get("status") == "error":
                    errors += 1
    
    durations.sort()
    n = len(durations)
    if n == 0:
        print(f"{label}: No data")
        return
    
    p50 = durations[n // 2]
    p90 = durations[int(n * 0.9)]
    p99 = durations[int(n * 0.99)]
    avg = total_duration_ms / n
    
    print(f"=== {label} ===")
    print(f"  Instances: {len(files)}")
    print(f"  Total downloads: {n}")
    print(f"  Errors: {errors}")
    print(f"  Total bytes: {total_bytes / 1e9:.2f} GB")
    print(f"  Avg latency: {avg:.0f} ms")
    print(f"  P50 latency: {p50} ms")
    print(f"  P90 latency: {p90} ms")
    print(f"  P99 latency: {p99} ms")
    print(f"  Min: {durations[0]} ms, Max: {durations[-1]} ms")
    print()

summarize("nonpublic/test-platform/results/stampede-20260217-173256", "Standard TTL (stampede)")
summarize("nonpublic/test-platform/results/stampede-zerottl-20260217-174625", "Zero TTL (stampede)")
