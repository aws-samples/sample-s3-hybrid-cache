# License Compliance Report

## Summary

All dependencies in the S3 Proxy project use approved open source licenses compatible with MIT licensing and distribution. No dependencies require legal review or special handling.

## License Categories

### Approved Licenses Used

All licenses in this project are standard open source licenses:

- **MIT** - Permissive, attribution required
- **Apache-2.0** - Permissive, attribution required
- **MIT OR Apache-2.0** - Dual licensed (choose either)
- **BSD-3-Clause** - Permissive, attribution required
- **BSD-2-Clause** - Permissive, attribution required
- **ISC** - Permissive, attribution required
- **Unlicense** - Public domain equivalent
- **Unicode-3.0** - Permissive for Unicode data
- **CC0-1.0** - Public domain dedication
- **MIT-0** - MIT without attribution requirement
- **Zlib** - Permissive, attribution required
- **BSL-1.0** - Boost Software License, permissive
- **OpenSSL** - OpenSSL License, permissive

### License Combinations

Some dependencies use combined licenses (all approved):

**Apache-2.0 WITH LLVM-exception** (rustix)
- LLVM exception relaxes Apache-2.0 requirements
- More permissive than standard Apache-2.0
- Widely used in LLVM/Rust ecosystem
- Standard Apache-2.0 attribution applies

**ISC** (ring)
- ISC is a permissive license similar to MIT
- Requires attribution in THIRD_PARTY file
- No additional restrictions

**MIT AND BSD-3-Clause** (matchit)
- Both MIT and BSD-3-Clause are approved
- Requires compliance with both licenses
- Include both attributions in THIRD_PARTY file

**CC0-1.0 OR Apache-2.0** (blake3)
- CC0-1.0 is public domain dedication (no attribution required)
- Apache-2.0 is permissive (attribution required)
- Can choose CC0-1.0 for no attribution requirement

## Core Dependencies

### Runtime & Networking
- **tokio** (1.0) - MIT
- **hyper** (1.0) - MIT
- **hyper-util** (0.1) - MIT
- **http-body-util** (0.1) - MIT
- **tower** (0.4) - MIT
- **bytes** (1.0) - MIT
- **futures** (0.3) - MIT OR Apache-2.0
- **pin-project** (1.0) - Apache-2.0 OR MIT

### Serialization & Configuration
- **serde** (1.0) - MIT OR Apache-2.0
- **serde_json** (1.0) - MIT OR Apache-2.0
- **serde_yaml** (0.9) - MIT OR Apache-2.0
- **clap** (4.0) - MIT OR Apache-2.0

### Caching & Storage
- **lz4_flex** (0.11) - MIT
- **fs2** (0.4) - MIT OR Apache-2.0
- **blake3** (1.5) - CC0-1.0 OR Apache-2.0
- **rand** (0.8) - MIT OR Apache-2.0
- **rayon** (1.8) - MIT OR Apache-2.0
- **walkdir** (2.4) - MIT OR Unlicense
- **dashmap** (6.0) - MIT

### TLS & Cryptography
- **rustls** (0.23) - Apache-2.0 OR ISC OR MIT (configured with ring backend)
- **rustls-pemfile** (2.0) - Apache-2.0 OR ISC OR MIT
- **rustls-native-certs** (0.7) - Apache-2.0 OR ISC OR MIT
- **tokio-rustls** (0.26) - MIT OR Apache-2.0 (configured with ring backend)
- **rcgen** (0.13) - MIT OR Apache-2.0
- **webpki-roots** (0.26) - MPL-2.0
- **ring** (0.17) - ISC

### Logging & Observability
- **tracing** (0.1) - MIT
- **tracing-subscriber** (0.3) - MIT
- **tracing-appender** (0.2) - MIT
- **opentelemetry** (0.24) - Apache-2.0
- **opentelemetry_sdk** (0.24) - Apache-2.0
- **opentelemetry-otlp** (0.17) - Apache-2.0
- **opentelemetry-semantic-conventions** (0.16) - Apache-2.0

### Utilities
- **anyhow** (1.0) - MIT OR Apache-2.0
- **thiserror** (1.0) - MIT OR Apache-2.0
- **chrono** (0.4) - MIT OR Apache-2.0
- **time** (0.3) - MIT OR Apache-2.0
- **uuid** (1.0) - Apache-2.0 OR MIT
- **hex** (0.4) - MIT OR Apache-2.0
- **httpdate** (1.0) - MIT OR Apache-2.0
- **urlencoding** (2.1) - MIT
- **sha2** (0.10) - MIT OR Apache-2.0
- **percent-encoding** (2.3) - MIT OR Apache-2.0
- **gethostname** (0.4) - Apache-2.0
- **hostname** (0.3) - MIT
- **libc** (0.2) - MIT OR Apache-2.0
- **scopeguard** (1.2) - MIT OR Apache-2.0
- **regex** (1.0) - MIT OR Apache-2.0
- **fastrand** (2.0) - MIT OR Apache-2.0

### DNS & Networking
- **trust-dns-resolver** (0.23) - MIT OR Apache-2.0
- **rustix** - Apache-2.0 WITH LLVM-exception

### Platform-Specific
- **winapi** (0.3, Windows only) - MIT OR Apache-2.0

### Testing
- **quickcheck** (1.0) - MIT OR Unlicense
- **quickcheck_macros** (1.0) - MIT OR Unlicense
- **tempfile** (3.0) - MIT OR Apache-2.0
- **tokio-test** (0.4) - MIT
- **filetime** (0.2) - MIT OR Apache-2.0
- **ureq** (2.9) - MIT OR Apache-2.0

## Compliance Requirements

### Attribution

All dependencies require attribution in the THIRD_PARTY_LICENSES file:

1. **MIT Licensed**: Include copyright notice and permission notice
2. **Apache-2.0 Licensed**: Include copyright notice and license text
3. **BSD Licensed**: Include copyright notice and disclaimer
4. **ISC Licensed**: Include copyright notice and permission notice
5. **Combined Licenses**: Include attribution for all required licenses

### No Copyleft Restrictions

None of the dependencies use copyleft licenses (GPL, LGPL, AGPL). All licenses are permissive and allow:
- Commercial use
- Modification
- Distribution
- Private use

### Special Cases

**BLAKE3** (CC0-1.0 OR Apache-2.0)
- Can choose CC0-1.0 (public domain, no attribution required)
- Or Apache-2.0 (attribution required)
- Recommendation: Use CC0-1.0 option for simplicity

**Unlicense** (quickcheck, walkdir)
- Public domain equivalent
- No attribution required
- Optional: Include in THIRD_PARTY for completeness

**LLVM Exception** (rustix)
- Relaxes Apache-2.0 requirements
- More permissive than standard Apache-2.0
- Standard Apache-2.0 attribution sufficient

## Verification

### Automated Checks

```bash
# List all licenses
cargo license

# Check for problematic licenses
cargo deny check licenses
```

### Manual Review

All dependencies have been manually reviewed against:
- MIT License compatibility
- Distribution requirements
- Attribution requirements
- Copyleft restrictions

## Action Items

### Required

1. Maintain THIRD_PARTY_LICENSES file with all attributions
2. Include license text for Apache-2.0 dependencies
3. Include copyright notices for MIT dependencies
4. Include copyright notices for BSD dependencies
5. Include copyright notices for ISC dependencies

### Recommended

1. Periodically run `cargo license` when updating dependencies
2. Review new dependencies before adding to Cargo.toml
3. Document any license changes in this file
4. Keep THIRD_PARTY_LICENSES file up to date

### Optional

1. Consider using `cargo-deny` for automated license checking
2. Add license check to CI/CD pipeline
3. Create script to auto-generate THIRD_PARTY_LICENSES

## Conclusion

All dependencies use approved open source licenses. All dependencies can be distributed according to their respective licenses with proper attribution in the THIRD_PARTY_LICENSES file.

**No legal review required.**

## Updates

### Version 2.3 (February 2026)
- Added dashmap dependency (MIT)
- All dependencies remain compliant

### Version 2.2 (February 2025)
- Added missing dependencies: scopeguard, regex, fastrand, winapi (all MIT OR Apache-2.0)
- Updated stale crate versions in THIRD_PARTY_LICENSES
- Removed status markers from documentation

### Version 2.1 (December 2024)
- **BREAKING CHANGE**: Switched from aws-lc-rs to ring for TLS cryptography
- Removed aws-lc-rs and aws-lc-sys dependencies (ISC AND Apache-2.0)
- Added ring dependency (ISC license)
- Configured rustls and tokio-rustls to use ring backend
- Simplified license compliance (fewer dual-licensed dependencies)
- All dependencies remain compliant

### Version 2.0 (December 2024)
- Added BLAKE3 dependency (CC0-1.0 OR Apache-2.0)
- All new dependencies verified as compliant
- No license policy changes required

### Version 1.0 (November 2024)
- Initial license compliance review
- All dependencies verified as compliant
- THIRD_PARTY_LICENSES file created

## References

- Cargo.toml - Complete dependency list
- THIRD_PARTY_LICENSES - Attribution file
- LICENSE - Project license (MIT)
