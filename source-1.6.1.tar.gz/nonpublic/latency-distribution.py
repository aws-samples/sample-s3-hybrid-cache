import csv, os, glob

def load_durations(results_dir):
    files = glob.glob(os.path.join(results_dir, "**", "*.csv"), recursive=True)
    durations = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                durations.append(int(row.get("duration_ms", 0)))
    return sorted(durations)

buckets = [
    (0, 250, "<250ms"),
    (250, 500, "250-500ms"),
    (500, 750, "500-750ms"),
    (750, 1000, "750ms-1s"),
    (1000, 1500, "1-1.5s"),
    (1500, 2000, "1.5-2s"),
    (2000, 3000, "2-3s"),
    (3000, 5000, "3-5s"),
    (5000, 10000, "5-10s"),
    (10000, 99999, "10s+"),
]

std = load_durations("nonpublic/test-platform/results/stampede-20260217-185630")
zttl = load_durations("nonpublic/test-platform/results/stampede-zerottl-20260217-193928")
direct = load_durations("nonpublic/test-platform/results/stampede-direct-20260217-184633")

def pcts(durations):
    n = len(durations)
    result = []
    for lo, hi, _ in buckets:
        count = sum(1 for d in durations if lo <= d < hi)
        result.append((count, count/n*100))
    return result

std_p = pcts(std)
zttl_p = pcts(zttl)
direct_p = pcts(direct)

print("LATENCY DISTRIBUTION — 100 clients × 100 files = 10,000 downloads each")
print()
print(f"{'Bucket':<12} {'Std TTL':>12} {'Zero TTL':>12} {'Direct S3':>12}")
print(f"{'':.<12} {'':.<12} {'':.<12} {'':.<12}")
for i, (lo, hi, name) in enumerate(buckets):
    sc, sp = std_p[i]
    zc, zp = zttl_p[i]
    dc, dp = direct_p[i]
    if sc > 0 or zc > 0 or dc > 0:
        print(f"{name:<12} {sc:>5} ({sp:>5.1f}%) {zc:>5} ({zp:>5.1f}%) {dc:>5} ({dp:>5.1f}%)")

print()
for label, d in [("Std TTL", std), ("Zero TTL", zttl), ("Direct S3", direct)]:
    n = len(d)
    print(f"{label:<12}  P50={d[n//2]}ms  P90={d[int(n*0.9)]}ms  P95={d[int(n*0.95)]}ms  P99={d[int(n*0.99)]}ms  Min={d[0]}ms  Max={d[-1]}ms")
