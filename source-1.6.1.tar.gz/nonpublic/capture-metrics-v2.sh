#!/bin/bash
set -euo pipefail
LABEL="${1:?Usage: capture-metrics-v2.sh <label>}"
REGION="us-west-2"
OUTPUT_DIR="nonpublic/test-platform/results/metrics"
mkdir -p "$OUTPUT_DIR"

CMD_ID=$(aws ssm send-command --region "$REGION" \
    --instance-ids "i-0c2dc9618325b3ac8" "i-07e18a197171fc9ee" "i-0f441137c0c3d2a98" \
    --document-name "AWS-RunShellScript" \
    --parameters '{"commands":["curl -s http://localhost:8081/api/cache-stats"]}' \
    --timeout-seconds 30 \
    --output text --query 'Command.CommandId' --no-cli-pager)

sleep 10

for INST in i-0c2dc9618325b3ac8 i-07e18a197171fc9ee i-0f441137c0c3d2a98; do
    aws ssm get-command-invocation --region "$REGION" \
        --command-id "$CMD_ID" --instance-id "$INST" \
        --query 'StandardOutputContent' --output text --no-cli-pager \
        > "$OUTPUT_DIR/${LABEL}-${INST}.json"
done

echo "Metrics saved to $OUTPUT_DIR/${LABEL}-*.json"
