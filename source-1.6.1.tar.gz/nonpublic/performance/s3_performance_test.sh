#!/bin/bash
set -e

# Performance Testing Tool for S3 Proxy
# Tests various operations with and without cache

# Configuration
# Generate unique bucket name with timestamp
UNIQUE_ID=$(date +%s)
DEFAULT_BUCKET="s3-proxy-perf-test-${UNIQUE_ID}"
BUCKET_NAME="${BUCKET_NAME:-}"
REGION="${AWS_REGION:-}"
PROXY_HOST="${PROXY_HOST:-}"
PROXY_PORT="${PROXY_PORT:-80}"  # Default to port 80 (HTTP with caching)
LOCAL_PROXY_PID=""
TEST_DIR="./perf_test_data"
RESULTS_DIR="./perf_test_results"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
HOSTS_FILE="/etc/hosts"
HOSTS_BACKUP="/tmp/hosts.backup.$$"
HOSTS_MODIFIED=false

# File sizes to test (in MB, 0.1 = 100KB)
FILE_SIZES=(0.1 1 10 50 100 500)
# Number of iterations per test
ITERATIONS=5
# Multi-part threshold (5MB)
MULTIPART_THRESHOLD=5
# Test s5cmd (can be disabled with SKIP_S5CMD=1)
SKIP_S5CMD="${SKIP_S5CMD:-0}"
# Short mode for quick testing (can be enabled with SHORT_MODE=1)
SHORT_MODE="${SHORT_MODE:-0}"

# Override settings for short mode
if [ "$SHORT_MODE" = "1" ]; then
    FILE_SIZES=(0.1 50)
    ITERATIONS=3
    SKIP_S5CMD=1
fi

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get current time in milliseconds (cross-platform)
get_time_ms() {
    python3 -c 'import time; print(int(time.time() * 1000))'
}

# Format size label (handles 0.1 MB as 100KB)
format_size_label() {
    local size=$1
    if [ "$size" = "0.1" ]; then
        echo "100KB"
    else
        echo "${size}MB"
    fi
}

# Log test result with cache status
log_test_result() {
    local size=$1
    local iteration=$2
    local duration=$3
    local throughput=$4
    local mode=$5
    
    local size_label=$(format_size_label "$size")
    
    if [ "$mode" = "proxy" ] && [ $iteration -eq 1 ]; then
        log "  ${size_label} iteration $iteration: ${duration}ms (${throughput} Mbps) [CACHE MISS]"
    elif [ "$mode" = "proxy" ] && [ $iteration -gt 1 ]; then
        log "  ${size_label} iteration $iteration: ${duration}ms (${throughput} Mbps) ✓ [CACHE HIT]"
    else
        log "  ${size_label} iteration $iteration: ${duration}ms (${throughput} Mbps)"
    fi
}

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Backup hosts file
backup_hosts() {
    if [ -f "$HOSTS_FILE" ]; then
        log "Backing up hosts file to $HOSTS_BACKUP"
        sudo cp "$HOSTS_FILE" "$HOSTS_BACKUP"
    fi
}

# Restore hosts file
restore_hosts() {
    if [ "$HOSTS_MODIFIED" = true ] && [ -f "$HOSTS_BACKUP" ]; then
        log "Restoring original hosts file..."
        sudo cp "$HOSTS_BACKUP" "$HOSTS_FILE"
        sudo rm -f "$HOSTS_BACKUP"
        HOSTS_MODIFIED=false
        log "Hosts file restored"
    fi
}

# Modify hosts file for proxy testing
setup_hosts_for_proxy() {
    log "Configuring hosts file for proxy testing..."
    
    backup_hosts
    
    # Check if entries already exist
    if grep -q "# S3 Proxy Performance Test" "$HOSTS_FILE" 2>/dev/null; then
        warn "Hosts file already configured for proxy testing"
        return
    fi
    
    # Resolve proxy hostname to IP address(es)
    log "Resolving proxy hostname: $PROXY_HOST"
    local proxy_ips=$(dig +short "$PROXY_HOST" 2>/dev/null | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -1)
    
    if [ -z "$proxy_ips" ]; then
        # Try with host command as fallback
        proxy_ips=$(host "$PROXY_HOST" 2>/dev/null | grep "has address" | awk '{print $NF}' | head -1)
    fi
    
    if [ -z "$proxy_ips" ]; then
        # If still no IP, check if it's localhost
        if [ "$PROXY_HOST" = "localhost" ] || [ "$PROXY_HOST" = "127.0.0.1" ]; then
            proxy_ips="127.0.0.1"
        else
            error "Could not resolve proxy hostname: $PROXY_HOST"
            exit 1
        fi
    fi
    
    log "Using proxy IP: $proxy_ips (resolved from $PROXY_HOST)"
    
    # Add entries using resolved IP
    local temp_file=$(mktemp)
    cat "$HOSTS_FILE" > "$temp_file"
    
    echo "" >> "$temp_file"
    echo "# S3 Proxy Performance Test - Added $(date)" >> "$temp_file"
    echo "# Proxy: $PROXY_HOST ($proxy_ips)" >> "$temp_file"
    echo "$proxy_ips s3.amazonaws.com" >> "$temp_file"
    echo "$proxy_ips $BUCKET_NAME.s3.amazonaws.com" >> "$temp_file"
    echo "$proxy_ips s3.$REGION.amazonaws.com" >> "$temp_file"
    echo "$proxy_ips $BUCKET_NAME.s3.$REGION.amazonaws.com" >> "$temp_file"
    echo "# End S3 Proxy Performance Test" >> "$temp_file"
    
    sudo cp "$temp_file" "$HOSTS_FILE"
    rm -f "$temp_file"
    
    HOSTS_MODIFIED=true
    log "Hosts file configured for proxy testing"
    log "Added entries routing S3 to: $proxy_ips ($PROXY_HOST)"
}

# Remove proxy entries from hosts file
cleanup_hosts() {
    if grep -q "# S3 Proxy Performance Test" "$HOSTS_FILE" 2>/dev/null; then
        log "Removing proxy entries from hosts file..."
        
        backup_hosts
        
        local temp_file=$(mktemp)
        sed '/# S3 Proxy Performance Test/,/# End S3 Proxy Performance Test/d' "$HOSTS_FILE" > "$temp_file"
        sudo cp "$temp_file" "$HOSTS_FILE"
        rm -f "$temp_file"
        
        log "Proxy entries removed from hosts file"
    fi
}

# Trap to ensure cleanup on exit
cleanup_on_exit() {
    restore_hosts
    stop_local_proxy
}
trap 'cleanup_on_exit' EXIT INT TERM

# Check if proxy is already running
check_existing_proxy() {
    local port=$1
    if lsof -ti:$port > /dev/null 2>&1; then
        return 0  # Proxy is running
    else
        return 1  # Proxy is not running
    fi
}

# Start local proxy
start_local_proxy() {
    # Check if proxy is already running
    if check_existing_proxy "$PROXY_PORT"; then
        log "Proxy already running on port $PROXY_PORT, using existing instance"
        return 0
    fi
    
    log "Starting local proxy..."
    
    # Check if config-perf.yaml exists
    if [ ! -f "config-perf.yaml" ]; then
        error "config-perf.yaml not found. Cannot start local proxy."
        exit 1
    fi
    
    # Start proxy in background
    cargo run --release -- -c config-perf.yaml > /tmp/proxy-perf-test.log 2>&1 &
    LOCAL_PROXY_PID=$!
    
    log "Proxy starting (PID: $LOCAL_PROXY_PID)..."
    
    # Wait for proxy to be ready (use S3 endpoint to avoid localhost DNS issues)
    local max_wait=30
    local waited=0
    while [ $waited -lt $max_wait ]; do
        # Test with a real S3 endpoint that proxy can resolve
        if curl -s -H "Host: s3.eu-west-1.amazonaws.com" "http://localhost:$PROXY_PORT/" > /dev/null 2>&1; then
            log "Local proxy ready on port $PROXY_PORT"
            return 0
        fi
        sleep 1
        waited=$((waited + 1))
    done
    
    error "Local proxy failed to start within ${max_wait}s"
    cat /tmp/proxy-perf-test.log
    exit 1
}

# Stop local proxy
stop_local_proxy() {
    if [ -n "$LOCAL_PROXY_PID" ]; then
        log "Stopping local proxy (PID: $LOCAL_PROXY_PID)..."
        kill $LOCAL_PROXY_PID 2>/dev/null || true
        wait $LOCAL_PROXY_PID 2>/dev/null || true
        LOCAL_PROXY_PID=""
        log "Local proxy stopped"
    else
        # Don't stop proxy if we didn't start it
        log "Using existing proxy, not stopping"
    fi
}

# Prompt for configuration
prompt_config() {
    if [ -z "$BUCKET_NAME" ]; then
        # Try to find existing bucket first
        existing_bucket=$(find_existing_bucket)
        if [ $? -eq 0 ] && [ -n "$existing_bucket" ]; then
            log "Found existing bucket: $existing_bucket"
            read -p "Use existing bucket $existing_bucket? (Y/n): " use_existing
            if [[ ! $use_existing =~ ^[Nn]$ ]]; then
                BUCKET_NAME="$existing_bucket"
                log "Using existing bucket: $BUCKET_NAME"
            else
                read -p "Enter S3 bucket name (default: $DEFAULT_BUCKET): " input_bucket
                BUCKET_NAME="${input_bucket:-$DEFAULT_BUCKET}"
            fi
        else
            read -p "Enter S3 bucket name (default: $DEFAULT_BUCKET): " input_bucket
            BUCKET_NAME="${input_bucket:-$DEFAULT_BUCKET}"
        fi
    fi
    
    if [ -z "$REGION" ]; then
        echo ""
        read -p "Enter AWS region (default: us-east-1): " input_region
        REGION="${input_region:-us-east-1}"
    fi
    
    if [ -z "$PROXY_HOST" ]; then
        echo ""
        echo "Proxy Configuration:"
        echo "  - Enter proxy DNS name/hostname for remote proxy (e.g., proxy.example.com)"
        echo "  - Press Enter to start local proxy on localhost"
        read -p "Proxy hostname (default: start local proxy): " input_proxy
        
        if [ -z "$input_proxy" ]; then
            PROXY_HOST="localhost"
            PROXY_PORT="80"  # Always use port 80 for local proxy
            start_local_proxy
        else
            PROXY_HOST="$input_proxy"
            if [ -z "$PROXY_PORT" ]; then
                read -p "Proxy port (default: 80): " input_port
                PROXY_PORT="${input_port:-80}"
            fi
        fi
    else
        # PROXY_HOST was set via environment variable
        # PROXY_PORT defaults to 80 (set at top of script)
        :
    fi
    
    log "Configuration:"
    log "  Bucket: $BUCKET_NAME"
    log "  Region: $REGION"
    log "  Proxy: $PROXY_HOST:$PROXY_PORT"
    echo ""
}

# Check dependencies
check_dependencies() {
    log "Checking dependencies..."
    
    local missing_deps=()
    
    if ! command -v aws &> /dev/null; then
        missing_deps+=("aws-cli")
    fi
    
    if ! command -v s5cmd &> /dev/null; then
        missing_deps+=("s5cmd")
    fi
    
    if ! command -v python3 &> /dev/null; then
        missing_deps+=("python3")
    fi
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        error "Missing dependencies: ${missing_deps[*]}"
        echo "Install instructions:"
        echo "  aws-cli: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html"
        echo "  s5cmd: brew install peak/tap/s5cmd (macOS) or https://github.com/peak/s5cmd"
        echo "  python3: brew install python3 (macOS)"
        exit 1
    fi
    
    # Configure AWS CLI to use CRT for better performance
    log "Configuring AWS CLI to use S3 Common Runtime (CRT)..."
    aws configure set default.s3.preferred_transfer_client crt
    
    # Verify CRT is configured
    local crt_setting=$(aws configure get default.s3.preferred_transfer_client)
    if [ "$crt_setting" = "crt" ]; then
        log "AWS CLI CRT enabled successfully"
    else
        warn "Failed to enable AWS CLI CRT, performance may be reduced"
    fi
    
    log "All dependencies found"
}

# Find existing bucket with test files
find_existing_bucket() {
    log "Looking for existing test bucket..."
    
    # List buckets matching our pattern and check for required files
    local buckets=$(aws s3 ls | grep "s3-proxy-perf-test-" | awk '{print $3}' | sort -r)
    
    for bucket in $buckets; do
        log "Checking bucket: $bucket"
        
        # Check if bucket has the required test files
        local has_files=true
        for size in "${FILE_SIZES[@]}"; do
            local key="test_${size}mb.bin"
            if ! aws s3 ls "s3://$bucket/$key" --region "$REGION" > /dev/null 2>&1; then
                has_files=false
                break
            fi
        done
        
        if [ "$has_files" = true ]; then
            log "Found existing bucket with all test files: $bucket"
            echo "$bucket"
            return 0
        fi
    done
    
    log "No existing bucket found with all required files"
    return 1
}

# Setup test environment
setup_environment() {
    log "Setting up test environment..."
    
    # Create directories
    mkdir -p "$TEST_DIR"
    mkdir -p "$RESULTS_DIR"
    
    # Create bucket
    log "Creating S3 bucket: $BUCKET_NAME"
    if aws s3 mb "s3://$BUCKET_NAME" --region "$REGION" 2>/dev/null; then
        log "Bucket created successfully"
        
        # Enable CloudWatch request metrics
        log "Enabling CloudWatch metrics for bucket..."
        aws s3api put-bucket-metrics-configuration \
            --bucket "$BUCKET_NAME" \
            --id "EntireBucket" \
            --metrics-configuration '{"Id":"EntireBucket"}' \
            --region "$REGION" 2>/dev/null
        
        if [ $? -eq 0 ]; then
            log "CloudWatch metrics enabled successfully"
        else
            warn "Failed to enable CloudWatch metrics, continuing..."
        fi
    else
        warn "Bucket already exists or creation failed, continuing..."
    fi
    
    # Generate test files
    log "Generating test files..."
    for size in "${FILE_SIZES[@]}"; do
        local filename="$TEST_DIR/test_${size}mb.bin"
        if [ ! -f "$filename" ]; then
            if [ "$size" = "0.1" ]; then
                log "Creating 100KB test file..."
                dd if=/dev/urandom of="$filename" bs=1k count=100 2>/dev/null
            else
                log "Creating ${size}MB test file..."
                dd if=/dev/urandom of="$filename" bs=1m count=$size 2>/dev/null
            fi
        else
            if [ "$size" = "0.1" ]; then
                log "Test file 100KB already exists, skipping..."
            else
                log "Test file ${size}MB already exists, skipping..."
            fi
        fi
    done
    
    log "Environment setup complete"
}

# Upload test files to S3
upload_test_files() {
    log "Uploading test files to S3..."
    
    for size in "${FILE_SIZES[@]}"; do
        local filename="$TEST_DIR/test_${size}mb.bin"
        local s3_key="test_${size}mb.bin"
        
        log "Uploading ${size}MB file..."
        aws s3 cp "$filename" "s3://$BUCKET_NAME/$s3_key" --region "$REGION"
    done
    
    log "Upload complete"
}

# Test HeadObject operations
test_head_object() {
    local mode=$1  # "direct" or "proxy"
    
    # Ensure results directory exists
    mkdir -p "$RESULTS_DIR"
    
    local result_file="$RESULTS_DIR/head_${mode}_${TIMESTAMP}.csv"
    
    log "Testing HeadObject operations ($mode)..."
    echo "file_size_mb,iteration,duration_ms" > "$result_file"
    
    # Only test one representative file size (10MB)
    local size=10
    local s3_key="test_${size}mb.bin"
    
    for i in $(seq 1 $ITERATIONS); do
        local start=$(get_time_ms)
        
        if [ "$mode" = "proxy" ]; then
            # Use HTTP endpoint to hit proxy on port 80 (AWS CLI defaults to HTTPS)
            aws s3api head-object \
                --bucket "$BUCKET_NAME" \
                --key "$s3_key" \
                --endpoint-url "http://s3.${REGION}.amazonaws.com" \
                --region "$REGION" > /dev/null
        else
            aws s3api head-object \
                --bucket "$BUCKET_NAME" \
                --key "$s3_key" \
                --region "$REGION" > /dev/null
        fi
        
        local end=$(get_time_ms)
        local duration=$((end - start))
        
        echo "$size,$i,$duration" >> "$result_file"
        
        local size_label=$(format_size_label "$size")
        if [ "$mode" = "proxy" ] && [ $i -eq 1 ]; then
            log "  ${size_label} iteration $i: ${duration}ms [CACHE MISS]"
        elif [ "$mode" = "proxy" ] && [ $i -gt 1 ]; then
            log "  ${size_label} iteration $i: ${duration}ms ✓ [CACHE HIT]"
        else
            log "  ${size_label} iteration $i: ${duration}ms"
        fi
    done
    
    log "HeadObject test complete: $result_file"
}

# Test GET operations with AWS CLI (S3 Common Runtime)
test_get_aws_cli() {
    local mode=$1  # "direct" or "proxy"
    
    # Ensure results directory exists
    mkdir -p "$RESULTS_DIR"
    
    local result_file="$RESULTS_DIR/get_awscli_${mode}_${TIMESTAMP}.csv"
    
    log "Testing GET operations with AWS CLI + CRT ($mode)..."
    echo "file_size_mb,iteration,duration_ms,throughput_mbps" > "$result_file"
    
    for size in "${FILE_SIZES[@]}"; do
        local s3_key="test_${size}mb.bin"
        local download_file="$TEST_DIR/download_${size}mb.bin"
        
        for i in $(seq 1 $ITERATIONS); do
            rm -f "$download_file"
            
            local start=$(get_time_ms)
            
            # Use aws s3 cp with CRT explicitly enabled for improved performance
            if [ "$mode" = "proxy" ]; then
                # Use HTTP endpoint to hit proxy on port 80 (AWS CLI defaults to HTTPS)
                aws s3 cp "s3://$BUCKET_NAME/$s3_key" "$download_file" \
                    --endpoint-url "http://s3.$REGION.amazonaws.com" \
                    --region "$REGION" \
                    --no-progress > /dev/null 2>&1
            else
                aws s3 cp "s3://$BUCKET_NAME/$s3_key" "$download_file" \
                    --region "$REGION" \
                    --no-progress > /dev/null 2>&1
            fi
            
            local end=$(get_time_ms)
            local duration=$((end - start))
            local throughput=$(awk "BEGIN {printf \"%.2f\", ($size * 8000) / $duration}")
            
            echo "$size,$i,$duration,$throughput" >> "$result_file"
            log_test_result "$size" "$i" "$duration" "$throughput" "$mode"
        done
    done
    
    log "AWS CLI GET test complete: $result_file"
}

# Test GET operations with s5cmd
test_get_s5cmd() {
    local mode=$1  # "direct" or "proxy"
    local result_file="$RESULTS_DIR/get_s5cmd_${mode}_${TIMESTAMP}.csv"
    
    log "Testing GET operations with s5cmd ($mode)..."
    echo "file_size_mb,iteration,duration_ms,throughput_mbps" > "$result_file"
    
    for size in "${FILE_SIZES[@]}"; do
        local s3_key="test_${size}mb.bin"
        local download_file="$TEST_DIR/download_${size}mb.bin"
        
        for i in $(seq 1 $ITERATIONS); do
            rm -f "$download_file"
            
            local start=$(get_time_ms)
            
            # s5cmd uses different syntax for endpoint
            if [ "$mode" = "proxy" ]; then
                # Use HTTP endpoint to hit proxy on port 80 (s5cmd defaults to HTTPS)
                s5cmd --endpoint-url "http://s3.$REGION.amazonaws.com" \
                    --log error \
                    cp "s3://$BUCKET_NAME/$s3_key" "$download_file"
            else
                s5cmd --log error \
                    cp "s3://$BUCKET_NAME/$s3_key" "$download_file"
            fi
            
            local end=$(get_time_ms)
            local duration=$((end - start))
            
            # Check if download succeeded
            if [ ! -f "$download_file" ]; then
                warn "s5cmd download failed for ${size}MB iteration $i"
                echo "$size,$i,0,0" >> "$result_file"
                continue
            fi
            
            local throughput=$(awk "BEGIN {printf \"%.2f\", ($size * 8000) / $duration}")
            
            echo "$size,$i,$duration,$throughput" >> "$result_file"
            log_test_result "$size" "$i" "$duration" "$throughput" "$mode"
        done
    done
    
    log "s5cmd GET test complete: $result_file"
}

# Test multipart upload operations
test_multipart_upload() {
    local mode=$1  # "direct" or "proxy"
    local result_file="$RESULTS_DIR/multipart_${mode}_${TIMESTAMP}.csv"
    
    log "Testing multipart upload operations ($mode)..."
    echo "file_size_mb,iteration,duration_ms,throughput_mbps" > "$result_file"
    
    for size in "${FILE_SIZES[@]}"; do
        # Only test multipart for files >= threshold
        if [ $size -lt $MULTIPART_THRESHOLD ]; then
            continue
        fi
        
        local filename="$TEST_DIR/test_${size}mb.bin"
        local s3_key="multipart_test_${size}mb.bin"
        
        for i in $(seq 1 $ITERATIONS); do
            # Delete existing object
            aws s3 rm "s3://$BUCKET_NAME/$s3_key" --region "$REGION" 2>/dev/null || true
            
            local start=$(get_time_ms)
            
            if [ "$mode" = "proxy" ]; then
                # Use HTTP endpoint to hit proxy on port 80 (AWS CLI defaults to HTTPS)
                aws s3 cp "$filename" "s3://$BUCKET_NAME/$s3_key" \
                    --endpoint-url "http://s3.$REGION.amazonaws.com" \
                    --region "$REGION" > /dev/null
            else
                aws s3 cp "$filename" "s3://$BUCKET_NAME/$s3_key" \
                    --region "$REGION" > /dev/null
            fi
            
            local end=$(get_time_ms)
            local duration=$((end - start))
            local throughput=$(awk "BEGIN {printf \"%.2f\", ($size * 8000) / $duration}")
            
            echo "$size,$i,$duration,$throughput" >> "$result_file"
            log_test_result "$size" "$i" "$duration" "$throughput" "$mode"
        done
    done
    
    log "Multipart upload test complete: $result_file"
}

# Test Get-after-Put operations
test_get_after_put() {
    local mode=$1  # "direct" or "proxy"
    
    # Ensure results directory exists
    mkdir -p "$RESULTS_DIR"
    
    local result_file="$RESULTS_DIR/get_after_put_${mode}_${TIMESTAMP}.csv"
    
    log "Testing Get-after-Put operations ($mode)..."
    echo "file_size_mb,iteration,put_duration_ms,get_duration_ms,total_duration_ms" > "$result_file"
    
    for size in "${FILE_SIZES[@]}"; do
        local filename="$TEST_DIR/test_${size}mb.bin"
        local download_file="$TEST_DIR/gap_download_${size}mb.bin"
        
        for i in $(seq 1 $ITERATIONS); do
            local s3_key="gap_test_${size}mb_${i}.bin"
            
            # PUT operation
            local put_start=$(get_time_ms)
            
            if [ "$mode" = "proxy" ]; then
                # Use HTTP endpoint to hit proxy on port 80 (AWS CLI defaults to HTTPS)
                aws s3 cp "$filename" "s3://$BUCKET_NAME/$s3_key" \
                    --endpoint-url "http://s3.$REGION.amazonaws.com" \
                    --region "$REGION" > /dev/null
            else
                aws s3 cp "$filename" "s3://$BUCKET_NAME/$s3_key" \
                    --region "$REGION" > /dev/null
            fi
            
            local put_end=$(get_time_ms)
            local put_duration=$((put_end - put_start))
            
            # GET operation immediately after PUT
            rm -f "$download_file"
            local get_start=$(get_time_ms)
            
            if [ "$mode" = "proxy" ]; then
                # Use HTTP endpoint to hit proxy on port 80 (AWS CLI defaults to HTTPS)
                aws s3 cp "s3://$BUCKET_NAME/$s3_key" "$download_file" \
                    --endpoint-url "http://s3.$REGION.amazonaws.com" \
                    --region "$REGION" > /dev/null
            else
                aws s3 cp "s3://$BUCKET_NAME/$s3_key" "$download_file" \
                    --region "$REGION" > /dev/null
            fi
            
            local get_end=$(get_time_ms)
            local get_duration=$((get_end - get_start))
            local total_duration=$((get_end - put_start))
            
            echo "$size,$i,$put_duration,$get_duration,$total_duration" >> "$result_file"
            
            local size_label=$(format_size_label "$size")
            if [ "$mode" = "proxy" ]; then
                log "  ${size_label} iteration $i: PUT=${put_duration}ms, GET=${get_duration}ms ✓ [CACHED], TOTAL=${total_duration}ms"
            else
                log "  ${size_label} iteration $i: PUT=${put_duration}ms, GET=${get_duration}ms, TOTAL=${total_duration}ms"
            fi
        done
    done
    
    log "Get-after-Put test complete: $result_file"
}

# Generate summary report
generate_report() {
    local report_file="$RESULTS_DIR/summary_${TIMESTAMP}.txt"
    
    log "Generating summary report..."
    
    {
        echo "=========================================="
        echo "S3 Proxy Performance Test Summary"
        echo "=========================================="
        echo "Timestamp: $TIMESTAMP"
        echo "Bucket: $BUCKET_NAME"
        echo "Region: $REGION"
        echo "Proxy: $PROXY_HOST:$PROXY_PORT"
        echo "Iterations per test: $ITERATIONS"
        echo "File sizes tested: ${FILE_SIZES[*]} MB"
        echo ""
        echo "Test Results Location: $RESULTS_DIR"
        echo ""
        echo "CSV Files Generated:"
        ls -1 "$RESULTS_DIR"/*_${TIMESTAMP}.csv 2>/dev/null || echo "  No CSV files found"
        echo ""
        echo "=========================================="
    } > "$report_file"
    
    cat "$report_file"
    log "Summary report saved to: $report_file"
}

# Cleanup test data
cleanup() {
    log "Cleaning up test data..."
    
    # Cleanup hosts file entries first
    cleanup_hosts
    
    # Prompt for bucket/region if not set
    if [ -z "$BUCKET_NAME" ] || [ -z "$REGION" ]; then
        prompt_config
    fi
    
    # Check if bucket exists
    if aws s3 ls "s3://$BUCKET_NAME" --region "$REGION" 2>/dev/null; then
        log "Found bucket: $BUCKET_NAME"
        
        read -p "Delete all objects from S3 bucket? (y/N) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            log "Deleting S3 objects..."
            aws s3 rm "s3://$BUCKET_NAME" --recursive --region "$REGION"
            log "Objects deleted"
            
            read -p "Delete S3 bucket? (y/N) " -n 1 -r
            echo
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                aws s3 rb "s3://$BUCKET_NAME" --region "$REGION"
                log "Bucket deleted"
            fi
        fi
    else
        warn "Bucket $BUCKET_NAME not found or not accessible"
    fi
    
    read -p "Delete local test files? (y/N) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf "$TEST_DIR"
        log "Local test files deleted"
    fi
    
    read -p "Delete test results? (y/N) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf "$RESULTS_DIR"
        log "Test results deleted"
    fi
    
    log "Cleanup complete"
}

# Main execution
main() {
    log "Starting S3 Proxy Performance Test"
    log "===================================="
    
    check_dependencies
    
    # Parse command line arguments
    local run_mode="${1:-both}"  # "direct", "proxy", or "both"
    
    case "$run_mode" in
        setup)
            prompt_config
            setup_environment
            upload_test_files
            log "Setup complete. Run with 'direct' or 'proxy' mode to test."
            ;;
        direct)
            prompt_config
            log "Running tests in DIRECT mode (no proxy)"
            test_head_object "direct"
            test_get_aws_cli "direct"
            if [ "$SKIP_S5CMD" != "1" ]; then
                test_get_s5cmd "direct"
            fi
            test_get_after_put "direct"
            generate_report
            ;;
        proxy)
            prompt_config
            log "Running tests in PROXY mode"
            
            # Check if proxy is running (use S3 endpoint to avoid DNS issues)
            if ! curl -s -H "Host: s3.eu-west-1.amazonaws.com" "http://$PROXY_HOST:$PROXY_PORT/" > /dev/null 2>&1; then
                warn "Proxy does not appear to be running at http://$PROXY_HOST:$PROXY_PORT"
                read -p "Continue anyway? (y/N) " -n 1 -r
                echo
                if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                    exit 1
                fi
            fi
            
            setup_hosts_for_proxy
            
            test_head_object "proxy"
            test_get_aws_cli "proxy"
            if [ "$SKIP_S5CMD" != "1" ]; then
                test_get_s5cmd "proxy"
            fi
            test_get_after_put "proxy"
            generate_report
            
            restore_hosts
            ;;
        all)
            prompt_config
            setup_environment
            upload_test_files
            
            log "Running tests in DIRECT mode (no proxy)"
            test_head_object "direct"
            test_get_aws_cli "direct"
            if [ "$SKIP_S5CMD" != "1" ]; then
                test_get_s5cmd "direct"
            fi
            test_get_after_put "direct"
            
            log ""
            log "===================================="
            log "Now run tests in PROXY mode"
            log "===================================="
            warn "Make sure your proxy is running!"
            
            # Check if proxy is running (use S3 endpoint to avoid DNS issues)
            if ! curl -s -H "Host: s3.eu-west-1.amazonaws.com" "http://$PROXY_HOST:$PROXY_PORT/" > /dev/null 2>&1; then
                error "Proxy is not running at http://$PROXY_HOST:$PROXY_PORT"
                echo "Start your proxy with: cargo run --release -- -c config-perf.yaml"
                exit 1
            fi
            
            log "Proxy detected at http://$PROXY_HOST:$PROXY_PORT"
            read -p "Press Enter to configure hosts file and continue with proxy tests..."
            
            setup_hosts_for_proxy
            
            test_head_object "proxy"
            test_get_aws_cli "proxy"
            if [ "$SKIP_S5CMD" != "1" ]; then
                test_get_s5cmd "proxy"
            fi
            test_get_after_put "proxy"
            
            restore_hosts
            
            generate_report
            ;;
        cleanup)
            cleanup_hosts
            cleanup
            ;;
        *)
            echo "Usage: $0 [setup|direct|proxy|all|cleanup]"
            echo ""
            echo "Modes:"
            echo "  setup   - Create bucket and generate test files"
            echo "  direct  - Run tests directly against S3 (no proxy)"
            echo "  proxy   - Run tests through the proxy"
            echo "  all     - Run setup, direct tests, and proxy tests"
            echo "  cleanup - Remove test data from S3 and local filesystem"
            echo ""
            echo "Environment variables:"
            echo "  BUCKET_NAME   - S3 bucket name (default: auto-generated unique name)"
            echo "  AWS_REGION    - AWS region (default: prompted, or us-east-1)"
            echo "  PROXY_HOST    - Proxy hostname (default: localhost)"
            echo "  PROXY_PORT    - Proxy port (default: 80)"
            echo "  SHORT_MODE    - Run quick test with 0.1MB and 50MB files, 3 iterations (default: 0)"
            echo "  SKIP_S5CMD    - Skip s5cmd tests (default: 0)"
            exit 1
            ;;
    esac
    
    log "Performance test complete!"
}

main "$@"
