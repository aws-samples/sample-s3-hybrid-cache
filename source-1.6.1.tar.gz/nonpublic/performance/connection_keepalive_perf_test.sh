#!/bin/bash
# Performance test for connection keepalive feature
# Measures latency and throughput improvements

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
RESULTS_DIR="$SCRIPT_DIR/keepalive_results"
TEST_BUCKET="${TEST_BUCKET:-your-test-bucket}"
TEST_OBJECT="${TEST_OBJECT:-test-file.bin}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Create results directory
mkdir -p "$RESULTS_DIR"

# Check if AWS CLI is available
if ! command -v aws &> /dev/null; then
    log_error "AWS CLI not found. Please install it first."
    exit 1
fi

# Check if test bucket is configured
if [ "$TEST_BUCKET" = "your-test-bucket" ]; then
    log_warn "TEST_BUCKET not set. Using default: $TEST_BUCKET"
    log_warn "Set TEST_BUCKET environment variable to use a real bucket"
fi

log_info "Connection Keepalive Performance Test"
log_info "======================================"
log_info "Test bucket: $TEST_BUCKET"
log_info "Test object: $TEST_OBJECT"
log_info "Results dir: $RESULTS_DIR"
echo ""

# Function to measure latency for N requests
measure_latency() {
    local config_file=$1
    local request_count=$2
    local output_file=$3
    local description=$4
    
    log_info "Testing: $description"
    log_info "Config: $config_file"
    log_info "Requests: $request_count"
    
    # Start proxy in background
    log_info "Starting proxy..."
    sudo cargo run --release -- -c "$config_file" > /dev/null 2>&1 &
    local proxy_pid=$!
    
    # Wait for proxy to start
    sleep 3
    
    # Check if proxy is running
    if ! kill -0 $proxy_pid 2>/dev/null; then
        log_error "Proxy failed to start"
        return 1
    fi
    
    # Measure latency for each request
    echo "request_num,latency_ms" > "$output_file"
    
    for i in $(seq 1 $request_count); do
        local start=$(date +%s%3N)
        
        # Download file through proxy
        aws s3 cp "s3://$TEST_BUCKET/$TEST_OBJECT" /tmp/keepalive_test_$i.bin \
            --endpoint-url "http://localhost" \
            > /dev/null 2>&1 || true
        
        local end=$(date +%s%3N)
        local latency=$((end - start))
        
        echo "$i,$latency" >> "$output_file"
        log_info "Request $i: ${latency}ms"
        
        # Clean up downloaded file
        rm -f /tmp/keepalive_test_$i.bin
        
        # Small delay between requests
        sleep 0.5
    done
    
    # Stop proxy
    log_info "Stopping proxy..."
    sudo kill $proxy_pid 2>/dev/null || true
    sleep 2
    
    log_info "Results saved to: $output_file"
    echo ""
}

# Function to measure throughput
measure_throughput() {
    local config_file=$1
    local duration_secs=$2
    local output_file=$3
    local description=$4
    
    log_info "Testing: $description"
    log_info "Config: $config_file"
    log_info "Duration: ${duration_secs}s"
    
    # Start proxy in background
    log_info "Starting proxy..."
    sudo cargo run --release -- -c "$config_file" > /dev/null 2>&1 &
    local proxy_pid=$!
    
    # Wait for proxy to start
    sleep 3
    
    # Check if proxy is running
    if ! kill -0 $proxy_pid 2>/dev/null; then
        log_error "Proxy failed to start"
        return 1
    fi
    
    # Measure throughput
    local request_count=0
    local start_time=$(date +%s)
    local end_time=$((start_time + duration_secs))
    
    log_info "Running throughput test for ${duration_secs}s..."
    
    while [ $(date +%s) -lt $end_time ]; do
        aws s3 cp "s3://$TEST_BUCKET/$TEST_OBJECT" /tmp/keepalive_throughput_test.bin \
            --endpoint-url "http://localhost" \
            > /dev/null 2>&1 || true
        
        request_count=$((request_count + 1))
        
        # Clean up downloaded file
        rm -f /tmp/keepalive_throughput_test.bin
    done
    
    local actual_duration=$(($(date +%s) - start_time))
    local rps=$(echo "scale=2; $request_count / $actual_duration" | bc)
    
    # Save results
    echo "duration_secs,request_count,requests_per_second" > "$output_file"
    echo "$actual_duration,$request_count,$rps" >> "$output_file"
    
    log_info "Completed $request_count requests in ${actual_duration}s"
    log_info "Throughput: $rps requests/second"
    
    # Stop proxy
    log_info "Stopping proxy..."
    sudo kill $proxy_pid 2>/dev/null || true
    sleep 2
    
    log_info "Results saved to: $output_file"
    echo ""
}

# Create test configurations
create_test_configs() {
    log_info "Creating test configurations..."
    
    # Config with keepalive enabled (default)
    cat > "$RESULTS_DIR/config_keepalive_enabled.yaml" <<EOF
http_port: 80
https_port: 443
cache_dir: /tmp/s3_proxy_cache_keepalive_test
ram_cache_size: 1073741824
disk_cache_size: 10737418240
connection_pool:
  enabled: true
  idle_timeout: "30s"
  max_idle_per_host: 1
  max_lifetime: "300s"
EOF
    
    # Config with keepalive disabled
    cat > "$RESULTS_DIR/config_keepalive_disabled.yaml" <<EOF
http_port: 80
https_port: 443
cache_dir: /tmp/s3_proxy_cache_keepalive_test
ram_cache_size: 1073741824
disk_cache_size: 10737418240
connection_pool:
  enabled: false
EOF
    
    log_info "Test configurations created"
    echo ""
}

# Analyze results
analyze_results() {
    log_info "Analyzing results..."
    
    # Latency analysis
    if [ -f "$RESULTS_DIR/latency_with_keepalive.csv" ] && \
       [ -f "$RESULTS_DIR/latency_without_keepalive.csv" ]; then
        
        log_info "Latency Analysis:"
        
        # Calculate average latency for first request
        local first_with=$(awk -F',' 'NR==2 {print $2}' "$RESULTS_DIR/latency_with_keepalive.csv")
        local first_without=$(awk -F',' 'NR==2 {print $2}' "$RESULTS_DIR/latency_without_keepalive.csv")
        
        # Calculate average latency for subsequent requests (2-10)
        local avg_with=$(awk -F',' 'NR>2 && NR<=11 {sum+=$2; count++} END {print sum/count}' "$RESULTS_DIR/latency_with_keepalive.csv")
        local avg_without=$(awk -F',' 'NR>2 && NR<=11 {sum+=$2; count++} END {print sum/count}' "$RESULTS_DIR/latency_without_keepalive.csv")
        
        log_info "  First request (with keepalive): ${first_with}ms"
        log_info "  First request (without keepalive): ${first_without}ms"
        log_info "  Avg subsequent (with keepalive): ${avg_with}ms"
        log_info "  Avg subsequent (without keepalive): ${avg_without}ms"
        
        # Calculate improvement
        local improvement=$(echo "scale=2; $avg_without - $avg_with" | bc)
        local improvement_pct=$(echo "scale=2; ($improvement / $avg_without) * 100" | bc)
        
        log_info "  Latency improvement: ${improvement}ms (${improvement_pct}%)"
        
        # Check if improvement meets expectations (100-200ms)
        if (( $(echo "$improvement >= 100" | bc -l) )); then
            log_info "  ✓ Latency improvement meets expectations (>100ms)"
        else
            log_warn "  ✗ Latency improvement below expectations (<100ms)"
        fi
    fi
    
    echo ""
    
    # Throughput analysis
    if [ -f "$RESULTS_DIR/throughput_with_keepalive.csv" ] && \
       [ -f "$RESULTS_DIR/throughput_without_keepalive.csv" ]; then
        
        log_info "Throughput Analysis:"
        
        local rps_with=$(awk -F',' 'NR==2 {print $3}' "$RESULTS_DIR/throughput_with_keepalive.csv")
        local rps_without=$(awk -F',' 'NR==2 {print $3}' "$RESULTS_DIR/throughput_without_keepalive.csv")
        
        log_info "  With keepalive: ${rps_with} req/s"
        log_info "  Without keepalive: ${rps_without} req/s"
        
        # Calculate improvement
        local improvement=$(echo "scale=2; $rps_with - $rps_without" | bc)
        local improvement_pct=$(echo "scale=2; ($improvement / $rps_without) * 100" | bc)
        
        log_info "  Throughput improvement: ${improvement} req/s (${improvement_pct}%)"
        
        # Check if improvement meets expectations (30-50%)
        if (( $(echo "$improvement_pct >= 30" | bc -l) )); then
            log_info "  ✓ Throughput improvement meets expectations (>30%)"
        else
            log_warn "  ✗ Throughput improvement below expectations (<30%)"
        fi
    fi
    
    echo ""
}

# Main test execution
main() {
    log_info "Starting performance tests..."
    echo ""
    
    # Create test configurations
    create_test_configs
    
    # Test 1: Latency with keepalive enabled
    measure_latency \
        "$RESULTS_DIR/config_keepalive_enabled.yaml" \
        10 \
        "$RESULTS_DIR/latency_with_keepalive.csv" \
        "Latency with keepalive enabled"
    
    # Test 2: Latency with keepalive disabled
    measure_latency \
        "$RESULTS_DIR/config_keepalive_disabled.yaml" \
        10 \
        "$RESULTS_DIR/latency_without_keepalive.csv" \
        "Latency with keepalive disabled"
    
    # Test 3: Throughput with keepalive enabled
    measure_throughput \
        "$RESULTS_DIR/config_keepalive_enabled.yaml" \
        30 \
        "$RESULTS_DIR/throughput_with_keepalive.csv" \
        "Throughput with keepalive enabled"
    
    # Test 4: Throughput with keepalive disabled
    measure_throughput \
        "$RESULTS_DIR/config_keepalive_disabled.yaml" \
        30 \
        "$RESULTS_DIR/throughput_without_keepalive.csv" \
        "Throughput with keepalive disabled"
    
    # Analyze results
    analyze_results
    
    log_info "Performance tests completed!"
    log_info "Results saved to: $RESULTS_DIR"
}

# Run main function
main
