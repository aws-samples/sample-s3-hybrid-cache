# S3 Proxy Performance Testing

Comprehensive performance testing suite for the S3 proxy, including cache validation and build testing.

## Scripts

- **`s3_performance_test.sh`**: Main performance test script with multiple modes (setup, direct, proxy, all, cleanup)
- **`build_and_validate.sh`**: Build validation script that runs all tests plus short performance test with cache validation

## Features

- **Multiple file sizes**: Tests with 1MB, 10MB, 50MB, 100MB, and 500MB files
- **Multiple operations**:
  - HeadObject operations
  - GET operations (using AWS CLI with S3 Common Runtime)
  - Multipart uploads (for files ≥5MB)
  - Get-after-Put scenarios (cache effectiveness)
- **Dual testing modes**: Direct S3 access vs. Proxy access
- **Statistical analysis**: Mean, median, std dev, p95, p99 metrics
- **Automated reporting**: CSV results and summary analysis

## Prerequisites

### Required Tools

1. **AWS CLI** (with S3 Common Runtime)
   ```bash
   # macOS
   brew install awscli
   
   # Or download from:
   # https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
   ```

2. **Python 3** (for analysis script)
   ```bash
   pip install pandas
   ```

### AWS Configuration

Ensure your AWS credentials are configured:
```bash
aws configure
```

### Proxy Configuration

**Starting the Proxy:**
```bash
# For performance testing (requires sudo for ports 80/443)
sudo cargo run --release -- -c config-perf.yaml

# For production (also requires sudo for ports 80/443)
sudo cargo run --release -- -c config.yaml
```

**Why sudo is required:** The proxy needs to listen on privileged ports 80 (HTTP) and 443 (HTTPS). AWS CLI and s5cmd default to HTTPS, so we use HTTP endpoint URLs to force them to use port 80 where the proxy provides caching.

**How Proxy Routing Works:**

The proxy uses a combination of hosts file routing and HTTP endpoint URLs:

1. **Hosts File**: Routes S3 hostnames to the proxy IP
   ```
   127.0.0.1 s3.amazonaws.com
   127.0.0.1 s3.us-east-1.amazonaws.com
   ```

2. **HTTP Endpoint URL**: Force clients to use HTTP (port 80) instead of HTTPS
   ```bash
   # AWS CLI defaults to HTTPS, so we force HTTP to hit the proxy
   aws s3 cp file.txt s3://bucket/key \
     --endpoint-url "http://s3.us-east-1.amazonaws.com"
   ```

3. **How It Works**:
   - DNS resolves `s3.us-east-1.amazonaws.com` → `127.0.0.1` (via hosts file)
   - Client connects to `127.0.0.1:80` (the proxy HTTP port)
   - Proxy receives request and forwards to real S3 endpoint via HTTPS
   - Proxy caches the response for subsequent requests

**Alternative: HTTPS with Self-Signed Certificates**

You can also use HTTPS mode with self-signed certificates:

```bash
# Set HTTPS mode to selfsigned in config-perf.yaml
# Then use --no-verify-ssl with AWS CLI
aws s3 cp file.txt s3://bucket/key \
  --no-verify-ssl
```

This allows the proxy to intercept HTTPS traffic on port 443, but requires disabling SSL verification.

**Hosts File Management:**
The script automatically manages your hosts file during proxy tests:
- Backs up `/etc/hosts` before modifications
- Adds S3 routing entries for proxy testing
- Restores original hosts file after tests complete
- Cleans up on script exit (even if interrupted)

**Note**: You'll be prompted for sudo password when the script modifies `/etc/hosts`.

## Usage

### Build Validation (Recommended)

```bash
# Run all tests plus short performance validation
chmod +x tests/performance/build_and_validate.sh
./tests/performance/build_and_validate.sh
```

This script:
1. Builds the project
2. Runs unit tests
3. Runs integration tests
4. Starts proxy and runs short performance test (0.1MB and 50MB files, 3 iterations)
5. Validates cache hits are at least 2x faster than cache misses
6. Cleans up all test resources

### Quick Start (Complete Test Suite)

```bash
# Run complete test suite
chmod +x tests/performance/s3_performance_test.sh
./tests/performance/s3_performance_test.sh all
```

You'll be prompted for:
- S3 bucket name (default: auto-generated unique name)
- AWS region (default: us-east-1)
- Proxy hostname (default: start local proxy automatically)
- Proxy port (default: 8081)

**Note:** If you press Enter at the proxy hostname prompt, the script will automatically start a local proxy for you.

The script will:
1. Create test bucket and generate test files
2. Upload files to S3
3. Run all tests in direct mode
4. Automatically configure hosts file
5. Run all tests in proxy mode
6. Restore hosts file
7. Generate summary report

### Step-by-Step Testing

#### 1. Setup (One-time)

```bash
./tests/performance/s3_performance_test.sh setup
```

Creates bucket, generates test files, and uploads to S3.

#### 2. Direct Mode Tests (No Proxy)

```bash
# Ensure hosts file does NOT redirect S3 traffic
./tests/performance/s3_performance_test.sh direct
```

#### 3. Proxy Mode Tests

```bash
# Run proxy tests (will prompt for proxy configuration)
./tests/performance/s3_performance_test.sh proxy
```

#### 4. Short Mode (Quick Validation)

```bash
# Run quick test with 0.1MB and 50MB files, 3 iterations
SHORT_MODE=1 ./tests/performance/s3_performance_test.sh proxy
```

The script will:
- Prompt for bucket name and region
- Prompt for proxy hostname (or start local proxy)
- Resolve proxy DNS name to IP address
- Check if proxy is accessible
- Backup your hosts file
- Add S3 routing entries using resolved IP
- Run all tests
- Restore original hosts file
- Stop local proxy if started

#### 5. Cleanup

```bash
./tests/performance/s3_performance_test.sh cleanup
```

Removes:
- All objects from S3 bucket
- S3 bucket (with confirmation)
- Local test files
- Test results

## Configuration

Set environment variables to customize testing:

```bash
export BUCKET_NAME="my-perf-test-bucket-12345"
export AWS_REGION="us-west-2"
export PROXY_HOST="proxy.example.com"  # DNS name for remote proxy
export PROXY_PORT="80"
export SHORT_MODE=1  # Quick test mode

./tests/performance/s3_performance_test.sh all
```

### Available Variables

- `BUCKET_NAME`: S3 bucket name (default: auto-generated with timestamp for uniqueness)
- `AWS_REGION`: AWS region (default: prompted, or `us-east-1`)
- `PROXY_HOST`: Proxy DNS hostname (default: prompted, or start local proxy)
- `PROXY_PORT`: Proxy port (default: `80`)
- `SHORT_MODE`: Run quick test with 0.1MB and 50MB files, 3 iterations (default: `0`)

### Proxy Configuration

**Local Proxy (Automatic):**
- Leave `PROXY_HOST` unset or press Enter when prompted
- Script will automatically start local proxy using `config-perf.yaml`
- Proxy will be stopped automatically when tests complete

**Remote Proxy:**
- Set `PROXY_HOST` to DNS name (e.g., `proxy.example.com`)
- Use DNS name, not IP address (supports multiple IPs for scale-out)
- Script will resolve DNS to IP for hosts file configuration
- Supports load-balanced proxy deployments

**Note**: If not set, you'll be prompted for all configuration when running tests.

## Results

### Output Files

Results are saved to `./perf_test_results/` with timestamp:

- `head_direct_TIMESTAMP.csv` - HeadObject direct mode
- `head_proxy_TIMESTAMP.csv` - HeadObject proxy mode
- `get_awscli_direct_TIMESTAMP.csv` - AWS CLI GET direct mode
- `get_awscli_proxy_TIMESTAMP.csv` - AWS CLI GET proxy mode
- `multipart_direct_TIMESTAMP.csv` - Multipart upload direct mode
- `multipart_proxy_TIMESTAMP.csv` - Multipart upload proxy mode
- `get_after_put_direct_TIMESTAMP.csv` - Get-after-Put direct mode
- `get_after_put_proxy_TIMESTAMP.csv` - Get-after-Put proxy mode
- `summary_TIMESTAMP.txt` - Test summary

### CSV Format

Each CSV contains:
- `file_size_mb`: Size of test file
- `iteration`: Test iteration number
- `duration_ms`: Operation duration in milliseconds
- `throughput_mbps`: Throughput in Mbps (for GET/PUT operations)

### Analysis

Run the analysis script to generate detailed comparison:

```bash
chmod +x tests/performance/s3_performance_test.sh
./tests/performance/s3_performance_test.sh all
```

The analysis includes:
- Mean, median, and percentile latencies
- Direct vs. proxy performance comparison
- Throughput analysis
- Cache effectiveness metrics
- Statistical significance

## Test Scenarios

### 1. HeadObject Operations

Tests metadata retrieval performance. Proxy should serve from cache after first request.

### 2. GET Operations (AWS CLI with CRT)

Uses AWS CLI with S3 Common Runtime (CRT) for high-performance downloads. Tests:
- Cold cache (iteration 1 - cache miss)
- Warm cache (iterations 2-5 - cache hits)
- Different file sizes

**Analysis Note**: Iteration 1 is compared separately from iterations 2-5 to measure cache effectiveness.

### 3. Multipart Uploads

Tests large file uploads (≥5MB) using multipart upload protocol. Validates:
- Proxy handling of multipart operations
- Upload performance
- Data integrity

### 4. Get-after-Put

Tests cache population during PUT operations:
1. Upload a file through proxy
2. Immediately download the same file
3. Measure if cache was populated during upload

This validates read-after-write consistency and cache effectiveness.

## Interpreting Results

### Cache Hit Performance

The analysis separates cache misses from cache hits:
- **Iteration 1 (cache miss)**: First request, data fetched from S3
- **Iterations 2-5 (cache hits)**: Subsequent requests, data served from cache

Expected results:
- **Cache miss**: Similar to direct mode (slight overhead acceptable)
- **Cache hits**: Significantly faster than direct mode

Look for:
- Negative percentages = proxy is faster (good for cache hits)
- Positive percentages = proxy is slower (expected for cache misses)

### Throughput

Higher throughput_mbps indicates better performance:
- Direct mode: Baseline S3 performance
- Proxy mode: Should match or exceed for cache hits

### Get-after-Put

Lower GET duration in proxy mode indicates:
- Successful cache population during PUT
- Effective read-after-write optimization

## Troubleshooting

### "Bucket already exists" error

The bucket might exist from a previous run. Either:
- Use a different bucket name
- Run cleanup first: `./scripts/perf_test.sh cleanup`

### Proxy tests failing

1. Verify proxy is running: `curl http://localhost:8080/health`
2. Check hosts file was modified: `grep "S3 Proxy" /etc/hosts`
3. Verify proxy port matches `PROXY_PORT` variable
4. If hosts file wasn't restored, run: `./scripts/perf_test.sh cleanup`

### Permission denied

Make scripts executable:
```bash
chmod +x scripts/perf_test.sh
chmod +x scripts/analyze_perf_results.py
```

## Advanced Usage

### Custom File Sizes

Edit `FILE_SIZES` array in `s3_performance_test.sh`:
```bash
FILE_SIZES=(5 25 75 200 1000)
```

### More Iterations

Increase `ITERATIONS` for more statistical confidence:
```bash
ITERATIONS=10 ./tests/performance/s3_performance_test.sh proxy
```

### Specific Tests Only

Comment out unwanted tests in the `main()` function of `s3_performance_test.sh`.

## Performance Tips

1. **Run on same network**: Test from EC2 instance in same region as S3 bucket
2. **Warm up cache**: Run tests twice, analyze second run
3. **Consistent environment**: Close other applications during testing
4. **Multiple iterations**: Use at least 5 iterations for statistical validity

## Example Output

```
[2025-11-20 10:30:15] Testing GET operations with AWS CLI (proxy)...
  1MB iteration 1: 45ms (178.67 Mbps)
  1MB iteration 2: 12ms (666.67 Mbps)  <- Cache hit!
  1MB iteration 3: 11ms (727.27 Mbps)
  10MB iteration 1: 234ms (341.88 Mbps)
  10MB iteration 2: 89ms (898.88 Mbps) <- Cache hit!
```

## License

Same as parent project.
