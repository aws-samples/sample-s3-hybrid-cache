#!/bin/bash
set -e

# Build and Test Script with Performance Validation
# Runs all tests including a short performance test to validate cache performance

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Step 1: Build
log "Building project..."
cargo build --release
if [ $? -ne 0 ]; then
    error "Build failed"
    exit 1
fi
log "Build successful"

# Step 2: Run unit tests
log "Running unit tests..."
cargo test --release
if [ $? -ne 0 ]; then
    error "Unit tests failed"
    exit 1
fi
log "Unit tests passed"

# Step 3: Run integration tests
log "Running integration tests..."
cargo test --release --test '*'
if [ $? -ne 0 ]; then
    error "Integration tests failed"
    exit 1
fi
log "Integration tests passed"

# Step 4: Run short performance test
log "Running short performance test to validate cache performance..."

# Check if proxy is already running
PROXY_PID=""
if lsof -ti:80 > /dev/null 2>&1; then
    warn "Proxy already running on port 80, using existing instance"
else
    log "Starting proxy for performance test..."
    cargo run --release -- -c tests/performance/config-perf.yaml > /tmp/proxy-test.log 2>&1 &
    PROXY_PID=$!
    
    # Wait for proxy to be ready
    sleep 3
    if ! curl -s -H "Host: s3.us-east-1.amazonaws.com" "http://localhost:80/" > /dev/null 2>&1; then
        error "Proxy failed to start"
        kill $PROXY_PID 2>/dev/null || true
        exit 1
    fi
    log "Proxy started (PID: $PROXY_PID)"
fi

# Create a unique bucket for this test
BUCKET_NAME="s3-proxy-test-$(date +%s)"
AWS_REGION="us-east-1"

# Create bucket and upload test files
log "Setting up test bucket: $BUCKET_NAME"
aws s3 mb "s3://$BUCKET_NAME" --region "$AWS_REGION" 2>/dev/null || true

# Generate and upload test files
mkdir -p /tmp/perf_test_data
dd if=/dev/urandom of=/tmp/perf_test_data/test_0.1mb.bin bs=1k count=100 2>/dev/null
dd if=/dev/urandom of=/tmp/perf_test_data/test_50mb.bin bs=1m count=50 2>/dev/null

aws s3 cp /tmp/perf_test_data/test_0.1mb.bin "s3://$BUCKET_NAME/test_0.1mb.bin" --region "$AWS_REGION" > /dev/null
aws s3 cp /tmp/perf_test_data/test_50mb.bin "s3://$BUCKET_NAME/test_50mb.bin" --region "$AWS_REGION" > /dev/null

log "Test files uploaded"

# Clear cache
rm -rf /tmp/s3-proxy-cache/*
log "Cache cleared"

# Run short performance test
log "Running performance test with cache validation..."

# Start watching logs in background
tail -f /tmp/s3-proxy-logs/app/*/s3-proxy.log.$(date +%Y-%m-%d) 2>/dev/null | grep -E "(cache hit|cache miss|GET|HEAD)" > /tmp/perf_test_cache_log.txt &
LOG_TAIL_PID=$!

# Run the test
sudo SHORT_MODE=1 BUCKET_NAME="$BUCKET_NAME" AWS_REGION="$AWS_REGION" PROXY_HOST=localhost bash tests/performance/s3_performance_test.sh proxy > /tmp/perf_test_results.txt 2>&1
TEST_EXIT_CODE=$?

# Stop log watching
kill $LOG_TAIL_PID 2>/dev/null || true

# Analyze results
if [ $TEST_EXIT_CODE -ne 0 ]; then
    error "Performance test failed to complete"
    cat /tmp/perf_test_results.txt
    
    # Cleanup
    if [ -n "$PROXY_PID" ]; then
        kill $PROXY_PID 2>/dev/null || true
    fi
    aws s3 rb "s3://$BUCKET_NAME" --force --region "$AWS_REGION" 2>/dev/null || true
    exit 1
fi

# Validate cache performance
log "Validating cache performance..."

# Extract timings from results
CACHE_MISS_TIMES=$(grep "CACHE MISS" /tmp/perf_test_results.txt | grep -oE "[0-9]+ms" | sed 's/ms//' || echo "")
CACHE_HIT_TIMES=$(grep "CACHE HIT" /tmp/perf_test_results.txt | grep -oE "[0-9]+ms" | sed 's/ms//' || echo "")

if [ -z "$CACHE_MISS_TIMES" ] || [ -z "$CACHE_HIT_TIMES" ]; then
    error "Could not extract cache timing data"
    cat /tmp/perf_test_results.txt
    
    # Cleanup
    if [ -n "$PROXY_PID" ]; then
        kill $PROXY_PID 2>/dev/null || true
    fi
    aws s3 rb "s3://$BUCKET_NAME" --force --region "$AWS_REGION" 2>/dev/null || true
    exit 1
fi

# Calculate averages
AVG_MISS=$(echo "$CACHE_MISS_TIMES" | awk '{sum+=$1; count++} END {if(count>0) print sum/count; else print 0}')
AVG_HIT=$(echo "$CACHE_HIT_TIMES" | awk '{sum+=$1; count++} END {if(count>0) print sum/count; else print 0}')

log "Average cache miss time: ${AVG_MISS}ms"
log "Average cache hit time: ${AVG_HIT}ms"

# Validate that cache hits are significantly faster (at least 2x faster)
SPEEDUP=$(echo "$AVG_MISS $AVG_HIT" | awk '{if($2>0) print $1/$2; else print 0}')
log "Cache speedup: ${SPEEDUP}x"

if (( $(echo "$SPEEDUP < 2.0" | bc -l) )); then
    error "Cache hits are not significantly faster than misses (speedup: ${SPEEDUP}x, expected: >2x)"
    error "This indicates the cache is not working properly"
    cat /tmp/perf_test_results.txt
    
    # Show cache logs
    log "Cache activity from logs:"
    cat /tmp/perf_test_cache_log.txt | tail -50
    
    # Cleanup
    if [ -n "$PROXY_PID" ]; then
        kill $PROXY_PID 2>/dev/null || true
    fi
    aws s3 rb "s3://$BUCKET_NAME" --force --region "$AWS_REGION" 2>/dev/null || true
    exit 1
fi

log "Cache performance validation passed (${SPEEDUP}x speedup)"

# Cleanup
log "Cleaning up test resources..."
if [ -n "$PROXY_PID" ]; then
    kill $PROXY_PID 2>/dev/null || true
    log "Proxy stopped"
fi

aws s3 rb "s3://$BUCKET_NAME" --force --region "$AWS_REGION" 2>/dev/null || true
rm -rf /tmp/perf_test_data
log "Test bucket deleted"

log "All tests passed successfully!"
