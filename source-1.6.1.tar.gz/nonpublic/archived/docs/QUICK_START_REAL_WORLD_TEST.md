# Quick Start: Real-World Cache Test

## TL;DR

```bash
# Option 1: Rust integration test (automated)
sudo -E cargo test --test real_world_cache_test test_real_world_cache_with_100mb_file -- --nocapture --ignored

# Option 2: Manual shell script (easier debugging)
sudo -E ./tests/manual_cache_test.sh
```

## Prerequisites Checklist

- [ ] Running on macOS or Linux
- [ ] Have sudo access: `sudo -v`
- [ ] AWS CLI installed: `aws --version`
- [ ] AWS credentials configured: `aws sts get-caller-identity`
- [ ] Can access test bucket: `aws s3 ls s3://egummett-testing-source-1/bigfiles/`
- [ ] Port 80 is available: `sudo lsof -i :80` (should return nothing)
- [ ] Proxy builds: `cargo build --release`

## What It Tests

1. **First Download**: Downloads 100MB file from S3 → Cache miss, stores in cache
2. **Second Download**: Downloads same file → 100% cache hit, no S3 requests
3. **Verification**: Confirms no range merge errors, files identical

## Expected Output

### First Download
```
=== FIRST DOWNLOAD - Expected: Cache Miss, S3 Fetch ===
✓ Download completed successfully
✓ File size: 104857600 bytes (100.00 MB)

Cache Hits: 0
Cache Misses: 150
S3 Requests: 150
Cache Hit Rate: 0%
```

### Second Download
```
=== SECOND DOWNLOAD - Expected: 100% Cache Hit, No S3 ===
✓ Download completed successfully
✓ File size: 104857600 bytes (100.00 MB)

Cache Hits: 150
Cache Misses: 0
S3 Requests: 0
Cache Hit Rate: 100%
Range Merge Errors: 0
```

### Final Result
```
✓ Second download verified: 100% cache hit, no S3 requests
✓ No range merge errors detected
✓ Both downloads produced identical file sizes

╔════════════════════════════════════════════════════════════╗
║  TEST PASSED - Cache working correctly with 100MB file    ║
╚════════════════════════════════════════════════════════════╝
```

## Troubleshooting

### "This test requires sudo"
```bash
# Add sudo and -E flag
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "AWS credentials not configured"
```bash
# Configure AWS
aws configure

# Or set environment variables
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_DEFAULT_REGION=eu-west-1

# Then run with -E to preserve environment
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "Port 80 already in use"
```bash
# Find what's using port 80
sudo lsof -i :80

# Kill it
sudo kill -9 <PID>

# Try again
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "Access Denied to S3 bucket"
You can modify the test to use your own bucket:

1. Edit `tests/real_world_cache_test.rs`
2. Change these constants:
   ```rust
   const TEST_BUCKET: &str = "your-bucket-name";
   const TEST_OBJECT: &str = "path/to/your/100MB/file";
   ```
3. Make sure the object is ~100MB for accurate testing

### Test hangs or times out
```bash
# Kill any stuck proxy processes
sudo pkill -9 s3-proxy

# Check if port 80 is free
sudo lsof -i :80

# Try again
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

## Using Your Own Test File

If you don't have access to the default test bucket, create your own:

```bash
# Create a 100MB test file
dd if=/dev/urandom of=100MB bs=1m count=100

# Upload to your S3 bucket
aws s3 cp 100MB s3://your-bucket/test-files/100MB

# Edit tests/real_world_cache_test.rs
# Change TEST_BUCKET and TEST_OBJECT constants

# Run test
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

## Manual Testing (Easier Debugging)

The shell script is easier to debug and provides better output:

```bash
# Run manual test
sudo -E ./tests/manual_cache_test.sh

# The script will:
# 1. Check all prerequisites
# 2. Build the proxy
# 3. Start the proxy
# 4. Download file twice
# 5. Analyze logs
# 6. Compare files
# 7. Stop proxy and cleanup

# Logs are saved in ./tmp/manual_test_cache/
```

## What Success Looks Like

✅ **First download completes** (5-30 seconds)  
✅ **Second download completes** (1-5 seconds, much faster!)  
✅ **Cache hit rate = 100%** on second download  
✅ **S3 requests = 0** on second download  
✅ **Range merge errors = 0**  
✅ **Files are identical**  

## What Failure Looks Like

❌ **Cache hit rate < 99%** → Cache lookup bug  
❌ **S3 requests > 0** on second download → Cache not being used  
❌ **Range merge errors > 0** → Range merging issues  
❌ **Files differ** → Data corruption  

## Next Steps After Running

### If Test Passes
Great! Your cache is working correctly. The test validates:
- Cache key sanitization
- Sharded path construction
- Metadata storage and retrieval
- Range overlap detection
- Cache hit serving

### If Test Fails
1. Check the logs in the temp directory (path printed during test)
2. Look for `[CACHE_LOOKUP]`, `[METADATA_LOOKUP]`, `[RANGE_OVERLAP]` entries
3. Review the diagnostic analysis from Task 7
4. Run the manual script for easier debugging: `sudo -E ./tests/manual_cache_test.sh`

## More Information

- **Full Documentation**: `tests/REAL_WORLD_CACHE_TEST_README.md`
- **Implementation Details**: `REAL_WORLD_CACHE_TEST_IMPLEMENTATION.md`
- **Task 7 Analysis**: `CACHE_LOOKUP_DIAGNOSTIC_ANALYSIS.md`
- **Spec Documents**: `.kiro/specs/cache-lookup-debug/`

## Questions?

Common questions:

**Q: Why do I need sudo?**  
A: The proxy binds to port 80, which requires root privileges.

**Q: Can I use a different port?**  
A: Yes, but you'll need to modify the test configuration and AWS CLI endpoint.

**Q: How long does it take?**  
A: First run: ~30-60 seconds. Subsequent runs: ~30-60 seconds (downloads twice).

**Q: Can I run this in CI?**  
A: Yes, but you'll need AWS credentials and sudo access in your CI environment.

**Q: What if I don't have access to the test bucket?**  
A: Use your own bucket and modify the TEST_BUCKET and TEST_OBJECT constants.

**Q: Why is the test marked with `#[ignore]`?**  
A: It requires external resources (AWS, sudo) and is slower, so it's opt-in.
