# Full Object Cache Replacement of Partial Ranges Implementation

## Overview

Implemented Requirement 2.9: When the Proxy caches a full object GET response and partial ranges already exist, the Proxy SHALL replace the existing cached ranges with the new full object data.

## Changes Made

### 1. Modified `store_full_object_as_range_new()` in `src/cache.rs`

**Location**: Lines 4970-5090

**Changes**:
- Added logic to detect existing partial ranges before storing a full object
- Reads existing metadata file if it exists
- Checks if existing ranges are partial (not covering the full object) using new helper method
- Removes all partial range files before storing the full object
- Logs range replacement operations for observability

**Key Logic**:
```rust
// Check for existing partial ranges and remove them before storing full object
let metadata_file_path = self.get_new_metadata_file_path(cache_key);
if metadata_file_path.exists() {
    // Read existing metadata
    match std::fs::read_to_string(&metadata_file_path) {
        Ok(content) => {
            match serde_json::from_str::<NewCacheMetadata>(&content) {
                Ok(existing_metadata) => {
                    // Check if existing ranges are partial
                    let has_partial_ranges = !existing_metadata.ranges.is_empty() && 
                        !Self::is_full_object_cached(&existing_metadata.ranges, content_length);
                    
                    if has_partial_ranges {
                        // Remove all existing range files
                        for range_spec in &existing_metadata.ranges {
                            let range_file_path = self.cache_dir.join("ranges").join(&range_spec.file_path);
                            if range_file_path.exists() {
                                std::fs::remove_file(&range_file_path)?;
                            }
                        }
                    }
                }
            }
        }
    }
}
```

### 2. Added Helper Method `is_full_object_cached()` in `src/cache.rs`

**Location**: After `extract_file_extension()` method

**Purpose**: Determines if a set of ranges represents a full object (single range from 0 to content_length-1)

**Implementation**:
```rust
/// Check if the given ranges represent a full object (single range from 0 to content_length-1)
/// Requirement 2.9: Helper to detect partial vs full object caching
fn is_full_object_cached(ranges: &[crate::cache_types::RangeSpec], content_length: u64) -> bool {
    if ranges.len() != 1 {
        return false;
    }
    
    let range = &ranges[0];
    range.start == 0 && range.end == content_length - 1
}
```

## Behavior

### Scenario 1: Partial Ranges Exist
1. Client performs range GET requests (e.g., bytes 0-24, 50-74)
2. Proxy caches these as partial ranges
3. Client performs full object GET or PUT
4. Proxy detects existing partial ranges
5. Proxy removes all partial range files
6. Proxy stores full object as single range (0 to content_length-1)
7. Logs: "Replaced N partial ranges with full object for key: X"

### Scenario 2: Full Object Already Exists
1. Full object already cached (range 0 to content_length-1)
2. Client performs another full object GET or PUT
3. Proxy detects existing range is already full object
4. Proxy overwrites the full object (no removal needed)
5. Logs: "Existing ranges already represent full object for key: X, will overwrite"

### Scenario 3: No Existing Ranges
1. No cached ranges exist
2. Client performs full object GET or PUT
3. Proxy stores full object as single range
4. No removal operations needed

## Logging

The implementation adds comprehensive logging:

- **Info Level**: 
  - "Detected N partial ranges for key: X, removing before storing full object"
  - "Replaced N partial ranges with full object for key: X"
  
- **Debug Level**:
  - "Checking for existing partial ranges for key: X"
  - "Removed partial range file: key=X, range=start-end, path=..."
  - "Partial range file not found (already deleted?): key=X, range=start-end"
  - "Existing ranges already represent full object for key: X, will overwrite"

- **Warn Level**:
  - "Failed to remove partial range file: key=X, range=start-end, error=..."
  - "Failed to parse existing metadata for key: X, error=..."

## Error Handling

- **Metadata Read Failure**: Logs warning, treats as new entry
- **Metadata Parse Failure**: Logs warning, overwrites with new metadata
- **Range File Removal Failure**: Logs warning, continues with storage (metadata will be overwritten)
- **Missing Range Files**: Logs debug message, continues (files may have been cleaned up already)

## Testing

All existing tests pass:
- `test_put_then_full_get_uses_cache` - Verifies PUT then GET flow
- `test_put_then_full_get_large_object` - Verifies large object handling
- `test_has_cached_ranges_optimization` - Verifies range detection
- `test_head_cache_stores_content_length_in_metadata` - Verifies metadata storage
- `test_get_response_stores_content_length_in_metadata` - Verifies GET metadata
- `test_has_cached_ranges_no_metadata` - Verifies missing metadata handling

## Requirements Satisfied

✅ **Requirement 2.9**: WHEN the Proxy caches a full object GET response and partial ranges already exist THEN the Proxy SHALL replace the existing cached ranges with the new full object data

## Files Modified

1. `src/cache.rs`:
   - Modified `store_full_object_as_range_new()` to detect and remove partial ranges
   - Added `is_full_object_cached()` helper method
   - Updated requirement references to include 2.9

## Performance Considerations

- **Minimal Overhead**: Only checks for existing metadata when storing full objects
- **Fast Detection**: Uses simple file existence check and JSON parsing
- **Efficient Cleanup**: Removes only partial range files, not full objects
- **No S3 Requests**: All operations are local filesystem operations

## Backward Compatibility

- Existing cache entries work without modification
- Old format cache entries (without ranges) are unaffected
- Gracefully handles missing or corrupted metadata files
- No migration required for existing cache data
