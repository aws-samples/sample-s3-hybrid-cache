# Daily Validation Scheduling Implementation

## Summary

Updated the cache size tracking validation scheduler to run once per day globally (across all instances) at a configured time with fixed 1-hour jitter, instead of running once per instance with configurable jitter.

## Changes Made

### 1. Design Document Updates (`.kiro/specs/cache-size-tracking/design.md`)

**Configuration Changes:**
- Removed `validation_interval: Duration` field
- Removed `validation_jitter_max: Duration` field  
- Added `validation_time_of_day: String` field (format: "HH:MM", default: "00:00")
- Jitter is now fixed at 1 hour (not configurable)

**Property 5 Update:**
- Changed from "Jitter Distribution" to "Daily Validation Scheduling"
- Now validates: "For any 24-hour period, exactly one validation scan should occur globally across all instances, scheduled at a configured time (default: midnight local time) with jitter applied"

**Implementation Details:**
- Added `calculate_next_validation_time()` method that:
  - Parses configured time of day (e.g., "00:00" for midnight)
  - Calculates next occurrence using local time
  - Checks if validation already ran in last 24 hours
  - Adds fixed 1-hour jitter (0-3600 seconds)
- Added `parse_time_of_day()` helper method
- Updated validation scheduler to loop daily instead of using intervals

**Configuration Example:**
```yaml
cache:
  size_tracking:
    checkpoint_interval: "300s"
    validation_time_of_day: "00:00"  # Midnight local time
    drift_threshold: 1073741824
    validation_enabled: true
```

### 2. Requirements Document Updates (`.kiro/specs/cache-size-tracking/requirements.md`)

**Requirement 4 (Validation Scan Scheduling):**
- Updated acceptance criteria 4: Changed from "add random jitter between 0 and the configured maximum" to "add random jitter between 0 and 1 hour"
- Updated acceptance criteria 3: Now uses "configured time of day (default: midnight local time)"

**Requirement 8 (Configuration):**
- Removed acceptance criteria for `validation_jitter_max`
- Updated acceptance criteria 2: Now accepts `validation_time_of_day` in "HH:MM" format (default: "00:00")
- Reduced from 5 to 4 acceptance criteria

### 3. Implementation Updates (`src/cache_size_tracker.rs`)

**CacheSizeConfig struct:**
```rust
pub struct CacheSizeConfig {
    pub checkpoint_interval: Duration,
    pub validation_time_of_day: String,  // NEW: "HH:MM" format
    pub drift_threshold: u64,
    pub validation_enabled: bool,
    // REMOVED: validation_interval
    // REMOVED: validation_jitter_max
}
```

**New Methods:**
- `calculate_next_validation_time()` - Calculates next validation time based on configured time of day with fixed 1-hour jitter
- `parse_time_of_day()` - Parses "HH:MM" format time string

**Updated Methods:**
- `validation_scheduler()` - Now loops daily instead of using intervals, calls `calculate_next_validation_time()` each iteration

**Dependencies:**
- Uses existing `chrono` crate for local time handling
- Uses `rand` crate for jitter generation

## Behavior Changes

### Before:
- Each instance scheduled validation independently based on `validation_interval` (default: 24 hours)
- Jitter was configurable via `validation_jitter_max` (default: 1 hour)
- Multiple instances could validate at different times within the 24-hour period

### After:
- Validation scheduled once per day globally at a specific time (default: midnight local time)
- Fixed 1-hour jitter prevents thundering herd
- Checks if validation already ran in last 24 hours to prevent duplicate runs
- More predictable scheduling (e.g., always around midnight)

## Testing

All existing unit tests pass:
- `test_size_update_increment`
- `test_size_update_decrement`
- `test_checkpoint_write_and_read`
- `test_delta_log_append_and_replay`
- `test_recovery_from_checkpoint_and_delta_log`
- `test_checkpoint_truncates_delta_log`
- `test_validation_metadata_persistence`
- `test_metrics_collection`
- `test_actively_remove_cached_data_flag`
- `test_recovery_with_no_checkpoint`
- `test_size_never_goes_negative`
- `test_checkpoint_count_increments`

## Configuration Migration

Users need to update their configuration files:

**Old Configuration:**
```yaml
cache:
  size_tracking:
    validation_interval: "86400s"
    validation_jitter_max: "3600s"
```

**New Configuration:**
```yaml
cache:
  size_tracking:
    validation_time_of_day: "00:00"  # Midnight local time
```

## Benefits

1. **Predictable Scheduling**: Validation always runs at the same time of day (e.g., midnight)
2. **Global Coordination**: Only one validation per 24-hour period across all instances
3. **Simpler Configuration**: One time-of-day setting instead of interval + jitter
4. **Better Resource Planning**: Administrators know when validation will occur
5. **Reduced Complexity**: Fixed jitter eliminates configuration decision

## Files Modified

1. `.kiro/specs/cache-size-tracking/design.md`
2. `.kiro/specs/cache-size-tracking/requirements.md`
3. `src/cache_size_tracker.rs`
4. `DAILY_VALIDATION_SCHEDULING_IMPLEMENTATION.md` (this file)
