# Cache Key Validation and Normalization Implementation

## Summary

Implemented cache key validation and normalization functionality to ensure consistent cache key handling across storage and lookup operations. This helps identify and prevent cache misses caused by cache key format inconsistencies.

## Changes Made

### 1. Cache Key Normalization Function

Added `normalize_cache_key()` function to ensure consistent cache key format:

```rust
pub fn normalize_cache_key(cache_key: &str) -> String
```

**Features:**
- Removes leading slashes from cache keys
- Ensures consistent format regardless of input
- Handles both "/bucket/path" and "bucket/path" formats

**Requirements:** 5.3, 5.5

### 2. CacheKeyValidator Struct

Added `CacheKeyValidator` struct to track all cache key transformations:

```rust
pub struct CacheKeyValidator {
    pub original_key: String,
    pub normalized_key: String,
    pub sanitized_key: String,
    pub bucket: String,
    pub object_key: String,
    pub metadata_path: PathBuf,
    pub range_path: PathBuf,
}
```

**Methods:**
- `new(cache_key, disk_cache)` - Creates validator and computes all transformations
- `log_diagnostics()` - Logs all key transformations for debugging
- `was_normalized()` - Checks if normalization changed the key
- `was_sanitized()` - Checks if sanitization changed the key

**Requirements:** 2.1, 2.2, 2.3, 2.4, 2.5, 5.3, 5.4, 5.5

### 3. Enhanced Sanitization Logging

Updated `sanitize_cache_key_new()` to add diagnostic logging:

**Logs when:**
- Sanitization changes the key (percent-encoding applied)
- Keys exceed 200 characters and are hashed

**Log format:**
```
[CACHE_KEY_VALIDATION] Cache key sanitized: original=bucket/path/to/file, sanitized=bucket%2Fpath%2Fto%2Ffile
[CACHE_KEY_VALIDATION] Cache key hashed (exceeds 200 chars): original_length=250, sanitized_length=300, hashed=long_key_abc123...
```

**Requirements:** 2.4, 2.5

### 4. Cache Key Format Validation

Added `validate_cache_key_format()` method to DiskCacheManager:

```rust
pub fn validate_cache_key_format(&self, cache_key: &str) -> Result<()>
```

**Features:**
- Normalizes the cache key
- Warns if normalization changes the key
- Parses bucket and object key
- Sanitizes the key
- Logs all transformations for debugging

**Log format:**
```
[CACHE_KEY_VALIDATION] Cache key format mismatch detected: original=/bucket/path, normalized=bucket/path. This may cause cache misses if storage and lookup use different formats.
[CACHE_KEY_VALIDATION] Cache key validation: original=/bucket/path, normalized=bucket/path, sanitized=bucket%2Fpath, bucket=bucket, object_key=path
```

**Requirements:** 2.5, 5.3, 5.4

## Usage Examples

### Using CacheKeyValidator

```rust
use crate::disk_cache::{CacheKeyValidator, DiskCacheManager};

// Create disk cache manager
let disk_cache = DiskCacheManager::new(cache_dir, true, 1024, false);

// Validate a cache key
let validator = CacheKeyValidator::new("/my-bucket/path/to/file.txt", &disk_cache)?;

// Log all transformations
validator.log_diagnostics();

// Check if key was transformed
if validator.was_normalized() {
    println!("Key was normalized: {} -> {}", validator.original_key, validator.normalized_key);
}

if validator.was_sanitized() {
    println!("Key was sanitized: {} -> {}", validator.normalized_key, validator.sanitized_key);
}
```

### Using normalize_cache_key

```rust
use crate::disk_cache::normalize_cache_key;

// Normalize keys with leading slashes
let key1 = normalize_cache_key("/bucket/path");  // Returns: "bucket/path"
let key2 = normalize_cache_key("bucket/path");   // Returns: "bucket/path"

assert_eq!(key1, key2);  // Both are now consistent
```

### Using validate_cache_key_format

```rust
// Validate cache key format
disk_cache.validate_cache_key_format("/bucket/path/to/file")?;

// This will log warnings if the key format is inconsistent
```

## Requirements Satisfied

- ✅ **Requirement 2.1**: `sanitize_cache_key_new()` is used consistently across all operations
- ✅ **Requirement 2.2**: Same sanitization function used for storage and lookup
- ✅ **Requirement 2.3**: Special characters are percent-encoded consistently
- ✅ **Requirement 2.4**: Long keys (>200 chars) are hashed consistently using BLAKE3
- ✅ **Requirement 2.5**: Both original and sanitized keys are logged for comparison
- ✅ **Requirement 5.3**: Cache key normalization removes leading slashes consistently
- ✅ **Requirement 5.4**: Cache key format mismatches are detected and logged
- ✅ **Requirement 5.5**: S3 paths are normalized consistently

## Diagnostic Logging

All cache key validation operations use the `[CACHE_KEY_VALIDATION]` prefix for easy filtering:

```bash
# Filter cache key validation logs
grep "\[CACHE_KEY_VALIDATION\]" logfile
```

## Example Log Output

```
[CACHE_KEY_VALIDATION] Cache key transformations:
 - original_key: /my-bucket/path/to/file.txt
 - normalized_key: my-bucket/path/to/file.txt
 - sanitized_key: my-bucket%2Fpath%2Fto%2Ffile.txt
 - bucket: my-bucket
 - object_key: path/to/file.txt
 - metadata_path: "/cache/objects/my-bucket/AB/CDE/my-bucket%2Fpath%2Fto%2Ffile.txt.meta"
 - range_path: "/cache/ranges/my-bucket/AB/CDE/my-bucket%2Fpath%2Fto%2Ffile.txt_0-1023.bin"

[CACHE_KEY_VALIDATION] Cache key sanitized: original=my-bucket/path/to/file.txt, sanitized=my-bucket%2Fpath%2Fto%2Ffile.txt

[CACHE_KEY_VALIDATION] Cache key validation: original=/my-bucket/path/to/file.txt, normalized=my-bucket/path/to/file.txt, sanitized=my-bucket%2Fpath%2Fto%2Ffile.txt, bucket=my-bucket, object_key=path/to/file.txt
```

## Integration with Existing Code

The new functionality integrates seamlessly with existing code:

1. **normalize_cache_key()** - Can be called before any cache operation to ensure consistent format
2. **CacheKeyValidator** - Can be used in tests and diagnostics to verify key transformations
3. **validate_cache_key_format()** - Can be called at cache entry points to detect format issues early
4. **Enhanced sanitization logging** - Automatically logs when keys are transformed

## Next Steps

With cache key validation and normalization in place, you can now:

1. Use `CacheKeyValidator` in diagnostic tests to verify key consistency
2. Call `validate_cache_key_format()` at cache operation entry points
3. Use `normalize_cache_key()` to ensure consistent key format before storage/lookup
4. Review logs with `[CACHE_KEY_VALIDATION]` prefix to identify format mismatches
