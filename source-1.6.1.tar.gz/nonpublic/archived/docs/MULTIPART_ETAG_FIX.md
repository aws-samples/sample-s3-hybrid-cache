# Multipart Upload ETag Extraction Fix

## Problem

When multipart uploads were completed via `CompleteMultipartUpload`, the ETag was not being extracted from the XML response body and stored in the cache metadata. This caused subsequent GET requests to fail with a 412 Precondition Failed error, forcing cache invalidation and re-fetching from S3.

## Root Cause

The `extract_etag_from_xml` function in `src/signed_put_handler.rs` was not properly extracting the ETag from the CompleteMultipartUpload XML response. The function existed but had issues with case sensitivity and logging.

## Fix Applied

Updated the `extract_etag_from_xml` function to:
1. Use case-insensitive XML tag matching
2. Add debug logging to show extraction attempts
3. Add info logging on successful extraction
4. Add warning logging with XML content preview on failure

### Code Changes

**File**: `src/signed_put_handler.rs`

```rust
fn extract_etag_from_xml(xml: &str) -> String {
    debug!("Attempting to extract ETag from XML response (length: {} bytes)", xml.len());
    
    // Simple XML parsing to extract ETag value
    // Look for <ETag>value</ETag> pattern (case-insensitive)
    let xml_lower = xml.to_lowercase();
    
    if let Some(start_pos) = xml_lower.find("<etag>") {
        let after_tag = &xml[start_pos + 6..]; // Skip "<ETag>" or "<etag>"
        if let Some(end_pos) = after_tag.to_lowercase().find("</etag>") {
            let etag = after_tag[..end_pos].trim();
            // Remove surrounding quotes if present
            let cleaned_etag = etag.trim_matches('"').to_string();
            info!("Successfully extracted ETag from XML: {}", cleaned_etag);
            return cleaned_etag;
        }
    }
    
    // Fallback: return empty string if ETag not found
    warn!("Failed to extract ETag from CompleteMultipartUpload response XML. XML content: {}", 
          if xml.len() > 500 { &xml[..500] } else { xml });
    String::new()
}
```

## Verification

After the fix, the logs show:
```
2025-11-25T16:47:56.014303+00:00  INFO Successfully extracted ETag from XML: 0c4af570340e15f2be9924e70bc34257-13
```

And the metadata file contains:
```json
{
  "etag": "0c4af570340e15f2be9924e70bc34257-13",
  ...
}
```

## Remaining Issue

There is still a 412 Precondition Failed error occurring on GET requests. This is due to a **range alignment mismatch** between:
- How multipart uploads store parts (with actual byte offsets including headers: 0-8388661, 8388662-16777323, etc.)
- How GET requests fetch ranges (standard 8MB chunks: 0-8388607, 8388608-16777215, etc.)

When the GET request tries to use the cached multipart data, it finds that the ranges don't align, triggers a precondition check with S3, and gets a 412 error because the cached ranges don't match what S3 would return for those specific byte ranges.

### Next Steps

The range alignment issue needs to be addressed separately. Options include:
1. Normalize range storage to use consistent byte boundaries
2. Implement range splitting/merging logic to handle misaligned ranges
3. Store multipart uploads differently to match GET request patterns

## Files Modified

- `src/signed_put_handler.rs` - Updated `extract_etag_from_xml` function

## Testing

Tested with:
```bash
aws s3 cp /tmp/test-100mb.bin s3://egummett-testing-source-1/bigfiles/100MB --endpoint-url http://s3.eu-west-1.amazonaws.com
```

The ETag is now successfully extracted and stored in the cache metadata.
