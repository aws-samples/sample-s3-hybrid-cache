# Async Cache Write Fix for AWS SDK Throughput Failure

## Problem

Downloads of large files (500MB) through the proxy failed with:
```
AWS_ERROR_HTTP_CHANNEL_THROUGHPUT_FAILURE: Http connection channel shut down due to failure to meet throughput minimum
```

## Root Cause

The AWS SDK makes sequential 8MB range requests for large files. The proxy was **synchronously writing each 8MB range to disk cache before sending the response to the client**.

For a 500MB file:
- ~63 sequential 8MB range requests
- Each request: Fetch from S3 → **Wait for disk write** → Send to client
- Disk write includes compression, which adds latency
- AWS SDK sees aggregate throughput as too low and kills connection

### Code Location

In `src/http_proxy.rs`, the `fetch_range_from_s3_as_fallback` function (lines 2306 and 2330):

```rust
// BEFORE (blocking):
if let Err(e) = range_handler.store_range_new_storage(...).await {
    warn!("Failed to cache range data: {}", e);
}

// Build response (only happens AFTER cache write completes)
let mut response_builder = Response::builder()
    .status(StatusCode::PARTIAL_CONTENT);
```

## Solution

Make cache writes **asynchronous** using `tokio::spawn`, so responses are sent immediately without waiting for disk I/O:

```rust
// AFTER (non-blocking):
tokio::spawn(async move {
    if let Err(e) = range_handler_clone.store_range_new_storage(...).await {
        warn!("Failed to cache range data: {}", e);
    }
});

// Build response (happens immediately, cache write runs in background)
let mut response_builder = Response::builder()
    .status(StatusCode::PARTIAL_CONTENT);
```

## Changes Made

Modified `src/http_proxy.rs` in `fetch_range_from_s3_as_fallback`:

1. **Full object caching** (line ~2306): Spawned async task
2. **Range caching** (line ~2330): Spawned async task

Both cache writes now run in background, allowing immediate response to client.

## Impact

### Performance
- **First byte latency**: Significantly reduced (no disk I/O wait)
- **Throughput**: AWS SDK sees continuous data flow, no timeout
- **Memory**: Minimal increase (8MB range cloned for async task)

### Consistency
- Cache writes still complete reliably
- Errors logged but don't block client response
- Matches pattern already used elsewhere in codebase (line 2147)

## Testing

Test with AWS SDK downloading 500MB file:
```bash
aws s3 cp s3://bucket/bigfiles/500MB ./500MB --endpoint-url http://proxy:80
```

Expected:
- ✅ Download completes successfully
- ✅ No throughput timeout errors
- ✅ Cache populated in background
- ✅ Subsequent requests served from cache

## Why This Works

The AWS SDK's throughput monitor measures **time between receiving bytes**. With synchronous cache writes:

```
Request 1: [Fetch 8MB] → [Write to disk 200ms] → [Send to client]
           ↑ SDK sees 200ms gap here ↑
Request 2: [Fetch 8MB] → [Write to disk 200ms] → [Send to client]
           ↑ SDK sees another 200ms gap ↑
...after many requests, aggregate throughput too low → TIMEOUT
```

With async cache writes:

```
Request 1: [Fetch 8MB] → [Send to client immediately]
                      ↳ [Write to disk in background]
Request 2: [Fetch 8MB] → [Send to client immediately]
                      ↳ [Write to disk in background]
...SDK sees continuous data flow → SUCCESS
```

## Related Code

This fix aligns with existing async cache pattern at line 2147:
```rust
tokio::spawn(async move {
    if let Err(e) = range_handler_clone.store_range_new_storage(...).await {
        warn!("Failed to cache fetched range {}-{}: {}", start, end, e);
    }
});
```

The fallback path now uses the same pattern for consistency.
