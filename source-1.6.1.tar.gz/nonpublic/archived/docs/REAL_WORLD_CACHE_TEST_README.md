# Real-World Cache Test

## Overview

This integration test validates the S3 proxy cache behavior with real-world scenarios using actual AWS S3 downloads. It tests:

1. **First Download (Cache Miss)**: Downloads a 100MB file from S3, verifying it's fetched from S3 and cached
2. **Second Download (Cache Hit)**: Downloads the same file again, verifying 100% cache hit with no S3 requests
3. **Range Request Handling**: Tests partial downloads and cache utilization

## Prerequisites

### 1. Sudo Access
The test requires sudo to bind to port 80:
```bash
# Test if you have sudo access
sudo -v
```

### 2. AWS CLI
Install and configure AWS CLI:
```bash
# Install AWS CLI (macOS)
brew install awscli

# Install AWS CLI (Linux)
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Configure AWS credentials
aws configure
```

### 3. S3 Access
You need read access to the test bucket:
- **Bucket**: `egummett-testing-source-1`
- **Object**: `bigfiles/100MB`
- **Region**: `eu-west-1`

Verify access:
```bash
aws s3 ls s3://egummett-testing-source-1/bigfiles/ --endpoint-url http://s3.eu-west-1.amazonaws.com
```

### 4. Build Dependencies
Ensure all dependencies are installed:
```bash
cargo build --release
```

## Running the Tests

### Run All Real-World Tests
```bash
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

The `-E` flag preserves environment variables (including AWS credentials).

### Run Specific Test

#### 100MB File Download Test
```bash
sudo -E cargo test --test real_world_cache_test test_real_world_cache_with_100mb_file -- --nocapture --ignored
```

#### Range Request Test
```bash
sudo -E cargo test --test real_world_cache_test test_real_world_cache_with_range_requests -- --nocapture --ignored
```

## What the Test Does

### Test Flow

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Setup                                                    │
│    - Create temporary cache directory                      │
│    - Generate test configuration                           │
│    - Clear any existing cache                              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. Start Proxy                                              │
│    - Build proxy binary (cargo build --release)            │
│    - Start proxy with sudo on port 80                      │
│    - Wait for health check to pass                         │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. First Download (Cache Miss)                              │
│    - Download 100MB file via AWS CLI                       │
│    - Proxy fetches from S3                                 │
│    - Proxy caches the data                                 │
│    - Verify S3 requests were made                          │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. Second Download (Cache Hit)                              │
│    - Download same 100MB file via AWS CLI                  │
│    - Proxy serves from cache                               │
│    - Verify 100% cache hit rate                            │
│    - Verify NO S3 requests made                            │
│    - Verify NO range merge errors                          │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 5. Verification                                             │
│    - Compare file sizes                                    │
│    - Analyze proxy logs                                    │
│    - Verify cache statistics                               │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 6. Cleanup                                                  │
│    - Stop proxy process                                    │
│    - Clean up temporary files                              │
└─────────────────────────────────────────────────────────────┘
```

### Log Analysis

The test analyzes proxy logs for:

- **Cache Hits/Misses**: Counts cache hit and miss events
- **S3 Requests**: Tracks requests made to S3
- **Range Overlaps**: Monitors exact matches, partial overlaps, and no overlaps
- **Range Merges**: Detects range merge operations and errors
- **Cache Hit Rate**: Calculates percentage of requests served from cache

### Expected Results

#### First Download
```
Cache Hits: 0
Cache Misses: ~100+ (depends on chunk size)
S3 Requests: ~100+ (fetching data)
Cache Hit Rate: 0%
```

#### Second Download
```
Cache Hits: ~100+
Cache Misses: 0
S3 Requests: 0 (all from cache)
Cache Hit Rate: 100%
Range Merge Errors: 0
```

## Troubleshooting

### "This test requires sudo"
```bash
# Run with sudo and -E flag to preserve environment
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "AWS CLI failed: Unable to locate credentials"
```bash
# Configure AWS credentials
aws configure

# Or set environment variables
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_DEFAULT_REGION=eu-west-1

# Then run with -E to preserve environment
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "Proxy failed to start within 30 seconds"
```bash
# Check if port 80 is already in use
sudo lsof -i :80

# Kill any process using port 80
sudo kill -9 <PID>

# Try again
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "Access Denied" to S3 bucket
```bash
# Verify you have access to the test bucket
aws s3 ls s3://egummett-testing-source-1/bigfiles/ --endpoint-url http://s3.eu-west-1.amazonaws.com

# If you don't have access, you can modify the test to use your own bucket:
# 1. Edit tests/real_world_cache_test.rs
# 2. Change TEST_BUCKET and TEST_OBJECT constants
# 3. Ensure the object is ~100MB for accurate testing
```

### Port 80 Permission Denied
```bash
# On Linux, you may need to allow binding to privileged ports
sudo setcap 'cap_net_bind_service=+ep' target/release/s3-proxy

# Or run the entire test with sudo (recommended)
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### Test Hangs or Times Out
```bash
# Check proxy logs in the temp directory
# The test prints the cache directory location

# Check if proxy is running
ps aux | grep s3-proxy

# Kill any stuck proxy processes
sudo pkill -9 s3-proxy

# Try again
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

## Test Configuration

The test uses a custom configuration optimized for testing:

```yaml
server:
  http_port: 80
  request_timeout: 300s  # 5 minutes for large downloads

cache:
  cache_dir: <temp_dir>/cache
  max_cache_size: 10GB
  get_ttl: ~10 years  # Cache forever for testing
  head_ttl: 60s
  range_merge_gap_threshold: 256KB

logging:
  log_level: debug  # Full debug logging for analysis
  access_log_enabled: true

health:
  enabled: true
  port: 8080  # Health check endpoint
```

## Interpreting Results

### Success Indicators

✅ **First download completes successfully**
- File downloaded to temp directory
- S3 requests logged in proxy
- Cache files created

✅ **Second download shows 100% cache hit**
- Cache hit rate ≥ 99%
- Zero new S3 requests
- No range merge errors

✅ **Files are identical**
- Same file size for both downloads
- Data integrity maintained

### Failure Indicators

❌ **Cache hit rate < 99% on second download**
- Indicates cache lookup bug
- Check logs for cache key mismatches
- Verify sharded path construction

❌ **Range merge errors detected**
- Indicates range merging issues
- Check logs for merge operation details
- Verify range overlap detection

❌ **S3 requests on second download**
- Indicates cache not being used
- Check cache TTL settings
- Verify cache files exist

## Performance Expectations

### First Download (100MB file)
- **Duration**: 5-30 seconds (depends on network speed)
- **S3 Requests**: ~100-200 (depends on chunk size)
- **Cache Operations**: ~100-200 writes

### Second Download (100MB file)
- **Duration**: 1-5 seconds (from cache)
- **S3 Requests**: 0
- **Cache Operations**: ~100-200 reads

### Cache Hit Rate
- **Expected**: 100% on second download
- **Acceptable**: ≥ 99% (allows for minor HEAD requests)
- **Failure**: < 99% indicates cache issues

## Extending the Test

### Test with Different File Sizes

Edit the test constants:
```rust
const TEST_OBJECT: &str = "bigfiles/1GB";  // Test with 1GB file
```

### Test with Different Buckets

```rust
const TEST_BUCKET: &str = "your-test-bucket";
const TEST_OBJECT: &str = "path/to/your/object";
```

### Add More Download Attempts

```rust
// Add third download
download_with_aws_cli(&config, 3)?;
let third_analysis = analyze_proxy_logs(&config, 3);
assert_eq!(third_analysis.cache_hit_rate(), 100.0);
```

### Test Concurrent Downloads

```rust
use std::thread;

let handles: Vec<_> = (0..10)
    .map(|i| {
        thread::spawn(move || {
            download_with_aws_cli(&config, i)
        })
    })
    .collect();

for handle in handles {
    handle.join().unwrap().unwrap();
}
```

## Related Tests

- `tests/cache_lookup_diagnostic_test.rs` - Unit tests for cache lookup
- `tests/integration_test.rs` - General integration tests
- `tests/range_get_test.rs` - Range request tests

## Support

If you encounter issues:

1. Check the troubleshooting section above
2. Review proxy logs in the temp directory (path printed during test)
3. Verify AWS credentials and S3 access
4. Ensure no other process is using port 80
5. Check that you have sudo access

For cache-related issues, enable debug logging and examine:
- `[CACHE_LOOKUP]` entries
- `[METADATA_LOOKUP]` entries
- `[RANGE_OVERLAP]` entries
- `[RANGE_MERGE]` entries
