# ETag and HEAD Cache Directory Fix

## Date
2025-11-26

## Problem Summary

Two critical bugs were causing 412 Precondition Failed errors on subsequent GET requests:

1. **Empty ETag in cached metadata**: When fetching ranges from S3, the proxy stored them with empty ETags
2. **HEAD cache directory not created**: The HEAD cache write operation failed because the parent directory wasn't created

## Root Cause Analysis

### Issue 1: Empty ETag Storage

**Location**: `src/http_proxy.rs:1522`

When storing fetched ranges, the code created ObjectMetadata with hardcoded empty values:

```rust
let object_metadata = crate::cache_types::ObjectMetadata {
    etag: String::new(), // Will be populated from S3 response
    last_modified: String::new(),
    // ...
};
```

The comment indicated intent to populate from S3 response, but this was never implemented.

**Impact**:
- First download: Fetched from S3, stored with empty ETag
- Second download: AWS CLI sent `If-Match: "0c4af570340e15f2be9924e70bc34257-13"` (real ETag)
- Proxy compared: `"0c4af570340e15f2be9924e70bc34257-13"` != `""` → 412 Precondition Failed

### Issue 2: HEAD Cache Directory Missing

**Location**: `src/cache.rs:1211`

The `store_head_cache_entry` function wrote directly to the HEAD cache file without ensuring the parent directory existed:

```rust
std::fs::write(&temp_head_file, head_json)
    .map_err(|e| ProxyError::CacheError(format!("Failed to write HEAD cache file: {}", e)))?;
```

**Impact**:
- After clearing cache with `rm -rf ./tmp/cache/*`, subdirectories were deleted
- HEAD cache writes failed with "No such file or directory (os error 2)"
- HEAD metadata couldn't be cached, forcing repeated S3 HEAD requests

## Solution

### Fix 1: Extract ETag from S3 Response Headers

Modified `fetch_missing_ranges` to return response headers along with data:

**src/range_handler.rs**:
- Changed return type from `Vec<(RangeSpec, Vec<u8>)>` to `Vec<(RangeSpec, Vec<u8>, HashMap<String, String>)>`
- Captured S3 response headers when fetching ranges
- Updated all callers to handle the new tuple structure

**src/http_proxy.rs**:
- Extract ETag, Last-Modified, and Content-Type from response headers
- Populate ObjectMetadata with actual values from S3

```rust
for (fetched_spec, fetched_data, response_headers) in &fetched_ranges {
    let etag = response_headers.get("etag")
        .or_else(|| response_headers.get("ETag"))
        .cloned()
        .unwrap_or_default();
    
    let last_modified = response_headers.get("last-modified")
        .or_else(|| response_headers.get("Last-Modified"))
        .cloned()
        .unwrap_or_default();
    
    let object_metadata = crate::cache_types::ObjectMetadata {
        etag,
        last_modified,
        // ...
    };
}
```

### Fix 2: Create HEAD Cache Directory Before Writing

**src/cache.rs**:
Added directory creation before atomic write operation:

```rust
// Ensure parent directory exists
if let Some(parent) = head_cache_file_path.parent() {
    std::fs::create_dir_all(parent)
        .map_err(|e| ProxyError::CacheError(format!("Failed to create HEAD cache directory: {}", e)))?;
}

let temp_head_file = head_cache_file_path.with_extension("head.tmp");
std::fs::write(&temp_head_file, head_json)
    .map_err(|e| ProxyError::CacheError(format!("Failed to write HEAD cache file: {}", e)))?;
```

## Files Modified

1. **src/cache.rs**
   - Added directory creation in `store_head_cache_entry`

2. **src/range_handler.rs**
   - Modified `fetch_missing_ranges` return type to include headers
   - Updated `merge_range_segments` to accept new tuple structure
   - Updated `merge_ranges_with_fallback` to accept new tuple structure
   - Updated pattern matching to destructure headers

3. **src/http_proxy.rs**
   - Extract metadata from S3 response headers
   - Populate ObjectMetadata with real ETag, Last-Modified, Content-Type

## Testing

After the fix:
1. Clear cache: `sudo rm -rf ./tmp/cache/*`
2. First download: Fetches from S3, extracts and stores ETag
3. Second download: AWS CLI sends If-Match, proxy validates against cached ETag, serves from cache

## Verification

Check logs for:
- `Creating new metadata entry: key=..., etag=<non-empty>`
- `Successfully stored HEAD cache entry for key: ...`
- No "Failed to cache HEAD response" errors
- No "If-Match validation failed" warnings on subsequent requests

## Related Issues

This fix resolves the 412 Precondition Failed errors that occurred when:
- AWS CLI downloads the same file multiple times
- Client sends conditional headers (If-Match, If-None-Match)
- Cache directories are cleared while proxy is running
