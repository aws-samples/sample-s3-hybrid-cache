# Presigned URL Support

## Overview

The S3 proxy supports AWS SigV4 presigned URLs transparently. Presigned URLs embed authentication credentials in query parameters, allowing time-limited access to S3 objects without requiring AWS credentials.

## How Presigned URLs Work

A presigned URL contains:
- `X-Amz-Algorithm`: Signature algorithm (e.g., AWS4-HMAC-SHA256)
- `X-Amz-Date`: When the URL was signed (ISO 8601: YYYYMMDDTHHMMSSZ)
- `X-Amz-Expires`: Validity duration in seconds
- `X-Amz-Credential`: AWS credential scope
- `X-Amz-SignedHeaders`: Headers included in signature
- `X-Amz-Signature`: The cryptographic signature

Example:
```
GET /bucket/object?X-Amz-Algorithm=AWS4-HMAC-SHA256
                  &X-Amz-Date=20240115T120000Z
                  &X-Amz-Expires=3600
                  &X-Amz-Credential=AKIAIOSFODNN7EXAMPLE/20240115/us-east-1/s3/aws4_request
                  &X-Amz-SignedHeaders=host
                  &X-Amz-Signature=abc123...
```

## Proxy Behavior

### Cache Key Generation

The proxy generates cache keys from the **path only**, excluding query parameters:
- Request: `/bucket/object?X-Amz-Signature=abc123`
- Cache key: `bucket/object`

This means:
- Multiple presigned URLs for the same object share the same cache entry
- Different signatures don't create duplicate cache entries
- Cache hits work regardless of which signature was used originally

### Request Forwarding

The proxy forwards the **complete URI** including all query parameters to S3:
- Signature validation happens at S3, not the proxy
- The proxy is a transparent forwarder
- Headers are forwarded unchanged

### Expiration Behavior

The proxy can check presigned URL expiration **without contacting S3** by parsing query parameters:

```rust
use s3_proxy::presigned_url::parse_presigned_url;

if let Some(info) = parse_presigned_url(&query_params) {
    if info.is_expired() {
        // URL has expired
        return Err("Presigned URL expired");
    }
}
```

## Cache TTL Strategies

### Strategy 1: Long TTL (Default - Performance Focused)

**Configuration:**
```yaml
cache:
  get_ttl: "24h"  # Long TTL
```

**Behavior:**
- Maximum performance (no S3 calls on cache hit)
- Maximum cost savings
- Cached data remains accessible after presigned URL expires
- **Trade-off**: Bypasses time-limited access control

**Use when:**
- Presigned URLs are used for authentication, not access control
- Performance is the primary concern
- Time-limited access is not a security requirement

### Strategy 2: Zero TTL (Security Focused)

**Configuration:**
```yaml
cache:
  get_ttl: "0s"  # Immediate expiration
```

**Behavior:**
- Every request triggers conditional revalidation (If-Modified-Since)
- S3 responds with 304 Not Modified if data unchanged
- Expired presigned URLs fail with 403 Forbidden
- **Benefits**: Respects time-limited access, still provides caching benefits

**Use when:**
- Presigned URLs enforce time-limited access control
- Security is the primary concern
- You want to respect presigned URL expiration

### Strategy 3: Matched TTL (Balanced)

**Configuration:**
Parse presigned URL expiration and set cache TTL dynamically:

```rust
use s3_proxy::presigned_url::parse_presigned_url;

if let Some(info) = parse_presigned_url(&query_params) {
    let cache_ttl = Duration::from_secs(info.expires_in_seconds);
    // Use cache_ttl for this specific request
}
```

**Behavior:**
- Cache TTL matches presigned URL expiration
- Cached data expires when access permission expires
- Balances performance and security

**Use when:**
- You want caching benefits without bypassing access control
- Presigned URLs have consistent expiration times
- You can implement dynamic TTL logic

## Local Expiration Checking

The proxy can determine if a presigned URL has expired without making an S3 request:

```rust
use s3_proxy::presigned_url::parse_presigned_url;
use std::collections::HashMap;

// Parse query parameters from request
let query_params: HashMap<String, String> = /* ... */;

// Check if this is a presigned URL and if it's expired
if let Some(info) = parse_presigned_url(&query_params) {
    if info.is_expired() {
        // Return 403 Forbidden immediately without contacting S3
        return Err("Presigned URL has expired");
    }
    
    // Get time remaining
    if let Some(time_remaining) = info.time_until_expiration() {
        println!("URL expires in {} seconds", time_remaining.as_secs());
    }
}
```

**Benefits:**
- No S3 API call required
- Immediate rejection of expired URLs
- Reduced latency and cost
- Can be used for early validation

**Limitations:**
- Cannot validate the signature itself (requires AWS secret key)
- Only checks expiration, not signature validity
- Clock skew between proxy and client could cause issues

## Implementation Example

See `examples/presigned_url_demo.rs` for a complete example:

```bash
cargo run --release --example presigned_url_demo
```

## Security Considerations

### Time-Limited Access Control

If presigned URLs are used for time-limited access control:
- Use `get_ttl=0` or match cache TTL to presigned URL expiration
- Consider implementing local expiration checking
- Monitor for clock skew between proxy and S3

### Signature Validation

The proxy **cannot validate signatures** without AWS secret keys:
- Signature validation always happens at S3
- The proxy is a transparent forwarder
- Invalid signatures are rejected by S3, not the proxy

### Cache Poisoning

With long cache TTLs:
- A valid presigned URL can populate the cache
- Cached data remains accessible after URL expires
- This is by design for performance, but may bypass access control

## Best Practices

1. **Choose TTL strategy based on use case:**
   - Performance-critical: Long TTL
   - Security-critical: Zero TTL or matched TTL
   - Balanced: Matched TTL with local expiration checking

2. **Monitor presigned URL usage:**
   - Log when presigned URLs are detected
   - Track cache hits vs. S3 requests
   - Monitor 403 errors from expired URLs

3. **Consider clock skew:**
   - Ensure proxy system time is synchronized (NTP)
   - Add buffer time when matching cache TTL to URL expiration
   - Handle edge cases where clocks differ

4. **Document behavior:**
   - Make it clear to users how presigned URLs interact with caching
   - Document the chosen TTL strategy and its implications
   - Provide guidance on when to use each strategy

## Testing

Test presigned URL behavior:

```bash
# Generate a presigned URL (expires in 1 hour)
aws s3 presign s3://bucket/object --expires-in 3600

# Test through proxy
curl -v "http://s3.region.amazonaws.com/bucket/object?X-Amz-Algorithm=..."

# Check cache behavior
# First request: Cache miss, fetches from S3
# Second request: Cache hit (if TTL > 0)

# Test expired URL (wait for expiration or use past date)
# Should return 403 Forbidden
```

## Related Documentation

- [CACHING.md](CACHING.md) - Cache architecture and TTL configuration
- [CONFIGURATION.md](CONFIGURATION.md) - Configuration options
- [TESTING.md](TESTING.md) - Testing guidelines
