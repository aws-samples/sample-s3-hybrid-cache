# Investigation: v1.1.9 Issues

Date: 2026-01-29
Version: 1.1.9

## Resolution Status

The issues identified in this investigation were attempted to be addressed by the following specs.

- **`.kiro/specs/journal-based-size-tracking/`** - Consolidated size tracking into JournalConsolidator
- **`.kiro/specs/eviction-and-journal-cleanup-fixes/`** - Stale entry cleanup, retry logic, configurable thresholds

These specs were implemented after this investigation was written. They were not successful

---

## Summary

Two issues identified during v1.1.9 testing:

1. **Size tracking discrepancy**: Size state shows 1.58 GB but actual disk usage is 919 MB
2. **Invalid journal entries**: 87 journal entries repeatedly filtered out every consolidation cycle

---

## Issue 1: Size Tracking Discrepancy

### Observed Behavior

| Metric | Value |
|--------|-------|
| Size state (`total_size`) | 1,583,647,411 bytes (1.47 GB) |
| Actual disk usage (ranges) | 916,254,284 bytes (874 MB) |
| Actual disk usage (metadata) | 2,847,906 bytes (2.7 MB) |
| **Total actual disk** | 919,127,612 bytes (877 MB) |
| **Discrepancy** | 664,519,799 bytes (634 MB over-reported) |

### Root Cause Analysis

The size state was tracking more bytes than actually existed on disk due to:

1. **Eviction size update failures** - `atomic_subtract_size()` could fail on lock timeout or I/O error
2. **No retry mechanism** - Failed size updates were lost, causing drift
3. **Journal entries for evicted ranges not cleaned up** - Stale entries accumulated

### Resolution

Implemented in `.kiro/specs/eviction-and-journal-cleanup-fixes/`:

- **Requirement 2**: Retry size state updates with exponential backoff (3 attempts, 100ms/200ms/400ms delays, ±20% jitter)
- **Requirement 1**: Timeout-based stale journal entry cleanup (5-minute threshold)
- **Requirement 4**: Eviction notification to journal consolidator for immediate cleanup

---

## Issue 2: Invalid Journal Entries (AccessUpdate for Evicted Ranges)

### Observed Behavior

Every 5 seconds, the consolidation loop logged:
```
Filtered out 87 invalid journal entries: cache_key=egummett-testing-source-1/more-bigfiles/1GB-2
```

### Root Cause Analysis

Journal entries were `AccessUpdate` operations referencing ranges that had been evicted:
- Range file was deleted by eviction
- Journal entry remained because validation only filtered (didn't remove) invalid entries
- Entries accumulated indefinitely

### Resolution

Implemented in `.kiro/specs/eviction-and-journal-cleanup-fixes/`:

- **Requirement 1**: Stale entries (invalid for >5 minutes) are now removed during consolidation
- **Requirement 4**: Eviction notifies consolidator of deleted ranges for immediate cleanup (bypasses 5-minute timeout)

---

## Issue 3: Eviction Threshold Configuration

### Original Behavior

| Threshold | Value | Description |
|-----------|-------|-------------|
| Eviction trigger | 100% of max_size | Eviction starts when `current_size > max_size` |
| Eviction target | 80% of max_size | Eviction aims to reduce to 80% |

### Resolution

Implemented in `.kiro/specs/eviction-and-journal-cleanup-fixes/`:

- **Requirement 3**: Configurable eviction thresholds
  - `eviction_trigger_percent`: Default 95% (configurable 50-100%)
  - `eviction_target_percent`: Default 80% (configurable 50-99%)
  - Provides headroom before hitting 100% capacity

---

## Implementation Details

See the spec files for full implementation details:

- `.kiro/specs/journal-based-size-tracking/design.md` - Architecture and data flow
- `.kiro/specs/eviction-and-journal-cleanup-fixes/requirements.md` - Acceptance criteria

Key code changes:
- `src/journal_consolidator.rs` - `validate_journal_entries_with_staleness()`, `atomic_subtract_size_with_retry()`, `mark_ranges_evicted()`
- `src/config.rs` - `eviction_trigger_percent`, `eviction_target_percent` fields
- `src/cache.rs` - Eviction notification to consolidator after range deletion
