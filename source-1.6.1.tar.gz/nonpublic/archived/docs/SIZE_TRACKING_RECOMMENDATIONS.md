# Size Tracking Analysis

## Problem Statement

Track total cache size in real-time across multiple proxy instances sharing NFS storage, without using `du` (too slow at scale).

### Constraints

1. **No `du`**: Scanning filesystem is O(n) where n = number of files. Unacceptable at scale.
2. **Multi-instance**: Multiple nodes read/write the same shared cache simultaneously.
3. **Duplicate writes**: Multiple nodes may cache the same range at nearly the same time.
4. **NFS latency**: Lock operations on NFS have non-trivial latency (~10-50ms).
5. **Performance critical**: Cache writes must not block on size tracking.

## Current Architecture

### Data Flow

1. **Range stored**: `store_range_data()` writes range file + metadata
2. **Journal entry**: HybridMetadataWriter creates journal entry for the range
3. **Direct size add**: Attempt to add compressed_size to `size_state.json` (with lock)
4. **Consolidation**: Every 5s, process journal entries, update metadata, adjust size

### The Fundamental Problem

**HybridMetadataWriter writes to `.meta` immediately**, then creates a journal entry.

When consolidation runs:
- Reads metadata → range already present (from immediate write)
- Processes journal entry
- Reads metadata again → same (range still there)
- `size_delta = size_after - size_before = 0`

The metadata-based diff shows no change because the range was already there.

### Why Direct Size Tracking Was Added (v1.1.23)

To fix the above, v1.1.23 added direct `atomic_add_size()` calls after storing ranges. This bypasses the journal-based tracking entirely for adds.

Eviction already did this (v1.1.21) - direct subtract after eviction.

### The Performance Problem (v1.1.24-v1.1.25)

Direct size tracking requires acquiring `size_state.lock` on NFS for every range store.

Even with non-blocking try-lock (v1.1.25), the lock attempt itself is an NFS operation that adds latency. With high concurrency, this causes ~30% throughput degradation.

## Analysis of Approaches

### Approach A: Direct Size Tracking (Current)

**How it works**: Lock → read → add → write → unlock on every range store.

**Pros**: Accurate (when lock acquired)
**Cons**: 
- NFS lock latency on every write (~10-50ms)
- 30% throughput degradation observed
- Lock contention with multiple instances

**Verdict**: Unacceptable performance impact.

### Approach B: Consolidation-Only (Pre-v1.1.23)

**How it works**: No per-write tracking. Consolidation calculates `size_delta = size_after - size_before`.

**Pros**: No per-write overhead
**Cons**: 
- Doesn't work with immediate metadata writes (range already in metadata)
- 20-25% under-reporting observed

**Verdict**: Doesn't work with current HybridMetadataWriter behavior.

### Approach C: Journal-Based Size Tracking

**How it works**: Journal entries include `compressed_size`. Consolidation sums sizes from journal entries.

**Problem**: Multiple instances may create journal entries for the same range. Summing all entries double-counts.

**Tried in v1.1.18-v1.1.19**: 
- v1.1.18: Count size from journal entries even when range exists in metadata
- v1.1.19: Deduplicate by (start, end) with HashSet

**Why it failed**: The deduplication only works within a single consolidation cycle. If Instance A's consolidation runs first and counts the range, then Instance B's consolidation runs and also counts it (different cycle, fresh HashSet), we still double-count.

**Verdict**: Failed in practice. Abandoned in v1.1.20.

### Approach D: Periodic Validation Scan

**How it works**: Periodically scan metadata files, sum all `compressed_size` values, reset `size_state.json`.

**Pros**: Self-correcting, handles all edge cases
**Cons**: 
- O(n) scan, but only on metadata files (much smaller than range files)
- Temporary inaccuracy between scans

**Verdict**: Good as a fallback/correction mechanism, not primary tracking.

### Approach E: Hybrid - Journal Tracking + Metadata Check

**How it works**:
1. Remove direct size tracking (no per-write lock)
2. Journal entries include `compressed_size`
3. Consolidation: only count size for ranges NOT already in metadata at cycle start
4. Periodic validation scan corrects drift

**Key insight**: Check metadata BEFORE processing journal entries. If range already exists, some previous consolidation (this instance or another) already counted it.

**Difference from v1.1.18-v1.1.19**: Those versions tried to deduplicate journal entries. This approach deduplicates against metadata state.

**Why this might work**:
- Instance A caches range X, creates journal entry
- Instance A's consolidation runs: range NOT in metadata → count size, add to metadata
- Instance B caches range X, creates journal entry (but range file already exists on NFS)
- Instance B's consolidation runs: range IS in metadata → skip size counting

**Potential issue**: What if Instance A and B's consolidations run simultaneously?
- Both read metadata at same time (range not present)
- Both count the size
- Both try to add to metadata (one wins, one sees "already exists")
- Result: Double-counted

**Mitigation**: The consolidation lock should prevent simultaneous consolidation of the same cache key. Need to verify this.

**Verdict**: Worth investigating if consolidation lock prevents the race.

## Recommended Solution

### Implemented in v1.1.26: Journal-Based Size Tracking with Deduplication

Reverted to v1.1.19-style approach:

1. **No direct size tracking** - removed `atomic_add_size()` call from `store_range_data()`
2. **Removed `size_tracked` flag** - no longer needed
3. **Size calculated from journal entries** with per-consolidation-cycle deduplication

**How it works:**
```rust
let mut seen_ranges: HashSet<(u64, u64)> = HashSet::new();
let mut size_delta: i64 = 0;

for entry in &valid_entries {
    let range_key = (entry.range_spec.start, entry.range_spec.end);
    match entry.operation {
        JournalOperation::Add => {
            if !seen_ranges.contains(&range_key) {
                seen_ranges.insert(range_key);
                size_delta += entry.range_spec.compressed_size as i64;
            }
        }
        JournalOperation::Remove => {
            size_delta -= entry.range_spec.compressed_size as i64;
        }
        _ => {} // No size change
    }
}
```

**Trade-offs:**
- Performance: Restored (no per-write NFS lock attempts)
- Accuracy: May over-report when multiple instances cache same range across different consolidation cycles
- Safety: Over-reporting is safe (eviction triggers early, disk never fills unexpectedly)

### Testing Plan

1. Deploy v1.1.26 with cache clear
2. Run multi-instance download test
3. Compare tracked size vs `du` output
4. If over-reporting observed, document the magnitude
5. If under-reporting observed, investigate root cause

### Key Questions to Answer

1. **Does one node consolidate all journals?** Yes - `discover_pending_cache_keys()` reads ALL `*.journal` files from all instances. Deduplication happens within a single consolidation run.

2. **Why did v1.1.19 over-report?** The changelog says it "couldn't handle all edge cases" but doesn't specify what. Need to re-test to determine actual behavior.

3. **What's the expected behavior with v1.1.26?**
   - Single instance: Should be accurate (no duplicate journal entries)
   - Multi-instance, same range cached by multiple: Depends on timing
     - If journals consolidated together: Dedup catches it, accurate
     - If journals consolidated in separate cycles: May double-count

4. **Is over-reporting acceptable?** Yes - eviction triggers early, disk never fills. Under-reporting is dangerous.

### Verification Commands

Check tracked vs actual size:
```bash
# Get tracked size from dashboard
curl -s http://localhost:8081/api/stats | jq '.cache_size'

# Get actual size from du
du -sb /mnt/efs/cache/ranges/ | cut -f1
```

Check consolidation logs for size delta:
```bash
journalctl -u s3-proxy --since "5 minutes ago" | grep "size_delta"
```

## Historical Issues

| Version | Issue | Root Cause |
|---------|-------|------------|
| v1.1.18 | ~120MB under-reporting fixed, then 350MB over-reporting | Counted journal entries even when range in metadata |
| v1.1.19 | Fixed 350MB over-reporting with HashSet dedup | Per-cycle dedup by (start, end) |
| v1.1.20 | Rewrote to metadata-based diff | Abandoned journal-based due to "edge cases" (unspecified) |
| v1.1.20-v1.1.22 | 20-25% under-reporting | Metadata-based diff = 0 with immediate writes |
| v1.1.23 | 2x over-reporting | Direct add + consolidation both counted |
| v1.1.24 | 6% under-reporting, slow consolidation | Retry logic caused 30-90s cycles |
| v1.1.25 | 30% throughput degradation | Non-blocking lock still has NFS latency |
| v1.1.26 | 100% under-reporting (showed 0) | Journal-based dedup: Remove entries processed but Add entries already cleaned up |
| v1.1.27 | ~18% under-reporting | Metadata-based diff: same issue as v1.1.20 - HybridMetadataWriter writes immediately |

## Architecture Notes

### Journal Consolidation Flow

1. Each instance writes to its own journal file: `metadata/_journals/{instance_id}.journal`
2. ANY instance's consolidation loop reads ALL journal files
3. For each unique cache_key found, `consolidate_object()` is called
4. Consolidation acquires per-cache-key lock before processing
5. All journal entries for that cache_key (from all instances) are processed together
6. Deduplication by (start, end) happens within this single consolidation run

### Why Deduplication Should Work

If Instance A and B both cache range X:
- Both write to their own journal files
- When consolidation runs (on any instance), it reads BOTH journal files
- Both entries for range X are seen in the same consolidation cycle
- HashSet dedup catches the duplicate → only counted once

### Potential Edge Case

If Instance A's consolidation runs and processes range X, then Instance B caches range X AFTER A's consolidation but BEFORE B's journal is read by the next consolidation:
- A's consolidation: counted range X, cleaned up A's journal entry
- B caches range X: writes to B's journal
- Next consolidation: sees B's entry, counts range X again
- Result: Double-counted

This is the "cross-cycle" double-counting scenario. The magnitude depends on how often this timing occurs.

## Files to Modify

- `src/disk_cache.rs`: Remove `atomic_add_size()` call
- `src/journal_manager.rs`: Remove `size_tracked` field
- `src/hybrid_metadata_writer.rs`: Remove `size_tracked` parameter
- `src/journal_consolidator.rs`: Fix size calculation to use journal entries directly
- `src/cache_hit_update_buffer.rs`: Remove `size_tracked` parameter
- `src/orphaned_range_recovery.rs`: Remove `size_tracked` parameter


## v1.1.26 and v1.1.27 Analysis

### v1.1.26: Journal-Based Dedup (Failed)

**Approach**: Calculate size_delta from journal entries with HashSet deduplication by (start, end).

**Result**: 100% under-reporting - tracked size showed 0 while actual was ~782 MB.

**Root Cause**: 
1. Add journal entries are created when ranges are stored
2. Consolidation processes Add entries, counts size, then cleans up entries from journal
3. Later, eviction runs and writes Remove journal entries
4. Next consolidation sees Remove entries but Add entries are already gone
5. Remove subtracts size, but there's no Add to balance it
6. Result: negative size_delta, total_size clamps to 0

**Key Insight**: Journal-based tracking fails because Add and Remove entries are processed in different consolidation cycles.

### v1.1.27: Metadata-Based Diff (Partial Success)

**Approach**: Calculate size_delta from metadata state: `size_after - size_before`.

**Result**: ~18% under-reporting - tracked 1.40 GB vs actual 1.71 GB.

**Why It's Better Than v1.1.26**: 
- Remove operations correctly subtract (range removed from metadata)
- No negative size_delta issue
- Eviction tracking works correctly

**Why It Still Under-Reports**:
- HybridMetadataWriter writes ranges to `.meta` immediately
- When consolidation runs, range is already in metadata
- `apply_journal_entries()` sees "range already exists" → skips it
- `size_before == size_after` for these ranges → delta = 0
- The range IS on disk and counted by `du`, but consolidation didn't see a change

**This is the same fundamental issue as v1.1.20.**

### Test Results (2026-02-04)

| Time | Tracked | Actual (du) | Gap | Error |
|------|---------|-------------|-----|-------|
| 21:13 | 1.28 GB | 1.31 GB | 21 MB | 1.7% |
| 21:29 | 1.40 GB | 1.71 GB | 305 MB | 17.9% |

The gap widened during active downloads because new ranges were written directly to metadata by HybridMetadataWriter, bypassing size tracking.

## Deep Analysis: Why Every Approach Fails

### The Core Conflict

Two architectural decisions create an unsolvable conflict:

1. **HybridMetadataWriter writes immediately** - For atomicity and crash recovery, ranges are written to `.meta` files immediately, then journal entries are created for redundancy.

2. **Consolidation is the size tracker** - Size tracking happens during consolidation, which processes journal entries.

**The Problem**: By the time consolidation runs, the range is already in metadata. Any approach that measures "what changed" sees no change.

### Why Each Approach Fails

| Approach | Failure Mode |
|----------|--------------|
| Journal entry counting | Add/Remove processed in different cycles → negative delta |
| Metadata diff (before/after) | Range already in metadata → delta = 0 |
| Direct per-write tracking | NFS lock latency → 30% throughput degradation |
| size_tracked flag | Double-counting when flag not set correctly |

### The Fundamental Options

1. **Change HybridMetadataWriter** - Don't write to metadata immediately; let consolidation do it. This would fix size tracking but break the atomicity guarantees.

2. **Track size at write time** - Accept the NFS lock overhead. This works but has unacceptable performance impact.

3. **Periodic validation scan** - Accept temporary inaccuracy, periodically scan metadata to correct drift. This is a fallback, not a solution.

4. **Hybrid: Journal + Metadata Check** - Count size from journal entries, but only if range is NOT already in metadata at cycle start. This might work but needs careful implementation.

5. **In-memory accumulator with periodic flush** - Track size in memory (no NFS lock per write), flush to disk periodically. Risk: lost updates on crash.

## Potential Solutions to Explore

### Option 1: Don't Clean Up Add Entries Until Range Removed

Keep Add journal entries in the journal until a corresponding Remove is processed. This ensures Add and Remove are always processed together.

**Pros**: Correct accounting
**Cons**: Journal files grow unbounded; complex cleanup logic

### Option 2: Track "Counted Ranges" Persistently

Maintain a persistent set of (cache_key, start, end) tuples that have been counted. Only count Add if not in set; only count Remove if in set.

**Pros**: Correct accounting across cycles
**Cons**: Another file to maintain; potential for drift

### Option 3: Size Tracking at HybridMetadataWriter Level

Move size tracking into HybridMetadataWriter. When it writes a NEW range (not update), increment an in-memory counter. Flush counter to disk periodically.

**Pros**: Tracks at the right moment; no NFS lock per write
**Cons**: Lost updates on crash; need to handle multi-instance

### Option 4: Accept Under-Reporting + Periodic Correction

Accept that real-time tracking will under-report by ~20%. Run periodic validation scan (every hour?) to correct drift.

**Pros**: Simple; no architectural changes
**Cons**: Eviction triggers late; may exceed capacity temporarily

### Option 5: Batched Size Updates

Accumulate size changes in memory. Every N seconds (or N writes), acquire lock and flush accumulated delta.

**Pros**: Amortizes lock overhead; better than per-write locking
**Cons**: Still some lock overhead; lost updates on crash

## Recommendation

**Short-term**: Accept v1.1.27's ~18% under-reporting. It's safe (won't fill disk unexpectedly) and has good performance.

**Medium-term**: Implement periodic validation scan to correct drift. Run every 30-60 minutes.

**Long-term**: Consider Option 3 (size tracking at HybridMetadataWriter level) with careful handling of multi-instance scenarios and crash recovery.

## Promising Solutions (2026-02-04)

### Option A: `metadata_written` Flag on Journal Entries

**Concept**: Add a boolean field to JournalEntry indicating whether the immediate write to `.meta` succeeded.

**Implementation**:
1. HybridMetadataWriter sets `metadata_written: true` when immediate write succeeds
2. HybridMetadataWriter sets `metadata_written: false` when falling back to journal-only
3. Consolidation only counts size for Add entries where `metadata_written: false`

**Why it works**:
- `metadata_written: true` → range already in metadata, don't count (would double-count)
- `metadata_written: false` → range not in metadata yet, count when consolidation adds it
- Flag is set at write time, avoiding cross-cycle problems

**Multi-instance behavior**:
- Each instance sets flag based on its own write result
- If Instance A succeeds (true) and Instance B fails (false) for same range, B's entry counts
- Slight over-counting possible but bounded

**Changes**: journal_manager.rs (add field), hybrid_metadata_writer.rs (set flag), journal_consolidator.rs (check flag)

### Option B: In-Memory Accumulator with Periodic Flush

**Concept**: Track size changes in memory, flush accumulated delta to disk periodically.

**Implementation**:
1. Each instance maintains `AtomicI64` for accumulated size delta
2. When range stored: `delta.fetch_add(compressed_size, Ordering::Relaxed)`
3. When range evicted: `delta.fetch_sub(compressed_size, Ordering::Relaxed)`
4. Every N seconds (e.g., 5s): acquire lock, read size_state, add delta, write size_state, reset delta to 0

**Why it works**:
- No per-write NFS lock (just atomic in-memory operation)
- Periodic flush amortizes lock overhead
- Daily validation corrects any drift

**Multi-instance behavior - THE CHALLENGE**:

Each instance accumulates its own delta. When flushing:
Instance A: delta_a = +100MB, reads size_state = 500MB, writes 600MB Instance B: delta_b = +50MB, reads size_state = 500MB, writes 550MB (OVERWRITES A's update!)


**Solutions for multi-instance**:

1. **Atomic read-modify-write with lock**: Already have this via `atomic_update_size_delta()`. Works but adds lock overhead at flush time.

2. **Delta files per instance**: Each instance writes to `size_tracking/delta_{instance_id}.json`. Consolidation sums all delta files. No lock contention.
size_tracking/ size_state.json # Total size (updated by consolidation) delta_instance1.json # Instance 1's pending delta delta_instance2.json # Instance 2's pending delta


Consolidation: `new_total = current_total + sum(all deltas)`, then truncate delta files.

3. **Append-only delta log**: Each instance appends to shared `delta.log`. Consolidation reads log, sums deltas, updates size_state, truncates log. Risk: concurrent appends need coordination.

**Recommended approach**: Per-instance delta files (option 2). Each instance writes only its own file (no lock needed). Consolidation reads all files (read-only, no lock needed), updates size_state (single writer), truncates delta files.

### Option C: Hybrid - Flag + Accumulator

Combine both approaches:
1. Use `metadata_written` flag for correctness
2. Use in-memory accumulator for performance
3. Flush accumulator during consolidation cycle

This gives both correctness (flag ensures we count the right things) and performance (no per-write lock).

## Recommendation

**Option A (`metadata_written` flag)** is the simplest and most correct solution. It requires minimal code changes and directly addresses the root cause: we need to know at consolidation time whether the range was already in metadata when the journal entry was created.

**Option B (in-memory accumulator)** is a performance optimization that could be added later if needed. The per-instance delta files approach solves the multi-instance problem elegantly.

**Next step**: Implement Option A and test. If performance is acceptable, ship it. If not, add Option B as an optimization layer.


**Next step**: Implement Option A and test. If performance is acceptable, ship it. If not, add Option B as an optimization layer.

## v1.1.28 Test Results (2026-02-05)

### Test Setup
- Cache cleared, proxy restarted at 07:32:06 UTC
- Downloads triggered through proxy
- Eviction occurred (cache exceeded 1.5GB limit)

### Results
| Metric | Value |
|--------|-------|
| Tracked size | 1,280,012,973 bytes (1.19 GB) |
| Actual ranges (du) | 1,377,694,563 bytes (1.28 GB) |
| Sum of compressed_size in metadata | 1,377,008,483 bytes |
| Gap | 97,681,590 bytes (~93 MB, 7.1%) |

### Observations
1. Sum of compressed_size in metadata matches actual disk usage (within ~686KB)
2. Tracked size is ~97 MB less than metadata sum
3. Consolidation logs show negative size_delta values (-2962080, -5101360, etc.)
4. Negative deltas are from Remove operations during eviction (correct behavior)
5. But total tracked size is still under-reporting

### Hypothesis
The `metadata_written` flag may be set to `true` in more cases than expected, causing Add entries to be skipped. Need debug logging to trace actual flag values.

### v1.1.29 Debug Logging
Added INFO-level logging to `calculate_size_delta()`:
- Each Add entry: logs COUNTED or SKIPPED with metadata_written value
- Each Remove entry: logs with size
- Summary: add_counted, add_skipped, remove_counted, total_delta

This will reveal whether Add entries are being incorrectly skipped due to metadata_written=true.
