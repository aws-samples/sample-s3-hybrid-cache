# Old Format Cache Storage Removal Summary

## Date
December 5, 2024

## Overview
Removed legacy "old format" cache storage code that stored range data inline within metadata structures. The codebase now exclusively uses the "new format" architecture where metadata and data are stored separately.

## Changes Made

### 1. Data Structure Changes

**File: `src/cache_types.rs`**
- Removed `data: Vec<u8>` field from `Range` struct
- Range struct now only contains metadata (start, end, etag, last_modified, compression_algorithm)
- Added documentation noting that data is stored separately in range files

### 2. Range Handler Simplification

**File: `src/range_handler.rs`**
- Removed old storage format fallback in `find_cached_ranges()` method (~120 lines)
  - Eliminated call to `get_cached_response()` for old format lookup
  - Removed full object body handling from old format
  - Removed old format range overlap checking
- Simplified `extract_bytes_from_cached_range()` method
  - Removed check for `cached_range.data.is_empty()`
  - Removed old format decompression logic
  - Now always loads from new storage architecture via `load_range_data_from_new_storage()`

### 3. HTTP Proxy Cleanup

**File: `src/http_proxy.rs`**
- Removed old format data handling in single-range cache hit path
  - Eliminated `if cached_range.data.is_empty()` check
  - Removed inline decompression of old format data
  - Simplified to always use `load_range_data_with_cache()`

### 4. Deprecated Methods (Still Present, Not Called)

**File: `src/cache.rs`**
The following methods are no longer used but remain in the codebase:
- `store_range_in_cache()` - Stores ranges in old format
- `get_range_from_cache()` - Retrieves ranges from old format
- `store_versioned_range_in_cache()` - Version-specific old format storage
- `get_versioned_range_from_cache()` - Version-specific old format retrieval
- `merge_overlapping_ranges()` - Merges old format ranges

**Note:** These methods are not called anywhere in the codebase and can be removed in a future cleanup.

## Architecture After Removal

### New Format (Only Format Now)
- **Metadata**: Stored in `cache_dir/objects/*.meta` files
  - Lightweight JSON files
  - Track which ranges exist
  - No actual data stored
- **Data**: Stored in `cache_dir/ranges/*.bin` files
  - Separate binary files for each range
  - Loaded on-demand
  - Compressed with LZ4

### Benefits
1. **Simpler Code**: Removed ~200 lines of fallback logic
2. **Single Code Path**: No more branching between old/new formats
3. **Clearer Architecture**: One way to store and retrieve data
4. **Better Performance**: No need to check multiple storage locations

## Backward Compatibility

**Breaking Change**: Old format cache entries will no longer be readable.

**Migration Path**: 
- Clear cache before upgrading: `rm -rf cache_dir/*`
- Or let cache naturally expire and repopulate

## Testing

- Library builds successfully: ✓
- No compilation errors related to removed fields: ✓
- No tests use removed methods: ✓

## Files Modified

1. `src/cache_types.rs` - Removed `data` field from `Range`
2. `src/range_handler.rs` - Removed old format fallback logic
3. `src/http_proxy.rs` - Removed old format data handling
4. `src/cache.rs` - Fixed RAM cache decompression bug (separate fix)

## Related Bug Fix

While removing old format code, also fixed a bug where RAM cache was returning compressed data without decompressing it. This was causing "slice index out of bounds" errors when serving cached ranges.

**Fix**: Modified `load_range_data_with_cache()` in `src/cache.rs` to check `ram_entry.compressed` flag and decompress data before returning.

## Next Steps

Optional future cleanup:
1. Remove unused deprecated methods from `cache.rs`
2. Remove `body` field from `CacheEntry` if not needed for write cache
3. Simplify `CacheEntry` structure further
