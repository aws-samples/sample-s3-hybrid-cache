# S3 Proxy - Quick Start Guide

## Prerequisites

- Rust toolchain installed
- AWS credentials configured (`aws configure`)

## Development/Testing Setup

Use non-privileged ports (no sudo required):

```bash
# 1. Build the project
cargo build --release

# 2. Start the proxy
cargo run --release -- -c config-perf.yaml
```

The proxy will start on:
- HTTP: `localhost:8081`
- HTTPS: `localhost:8443`
- Health: `localhost:8080/health`
- Metrics: `localhost:8080/metrics`

## Production Setup

Use standard ports (requires sudo):

```bash
# 1. Build the project
cargo build --release

# 2. Create directories
sudo mkdir -p /var/log/s3-proxy/access /var/log/s3-proxy/app /var/cache/s3-proxy
sudo chown $USER:$USER /var/log/s3-proxy /var/cache/s3-proxy -R

# 3. Start the proxy
sudo ./target/release/s3-proxy -c config.yaml
```

The proxy will start on:
- HTTP: `0.0.0.0:80`
- HTTPS: `0.0.0.0:443`
- Health: `0.0.0.0:8080/health`
- Metrics: `0.0.0.0:8080/metrics`

## Configure Hosts File

To route S3 traffic through the proxy:

```bash
# Edit /etc/hosts (requires sudo)
sudo nano /etc/hosts

# Add these lines (for localhost testing)
127.0.0.1 s3.amazonaws.com
127.0.0.1 s3.us-east-1.amazonaws.com
127.0.0.1 your-bucket.s3.amazonaws.com
```

## Test the Proxy

### With Development Config (port 8081)

```bash
# Test with curl (direct HTTP)
curl http://localhost:8081/your-bucket/your-key

# AWS CLI requires endpoint URL for non-standard ports
aws s3 ls s3://your-bucket/ \
  --endpoint-url "http://localhost:8081"

# Check health
curl http://localhost:8080/health

# Check metrics
curl http://localhost:9090/metrics
```

### With Production Config (port 80)

```bash
# AWS CLI defaults to HTTPS, force HTTP to use proxy caching
aws s3 ls s3://your-bucket/ \
  --endpoint-url "http://s3.us-east-1.amazonaws.com"

# Or use HTTPS with self-signed mode (requires config change)
aws s3 ls s3://your-bucket/ --no-verify-ssl

# Test with curl
curl http://s3.amazonaws.com/your-bucket/your-key

# Check health
curl http://localhost:8080/health

# Check metrics
curl http://localhost:9090/metrics
```

## Configuration Files

- `config.yaml` - Production config (ports 80/443, requires sudo)
- `config-perf.yaml` - Testing config (ports 8081/8443, no sudo)
- `config.example.yaml` - Docker config (ports 80/443, Docker paths)

## Key Configuration Options

### Cache Settings
```yaml
cache:
  cache_dir: "/var/cache/s3-proxy"  # Cache storage location
  max_cache_size: 10737418240       # 10GB max cache size
  get_ttl: "315360000s"             # ~10 years (cache forever)
  put_ttl: "3600s"                  # 1 hour for PUT operations
```

### Logging
```yaml
logging:
  access_log_dir: "/var/log/s3-proxy/access"
  app_log_dir: "/var/log/s3-proxy/app"
  access_log_mode: "all"            # or "cached_only"
  log_level: "info"
```

### Compression
```yaml
compression:
  enabled: true
  threshold: 1024                   # 1KB minimum
  preferred_algorithm: "lz4"
  content_aware: true               # Skip already-compressed files
```

## Troubleshooting

### "Address already in use"
- Ports 80/443 are privileged - use `sudo` or use `config-perf.yaml`
- Check if another service is using the port: `lsof -i :80`

### "Failed to create log directory"
- Ensure you're using `-c config.yaml` or `-c config-perf.yaml`
- Without `-c`, the proxy uses Docker default paths

### "Read-only file system"
- Create directories with proper permissions
- For testing, use `/tmp` paths in configuration files

## Next Steps

- Review [Caching Documentation](docs/CACHING.md)
- Configure [OTLP Metrics](docs/OTLP_METRICS.md)
- Deploy with [Docker](docs/README-Docker.md)

## Common Commands

```bash
# Build
cargo build --release

# Test
cargo test

# Run with config
cargo run --release -- -c config-perf.yaml

# View logs
tail -f /tmp/s3-proxy-logs/app/$(hostname)/s3-proxy.log.*
```
