# Size Tracking Bug Analysis (v1.1.30 - v1.1.32)

See `SIZE_TRACKING_RECOMMENDATIONS.md` for full history.

## v1.1.30 Test Results (2026-02-05)

### Issue: Double Subtraction on Eviction

**Root Cause**: Eviction was subtracting bytes_freed twice:
1. Direct call to `atomic_subtract_size_with_retry()` after eviction
2. Remove journal entries processed by consolidation

**Fix**: Removed direct subtraction calls in `src/cache.rs` (lines ~4200 and ~5930). Let consolidation handle all size updates via journal entries.

### Test Results

| Metric | Value |
|--------|-------|
| Tracked | 1,287,071,156 bytes (1.2 GB) |
| Actual (du) | 398,361,058 bytes (380 MB) |
| Metadata sum | 398,057,954 bytes |

**Now OVER-REPORTING by ~3x!**

### Analysis

- Add COUNTED: 3384 entries (all with `metadata_written=false`)
- Add SKIPPED: 0 entries
- Remove COUNTED: 2413 entries
- Eviction wrote 2342 Remove entries

The math doesn't add up. Tracked is 3x actual.

## v1.1.31 Fix: Duplicate Journal Entry Over-Counting

### Root Cause Found

`calculate_size_delta()` was counting ALL valid journal entries, but `apply_journal_entries()` skips Add entries where the range already exists in metadata.

In multi-instance environments, the same range can have multiple journal entries (from retries or multiple instances). Each entry was counted for size, but the range was only added once to metadata.

**Example**:
1. Instance A caches range X, creates journal entry (+100KB)
2. Instance B caches same range X, creates journal entry (+100KB)
3. Both entries are valid (range file exists)
4. `calculate_size_delta()` counts BOTH: +200KB
5. `apply_journal_entries()` adds range ONCE (second is "already exists")
6. Result: 100KB on disk, 200KB tracked

### Fix

Changed `apply_journal_entries()` to return `size_affecting_entries` - only entries that actually affect size:
- Add entries that were actually applied (not skipped)
- All Remove entries

Changed `consolidate_object()` to use `size_affecting_entries` for `calculate_size_delta()` instead of `valid_entries`.

### Files Changed

- `src/journal_consolidator.rs`: 
  - `apply_journal_entries()`: populate and return `size_affecting_entries`
  - `consolidate_object()`: use returned entries for size calculation

## Performance Concern

**Observed**: Downloads slowed to ~230 MB/s vs previous 300+ MB/s.

**Possible causes to investigate**:
1. INFO-level logging in `calculate_size_delta()` (added in v1.1.29)
2. Additional vector allocation for `size_affecting_entries`
3. Clone operations on journal entries

**Recommendation**: If size tracking is accurate in v1.1.31, consider removing verbose INFO logging or reducing to DEBUG level.

## Test Plan for v1.1.31

1. Run multi-instance download test
2. Compare tracked size vs `du` output
3. Monitor download throughput
4. If accurate but slow, remove verbose logging in v1.1.32


## v1.1.31 Test Results (2026-02-05)

| Metric | Value |
|--------|-------|
| Tracked | 1,287,372,437 bytes (1.23 GB) |
| Actual (du) | 1,488,466,883 bytes (1.42 GB) |
| Metadata sum | 1,487,805,379 bytes |
| Gap | 201 MB (13.5% under-reporting) |

### Investigation Findings

1. SIZE_TRACK logs show `add_skipped=0` - no entries skipped due to `metadata_written=true`
2. Same cache_key processed multiple times (e.g., `500MBcopy` processed 226 times across 3 instances)
3. No lock contention: 0 "lock held by another" messages - instances run sequentially
4. Sum of deltas from all instances: ~5.5 GB (much higher than actual 1.42 GB)
5. Size dropped from 1.68 GB to 1.23 GB between consolidation cycles without eviction logging
6. NFS issue: `WARN Failed to acquire journal file lock for cleanup: error=Stale file handle (os error 116)`
7. Long consolidation cycle: 92,798ms during which another instance modified size_state.json

### Root Cause Analysis

The per-cache-key lock prevents simultaneous consolidation of the same cache_key, but does NOT prevent:

1. **Sequential duplicate processing**: Due to NFS caching delays, journal cleanup may not be visible to other instances. Instance A consolidates, cleans up journal, but Instance B still sees the entry (NFS cached) and processes it again.

2. **Size state drift during long cycles**: Instance 1 starts 92-second consolidation, Instance 2 runs eviction mid-cycle and updates size_state.json, Instance 1 finishes and reads the modified (lower) value.

## v1.1.32 Fix: Global Consolidation Lock

### Solution

Added flock-based global consolidation lock to prevent multiple instances from running consolidation cycles simultaneously.

### Implementation

- New struct: `GlobalConsolidationLock` (instance_id, process_id, hostname, acquired_at, timeout_seconds)
- New field: `consolidation_lock_file: Mutex<Option<std::fs::File>>` in `JournalConsolidator`
- New methods:
  - `try_acquire_global_consolidation_lock()` - non-blocking flock
  - `release_global_consolidation_lock()` - explicit release
- Lock file: `{cache_dir}/locks/global_consolidation.lock`
- Uses `scopeguard` for RAII-based lock release on all exit paths
- If lock held by another instance, cycle is skipped (returns immediately)

### Trade-off

Only one instance consolidates at a time. Given 5-second interval and typical cycle duration, this should not cause significant delays.

### Files Changed

- `src/journal_consolidator.rs`: Added lock struct, field, methods, modified `run_consolidation_cycle()`
- `Cargo.toml`: Added `scopeguard = "1.2"` dependency, bumped version to 1.1.32
- `CHANGELOG.md`: Added v1.1.32 entry

## v1.1.32 Test Results (2026-02-05/06)

### Test Timeline

- v1.1.29 running from 08:08:27 UTC (test ran 09:10-14:00)
- v1.1.32 deployed at 14:39:52 UTC
- Daily validation ran at 00:03:18 UTC on Feb 6

### Critical Finding: Test Ran on Wrong Version

The SIZE_TRACK logs analyzed (09:10-14:00) were from **v1.1.29**, not v1.1.32. The global consolidation lock wasn't active during the test.

### Multi-Instance Over-Counting (v1.1.29)

| Instance | Delta Sum | 
|----------|-----------|
| Instance 1 | 1,586,787,150 bytes (1.48 GB) |
| Instance 3 | 3,021,611,933 bytes (2.81 GB) |
| Instance 4 | 2,059,863,495 bytes (1.92 GB) |
| **Total** | **6,668,262,578 bytes (6.21 GB)** |
| **Actual disk** | **1,475,160,085 bytes (1.37 GB)** |

**Over-counting ratio: 4.5x**

All 3 instances ran consolidation simultaneously, each processing the same journal entries and logging SIZE_TRACK deltas. Zero "Skipping consolidation cycle" messages found.

### Daily Validation Correction

```
Feb 06 00:03:18 Cache validation: 1.4 GiB scanned, drift +83.5 MiB
Feb 06 00:03:18 Updated size state from validation: old_size=1387566143, new_size=1475160085, drift=87593942
```

The validation scan corrected the tracked size from 1.29 GB to 1.37 GB (actual).

### Current State (Post-Validation)

| Metric | Value |
|--------|-------|
| Tracked (size_state.json) | 1,475,160,085 bytes |
| Actual (du) | 1,475,641,365 bytes |
| Gap | 481,280 bytes (0.03%) |

Global consolidation lock file shows recent acquisition by Instance 3 at 10:13:59 UTC on Feb 6.

### Root Cause Summary

Without the global consolidation lock (v1.1.29):
1. All instances read the same journal entries from NFS
2. Each instance calculated and logged SIZE_TRACK deltas independently
3. Race conditions in atomic_update_size_delta caused unpredictable results
4. Net effect: under-reporting due to read-modify-write conflicts

## v1.1.33 Test Results (2026-02-08)

v1.1.33 replaced journal-based size tracking with in-memory AtomicI64 accumulator. See `.kiro/specs/accumulator-size-tracking/` for full design.

### Deployment

- Deploy cleared cache: `sudo rm -rf /mnt/efs/cache/*`
- All 3 proxy instances restarted with v1.1.33 at ~16:03:56 UTC
- Cache initialized at 0 B on all instances
- Downloads started at ~16:11:57 UTC (3 instances writing concurrently)

### Infrastructure Reference

| Name | Instance ID | Private IP | Public IP | Role |
|------|-------------|------------|-----------|------|
| S3Proxy-Native-1 | i-0c2dc9618325b3ac8 | 172.31.34.221 | 52.33.106.186 | Proxy |
| S3Proxy-Native-3 | i-07e18a197171fc9ee | 172.31.37.46 | 54.245.57.47 | Proxy |
| S3Proxy-Native-4 | i-0f441137c0c3d2a98 | 172.31.34.83 | 35.93.194.242 | Proxy |
| S3Proxy-Test-4xlarge | i-0de43e30d415a2058 | 172.31.41.2 | 54.201.62.0 | Test client |

SSM commands target all 3 proxy instances. Region: us-west-2.

### Test Results

| Metric | Value |
|--------|-------|
| Tracked (size_state.json) | 1,325,238,696 bytes (1.23 GB) |
| Actual disk (du -sb ranges/) | 2,133,694,665 bytes (1.99 GB) |
| Metadata compressed_size sum | 2,132,918,473 bytes (2.03 GB) |
| Ranges on disk | 5,525 .bin files |
| Ranges in metadata | 5,525 entries |
| Gap (actual - tracked) | 807,679,777 bytes (770 MB) |
| Under-reporting | 37.9% |

### Accumulator Mechanism Observations

The accumulator and delta file mechanism is working:
- 3 delta files created (one per instance), all flushed to 0 after consolidation
- Consolidation cycles log `accumulator_delta` values correctly
- Eviction subtracted 428 MB via accumulator (symmetric with adds)
- Global lock working: only one instance consolidates at a time

One flush failure observed on Native-3 at 16:15:11:
```
WARN Failed to flush size accumulator at cycle start: Failed to rename delta file ... No such file or directory (os error 2)
```
The rollback logic restored the value to the accumulator (per design). This is a minor NFS timing issue, not the root cause.

### Root Cause Analysis: Silent Consolidation Cycles

The consolidation cycle progression from Native-3 (lock winner) reveals large gaps between logged cycles where `current_size` jumps far more than the logged `accumulator_delta`:

| Cycle | Acc Delta | Current Size | Silent Delta (gap) |
|-------|-----------|-------------|-------------------|
| 1 | +2.0 MB | 524.2 MB | +522.2 MB (silent cycles before first logged) |
| 6→7 | +28.6 MB | 1,665.5 MB | +794.8 MB (silent cycles between) |

The consolidation task runs every 5 seconds. When a cycle has no pending journal entries AND the accumulator delta collected is 0, it returns early without logging. But the `collect_and_apply_deltas()` step still runs and applies any pending delta files from other instances.

The problem: **the `accumulator_delta` logged in each cycle is only the delta collected from delta files in THAT cycle. But between logged cycles, many silent cycles also collected and applied deltas.** The logged deltas don't sum to the total because silent cycles applied deltas too.

This means the logging is misleading but the tracking itself may be correct — the question is whether the final tracked value (1.33 GB) accounts for all writes minus eviction.

### The Real Gap

Cache started at 0. All data was written fresh. The accumulator should have captured every `store_range()` call. Eviction freed ~431 MB of files. So:

- Expected tracked: (total bytes written) - (eviction bytes subtracted) 
- Actual tracked: 1,325,238,696

The metadata says 2,132,918,473 bytes exist on disk (post-eviction). If the accumulator tracked all writes and all eviction subtractions correctly, the tracked size should match the metadata sum.

Gap = 2,132,918,473 - 1,325,238,696 = 807,679,777 bytes (770 MB)

### Hypotheses for 770 MB Under-Reporting

1. **Eviction subtracted more than it should**: The eviction freed 431 MB from disk but the accumulator subtracted based on `compressed_size` from `RangeEvictionCandidate`. If `compressed_size` was larger than actual file size (e.g., due to stale metadata), the subtraction would be too large. Need to verify `compressed_size` values match actual file sizes.

2. **Multiple instances subtracting for same eviction**: Eviction runs on one instance, but if eviction journal Remove entries cause OTHER instances to also subtract via their accumulators, that would double-subtract. Need to verify only the evicting instance subtracts from accumulator.

3. **Delta file race condition**: The consolidator resets delta files after reading them. If an instance flushes its accumulator to a delta file AFTER the consolidator reads it but BEFORE the consolidator resets it, the flushed value gets overwritten with 0. This would lose deltas. The atomic tmp+rename pattern should prevent this, but NFS semantics may differ.

4. **`atomic_update_size_delta` called with (0,0) for consolidation count**: The code calls `atomic_update_size_delta(0, 0)` when `total_entries_consolidated > 0` just to increment `consolidation_count`. But this function has `if size_delta == 0 && write_cache_delta == 0 { return }` — so it skips the call entirely, meaning consolidation_count doesn't increment for journal-only cycles. This is a minor bug but doesn't affect size tracking.

## v1.1.34 Fix: Delta File Race Condition + Logging

### Changes

1. **Consolidator deletes delta files after reading** instead of resetting to 0. Eliminates the race where an instance flushes between the consolidator's read and reset, losing the new delta.
2. **Flush uses additive writes**: reads existing delta file, adds new delta, writes back. If the file was deleted by the consolidator, starts from 0 (no data loss).
3. **`reset_all_delta_files()` deletes files** instead of resetting to 0.
4. **Removed dead `atomic_update_size_delta(0, 0)` call** that was skipped by early return.
5. **INFO logging on every accumulator operation**: `SIZE_ACCUM add/subtract/flush/collect` with byte counts and instance IDs.

### Deployment

- Deployed to all 3 instances at ~17:03 UTC on Feb 8
- Cache cleared: `sudo rm -rf /mnt/efs/cache/*`
- Logs cleared: `journalctl --rotate && journalctl --vacuum-time=1s`
- Downloads started at ~17:06 UTC (3 instances writing concurrently)
- Downloads completed, eviction ran, system settled by ~17:17 UTC

### Test Results

| Metric | Value |
|--------|-------|
| Tracked (size_state.json) | 637,873,013 bytes (608 MB) |
| Actual disk (du -sb ranges/) | 638,188,405 bytes (608 MB) |
| Metadata compressed_size sum | 637,873,013 bytes |
| Ranges on disk | 2,519 .bin files |
| Ranges in metadata | 2,519 entries |
| Gap (actual - tracked) | 315,392 bytes (0.05%) |
| Metadata files | 45 |
| Consolidation cycles | 31 |

Tracked size matches metadata sum exactly. The 315 KB gap between tracked and `du` is filesystem block alignment overhead.

### Accumulator Mechanism Observations

The SIZE_ACCUM logging confirms the full lifecycle:
- `SIZE_ACCUM add`: logged on every `store_range()` call with compressed_size
- `SIZE_ACCUM subtract`: logged on every eviction range with compressed_size
- `SIZE_ACCUM flush`: logged with delta values being written to disk (e.g., `delta=-704103356`)
- `SIZE_ACCUM collect`: logged per-file with instance ID and delta values
- `SIZE_ACCUM collect_total`: logged with sum across all files (e.g., `files=3, total_delta=-1367396799`)

Delta file delete-after-read working: "no delta files" present at check time (all consumed by consolidator).

Additive flush working: Instance 3 (Native-3) flushed `+1546864` then `+691152` in consecutive cycles — the second flush correctly added to a fresh file after the consolidator deleted the first.

### Eviction Behavior

Two eviction rounds observed on Instance 1:
1. 17:12:05 — freed 237 MB (184 ranges from 1 key), triggered at 95.4% capacity
2. 17:15:18 — freed 685 MB (1594 ranges from 12 keys), triggered at 124.5% capacity

The second eviction took ~100 seconds (17:15:18 to 17:16:59) due to 1594 range deletions on NFS. During this time, the consolidation cycle was blocked (160,951ms duration logged).

Instance 4 (Native-4) also ran eviction independently: freed 665 MB (1958 ranges from 17 keys) at 17:12:26-17:14:58.

### No Errors or Warnings

No SIZE_ACCUM-related warnings or errors. One unrelated connection error on Instance 1 (HTTP body read failure, retried successfully).

### Conclusion

The delta file race condition was the root cause of the 770 MB under-reporting in v1.1.33. The fix (delete-after-read + additive flush) eliminates the race. Size tracking is now accurate to within filesystem block alignment overhead (0.05%).

### Next Steps

1. Reduce SIZE_ACCUM add/subtract logging from INFO to DEBUG — the per-operation logging is very verbose (thousands of lines per download). Keep flush/collect/collect_total at INFO.
2. Monitor over 24 hours to confirm daily validation scan drift is minimal.
3. Consider whether the 100-second eviction blocking the consolidation cycle is a problem. If so, eviction could be moved to a separate task that doesn't hold the consolidation cycle.


## Eviction Performance and Over-Eviction Analysis (v1.1.34)

Three related problems observed in v1.1.34 testing:
1. Cache size drops far below the 80% eviction target
2. Eviction blocks the consolidation cycle (100+ seconds observed)
3. Eviction is slow on NFS (1594 ranges took ~100 seconds)

### Problem 1: Over-Eviction

The eviction target is 80% of max_cache_size. In v1.1.34 testing, the cache dropped to 608 MB (from a max_cache_size of ~500 MB example config, though production uses a larger value). The v1.1.33 test shows the problem more clearly: eviction freed 237 MB in round 1, then 685 MB in round 2, with the second round triggered at 124.5% capacity.

Root cause: `group_candidates_by_object()` accumulates candidates until `accumulated_bytes >= bytes_to_free`, then stops. But it groups by object — when the last object added has many ranges, all of that object's ranges are included. The eviction loop in `perform_eviction_with_lock()` then evicts ALL grouped candidates without checking whether enough bytes have been freed mid-loop.

```
group_candidates_by_object():
  for candidate in sorted_candidates:
    if accumulated_bytes >= target_bytes:
      break                          # stops adding new candidates
    accumulated_bytes += candidate.size
    grouped[candidate.cache_key].push(candidate)

perform_eviction_with_lock():
  for (cache_key, ranges) in grouped_candidates:
    batch_evict_ranges(cache_key, ranges)   # no early exit check
```

The grouping function correctly limits candidate selection. The eviction loop does not over-evict beyond what was grouped. However, the grouping itself can overshoot because it adds candidates one at a time and the last candidate may push `accumulated_bytes` well past `target_bytes`.

More significantly: during active downloads, new data arrives while eviction runs. Eviction uses a stale `current_size` snapshot from the start of the consolidation cycle. By the time eviction finishes (100+ seconds later), the actual cache size may have grown significantly, but eviction already freed based on the old snapshot. The next consolidation cycle sees the cache is still over capacity and triggers another eviction round — this time with even more data to evict because the first round's freed space was partially refilled.

The real over-eviction happens when multiple eviction rounds fire in quick succession during active writes. Each round uses a stale size, each round frees aggressively to reach 80%, and the cumulative effect drops the cache well below target.

### Problem 2: Eviction Blocks Consolidation

The consolidation cycle in `run_consolidation_cycle()` calls `maybe_trigger_eviction()` synchronously at the end of each cycle. `maybe_trigger_eviction()` calls `enforce_disk_cache_limits_skip_consolidation()` which calls `perform_eviction_with_lock()` — all awaited inline.

The consolidation cycle holds the global consolidation lock for the entire duration. While eviction runs (100+ seconds for large evictions on NFS), no other instance can run consolidation. This means:
- Delta files from other instances accumulate without being collected
- Size state becomes stale
- Journal entries pile up without being consolidated
- New writes during eviction are not reflected in size tracking until eviction completes

The consolidation interval is 5 seconds. A 100-second eviction blocks 20 consolidation cycles.

### Problem 3: Slow NFS Deletes

`batch_delete_ranges()` in `disk_cache.rs` uses synchronous `std::fs::remove_file()` in a sequential loop. Each NFS delete operation has ~10-50ms latency. For 1594 ranges, that's 16-80 seconds just for file deletes, plus `std::fs::metadata()` calls for each file to get size before deletion.

The per-object loop in `perform_eviction_with_lock()` is also sequential — objects are evicted one at a time, each requiring lock acquisition, metadata read, file deletes, metadata write, and lock release.

### Proposed Fix: Decouple Eviction from Consolidation

Move eviction to a separate `tokio::spawn` task so it runs concurrently with consolidation instead of blocking it.

Changes to `run_consolidation_cycle()`:
- Replace the synchronous `maybe_trigger_eviction()` call with a non-blocking spawn
- The consolidation cycle completes and releases the global lock immediately
- Eviction runs independently, acquiring only the global eviction lock (already exists)

Changes to `maybe_trigger_eviction()`:
- Spawn eviction as a detached task: `tokio::spawn(async move { cache_manager.enforce_disk_cache_limits_skip_consolidation().await })`
- Return immediately after spawning (no bytes_evicted return value needed)
- Use an `AtomicBool` flag to prevent multiple concurrent eviction spawns

This eliminates problem 2 entirely. Consolidation cycles continue every 5 seconds regardless of eviction duration. Delta files are collected, size state is updated, and journal entries are processed while eviction runs in the background.

### Proposed Fix: Parallel NFS Deletes

Change `batch_delete_ranges()` to use parallel file operations instead of sequential `std::fs::remove_file()`.

Two levels of parallelism, both independent:

Level 1 — parallel file deletes within each object:
- Use `tokio::fs::remove_file` with `futures::stream::buffer_unordered` for file deletes within `batch_delete_ranges()`
- Delete multiple .bin files concurrently (e.g., 16 at a time)
- Keep the per-object metadata lock — files are deleted in parallel, then metadata is updated once

Level 2 — parallel across objects:
- In `perform_eviction_with_lock()`, process multiple objects concurrently using `buffer_unordered`
- Each object acquires its own per-object lock (different lock files), so no contention between them
- Client requests writing to the same object could contend, but the shorter wall-clock eviction time actually reduces that window vs sequential processing

Both levels can be combined. Level 1 addresses the main bottleneck (sequential NFS deletes within a single object). Level 2 adds throughput when evicting ranges across many objects.

Estimated improvement: With 16-way parallelism on file deletes, 1594 ranges at 50ms each drops from ~80 seconds to ~5 seconds.

### Proposed Fix: Eviction Early Exit (Optional)

Add an early exit check in the eviction loop to stop once enough bytes have been freed:

```rust
for (cache_key, ranges) in &grouped_candidates {
    if total_bytes_freed >= bytes_to_free {
        break;  // already freed enough
    }
    // ... existing eviction logic
}
```

This is a minor optimization since `group_candidates_by_object()` already limits candidate selection. The main benefit is avoiding unnecessary work when the first few objects free more bytes than expected (e.g., due to filesystem block alignment making actual file sizes larger than `compressed_size`).

### Implementation Priority

1. Decouple eviction from consolidation (fixes problem 2, reduces impact of problem 1)
2. Parallel NFS deletes (fixes problem 3)
3. Early exit check (minor optimization for problem 1)

All three changes are independent and can be implemented incrementally. The decoupling is the highest priority because it eliminates the consolidation blocking regardless of eviction speed.

### Size Tracking Implications

Decoupling eviction from consolidation does not affect size tracking correctness. The accumulator subtract operations happen inside `perform_eviction_with_lock()` after each batch eviction — this is independent of whether eviction runs inside or outside the consolidation cycle. The accumulator is thread-safe (`AtomicI64`), and delta file flushing happens at the start of each consolidation cycle regardless of eviction state.

One consideration: if eviction runs concurrently with consolidation, the consolidator may collect a delta file that includes subtract operations from an in-progress eviction. This is correct behavior — the subtracted bytes are already deleted from disk, so the size state should reflect them immediately.

### Implementation (v1.1.35)

All three proposed fixes were implemented in v1.1.35:

1. **Decoupled eviction from consolidation** — `maybe_trigger_eviction()` spawns eviction as a detached `tokio::spawn` task and returns immediately. An `Arc<AtomicBool>` guard prevents concurrent spawns, reset via `scopeguard` on all exit paths.
2. **Parallel NFS file deletes** — `batch_delete_ranges()` uses `tokio::fs::remove_file` with `buffer_unordered(32)` for concurrent file deletes within each object. `perform_eviction_with_lock()` processes up to 8 objects concurrently via `buffer_unordered(8)`.
3. **Early exit check** — The eviction aggregation loop breaks once `total_bytes_freed >= bytes_to_free`, skipping remaining objects.

### v1.1.35 Test Results (2026-02-08)

3-instance deployment (Native-1, Native-3, Native-4) with fresh cache. Download test filled cache to ~1.7 GiB against 1.5 GiB limit.

#### Size Tracking Accuracy

| Metric | Value |
|--------|-------|
| Tracked (size_state.json) | 1,284,946,339 bytes (1.20 GiB) |
| Actual (du -sb ranges/) | 1,405,772,787 bytes (1.31 GiB) |
| Gap | ~120 MiB (tracked < actual) |
| Range file count | 2,919 |

Investigation revealed the gap is NOT a compressed_size vs file size discrepancy. The accumulator net across all 3 instances (1,405,314,035) matches the metadata compressed_size_sum exactly. The 120 MiB gap is between the accumulator net and size_state.json — delta collection is losing data. See "Size Tracking Gap Root Cause" below.

#### Eviction Performance

The decoupling from consolidation is working — `eviction_triggered=true` with `bytes_evicted=0` confirms the spawned task pattern. "Background eviction completed" messages confirm `tokio::spawn` path.

| Instance | Eviction Duration | Ranges Evicted | Keys Evicted | Bytes Freed |
|----------|-------------------|----------------|--------------|-------------|
| Native-1 | ~148s (19:40:36 → 19:43:04) | 1,711 | 14 | 503.18 MiB |
| Native-3 | ~85s (19:43:19 → 19:44:44) | 1,803 | 8 | 358.83 MiB |

#### Consolidation Cycle Durations

| Instance | Timestamp | Duration | Entries | Notes |
|----------|-----------|----------|---------|-------|
| Native-1 | 19:32:22 | 33,122ms | 205 | First consolidation with journal backlog |
| Native-3 | 19:41:02 | 33,085ms | 278 | During active downloads |
| Native-3 | 19:43:16 | 133,818ms | 1,200 | Processing eviction Remove entries |
| Native-3 | 19:43:19 | 2,822ms | 2,890 | Normal after eviction journal processed |

#### Observed Problems

1. **Eviction still takes 85-148 seconds** — Deleting 1700+ range files over NFS with parallel I/O. The `buffer_unordered(32)` for files and `buffer_unordered(8)` for objects helps, but NFS latency at scale remains the bottleneck. Each `batch_delete_ranges` holds the per-object metadata lock for the entire parallel delete operation.

2. **Consolidation journal processing is slow** — 133 seconds to process 1,200 eviction Remove entries. The consolidator holds the global lock during this time, blocking other instances from consolidating and causing size tracking drift.

3. **Download slowdown during eviction** — User reported noticeable slowdown during eviction. Root cause is NFS contention: eviction deletes and new writes compete for NFS I/O bandwidth. Per-object metadata locks held during file deletion may also block concurrent writes to the same objects.

4. **Repeated "Disk cache over limit" after eviction** — After eviction completes, the tracked size doesn't immediately reflect freed bytes because the accumulator subtract hasn't been consolidated yet. This causes the next consolidation cycle to see the cache as still over limit and attempt eviction again (blocked by the guard).

### Proposed Improvements (v1.1.36)

#### 1. Reduce Per-Object Lock Hold Time During Eviction

Currently `batch_delete_ranges()` holds the metadata lock for the entire operation: read metadata → delete files in parallel → update metadata. The file deletion phase (NFS I/O) dominates the lock hold time.

Proposed change: Read metadata and identify files to delete under the lock, release the lock, delete files in parallel (no lock), re-acquire the lock, update metadata. This lets writes to the same object proceed during file deletion.

Risk: Another operation could modify metadata between release and re-acquire. Mitigation: re-read metadata after re-acquiring and reconcile (only remove ranges that still exist in metadata).

#### 2. Batch Eviction Journal Writes

Currently eviction writes one Remove journal entry per evicted range (1,711 entries in the test). The consolidator processes these one-at-a-time, taking 133 seconds.

Proposed change: Write eviction Remove entries in batches (e.g., one batch per object instead of one per range). The consolidator can process a single batch entry that removes multiple ranges, reducing journal I/O and consolidation processing time.

#### 3. Incremental Accumulator Subtract

Currently all accumulator subtract operations happen inside `perform_eviction_with_lock()` after each object's batch eviction. The consolidated size doesn't reflect freed bytes until the next consolidation cycle collects the delta.

Proposed change: Flush the accumulator delta immediately after each object's eviction completes (or after all eviction completes), so the next consolidation cycle sees the correct size and doesn't re-trigger eviction.

#### 4. Eviction I/O Throttling During Active Downloads

Eviction and downloads compete for NFS bandwidth. During heavy download activity, eviction's parallel file deletes add significant NFS load.

Proposed change: Monitor active download count. When downloads are active, reduce eviction concurrency (e.g., `OBJECT_CONCURRENCY_LIMIT` from 8 to 2, `FILE_CONCURRENCY_LIMIT` from 32 to 8). This prioritizes download throughput over eviction speed.

#### 5. Consolidation Journal Processing Optimization

The consolidator processes journal entries sequentially, reading and updating metadata files one entry at a time. With 1,200+ eviction entries, this is slow.

Proposed change: Group journal entries by cache_key before processing. Process all entries for a single object in one metadata read-modify-write cycle instead of one cycle per entry. This reduces NFS metadata I/O proportional to the number of unique objects rather than the number of ranges.

#### 6. Eliminate NFS Stale Reads in Delta Collection

The 120 MiB size tracking gap is caused by NFS stale reads during delta file collection.

Architecture: Every instance runs `run_consolidation_cycle()` every 5 seconds. Each cycle starts by flushing the local accumulator to a per-instance delta file (additive read-modify-write via `write_delta_file`). Then the instance attempts the global consolidation lock. Only the lock holder proceeds to collect all instances' delta files, sum them, delete them, and apply the sum to `size_state.json`. Instances that don't get the lock return after flushing.

The result: all 3 instances write their delta files every 5 seconds. One instance (the consolidator) reads and deletes all 3 files. The consolidator and the other instances are on different NFS clients.

The NFS stale read race (cross-instance):

1. Instance I (on machine M1) flushes, writes delta file = 500 (additive: read 400, add 100, write 500)
2. Instance I flushes again 5s later, writes delta file = 700 (read 500, add 200, write 700)
3. Consolidator C (on machine M2) reads I's delta file — NFS client cache on M2 returns stale content = 500
4. Consolidator deletes the file
5. Instance I flushes again — file is gone, writes just the new delta (e.g., 150)
6. 200 bytes permanently lost (the delta between stale read 500 and actual value 700)

This race only affects cross-instance reads. The consolidator's own delta file is written and read by the same NFS client, so stale reads are unlikely (the rename in `write_delta_file` invalidates the local cache entry). The local TOCTOU race (flush overlapping with collect on the same instance) cannot happen because flush and collect are sequential in the same async task.

With 5-second flush intervals and 19 consolidation cycles, these cross-instance stale read losses accumulate to 120,367,696 bytes (~4.7% of 2.56 GiB total adds).

Evidence:

| Metric | Value |
|--------|-------|
| Accumulator net (sum of all add - subtract across 3 instances) | 1,405,314,035 |
| Metadata compressed_size_sum (ground truth) | 1,405,314,035 |
| size_state.json total_size | 1,284,946,339 |
| Delta collection loss | 120,367,696 (8.6% of final size) |
| Actual disk usage (du) | 1,405,772,787 |
| du vs metadata gap (filesystem overhead) | 458,752 (negligible) |

The accumulator arithmetic is correct. Every add and subtract is accounted for. The loss occurs between flush-to-file and collect-from-file.

Three candidate fixes, each with tradeoffs:

**Option A: Append-only delta files.** Each flush creates a new uniquely-named file (e.g., `delta_{instance}_{sequence}.json`) instead of read-modify-writing a single file. The consolidator reads and deletes all files for each instance. No read-modify-write means no stale read of accumulated values — each file contains exactly one flush's delta. Downside: many small files on NFS (one per flush per instance, ~12/minute/instance = ~36/minute total). NFS `readdir` on a directory with many small files can be slow. Mitigation: the consolidator deletes files after reading, so the directory stays bounded by the number of flushes between collections (~3 files per instance per cycle = ~9 total).

**Option B: Consolidator applies own delta directly from memory.** The consolidating instance already flushes before collecting. Instead of flush-to-file then read-from-file, it could skip the file for its own delta and apply it directly to size_state. Since the race only affects cross-instance reads, this doesn't fix the problem — the consolidator's own file is already safe (same NFS client). This option has no impact on the observed bug.

**Option C: Eliminate additive read-modify-write.** Instead of reading the existing file and adding to it, each flush overwrites the file with just the new delta. The consolidator reads the file, then resets it to zero (instead of deleting). This eliminates the stale read problem because the consolidator doesn't need to read the accumulated value — it reads whatever is there and resets to zero. But this reintroduces the original race that additive writes were designed to prevent: if the instance flushes between the consolidator's read and reset, the new delta is overwritten with zero.

**Option D: Consolidator skips delta files entirely — uses journal-derived size deltas.** The consolidator already processes journal entries and can calculate size deltas from Add/Remove entries via `calculate_size_delta()`. Instead of the accumulator → delta file → collect pipeline, derive size changes from the journal entries that are already being consolidated. The accumulator becomes a fast estimate for eviction decisions only, not the source of truth for size_state. Downside: this was the original approach before the accumulator was introduced. It was replaced because journal-derived deltas lag behind actual writes (the journal entry is written after the range file, and consolidated later). The accumulator was introduced specifically to close this gap.

**Option E: Append-only with batched cleanup.** Hybrid of Option A with a twist: each flush appends a line to a per-instance log file (not a separate file per flush). The consolidator reads the entire log, sums all deltas, and truncates the file. This avoids the many-small-files problem of Option A. The stale read risk is reduced because the consolidator reads the whole file — even if it gets a slightly stale version, it only misses the most recent append, not accumulated value. Downside: file truncation on NFS has its own atomicity concerns. An append followed by a truncate from a different client could lose data.

**Option F: Sequence-numbered delta files with acknowledgment.** Each flush writes to a sequentially-numbered file (`delta_{instance}_{seq}.json`). The consolidator reads all files, records the highest sequence number it processed, and deletes only files up to that sequence. The instance checks the acknowledgment before reusing sequence numbers. This is essentially Option A with explicit coordination. More complex but eliminates all races. Downside: requires shared state (the acknowledgment) which itself needs NFS coordination.

Recommendation: Option A is the cleanest fix. The concern about many small files is mitigated by the math: with 5-second flush intervals and 5-second consolidation intervals, each instance produces ~1 file between collections. The consolidator reads and deletes ~3 files per cycle. The directory never grows beyond ~6-9 files (3 instances × 1-3 pending flushes). NFS `readdir` on 9 files is negligible. The implementation is straightforward: change `write_delta_file` to write a new uniquely-named file each time (no read of existing file), and change `collect_and_apply_deltas` to process all `delta_*.json` files (it already does this).

#### Priority

1. Eliminate NFS stale reads via append-only delta files (fixes the 120 MiB / 8.6% size tracking gap)
2. Batch eviction journal writes + consolidation grouping (fixes the 133s consolidation bottleneck)
3. Reduce per-object lock hold time (reduces write contention during eviction)
4. Incremental accumulator subtract (prevents false re-trigger of eviction)
5. Eviction I/O throttling (reduces download impact, lower priority)

### Implementation (v1.1.36)

Implemented Option A (append-only delta files) to fix the NFS stale read race in delta collection.

Changes to `SizeAccumulator` in `src/journal_consolidator.rs`:
- Replaced `delta_file_path: PathBuf` field with `size_tracking_dir: PathBuf` and `flush_sequence: AtomicU64`
- `write_delta_file()` now creates a new uniquely-named file per flush: `delta_{instance}_{seq}.json`
- No read of existing file — each file contains exactly one flush's delta value
- Eliminates the additive read-modify-write that was vulnerable to NFS stale reads

No changes to `collect_and_apply_deltas()` — it already iterates all `delta_*.json` files and deletes after reading.

`reset_all_delta_files()` unchanged — already matches `delta_*.json` pattern and deletes all.

Deployed to 3-instance cluster (Native-1, Native-3, Native-4) with fresh cache and cleared logs. Awaiting download test to measure size tracking accuracy.

### v1.1.36 Test Results (2026-02-08)

3-instance deployment with fresh cache. Download test filled cache past 1.5 GiB limit.

#### Delta File Mechanism

The append-only delta files work correctly. Sequence-numbered files (`delta_{instance}_{seq}.json`) are created on flush, collected by the consolidator, and deleted promptly. Zero delta files lingering between cycles. No regression from the file-per-flush approach.

#### Consolidation Performance (pre-existing, not a v1.1.36 regression)

Consolidation cycle durations during active downloads:

| Duration | Entries | Keys | Notes |
|----------|---------|------|-------|
| 148ms | 13 | 1 | Light load |
| 580ms | 153 | 2 | Normal |
| 1,691ms | 88 | 4 | Moderate NFS latency |
| 1,902ms | 94 | 10 | Moderate |
| 7,992ms | 212 | 1 | NFS latency spike |
| 8,199ms | 333 | 7 | Heavy journal backlog |
| 17,207ms | 91 | 3 | Severe NFS contention |

The 17-second cycle with only 91 entries (~190ms/entry) indicates NFS latency spikes, not volume. Stale journal lock cleanup messages ("Cleaned up 1-4 stale journal lock files") confirm cross-instance NFS lock contention during consolidation. This is the same bottleneck observed in v1.1.35 — consolidation grouping (priority #2) would address it.

#### Size Tracking Accuracy

Data collected after download test completed and all consolidation cycles settled (current_size stable at 993,823,257).

| Metric | Value | Notes |
|--------|-------|-------|
| size_state.json total_size | 993,823,257 | Shared across all 3 instances via NFS |
| Accumulator total net | 993,823,257 | Sum of per-instance (adds - subtracts) |
| du -sb /mnt/efs/cache/ | 996,728,196 | Actual disk usage including metadata/journals |
| Consolidation count | 47 | Total consolidation cycles |

Per-instance accumulator breakdown:

| Instance | Adds | Subtracts | Net |
|----------|------|-----------|-----|
| Native-1 | 797,287,116 | 358,972,244 | 438,314,872 |
| Native-3 | 700,631,518 | 874,072,558 | -173,441,040 |
| Native-4 | 1,001,510,198 | 272,560,773 | 728,949,425 |
| Total | 2,499,428,832 | 1,505,605,575 | 993,823,257 |

Gap analysis:

| Comparison | Gap | Percentage |
|------------|-----|------------|
| accumulator net vs size_state | 0 | 0.00% |
| du vs size_state | 2,904,939 | 0.29% |

The accumulator net matches size_state exactly — zero gap. The append-only delta files completely eliminated the NFS stale read race that caused the 120 MiB (8.6%) gap in v1.1.35.

The remaining 2.9 MiB (0.29%) gap between `du` and `size_state` is expected filesystem overhead: metadata JSON files, journal files, lock files, size_tracking directory, and EFS directory entries. These are not tracked by the size accumulator (which only tracks range data file sizes).

#### v1.1.35 vs v1.1.36 Comparison

| Metric | v1.1.35 | v1.1.36 | Change |
|--------|---------|---------|--------|
| accumulator net vs size_state | 120,367,696 (8.6%) | 0 (0.00%) | Eliminated |
| du vs size_state | 120,367,696 (8.6%) | 2,904,939 (0.29%) | 97.6% reduction |
| Root cause | NFS stale reads on read-modify-write delta files | N/A — fixed | Append-only delta files |

The append-only delta file approach (one file per flush, no read of existing files) is confirmed effective at eliminating the cross-instance NFS stale read race condition.

#### Over-Eviction Analysis (v1.1.36)

Despite accurate size tracking, the cache dropped to 62% of max (993 MiB / 1.5 GiB) — well below the 80% eviction target. Four eviction rounds fired across 3 instances:

| Instance | Start Time | Usage at Start | to_free | Freed | Duration |
|----------|------------|----------------|---------|-------|----------|
| Native-4 | 20:59:29 | 96.7% | 257 MiB | 260 MiB | ~35s |
| Native-3 | 21:00:04 | 111.3% | 481 MiB | 487 MiB | ~41s |
| Native-3 | 21:00:47 | 102.1% | 339 MiB | 347 MiB | ~41s |
| Native-1 | 21:01:35 | 102.1% | 339 MiB | 359 MiB | ~90s |
| **Total** | | | **1,416 MiB** | **1,453 MiB** | |

Total evicted: 1,453 MiB — nearly the entire 1.5 GiB cache. Each instance read a stale `size_state` that didn't reflect other instances' recent evictions. The `eviction_in_progress` guard is per-instance (in-memory `AtomicBool`), so it doesn't prevent cross-instance concurrent eviction.

The 111.3% usage seen by Native-3 at 21:00:04 is inflated — Native-4 had just freed 260 MiB but its accumulator subtract hadn't been flushed/collected yet. Native-3's second eviction at 21:00:47 shows the same pattern: stale size_state triggers unnecessary eviction.

Root causes:
1. No cross-instance eviction coordination — multiple instances evict simultaneously based on stale size data
2. Accumulator subtract from eviction isn't flushed until the next consolidation cycle (up to 5 seconds later)
3. Consolidation cycles take 7-62 seconds during active downloads, further delaying size_state updates

### Proposed Improvements (v1.1.37)

#### Priority 1: Consolidation Journal Grouping

Consolidation processes cache keys sequentially, each requiring per-key NFS lock acquire, metadata read, entry apply, metadata write, lock release. With NFS latency spikes, 91 entries took 17 seconds (190ms/entry). The global consolidation lock is held for the entire cycle.

Fix: process multiple cache keys concurrently within a single consolidation cycle using `buffer_unordered(4)`. Per-key locks are independent — no contention between keys. Reduces wall-clock consolidation time proportional to NFS latency variance (fast keys don't wait for slow keys).

#### Priority 2: Cross-Instance Eviction Coordination

The global eviction lock file infrastructure already exists (`eviction_lock_timeout` config). Use it to serialize eviction across instances. Before starting eviction, acquire the global eviction lock. After eviction completes and the accumulator delta is flushed, release it. The second instance re-reads size_state and may find eviction is no longer needed.

#### Priority 3: Immediate Accumulator Flush After Eviction

After `perform_eviction_with_lock()` completes all subtract operations, immediately call `size_accumulator.flush()`. Currently the delta sits in memory until the next consolidation cycle's flush step (up to 5 seconds). Combined with Priority 2, this ensures the next instance to check size_state sees the correct post-eviction size.

#### Priority 4: Reduce SIZE_ACCUM Logging Verbosity

Per-operation `SIZE_ACCUM add` and `SIZE_ACCUM subtract` logs at INFO level produce thousands of lines per download. Size tracking accuracy is confirmed (0.00% gap). Reduce to DEBUG. Keep `flush`, `collect`, and `collect_total` at INFO.

### Implementation (v1.1.37)

Implemented Priorities 1-4:

1. **Parallel consolidation key processing** — `run_consolidation_cycle()` processes cache keys with `buffer_unordered(4)` instead of sequentially. Per-key locks are independent, so no contention between concurrent key processing.

2. **Re-read size after eviction lock** — `enforce_disk_cache_limits_internal()` re-reads `current_size` from the consolidator after acquiring the global eviction lock. If another instance already evicted and the cache is now below the trigger threshold, eviction is skipped.

3. **Immediate accumulator flush after eviction** — After `perform_eviction_with_lock()` completes, calls `consolidator.size_accumulator().flush().await` before releasing the eviction lock. The next instance to check size_state sees the correct post-eviction value.

4. **Reduced SIZE_ACCUM logging** — `add()` and `subtract()` in `SizeAccumulator` changed from `info!` to `debug!`. `flush`, `collect`, and `collect_total` remain at INFO.

### v1.1.37 Test Results (2026-02-08)

3-instance deployment (Native-1, Native-3, Native-4) with fresh cache. Cache was populated from previous v1.1.36 test data still on EFS. Consolidation ran immediately after startup, processing existing journal entries.

#### Size Tracking Accuracy

| Metric | Value |
|--------|-------|
| size_state.json total_size | 1,118,033,549 bytes (1.04 GiB) |
| du -sb ranges/ | 1,118,531,213 bytes |
| Gap (du - tracked) | 497,664 bytes (0.04%) |

The 497 KB gap is filesystem block alignment overhead — effectively perfect tracking. Consistent with v1.1.36's 0.00% accumulator-vs-size_state gap.

#### Eviction Behavior

Native-4 eviction observed: freed 517.22 MiB (1,401 ranges from 15 keys), landing at 79.8% usage (1.20 GiB / 1.50 GiB). This is close to the 80% target — the re-read-size-after-lock and immediate-flush improvements are working as intended.

Native-1 consolidation shows accumulator deltas being absorbed correctly: `-166,232,153` then `-912,700,090`, tracking size down from 2.03 GiB to 1.12 GiB across two cycles.

#### Consolidation Performance

Parallel key processing (`buffer_unordered(4)`) is active. Consolidation cycles processing 19 keys with 4,469 entries completed in 5,193ms. A second cycle with 3 keys and 132 entries completed in 1,404ms. These are reasonable for NFS-backed operations.

#### v1.1.35 → v1.1.36 → v1.1.37 Comparison

| Metric | v1.1.35 | v1.1.36 | v1.1.37 |
|--------|---------|---------|---------|
| accumulator vs size_state gap | 120 MiB (8.6%) | 0 (0.00%) | 0 (0.04%) |
| Over-eviction | Not measured | 62% of max (38% below target) | 79.8% of max (0.2% below target) |
| Root fix | N/A | Append-only delta files | Re-read size + immediate flush |
