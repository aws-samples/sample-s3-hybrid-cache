# Real-World Cache Test Implementation

## Overview

Implemented comprehensive real-world integration tests for the S3 proxy cache system using actual AWS S3 downloads. These tests validate cache behavior with a 100MB file to ensure cache lookup, storage, and retrieval work correctly in production scenarios.

## Files Created

### 1. `tests/real_world_cache_test.rs`
Rust integration test that:
- Starts the S3 proxy with sudo on port 80
- Clears cache before testing
- Downloads a 100MB file from S3 (cache miss)
- Downloads the same file again (cache hit)
- Verifies 100% cache hit rate with no range merge errors
- Analyzes proxy logs for cache behavior
- Validates file integrity

**Key Features**:
- Automatic proxy lifecycle management (start/stop)
- Health check waiting with timeout
- Comprehensive log analysis
- Cache statistics calculation
- File comparison verification

### 2. `tests/manual_cache_test.sh`
Bash script for manual testing and debugging:
- Easier to run and debug than Rust test
- Provides colored output for better readability
- Shows detailed progress at each step
- Useful for troubleshooting cache issues
- Can be run independently

**Key Features**:
- Prerequisite checking (sudo, AWS CLI, credentials)
- Automatic cleanup on exit
- Detailed log analysis
- Cache file verification
- File comparison

### 3. `tests/REAL_WORLD_CACHE_TEST_README.md`
Comprehensive documentation including:
- Prerequisites and setup instructions
- How to run the tests
- Test flow diagrams
- Expected results
- Troubleshooting guide
- Performance expectations
- Extension examples

## Test Scenarios

### Test 1: 100MB File Download
```rust
test_real_world_cache_with_100mb_file()
```

**Flow**:
1. Clear cache
2. Start proxy on port 80
3. Download 100MB file (first time - cache miss)
4. Verify S3 requests were made
5. Download same file (second time - cache hit)
6. Verify 100% cache hit rate
7. Verify no S3 requests on second download
8. Verify no range merge errors
9. Compare file sizes

**Expected Results**:
- First download: Cache miss, S3 requests made
- Second download: 100% cache hit, no S3 requests
- Files identical in size
- No range merge errors

### Test 2: Range Request Handling
```rust
test_real_world_cache_with_range_requests()
```

**Flow**:
1. Download first 10MB with range request
2. Download full 100MB file
3. Verify first 10MB served from cache
4. Verify remaining 90MB fetched from S3

**Expected Results**:
- First 10MB: Cache hit
- Remaining 90MB: Cache miss, S3 fetch
- Intelligent range merging

## Running the Tests

### Rust Integration Test

```bash
# Run all real-world tests
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored

# Run specific test
sudo -E cargo test --test real_world_cache_test test_real_world_cache_with_100mb_file -- --nocapture --ignored
```

### Manual Shell Script

```bash
# Run manual test
sudo -E ./tests/manual_cache_test.sh
```

## Prerequisites

### 1. Sudo Access
Required to bind to port 80:
```bash
sudo -v
```

### 2. AWS CLI
```bash
# macOS
brew install awscli

# Linux
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Configure
aws configure
```

### 3. S3 Access
- Bucket: `egummett-testing-source-1`
- Object: `bigfiles/100MB`
- Region: `eu-west-1`

Verify:
```bash
aws s3 ls s3://egummett-testing-source-1/bigfiles/ --endpoint-url http://s3.eu-west-1.amazonaws.com
```

### 4. Dependencies
```bash
cargo build --release
```

## Test Configuration

The tests use a custom configuration optimized for testing:

```yaml
server:
  http_port: 80
  request_timeout: 300s  # 5 minutes for large downloads

cache:
  cache_dir: <temp_dir>/cache
  max_cache_size: 10GB
  get_ttl: ~10 years  # Cache forever for testing
  head_ttl: 60s
  range_merge_gap_threshold: 256KB

logging:
  log_level: debug  # Full debug logging
  access_log_enabled: true

health:
  enabled: true
  port: 8080
```

## Log Analysis

The tests analyze proxy logs for:

### Cache Metrics
- **Cache Hits**: Requests served from cache
- **Cache Misses**: Requests requiring S3 fetch
- **Cache Hit Rate**: Percentage of hits (target: 100%)

### Range Operations
- **Exact Matches**: Requested range exactly matches cached range
- **Partial Overlaps**: Requested range partially overlaps cached range
- **No Overlaps**: Requested range doesn't overlap cached ranges
- **Range Merges**: Operations combining multiple ranges
- **Merge Errors**: Errors during range merging

### S3 Operations
- **S3 Requests**: Total requests made to S3
- **Request Timing**: Duration of S3 operations

## Expected Performance

### First Download (100MB)
- **Duration**: 5-30 seconds (network dependent)
- **S3 Requests**: ~100-200 (chunk-based)
- **Cache Operations**: ~100-200 writes
- **Cache Hit Rate**: 0%

### Second Download (100MB)
- **Duration**: 1-5 seconds (from cache)
- **S3 Requests**: 0
- **Cache Operations**: ~100-200 reads
- **Cache Hit Rate**: 100%

## Troubleshooting

### "This test requires sudo"
```bash
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "AWS CLI failed: Unable to locate credentials"
```bash
aws configure
# Or
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "Proxy failed to start within 30 seconds"
```bash
# Check port 80
sudo lsof -i :80

# Kill process
sudo kill -9 <PID>

# Try again
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

### "Access Denied" to S3 bucket
```bash
# Verify access
aws s3 ls s3://egummett-testing-source-1/bigfiles/

# Or modify test to use your own bucket
# Edit tests/real_world_cache_test.rs:
# const TEST_BUCKET: &str = "your-bucket";
# const TEST_OBJECT: &str = "your-object";
```

### Port 80 Permission Denied
```bash
# Linux: Allow binding to privileged ports
sudo setcap 'cap_net_bind_service=+ep' target/release/s3-proxy

# Or run with sudo (recommended)
sudo -E cargo test --test real_world_cache_test -- --nocapture --ignored
```

## Success Indicators

✅ **First download completes**
- File downloaded successfully
- S3 requests logged
- Cache files created

✅ **Second download shows 100% cache hit**
- Cache hit rate ≥ 99%
- Zero new S3 requests
- No range merge errors

✅ **Files are identical**
- Same file size
- Data integrity maintained

## Failure Indicators

❌ **Cache hit rate < 99% on second download**
- Indicates cache lookup bug
- Check logs for cache key mismatches
- Verify sharded path construction

❌ **Range merge errors detected**
- Indicates range merging issues
- Check logs for merge details
- Verify range overlap detection

❌ **S3 requests on second download**
- Indicates cache not being used
- Check cache TTL settings
- Verify cache files exist

## Integration with Task 7

This test complements the diagnostic tests from Task 7:

**Task 7 Tests** (Unit/Integration):
- Test cache lookup logic in isolation
- Use temporary test data
- Fast execution (< 1 second)
- No external dependencies

**Real-World Tests** (End-to-End):
- Test complete proxy with real S3
- Use actual 100MB file
- Realistic execution (~30-60 seconds)
- Requires AWS credentials and sudo

Together, they provide comprehensive coverage:
1. Task 7 validates cache lookup logic
2. Real-world tests validate production behavior

## Extending the Tests

### Test Different File Sizes
```rust
const TEST_OBJECT: &str = "bigfiles/1GB";
```

### Test Different Buckets
```rust
const TEST_BUCKET: &str = "your-bucket";
const TEST_OBJECT: &str = "path/to/object";
```

### Test Concurrent Downloads
```rust
use std::thread;

let handles: Vec<_> = (0..10)
    .map(|i| {
        thread::spawn(move || download_with_aws_cli(&config, i))
    })
    .collect();
```

### Test Range Requests
```rust
// Download specific byte ranges
aws s3api get-object \
    --bucket ${TEST_BUCKET} \
    --key ${TEST_OBJECT} \
    --range bytes=0-10485759 \
    output.bin
```

## Related Files

- `tests/cache_lookup_diagnostic_test.rs` - Unit tests for cache lookup
- `.kiro/specs/cache-lookup-debug/` - Spec documents
- `CACHE_LOOKUP_DIAGNOSTIC_ANALYSIS.md` - Task 7 analysis
- `TASK_7_DIAGNOSTIC_TEST_SUMMARY.md` - Task 7 summary

## Benefits

### For Development
- Validates cache behavior with real-world scenarios
- Catches issues that unit tests might miss
- Provides confidence in production deployment

### For Debugging
- Manual script for easy troubleshooting
- Detailed log analysis
- Step-by-step progress tracking

### For CI/CD
- Can be integrated into CI pipeline (with AWS credentials)
- Automated validation of cache behavior
- Regression testing for cache changes

## Limitations

### Requires External Resources
- AWS credentials
- S3 access
- Network connectivity

### Requires Privileges
- Sudo access for port 80
- May not work in all CI environments

### Slower Execution
- Downloads 100MB file (twice)
- Takes 30-60 seconds to complete
- Not suitable for rapid iteration

### Solutions
- Use `#[ignore]` attribute (only run when needed)
- Provide manual script for local testing
- Keep unit tests fast for development
- Run real-world tests in CI/staging

## Future Enhancements

### Additional Test Scenarios
- [ ] Test with multiple file sizes (1MB, 10MB, 100MB, 1GB)
- [ ] Test with concurrent downloads
- [ ] Test with different cache configurations
- [ ] Test cache eviction behavior
- [ ] Test multi-instance coordination

### Enhanced Analysis
- [ ] Parse access logs for detailed metrics
- [ ] Generate performance reports
- [ ] Compare cache efficiency across runs
- [ ] Track cache hit rates over time

### CI Integration
- [ ] Add GitHub Actions workflow
- [ ] Use AWS credentials from secrets
- [ ] Generate test reports
- [ ] Upload artifacts (logs, metrics)

## Conclusion

The real-world cache tests provide comprehensive validation of the S3 proxy cache system using actual AWS S3 downloads. Combined with the diagnostic tests from Task 7, they ensure the cache works correctly both in isolation and in production scenarios.

The tests are designed to be:
- **Easy to run**: Simple commands with clear instructions
- **Easy to debug**: Manual script and detailed logging
- **Easy to extend**: Modular design for additional scenarios
- **Production-ready**: Tests real-world behavior with actual S3

This implementation addresses the requirement to test cache behavior with a real 100MB file download, verifying 100% cache hit on the second download with no range merging mismatches.
