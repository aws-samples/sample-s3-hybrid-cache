# Capacity Check Compression Fix

## Issue

The capacity checking logic in `CacheWriter` was checking against **uncompressed** byte sizes instead of **compressed** byte sizes. This was incorrect because:

1. Data is stored on disk in compressed form (using LZ4)
2. Compressed data is typically 2-3x smaller than uncompressed for text/JSON/XML
3. The capacity check was rejecting requests that would actually fit after compression
4. The actual disk usage is based on compressed size, not uncompressed size

## Root Cause

In `src/cache_writer.rs`, the capacity check was:

```rust
if self.bytes_written + chunk_size > limit {
    // Reject
}
```

But `bytes_written` tracks uncompressed bytes, while the actual disk usage is `bytes_written_compressed`.

## Fix

Changed the capacity checking to use compressed sizes:

### 1. Updated `write_chunk()` method

- Compress data **before** checking capacity
- Check `bytes_written_compressed + compressed_size` against limit
- This ensures we check the actual disk space that will be used

```rust
// Compress first
let data_to_write = compress(data);
let compressed_size = data_to_write.len();

// Check capacity against compressed size
if self.bytes_written_compressed + compressed_size > limit {
    return Err("Capacity exceeded");
}
```

### 2. Updated `check_capacity()` method

Changed from checking uncompressed bytes to compressed bytes:

```rust
pub fn check_capacity(&self, additional_compressed_bytes: u64) -> bool {
    if let Some(limit) = self.capacity_limit {
        self.bytes_written_compressed + additional_compressed_bytes > limit
    } else {
        false
    }
}
```

### 3. Updated Tests

Updated unit tests to account for compressed size checking:

- `test_cache_writer_capacity_limit`: Now uses realistic capacity limits and verifies compressed size tracking
- `test_cache_writer_check_capacity`: Now checks against actual compressed bytes written

## Impact

### Positive

1. **More accurate capacity management**: Capacity limits now reflect actual disk usage
2. **Better cache utilization**: Can cache more objects since we account for compression
3. **Correct behavior**: Aligns capacity checks with actual storage mechanism

### Example

Before fix:
- Content-Length: 10MB (uncompressed)
- Available capacity: 8MB
- Result: **Rejected** (10MB > 8MB)
- Actual compressed size: 3MB (would have fit!)

After fix:
- Content-Length: 10MB (uncompressed)
- Compress to: 3MB
- Available capacity: 8MB
- Result: **Accepted** (3MB < 8MB)
- Actual disk usage: 3MB ✓

## Files Changed

- `src/cache_writer.rs`:
  - Modified `write_chunk()` to check compressed size
  - Modified `check_capacity()` to use `bytes_written_compressed`
  - Updated unit tests to verify compressed size checking

## Testing

All unit tests pass:
```
test cache_writer::tests::test_cache_writer_basic ... ok
test cache_writer::tests::test_cache_writer_capacity_limit ... ok
test cache_writer::tests::test_cache_writer_check_capacity ... ok
test cache_writer::tests::test_cache_writer_multiple_chunks ... ok
test cache_writer::tests::test_cache_writer_discard ... ok
test cache_writer::tests::test_cache_writer_drop_cleanup ... ok
test cache_writer::tests::test_cache_writer_cannot_write_after_commit ... ok
test cache_writer::tests::test_cache_writer_cannot_write_after_discard ... ok
```

## Backward Compatibility

This change improves behavior and does not break any existing functionality:

- Capacity limits are now more permissive (allow more caching)
- No API changes
- No configuration changes needed
- Existing cached data is unaffected

## Related

This fix applies to the signed PUT caching feature implemented in the `signed-put-caching` spec. It ensures that capacity checks accurately reflect the actual disk space used by compressed cache entries.
