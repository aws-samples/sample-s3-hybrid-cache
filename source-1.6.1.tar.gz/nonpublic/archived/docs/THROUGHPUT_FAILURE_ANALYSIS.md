# AWS SDK Throughput Failure Root Cause Analysis

## Status: RESOLVED ✅

**Fix implemented**: December 2025 - Added streaming support for range cache misses.

## Problem Statement

Downloads of large files (500MB) through the proxy were failing with:
```
AWS_ERROR_HTTP_CHANNEL_THROUGHPUT_FAILURE: Http connection channel shut down due to failure to meet throughput minimum
```

This error did NOT occur when bypassing the proxy, and was not due to hardware performance issues.

## Root Cause

The proxy was using a **fully-buffered response architecture** that collected entire responses in memory before sending to clients. For large files, this created a long pause where no data flowed to the client, triggering the AWS SDK's throughput monitoring.

### Evidence

1. **S3 Client buffers entire response** (`src/s3_client.rs:323`):
   ```rust
   let body_bytes = body.collect().await
       .map_err(|e| ProxyError::HttpError(format!("Failed to read response body: {}", e)))?
       .to_bytes();
   ```

2. **HTTP Proxy uses Full<Bytes>** (`src/http_proxy.rs:9`):
   ```rust
   use http_body_util::Full;
   // ...
   async fn handle_request(...) -> Result<Response<Full<Bytes>>, Infallible>
   ```

3. **Response construction waits for complete data**:
   ```rust
   let response = response_builder.body(Full::new(Bytes::from(range_data))).unwrap();
   ```

### Timeline for 500MB File

1. **T+0s**: Client requests 500MB file
2. **T+0s to T+Xs**: S3 client collects all 500MB into memory (no data sent to client)
3. **T+Xs**: Proxy wraps complete 500MB in `Full<Bytes>`
4. **T+Xs**: Data finally starts flowing to client
5. **During step 2**: AWS SDK sees no throughput, triggers `AWS_ERROR_HTTP_CHANNEL_THROUGHPUT_FAILURE`

## Why It Works Without Proxy

Direct S3 connections stream data immediately - bytes flow from S3 → SDK continuously, satisfying throughput requirements.

## Solution: Implement Streaming Responses

The proxy needs to stream response bodies instead of buffering them completely.

### Required Changes

#### 1. S3 Client - Stream Response Bodies

**Current** (`src/s3_client.rs`):
```rust
pub struct S3Response {
    pub status: StatusCode,
    pub headers: HashMap<String, String>,
    pub body: Option<Bytes>,  // ❌ Fully buffered
    pub request_duration: Duration,
    pub connection_ip: IpAddr,
}
```

**Needed**:
```rust
use http_body_util::StreamBody;
use hyper::body::Frame;

pub struct S3Response {
    pub status: StatusCode,
    pub headers: HashMap<String, String>,
    pub body: Option<StreamBody<impl Stream<Item = Result<Frame<Bytes>>>>>,  // ✅ Streaming
    pub request_duration: Duration,
    pub connection_ip: IpAddr,
}
```

#### 2. HTTP Proxy - Return Streaming Bodies

**Current** (`src/http_proxy.rs`):
```rust
async fn handle_request(
    req: Request<hyper::body::Incoming>,
    // ...
) -> Result<Response<Full<Bytes>>, Infallible>  // ❌ Fully buffered
```

**Needed**:
```rust
use http_body_util::combinators::BoxBody;

async fn handle_request(
    req: Request<hyper::body::Incoming>,
    // ...
) -> Result<Response<BoxBody<Bytes, hyper::Error>>, Infallible>  // ✅ Streaming
```

#### 3. Cache Serving - Stream from Disk

Cached data also needs streaming to avoid buffering large files:

```rust
// Instead of reading entire file into Vec<u8>
let data = tokio::fs::read(&path).await?;

// Stream file in chunks
let file = tokio::fs::File::open(&path).await?;
let stream = tokio_util::codec::FramedRead::new(file, tokio_util::codec::BytesCodec::new());
```

### Implementation Complexity

This is a **major architectural change** affecting:

- `src/s3_client.rs` - Response type and body collection
- `src/http_proxy.rs` - All response construction paths
- `src/range_handler.rs` - Range merging and serving
- `src/disk_cache.rs` - Cache reading operations
- `src/cache.rs` - Cache serving logic

**Estimated effort**: 2-3 days of development + testing

### Alternative: Increase AWS SDK Timeout

A **temporary workaround** (not a fix) would be to increase the AWS SDK's throughput timeout:

```rust
// In AWS SDK configuration
.http_client(
    aws_smithy_runtime::client::http::hyper_014::HyperClientBuilder::new()
        .build_https()
        .with_throughput_timeout(Duration::from_secs(300))  // Increase timeout
)
```

This doesn't solve the underlying issue but may allow larger files to complete.

## Solution Implemented

The fix was implemented in `src/http_proxy.rs` by adding streaming support for **complete range cache misses**.

### Key Changes

1. **New function `stream_range_from_s3_with_caching`**: Handles complete cache misses by streaming directly from S3 to the client while caching in the background.

2. **Modified `forward_range_request_to_s3`**: Now detects complete cache misses (when `overlap.cached_ranges.is_empty()`) and routes them to the streaming function instead of buffering.

3. **Uses `TeeStream`**: Simultaneously streams bytes to the client and sends them to a background task for caching.

### How It Works

```
Complete Cache Miss (BEFORE):
S3 → [Buffer entire response] → Client
     ↑ Long pause, no bytes flowing

Complete Cache Miss (AFTER):
S3 → TeeStream → Client (immediate byte flow)
         ↓
    Background Cache Task
```

### What's Still Buffered

- **Partial cache hits**: When some ranges are cached and some need fetching, the data must be merged before sending. This requires buffering.
- **Small responses**: Responses under 1MB are buffered for simplicity.
- **Error responses**: Always buffered.

### Limitations

Partial cache hits still require buffering to merge cached + fetched data. A future optimization could stream cached data first, then stream fetched data, but this adds complexity.

## Testing Strategy

After implementing streaming:

1. Test 500MB file download through proxy
2. Monitor memory usage (should remain constant, not grow with file size)
3. Verify AWS SDK throughput monitoring is satisfied
4. Test range requests with streaming
5. Test cache hits with streaming
6. Performance test: compare latency of first byte (should improve significantly)
