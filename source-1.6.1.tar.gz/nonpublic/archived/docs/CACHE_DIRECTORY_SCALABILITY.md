# Cache Directory Scalability Design

## Problem Statement

Modern filesystems experience significant performance degradation when directories contain more than 10,000 files. With support for tens of millions of cached objects, the current flat directory structure in `objects/` and `ranges/` will become a bottleneck.

### Current Architecture Limitations

```
cache_dir/
├── objects/          # All .meta files (flat structure)
│   ├── bucket%3Aobject1.meta
│   ├── bucket%3Aobject2.meta
│   └── ... (potentially millions of files)
└── ranges/           # All .bin files (flat structure)
    ├── bucket%3Aobject1_0-8388607.bin
    ├── bucket%3Aobject1_8388608-16777215.bin
    └── ... (potentially tens of millions of files)
```

**Challenges:**
- Directory listing operations become O(n) with large n
- Filesystem inode table lookups degrade
- Backup and maintenance operations slow dramatically
- Risk of hitting filesystem limits (ext4: ~10M files per directory)
- Cannot clean cache on a per-bucket basis
- Bucket name repeated in every filename (wasted space)

## Design Goals

1. **Scalability**: Support 10M+ objects with 100M+ range files per bucket
2. **Performance**: Maintain O(1) file lookup regardless of cache size
3. **Predictability**: Evenly distribute files across subdirectories within each bucket
4. **Bucket-level operations**: Enable per-bucket cache cleanup, monitoring, and management
5. **Space efficiency**: Eliminate bucket name redundancy in filenames
6. **Simplicity**: Minimize complexity in path resolution and maintenance
7. **Breaking changes acceptable**: No backward compatibility required

## Solution: Bucket-First Hash-Based Sharding

### Overview

Organize cache by bucket first, then use BLAKE3 hash of the object key (not including bucket) to distribute files within each bucket's directory hierarchy. This approach:
- Enables per-bucket cache management and cleanup
- Eliminates bucket name redundancy in filenames
- Provides uniform distribution within each bucket
- Scales to billions of objects per bucket with predictable performance
- Maintains O(1) lookup time

### Architecture

```
cache_dir/
├── objects/
│   ├── my-bucket/              # Bucket name as directory
│   │   ├── 00/                 # Hash of object key (first 2 hex digits)
│   │   │   ├── 000/            # Hash of object key (next 3 hex digits)
│   │   │   │   ├── object1.meta
│   │   │   │   ├── path%2Fto%2Fobject2.meta
│   │   │   │   └── ... (max ~2,500 files)
│   │   │   ├── 001/
│   │   │   ├── 002/
│   │   │   └── ... (4,096 subdirs)
│   │   ├── 01/
│   │   │   ├── 000/
│   │   │   └── ... (4,096 subdirs)
│   │   └── ... (256 L1 dirs)
│   ├── another-bucket/
│   │   ├── 00/
│   │   └── ...
│   └── ...
└── ranges/
    ├── my-bucket/
    │   ├── 00/
    │   │   ├── 000/
    │   │   │   ├── object1_0-8388607.bin
    │   │   │   ├── object1_8388608-16777215.bin
    │   │   │   └── ... (max ~2,500 files)
    │   │   ├── 001/
    │   │   └── ... (4,096 subdirs)
    │   └── ... (256 L1 dirs)
    └── ...
```

### Hash Function Selection

**Chosen: BLAKE3**

Rationale:
- **Speed**: 10x faster than SHA-256, 3x faster than SHA-1
- **Security**: Cryptographically secure (prevents collision attacks)
- **Distribution**: Excellent avalanche properties for uniform distribution
- **Rust Support**: Native Rust implementation with zero-copy operations
- **License**: CC0-1.0 OR Apache-2.0 (fully compatible, no restrictions)
- **Dual Purpose**: Can replace SHA-256 for long key hashing (currently at 200 char threshold)

**License Compatibility:**
- BLAKE3 is triple-licensed: CC0-1.0 (public domain) OR Apache-2.0 OR Apache-2.0 WITH LLVM-exception
- No GPL or copyleft restrictions
- Compatible with existing Apache-2.0 project license
- No attribution requirements under CC0-1.0 option

Alternative considered:
- **SHA-256**: Slower but already in dependency tree (used for long key hashing)
- **xxHash**: Faster but non-cryptographic (vulnerable to collision attacks)
- **FNV-1a**: Simple but poor distribution for similar keys

### Directory Hierarchy Design

**Structure: `{bucket}/XX/YYY/`**

- **Level 0**: Bucket name (S3 bucket)
- **Level 1**: First 2 hex digits of BLAKE3(object_key) - 256 directories per bucket
- **Level 2**: Next 3 hex digits of BLAKE3(object_key) - 4,096 subdirectories per L1
- **Total per bucket**: 1,048,576 leaf directories (256 × 4,096)

**File Types:**
- **Metadata files** (`.meta`): One per object in `objects/{bucket}/XX/YYY/`
- **Range files** (`.bin`): One per cached byte range in `ranges/{bucket}/XX/YYY/`

**Capacity Analysis (per bucket):**

With 10,000 files per directory limit:
- **Maximum total files**: 1,048,576 × 10,000 = 10.5B files (metadata + ranges combined)
- **Optimal total files**: 1,048,576 × 2,500 = 2.6B files (40% safety margin)

**Example: 100M objects per bucket with average 10 byte ranges each:**
- **Metadata files**: 100M objects → 100M `.meta` files in `objects/`
  - Distribution: 100M / 1,048,576 = ~95 `.meta` files per leaf directory
- **Range files**: 100M objects × 10 ranges = 1B byte ranges → 1B `.bin` files in `ranges/`
  - Distribution: 1B / 1,048,576 = ~954 `.bin` files per leaf directory
- **Total files**: 100M + 1B = 1.1B files across both `objects/` and `ranges/`
- **Files per directory**: ~95 in `objects/`, ~954 in `ranges/` (both well under 10K limit)

**Scalability headroom**: 
- Can handle 2.6B objects with 10 ranges each = 26B byte ranges + 2.6B metadata = 28.6B total files
- Or 100M objects with 260 ranges each = 26B byte ranges + 100M metadata = 26.1B total files

**Multi-bucket scalability**: Unlimited buckets, each with independent 10.5B file capacity

**Directory overhead**: 256 + (256 × 4,096) = 1,049,088 directories per bucket (~268 MB in inodes)

### Bucket Name Handling

**S3 Bucket Naming Rules** (per AWS documentation):
- 3-63 characters long
- Lowercase letters, numbers, hyphens, and periods only
- Must start and end with letter or number
- Cannot be formatted as IP address (e.g., 192.168.1.1)
- No uppercase or underscores

**Filesystem Compatibility:**
- All valid S3 bucket names are filesystem-safe (no special characters)
- Periods (`.`) are allowed in S3 but could be problematic in some contexts
- Hyphens (`-`) are safe on all filesystems

**Mitigation Strategy:**
- Use bucket names directly as directory names (no encoding needed)
- S3 bucket naming rules already ensure filesystem safety
- No collision risk (S3 bucket names are globally unique)

**Edge Cases:**
- Buckets with periods: `my.bucket.name` → directory `my.bucket.name/` (safe)
- Buckets with hyphens: `my-bucket-name` → directory `my-bucket-name/` (safe)
- No special handling required

### File Naming Convention

**Format**: `{sanitized_object_key}.{ext}`

**Components:**
- `sanitized_object_key`: Percent-encoded object key (or BLAKE3 hash if >150 chars)
- `ext`: File extension (`.meta`, `.bin`)

**Cache Key Format**: `bucket:object_key`
- Split on first `:` to extract bucket and object key
- Bucket becomes directory name
- Object key (without bucket) is hashed for sharding and used in filename

**Examples:**
```
# Cache key: "my-bucket:object1"
objects/my-bucket/a7/3f2/object1.meta
ranges/my-bucket/a7/3f2/object1_0-8388607.bin

# Cache key: "my-bucket:path/to/object"
objects/my-bucket/d4/7e8/path%2Fto%2Fobject.meta
ranges/my-bucket/d4/7e8/path%2Fto%2Fobject_0-8388607.bin

# Long object key (>150 chars after encoding) uses BLAKE3 hash
# Cache key: "my-bucket:very/long/path/..."
objects/my-bucket/f2/8a9/f28a9c1b3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b.meta
```

**Benefits:**
- **No bucket name in filename**: Saves space, reduces redundancy
- **Per-bucket operations**: `rm -rf cache_dir/objects/my-bucket/` clears entire bucket
- **Cleaner filenames**: Object key without bucket prefix
- **Better organization**: Natural grouping by bucket
- **Monitoring**: Easy to track cache usage per bucket

### Implementation Details

#### Path Resolution Function

```rust
use blake3;

/// Parse cache key into bucket and object key
/// Cache key format: "bucket:object_key"
fn parse_cache_key(cache_key: &str) -> Result<(&str, &str)> {
    cache_key.split_once(':')
        .ok_or_else(|| ProxyError::CacheError(
            format!("Invalid cache key format: {}", cache_key)
        ))
}

pub fn get_sharded_path(
    base_dir: &Path,
    cache_key: &str,
    suffix: &str,
) -> Result<PathBuf> {
    // Parse cache key: "bucket:object_key"
    let (bucket, object_key) = parse_cache_key(cache_key)?;
    
    // Compute BLAKE3 hash of object key (not including bucket)
    let hash = blake3::hash(object_key.as_bytes());
    let hash_hex = hash.to_hex();
    
    // Extract directory levels from hash
    let level1 = &hash_hex[0..2];   // 2 hex digits = 256 directories
    let level2 = &hash_hex[2..5];   // 3 hex digits = 4,096 directories
    
    // Sanitize object key for filename (use hash if too long)
    let filename = sanitize_object_key_for_filename(object_key, suffix);
    
    // Construct path: base_dir/bucket/XX/YYY/filename
    // Bucket name is used directly (S3 naming rules ensure filesystem safety)
    Ok(base_dir
        .join(bucket)
        .join(level1)
        .join(level2)
        .join(filename))
}

fn sanitize_object_key_for_filename(object_key: &str, suffix: &str) -> String {
    use percent_encoding::{utf8_percent_encode, AsciiSet, CONTROLS};
    
    const FRAGMENT: &AsciiSet = &CONTROLS
        .add(b' ').add(b'/').add(b'\\').add(b':')
        .add(b'*').add(b'?').add(b'"').add(b'<')
        .add(b'>').add(b'|').add(b'%');
    
    let sanitized = utf8_percent_encode(object_key, FRAGMENT).to_string();
    
    // Filesystem filename limit is 255 bytes
    // Reserve space for suffix (e.g., "_0-8388607.bin" = ~20 chars)
    let max_base_len = 200;
    
    if sanitized.len() > max_base_len {
        // Use BLAKE3 hash for long object keys (64 hex chars)
        // This replaces the current SHA-256 approach with faster BLAKE3
        let hash = blake3::hash(object_key.as_bytes());
        format!("{}{}", hash.to_hex(), suffix)
    } else {
        format!("{}{}", sanitized, suffix)
    }
}
```

#### Usage Examples

```rust
// Metadata file (short object key)
let meta_path = get_sharded_path(
    &cache_dir.join("objects"),
    "my-bucket:path/to/object",
    ".meta"
)?;
// Result: cache_dir/objects/my-bucket/a7/3f2/path%2Fto%2Fobject.meta

// Range file (short object key)
let range_path = get_sharded_path(
    &cache_dir.join("ranges"),
    "my-bucket:path/to/object",
    "_0-8388607.bin"
)?;
// Result: cache_dir/ranges/my-bucket/a7/3f2/path%2Fto%2Fobject_0-8388607.bin

// Different bucket, same object key - same hash directories
let range_path = get_sharded_path(
    &cache_dir.join("ranges"),
    "other-bucket:path/to/object",
    "_0-8388607.bin"
)?;
// Result: cache_dir/ranges/other-bucket/a7/3f2/path%2Fto%2Fobject_0-8388607.bin
// Note: Same hash (a7/3f2) because object key is the same, but different bucket directory

// Long object key (>200 chars after encoding) - uses BLAKE3 hash as filename
let long_key = "my-bucket:very/long/path/with/many/segments/".to_string() + &"x".repeat(200);
let meta_path = get_sharded_path(
    &cache_dir.join("objects"),
    &long_key,
    ".meta"
)?;
// Result: cache_dir/objects/my-bucket/d4/7e8/d47e8c9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d.meta

// Per-bucket cache cleanup
std::fs::remove_dir_all(cache_dir.join("objects").join("my-bucket"))?;
std::fs::remove_dir_all(cache_dir.join("ranges").join("my-bucket"))?;
```

### Migration Strategy

**Breaking Change Acceptable**: No backward compatibility required.

#### Deployment Approach

**Option 1: Clean Slate (Recommended)**
- Deploy new version with bucket-first sharding
- Cache starts empty and repopulates on demand
- Simplest approach, no migration complexity
- Downtime: None (cache miss = fetch from S3)

**Option 2: Offline Migration**
- Stop proxy instances
- Run migration tool to reorganize cache
- Start proxy instances with new structure
- Downtime: Duration of migration (minutes to hours depending on cache size)

**Option 3: Parallel Cache**
- Deploy new version pointing to new cache directory
- Old cache naturally expires over time
- No migration needed, but uses 2x disk space temporarily
- Downtime: None

#### Migration Tool (Optional)

**Tool**: `cargo run --bin migrate_cache_structure`

**Features:**
- Scans flat directories (`objects/`, `ranges/`)
- Parses cache keys from filenames
- Moves files to bucket-first sharded structure
- Atomic operations (temp file + rename)
- Progress reporting
- Dry-run mode for validation

**Algorithm:**
```rust
async fn migrate_to_bucket_first_structure(
    cache_dir: &Path,
    subdir: &str,
    dry_run: bool,
) -> Result<MigrationStats> {
    let source_dir = cache_dir.join(subdir);
    let mut stats = MigrationStats::default();
    
    for entry in std::fs::read_dir(&source_dir)? {
        let entry = entry?;
        let path = entry.path();
        
        // Skip if already in subdirectory (bucket directory)
        if path.is_dir() {
            continue;
        }
        
        // Extract cache key from filename
        // Old format: "bucket%3Aobject.meta" or "bucket%3Aobject_0-1023.bin"
        let cache_key = extract_cache_key_from_old_filename(&path)?;
        
        // Compute new bucket-first sharded path
        let new_path = get_sharded_path(
            &cache_dir.join(subdir),
            &cache_key,
            extract_suffix_from_filename(&path)?
        )?;
        
        if dry_run {
            println!("Would move: {:?} -> {:?}", path, new_path);
            stats.would_migrate += 1;
        } else {
            // Create parent directories (bucket/XX/YY/)
            if let Some(parent) = new_path.parent() {
                std::fs::create_dir_all(parent)?;
            }
            
            // Atomic move
            std::fs::rename(&path, &new_path)?;
            stats.migrated += 1;
            
            if stats.migrated % 1000 == 0 {
                info!("Migrated {} files", stats.migrated);
            }
        }
    }
    
    Ok(stats)
}

fn extract_cache_key_from_old_filename(path: &Path) -> Result<String> {
    let filename = path.file_stem()
        .and_then(|s| s.to_str())
        .ok_or_else(|| ProxyError::CacheError("Invalid filename".to_string()))?;
    
    // Remove range suffix if present (e.g., "_0-1023")
    let key_part = if let Some(pos) = filename.rfind('_') {
        // Check if this is a range suffix (digits-digits)
        let suffix = &filename[pos+1..];
        if suffix.contains('-') && suffix.split('-').all(|s| s.chars().all(|c| c.is_ascii_digit())) {
            &filename[..pos]
        } else {
            filename
        }
    } else {
        filename
    };
    
    // Decode percent encoding to get original cache key
    urlencoding::decode(key_part)
        .map(|s| s.to_string())
        .map_err(|e| ProxyError::CacheError(format!("Failed to decode filename: {}", e)))
}
```

### Performance Considerations

#### Lookup Performance

**Flat structure (10M files):**
- Directory scan: O(n) = ~10M comparisons
- Inode lookup: O(log n) with B-tree, degraded with fragmentation
- Typical latency: 10-100ms

**Sharded structure (10M files):**
- Hash computation: O(1) = ~1μs (BLAKE3)
- Directory traversal: O(1) = 2 levels
- Inode lookup: O(log 2500) = ~11 comparisons
- Typical latency: <1ms

**Improvement**: 10-100x faster lookups

#### Write Performance

**Additional overhead:**
- Hash computation: ~1μs per operation
- Directory creation: Amortized O(1) (created once per shard)

**Impact**: Negligible (<1% overhead)

#### Space Overhead

**Directory inodes:**
- Flat: 2 directories (objects, ranges)
- Sharded: 2 + (2 × 256) + (2 × 256 × 256) = 131,586 directories

**Inode usage:**
- Typical inode size: 256 bytes
- Total overhead: 131,586 × 256 = ~32 MB

**Impact**: Negligible for modern filesystems

### Alternative Approaches Considered

#### 1. Prefix-Based Sharding

**Approach**: Use first N characters of sanitized cache key

```
objects/
├── bu/
│   └── bucket%3Aobject.meta
└── my/
    └── mybucket%3Aobject.meta
```

**Pros:**
- Simple implementation
- Human-readable directory names
- No hash computation overhead

**Cons:**
- **Poor distribution**: Real-world keys often share prefixes (bucket names)
- **Unpredictable**: Some directories could have millions of files
- **Vulnerable**: Malicious keys could target specific directories
- **Not scalable**: Requires assumptions about key patterns

**Verdict**: ❌ Rejected due to distribution concerns

#### 2. Modulo-Based Sharding

**Approach**: Use `hash(key) % N` for directory selection

```
objects/
├── 0000/
├── 0001/
└── ... (10,000 directories)
```

**Pros:**
- Simple implementation
- Configurable shard count
- Good distribution

**Cons:**
- **Not extensible**: Changing N requires full migration
- **Numeric names**: Less debuggable than hex
- **Single level**: Limits maximum scalability

**Verdict**: ❌ Rejected due to extensibility concerns

#### 3. Date-Based Sharding

**Approach**: Organize by creation date

```
objects/
├── 2024/
│   ├── 11/
│   │   ├── 27/
│   │   │   └── bucket%3Aobject.meta
```

**Pros:**
- Natural organization for time-series data
- Easy to implement time-based cleanup
- Human-readable structure

**Cons:**
- **Uneven distribution**: Hot days create hotspots
- **Lookup requires metadata**: Can't compute path from key alone
- **Not suitable for long-lived cache**: Directories grow indefinitely

**Verdict**: ❌ Rejected due to distribution and lookup concerns

#### 4. Consistent Hashing with Virtual Nodes

**Approach**: Use consistent hashing ring with virtual nodes

**Pros:**
- Excellent for distributed systems
- Handles node addition/removal gracefully
- Proven at scale (Cassandra, DynamoDB)

**Cons:**
- **Overkill**: Single-node filesystem doesn't need rebalancing
- **Complex**: Requires ring management and virtual node mapping
- **Overhead**: Additional metadata and computation

**Verdict**: ❌ Rejected as unnecessarily complex for single-node use case

### Testing Strategy

#### Unit Tests

```rust
#[test]
fn test_hash_distribution() {
    // Generate 100K random keys
    let keys: Vec<String> = (0..100_000)
        .map(|i| format!("bucket:object-{}", i))
        .collect();
    
    // Count files per directory
    let mut distribution: HashMap<String, usize> = HashMap::new();
    for key in &keys {
        let path = get_sharded_path(&PathBuf::from("cache"), key, ".meta");
        let dir = path.parent().unwrap().to_string_lossy().to_string();
        *distribution.entry(dir).or_insert(0) += 1;
    }
    
    // Verify uniform distribution (chi-squared test)
    let expected = keys.len() / 65536;
    let variance: f64 = distribution.values()
        .map(|&count| {
            let diff = count as f64 - expected as f64;
            diff * diff
        })
        .sum::<f64>() / distribution.len() as f64;
    
    // Standard deviation should be low for uniform distribution
    let std_dev = variance.sqrt();
    assert!(std_dev < expected as f64 * 0.1); // Within 10%
}

#[test]
fn test_collision_resistance() {
    // Test similar keys produce different paths
    let keys = vec![
        "bucket:object",
        "bucket:object1",
        "bucket:object2",
        "bucket:objec",
    ];
    
    let paths: HashSet<PathBuf> = keys.iter()
        .map(|k| get_sharded_path(&PathBuf::from("cache"), k, ".meta"))
        .collect();
    
    // All paths should be unique
    assert_eq!(paths.len(), keys.len());
}

#[test]
fn test_long_key_uses_blake3_hash() {
    // Test that long keys use BLAKE3 hash instead of truncation
    let long_key = "bucket:".to_string() + &"x".repeat(250);
    let path = get_sharded_path(&PathBuf::from("cache"), &long_key, ".meta");
    
    let filename = path.file_name().unwrap().to_str().unwrap();
    
    // Should be 64 hex chars (BLAKE3) + .meta extension
    assert_eq!(filename.len(), 64 + 5); // 64 hex + ".meta"
    assert!(filename.chars().take(64).all(|c| c.is_ascii_hexdigit()));
}

#[test]
fn test_short_key_preserves_readability() {
    // Test that short keys remain human-readable
    let key = "bucket:object";
    let path = get_sharded_path(&PathBuf::from("cache"), key, ".meta");
    
    let filename = path.file_name().unwrap().to_str().unwrap();
    
    // Should contain percent-encoded key
    assert!(filename.contains("bucket%3Aobject"));
}

#[test]
fn test_deterministic_hashing() {
    let key = "my-bucket:object";
    let path1 = get_sharded_path(&PathBuf::from("cache/objects"), key, ".meta").unwrap();
    let path2 = get_sharded_path(&PathBuf::from("cache/objects"), key, ".meta").unwrap();
    
    assert_eq!(path1, path2);
}

#[test]
fn test_parse_cache_key() {
    let (bucket, object_key) = parse_cache_key("my-bucket:path/to/object").unwrap();
    assert_eq!(bucket, "my-bucket");
    assert_eq!(object_key, "path/to/object");
    
    // Test with colon in object key
    let (bucket, object_key) = parse_cache_key("my-bucket:object:with:colons").unwrap();
    assert_eq!(bucket, "my-bucket");
    assert_eq!(object_key, "object:with:colons");
    
    // Test invalid format
    assert!(parse_cache_key("invalid-no-colon").is_err());
}

#[test]
fn test_bucket_first_structure() {
    let path = get_sharded_path(
        &PathBuf::from("cache/objects"),
        "my-bucket:object1",
        ".meta"
    ).unwrap();
    
    // Should have bucket as directory level
    assert!(path.to_string_lossy().contains("my-bucket"));
    
    // Filename should not contain bucket name
    let filename = path.file_name().unwrap().to_str().unwrap();
    assert!(!filename.contains("my-bucket"));
    assert!(filename.contains("object1"));
}

#[test]
fn test_same_object_key_different_buckets() {
    let path1 = get_sharded_path(
        &PathBuf::from("cache/objects"),
        "bucket-a:path/to/object",
        ".meta"
    ).unwrap();
    
    let path2 = get_sharded_path(
        &PathBuf::from("cache/objects"),
        "bucket-b:path/to/object",
        ".meta"
    ).unwrap();
    
    // Different bucket directories
    assert!(path1.to_string_lossy().contains("bucket-a"));
    assert!(path2.to_string_lossy().contains("bucket-b"));
    
    // Same filename (same object key)
    assert_eq!(path1.file_name(), path2.file_name());
}

#[test]
fn test_bucket_name_edge_cases() {
    // Test S3 bucket naming rules
    let test_cases = vec![
        "my-bucket",           // Hyphens
        "my.bucket.name",      // Periods
        "bucket123",           // Numbers
    ];
    
    for bucket_name in test_cases {
        let cache_key = format!("{}:object", bucket_name);
        let path = get_sharded_path(
            &PathBuf::from("cache/objects"),
            &cache_key,
            ".meta"
        ).unwrap();
        
        // Verify bucket name appears in path
        assert!(path.to_string_lossy().contains(bucket_name));
    }
}
```

#### Integration Tests

```rust
#[tokio::test]
async fn test_sharded_cache_operations() {
    let temp_dir = TempDir::new().unwrap();
    let mut cache = DiskCacheManager::new(
        temp_dir.path().to_path_buf(),
        true,  // compression
        1024,  // threshold
        false, // write cache
    );
    cache.enable_sharding(true);
    cache.initialize().await.unwrap();
    
    // Store 1000 objects
    for i in 0..1000 {
        let key = format!("bucket:object-{}", i);
        let data = vec![i as u8; 1024];
        let metadata = ObjectMetadata::new(
            format!("etag-{}", i),
            "2024-11-27T00:00:00Z".to_string(),
            1024,
            None,
            None,
        );
        
        cache.store_range(&key, 0, 1023, &data, metadata).await.unwrap();
    }
    
    // Verify all objects retrievable
    for i in 0..1000 {
        let key = format!("bucket:object-{}", i);
        let entry = cache.get_range(&key, 0, 1023).await.unwrap();
        assert!(entry.is_some());
    }
    
    // Verify files distributed across directories
    let ranges_dir = temp_dir.path().join("ranges");
    let mut dir_count = 0;
    for entry in std::fs::read_dir(&ranges_dir).unwrap() {
        let entry = entry.unwrap();
        if entry.path().is_dir() {
            dir_count += 1;
        }
    }
    
    // Should have multiple L1 directories
    assert!(dir_count > 1);
}
```

#### Performance Benchmarks

```rust
#[bench]
fn bench_flat_lookup_10k(b: &mut Bencher) {
    // Benchmark flat directory with 10K files
}

#[bench]
fn bench_sharded_lookup_10k(b: &mut Bencher) {
    // Benchmark sharded directory with 10K files
}

#[bench]
fn bench_flat_lookup_100k(b: &mut Bencher) {
    // Benchmark flat directory with 100K files
}

#[bench]
fn bench_sharded_lookup_100k(b: &mut Bencher) {
    // Benchmark sharded directory with 100K files
}
```

### Configuration

No configuration changes required. The bucket-first sharding is the new default structure.

#### YAML Configuration (unchanged)

```yaml
cache:
  directory: ~/cache
  compression_enabled: true
  compression_threshold: 1024
```

The cache directory structure is now:
```
~/cache/
├── objects/
│   ├── {bucket}/
│   │   ├── {XX}/
│   │   │   ├── {YY}/
│   │   │   │   └── {object_key}.meta
└── ranges/
    ├── {bucket}/
    │   ├── {XX}/
    │   │   ├── {YY}/
    │   │   │   └── {object_key}_{start}-{end}.bin
```

### Monitoring and Observability

#### Metrics

```rust
pub struct CacheShardingMetrics {
    // Per-bucket metrics
    pub buckets_cached: Gauge,
    pub files_per_bucket: Histogram,
    
    // Distribution metrics (per bucket)
    pub files_per_shard: Histogram,
    pub shard_utilization: Gauge,
    
    // Performance metrics
    pub hash_computation_time: Histogram,
    pub path_resolution_time: Histogram,
}
```

#### Logging

```rust
info!(
    "Cache file stored: bucket={}, object_key={}, shard={}/{}",
    bucket, object_key, level1, level2
);

debug!(
    "Bucket cache stats: bucket={}, total_objects={}, total_ranges={}, disk_usage={}",
    bucket, object_count, range_count, disk_bytes
);

warn!(
    "Shard approaching capacity: bucket={}, shard={}/{}, files={}, threshold={}",
    bucket, level1, level2, file_count, threshold
);
```

#### Per-Bucket Operations

```rust
// Get cache statistics for a specific bucket
pub async fn get_bucket_cache_stats(&self, bucket: &str) -> Result<BucketCacheStats> {
    let objects_dir = self.cache_dir.join("objects").join(bucket);
    let ranges_dir = self.cache_dir.join("ranges").join(bucket);
    
    let mut stats = BucketCacheStats::default();
    
    // Count metadata files
    if objects_dir.exists() {
        stats.object_count = count_files_recursive(&objects_dir)?;
    }
    
    // Count range files
    if ranges_dir.exists() {
        stats.range_count = count_files_recursive(&ranges_dir)?;
        stats.disk_usage = calculate_directory_size(&ranges_dir)?;
    }
    
    Ok(stats)
}

// Clear cache for a specific bucket
pub async fn clear_bucket_cache(&self, bucket: &str) -> Result<()> {
    let objects_dir = self.cache_dir.join("objects").join(bucket);
    let ranges_dir = self.cache_dir.join("ranges").join(bucket);
    
    if objects_dir.exists() {
        std::fs::remove_dir_all(&objects_dir)?;
        info!("Cleared object cache for bucket: {}", bucket);
    }
    
    if ranges_dir.exists() {
        std::fs::remove_dir_all(&ranges_dir)?;
        info!("Cleared range cache for bucket: {}", bucket);
    }
    
    Ok(())
}
```

### Rollout Plan

#### Stage 1: Implementation (Sprint 1)
- [ ] Add BLAKE3 dependency to Cargo.toml (`blake3 = "1.5"`)
- [ ] Update LICENSE_COMPLIANCE_REPORT.md with BLAKE3 license info
- [ ] Implement `parse_cache_key()` to split bucket and object key
- [ ] Implement `get_sharded_path()` with bucket-first hierarchy
- [ ] Replace SHA-256 with BLAKE3 in long key hashing
- [ ] Update all `DiskCacheManager` methods to use new structure
- [ ] Update `SignedPutHandler` to use new structure
- [ ] Add unit tests for bucket name handling and hash distribution

#### Stage 2: Testing (Sprint 2)
- [ ] Integration tests with bucket-first structure
- [ ] Test multiple buckets with same object keys
- [ ] Test S3 bucket naming edge cases (periods, hyphens)
- [ ] Performance benchmarks (flat vs bucket-first sharded)
- [ ] Load testing with 1M+ objects across multiple buckets
- [ ] Test per-bucket cache operations

#### Stage 3: Migration Tool (Sprint 3)
- [ ] Implement migration binary for existing caches
- [ ] Add cache key extraction from old filenames
- [ ] Add progress reporting and dry-run mode
- [ ] Test with production-like data
- [ ] Document migration procedure

#### Stage 4: Deployment (Sprint 4)
- [ ] Deploy new version (breaking change)
- [ ] Choose deployment strategy:
  - Clean slate (recommended): Let cache repopulate
  - Offline migration: Run migration tool during maintenance window
  - Parallel cache: Point to new cache directory
- [ ] Monitor cache hit rates and performance
- [ ] Verify per-bucket operations work correctly

#### Stage 5: Documentation (Sprint 5)
- [ ] Update README.md with new cache structure
- [ ] Update docs/CACHING.md with bucket-first architecture
- [ ] Add examples of per-bucket cache management
- [ ] Document bucket naming considerations

### Future Enhancements

#### Dynamic Shard Depth

Automatically increase directory depth when shards approach capacity:

```rust
pub fn get_adaptive_sharded_path(
    base_dir: &Path,
    cache_key: &str,
    level_widths: &[usize],  // e.g., [2, 3] for XX/YYY/
    suffix: &str,
) -> Result<PathBuf> {
    let (bucket, object_key) = parse_cache_key(cache_key)?;
    let hash = blake3::hash(object_key.as_bytes());
    let hash_hex = hash.to_hex();
    
    let mut path = base_dir.join(bucket);
    let mut offset = 0;
    
    for &width in level_widths {
        let level = &hash_hex[offset..offset+width];
        path = path.join(level);
        offset += width;
    }
    
    // Add filename (no hash prefix needed)
    let filename = sanitize_object_key_for_filename(object_key, suffix);
    Ok(path.join(filename))
}

// Example usage:
// get_adaptive_sharded_path(base, "bucket:key", &[2, 3], ".meta")  // XX/YYY/
// get_adaptive_sharded_path(base, "bucket:key", &[2, 3, 2], ".meta")  // XX/YYY/ZZ/
```

#### Shard Rebalancing

Automatically split hot shards:

```rust
async fn rebalance_shard(shard_path: &Path) -> Result<()> {
    let file_count = count_files_in_directory(shard_path)?;
    
    if file_count > REBALANCE_THRESHOLD {
        // Increase depth for this shard
        split_shard_into_subdirectories(shard_path).await?;
    }
    
    Ok(())
}
```

#### Shard-Level Metrics

Per-shard statistics for monitoring:

```rust
pub struct ShardMetrics {
    pub shard_id: String,
    pub file_count: usize,
    pub total_size: u64,
    pub avg_file_size: u64,
    pub oldest_file: SystemTime,
    pub newest_file: SystemTime,
}
```

## Design Rationale: Why No Hash Prefix in Filename?

### Question: Should we include hash prefix in filename like `a73f8c21_bucket%3Aobject.meta`?

**Answer: No, it's redundant and adds no value.**

**Reasoning:**

1. **Directory already encodes hash**: The path `objects/a7/3f/` already contains the first 4 hex digits of the hash. Adding more hash digits to the filename provides no additional information.

2. **No collision risk**: Within a given directory (e.g., `objects/a7/3f/`), filenames are already unique because:
   - Different cache keys with same hash prefix (first 4 digits) will have different sanitized names
   - True hash collisions are cryptographically infeasible with BLAKE3 (2^256 space)

3. **Debugging is easier without prefix**: 
   - With prefix: `a73f8c21_bucket%3Aobject.meta` (harder to read)
   - Without prefix: `bucket%3Aobject.meta` (immediately recognizable)

4. **Verification doesn't require prefix**: If you need to verify a file is in the correct directory, you can:
   ```rust
   let expected_path = get_sharded_path(base_dir, cache_key, ".meta");
   assert_eq!(actual_path, expected_path);
   ```
   The hash is computed once during path resolution, not extracted from filename.

5. **Consistency with existing pattern**: Current code uses `long_key_{hash}` only when the key itself is too long. For normal keys, we preserve readability.

### BLAKE3 for Long Keys

**Current approach** (SHA-256):
```rust
if sanitized.len() > 200 {
    format!("long_key_{:x}", sha256_hash)  // 64 hex chars
}
```

**Proposed approach** (BLAKE3):
```rust
if sanitized.len() > 200 {
    blake3::hash(cache_key).to_hex().to_string()  // 64 hex chars
}
```

**Advantages:**
- **10x faster**: BLAKE3 is significantly faster than SHA-256
- **Same output size**: Both produce 64 hex character strings
- **Better distribution**: BLAKE3 has superior avalanche properties
- **Single dependency**: Use BLAKE3 for both sharding and long key hashing
- **License compatible**: CC0-1.0 OR Apache-2.0 (no restrictions)

**No downsides**: Since we're already adding BLAKE3 for sharding, using it for long keys is a pure win.

## Summary

The bucket-first hash-based directory sharding design provides:

✅ **Scalability**: 655M files per bucket, unlimited buckets  
✅ **Performance**: O(1) lookups regardless of cache size  
✅ **Reliability**: Uniform distribution prevents hotspots within each bucket  
✅ **Bucket Operations**: Per-bucket cache cleanup, monitoring, and management  
✅ **Space Efficiency**: No bucket name redundancy in filenames  
✅ **Simplicity**: Straightforward implementation and maintenance  
✅ **Readability**: Clean filenames with only object keys  
✅ **Efficiency**: BLAKE3 for both sharding and long key hashing  
✅ **Breaking Change**: No backward compatibility burden  

**Key Benefits:**

1. **Massive scale**: 10.5B total files per bucket (metadata + byte ranges combined)
2. **Per-bucket management**: `rm -rf cache/objects/my-bucket/` clears entire bucket
3. **Better organization**: Natural grouping by bucket for monitoring and debugging
4. **Reduced redundancy**: Bucket name not repeated in every filename
5. **Filesystem safe**: S3 bucket naming rules ensure directory name compatibility
6. **Low file density**: ~1,000 files per directory even with 1B byte ranges per bucket

**Scale Comparison:**

| Structure | Leaf Dirs | Max Total Files | Files/Dir @ 1B byte ranges + 100M metadata |
|-----------|-----------|-----------------|-------------------------------------------|
| Flat | 1 | ~10M (filesystem limit) | 1.1B (unusable) |
| XX/YY/ | 65K | 655M | 16,784 (approaching limit) |
| XX/YYY/ | 1M | 10.5B | 1,049 (comfortable) |

**Terminology Clarification:**
- **Objects**: S3 objects (e.g., files in a bucket)
- **Byte ranges**: Cached portions of objects (e.g., bytes 0-8388607 of an object)
- **Metadata files**: One `.meta` file per object in `objects/` directory
- **Range files**: One `.bin` file per cached byte range in `ranges/` directory
- **Total files**: Metadata files + range files

This design ensures the S3 proxy cache can scale to billions of objects with tens of billions of byte ranges across thousands of buckets while maintaining sub-millisecond file lookup performance and enabling practical per-bucket cache operations.
