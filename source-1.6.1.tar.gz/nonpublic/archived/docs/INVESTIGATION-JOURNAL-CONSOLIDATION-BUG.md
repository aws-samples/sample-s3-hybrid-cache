# Investigation: Journal Consolidation Losing Ranges

## Problem Statement

After downloading files to the S3 proxy cache, range files are "orphaned" - they exist on disk but are not referenced in metadata files. This causes cache misses on repeat downloads even though the data is cached.

**Original Symptoms (v1.0.5):**
- 2,753 range files on disk
- 2,420 ranges in metadata files
- 333 ranges (12%) orphaned
- Cache hit rate on repeat downloads: ~88%

## Root Causes Identified

### Bug 1: Journal Truncation Before Consolidation Complete (Fixed in v1.0.6)

The `cleanup_instance_journals()` function was truncating ALL journal files unconditionally after consolidation, but `validate_journal_entries()` was filtering out entries where range files weren't visible (due to NFS attribute caching delays).

**The Race Condition:**
1. Instance A writes a range file and creates a journal entry
2. Consolidation runs - `validate_journal_entries()` checks if range files exist
3. NFS attribute caching may cause the range file to appear as "not existing"
4. Entries with "missing" range files are filtered out as invalid
5. `cleanup_instance_journals()` TRUNCATED ALL journal files
6. Result: Journal entry lost forever, range file orphaned

**Fix:** New `cleanup_consolidated_entries()` method only removes entries that were successfully consolidated. Entries with missing range files are preserved for retry.

### Bug 2: Multi-Instance Consolidation Race (Fixed in v1.0.7)

Multiple proxy instances were consolidating the SAME cache key simultaneously, causing entries to be lost.

**The Race Condition:**
1. Instance A, B, C all run `discover_pending_cache_keys()` at the same time
2. All 3 instances see the same cache keys with pending entries
3. All 3 instances call `consolidate_object()` for the same key
4. Lock was acquired AFTER reading journal entries
5. All instances read the same entries before any acquired the lock
6. First instance to get lock consolidates and cleans up entries
7. Other instances' reads are now stale - entries already removed

**Fix:** Acquire lock BEFORE reading journal entries. Only one instance processes each cache key at a time. Other instances skip (another instance is handling it).

### Bug 3: Non-Atomic Metadata Write (Fixed in v1.0.8)

The `write_metadata_to_disk()` function in journal consolidator used `tokio::fs::write()` which is NOT atomic on NFS.

**The Race Condition:**
1. Instance A consolidates cache_key_1, starts writing metadata
2. `tokio::fs::write()` internally: opens file, truncates, writes content
3. Instance B consolidates cache_key_1 (different consolidation cycle)
4. Instance B acquires lock, reads metadata file
5. Instance B sees empty/partial file (Instance A still writing)

**Error:** "Failed to parse metadata file: EOF while parsing a value at line 1 column 0"

**Fix:** Use atomic write pattern (temp file + rename) like `hybrid_metadata_writer.rs`. Readers always see complete, valid JSON.

### Bug 4: Journal Append Race Condition (Fixed in v1.0.9)

The `append_range_entry()` function in `journal_manager.rs` was NOT thread-safe within a single instance.

**The Race Condition:**
1. Thread A reads existing journal content (entries 1-10)
2. Thread B reads existing journal content (entries 1-10) - same content
3. Thread A writes entries 1-10 + entry 11 to temp file, renames to journal
4. Thread B writes entries 1-10 + entry 12 to temp file, renames to journal
5. Result: Entry 11 is LOST - overwritten by Thread B's write

**Evidence from v1.0.8 test:**
- Orphaned range `5GB-1:1216348160-1224736767` was stored at 13:41:29.912
- Multiple threads storing ranges within milliseconds
- No journal entry found for the orphaned range
- Range file exists, "Range stored" was logged, but journal entry was overwritten

**Fix:** Added `tokio::sync::Mutex` to `JournalManager` struct. The `append_range_entry()` function now acquires the mutex before reading/writing the journal file, serializing all appends within each instance.

### Bug 5: Cleanup vs Append Race Condition (Identified in v1.0.9 testing)

The v1.0.9 mutex fix only protects appends from each other. It does NOT protect against the cleanup operation in `JournalConsolidator::cleanup_consolidated_entries()`.

**The Race Condition:**
1. Cleanup reads journal file (entries 1-10)
2. Append writes new entry 11 (protected by mutex, but cleanup doesn't use it)
3. Cleanup writes back filtered entries (entries 1-10 minus consolidated ones)
4. Result: Entry 11 is LOST - overwritten by cleanup's write

**Evidence from v1.0.9 test:**
- 22 orphans out of 2753 ranges (0.8%)
- Orphaned range `1107296256-1115684863` was stored at 14:03:18.735
- "Range stored (hybrid)" was logged - journal write succeeded
- Consolidation at 14:03:22 should have picked it up, but didn't
- Entry was lost between append and next consolidation read

**Why the mutex doesn't help:**
- The mutex is in `JournalManager` and protects `append_range_entry()`
- The cleanup is in `JournalConsolidator` and doesn't use the mutex
- Cleanup runs on potentially different instances, can't share in-process mutex

**Proposed Fix Options:**

1. **File-level locking (flock):** Both append and cleanup acquire exclusive lock on journal file. Problem: cleanup holds lock for ~10-100ms, blocking all appends during consolidation. Cache writes would stall.

2. **Fresh journal on lock contention:** If append can't get lock, create new journal file with unique name (e.g., `{instance_id}:{timestamp}.journal`). Cleanup only touches existing files. Appends never block. Consolidator already scans all `*.journal` files.

3. **O_APPEND flag:** Use kernel's atomic append guarantee. No read-modify-write for appends, just append. Cleanup still needs coordination but appends are always fast.

**Recommended: Option 2 (Fresh journal on lock contention)**
- Appends never block - cache writes stay fast
- Cleanup can take its time with exclusive lock
- Consolidator already handles multiple journal files
- Simple to implement

**Status:** Fixed in v1.0.10. Implementation details:
- `append_range_entry()` uses non-blocking `try_lock_exclusive()` on journal lock file
- If lock is busy, creates fresh journal file: `{instance_id}:{timestamp}.journal`
- `cleanup_consolidated_entries()` acquires exclusive `flock()` before read-modify-write
- Fresh journal files are deleted when empty (primary journals are truncated)
- Consolidator already scans all `*.journal` files, so fresh journals are automatically discovered

## Test Results

### v1.0.6 Results (Bug 1 Fixed)
- 1st download: 2753 range files, 2734 in metadata = **19 orphans (0.7%)**
- 2nd download: 2641 cache hits, 35 misses = **98.7% hit rate**
- Improvement: 12% → 0.7% orphans

### v1.0.7 Results (Bug 2 Fixed)
- 4104 range files, 4089 in metadata = **15 orphans (0.4%)**
- All GET requests were cache HITs (only HEAD misses expected)
- No "lock held by another" messages (lock-before-read working)

### v1.0.8 Test (Bug 3 Fixed)
- 2660 range files, 2647 in metadata = **13 orphans (0.5%)**
- No "EOF" or parse errors in consolidation logs (atomic write working)
- Remaining orphans caused by Bug 4 (journal append race condition)

### v1.0.9 Test (Bug 4 Fixed, Bug 5 Identified)
- 2753 range files, 2731 in metadata = **22 orphans (0.8%)**
- Mutex prevents intra-instance append races
- But cleanup vs append race (Bug 5) still causes orphans
- Orphaned ranges were stored successfully but lost during cleanup

### v1.0.10 Results (Bug 5 Fixed)
- 2279 range files, 2279 in metadata = **0 orphans (0%)**
- Fresh journal on lock contention approach working correctly
- Many fresh journals created during high-concurrency download, all consolidated successfully
- **100% cache consistency achieved**

### v1.0.11 Results (Retry + Lock Cleanup)
- 2753 range files, 2753 in metadata = **0 orphans (0%)**
- Stale journal lock file cleanup working (logs show "Cleaned up X stale journal lock files")
- S3 retry logic in place (no retries needed in test - good sign)
- Second download: 7599 cache HITs, 0 misses for previously cached data

### v1.0.12 (Log Noise Reduction)
- Downgraded benign race condition logs from WARN/ERROR to INFO
- No functional changes

## Fixes Applied

### v1.0.6 Changes
- `ConsolidationResult` now includes `consolidated_entries: Vec<JournalEntry>`
- New `cleanup_consolidated_entries()` removes only specific entries
- Deprecated `cleanup_instance_journals()` 
- Updated `main.rs` consolidation loop

### v1.0.7 Changes
- `consolidate_object()` acquires lock BEFORE reading journal entries
- Instances that can't get lock skip the cache key (returns success with 0 entries)
- Eliminates multi-instance race condition

### v1.0.8 Changes
- `write_metadata_to_disk()` now uses atomic write (temp file + rename)
- Prevents readers from seeing empty/partial metadata files during write
- Matches pattern used in `hybrid_metadata_writer.rs`

### v1.0.9 Changes
- Added `tokio::sync::Mutex` to `JournalManager` struct
- `append_range_entry()` acquires mutex before read/write operations
- Serializes journal appends within each instance, preventing lost updates
- Does NOT fix cleanup vs append race (Bug 5)

### v1.0.10 Changes
- `append_range_entry()` uses non-blocking `try_lock_exclusive()` on journal lock file
- If lock is busy (cleanup in progress), creates fresh journal file with timestamp suffix
- `cleanup_consolidated_entries()` acquires exclusive `flock()` before read-modify-write
- Fresh journal files are deleted when empty (primary journals are truncated)
- Appends never block - cache writes stay fast during consolidation

### v1.0.11 Changes
- Added S3 request retry logic (up to 2 retries with 100ms/200ms backoff) for transient failures
- Added stale journal lock file cleanup during consolidation

### v1.0.12 Changes
- Downgraded "Failed to read journal file for cleanup" from WARN to INFO
- Downgraded "Failed to break stale lock" from ERROR to INFO
- These are expected race conditions on shared NFS storage

## Next Steps

**RESOLVED** - Journal consolidation bug investigation complete. All 5 bugs identified and fixed:
- Bug 1 (v1.0.6): Journal truncation before consolidation complete
- Bug 2 (v1.0.7): Multi-instance consolidation race
- Bug 3 (v1.0.8): Non-atomic metadata write
- Bug 4 (v1.0.9): Journal append race condition (intra-instance)
- Bug 5 (v1.0.10): Cleanup vs append race condition (inter-process)

Orphan rate progression: 12% → 0.7% → 0.4% → 0.5% → 0.8% → **0%**

**NFS Mount Optimization:** Changed from `lookupcache=none` to `lookupcache=pos` for better cache hit performance while maintaining multi-instance file visibility.

### Stale Lock File Cleanup (Implemented in v1.0.11)
The "fresh journal on lock contention" approach created `.journal.lock` files that accumulated. v1.0.11 added automatic cleanup of stale lock files during consolidation.

## Environment

- **Deployment:** 3 EC2 instances with shared EFS cache
- **NFS Mount:** `lookupcache=pos` (positive lookups cached, negative lookups not cached)
- **Consolidation Interval:** 5 seconds

### NFS Mount Option Discovery

Initial testing used `lookupcache=none` which disabled all directory entry caching. This fixed the multi-instance visibility issue but degraded cache hit performance (every file lookup went to NFS server).

**Solution:** `lookupcache=pos` provides the best of both worlds:
- **Positive lookups cached:** Files that exist are cached locally (fast repeated access)
- **Negative lookups not cached:** "File not found" results are not cached, so new files created by other instances are visible immediately

This eliminates the original problem (instances caching "file not found" for files that exist) while maintaining good cache hit performance.

## Validation Commands

```bash
# Check orphan count
RANGE_COUNT=$(find /mnt/efs/cache/ranges -name '*.bin' | wc -l)
META_RANGES=$(find /mnt/efs/cache/metadata -name '*.meta' -exec cat {} \; | jq '.ranges | length' | awk '{sum+=$1} END {print sum}')
echo "Range files: $RANGE_COUNT, Metadata: $META_RANGES, Orphans: $((RANGE_COUNT - META_RANGES))"

# Find orphaned ranges for specific object
cat /path/to/object.meta | jq -r '.ranges[] | "\(.start)-\(.end)"' | sort > /tmp/meta.txt
find /path/to/ranges -name '*object*.bin' | sed 's|.*_||' | sed 's|.bin||' | sort > /tmp/disk.txt
comm -23 /tmp/disk.txt /tmp/meta.txt
```

## Related Learnings

### NFS Log File Clearing
Do NOT use `rm -rf` to clear log files while proxy is running. NFS does "silly rename" to `.nfs*` files. Proxy keeps writing to renamed file, dashboards can't find logs.

**Fix:** Restart proxy after clearing logs, or use `truncate -s 0` instead of `rm`.

## Files Modified

- `src/journal_consolidator.rs` - Fixes for bugs 1, 2, 3 (v1.0.6, v1.0.7, v1.0.8)
- `src/journal_manager.rs` - Bug 4 fix (v1.0.9), Bug 5 fix pending
- `src/main.rs` - Updated consolidation loop
- `tests/journal_based_metadata_updates_test.rs` - New test
- `Cargo.toml` - Version bumps
- `CHANGELOG.md` - Release notes
