# AWS Signature Version 4 - 403 Fix Implementation

## Problem Summary

Multipart upload requests were failing with 403 Forbidden errors because:
1. AWS SigV4 creates cryptographic signatures that include specific headers
2. The proxy was parsing and rebuilding HTTP requests using Hyper
3. Hyper modifies headers (host, content-length, etc.) during request building
4. Modified headers cause signature validation to fail at S3

## Solution Implemented

Implemented **Option 1: Preserve Original Request Exactly** as documented in `AWS_SIGV4_403_ANALYSIS.md`.

### Architecture

```
Client (AWS CLI/SDK)
  ↓ (HTTP/HTTPS with AWS SigV4 signature)
Proxy (Port 80/443)
  ↓ (Detect signature)
  ├─ Signed Request → Raw HTTP Forwarding (preserve exact bytes)
  └─ Unsigned Request → Normal Hyper Processing (caching, etc.)
  ↓ (HTTPS to S3)
S3 (Validates signature)
```

### Components Created

#### 1. New Module: `src/signed_request_proxy.rs`

**Purpose**: Handle AWS SigV4 signed requests by preserving the original HTTP request exactly.

**Key Functions**:
- `is_aws_sigv4_signed()` - Detects AWS4-HMAC-SHA256 signatures in Authorization header
- `forward_signed_request()` - Forwards raw HTTP request without modification
- Raw HTTP parsing and building to avoid Hyper's header modifications

**How it works**:
1. Detects signed requests by checking for `AWS4-HMAC-SHA256` in Authorization header
2. Extracts request components (method, URI, headers, body)
3. Builds raw HTTP request bytes manually
4. Establishes TLS connection to S3
5. Sends raw bytes over TLS
6. Reads raw response
7. Parses response back into Hyper Response

#### 2. Integration in `src/http_proxy.rs`

**Changes**:
- Added signed request detection in `handle_put_request()`
- Added signed request detection in `handle_other_request()` for POST/DELETE
- Added helper methods:
  - `forward_signed_put_request()`
  - `forward_signed_post_request()`
  - `forward_signed_delete_request()`
  - `forward_signed_request()` - Common implementation

**Flow**:
```rust
// In handle_put_request()
if is_aws_sigv4_signed(&headers) {
    // Forward without modification
    return forward_signed_put_request(req, host, s3_client).await;
}
// Otherwise, proceed with normal caching logic
```

### What Gets Preserved

For signed requests, we preserve:
- ✅ Exact header names and values (including casing)
- ✅ Exact header order
- ✅ Exact request body
- ✅ HTTP method and URI
- ✅ HTTP version

### What Still Works

- ✅ **Read operations (GET/HEAD)** - Continue to use caching
- ✅ **Unsigned write operations** - Continue to use write cache
- ✅ **DNS resolution** - Still use connection pool for IP resolution
- ✅ **TLS** - Still establish secure connections to S3

### What Changes for Signed Requests

- ❌ **No caching** - Signed write operations bypass cache
- ❌ **No header modification** - Headers forwarded exactly as received
- ❌ **No request rebuilding** - Raw HTTP bytes forwarded

## Retry Behavior

### Per-Request Retry Logic

The proxy implements retry logic at the **per-request level**, not per-upload:

- **Each HTTP request** (GET, PUT, UploadPart, etc.) gets up to **3 retry attempts**
- Retries handle transient failures: TLS resets, connection errors, timeouts
- Exponential backoff: 100ms → 200ms → 400ms between retries

### Multipart Upload Resilience

For large uploads (terabytes over hours):
- ✅ **Each UploadPart is independent** - gets its own 3 retries
- ✅ **Parts are typically 5MB-100MB** - complete quickly even with resets
- ✅ **Client-level retry** - AWS SDKs retry failed parts at application level
- ✅ **Handles frequent resets** - One reset per minute is fine for typical part sizes

Example: Uploading 1TB file
- Split into ~200 parts of 5GB each
- Each part request gets 3 retries for TLS/connection issues
- Even with connection resets every minute, individual parts complete successfully

### Retry Limits by Method

From `s3_client.rs`:
```rust
Method::GET | Method::HEAD => 3 retries
Method::PUT => 1 retry  // Prevent duplicate uploads
Other methods => 3 retries
```

From `signed_request_proxy.rs`:
```rust
Signed requests => 3 retries for TLS/connection establishment
```

## Testing

### Unit Tests Added

In `src/signed_request_proxy.rs`:
- `test_is_aws_sigv4_signed()` - Signature detection
- `test_find_header_end()` - HTTP parsing
- `test_parse_status_code()` - Response parsing

### Manual Testing Required

1. **Multipart Upload Test**:
   ```bash
   aws s3 cp large-file.bin s3://bucket/key --endpoint-url http://proxy:80
   ```
   Expected: Success (no 403 errors)

2. **Regular PUT Test**:
   ```bash
   aws s3 cp small-file.txt s3://bucket/key --endpoint-url http://proxy:80
   ```
   Expected: Success with caching (if unsigned) or success without caching (if signed)

3. **GET Test** (verify caching still works):
   ```bash
   aws s3 cp s3://bucket/key local-file.txt --endpoint-url http://proxy:80
   ```
   Expected: Success with cache hit on second request

## Trade-offs

### Advantages
- ✅ Fixes 403 errors for all AWS SigV4 signed requests
- ✅ No AWS credentials required in proxy
- ✅ Maintains "transparent forwarder" design
- ✅ Simple implementation
- ✅ Works for all signed operations (PUT, POST, DELETE)

### Disadvantages
- ❌ Signed write operations don't benefit from caching
- ❌ Slightly more complex code path
- ❌ Raw HTTP parsing/building (though well-tested)

## Future Improvements

1. **Selective Caching**: Cache the response even if request is signed
   - Challenge: Need to handle cache invalidation properly
   
2. **Signature Rewriting**: Re-sign requests with proxy's credentials
   - Challenge: Requires AWS credentials in proxy
   - Challenge: Violates "transparent forwarder" design

3. **HTTP/2 Support**: Currently only handles HTTP/1.1
   - Challenge: More complex raw protocol handling

## Configuration

No configuration changes required. The proxy automatically detects and handles signed requests.

## Monitoring

### Log Messages

Key log messages to watch for:
- `INFO Detected AWS SigV4 signed PUT request, forwarding without modification`
- `INFO Detected AWS SigV4 signed POST request, forwarding without modification`
- `INFO Detected AWS SigV4 signed DELETE request, forwarding without modification`
- `INFO Successfully forwarded signed request to {host}`
- `INFO Parsed signed request response: 200` (UploadPart - no body size logged)
- `INFO Parsed signed request response: 200 with body size: X bytes` (other responses)
- `WARN TLS handshake attempt N failed: {error}` (retry in progress)
- `ERROR Failed to forward signed request: {error}` (all retries exhausted)

### Response Logging

For signed requests, the proxy logs response status differently:
- **UploadPart responses** (200 OK with empty body): Omits body size for cleaner logs
- **Other responses**: Includes body size for debugging

## Rollback Plan

If issues arise:
1. Remove `signed_request_proxy` module from `src/lib.rs`
2. Remove signed request detection from `http_proxy.rs`
3. Revert to previous behavior (all requests use Hyper)

Note: This will bring back the 403 errors for signed requests.

## Related Documents

- `AWS_SIGV4_403_ANALYSIS.md` - Root cause analysis and solution options
- `.kiro/specs/unified-range-write-cache/` - Write cache implementation spec
