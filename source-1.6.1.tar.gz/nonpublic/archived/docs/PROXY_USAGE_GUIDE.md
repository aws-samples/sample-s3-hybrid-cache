# S3 Proxy Usage Guide

## Understanding Proxy Modes and Ports

The S3 Proxy operates on two ports with different behaviors:

### Port 80 (HTTP) - **Caching Enabled**
- Full caching of GET, HEAD, and PUT requests
- Range request optimization
- Write-through caching
- **Use this for performance benefits**

### Port 443 (HTTPS) - **TCP Passthrough (Default)**
- Transparent TCP tunneling
- No TLS termination
- No caching (passthrough only)
- Preserves end-to-end encryption
- **Use this for compatibility without caching**

### Port 443 (HTTPS) - **Self-Signed Mode (Optional)**
- TLS termination with self-signed certificates
- Full caching like port 80
- Requires `--no-verify-ssl` flag
- **Use this to cache HTTPS traffic**

## How to Use the Proxy

### Option 1: HTTP with Caching (Recommended for Performance)

**Setup:**
1. Run proxy on port 80 (requires sudo)
2. Configure hosts file to route S3 to proxy
3. Use HTTP endpoint URL to force HTTP

**Example:**
```bash
# Start proxy
sudo cargo run --release -- -c config.yaml

# Configure hosts file
sudo bash -c 'echo "127.0.0.1 s3.us-east-1.amazonaws.com" >> /etc/hosts'

# Use AWS CLI with HTTP endpoint
aws s3 cp file.txt s3://bucket/key \
  --endpoint-url "http://s3.us-east-1.amazonaws.com" \
  --region us-east-1
```

**Why this works:**
- AWS CLI defaults to HTTPS (port 443)
- `--endpoint-url "http://..."` forces HTTP (port 80)
- Hosts file routes `s3.us-east-1.amazonaws.com` → proxy IP
- Proxy caches the request on port 80
- Proxy forwards to real S3 via HTTPS

### Option 2: HTTPS with Self-Signed Certificates

**Setup:**
1. Configure `https_mode: "selfsigned"` in config
2. Run proxy on port 443 (requires sudo)
3. Configure hosts file
4. Use `--no-verify-ssl` flag

**Example:**
```bash
# config.yaml
server:
  https_mode: "selfsigned"
  https_port: 443

# Start proxy
sudo cargo run --release -- -c config.yaml

# Configure hosts file
sudo bash -c 'echo "127.0.0.1 s3.us-east-1.amazonaws.com" >> /etc/hosts'

# Use AWS CLI with --no-verify-ssl
aws s3 cp file.txt s3://bucket/key \
  --no-verify-ssl \
  --region us-east-1
```

**Why this works:**
- AWS CLI uses HTTPS (port 443) by default
- Hosts file routes to proxy
- Proxy terminates TLS with self-signed cert
- `--no-verify-ssl` bypasses certificate validation
- Proxy caches the request
- Proxy forwards to real S3 via HTTPS

### Option 3: HTTPS Passthrough (No Caching)

**Setup:**
1. Use default `https_mode: "passthrough"`
2. Run proxy on port 443
3. Configure hosts file
4. No special flags needed

**Example:**
```bash
# Start proxy (passthrough is default)
sudo cargo run --release -- -c config.yaml

# Configure hosts file
sudo bash -c 'echo "127.0.0.1 s3.us-east-1.amazonaws.com" >> /etc/hosts'

# Use AWS CLI normally
aws s3 cp file.txt s3://bucket/key --region us-east-1
```

**Why this works:**
- AWS CLI uses HTTPS (port 443)
- Hosts file routes to proxy
- Proxy passes through TLS without termination
- No caching occurs
- Useful for compatibility testing

## Key Concepts

### Host Header Port Stripping

The proxy automatically strips ports from the Host header:
- Client sends: `Host: s3.amazonaws.com:8081`
- Proxy uses: `s3.amazonaws.com` (port stripped)
- Forwards to: Real S3 endpoint

This prevents DNS resolution errors when using non-standard ports.

### Why AWS CLI Defaults to HTTPS

AWS CLI and s5cmd default to HTTPS for security. To use HTTP caching:
- Use `--endpoint-url "http://..."` to force HTTP
- Or use self-signed HTTPS mode with `--no-verify-ssl`

### Hosts File Routing

The hosts file routes S3 hostnames to the proxy:
```
127.0.0.1 s3.amazonaws.com
127.0.0.1 s3.us-east-1.amazonaws.com
127.0.0.1 bucket.s3.us-east-1.amazonaws.com
```

This works for both HTTP and HTTPS traffic.

## Performance Testing

Performance tests use **Option 1 (HTTP with Caching)**:

```bash
# Runs proxy on port 80 with sudo
# Uses HTTP endpoint URLs
# Measures cache effectiveness
# Performance testing scripts are maintained separately
```

## Production Recommendations

### For Maximum Performance
- Use **Option 1 (HTTP)** for internal/trusted networks
- Requires clients to use HTTP endpoint URLs
- Full caching benefits

### For Security + Performance
- Use **Option 2 (Self-Signed HTTPS)** with proper certificate management
- Requires `--no-verify-ssl` or installing proxy cert in client trust store
- Full caching with TLS

### For Compatibility Only
- Use **Option 3 (HTTPS Passthrough)**
- No configuration changes needed for clients
- No caching benefits

## Common Issues

### "AWS CLI still goes to real S3"
- Check hosts file is configured
- Verify you're using HTTP endpoint URL for port 80
- Or verify `--no-verify-ssl` for self-signed mode

### "Certificate verification failed"
- You're in self-signed mode without `--no-verify-ssl`
- Either add the flag or switch to HTTP mode

### "Connection refused on port 80"
- Port 80 requires sudo
- Use `sudo cargo run --release -- -c config.yaml`

### "DNS resolution failed for hostname:port"
- This was the bug we fixed
- Update to latest version with port stripping

## Summary

| Mode | Port | Caching | TLS | Client Flag | Use Case |
|------|------|---------|-----|-------------|----------|
| HTTP | 80 | ✅ Yes | No | `--endpoint-url "http://..."` | Performance testing, internal networks |
| HTTPS Self-Signed | 443 | ✅ Yes | Yes | `--no-verify-ssl` | Performance + security (with cert management) |
| HTTPS Passthrough | 443 | ❌ No | Yes | None | Compatibility, no caching needed |

**For performance testing and benchmarking, always use HTTP mode (port 80) with HTTP endpoint URLs.**
