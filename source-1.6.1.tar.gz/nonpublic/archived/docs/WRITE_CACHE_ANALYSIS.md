# Write-Through Cache and Multipart Upload Analysis

## Current Architecture

### Write-Through Cache (PUT Requests)
**Storage Location:** `cache_dir/write_cache/`
**Format:** Full object body stored as complete file
**Structure:**
```
write_cache/
  {sanitized_key}.cache     # Full object body (compressed)
  {sanitized_key}.meta      # Metadata JSON
```

**Key Characteristics:**
- Stores entire PUT request body
- Uses PUT_TTL for expiration
- Separate from GET cache
- Transitions to GET cache on first read
- **NOT stored as ranges** - stored as complete objects

### Multipart Upload Parts
**Storage Location:** `cache_dir/ranges/` (unified with range storage)
**Format:** Parts stored as ranges within a single object
**Structure:**
```
objects/
  {sanitized_key}.meta      # Metadata tracking all uploaded parts as ranges
ranges/
  {sanitized_key}_0-5242879.bin          # Part 1 data (compressed)
  {sanitized_key}_5242880-10485759.bin   # Part 2 data (compressed)
  {sanitized_key}_10485760-15728639.bin  # Part 3 data (compressed)
```

**Key Characteristics:**
- Each part stored as a range at its byte position in the final object
- Cache key format: Same as regular objects (no special part suffix)
- Parts automatically indexed by byte position
- Metadata tracks upload state (in-progress vs completed)
- **Capacity-aware**: Bypass cache if total upload size exceeds write cache capacity
- **Invalidation on conflict**: Drop cached parts if new PutObject or CreateMultipartUpload starts for same key

### Range Storage (GET Requests)
**Storage Location:** `cache_dir/ranges/`
**Format:** New architecture - separate binary files per range
**Structure:**
```
objects/
  {sanitized_key}.meta      # Lightweight JSON index (~25KB for 100 ranges)
ranges/
  {sanitized_key}_0-8388607.bin          # Range data (compressed)
  {sanitized_key}_8388608-16777215.bin   # Range data (compressed)
```

**Key Characteristics:**
- Each range stored in separate `.bin` file
- Metadata file tracks all ranges for an object
- Full objects stored as range 0-N
- Lazy loading - only load needed ranges
- 5000x smaller metadata files
- 200x faster parsing

## Problem: Architectural Inconsistency

### Current Issues

1. **Two Different Storage Formats:**
   - Write cache: Full objects in `write_cache/`
   - Range cache: Ranges in `ranges/` with metadata in `objects/`

2. **Write Cache Cannot Serve Range Requests:**
   - PUT-cached object stored as complete file
   - When GET with Range header arrives, cannot serve partial content
   - Must fetch entire object from write cache or go to S3

3. **Transition Inefficiency:**
   - Write cache → GET cache transition copies entire object
   - Doesn't convert to range format
   - Misses opportunity to serve range requests efficiently

4. **Multipart Upload Challenges:**
   - Need to track upload state (in-progress vs completed)
   - Must handle capacity constraints (large uploads may exceed cache)
   - Must invalidate on conflicts (new upload to same key)
   - Parts arrive incrementally with byte positions

## Proposed Solution: Unified Range Storage

### Concept
**Store ALL cached data as ranges in the new range storage architecture**

### Benefits

1. **Unified Storage Format:**
   - Write cache, multipart uploads, and GET cache all use same format
   - Single code path for storage and retrieval
   - Consistent metadata structure

2. **Range Request Support:**
   - PUT-cached objects can immediately serve range requests
   - No need to fetch entire object for partial content
   - Multipart parts automatically indexed by byte position

3. **Efficient Transitions:**
   - No copying needed - already in correct format
   - Just update TTL metadata (PUT_TTL → GET_TTL)
   - Metadata update is lightweight (~25KB file)

4. **Multipart as Single Object:**
   - Parts stored as ranges within one logical object
   - Can determine which part(s) contain requested range
   - Automatic assembly for full object requests
   - Capacity-aware: bypass cache if upload exceeds limits
   - Conflict handling: invalidate on new upload to same key

### Implementation Approach

#### 1. Write Cache as Ranges
```rust
// When storing PUT request
pub async fn store_write_cache_entry(
    &self,
    cache_key: &str,
    response_body: &[u8],
    headers: HashMap<String, String>,
    metadata: CacheMetadata,
) -> Result<()> {
    let content_length = response_body.len() as u64;
    
    // Store as range 0 to content_length-1
    let object_metadata = ObjectMetadata {
        etag: metadata.etag,
        last_modified: metadata.last_modified,
        content_length,
        content_type: None,
    };
    
    // Use disk cache manager to store as range
    let mut disk_cache = self.disk_cache_manager.lock().await;
    disk_cache.store_full_object_as_range(
        cache_key,
        response_body,
        object_metadata
    ).await?;
    
    // Update metadata with PUT_TTL
    disk_cache.update_metadata_with_put_ttl(cache_key, self.put_ttl).await?;
    
    Ok(())
}
```

#### 2. Multipart Parts as Ranges
```rust
// When initiating multipart upload
pub async fn initiate_multipart_upload(
    &self,
    path: &str,
) -> Result<()> {
    let cache_key = Self::generate_cache_key(path);
    
    // NOTE: Cannot check capacity upfront - total size unknown until CompleteMultipartUpload
    // Will check incrementally as parts arrive
    
    // Invalidate any existing cached data for this key
    let mut disk_cache = self.disk_cache_manager.lock().await;
    disk_cache.invalidate(&cache_key).await?;
    
    // Create metadata for in-progress multipart upload
    let metadata = ObjectMetadata {
        upload_state: UploadState::InProgress,
        parts: Vec::new(),
        cumulative_size: 0,
        ..Default::default()
    };
    disk_cache.create_metadata(&cache_key, metadata).await?;
    
    Ok(())
}

// When storing multipart part
pub async fn store_multipart_part(
    &self,
    path: &str,
    part_number: u32,
    part_data: &[u8],
    headers: HashMap<String, String>,
    metadata: CacheMetadata,
) -> Result<()> {
    // Generate cache key for the OBJECT (not the part)
    let cache_key = Self::generate_cache_key(path);
    
    let mut disk_cache = self.disk_cache_manager.lock().await;
    
    // Check if we're still caching this upload
    let obj_metadata = disk_cache.get_metadata(&cache_key).await?;
    if obj_metadata.is_none() || obj_metadata.unwrap().upload_state == UploadState::Bypassed {
        // Not caching this upload
        return Ok(());
    }
    
    // Check if adding this part would exceed capacity
    let current_size = disk_cache.get_object_size(&cache_key).await?;
    let part_size = part_data.len() as u64;
    if current_size + part_size > self.write_cache_capacity {
        // Mark upload as bypassed and clean up existing parts
        disk_cache.invalidate(&cache_key).await?;
        return Ok(());
    }
    
    // Store part with its number and size (byte position calculated later)
    let part_info = PartInfo {
        part_number,
        size: part_size,
        etag: metadata.etag.clone(),
        data: part_data.to_vec(),
    };
    
    // Add to metadata's parts list
    let mut obj_metadata = disk_cache.get_metadata(&cache_key).await?.unwrap();
    obj_metadata.parts.push(part_info);
    disk_cache.update_metadata(&cache_key, obj_metadata).await?;
    
    Ok(())
}

// When completing multipart upload
pub async fn complete_multipart_upload(
    &self,
    path: &str,
) -> Result<()> {
    let cache_key = Self::generate_cache_key(path);
    
    let mut disk_cache = self.disk_cache_manager.lock().await;
    
    if let Some(mut metadata) = disk_cache.get_metadata(&cache_key).await? {
        // Sort parts by part number
        metadata.parts.sort_by_key(|p| p.part_number);
        
        // Calculate byte positions and store each part as a range
        let mut current_position = 0u64;
        for part in &metadata.parts {
            let start = current_position;
            let end = start + part.size - 1;
            
            // Store this part as a range
            disk_cache.store_range(
                &cache_key,
                start,
                end,
                &part.data,
                metadata.clone()
            ).await?;
            
            current_position += part.size;
        }
        
        // Update metadata to mark upload as complete
        metadata.upload_state = UploadState::Complete;
        metadata.expires_at = SystemTime::now() + self.put_ttl;
        metadata.content_length = current_position;
        
        // Clear part data from metadata (now stored as ranges)
        metadata.parts.clear();
        
        disk_cache.update_metadata(&cache_key, metadata).await?;
    }
    
    Ok(())
}
```

#### 3. TTL Transition (Simplified)
```rust
// Transition from PUT_TTL to GET_TTL
pub async fn transition_write_cache_to_get_cache(&self, cache_key: &str) -> Result<()> {
    // Just update the TTL in metadata - data already in range format
    let mut disk_cache = self.disk_cache_manager.lock().await;
    
    // Update metadata to use GET_TTL instead of PUT_TTL
    if let Some(mut metadata) = disk_cache.get_metadata(cache_key).await? {
        metadata.expires_at = SystemTime::now() + self.get_ttl;
        disk_cache.update_metadata(cache_key, metadata).await?;
    }
    
    Ok(())
}
```

### Challenges and Considerations

#### 1. Multipart Part Byte Positions
**Problem:** S3 doesn't tell us the byte position of each part in the final object during upload.

**Solution:** Calculate positions from part numbers and sizes on CompleteMultipartUpload
- Store each part with its part number and size in metadata
- Parts can arrive out of order (part 3 before part 2 completes)
- On CompleteMultipartUpload:
  - Sort parts by part number
  - Calculate byte positions: Part 1 at 0, Part 2 at size1, Part 3 at size1+size2, etc.
  - Update metadata with final byte ranges
- Each part stored as a range once position is known

#### 2. Capacity Management
**Problem:** Multipart uploads can be very large and exceed cache capacity. Total size is unknown until CompleteMultipartUpload.

**Solution:** Incremental capacity checking as parts arrive
- **Cannot check total size upfront** - not known until completion
- Track cumulative size as each part arrives
- Before storing each part:
  - Calculate: current_cached_size + new_part_size
  - If sum exceeds write_cache_capacity:
    - Mark upload as "bypassed" in metadata
    - Clean up any already-cached parts
    - Stop caching this and subsequent parts
- This means some uploads may be partially cached before hitting limit
- Prevents cache thrashing from oversized uploads

#### 3. Conflict Handling
**Problem:** New upload to same key should invalidate in-progress multipart upload.

**Solution:** Invalidate on conflict
- On PutObject: Invalidate any cached data for that key
- On CreateMultipartUpload: Invalidate any existing cached data for that key
- Ensures cache consistency when uploads are overwritten or restarted

#### 4. Write Cache Directory Structure
**Current:** Separate `write_cache/` directory
**Proposed:** Use same `objects/` and `ranges/` directories

**Migration:**
- Add `upload_state` field to metadata (InProgress, Complete, Bypassed)
- Use PUT_TTL for expiration
- Transition updates state and TTL

#### 5. Metadata Structure
**New fields needed:**
```rust
pub enum UploadState {
    Complete,      // Regular PUT or completed multipart
    InProgress,    // Multipart upload in progress
    Bypassed,      // Upload too large, not caching
}

pub struct PartInfo {
    pub part_number: u32,
    pub size: u64,
    pub etag: String,
    pub data: Vec<u8>,  // Temporary storage until CompleteMultipartUpload
}

pub struct ObjectMetadata {
    // Existing fields...
    pub upload_state: UploadState,
    pub cumulative_size: u64,      // Running total of cached part sizes
    pub parts: Vec<PartInfo>,      // Parts awaiting assembly (cleared after complete)
    // ...
}

// Note: total_size is NOT known until CompleteMultipartUpload
// We track cumulative_size incrementally as parts arrive
```

#### 6. Backward Compatibility
**Concern:** Existing cached data in old format

**Solution:**
- Detect old format on read
- Convert to new format lazily
- Or: Clear cache on upgrade (acceptable for cache)

### Performance Impact

#### Positive
- ✅ Range requests from write cache (no S3 fetch)
- ✅ No data copying on transition
- ✅ Unified code paths (less complexity)
- ✅ Multipart parts usable for range requests
- ✅ Capacity-aware caching prevents cache thrashing
- ✅ Conflict handling ensures cache consistency

#### Neutral
- ≈ Storage overhead similar (metadata slightly larger with upload_state)
- ≈ Write performance similar (same compression)

#### Potential Concerns
- ⚠️ Metadata updates more frequent (TTL transitions, upload state)
- ⚠️ Need to track cumulative size during multipart uploads
- ⚠️ Invalidation on conflict requires cleanup of partial data

## Recommendation

**YES - Unify on range storage format**

### Implementation Priority

1. **Phase 1:** Write cache as ranges
   - Highest value - enables range requests from PUT cache
   - Simplest to implement
   - Foundation for multipart support

2. **Phase 2:** Simplify TTL transitions
   - Remove data copying
   - Just update metadata

3. **Phase 3:** Multipart as ranges
   - Store parts as ranges within single object
   - Track upload state and cumulative size
   - Implement capacity checking and bypass logic
   - Add conflict invalidation on new uploads

### Next Steps

1. Update `store_write_cache_entry` to use `store_full_object_as_range`
2. Update `transition_write_cache_to_get_cache` to only update metadata
3. Add `UploadState` enum and update `ObjectMetadata` structure
4. Implement `initiate_multipart_upload` with capacity checking
5. Update `store_multipart_part` to:
   - Store part info (number, size, data) in metadata
   - Check capacity constraints
   - Handle out-of-order part arrivals
6. Implement `complete_multipart_upload` to:
   - Sort parts by part number
   - Calculate byte positions from part sizes
   - Store each part as a range
   - Mark upload complete and clear temporary part data
7. Add invalidation logic to PutObject and CreateMultipartUpload handlers
8. Add tests for:
   - Range requests from write cache
   - Multipart uploads as single object
   - Capacity bypass for large uploads
   - Conflict invalidation
9. Update documentation

## Code Changes Required

### Files to Modify
- `src/cache.rs` - Write cache storage functions
- `src/http_proxy.rs` - PUT request handling
- `src/disk_cache.rs` - Metadata structure (add PUT_TTL field)
- Tests - Add range request tests for write cache

### Estimated Effort
- **Phase 1 (Write cache):** 2-3 hours
- **Phase 2 (Transitions):** 1-2 hours
- **Phase 3 (Multipart):** 5-7 hours
  - Metadata structure updates (PartInfo, upload_state): 1 hour
  - Part storage with out-of-order handling: 1.5 hours
  - CompleteMultipartUpload assembly logic: 1.5 hours
  - Capacity management: 1.5 hours
  - Conflict invalidation: 0.5 hours
  - Testing: 2 hours

Total: ~8-12 hours for complete implementation
