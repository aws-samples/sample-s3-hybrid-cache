# Connection Pooling Optimization Analysis

## Current State

### What We Have Now
- **Metadata-only connection pool**: Tracks connection IDs, IP addresses, and metrics
- **Connection creation per request**: Each request creates a new TCP connection and TLS handshake
- **Connection release**: Metadata is released back to pool, but actual socket is closed
- **Load balancing**: Round-robin across multiple S3 IP addresses

### Performance Impact
Looking at the logs, each request shows:
```
INFO Created new connection <uuid> for IP <ip>
```

This means:
1. **TCP handshake** (~1 RTT): SYN, SYN-ACK, ACK
2. **TLS handshake** (~2 RTTs): ClientHello, ServerHello, Certificate exchange, Finished
3. **HTTP request/response** (~1 RTT)

**Total: ~4 RTTs per request** (approximately 40-80ms for typical AWS latencies)

## Optimization Opportunities

### 1. HTTP/1.1 Keep-Alive Connection Reuse ⭐⭐⭐
**Impact**: HIGH - Eliminates TCP + TLS handshake overhead
**Complexity**: HIGH
**Savings**: ~3 RTTs per request (30-60ms)

#### Current Architecture Issue
```rust
// In send_http_request():
let (mut sender, conn) = http1::handshake(io).await?;
// ... send request ...
conn_task.abort();  // ❌ Connection is closed here
```

The connection is aborted after each request, preventing reuse.

#### Solution Approach
Use Hyper's connection pooling with `hyper::client::Client`:

```rust
// Instead of manual http1::handshake, use Client with pooling
use hyper::client::Client;
use hyper_rustls::HttpsConnectorBuilder;

let https = HttpsConnectorBuilder::new()
    .with_native_roots()
    .https_or_http()
    .enable_http1()
    .build();

let client = Client::builder()
    .pool_idle_timeout(Duration::from_secs(90))
    .pool_max_idle_per_host(10)
    .build(https);
```

**Benefits**:
- Automatic connection reuse
- Built-in idle timeout management
- Connection health checking
- Thread-safe connection sharing

**Challenges**:
- Need to refactor `S3Client` to use `hyper::Client` instead of manual connections
- Need to integrate with existing IP-based load balancing
- Need to handle connection pool per S3 endpoint

### 2. HTTP/2 Multiplexing ⭐⭐
**Impact**: MEDIUM-HIGH - Multiple requests over single connection
**Complexity**: MEDIUM
**Savings**: Eliminates per-request overhead entirely for concurrent requests

S3 supports HTTP/2. Benefits:
- **Request multiplexing**: Multiple requests on one TCP connection
- **Header compression**: HPACK reduces header overhead
- **Server push**: Potential for proactive caching

```rust
let https = HttpsConnectorBuilder::new()
    .with_native_roots()
    .https_only()
    .enable_http2()  // Enable HTTP/2
    .build();
```

**Challenges**:
- Need to verify S3 HTTP/2 support across all regions
- More complex error handling
- Potential head-of-line blocking issues

### 3. Connection Pre-warming ⭐
**Impact**: LOW-MEDIUM - Reduces first-request latency
**Complexity**: LOW

Pre-establish connections to S3 endpoints on startup:

```rust
pub async fn prewarm_connections(&mut self, endpoint: &str, count: usize) -> Result<()> {
    for _ in 0..count {
        let connection = self.create_connection(endpoint).await?;
        self.release_connection(endpoint, &connection.id)?;
    }
    Ok(())
}
```

### 4. DNS Caching Optimization ⭐
**Impact**: LOW - Already implemented
**Complexity**: N/A

Current implementation already caches DNS results and rotates through IPs.

## Recommended Implementation Plan

### Phase 1: HTTP/1.1 Keep-Alive (Highest Priority)
**Estimated effort**: 2-3 days
**Expected improvement**: 40-60% reduction in request latency for non-cached requests

1. Refactor `S3Client` to use `hyper::Client` with connection pooling
2. Integrate with existing `ConnectionPoolManager` for metrics and load balancing
3. Configure appropriate idle timeouts (90 seconds recommended)
4. Test connection reuse with multiple sequential requests

### Phase 2: HTTP/2 Support (Optional)
**Estimated effort**: 1-2 days
**Expected improvement**: Additional 10-20% for concurrent requests

1. Enable HTTP/2 in connector configuration
2. Test with S3 endpoints
3. Monitor for any compatibility issues
4. Implement fallback to HTTP/1.1 if needed

### Phase 3: Connection Pre-warming (Nice to have)
**Estimated effort**: 0.5 days
**Expected improvement**: Eliminates first-request latency spike

1. Add pre-warming on server startup
2. Pre-warm on DNS refresh
3. Configure number of connections per endpoint

## Current Workaround Enabled

✅ **Connection metadata pooling**: We've enabled the release of connection metadata back to the pool, which helps with:
- Load balancing metrics
- Connection count tracking
- Health monitoring
- IP rotation

However, this doesn't provide the latency benefits of true connection reuse since we're still creating new TCP/TLS connections for each request.

## Performance Comparison

### Current (No Connection Reuse)
```
Request 1: TCP (20ms) + TLS (40ms) + HTTP (20ms) = 80ms
Request 2: TCP (20ms) + TLS (40ms) + HTTP (20ms) = 80ms
Request 3: TCP (20ms) + TLS (40ms) + HTTP (20ms) = 80ms
Total: 240ms for 3 requests
```

### With HTTP/1.1 Keep-Alive
```
Request 1: TCP (20ms) + TLS (40ms) + HTTP (20ms) = 80ms
Request 2: HTTP (20ms) = 20ms  ← Reuses connection
Request 3: HTTP (20ms) = 20ms  ← Reuses connection
Total: 120ms for 3 requests (50% faster)
```

### With HTTP/2 Multiplexing
```
Request 1: TCP (20ms) + TLS (40ms) + HTTP (20ms) = 80ms
Request 2: HTTP (0ms) = 0ms   ← Multiplexed on same connection
Request 3: HTTP (0ms) = 0ms   ← Multiplexed on same connection
Total: 80ms for 3 concurrent requests (67% faster)
```

## Testing Strategy

1. **Benchmark current performance**: Measure latency for sequential requests
2. **Implement HTTP/1.1 keep-alive**: Refactor to use `hyper::Client`
3. **Verify connection reuse**: Check logs for "reusing connection" messages
4. **Measure improvement**: Compare before/after latency
5. **Load test**: Ensure connection pool handles high concurrency
6. **Monitor connection leaks**: Verify connections are properly closed on idle timeout

## Conclusion

The biggest optimization opportunity is implementing true HTTP/1.1 connection reuse with `hyper::Client`. This would eliminate 3 out of 4 RTTs for subsequent requests, providing a **40-60% latency reduction** for non-cached S3 requests.

The current metadata-only pooling is a good foundation for metrics and load balancing, but doesn't provide the performance benefits of actual connection reuse.
