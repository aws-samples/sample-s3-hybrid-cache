# Size Tracking Bug Analysis

## Problem
Disk usage (du): 47MB (11 range files)
Size state tracking: 1.5GB

This is a ~30x discrepancy.

## Root Cause Found

The bug is in `validate_journal_entries_with_staleness()` in `src/journal_consolidator.rs` (lines 1468-1540).

### The Issue

When a range file doesn't exist but the journal entry is recent (within 5 minutes), the entry is added to `valid_entries`:

```rust
} else {
    // Entry is recent - may still be streaming, keep it
    valid_entries.push(entry.clone());
    debug!(
        "Journal entry retained (recent, may be streaming): cache_key={}, range={}-{}, age={:.1}s",
        ...
    );
}
```

### Bug Scenario

1. Download starts, journal entry is written with `compressed_size = X`
2. Before range file is fully written (or visible due to NFS caching), consolidation runs
3. Entry is recent (< 5 min), so it's added to `valid_entries`
4. Range doesn't exist in metadata, so it's added to metadata AND `applied_entries`
5. Size delta is calculated from `applied_entries`: size += X
6. Entry is removed from journal (because it's in `valid_entries`)
7. Range file write fails or never completes
8. **Result: Size was added but range file doesn't exist**

Or alternatively:

1. Download completes, journal entry written, range file written
2. Consolidation runs: entry validated (file exists), applied to metadata, size += X
3. Eviction runs: range file deleted, metadata updated, size -= X
4. Download same range again
5. Journal entry written
6. Before range file is written, consolidation runs
7. Entry is recent, added to `valid_entries`
8. Range NOT in metadata (was removed in step 3), so it's added
9. Size delta calculated: size += X
10. Entry removed from journal
11. Range file write fails
12. **Result: Size was added but range file doesn't exist**

### Why This Causes 30x Discrepancy

With NFS/EFS, there can be significant delays between:
- Journal entry being written
- Range file becoming visible to other instances

If consolidation runs during this window (every 5 seconds), entries with missing files are processed and counted in size delta. The entry is then removed from the journal, so even when the file becomes visible, it won't be re-processed.

Over time, with many downloads and evictions, this accumulates into a large discrepancy.

### The Fix

In `validate_journal_entries_with_staleness()`, entries with missing range files should NOT be added to `valid_entries`. They should be excluded entirely:

Current code (WRONG):
```rust
} else {
    // Entry is recent - may still be streaming, keep it
    valid_entries.push(entry.clone());  // BUG: This causes size to be counted
}
```

Fixed code:
```rust
} else {
    // Entry is recent - may still be streaming
    // Do NOT add to valid_entries - this prevents size from being counted
    // Entry will remain in journal and be retried next cycle
    debug!(
        "Journal entry pending (recent, may be streaming): cache_key={}, range={}-{}, age={:.1}s",
        ...
    );
    // Entry is NOT added to any list, so it stays in journal for retry
}
```

### Additional Issue

The `pending_count` calculation is also wrong:
```rust
let pending_count = all_entries.len() - valid_entries.len() - stale_count;
```

This assumes pending entries are NOT in `valid_entries`, but they ARE. With the fix above, this calculation will be correct.

### Alternative Fix: Return Three Lists

Return a third list from `validate_journal_entries_with_staleness()`:
```rust
(valid_entries, stale_entries, pending_entries)
```

Where:
- `valid_entries`: Range file exists - process for size delta, remove from journal
- `stale_entries`: Range file missing AND entry is old (> 5 min) - remove from journal
- `pending_entries`: Range file missing AND entry is recent (< 5 min) - keep in journal

Only `valid_entries` should be processed for size delta calculation.
Only `valid_entries` and `stale_entries` should be removed from journal.
`pending_entries` stay in journal for retry on next consolidation cycle.
