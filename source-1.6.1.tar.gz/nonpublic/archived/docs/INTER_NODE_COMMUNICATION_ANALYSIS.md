# Inter-Node Communication Analysis

Analysis of whether proxy nodes should communicate directly with each other vs. the current shared-storage coordination approach.

## Current Architecture

Proxy nodes coordinate via shared storage (EFS/NFS):
- Journal-based metadata updates
- File locking for atomic operations
- TTL-based cache consistency
- No direct node-to-node communication

## What Inter-Node Communication Would Enable

### Cache Coordination
- Eliminate journal consolidation — leader maintains authoritative state
- No file locking contention on shared storage
- Instant cache invalidation broadcast vs. polling/TTL
- Coordinated eviction — leader decides globally, no duplicate work

### Request Routing
- Cache-aware load balancing — route to nodes with cached data
- Reduce redundant S3 fetches — fetch from peer instead of S3
- Distributed RAM cache — partition hot data across nodes

### Performance
- Sub-millisecond coordination vs. NFS latency (10-50ms)
- Eliminate metadata lock contention
- Faster warmup — new nodes pull from peers

## Risks for Ephemeral Node Design

### State Coupling
- Leader failure becomes cluster-wide event
- Network partitions create split-brain scenarios
- Node replacement requires membership change handling

### Startup Dependencies
- Nodes must discover cluster before serving traffic
- Bootstrap problem on full cluster restart
- Health checks become complex (peer connectivity)

### Ephemeral Nature Conflicts
- Current: nodes are stateless, interchangeable, can die anytime
- With coordination: nodes have identity, relationships, state
- Auto-scaling requires cluster reconfiguration

## Additional Problems

### Complexity
- Consensus protocol (Raft/Paxos) or leader election
- Network protocol design and versioning
- Distributed state debugging

### Failure Modes
- Network partitions between nodes (but not to S3/clients)
- Clock skew issues
- Cascading failures from slow nodes

### Operational Overhead
- Additional ports for inter-node communication
- mTLS between nodes
- Cluster health monitoring

### Edge Cases
- Nodes reach S3 but not each other
- Peer response timeout vs. S3 fallback
- Stale peer data vs. fresh S3 data

## Decision: Shared Storage Approach

| Aspect | Shared Storage | Inter-Node |
|--------|---------------|------------|
| Complexity | Medium | High |
| Failure isolation | Good | Poor |
| Ephemeral-friendly | Yes | Partially |
| Latency | NFS-bound (10-50ms) | Sub-ms |
| Operational burden | Low | Medium-High |

### Rationale

1. **Simplicity**: Journal system is "coordination via shared storage" — fewer failure modes
2. **Failure isolation**: One node dying doesn't affect others
3. **Ephemeral alignment**: Nodes remain stateless and interchangeable
4. **Sufficient performance**: NFS latency acceptable for metadata operations
5. **TTL-based consistency**: Adequate for caching use case

### When to Reconsider

- NFS latency becomes a bottleneck (unlikely for metadata)
- Real-time cache coherence required (TTL approach currently sufficient)
- Distributed RAM cache needed (significant complexity for marginal gain)

### Alternative for Cache-Aware Routing

If cache locality becomes important, consider consistent hashing at the load balancer level — same objects route to same node without inter-node communication.

## Conclusion

The shared-storage coordination approach is the right tradeoff for an ephemeral proxy design. Inter-node communication would add significant complexity and failure modes for benefits that don't justify the cost in this architecture.
