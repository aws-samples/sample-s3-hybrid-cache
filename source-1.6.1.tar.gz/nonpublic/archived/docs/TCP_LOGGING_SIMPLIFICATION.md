# TCP Passthrough Logging Simplification

## Summary

Simplified TCP tunnel logging from 3 INFO messages per connection to 1 consolidated message, reducing log verbosity by 67% while maintaining all essential information.

## Changes Made

### Before (3 log lines per connection):
```
INFO TCP tunnel established: [::ffff:127.0.0.1]:60879 <-> s3.eu-west-1.amazonaws.com:443
INFO TCP tunnel statistics for [::ffff:127.0.0.1]:60879 <-> s3.eu-west-1.amazonaws.com:443: client->server: 0 bytes, server->client: 29652 bytes
INFO TCP tunnel closed normally: [::ffff:127.0.0.1]:60879 <-> s3.eu-west-1.amazonaws.com:443
INFO TCP connection from [::ffff:127.0.0.1]:60879 completed successfully in 19.721054625s
```

### After (1 log line per connection):
```
INFO TCP tunnel completed: 127.0.0.1:60879 <-> s3.eu-west-1.amazonaws.com:443 | duration: 19.7s | rx: 29.0KB, tx: 0B
```

## Improvements

1. **Reduced verbosity**: 3-4 INFO lines → 1 INFO line per connection
2. **Human-readable formatting**:
   - Duration: `19.7s` instead of `19.721054625s`
   - Bytes: `29.0KB` instead of `29652 bytes`
   - Address: `127.0.0.1:60879` instead of `[::ffff:127.0.0.1]:60879`
3. **Single-line format**: All essential info in one compact line
4. **Clearer labels**: `rx` (received from server) and `tx` (transmitted to server)

## Implementation Details

### Modified Functions

1. **`forward_tcp_traffic()`**:
   - Now returns `Result<(u64, u64)>` with (tx_bytes, rx_bytes)
   - Removed internal statistics logging
   - Returns byte counts for parent function to log

2. **`establish_tcp_tunnel()`**:
   - Moved "established" log to DEBUG level
   - Added single INFO log at completion with all statistics
   - Includes duration, formatted bytes, and simplified addresses

3. **Added helper functions**:
   - `format_addr()`: Simplifies IPv6-mapped IPv4 addresses
   - `format_bytes()`: Converts bytes to human-readable format (B/KB/MB/GB)

### Error Handling

- Error logs remain detailed with duration and context
- Connection establishment errors still logged at ERROR level
- No loss of diagnostic information for troubleshooting

## Benefits

- **Cleaner logs**: Easier to scan and read in production
- **Reduced I/O**: 67% fewer log writes per connection
- **Better readability**: Human-friendly units and formatting
- **Maintained observability**: All essential metrics still captured
- **Consistent format**: Predictable single-line format for log parsing

## Testing

- Code compiles successfully with no errors
- All existing tests pass
- No functional changes to TCP tunneling behavior
