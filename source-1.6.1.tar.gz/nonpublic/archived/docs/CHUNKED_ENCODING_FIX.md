# Chunked Encoding Fix for Multipart Upload

## Problem

When uploading files via multipart upload through the proxy, S3 was returning 400 Bad Request errors for some parts. Investigation revealed that:

1. **AWS CLI sends chunked-encoded data**: When uploading multipart parts, the AWS CLI sends the request body with HTTP chunked transfer encoding (format: `<hex-size>\r\n<data>\r\n`)
2. **Proxy was stripping encoding before forwarding**: The proxy detected and stripped the chunked encoding (~10 bytes of framing), reducing the body from 8,388,662 bytes to 8,388,608 bytes
3. **Content-Length mismatch**: The proxy then forwarded the stripped body to S3 but kept the original `Content-Length: 8388662` header
4. **S3 rejected the request**: S3 received a request claiming 8,388,662 bytes but only got 8,388,608 bytes, returning 400 Bad Request

## Root Cause

The proxy was stripping chunked encoding from the request body before forwarding to S3, but S3 expects to receive the original request with the correct Content-Length matching the actual body size.

## Solution

**Separate the forwarding path from the caching path:**

1. **Forward ORIGINAL body to S3**: Send the complete request body with chunked encoding intact to S3, preserving all original headers including Content-Length
2. **Strip encoding ONLY for caching**: When caching the part data, strip the chunked encoding framing to store clean 8,388,608 byte parts

## Implementation

### Before (Buggy)
```rust
// Read body
let mut body_bytes = collected.to_bytes();

// Strip chunked encoding (modifies body_bytes)
if chunked_detected {
    body_bytes = body_bytes.slice(chunk_start..chunk_end);
}

// Forward stripped body to S3 ❌ WRONG
raw_request.extend_from_slice(&body_bytes);

// Cache stripped body
cache_upload_part(&body_bytes);
```

### After (Fixed)
```rust
// Read body
let original_body_bytes = collected.to_bytes();

// Strip chunked encoding ONLY for caching
let cache_body_bytes = if chunked_detected {
    original_body_bytes.slice(chunk_start..chunk_end)
} else {
    original_body_bytes.clone()
};

// Forward ORIGINAL body to S3 ✓ CORRECT
raw_request.extend_from_slice(&original_body_bytes);

// Cache stripped body
cache_upload_part(&cache_body_bytes);
```

## Results

- ✅ S3 receives the correct request body with matching Content-Length
- ✅ No more 400 Bad Request errors
- ✅ Cached parts are exactly 8,388,608 bytes (8 MiB) without HTTP framing
- ✅ Part boundaries align correctly: `0-8388607`, `8388608-16777215`, etc.
- ✅ Range serving works correctly with properly aligned cached data

## Files Modified

- `src/signed_put_handler.rs`: Updated `handle_upload_part()` to separate original body (for S3) from cache body (stripped)

## Testing

Verified with multipart upload of Archive.zip:
- All parts uploaded successfully without 400 errors
- Cached parts show correct sizes (8,388,608 bytes each)
- Logs confirm: "Stripped chunked encoding for part N (caching only): 8388618 bytes -> 8388608 bytes"

## Related Issues

This fix addresses the root cause identified in the range-slice-bug-fix spec, where cached parts had incorrect byte boundaries due to HTTP framing being included in cached data.
