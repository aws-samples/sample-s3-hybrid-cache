# Range Merging Analysis: Current Issues and Proposed Solution

## Current Behavior

### Problem 1: Unnecessary S3 Fetches for Partial Cache Hits

When a GET request requires bytes that are partially cached:

**Current Flow:**
1. Client requests `bytes=0-104857599` (100MB)
2. Cache has ranges: `0-8388607`, `8388608-16777215`, `16777216-25165823`, etc.
3. Cache lookup finds overlapping ranges but determines `can_serve_from_cache = false` because one range is missing
4. **Entire request is forwarded to S3** requesting `bytes=0-104857599`
5. S3 returns all 100MB
6. Response is cached and returned to client

**Issues:**
- Wastes S3 bandwidth (fetches bytes we already have)
- Slower response time (fetches more data than needed)
- Inefficient cache utilization

### Problem 2: Multipart Upload Range Alignment

When a multipart upload is finalized:

**Current Flow:**
1. Parts are uploaded (e.g., 13 parts of 8MB each)
2. Finalization creates range files from parts
3. Range files are created with part boundaries (0-8388607, 8388608-16777215, etc.)
4. First GET request after finalization requests `bytes=0-8388607`
5. **Sometimes the range file isn't found** due to race condition
6. System fetches from S3 instead of using cached data

**Issues:**
- Race condition between metadata write and range file creation
- First GET after upload should be fully cached but isn't
- Non-atomic file operations cause inconsistency

## Root Causes

### 1. `forward_range_request_to_s3` Ignores Cached Ranges

```rust
async fn forward_range_request_to_s3(
    // ...
    _overlap: crate::range_handler::RangeOverlap,  // ← UNUSED!
    // ...
) {
    // Forwards ENTIRE requested range to S3
    s3_headers.insert("range".to_string(), 
        format!("bytes={}-{}", range_spec.start, range_spec.end));
}
```

The `_overlap` parameter contains information about cached ranges but is never used.

### 2. No Range Merging Implementation

```rust
} else {
    // Multiple cached ranges need to be merged
    // TODO: Implement range merging for response
    error!("Multiple cached ranges merging not yet implemented");
    return Ok(Self::build_error_response(
        StatusCode::NOT_IMPLEMENTED,
        "NotImplemented",
        "Multiple cached ranges merging not yet implemented.",
        None,
    ));
};
```

The code explicitly states that merging multiple cached ranges is not implemented.

### 3. Non-Atomic Range File Creation

In multipart upload finalization, range files and metadata are written separately without proper synchronization, creating a window where metadata exists but range files don't.

## Proposed Solution

### Phase 1: Atomic File Operations (COMPLETED ✅)

**Implemented in previous session:**
- Write range files to `.tmp` extension first
- Atomically rename to final location
- Write metadata file only after all range files exist
- Added compression to multipart upload parts

**Benefits:**
- Eliminates race conditions
- Ensures consistency between metadata and range files
- First GET after multipart upload is fully cached

### Phase 2: Intelligent Range Merging (PROPOSED)

**Implementation Plan:**

#### 2.1 Fetch Only Missing Ranges

```rust
async fn forward_range_request_to_s3(
    // ...
    overlap: crate::range_handler::RangeOverlap,  // Use it!
    // ...
) {
    // Instead of fetching entire range, fetch only missing portions
    for missing_range in overlap.missing_ranges {
        // Fetch missing_range from S3
        // Cache the fetched data
    }
    
    // Merge cached + fetched ranges
    let merged_data = merge_ranges(
        &overlap.cached_ranges,
        &fetched_ranges,
        &range_spec
    );
    
    // Return merged response
}
```

#### 2.2 Implement Range Merging Logic

```rust
fn merge_ranges(
    cached_ranges: &[Range],
    fetched_ranges: &[Range],
    requested_range: &RangeSpec,
) -> Result<Vec<u8>> {
    // 1. Combine all available ranges (cached + fetched)
    // 2. Sort by start position
    // 3. Extract requested bytes from each range
    // 4. Concatenate in order
    // 5. Validate total size matches request
}
```

#### 2.3 Optimize S3 Fetch Consolidation

```rust
fn consolidate_missing_ranges(
    missing_ranges: Vec<RangeSpec>,
    max_gap_size: u64,
) -> Vec<RangeSpec> {
    // If gaps between missing ranges are small, fetch as one range
    // Example: Missing [100-200] and [250-300] with gap of 50 bytes
    // Fetch [100-300] instead of two separate requests
}
```

### Phase 3: Enhanced Logging and Metrics

Add detailed logging for:
- Cache hit ratio per request
- Bytes served from cache vs S3
- Range merging operations
- Performance metrics

## Expected Benefits

### Performance Improvements

**Scenario: 100MB file, 90% cached, 10% missing**

Current:
- Fetch: 100MB from S3
- Time: ~2 seconds
- Bandwidth: 100MB

With Range Merging:
- Fetch: 10MB from S3 (only missing portions)
- Time: ~0.5 seconds (90MB from fast cache + 10MB from S3)
- Bandwidth: 10MB
- **Savings: 90% bandwidth, 75% faster**

### Cost Savings

For a proxy serving 1TB/day with 80% cache hit rate:
- Current: 1TB S3 bandwidth (partial hits refetch everything)
- With merging: ~200GB S3 bandwidth (only fetch missing portions)
- **Savings: 80% reduction in S3 data transfer costs**

### Reliability Improvements

- First GET after multipart upload is always fully cached
- No race conditions in range file creation
- Consistent behavior regardless of range alignment

## Implementation Priority

1. ✅ **Phase 1 (COMPLETED)**: Atomic file operations for multipart uploads
2. **Phase 2 (HIGH PRIORITY)**: Intelligent range merging
   - Implement merge_ranges function
   - Update forward_range_request_to_s3 to use overlap data
   - Add range consolidation logic
3. **Phase 3 (MEDIUM PRIORITY)**: Enhanced observability
   - Add cache efficiency metrics
   - Improve logging for troubleshooting

## Testing Strategy

### Unit Tests
- Test range extraction from cached data
- Test range merging with various overlap patterns
- Test edge cases (empty ranges, single bytes, max size)

### Property-Based Tests
- For any requested range and any set of cached ranges, merged result should match S3 response
- For any set of missing ranges, consolidated ranges should cover the same bytes
- For any merge operation, output size should equal requested range size

### Integration Tests
- Test multipart upload followed by immediate GET
- Test partial cache hits with various overlap patterns
- Test performance improvements with real S3 backend

## Next Steps

1. Review and approve requirements document
2. Create design document with detailed implementation plan
3. Implement range merging logic
4. Add comprehensive tests
5. Deploy and monitor performance improvements
