# Signed PUT Caching Fixes

## Issues Found and Fixed

### Issue 1: CompleteMultipartUpload Not Being Handled
**Problem:** POST requests for CompleteMultipartUpload were being forwarded without modification instead of being routed to the SignedPutHandler. This meant:
- Multipart upload parts were cached successfully
- But the final metadata linking all parts together was never created
- GET requests couldn't be served from cache because the metadata was incomplete

**Root Cause:** The `handle_other_request` method detected signed POST requests and forwarded them directly to S3, bypassing the multipart completion logic.

**Fix:** Modified `handle_other_request` to:
1. Detect CompleteMultipartUpload POST requests (has `uploadId` but no `partNumber` in query)
2. Route them to `handle_put_request` which then calls SignedPutHandler
3. SignedPutHandler detects CompleteMultipartUpload and calls `finalize_multipart_upload`

**Files Changed:**
- `src/http_proxy.rs`: Updated `handle_other_request` signature and logic

### Issue 2: Wrong Directory for Multipart Uploads
**Problem:** The code was using `parts/` directory for multipart uploads in progress, but the system uses `mpus_in_progress/` directory.

**Fix:** Updated all references from `parts/` to `mpus_in_progress/`

**Files Changed:**
- `src/signed_put_handler.rs`: Updated `cache_upload_part` and `finalize_multipart_upload` methods

## How It Works Now

### Multipart Upload Flow:
1. **UploadPart (PUT with uploadId and partNumber)**
   - Detected by SignedPutHandler
   - Part data cached to `mpus_in_progress/{upload_id}/part_{N}.bin`
   - Part metadata cached to `mpus_in_progress/{upload_id}/part_{N}.meta`
   - Upload metadata updated with cumulative size

2. **CompleteMultipartUpload (POST with uploadId, no partNumber)**
   - Now correctly routed to SignedPutHandler
   - `finalize_multipart_upload` is called
   - All parts are read and converted to range files in `ranges/`
   - Object metadata is created in `objects/` with correct content_length
   - Multipart directory is cleaned up

3. **GET Requests**
   - Can now be served from cache using the range files
   - Metadata has correct content_length and range information

## Testing Needed

After restarting the proxy, test:
1. Upload a large file via multipart upload
2. Verify CompleteMultipartUpload is detected and handled
3. Verify metadata is created with correct content_length
4. Verify GET requests are served from cache
5. Check metrics are recorded correctly

## Remaining Issues

### Metrics Not Recorded for Multipart Uploads
The `handle_upload_part` method successfully caches parts but doesn't call:
- `record_cached_put()` for successful caching
- `record_put_cache_failure()` for failures

This should be added in a future fix to track multipart upload caching in metrics.
