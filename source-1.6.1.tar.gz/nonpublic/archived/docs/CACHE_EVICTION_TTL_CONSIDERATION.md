# Cache Eviction TTL Prioritization - Future Consideration

## Issue Summary

The current cache eviction logic does not prioritize expired entries for removal when capacity limits are reached. This means that valid, non-expired cached data may be evicted before expired entries, which is suboptimal.

## Current Behavior

### Eviction Logic (`src/cache.rs`)

1. **`collect_cache_entries_for_eviction()` (line ~3001)**
   - Collects cache entries with: `(cache_key, last_accessed, size)`
   - Uses `created_at` as a proxy for `last_accessed`
   - **Does NOT collect or check the `expires_at` field**

2. **`sort_entries_for_eviction()` (line ~3090)**
   - Sorts entries only by `last_accessed` time (LRU algorithm)
   - Falls back to LRU for LFU and TinyLFU (due to lack of frequency tracking)
   - **Does NOT consider TTL expiration**

3. **`actively_remove_cached_data` flag**
   - Stored in `CacheManager` struct
   - **Never actually used in eviction logic**
   - Intended to control whether expired entries are actively removed vs. lazily removed on access

### Data Structures

- **`CacheEntry`** (`src/cache_types.rs`):
  - Has `expires_at: SystemTime` field (data TTL based on `get_ttl`)
  - Has `metadata_expires_at: SystemTime` field (metadata validation TTL based on `head_ttl`)
  - Has `created_at: SystemTime` field (used as last access proxy)

- **`NewCacheMetadata`** (`src/cache_types.rs`):
  - Has `expires_at: SystemTime` field
  - Has `created_at: SystemTime` field

## Expected Behavior

When `actively_remove_cached_data` is `false`:
- Expired entries should be **prioritized for removal** during capacity-based eviction
- The eviction process should:
  1. First remove all expired entries (where `SystemTime::now() > expires_at`)
  2. Only after expired entries are exhausted, apply the configured eviction algorithm (LRU/LFU/TinyLFU) to non-expired entries

This ensures that:
- Valid cached data is preserved as long as possible
- Expired data is cleaned up opportunistically during capacity pressure
- The `actively_remove_cached_data` flag has meaningful behavior

## Recommended Implementation

### 1. Update `collect_cache_entries_for_eviction()`

Change return type from:
```rust
Vec<(String, SystemTime, u64)>  // (cache_key, last_accessed, size)
```

To:
```rust
Vec<(String, SystemTime, u64, SystemTime)>  // (cache_key, last_accessed, size, expires_at)
```

Collect the `expires_at` field from:
- `CacheEntry.expires_at` for legacy format
- `NewCacheMetadata.expires_at` for new format

### 2. Update `sort_entries_for_eviction()`

Implement TTL-aware sorting:

```rust
fn sort_entries_for_eviction(&self, entries: &mut Vec<(String, SystemTime, u64, SystemTime)>) {
    let now = SystemTime::now();
    
    // Separate expired from non-expired entries
    let (mut expired, mut valid): (Vec<_>, Vec<_>) = entries
        .drain(..)
        .partition(|(_, _, _, expires_at)| now > *expires_at);
    
    // Sort expired entries by expiration time (most expired first)
    expired.sort_by_key(|(_, _, _, expires_at)| *expires_at);
    
    // Sort valid entries by configured algorithm
    match self.eviction_algorithm {
        CacheEvictionAlgorithm::LRU => {
            valid.sort_by_key(|(_, last_accessed, _, _)| *last_accessed);
        }
        CacheEvictionAlgorithm::LFU => {
            // Fall back to LRU until frequency tracking is implemented
            warn!("LFU algorithm requested but frequency data not available, using LRU fallback");
            valid.sort_by_key(|(_, last_accessed, _, _)| *last_accessed);
        }
        CacheEvictionAlgorithm::TinyLFU => {
            // Fall back to LRU until frequency tracking is implemented
            warn!("TinyLFU algorithm requested but frequency data not available, using LRU fallback");
            valid.sort_by_key(|(_, last_accessed, _, _)| *last_accessed);
        }
    }
    
    // Prioritize expired entries for eviction
    entries.clear();
    entries.extend(expired);
    entries.extend(valid);
    
    debug!(
        "Sorted {} entries for eviction: {} expired, {} valid (using {:?} algorithm)",
        entries.len(),
        entries.len() - valid.len(),
        valid.len(),
        self.eviction_algorithm
    );
}
```

### 3. Use `actively_remove_cached_data` Flag

Add conditional logic to respect the flag:

```rust
fn sort_entries_for_eviction(&self, entries: &mut Vec<(String, SystemTime, u64, SystemTime)>) {
    // If actively_remove_cached_data is true, expired entries are already removed
    // during regular maintenance, so we don't need to prioritize them here
    if self.actively_remove_cached_data {
        // Use standard eviction algorithm without TTL prioritization
        match self.eviction_algorithm {
            CacheEvictionAlgorithm::LRU => {
                entries.sort_by_key(|(_, last_accessed, _, _)| *last_accessed);
            }
            // ... other algorithms
        }
    } else {
        // Prioritize expired entries for removal
        // (implementation as shown above)
    }
}
```

## Benefits

1. **Better cache efficiency**: Valid data stays cached longer
2. **Opportunistic cleanup**: Expired entries are removed during capacity pressure even when `actively_remove_cached_data` is false
3. **Meaningful flag behavior**: The `actively_remove_cached_data` flag actually affects eviction behavior
4. **Reduced S3 requests**: By keeping valid cached data longer, fewer requests need to go to S3

## Testing Considerations

When implementing this feature, add tests for:

1. **Expired entries prioritized**: Verify expired entries are evicted before valid ones
2. **Flag behavior**: Test both `actively_remove_cached_data` true and false
3. **Mixed scenarios**: Test with mix of expired and valid entries
4. **Algorithm compatibility**: Ensure works with LRU, LFU, and TinyLFU
5. **Edge cases**: 
   - All entries expired
   - No entries expired
   - Entries expiring during eviction process

## Related Code Locations

- `src/cache.rs`:
  - `collect_cache_entries_for_eviction()` (~line 3001)
  - `sort_entries_for_eviction()` (~line 3090)
  - `perform_eviction_with_lock()` (~line 2900)
  - `actively_remove_cached_data` field (~line 340)

- `src/cache_types.rs`:
  - `CacheEntry` struct (line 12)
  - `NewCacheMetadata` struct (line 150)

- `src/config.rs`:
  - `actively_remove_cached_data` configuration option

## Priority

**Medium** - This is an optimization that improves cache efficiency but doesn't affect correctness. The current behavior is functional, just not optimal.

## Estimated Effort

**Small to Medium** - The changes are localized to a few methods in `cache.rs` and should be straightforward to implement with proper testing.

---

**Date Documented**: 2025-11-25  
**Documented By**: Development team during signed PUT caching implementation
