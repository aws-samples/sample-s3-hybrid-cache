# Streaming with Caching - Implementation Plan

## Current Status

✅ Phase 1: S3ResponseBody enum supports streaming
✅ Phase 2: HTTP responses use BoxBody
✅ TeeStream module created
❌ Streaming disabled (threshold = u64::MAX) to enable caching

## The Problem

When streaming is enabled:
- Data flows S3 → Proxy → Client (good for throughput)
- But stream is consumed, nothing left to cache (bad for caching)

When streaming is disabled:
- Data is buffered: S3 → Proxy buffer → Client (bad for throughput)
- Buffer can be cached (good for caching)

## The Solution: Tee Stream Architecture

```
S3 Response (streaming)
    ↓
TeeStream wrapper
    ├→ Client (streaming, immediate)
    └→ mpsc channel → Background task → Cache (buffered)
```

### Implementation Steps

1. **In range_handler.rs when fetching from S3:**
   - Create mpsc channel for cache data
   - Spawn background task to collect from channel and cache
   - Wrap S3 streaming body with TeeStream
   - Return wrapped stream to client

2. **Key code location:** `range_handler.rs` around line 2100 where we fetch ranges

3. **Pattern:**
```rust
// Create channel for cache data
let (cache_tx, mut cache_rx) = mpsc::channel(100);

// Spawn background cache task
let cache_key_clone = cache_key.clone();
tokio::spawn(async move {
    let mut accumulated = Vec::new();
    while let Some(chunk) = cache_rx.recv().await {
        accumulated.extend_from_slice(&chunk);
    }
    // Cache accumulated data
    range_handler.store_range(&cache_key_clone, &accumulated).await;
});

// Wrap streaming body with tee
let tee_body = TeeStream::new(streaming_body, cache_tx);

// Return tee'd stream to client
return Ok(S3ResponseBody::Streaming(tee_body));
```

## Next Steps

1. Lower streaming threshold back to 1MB
2. Modify range_handler to use TeeStream for S3 responses
3. Test that both streaming AND caching work
4. Verify throughput timeout is resolved

## Expected Outcome

- ✅ Data streams immediately to client (no throughput timeout)
- ✅ Data is cached in background (cache works)
- ✅ Memory usage stays constant (no buffering entire response)
- ✅ First byte latency < 100ms
