# Performance Improvements

Analysis of performance bottlenecks and improvement opportunities for S3 Proxy, focused on the range request hot path (8 MiB range GETs to large files over NFS/EFS shared cache).

## Table of Contents

- [Hot Path Analysis](#hot-path-analysis)
- [Bottleneck 1: Redundant NFS Metadata Reads](#bottleneck-1-redundant-nfs-metadata-reads)
- [Bottleneck 2: Full-Object Cache Check on Every Range Request](#bottleneck-2-full-object-cache-check-on-every-range-request)
- [Bottleneck 3: Metadata Cache Staleness Window](#bottleneck-3-metadata-cache-staleness-window)
- [Bottleneck 4: Synchronous Blocking I/O in get_metadata](#bottleneck-4-synchronous-blocking-io-in-get_metadata)
- [Bottleneck 5: Lock Contention on disk_cache_manager](#bottleneck-5-lock-contention-on-disk_cache_manager)
- [Bottleneck 6: Range Data Not Streamed from Disk](#bottleneck-6-range-data-not-streamed-from-disk)
- [Bottleneck 7: Consolidation Cycle Duration](#bottleneck-7-consolidation-cycle-duration)
- [Bottleneck 8: Metadata Re-read in serve_range_from_cache](#bottleneck-8-metadata-re-read-in-serve_range_from_cache)
- [Bottleneck 9: Connection Pool max_idle_per_host](#bottleneck-9-connection-pool-max_idle_per_host)
- [Next Steps](#next-steps)

---

## Hot Path Analysis

For a cached 8 MiB range GET, `handle_range_request` executes this sequence:

```
1. get_metadata_cached()          → RAM metadata cache lookup (or NFS read on miss/stale)
2. has_cached_ranges()            → get_metadata_from_disk() → NFS read (always)
3. find_cached_ranges() [full]    → disk_cache.read().await + get_metadata() → NFS read
4. find_cached_ranges() [range]   → disk_cache.read().await + get_metadata() → NFS read
5. check_range_expiration()       → disk_cache.read().await
6. serve_range_from_cache()       → load_range_data_with_cache() → RAM or NFS read
7. get_metadata_from_disk()       → NFS read (for response headers)
```

A single cache hit triggers up to 4-5 NFS metadata file reads and 1 NFS range data read. On EFS with ~1-5ms per NFS operation, this adds 5-25ms of pure I/O latency per request.

---

## Bottleneck 1: Redundant NFS Metadata Reads

**Impact: High**

The hot path reads the same `.meta` file from NFS multiple times per request:

1. `get_metadata_cached()` — step 1, uses RAM metadata cache (fast on hit)
2. `has_cached_ranges()` → calls `get_metadata_from_disk()` — bypasses RAM cache entirely
3. `find_cached_ranges()` for full object → calls `disk_cache.get_metadata()` — bypasses RAM cache
4. `find_cached_ranges()` for range → calls `disk_cache.get_metadata()` again — bypasses RAM cache
5. `serve_range_from_cache()` → calls `get_metadata_from_disk()` — bypasses RAM cache

Steps 2-5 all bypass the `MetadataCache` and read directly from NFS. The RAM metadata cache exists but only step 1 uses it.

**Fix**: Route `has_cached_ranges()` and `find_cached_ranges()` through `get_metadata_cached()` instead of reading from disk directly. Pass the already-loaded metadata through the call chain to avoid re-reads. The metadata loaded in step 1 contains everything needed for steps 2-5.

**Expected gain**: Eliminate 3-4 NFS reads per request (~3-20ms saved).

---

## Bottleneck 2: Full-Object Cache Check on Every Range Request

**Impact: High (standalone) / Low (if Bottleneck 1 is fixed)**

`handle_range_request` always checks if a full object is cached before falling back to range-specific lookup:

```rust
// Step 1: Check if full object is cached
match cache_manager.has_cached_ranges(&cache_key).await {
    Ok(Some((true, total_size))) => {
        // Build full_range = 0..total_size-1
        // Call find_cached_ranges for full object
        // If full object cached, filter and serve
    }
}

// Step 2: Fall back to range-specific lookup
match range_handler.find_cached_ranges(&cache_key, &range_spec, ...).await {
```

For a 5 GB file with 8 MiB range requests, the full-object check always fails (the file is cached as individual ranges, not as a single 0-5GB range). This wastes an NFS metadata read + a `find_cached_ranges` call with a 0-5GB range spec that scans all ~640 cached ranges.

**Dependency on Bottleneck 1**: If Bottleneck 1 is fixed (all metadata reads routed through the RAM metadata cache), the NFS cost of this check disappears. The remaining cost is a RAM cache lookup + in-memory scan of cached ranges, which is negligible. The full-object check is required for correctness — a full GET that caches the entire object as range 0-N must be discoverable by subsequent range requests.

**Fix (standalone)**: If Bottleneck 1 is not yet fixed, route `has_cached_ranges()` and the full-object `find_cached_ranges()` through the RAM metadata cache to avoid NFS reads.

**Fix (optimization)**: Store a boolean flag in metadata (e.g., `has_full_object_range: bool`) updated when a full-object GET is cached. The full-object `find_cached_ranges` call can then be skipped when the flag is false, avoiding the in-memory range scan. This is a minor CPU optimization — not worth pursuing until NFS I/O is resolved.

**Expected gain**: If Bottleneck 1 is fixed, minimal additional gain. Standalone: eliminate 1-2 NFS reads per request (~2-10ms saved).

---

## Bottleneck 3: Metadata Cache Underutilized (Not a Staleness Issue)

**Impact: Low (if Bottleneck 1 is fixed) / High (standalone)**

The `MetadataCache` has a 5-second `refresh_interval`. This interval is correct and should not be increased — in a multi-instance deployment, other nodes can invalidate ranges, write new ranges, or consolidate journals at any time. The 5-second window is the mechanism that catches cross-instance changes. Lengthening it would risk serving stale or invalidated data.

The actual problem is that the hot path bypasses the `MetadataCache` entirely (Bottleneck 1). The cache exists and works correctly, but `has_cached_ranges()`, `find_cached_ranges()`, and `serve_range_from_cache()` all read directly from NFS. Once Bottleneck 1 is fixed and all metadata reads route through the RAM cache, the 5-second refresh becomes the only NFS read per cache key per 5-second window — one read instead of 4-5 per request.

**Fix**: This bottleneck is resolved by fixing Bottleneck 1. No changes to the `MetadataCache` refresh interval or staleness logic are needed.

**Expected gain**: Subsumed by Bottleneck 1 fix.

---

## Bottleneck 4: Synchronous Blocking I/O in disk_cache.rs

**Impact: Low (if Bottleneck 1 is fixed)**

`DiskCacheManager` uses synchronous `std::fs::read_to_string()` and `std::fs::write()` throughout. This is deliberate — not an oversight:

1. Many operations hold file locks (`lock_file.lock()`) for atomic read-modify-write cycles. Awaiting inside a lock-held section risks deadlock if the Tokio runtime schedules another task on the same thread that tries to acquire the same lock.
2. `DiskCacheManager` is behind an `RwLock`. Holding an `RwLock` guard across `.await` points requires `Send` bounds and careful handling to avoid holding the guard across yield points.
3. Other modules (`hybrid_metadata_writer.rs`, `cache_initialization_coordinator.rs`) use `tokio::fs` where they don't hold file locks.

If Bottleneck 1 is fixed, `get_metadata()` is only called during the 5-second metadata cache refresh — not on the hot path. The sync I/O impact on request latency becomes negligible.

**Remaining concern**: `load_range_data` (reading the actual range file from NFS) is still on the hot path for disk cache hits (RAM cache miss). This is a single sync `std::fs::read()` of 8 MiB per request. Wrapping this in `spawn_blocking()` would prevent it from blocking the executor thread during concurrent requests.

**Fix**: Wrap `load_range_data`'s file read in `tokio::task::spawn_blocking()`. Leave the lock-holding metadata operations as sync I/O — the pattern is correct there.

**Expected gain**: Marginal throughput improvement under high concurrency for disk cache hits. No impact on RAM cache hits.

---

## Bottleneck 5: Lock Contention on disk_cache_manager

**Impact: Medium**

`RangeHandler` holds `disk_cache_manager` behind an `RwLock<DiskCacheManager>`. Every `find_cached_ranges()` call acquires a read lock:

```rust
let disk_cache = self.disk_cache_manager.read().await;
```

The lock is held for the entire metadata read + range overlap calculation. With NFS latency, this means the read lock is held for 1-5ms per call. Write operations (store_range, consolidation) need a write lock, which blocks behind all readers.

In `handle_range_request`, the expiration check also acquires a separate read lock, then potentially upgrades to a write lock for TTL refresh:

```rust
let disk_cache = range_handler.get_disk_cache_manager();
let disk_cache_guard = disk_cache.read().await;
// ... check expiration ...
drop(disk_cache_guard);
let mut disk_cache_guard = disk_cache.write().await;  // blocks all readers
```

**Fix**: Reduce lock scope by loading metadata outside the lock (via the RAM metadata cache), then only acquiring the lock for mutations. Consider splitting the `RwLock` into separate locks for metadata reads vs. range data writes.

**Expected gain**: Reduced tail latency under concurrent load, especially during consolidation cycles.

---

## Bottleneck 6: Range Data Not Streamed from Disk

**Impact: Medium (for large ranges)**

`serve_range_from_cache` loads the entire 8 MiB range into memory via `load_range_data_with_cache()`, then wraps it in `Full::new(Bytes::from(range_data))`. The data path:

1. Read 8 MiB from NFS into `Vec<u8>`
2. Potentially decompress (LZ4)
3. Clone into `Bytes`
4. Send as single HTTP response body

For 8 MiB ranges this allocates ~16-24 MiB transiently (original + decompressed + Bytes). With many concurrent requests, this creates memory pressure.

The S3 client already has streaming support for responses > 1 MiB (`STREAMING_THRESHOLD`), but the cache-hit path doesn't use streaming.

**Fix**: Stream range data from disk in chunks (e.g., 64 KB) instead of loading the entire range into memory. Use the same streaming architecture already implemented for S3 responses.

**Expected gain**: Reduced memory usage per concurrent request. May improve first-byte latency for cache hits since the first chunk can be sent before the full range is read.

---

## Bottleneck 7: Consolidation Cycle Duration

**Impact: Low-Medium**

Observed consolidation cycles taking 223ms to 9.9 seconds with 456 entries across 5 delta files. During consolidation, the consolidator holds locks that can block cache writes.

The consolidation cycle reads all journal files, parses entries, reads/writes metadata files, and updates size tracking — all on NFS.

**Fix**: 
- Process journal entries in batches, releasing locks between batches
- Use async I/O for journal file reads
- Consider consolidating only changed cache keys (track dirty set) rather than re-reading all journals
- The 9.9s outlier likely reflects NFS latency spikes; adding timeout/circuit-breaker logic would prevent one slow cycle from blocking the next

**Expected gain**: Reduced lock hold time during consolidation, fewer latency spikes on cache writes.

---

## Bottleneck 8: Metadata Re-read in serve_range_from_cache

**Impact: Medium**

After loading range data, `serve_range_from_cache` reads metadata again to build response headers:

```rust
let cached_metadata = {
    for attempt in 0..5 {
        match cache_manager.get_metadata_from_disk(cache_key).await {
```

This is a 6th NFS read for the same `.meta` file, with a retry loop (up to 5 attempts with 20-80ms delays). The metadata was already loaded earlier in the request.

**Fix**: Pass the metadata loaded during cache lookup through to `serve_range_from_cache`. The `RangeOverlap` struct already carries etag and last_modified from the metadata — extend it to carry the full `ObjectMetadata` or response headers.

**Expected gain**: Eliminate 1 NFS read per request (~1-5ms saved). Eliminate retry delay risk (up to 200ms worst case).

---

## Bottleneck 9: Connection Pool max_idle_per_host

**Impact: Low-Medium**

The default config sets `max_idle_per_host: 1`, meaning Hyper keeps only 1 idle connection per S3 endpoint. With concurrent cache misses, each new request beyond the first must establish a new TLS connection to S3 (~50-100ms handshake).

For workloads with burst cache misses (e.g., initial cache warming), this creates a connection establishment bottleneck.

**Fix**: Increase `max_idle_per_host` to 10-20 for production deployments. This allows Hyper to reuse more connections during burst traffic.

**Expected gain**: Reduced S3 request latency during cache warming and burst miss scenarios.

---

## Implementation Status (v1.1.39)

All high-priority bottlenecks addressed:

1. **Metadata pass-through** (Bottlenecks 1, 3, 8): Metadata loaded once via `get_metadata_cached()` and passed through the call chain. NFS reads per cache hit reduced from ~5 to ~1.
2. **Large file full-object check skip** (Bottleneck 2): `content_length > full_object_check_threshold` (default 64 MiB) skips the full-object scan.
3. **Connection pool tuning** (Bottleneck 9): `max_idle_per_host` default changed from 1 to 10.
4. **Consolidation cycle timeout** (Bottleneck 7): Per-key processing phase enforces configurable timeout (default 30s).
5. **Disk streaming** (Bottleneck 6): Cached ranges >= `disk_streaming_threshold` (default 1 MiB) streamed in 512 KiB chunks.

### Not addressed (low priority)

| Bottleneck | Reason |
|-----------|--------|
| 4 — Sync blocking I/O | Resolved by metadata pass-through (reads come from RAM cache) |
| 5 — Lock contention | Resolved by metadata pass-through (lock hold time drops to microseconds) |
