# Cache Lookup Diagnostic Logging Implementation

## Summary

Implemented comprehensive diagnostic logging throughout the cache lookup path to help debug cache lookup failures. All logging uses standardized prefixes for easy filtering and includes both original and sanitized cache keys for comparison.

## Changes Made

### 1. Range Handler (`src/range_handler.rs`)

Added `[CACHE_LOOKUP]` prefixed debug logs in `find_cached_ranges()`:

- **Entry point logging**: Logs cache key, requested range, and current ETag when cache lookup starts
- **Storage architecture checks**: Logs when checking new vs old storage formats
- **Metadata discovery**: Logs when metadata is found with range count and ETag
- **Range enumeration**: Logs each range in metadata with expiration status
- **Overlap detection**: Logs overlapping ranges found with compression algorithm
- **Result summary**: Logs final cache lookup result with overlap/missing range counts
- **Old storage fallback**: Logs when falling back to old storage format

**Key logging points:**
```rust
debug!(
    "[CACHE_LOOKUP] Starting cache lookup: cache_key={}, requested_range={}-{}, current_etag={:?}",
    cache_key, requested_range.start, requested_range.end, current_etag
);
```

### 2. Disk Cache - Path Resolution (`src/disk_cache.rs`)

Added `[PATH_RESOLUTION]` prefixed debug logs in `get_new_metadata_file_path()`:

- **Successful path construction**: Logs original cache key, sanitized key, and resulting sharded path
- **Fallback to flat structure**: Logs when sharding fails and flat structure is used
- **Path comparison**: Includes both original and sanitized keys for debugging format mismatches

**Key logging points:**
```rust
debug!(
    "[PATH_RESOLUTION] Metadata path constructed: cache_key={}, sanitized_key={}, path={:?}",
    cache_key, sanitized_key, path
);
```

### 3. Disk Cache - Metadata Lookup (`src/disk_cache.rs`)

Added `[METADATA_LOOKUP]` prefixed debug logs in `get_metadata()`:

- **File existence check**: Logs cache key, sanitized key, computed path, and whether file exists
- **Cache miss**: Logs when metadata file is not found
- **File read success**: Logs successful metadata file read with size
- **File read failure**: Logs read errors with recovery action
- **JSON parse success**: Logs successful parse with range count and ETag
- **JSON parse failure**: Logs parse errors with recovery action

**Key logging points:**
```rust
debug!(
    "[METADATA_LOOKUP] Checking metadata file: cache_key={}, sanitized_key={}, path={:?}, exists={}",
    cache_key, sanitized_key, metadata_file_path, file_exists
);
```

### 4. Disk Cache - Range Overlap Detection (`src/disk_cache.rs`)

Added `[RANGE_OVERLAP]` prefixed debug logs in `find_cached_ranges()`:

- **Expiration check**: Logs when ranges are expired and skipped
- **Overlap check**: Logs each range being checked with overlap result (true/false)
- **Overlap detection**: Logs when overlap is detected with range details
- **Exact match**: Logs when exact match optimization is triggered
- **Full containment**: Logs when full containment optimization is triggered
- **Final result**: Logs completion with overlap/no-overlap result and timing

**Key logging points:**
```rust
debug!(
    "[RANGE_OVERLAP] Checking range overlap: cache_key={}, cached_range={}-{}, requested_range={}-{}, overlaps={}",
    cache_key, range_spec.start, range_spec.end, requested_start, requested_end, overlaps
);
```

## Requirements Satisfied

- ✅ **Requirement 1.1**: Log cache key, requested range, and current ETag in `range_handler.rs::find_cached_ranges()`
- ✅ **Requirement 1.2**: Log input cache key and resulting path in `disk_cache.rs::get_new_metadata_file_path()`
- ✅ **Requirement 1.3**: Log cache key, computed path, and file existence in `disk_cache.rs::get_metadata()`
- ✅ **Requirement 1.4**: Log number of ranges and their positions when metadata is loaded
- ✅ **Requirement 1.5**: Log each range being checked for overlap in `disk_cache.rs::find_cached_ranges()`
- ✅ **Requirement 2.5**: Include both original and sanitized cache keys in all logs
- ✅ **Requirements 5.1, 5.2**: Log cache key format at storage and lookup time
- ✅ **Requirements 6.1, 6.2, 6.3, 6.5**: Log exact cache key, full path, existence check, and metadata details

## Usage

To enable diagnostic logging, set the `RUST_LOG` environment variable:

```bash
# Enable all debug logs
export RUST_LOG=debug

# Filter only cache lookup diagnostics
export RUST_LOG=debug
# Then grep for specific prefixes:
grep "\[CACHE_LOOKUP\]" logfile
grep "\[PATH_RESOLUTION\]" logfile
grep "\[METADATA_LOOKUP\]" logfile
grep "\[RANGE_OVERLAP\]" logfile
```

## Log Prefix Reference

| Prefix | Location | Purpose |
|--------|----------|---------|
| `[CACHE_LOOKUP]` | `range_handler.rs::find_cached_ranges()` | High-level cache lookup flow |
| `[PATH_RESOLUTION]` | `disk_cache.rs::get_new_metadata_file_path()` | Path construction and sharding |
| `[METADATA_LOOKUP]` | `disk_cache.rs::get_metadata()` | Metadata file operations |
| `[RANGE_OVERLAP]` | `disk_cache.rs::find_cached_ranges()` | Range overlap detection logic |

## Example Log Output

```
[CACHE_LOOKUP] Starting cache lookup: cache_key=bucket/path/to/object, requested_range=0-1023, current_etag=Some("abc123")
[PATH_RESOLUTION] Metadata path constructed: cache_key=bucket/path/to/object, sanitized_key=bucket%2Fpath%2Fto%2Fobject, path="/cache/objects/bucket/AB/CDE/bucket%2Fpath%2Fto%2Fobject.meta"
[METADATA_LOOKUP] Checking metadata file: cache_key=bucket/path/to/object, sanitized_key=bucket%2Fpath%2Fto%2Fobject, path="/cache/objects/bucket/AB/CDE/bucket%2Fpath%2Fto%2Fobject.meta", exists=true
[METADATA_LOOKUP] Metadata file read successfully: cache_key=bucket/path/to/object, sanitized_key=bucket%2Fpath%2Fto%2Fobject, size=512 bytes
[METADATA_LOOKUP] Metadata JSON parsed successfully: cache_key=bucket/path/to/object, sanitized_key=bucket%2Fpath%2Fto%2Fobject, ranges=2, etag=abc123
[CACHE_LOOKUP] Found new-format metadata: cache_key=bucket/path/to/object, ranges_count=2, etag=abc123
[CACHE_LOOKUP] Metadata range 0: cache_key=bucket/path/to/object, start=0, end=1023, expired=false
[CACHE_LOOKUP] Metadata range 1: cache_key=bucket/path/to/object, start=1024, end=2047, expired=false
[CACHE_LOOKUP] Calling disk_cache.find_cached_ranges: cache_key=bucket/path/to/object, requested_range=0-1023
[RANGE_OVERLAP] Checking range overlap: cache_key=bucket/path/to/object, cached_range=0-1023, requested_range=0-1023, overlaps=true
[RANGE_OVERLAP] Overlap detected: key=bucket/path/to/object, cached_range=0-1023, requested_range=0-1023, overlap_type=partial
[RANGE_OVERLAP] Range lookup completed: key=bucket/path/to/object, requested_range=0-1023, result=exact_match, cached_range=0-1023, duration=0.52ms
[CACHE_LOOKUP] disk_cache.find_cached_ranges returned: cache_key=bucket/path/to/object, overlapping_ranges_count=1
[CACHE_LOOKUP] Found overlapping ranges in new storage: cache_key=bucket/path/to/object, count=1
[CACHE_LOOKUP] Overlapping range 0: cache_key=bucket/path/to/object, start=0, end=1023, compression=Some(Lz4)
[CACHE_LOOKUP] Cache lookup result: cache_key=bucket/path/to/object, overlapping_ranges=1, missing_ranges=0, requested_range=0-1023, can_serve_from_cache=true
```

## Debugging Cache Lookup Issues

With these logs, you can now:

1. **Trace cache key transformations**: Compare original vs sanitized keys at each step
2. **Verify path construction**: See exactly what paths are being computed
3. **Check file existence**: Confirm whether metadata files exist at expected locations
4. **Analyze range overlap logic**: See which ranges are being checked and why overlaps are/aren't detected
5. **Identify format mismatches**: Spot differences in cache key format between storage and lookup

## Next Steps

The diagnostic logging is now in place. To debug the cache lookup issue:

1. Run the application with `RUST_LOG=debug`
2. Perform a cache operation that should hit but misses
3. Grep the logs for the cache key using the prefixes above
4. Compare the paths, keys, and overlap detection results
5. Identify where the mismatch occurs (key format, path construction, or overlap logic)
