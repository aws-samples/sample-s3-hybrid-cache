# Cache Eviction Strategy Comparison: TinyLFU vs GDSF

## Executive Summary

This document compares two advanced cache eviction algorithms for the S3 Proxy project: **TinyLFU** (currently implemented) and **GDSF (Greedy Dual Size Frequency)**. Both algorithms aim to improve upon simple LRU/LFU by considering multiple factors when making eviction decisions.

**Recommendation**: Keep TinyLFU as the default, but consider adding GDSF as an optional algorithm for workloads with highly variable object sizes.

---

## Algorithm Overview

### TinyLFU (Tiny Least Frequently Used)

**Current Implementation**: Yes (in `src/ram_cache.rs`)

TinyLFU is a frequency-based admission policy that uses a compact frequency sketch to track access patterns with minimal memory overhead. It combines:
- **Frequency estimation**: Tracks how often items are accessed using a sliding window
- **Recency consideration**: Balances frequency with time-based decay
- **Admission policy**: New items must prove their value before evicting existing items

**Key Characteristics**:
- Space-efficient frequency tracking (uses window + frequency map)
- Resistant to scan patterns (one-time access bursts)
- Good for workloads with recurring access patterns
- Size-agnostic (doesn't consider object size in eviction decisions)

### GDSF (Greedy Dual Size Frequency)

**Current Implementation**: No

GDSF is a cost-based eviction algorithm that considers three factors:
- **Access frequency**: How often an item is accessed
- **Object size**: Larger objects have higher eviction priority
- **Recency**: Time since last access

**Formula**: `Priority = (Frequency × Cost) / Size + L`

Where:
- `Frequency` = number of accesses
- `Cost` = fetch cost (typically 1 for all objects, or latency-based)
- `Size` = object size in bytes
- `L` = aging factor (increases over time to prevent starvation)

**Key Characteristics**:
- Size-aware eviction (favors keeping small, frequently accessed items)
- Balances hit rate with byte hit rate
- Better cache utilization for variable-sized objects
- More complex to implement and tune

---

## Detailed Comparison

### 1. Memory Overhead

| Aspect | TinyLFU | GDSF |
|--------|---------|------|
| **Per-entry metadata** | Window position + frequency counter | Priority value + frequency + size + timestamp |
| **Additional structures** | Sliding window (VecDeque) + frequency map | Priority queue (BinaryHeap) or sorted list |
| **Memory complexity** | O(W + N) where W = window size, N = entries | O(N) where N = entries |
| **Typical overhead** | ~16-24 bytes per entry + window | ~32-48 bytes per entry |

**Winner**: TinyLFU (lower memory overhead)

### 2. Computational Complexity

| Operation | TinyLFU | GDSF |
|-----------|---------|------|
| **Get (hit)** | O(1) - update frequency + window | O(log N) - update priority in heap |
| **Put (insert)** | O(1) - add to window + frequency | O(log N) - insert into priority queue |
| **Eviction** | O(N) - scan all entries for min score | O(log N) - pop from priority queue |
| **Window maintenance** | O(1) amortized - pop front when full | N/A |

**Winner**: Mixed - TinyLFU better for get/put, GDSF better for eviction

### 3. Cache Hit Rate

**TinyLFU Strengths**:
- Excellent for workloads with recurring patterns (e.g., popular objects accessed repeatedly)
- Resistant to cache pollution from one-time scans
- Frequency tracking prevents eviction of truly popular items

**GDSF Strengths**:
- Better byte hit rate (considers size, so more small objects fit)
- Optimal for workloads with highly variable object sizes
- Balances frequency with space efficiency

**Workload Considerations**:

| Workload Type | TinyLFU Performance | GDSF Performance |
|---------------|---------------------|------------------|
| Uniform object sizes | Excellent | Excellent |
| Variable sizes (10KB-100MB) | Good | Excellent |
| Scan-heavy (one-time access) | Excellent | Good |
| Zipfian distribution (few hot objects) | Excellent | Good |
| Size-correlated popularity (small = popular) | Good | Excellent |

### 4. Implementation Complexity

**TinyLFU**:
```rust
// Current implementation (simplified)
fn find_tinylfu_victim(&self) -> Option<String> {
    self.entries.iter()
        .min_by_key(|(key, entry)| {
            let frequency = self.tinylfu_frequencies.get(*key).unwrap_or(&1);
            let recency_factor = now.duration_since(entry.last_accessed)
                .unwrap_or_default().as_secs().max(1);
            frequency * 1000 / recency_factor
        })
        .map(|(key, _)| key.clone())
}
```

**GDSF** (hypothetical implementation):
```rust
// Would require additional structures
struct GDSFEntry {
    key: String,
    frequency: u64,
    size: u64,
    priority: f64,
    last_access: SystemTime,
}

fn find_gdsf_victim(&mut self) -> Option<String> {
    // Update L (aging factor) based on last eviction
    self.aging_factor = self.last_evicted_priority;
    
    // Find entry with minimum priority
    self.entries.iter()
        .min_by(|(_, a), (_, b)| {
            let priority_a = (a.frequency as f64 / a.size as f64) + self.aging_factor;
            let priority_b = (b.frequency as f64 / b.size as f64) + self.aging_factor;
            priority_a.partial_cmp(&priority_b).unwrap()
        })
        .map(|(key, _)| key.clone())
}
```

**Complexity Assessment**:
- TinyLFU: ~200 lines of code (already implemented)
- GDSF: ~300-400 lines of code (estimated)
- GDSF requires careful tuning of aging factor and cost function

**Winner**: TinyLFU (simpler, already implemented)

### 5. S3 Proxy Specific Considerations

**Object Size Distribution in S3**:
- Highly variable (bytes to terabytes)
- Common pattern: Many small objects (metadata, thumbnails) + few large objects (videos, backups)
- Range requests complicate size tracking (partial objects)

**Current Architecture**:
- RAM cache: Small objects and metadata (TinyLFU works well)
- Disk cache: All sizes including ranges (size-awareness could help)
- Range-aware caching: Objects split into chunks (complicates GDSF)

**TinyLFU Advantages for S3 Proxy**:
- ✅ Simple integration with existing range-based caching
- ✅ Works well for metadata and small object caching (HEAD responses)
- ✅ Resistant to scan patterns (e.g., backup jobs reading everything once)
- ✅ Low overhead for high-throughput scenarios

**GDSF Advantages for S3 Proxy**:
- ✅ Better disk cache utilization (size-aware eviction)
- ✅ Optimal for mixed workloads (small thumbnails + large videos)
- ✅ Higher byte hit rate (more data served from cache)
- ⚠️ Requires careful handling of range requests (what's the "size"?)

---

## Performance Benchmarks (Theoretical)

### Scenario 1: Uniform Object Sizes (1MB each)

| Metric | TinyLFU | GDSF |
|--------|---------|------|
| Hit Rate | 85% | 85% |
| Byte Hit Rate | 85% | 85% |
| Eviction Time | O(N) scan | O(log N) heap |
| Memory Overhead | Low | Medium |

**Result**: Tie - both perform similarly when sizes are uniform

### Scenario 2: Variable Sizes (1KB-100MB, Zipfian distribution)

| Metric | TinyLFU | GDSF |
|--------|---------|------|
| Hit Rate | 75% | 70% |
| Byte Hit Rate | 60% | 75% |
| Cache Utilization | 70% | 85% |
| Small Object Hit Rate | 80% | 90% |

**Result**: GDSF wins on byte hit rate and utilization, TinyLFU wins on object hit rate

### Scenario 3: Scan-Heavy Workload (80% one-time access)

| Metric | TinyLFU | GDSF |
|--------|---------|------|
| Hit Rate | 65% | 45% |
| Cache Pollution | Low | High |
| Popular Object Retention | Excellent | Good |

**Result**: TinyLFU wins - better scan resistance

---

## Implementation Considerations

### Adding GDSF to S3 Proxy

**Required Changes**:

1. **New eviction algorithm enum** (`src/cache_types.rs`):
```rust
pub enum CacheEvictionAlgorithm {
    LRU,
    LFU,
    TinyLFU,
    GDSF,  // New
}
```

2. **GDSF-specific fields** (`src/ram_cache.rs`):
```rust
struct RamCache {
    // ... existing fields ...
    
    // GDSF-specific
    gdsf_priorities: HashMap<String, f64>,
    gdsf_aging_factor: f64,
    gdsf_last_evicted_priority: f64,
}
```

3. **Priority calculation**:
```rust
fn calculate_gdsf_priority(&self, key: &str, entry: &RamCacheEntry) -> f64 {
    let frequency = self.access_frequencies.get(key).unwrap_or(&1);
    let size = self.calculate_entry_size(entry);
    let cost = 1.0; // Could be latency-based in future
    
    (*frequency as f64 * cost) / (size as f64) + self.gdsf_aging_factor
}
```

4. **Eviction logic**:
```rust
fn find_gdsf_victim(&mut self) -> Option<String> {
    let victim = self.entries.iter()
        .min_by(|(key_a, entry_a), (key_b, entry_b)| {
            let priority_a = self.calculate_gdsf_priority(key_a, entry_a);
            let priority_b = self.calculate_gdsf_priority(key_b, entry_b);
            priority_a.partial_cmp(&priority_b).unwrap()
        })
        .map(|(key, _)| key.clone());
    
    if let Some(ref key) = victim {
        if let Some(entry) = self.entries.get(key) {
            self.gdsf_aging_factor = self.calculate_gdsf_priority(key, entry);
        }
    }
    
    victim
}
```

**Estimated Implementation Effort**: 4-6 hours

### Configuration

**Proposed YAML config**:
```yaml
cache:
  ram:
    max_size: 1GB
    eviction_algorithm: tinylfu  # or: lru, lfu, gdsf
    
    # GDSF-specific tuning (optional)
    gdsf_cost_function: uniform  # or: latency_based
    gdsf_aging_decay: 0.95
```

---

## Pros and Cons Summary

### TinyLFU

**Pros**:
- ✅ Already implemented and tested
- ✅ Lower memory overhead
- ✅ Excellent scan resistance
- ✅ Simple to understand and maintain
- ✅ Good performance for most workloads
- ✅ Fast get/put operations (O(1))
- ✅ Works well with range-based caching

**Cons**:
- ❌ Size-agnostic (may cache large, infrequently accessed objects)
- ❌ Lower byte hit rate for variable-sized workloads
- ❌ Slower eviction (O(N) scan)
- ❌ May waste cache space on large objects

### GDSF

**Pros**:
- ✅ Size-aware eviction (better cache utilization)
- ✅ Higher byte hit rate for variable sizes
- ✅ Optimal for mixed small/large object workloads
- ✅ Fast eviction (O(log N) with heap)
- ✅ Balances frequency, size, and recency

**Cons**:
- ❌ Not yet implemented (development effort required)
- ❌ Higher memory overhead
- ❌ More complex to tune (aging factor, cost function)
- ❌ Slower get/put operations (O(log N))
- ❌ Less resistant to scan patterns
- ❌ Complexity with range requests (what's the "size"?)

---

## Recommendations

### Default Algorithm: TinyLFU

**Rationale**:
1. **Already implemented and battle-tested** - no development risk
2. **Lower overhead** - better for high-throughput scenarios
3. **Scan resistance** - critical for S3 workloads (backups, analytics)
4. **Simplicity** - easier to maintain and debug
5. **Good enough** - performs well for most S3 access patterns

### When to Consider GDSF

GDSF would be beneficial for:
- **Disk cache** (not RAM cache) - where size matters more
- **Workloads with extreme size variance** (1KB-1GB objects)
- **Size-correlated popularity** (small objects are more popular)
- **Byte hit rate optimization** (serving more data from cache)

### Hybrid Approach (Future Enhancement)

Consider a **two-tier strategy**:
- **RAM cache**: TinyLFU (optimized for hit rate, scan resistance)
- **Disk cache**: GDSF (optimized for byte hit rate, space utilization)

This leverages the strengths of both algorithms at appropriate tiers.

---

## Implementation Roadmap (If Adding GDSF)

### Phase 1: Core Implementation (4-6 hours)
- [ ] Add GDSF enum variant
- [ ] Implement priority calculation
- [ ] Implement GDSF eviction logic
- [ ] Add GDSF-specific tracking structures

### Phase 2: Testing (3-4 hours)
- [ ] Unit tests for GDSF eviction
- [ ] Property-based tests for consistency
- [ ] Benchmark tests comparing TinyLFU vs GDSF
- [ ] Integration tests with compression

### Phase 3: Configuration & Documentation (2-3 hours)
- [ ] Add GDSF config options
- [ ] Update documentation
- [ ] Add performance tuning guide
- [ ] Create migration guide

**Total Effort**: 9-13 hours

---

## Conclusion

**Keep TinyLFU as the default** for the S3 Proxy project. It provides excellent performance with minimal overhead and is well-suited for S3 workloads with scan patterns.

**Consider adding GDSF** as an optional algorithm if:
1. Users report poor cache utilization with variable-sized objects
2. Byte hit rate becomes a critical metric
3. Disk cache eviction needs optimization

The current TinyLFU implementation is production-ready and performs well. Adding GDSF would be a nice-to-have enhancement rather than a critical need.

---

## References

- **TinyLFU Paper**: "TinyLFU: A Highly Efficient Cache Admission Policy" (Gil Einziger, Roy Friedman, 2017)
- **GDSF Paper**: "GreedyDual-Size: A Cost-Aware WWW Proxy Caching Algorithm" (Pei Cao, Sandy Irani, 1997)
- **Current Implementation**: `src/ram_cache.rs` (lines 1-700)
- **Cache Architecture**: `docs/CACHING.md`
