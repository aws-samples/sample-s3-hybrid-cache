# Consensus Systems for S3 Proxy: etcd, Raft, and Alternatives

Analysis of whether distributed consensus (etcd, Raft) should replace the current
file-based coordination for metadata and size tracking.

## Current Architecture Summary

The proxy uses a **stateless instance model** where all coordination happens through
shared NFS/EFS storage:

- Per-instance journal files (no write contention between instances)
- File-based locking (`fs2::flock`) for metadata updates and eviction
- A single `size_state.json` file updated via lock-protected read-modify-write
- Global consolidation lock prevents multiple instances from running consolidation simultaneously
- Daily validation scan corrects drift

The core size tracking problem: HybridMetadataWriter writes ranges to `.meta` files
immediately for atomicity, then creates journal entries. By the time consolidation
runs, the range is already in metadata, so metadata-diff approaches see no change.
Journal-based approaches suffer from cross-cycle double-counting and NFS caching
delays that cause duplicate processing across instances.

## The Fundamental Problem

Size tracking has gone through 15+ iterations (v1.1.18 through v1.1.32) and every
approach hits one of these walls:

| Approach | Failure Mode |
|----------|-------------|
| Metadata diff (before/after) | Range already in metadata → delta = 0 |
| Journal entry counting | Cross-cycle duplicates, Add/Remove in different cycles |
| Direct per-write tracking | NFS lock latency → 30% throughput degradation |
| metadata_written flag | Flag not always set correctly; multi-instance edge cases |
| Global consolidation lock | Eliminates races but doesn't fix the fundamental counting gap |

The root cause is that NFS provides **no atomic read-modify-write** and **no reliable
change notifications**. File locking on NFS is advisory, subject to caching delays,
and stale file handles. The system is fighting the storage layer.

## Option 1: etcd for Metadata and Size Tracking

### What etcd Provides

- Linearizable key-value store with strong consistency
- Watch API for real-time change notifications
- Atomic compare-and-swap (CAS) operations
- Lease-based distributed locking with automatic expiry
- Built-in leader election

### How It Would Work

```
Instance 1 ──┐                    ┌── etcd cluster (3 nodes)
Instance 2 ──┼── gRPC/HTTP ──────┤   key: /cache/size → {total: 1.5GB, write: 200MB}
Instance N ──┘                    │   key: /cache/meta/{key} → {ranges, etag, ...}
                                  └── Shared Storage (NFS) - range .bin files only
```

Size tracking becomes trivial:
```
store_range() → etcd.transaction {
    compare: size.version == current_version
    success: put(size, current + compressed_size)
}
```

### Advantages

- **Atomic size updates**: CAS eliminates all race conditions
- **No NFS lock overhead**: Size state lives in etcd, not on NFS
- **Watch-based eviction**: Instances subscribe to size changes, react immediately
- **Lease-based locking**: Automatic lock release on instance crash (no stale locks)
- **Metadata consistency**: etcd's linearizability guarantees all instances see same state

### Disadvantages

- **New infrastructure dependency**: etcd cluster requires 3+ nodes for HA
- **Operational complexity**: etcd needs monitoring, backup, compaction, defragmentation
- **Network dependency**: etcd unavailability blocks all cache operations
- **Latency**: etcd writes are ~2-10ms (consensus round), comparable to NFS locks
- **Scale ceiling**: etcd is designed for small metadata (recommended <8GB total)
- **Deployment model conflict**: The proxy's value proposition is "stateless instances
  with shared storage, no cluster coordination." etcd is a cluster that needs coordination.

### Verdict: Overkill

etcd solves the size tracking problem but introduces a distributed system to manage
a distributed system. The proxy currently deploys as 2-4 instances behind NFS. Adding
a 3-node etcd cluster more than doubles the infrastructure footprint. The operational
burden (etcd compaction, defrag, backup, TLS cert rotation, version upgrades) exceeds
the problem being solved.

etcd makes sense when you have dozens of nodes needing strong consistency for
configuration, service discovery, or leader election. For 2-4 proxy instances tracking
a single integer (cache size), it's a sledgehammer for a thumbtack.

## Option 2: Embedded Raft (e.g., openraft, raft-rs)

### What Embedded Raft Provides

- Consensus without external infrastructure
- Leader election among proxy instances
- Replicated state machine for metadata
- No additional services to deploy

### How It Would Work

```
Instance 1 (Leader) ──┐
Instance 2 (Follower) ─┼── Raft protocol (TCP between instances)
Instance 3 (Follower) ─┘
                        │
                        ▼
              Replicated State Machine:
              - cache_size: u64
              - write_cache_size: u64
              - per-key metadata (optional)
```

Size updates become Raft log entries:
```rust
enum CacheCommand {
    AddRange { key: String, start: u64, end: u64, compressed_size: u64 },
    RemoveRange { key: String, start: u64, end: u64, compressed_size: u64 },
}
```

### Advantages

- **No external infrastructure**: Raft runs inside the proxy process
- **Strong consistency**: All instances agree on cache size
- **Automatic leader election**: No manual coordination
- **Crash recovery**: Raft log provides durability

### Disadvantages

- **Breaks stateless model**: Instances must know about each other (peer addresses)
- **Minimum 3 nodes**: Raft requires odd-numbered quorum for leader election
- **Network partition sensitivity**: Split-brain scenarios need careful handling
- **Complexity**: Raft implementation is non-trivial even with libraries
  - Log compaction/snapshotting
  - Membership changes (adding/removing instances)
  - Persistent storage for Raft log
- **Single-instance degradation**: Cannot form quorum with 1 node; need special handling
- **Startup ordering**: Instances need bootstrap configuration or discovery
- **Latency**: Every size update requires consensus round (leader → followers → commit)
- **Dependency weight**: openraft or raft-rs are substantial dependencies

### Verdict: Wrong abstraction

Raft solves distributed consensus. The proxy doesn't need consensus — it needs
accurate accounting of bytes on a shared filesystem. Raft would give every instance
an identical view of cache size, but the actual data still lives on NFS. If NFS is
slow or caching stale data, Raft's perfect consistency doesn't help — the metadata
in Raft could say a range exists while NFS hasn't made the file visible yet.

Raft also fundamentally changes the deployment model. Today, instances are ephemeral
and independent. With Raft, they form a cluster that needs membership management,
peer discovery, and quorum maintenance. This is a significant architectural shift
for a caching proxy.

## Option 3: Lightweight Coordination Service (Redis/Valkey)

### How It Would Work

```
Instance 1 ──┐
Instance 2 ──┼── Redis protocol ──── Redis/Valkey (single node or Sentinel)
Instance N ──┘
                                      INCRBY cache:size <compressed_size>
                                      DECRBY cache:size <compressed_size>
```

### Advantages

- **Atomic INCRBY/DECRBY**: Size tracking becomes a single atomic operation
- **Sub-millisecond latency**: Much faster than NFS locks
- **Simple operations model**: Redis is well-understood infrastructure
- **Pub/Sub for eviction**: Instances can subscribe to size threshold events

### Disadvantages

- **External dependency**: Another service to deploy and monitor
- **Single point of failure**: Redis without Sentinel/Cluster is not HA
- **Data loss risk**: Redis persistence (RDB/AOF) can lose recent writes on crash
- **Network dependency**: Redis unavailability blocks size tracking

### Verdict: Better fit than etcd/Raft, but still adds infrastructure

Redis solves the atomic counter problem elegantly. `INCRBY` and `DECRBY` are exactly
what size tracking needs. But adding Redis to a system whose selling point is
"just NFS and stateless proxies" changes the deployment story.

## Option 4: Fix the Current Architecture (Recommended)

The size tracking problem has a specific root cause that doesn't require distributed
consensus to solve. The issue is architectural, not a coordination problem.

### Root Cause Recap

1. HybridMetadataWriter writes range to `.meta` immediately (for atomicity)
2. HybridMetadataWriter creates journal entry (for consolidation)
3. Consolidation runs, sees range already in metadata, delta = 0
4. Size never gets counted

### Proposed Fix: Size Tracking at Write Time with In-Memory Accumulator

This combines the best aspects of approaches already explored:

```
store_range_data()
    → write .bin file to disk
    → write range to .meta (HybridMetadataWriter, immediate)
    → create journal entry (for consolidation/access tracking)
    → AtomicI64::fetch_add(compressed_size)  ← in-memory, zero overhead

evict_range()
    → delete .bin file
    → create Remove journal entry
    → AtomicI64::fetch_sub(compressed_size)  ← in-memory, zero overhead

consolidation_cycle()  (every 5s, under global lock)
    → read all instance accumulators via shared memory or per-instance delta files
    → atomic_update_size_delta(sum_of_deltas)
    → reset accumulators
    → process journal entries for metadata updates (access counts, TTL, etc.)
    → trigger eviction if needed
```

#### Per-Instance Delta Files (No NFS Lock Per Write)

Each instance writes its accumulated delta to its own file:

```
size_tracking/
    size_state.json          ← total size (updated by consolidator under lock)
    delta_{instance_1}.json  ← instance 1's pending delta
    delta_{instance_2}.json  ← instance 2's pending delta
```

The consolidator (which already holds the global consolidation lock) reads all
delta files, sums them, updates `size_state.json`, and truncates the delta files.

Each instance only writes its own delta file — no lock needed. The consolidator
is the only writer of `size_state.json` — already serialized by the global lock.

#### Why This Works

- **No per-write NFS lock**: Delta accumulates in memory, flushed to per-instance file
- **No double-counting**: Each range store increments exactly once (at write time)
- **No cross-cycle issues**: Size is tracked at the moment of write, not during consolidation
- **Crash recovery**: Lost in-memory delta is bounded by flush interval (5s).
  Daily validation corrects any drift.
- **Multi-instance safe**: Per-instance files eliminate write contention.
  Consolidator reads all files under its existing global lock.

#### What Changes

| Component | Change |
|-----------|--------|
| `store_range_data()` | Add `AtomicI64::fetch_add(compressed_size)` |
| `evict_range()` | Add `AtomicI64::fetch_sub(compressed_size)` |
| `JournalConsolidator` | Read per-instance delta files, sum into size_state |
| `calculate_size_delta()` | Removed in v1.1.38 — no longer needed for size tracking |
| Journal entries | Still used for metadata updates, access tracking, TTL refresh |
| `size_state.json` | Still the persistent source of truth |
| Daily validation | Still runs as safety net |

#### What Doesn't Change

- HybridMetadataWriter still writes immediately (atomicity preserved)
- Journal system still handles metadata consolidation and access tracking
- Global consolidation lock still serializes consolidation cycles
- Eviction still triggered by consolidator
- NFS is still the shared storage layer

### Eviction Correctness

Eviction runs inside the consolidation cycle (called by `maybe_trigger_eviction()`
after journal processing). The sequence with the accumulator:

1. Consolidation starts, acquires global lock
2. Reads per-instance delta files, sums into `size_state.json`, resets deltas
3. Processes journal entries for metadata only (no size tracking)
4. `maybe_trigger_eviction()` → deletes `.bin` files → `fetch_sub(compressed_size)`
5. Writes `Remove` journal entries (for metadata updates only, not size)
6. Cycle ends, releases lock

**Critical requirements:**

1. **Symmetric values**: `fetch_sub` must use `compressed_size` from the `RangeSpec`
   (same value used by `fetch_add` at write time), NOT `bytes_freed` from
   `batch_delete_ranges()` (which uses `fs::metadata().len()` — the actual file
   size on disk). Using RangeSpec values ensures add/subtract symmetry. Any
   discrepancy between RangeSpec and actual file size is corrected by daily
   validation.

2. **No double subtraction**: `calculate_size_delta()` was removed in v1.1.38.
   Journal `Remove` entries are still written for metadata purposes (removing
   ranges from `.meta` files in `apply_journal_entries()`), but they do not feed
   into size calculations. This prevents double subtraction (once via accumulator,
   once via journal processing).

3. **5-second stale window**: After eviction, `size_state.json` still shows the
   pre-eviction size until the next consolidation cycle flushes the negative delta.
   During this window, `get_current_size()` returns a stale value. This is
   acceptable — eviction already ran, so the cache is actually smaller. Worst case:
   a redundant eviction check that finds nothing more to evict.

4. **Journal write failure**: If `write_eviction_journal_entries()` fails, the
   accumulator still correctly decrements (the `.bin` file is already deleted).
   The metadata update (removing range from `.meta`) is missed, but orphan recovery
   handles stale metadata entries.

### Other Edge Cases

**Duplicate writes (same range cached by multiple instances):**
Both instances increment their accumulators. This over-counts by the size of one
range. The daily validation scan corrects this. Over-counting is safe — it triggers
eviction slightly early rather than letting disk fill.

**Instance crash before flush:**
At most 5 seconds of deltas are lost. The next validation scan corrects the drift.
This is the same recovery model as the current architecture.

**Eviction during consolidation:**
Eviction is called from within the consolidation cycle, which holds the global lock.
No other instance can run consolidation or read delta files simultaneously. The
eviction subtraction goes into the in-memory accumulator and is flushed in the next
cycle. No race condition.

## Comparison Matrix

| Criterion | etcd | Raft | Redis | Fix Current |
|-----------|------|------|-------|-------------|
| Accuracy | Perfect | Perfect | Near-perfect | Near-perfect + validation |
| Infrastructure | 3+ nodes | None (embedded) | 1+ nodes | None |
| Operational burden | High | Medium | Low-Medium | None |
| Deployment model change | Yes | Yes (clustering) | Yes | No |
| Per-write latency | ~2-10ms | ~1-5ms | <1ms | ~0 (in-memory) |
| Crash recovery | Automatic | Automatic | Partial | Validation scan |
| NFS dependency | Reduced | Reduced | Reduced | Same |
| Implementation effort | High | High | Medium | Low |
| Stateless instances | No | No | No | Yes |

## Recommendation

**Fix the current architecture** using per-instance delta files with in-memory
accumulators. This approach:

1. Solves the root cause (size tracked at write time, not during consolidation)
2. Adds zero per-write overhead (atomic in-memory operation)
3. Requires no new infrastructure
4. Preserves the stateless instance model
5. Is a small, focused change to existing code

etcd and Raft are solutions to distributed consensus problems. The proxy doesn't
have a consensus problem — it has an accounting problem caused by the gap between
"when data is written" and "when size is counted." Closing that gap at the source
is simpler and more reliable than adding a consensus layer.

If the proxy eventually needs strong consistency for other reasons (e.g., cache
invalidation protocol, cross-region coordination, configuration management across
dozens of instances), then etcd or a lightweight coordination service becomes worth
revisiting. At the current scale of 2-4 instances sharing NFS, the complexity
isn't justified.

## Concurrent Cache-Miss Problem (Thundering Herd)

### Current Behavior

When multiple clients request the same uncached object simultaneously, the proxy
has no request coalescing for regular GET requests. Each concurrent cache miss
independently:

1. Forwards the request to S3
2. Streams the response to the client
3. Caches the response data (via TeeStream for large files)

This means N concurrent requests for the same uncached 500MB file produce N
parallel S3 fetches, N copies of the data streaming through the proxy, and N
attempts to write the same range to the shared cache.

The proxy does have per-instance dedup for part-number requests (`ActivePartFetch`
in `cache.rs`), which returns 503 with Retry-After to concurrent part requests
while one is in flight. But this only covers `?partNumber=N` requests, not
regular GET or range requests.

### What Happens on Disk

Multiple instances writing the same range to NFS:
- Each writes to a temp file, then renames to the final path
- Last rename wins (NFS rename is atomic per-file)
- No data corruption, but wasted bandwidth, CPU, and S3 request costs
- Each write creates a journal entry → size tracking counts the range multiple times
  (this is one source of the over-counting described in the size tracking analysis)

### Would Consensus Systems Help?

#### etcd / Redis: Distributed Lock for In-Flight Requests

```
Client A requests /bucket/large-file.bin (cache miss)
  → etcd: SET /inflight/bucket/large-file.bin = instance1 (with TTL)
  → Fetch from S3, stream to client + cache

Client B requests /bucket/large-file.bin (cache miss, same or different instance)
  → etcd: GET /inflight/bucket/large-file.bin → "instance1 is fetching"
  → Wait for completion notification (etcd watch or Redis pub/sub)
  → Serve from cache once available
```

This eliminates duplicate S3 fetches. But it requires:
- Network round-trip to etcd/Redis before every cache-miss fetch
- Watch/notification mechanism for waiters
- TTL-based cleanup for crashed fetchers
- Handling the case where the fetcher fails mid-stream

The latency added by the coordination check (~2-10ms) is negligible compared to
S3 fetch time. The real cost is the infrastructure dependency.

#### Raft: Not Helpful

Raft provides consensus on state, not request coordination. You'd still need a
separate mechanism to track in-flight requests. Raft adds nothing here that a
simple distributed lock doesn't provide better.

### Better Approach: In-Process Request Coalescing (No External Dependencies)

The standard solution for this is a **singleflight** / **request coalescing** pattern,
implemented entirely within each proxy instance:

```rust
// Conceptual structure
struct InFlightTracker {
    pending: DashMap<String, Arc<tokio::sync::broadcast::Sender<()>>>,
}
```

When a cache miss occurs:
1. Check `InFlightTracker` for this cache key
2. If no in-flight request: register this request, proceed to S3
3. If in-flight request exists: subscribe to broadcast channel, wait
4. When the fetcher completes caching, broadcast completion
5. Waiters read from cache (which now has the data)

```
Instance 1:
  Request A: cache miss → register in-flight → fetch from S3 → cache → broadcast done
  Request B: cache miss → sees in-flight → waits → reads from cache
  Request C: cache miss → sees in-flight → waits → reads from cache

Instance 2 (separate process, no shared state):
  Request D: cache miss → register in-flight → fetch from S3 → cache → broadcast done
  Request E: cache miss → sees in-flight → waits → reads from cache
```

#### Per-Instance vs Cross-Instance

This approach deduplicates within each instance but not across instances. With
2-4 instances behind DNS round-robin, the worst case is N instances each making
one S3 fetch for the same object (where N = number of instances). This is a
significant improvement over the current behavior where each instance might have
dozens of concurrent requests all fetching independently.

Cross-instance dedup would require a shared coordination point (etcd, Redis, or
a custom protocol between instances). The marginal benefit of reducing N fetches
to 1 fetch (where N = 2-4) rarely justifies the added infrastructure.

#### Implementation Considerations

**Timeout handling**: If the fetcher takes too long or fails, waiters need a
timeout to fall back to their own S3 fetch. The `ActivePartFetch` pattern already
handles this with a 60-second staleness check.

**Streaming compatibility**: The proxy uses TeeStream for large files. Waiters
can't piggyback on the in-flight stream easily (they'd need their own stream).
The practical approach is: waiters wait for caching to complete, then serve from
cache. This adds latency for waiters (they wait for the full object to be cached)
but eliminates duplicate S3 fetches.

**Alternative for streaming**: A more sophisticated approach uses a shared
broadcast channel where the fetcher sends chunks to all waiters simultaneously.
This gives waiters streaming latency (first byte as soon as S3 starts responding)
but is significantly more complex. The wait-then-serve-from-cache approach is
simpler and sufficient for most workloads.

**Range requests**: Need to track in-flight requests at the range level, not just
the object level. Two requests for different ranges of the same object should both
proceed independently.

#### What Changes

| Component | Change |
|-----------|--------|
| `CacheManager` | Add `DashMap<String, broadcast::Sender<()>>` for in-flight tracking |
| `http_proxy.rs` | Before S3 fetch: check/register in-flight. After cache: broadcast |
| `ActivePartFetch` | Can be generalized into the same mechanism |
| Dependencies | Add `dashmap` crate (or use existing `tokio::sync` primitives) |

#### Impact on Size Tracking

Request coalescing directly reduces the duplicate journal entries that cause
over-counting. If only one request per instance fetches and caches a given range,
there's only one journal entry per instance instead of potentially dozens. This
doesn't fully solve size tracking (cross-instance duplicates remain) but
significantly reduces the magnitude of drift.

### Recommendation

Implement per-instance request coalescing using `tokio::sync::broadcast` or a
similar in-process mechanism. This:

1. Eliminates the most common case of duplicate S3 fetches (concurrent requests
   within the same instance)
2. Reduces wasted bandwidth and S3 request costs
3. Reduces duplicate journal entries (helps size tracking accuracy)
4. Requires no external infrastructure
5. Follows the same pattern already used for part requests (`ActivePartFetch`)
   but generalized to all cache-miss fetches

Cross-instance dedup via etcd/Redis is not worth the infrastructure cost at
2-4 instances. If the deployment scales to 10+ instances, revisit.

## When Consensus Would Make Sense

- **10+ instances** with high write concurrency where NFS locking becomes a bottleneck
- **Cross-region deployments** where shared NFS isn't available
- **Cache invalidation protocol** requiring guaranteed delivery to all instances
- **Dynamic configuration** that must be consistent across all instances in real-time
- **Moving away from NFS entirely** to instance-local storage with replication

None of these apply to the current deployment model.
