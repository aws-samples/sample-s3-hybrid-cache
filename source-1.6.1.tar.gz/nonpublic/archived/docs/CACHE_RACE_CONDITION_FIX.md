# Cache Race Condition Fix

## Problem

During concurrent downloads (which AWS CLI does by default), the proxy was experiencing a race condition where:

1. Multiple ranges were being fetched and stored simultaneously
2. Each `store_range` operation would:
   - Write the range binary file (making it visible immediately)
   - Acquire a lock
   - Update metadata to register the range
   - Release the lock
3. Concurrent `find_cached_ranges` lookups would check metadata but not find recently stored ranges

**Symptom**: Every range request showed `cached: 0, missing: 1` even after ranges were stored, causing all ranges to be re-fetched from S3 on subsequent downloads.

**Root Cause**: The range binary file was made visible (via atomic rename) BEFORE the metadata was updated. This created a window where:
- Thread A: Storing range 0-8MB (binary file visible, acquiring lock, updating metadata...)
- Thread B: Looking up range 0-8MB (reads metadata, doesn't find it yet)
- Result: Thread B thinks range isn't cached and fetches from S3 again

## Solution

Reversed the order of operations in `store_range`:

### Before (Broken)
```
1. Write range data to temp file
2. Rename temp → final (RANGE FILE NOW VISIBLE)
3. Acquire lock
4. Update metadata
5. Release lock
```

### After (Fixed)
```
1. Write range data to temp file (keep as .tmp)
2. Acquire lock
3. Update metadata
4. Release lock
5. Rename temp → final (RANGE FILE NOW VISIBLE)
```

**Key Insight**: Metadata must be updated BEFORE the range binary file becomes visible. This ensures that any concurrent lookup will either:
- See the range in metadata AND find the binary file (cache hit)
- Not see the range in metadata yet (cache miss, will fetch and store)

No race condition possible because the metadata is the source of truth, and it's always updated before the data becomes accessible.

## Changes Made

### `src/disk_cache.rs` - `store_range()` function

1. **Step 2**: Keep range file as `.bin.tmp` (don't rename yet)
   - Changed log message to indicate writing to temp
   - Removed the atomic rename that was happening here

2. **Step 3**: Update metadata while range is still temp
   - All error handling now cleans up `range_tmp_path` instead of `range_file_path`
   - Metadata is committed before range becomes visible

3. **Step 4** (NEW): Make range visible after metadata update
   - Added atomic rename from `.bin.tmp` to `.bin`
   - This happens AFTER lock is released and metadata is committed
   - If this fails, metadata has the range but binary doesn't exist (handled as cache miss on read)

## Testing

### Before Fix
```
INFO Range request requires partial S3 fetch (cached: 0, missing: 1)
INFO Range request requires partial S3 fetch (cached: 0, missing: 1)
INFO Range request requires partial S3 fetch (cached: 0, missing: 1)
... (every range fetched from S3, even on second download)
```

### After Fix
Expected behavior:
- First download: All ranges fetched from S3 and stored
- Second download: All ranges served from cache (cache hits)

## Impact

- **Fixes**: Concurrent download cache misses
- **Performance**: Massive improvement for repeated downloads (should be 100% cache hits)
- **Correctness**: Eliminates race condition in cache storage
- **Backward Compatible**: No changes to cache format or API

## Related Files

- `src/disk_cache.rs` - Modified `store_range()` function
- `src/range_handler.rs` - Uses `find_cached_ranges()` which reads metadata
- `src/http_proxy.rs` - Calls range storage during downloads

## Monitoring

Watch for these log patterns to verify the fix:
- First download: `Range request requires partial S3 fetch (cached: 0, missing: 1)`
- Second download: `Range request can be served entirely from cache` or `Range cache hit`
- Should see: `Range binary file made visible` after `Released lock` in logs
