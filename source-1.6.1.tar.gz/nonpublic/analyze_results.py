#!/usr/bin/env python3
"""
Performance Test Results Analyzer
Analyzes and visualizes S3 proxy performance test results
"""

import os
import sys
import glob
import pandas as pd
import argparse
from pathlib import Path
from datetime import datetime

def load_results(results_dir, timestamp=None):
    """Load all CSV results from the results directory"""
    results = {}
    
    pattern = f"*_{timestamp}.csv" if timestamp else "*.csv"
    csv_files = glob.glob(os.path.join(results_dir, pattern))
    
    if not csv_files:
        print(f"No CSV files found in {results_dir}")
        return results
    
    for csv_file in csv_files:
        filename = os.path.basename(csv_file)
        # Parse filename: {test_type}_{mode}_{timestamp}.csv
        parts = filename.replace('.csv', '').split('_')
        
        if len(parts) >= 3:
            test_type = '_'.join(parts[:-2])
            mode = parts[-2]
            
            df = pd.read_csv(csv_file)
            key = f"{test_type}_{mode}"
            results[key] = df
            print(f"Loaded: {filename} ({len(df)} rows)")
    
    return results

def calculate_statistics(df, duration_col='duration_ms'):
    """Calculate statistics for a dataframe"""
    stats = df.groupby('file_size_mb')[duration_col].agg([
        ('mean', 'mean'),
        ('median', 'median'),
        ('std', 'std'),
        ('min', 'min'),
        ('max', 'max'),
        ('p95', lambda x: x.quantile(0.95)),
        ('p99', lambda x: x.quantile(0.99))
    ]).round(2)
    
    return stats

def compare_modes(results, test_type):
    """Compare direct vs proxy performance for a test type"""
    direct_key = f"{test_type}_direct"
    proxy_key = f"{test_type}_proxy"
    
    if direct_key not in results or proxy_key not in results:
        print(f"Missing data for {test_type} comparison")
        return None
    
    direct_df = results[direct_key]
    proxy_df = results[proxy_key]
    
    # Determine duration column
    duration_col = 'duration_ms'
    if 'duration_ms' not in direct_df.columns:
        if 'total_duration_ms' in direct_df.columns:
            duration_col = 'total_duration_ms'
        else:
            print(f"No duration column found in {test_type}")
            return None
    
    direct_stats = calculate_statistics(direct_df, duration_col)
    proxy_stats = calculate_statistics(proxy_df, duration_col)
    
    # Separate proxy iteration 1 (cache miss) from 2-5 (cache hits)
    proxy_iter1 = proxy_df[proxy_df['iteration'] == 1].groupby('file_size_mb')[duration_col].mean()
    proxy_iter2plus = proxy_df[proxy_df['iteration'] > 1].groupby('file_size_mb')[duration_col].mean()
    
    # Calculate improvement/degradation
    comparison = pd.DataFrame({
        'direct_mean': direct_stats['mean'],
        'proxy_iter1_mean': proxy_iter1,
        'proxy_iter2plus_mean': proxy_iter2plus,
        'proxy_all_mean': proxy_stats['mean'],
        'cache_miss_diff_pct': ((proxy_iter1 - direct_stats['mean']) / direct_stats['mean'] * 100).round(2),
        'cache_hit_diff_pct': ((proxy_iter2plus - direct_stats['mean']) / direct_stats['mean'] * 100).round(2),
        'direct_p95': direct_stats['p95'],
        'proxy_p95': proxy_stats['p95']
    })
    
    return comparison

def analyze_throughput(results, test_type):
    """Analyze throughput for GET operations"""
    direct_key = f"{test_type}_direct"
    proxy_key = f"{test_type}_proxy"
    
    if direct_key not in results or proxy_key not in results:
        return None
    
    direct_df = results[direct_key]
    proxy_df = results[proxy_key]
    
    if 'throughput_mbps' not in direct_df.columns:
        return None
    
    direct_throughput = direct_df.groupby('file_size_mb')['throughput_mbps'].agg(['mean', 'median', 'std']).round(2)
    proxy_throughput = proxy_df.groupby('file_size_mb')['throughput_mbps'].agg(['mean', 'median', 'std']).round(2)
    
    comparison = pd.DataFrame({
        'direct_mean_mbps': direct_throughput['mean'],
        'proxy_mean_mbps': proxy_throughput['mean'],
        'improvement_pct': ((proxy_throughput['mean'] - direct_throughput['mean']) / direct_throughput['mean'] * 100).round(2)
    })
    
    return comparison

def analyze_get_after_put(results):
    """Analyze Get-after-Put performance"""
    direct_key = "get_after_put_direct"
    proxy_key = "get_after_put_proxy"
    
    if direct_key not in results or proxy_key not in results:
        return None
    
    direct_df = results[direct_key]
    proxy_df = results[proxy_key]
    
    direct_stats = direct_df.groupby('file_size_mb').agg({
        'put_duration_ms': ['mean', 'median'],
        'get_duration_ms': ['mean', 'median'],
        'total_duration_ms': ['mean', 'median']
    }).round(2)
    
    proxy_stats = proxy_df.groupby('file_size_mb').agg({
        'put_duration_ms': ['mean', 'median'],
        'get_duration_ms': ['mean', 'median'],
        'total_duration_ms': ['mean', 'median']
    }).round(2)
    
    return {
        'direct': direct_stats,
        'proxy': proxy_stats
    }

def generate_report(results, output_file):
    """Generate comprehensive analysis report"""
    with open(output_file, 'w') as f:
        f.write("=" * 80 + "\n")
        f.write("S3 PROXY PERFORMANCE TEST ANALYSIS\n")
        f.write("=" * 80 + "\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        # HeadObject Analysis
        f.write("\n" + "=" * 80 + "\n")
        f.write("HEAD OBJECT OPERATIONS\n")
        f.write("=" * 80 + "\n")
        head_comparison = compare_modes(results, 'head')
        if head_comparison is not None:
            f.write("\nPerformance Comparison (Direct vs Proxy):\n")
            f.write(head_comparison.to_string())
            f.write("\n\nInterpretation:\n")
            cache_miss_avg = head_comparison['cache_miss_diff_pct'].mean()
            cache_hit_avg = head_comparison['cache_hit_diff_pct'].mean()
            f.write(f"  Cache Miss (iter 1): {cache_miss_avg:+.1f}% vs direct\n")
            f.write(f"  Cache Hit (iter 2-5): {cache_hit_avg:+.1f}% vs direct\n")
            if cache_hit_avg < 0:
                f.write(f"  ✓ Cache provides {abs(cache_hit_avg):.1f}% improvement\n")
            else:
                f.write(f"  ✗ Cache has {cache_hit_avg:.1f}% overhead\n")
        
        # GET Operations - AWS CLI
        f.write("\n" + "=" * 80 + "\n")
        f.write("GET OPERATIONS - AWS CLI (S3 Common Runtime)\n")
        f.write("=" * 80 + "\n")
        get_awscli_comparison = compare_modes(results, 'get_awscli')
        if get_awscli_comparison is not None:
            f.write("\nLatency Comparison:\n")
            f.write(get_awscli_comparison.to_string())
            
            throughput_comparison = analyze_throughput(results, 'get_awscli')
            if throughput_comparison is not None:
                f.write("\n\nThroughput Comparison:\n")
                f.write(throughput_comparison.to_string())
                f.write("\n\nInterpretation:\n")
                avg_improvement = throughput_comparison['improvement_pct'].mean()
                if avg_improvement > 0:
                    f.write(f"  ✓ Proxy provides {avg_improvement:.1f}% throughput improvement on average\n")
                else:
                    f.write(f"  ✗ Proxy has {abs(avg_improvement):.1f}% throughput degradation on average\n")
        
        # GET Operations - s5cmd
        f.write("\n" + "=" * 80 + "\n")
        f.write("GET OPERATIONS - s5cmd\n")
        f.write("=" * 80 + "\n")
        get_s5cmd_comparison = compare_modes(results, 'get_s5cmd')
        if get_s5cmd_comparison is not None:
            f.write("\nLatency Comparison:\n")
            f.write(get_s5cmd_comparison.to_string())
            
            throughput_comparison = analyze_throughput(results, 'get_s5cmd')
            if throughput_comparison is not None:
                f.write("\n\nThroughput Comparison:\n")
                f.write(throughput_comparison.to_string())
        
        # Multipart Upload
        f.write("\n" + "=" * 80 + "\n")
        f.write("MULTIPART UPLOAD OPERATIONS\n")
        f.write("=" * 80 + "\n")
        multipart_comparison = compare_modes(results, 'multipart')
        if multipart_comparison is not None:
            f.write("\nPerformance Comparison:\n")
            f.write(multipart_comparison.to_string())
            
            throughput_comparison = analyze_throughput(results, 'multipart')
            if throughput_comparison is not None:
                f.write("\n\nThroughput Comparison:\n")
                f.write(throughput_comparison.to_string())
        
        # Get-after-Put
        f.write("\n" + "=" * 80 + "\n")
        f.write("GET-AFTER-PUT OPERATIONS\n")
        f.write("=" * 80 + "\n")
        gap_stats = analyze_get_after_put(results)
        if gap_stats is not None:
            f.write("\nDirect Mode Statistics:\n")
            f.write(gap_stats['direct'].to_string())
            f.write("\n\nProxy Mode Statistics:\n")
            f.write(gap_stats['proxy'].to_string())
            f.write("\n\nInterpretation:\n")
            f.write("  This test measures cache effectiveness for recently uploaded objects.\n")
            f.write("  Lower GET times in proxy mode indicate successful cache population during PUT.\n")
        
        # Summary
        f.write("\n" + "=" * 80 + "\n")
        f.write("SUMMARY\n")
        f.write("=" * 80 + "\n")
        f.write("\nKey Findings:\n")
        
        # Calculate overall cache effectiveness
        if get_awscli_comparison is not None:
            cache_hit_improvement = -get_awscli_comparison['diff_pct'].mean()
            f.write(f"  • Cache provides ~{cache_hit_improvement:.1f}% latency improvement for GET operations\n")
        
        if head_comparison is not None:
            head_improvement = -head_comparison['diff_pct'].mean()
            f.write(f"  • HeadObject operations are ~{head_improvement:.1f}% faster with proxy\n")
        
        f.write("\n" + "=" * 80 + "\n")
    
    print(f"\nAnalysis report saved to: {output_file}")

def main():
    parser = argparse.ArgumentParser(description='Analyze S3 proxy performance test results')
    parser.add_argument('--results-dir', default='./tests/performance/perf_test_results',
                       help='Directory containing test results (default: ./tests/performance/perf_test_results)')
    parser.add_argument('--timestamp', help='Specific timestamp to analyze (optional)')
    parser.add_argument('--output', default=None,
                       help='Output file for analysis report (default: results_dir/analysis_TIMESTAMP.txt)')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.results_dir):
        print(f"Error: Results directory not found: {args.results_dir}")
        sys.exit(1)
    
    print(f"Loading results from: {args.results_dir}")
    results = load_results(args.results_dir, args.timestamp)
    
    if not results:
        print("No results found to analyze")
        sys.exit(1)
    
    print(f"\nFound {len(results)} result sets")
    
    # Generate output filename
    if args.output is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        args.output = os.path.join(args.results_dir, f'analysis_{timestamp}.txt')
    
    generate_report(results, args.output)
    
    # Print to console as well
    with open(args.output, 'r') as f:
        print("\n" + f.read())

if __name__ == '__main__':
    main()
