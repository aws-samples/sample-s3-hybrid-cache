# Test Platform Results

## Test Environment

- 3 proxy instances: m6in.2xlarge, us-west-2b, shared EFS cache
- Cache config: 100 GB disk, 1 GB RAM, TinyLFU eviction
- Download coordination: enabled, 30s wait timeout
- Test data: 100 files, 0.1–100 MB (log-uniform), 50% compressible (~1.4 GB total per client)
- Test clients: 100 × c7gn.large (ARM, 25 Gbps network), same AZ
- Zero TTL bucket: `_settings.json` with `{"get_ttl": "0s"}` on shared EFS

## Test 1: Stampede (100 clients × 100 files)

All clients download all 100 files simultaneously, starting at the same wall-clock second.

### v1.5.2 Results (2026-02-17)

Proxy version 1.5.2 with object-level expiration. Cold cache for all proxy tests.

#### Latency Distribution

```
Bucket        Std TTL     Zero TTL    Direct S3
<250ms          32 (0.3%)    27 (0.3%)     0 (0.0%)
250-500ms        0 (0.0%)     0 (0.0%)     0 (0.0%)
500-750ms     6311 (63.1%)  6460 (64.6%)  7312 (73.1%)
750ms-1s      1298 (13.0%)  1191 (11.9%)   712 (7.1%)
1-1.5s         573 (5.7%)    685 (6.9%)  1005 (10.1%)
1.5-2s         249 (2.5%)    348 (3.5%)   476 (4.8%)
2-3s           508 (5.1%)    433 (4.3%)   494 (4.9%)
3-5s           527 (5.3%)    662 (6.6%)     1 (0.0%)
5-10s          502 (5.0%)    194 (1.9%)     0 (0.0%)
```

#### Percentiles

| Scenario | P50 | P90 | P95 | P99 | Max |
|----------|-----|-----|-----|-----|-----|
| Standard TTL (proxy, ~10yr) | 601 ms | 3,076 ms | 5,011 ms | 7,048 ms | 8,169 ms |
| Zero TTL (proxy, get_ttl=0s) | 557 ms | 2,708 ms | 3,859 ms | 5,483 ms | 7,681 ms |
| Direct to S3 (no proxy) | 615 ms | 1,484 ms | 1,997 ms | 2,600 ms | 3,193 ms |

#### Proxy Metrics

| Metric | Standard TTL | Zero TTL |
|--------|-------------|----------|
| Total proxy requests | 17,168 | 18,026 |
| RAM cache hits | 8,692 (89.2%) | 0 (0.0%) |
| Disk cache hits | 4,366 (89.2%) | 13,430 (95.8%) |
| S3 fetches (disk misses) | 526 | 583 |
| S3 transfer saved | 226.3 GB | 236.7 GB |
| Errors | 0 | 0 |

#### Observations

- The 3-10s tail in standard TTL is download coordination: concurrent requests for the same uncached object wait while the first request fetches from S3. Larger files take longer to download, so waiters block longer.
- Direct S3 has no tail beyond 3.2s because every client fetches independently — no coordination overhead, but also no cache benefit.
- Zero TTL has a shorter tail than standard TTL because on warm cache, every request does a quick 304 revalidation (~100-200ms S3 round-trip) rather than waiting for a full download.
- Zero TTL correctly shows 0 RAM cache hits — `ram_cache_eligible` is forced false when `get_ttl=0`.
- Zero TTL disk "hits" (95.8%) are revalidation-served: data found on disk, confirmed fresh via 304, served from cache.
- Standard TTL: 526 S3 fetches for 10,000 downloads = 94.7% of requests avoided S3.
- Zero TTL: 583 S3 fetches (cold cache misses) + ~9,400 conditional 304 requests = all requests touch S3, but most transfer only headers.

### v1.2.3 Results (2026-02-10, historical)

| Metric | Value |
|--------|-------|
| Total requests | 10,000 |
| Errors | 0 |
| Latency p50 | 564 ms |
| Latency p95 | 6,074 ms |
| Latency p99 | 11,270 ms |
| Latency mean | 1,266 ms |
| Total data | 141 GB |
| Wall-clock time | 132 s |
| Aggregate throughput | 8.96 Gbps |

Download coordination across 3 proxies:

| Proxy | Fetchers (S3) | Waiters (cache) | Coalesce rate |
|-------|--------------|-----------------|---------------|
| Native-1 | 87 | 391 | 82% |
| Native-3 | 79 | 452 | 85% |
| Native-4 | 86 | 406 | 83% |
| Total | 252 | 1,249 | 83% |

### Warm Cache

| Metric | Value |
|--------|-------|
| Total requests | 10,000 |
| Errors | 0 |
| Latency p50 | 578 ms |
| Latency p95 | 839 ms |
| Latency p99 | 1,247 ms |
| Latency mean | 623 ms |
| Total data | 141 GB |
| Wall-clock time | 73 s |
| Aggregate throughput | 16.23 Gbps |

### Direct to S3 (baseline, no proxy)

| Metric | Value |
|--------|-------|
| Total requests | 10,000 |
| Errors | 0 |
| Latency p50 | 634 ms |
| Latency p95 | 1,988 ms |
| Latency p99 | 2,540 ms |
| Latency mean | 835 ms |
| Total data | 141 GB |
| Wall-clock time | 89 s |
| Aggregate throughput | 13.29 Gbps |

### Comparison

| Scenario | p50 | p95 | p99 | Throughput |
|----------|-----|-----|-----|------------|
| Direct to S3 | 634 ms | 1,988 ms | 2,540 ms | 13.3 Gbps |
| Proxy (cold) | 564 ms | 6,074 ms | 11,270 ms | 9.0 Gbps |
| Proxy (warm) | 578 ms | 839 ms | 1,247 ms | 16.2 Gbps |

- Warm cache: 22% higher throughput, 2.4× lower p95 than direct S3
- Cold cache p50 faster than direct S3 due to coalescing
- 83% of cold-cache requests coalesced (1,249 of ~1,500 avoided S3)

## Test 2: Random Range Reads + Overwrites (100 clients)

Each client continuously downloads random 8MB ranges with 80/20 file bias.
~5% of operations are overwrite uploads routed through the proxy (or direct to S3 for baseline).

### v1.5.2 Results (2026-02-17, FSxZ 10240 MB/s, 20 min)

#### Latency Distribution — Range Reads

```
Bucket        Proxy+FSxZ       Direct S3
<50ms              0 (0.0%)         0 (0.0%)
50-100ms           0 (0.0%)         0 (0.0%)
100-250ms          0 (0.0%)         0 (0.0%)
250-500ms        122 (0.1%)         0 (0.0%)
500ms-1s     127,139 (97.1%)  183,721 (100.0%)
1-2s           1,925 (1.5%)        33 (0.0%)
2-5s           1,656 (1.3%)         9 (0.0%)
5s+               29 (0.0%)         1 (0.0%)
```

#### Percentiles — Range Reads

| Scenario | Requests | P50 | P90 | P95 | P99 | Max |
|----------|----------|-----|-----|-----|-----|-----|
| Proxy + FSxZ | 130,871 | 566 ms | 669 ms | 744 ms | 2,338 ms | 7,283 ms |
| Direct S3 | 183,764 | 582 ms | 632 ms | 641 ms | 689 ms | 9,002 ms |

#### Overwrite Uploads

| Scenario | Requests | P50 | P90 | P95 | P99 |
|----------|----------|-----|-----|-----|-----|
| Proxy + FSxZ | 8,620 | 641 ms | 917 ms | 1,171 ms | 1,323 ms |
| Direct S3 | 10,013 | 640 ms | 835 ms | 1,005 ms | 1,096 ms |

#### Proxy Metrics (FSxZ run, 3 proxies)

| Metric | Value |
|--------|-------|
| Total proxy requests | 222,043 |
| RAM cache hits | 120,377 (50.7%) |
| Disk cache hits | 13,816 (14.4%) |
| S3 transfer saved | 856.4 GB |

#### Observations

- Range read P50 is comparable: 566ms (proxy) vs 582ms (direct). The proxy adds minimal overhead for cache hits.
- The proxy's P99 tail (2.3s) is higher than direct S3 (689ms) due to download coordination waits and cache write contention during cold-cache population.
- 97% of proxy range reads complete in under 1s vs 100% for direct S3 — the 3% tail is cache-miss/coordination overhead.
- RAM cache hit rate of 50.7% reflects the 80/20 bias — hot ranges stay in RAM.
- Disk cache hit rate of 14.4% is expected for random 8MB ranges across 100 files — low overlap between random range offsets.
- Direct S3 achieves higher request throughput (193K vs 139K in 20 min) because every request is independent with no coordination overhead.
- 856 GB S3 transfer saved despite low disk hit rate — RAM cache serves the hot ranges efficiently.

### v1.2.3 Results (2026-02-10, EFS, 120s, historical)

| Metric | Value |
|--------|-------|
| Total requests | 15,780 |
| Range reads | 14,938 |
| Overwrite uploads | 842 |
| True errors | 3,222 |
| Range invalid (expected) | 2,151 |
| Read latency p50 | 691 ms |
| Read latency p95 | 1,389 ms |
| Read latency p99 | 1,911 ms |

### Finding: Stale Range Data After Overwrite

When a file is overwritten via PUT through the proxy, the proxy caches the new object but does not invalidate previously cached range files for the old version. Subsequent range reads may serve stale data from old range files, causing checksum mismatches detected by the AWS CLI. The 3,222 true errors are checksum failures from this stale data.

This is a cache consistency gap: PUT write-through updates the object metadata and stores the new data as a range, but old range files from previous GET requests remain on disk and may be served for range requests that overlap with them.
