#!/bin/bash
set -euo pipefail
# Download test results from S3 and prepare for analysis
# Usage: collect-results.sh [run_id]

RUN_ID="${1:-$(cat /tmp/last-test-run-id.txt 2>/dev/null || echo '')}"
if [[ -z "$RUN_ID" ]]; then
    echo "Usage: collect-results.sh <run_id>"
    echo "No run_id provided and no last-test-run-id.txt found."
    exit 1
fi

REGION="us-west-2"
RESULTS_BUCKET="s3-proxy-test-results"
DUALSTACK_ENDPOINT="https://s3.dualstack.us-west-2.amazonaws.com"
LOCAL_DIR="nonpublic/test-platform/results/$RUN_ID"

echo "Collecting results for run: $RUN_ID"

mkdir -p "$LOCAL_DIR"

aws s3 sync "s3://$RESULTS_BUCKET/$RUN_ID/" "$LOCAL_DIR/" \
    --region "$REGION" --endpoint-url "$DUALSTACK_ENDPOINT" --no-cli-pager --quiet

# Count results
INSTANCE_COUNT=$(ls -d "$LOCAL_DIR"/i-* 2>/dev/null | wc -l | tr -d ' ')
CSV_COUNT=$(find "$LOCAL_DIR" -name "*.csv" | wc -l | tr -d ' ')

echo "Downloaded: $CSV_COUNT CSV files from $INSTANCE_COUNT instances"
echo "Location: $LOCAL_DIR/"
echo ""
echo "Generate graphs:"
echo "  python3 nonpublic/test-platform/orchestrator/graph.py $LOCAL_DIR"
