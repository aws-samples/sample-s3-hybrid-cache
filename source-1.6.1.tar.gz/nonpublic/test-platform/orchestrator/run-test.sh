#!/bin/bash
set -euo pipefail
# Orchestrate a test run across all fleet instances via SSM
# Usage: run-test.sh <stampede|ranges> [duration_secs]

TEST_TYPE="${1:?Usage: run-test.sh <stampede|ranges> [duration_secs]}"
DURATION="${2:-60}"
REGION="us-west-2"
RESULTS_BUCKET="s3-proxy-test-results"
DUALSTACK_ENDPOINT="https://s3.dualstack.us-west-2.amazonaws.com"

RUN_ID="${TEST_TYPE}-$(date +%Y%m%d-%H%M%S)"

# Get all running test fleet instance IDs
INSTANCE_IDS=$(aws ec2 describe-instances --region "$REGION" \
    --filters "Name=tag:Fleet,Values=test-platform" "Name=instance-state-name,Values=running" \
    --query 'Reservations[].Instances[].InstanceId' --output text --no-cli-pager)

if [[ -z "$INSTANCE_IDS" ]]; then
    echo "ERROR: No running test instances found. Run launch-fleet.sh first."
    exit 1
fi

COUNT=$(echo "$INSTANCE_IDS" | wc -w | tr -d ' ')
echo "Run ID: $RUN_ID"
echo "Test: $TEST_TYPE"
echo "Fleet: $COUNT instances"

# Upload workload scripts to S3 for clients to download
SCRIPT_DIR="$(cd "$(dirname "$0")/../workloads" && pwd)"
SCRIPTS_PREFIX="scripts/$(date +%Y%m%d)"

echo "Uploading workload scripts to s3://$RESULTS_BUCKET/$SCRIPTS_PREFIX/ ..."
for f in "$SCRIPT_DIR"/common.sh "$SCRIPT_DIR"/test1-stampede.sh "$SCRIPT_DIR"/test1-stampede-direct.sh "$SCRIPT_DIR"/test2-random-range.sh; do
    aws s3 cp "$f" "s3://$RESULTS_BUCKET/$SCRIPTS_PREFIX/$(basename "$f")" \
        --region "$REGION" --endpoint-url "$DUALSTACK_ENDPOINT" --no-cli-pager --quiet
done

case "$TEST_TYPE" in
    stampede)
        START_EPOCH=$(( $(date +%s) + 30 ))  # 30s from now for SSM delivery + script download
        echo "Synchronized start at epoch: $START_EPOCH"

        CMD_FILE=$(mktemp)
        cat > "$CMD_FILE" << EOF
{
    "commands": [
        "aws s3 cp s3://$RESULTS_BUCKET/$SCRIPTS_PREFIX/common.sh /tmp/common.sh --region $REGION --endpoint-url $DUALSTACK_ENDPOINT --no-cli-pager --quiet",
        "aws s3 cp s3://$RESULTS_BUCKET/$SCRIPTS_PREFIX/test1-stampede.sh /tmp/test1-stampede.sh --region $REGION --endpoint-url $DUALSTACK_ENDPOINT --no-cli-pager --quiet",
        "chmod +x /tmp/common.sh /tmp/test1-stampede.sh",
        "sed -i 's|SCRIPT_DIR=.*|SCRIPT_DIR=/tmp|' /tmp/test1-stampede.sh",
        "bash /tmp/test1-stampede.sh $RUN_ID $START_EPOCH 2>&1"
    ]
}
EOF
        ;;
    stampede-direct)
        START_EPOCH=$(( $(date +%s) + 30 ))
        echo "Synchronized start at epoch: $START_EPOCH (DIRECT to S3, no proxy)"

        CMD_FILE=$(mktemp)
        cat > "$CMD_FILE" << EOF
{
    "commands": [
        "aws s3 cp s3://$RESULTS_BUCKET/$SCRIPTS_PREFIX/common.sh /tmp/common.sh --region $REGION --endpoint-url $DUALSTACK_ENDPOINT --no-cli-pager --quiet",
        "aws s3 cp s3://$RESULTS_BUCKET/$SCRIPTS_PREFIX/test1-stampede-direct.sh /tmp/test1-stampede-direct.sh --region $REGION --endpoint-url $DUALSTACK_ENDPOINT --no-cli-pager --quiet",
        "chmod +x /tmp/common.sh /tmp/test1-stampede-direct.sh",
        "sed -i 's|SCRIPT_DIR=.*|SCRIPT_DIR=/tmp|' /tmp/test1-stampede-direct.sh",
        "bash /tmp/test1-stampede-direct.sh $RUN_ID $START_EPOCH 2>&1"
    ]
}
EOF
        ;;
    ranges)
        CMD_FILE=$(mktemp)
        cat > "$CMD_FILE" << EOF
{
    "commands": [
        "aws s3 cp s3://$RESULTS_BUCKET/$SCRIPTS_PREFIX/common.sh /tmp/common.sh --region $REGION --endpoint-url $DUALSTACK_ENDPOINT --no-cli-pager --quiet",
        "aws s3 cp s3://$RESULTS_BUCKET/$SCRIPTS_PREFIX/test2-random-range.sh /tmp/test2-random-range.sh --region $REGION --endpoint-url $DUALSTACK_ENDPOINT --no-cli-pager --quiet",
        "chmod +x /tmp/common.sh /tmp/test2-random-range.sh",
        "sed -i 's|SCRIPT_DIR=.*|SCRIPT_DIR=/tmp|' /tmp/test2-random-range.sh",
        "bash /tmp/test2-random-range.sh $RUN_ID $DURATION 2>&1"
    ]
}
EOF
        ;;
    *)
        echo "Unknown test type: $TEST_TYPE (use 'stampede' or 'ranges')"
        exit 1
        ;;
esac

# Use tag-based targeting to avoid 50-instance limit
COMMAND_ID=$(aws ssm send-command --region "$REGION" \
    --targets "Key=tag:Fleet,Values=test-platform" \
    --document-name "AWS-RunShellScript" \
    --parameters "file://$CMD_FILE" \
    --timeout-seconds 600 \
    --max-concurrency "100%" \
    --output text --query 'Command.CommandId' --no-cli-pager)

rm -f "$CMD_FILE"

echo ""
echo "SSM Command ID: $COMMAND_ID"
echo "Run ID: $RUN_ID"
echo "Fleet: $COUNT instances (tag-targeted)"
echo ""
echo "Monitor progress:"
echo "  aws ssm list-command-invocations --region $REGION --command-id $COMMAND_ID --query 'CommandInvocations[].[Status]' --output text --no-cli-pager | sort | uniq -c"
echo ""
echo "Check individual instance:"
echo "  aws ssm get-command-invocation --region $REGION --command-id $COMMAND_ID --instance-id <ID> --query '[Status,StandardOutputContent]' --output text --no-cli-pager"
echo ""
echo "Collect results after completion:"
echo "  nonpublic/test-platform/orchestrator/collect-results.sh $RUN_ID"

echo "$RUN_ID" > /tmp/last-test-run-id.txt
