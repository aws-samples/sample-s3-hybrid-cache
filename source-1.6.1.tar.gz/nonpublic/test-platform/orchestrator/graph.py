#!/usr/bin/env python3
"""
Generate performance graphs from test platform results.

Usage: python3 graph.py <results_dir>

Produces PNG charts and a summary.txt in the results directory.
"""

import csv
import os
import sys
from collections import defaultdict
from pathlib import Path

try:
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
except ImportError:
    print("ERROR: matplotlib required. Install with: pip3 install matplotlib")
    sys.exit(1)

import statistics


def load_csvs(results_dir, filename_pattern):
    """Load all CSVs matching pattern across instance subdirectories."""
    rows = []
    for instance_dir in sorted(Path(results_dir).iterdir()):
        if not instance_dir.is_dir() or not instance_dir.name.startswith("i-"):
            continue
        instance_id = instance_dir.name
        for csv_file in instance_dir.glob(filename_pattern):
            with open(csv_file) as f:
                reader = csv.DictReader(f)
                for row in reader:
                    row["_instance"] = instance_id
                    rows.append(row)
    return rows


def graph_stampede(results_dir):
    """Generate stampede test graphs."""
    rows = load_csvs(results_dir, "stampede-results.csv")
    if not rows:
        print("No stampede results found.")
        return

    instances = sorted(set(r["_instance"] for r in rows))
    print(f"Stampede: {len(rows)} data points from {len(instances)} instances")

    # --- Per-file latency box plot ---
    file_latencies = defaultdict(list)
    for r in rows:
        try:
            fnum = int(r["file_number"])
            dur = float(r["duration_ms"])
            file_latencies[fnum].append(dur)
        except (ValueError, KeyError):
            continue

    fig, ax = plt.subplots(figsize=(16, 6))
    file_nums = sorted(file_latencies.keys())
    data = [file_latencies[f] for f in file_nums]

    positions = list(range(len(file_nums)))
    bp = ax.boxplot(data, positions=positions, widths=0.6, patch_artist=True,
                    showfliers=False, medianprops=dict(color='red', linewidth=1.5))
    for patch in bp['boxes']:
        patch.set_facecolor('#4C72B0')
        patch.set_alpha(0.7)

    ax.set_xlabel("File Number")
    ax.set_ylabel("Latency (ms)")
    ax.set_title(f"Stampede: Per-File Download Latency ({len(instances)} clients)")
    step = max(1, len(file_nums) // 20)
    ax.set_xticks(positions[::step])
    ax.set_xticklabels([str(file_nums[i]) for i in range(0, len(file_nums), step)])
    ax.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, "stampede_latency.png"), dpi=150)
    plt.close()
    print(f"  Saved stampede_latency.png")

    # --- Per-instance throughput (wall-clock: total bytes / elapsed time) ---
    instance_bytes = defaultdict(int)
    instance_start = {}  # earliest start_ms
    instance_end = {}    # latest (start_ms + duration_ms)
    for r in rows:
        try:
            inst = r["_instance"]
            start = int(r["start_ms"])
            dur = int(float(r["duration_ms"]))
            size = int(r["size_bytes"])
            instance_bytes[inst] += size
            end = start + dur
            if inst not in instance_start or start < instance_start[inst]:
                instance_start[inst] = start
            if inst not in instance_end or end > instance_end[inst]:
                instance_end[inst] = end
        except (ValueError, KeyError):
            continue

    instance_throughput = {}
    for inst in instances:
        elapsed_ms = instance_end.get(inst, 0) - instance_start.get(inst, 0)
        if elapsed_ms > 0:
            instance_throughput[inst] = instance_bytes[inst] * 8 / elapsed_ms / 1_000_000  # Gbps
        else:
            instance_throughput[inst] = 0

    fig, ax = plt.subplots(figsize=(12, 5))
    x = range(len(instances))
    throughputs = [instance_throughput.get(inst, 0) for inst in instances]
    ax.bar(x, throughputs, color='#4C72B0', alpha=0.8)
    ax.set_xlabel("Client Instance")
    ax.set_ylabel("Throughput (Gbps)")
    ax.set_title(f"Stampede: Per-Client Wall-Clock Throughput")
    ax.set_xticks(x)
    ax.set_xticklabels([inst[-4:] for inst in instances], rotation=45)
    ax.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, "stampede_throughput.png"), dpi=150)
    plt.close()
    print(f"  Saved stampede_throughput.png")

    # --- Aggregate throughput: total bytes across all instances / wall-clock elapsed ---
    all_starts = [instance_start[i] for i in instances if i in instance_start]
    all_ends = [instance_end[i] for i in instances if i in instance_end]
    total_bytes = sum(instance_bytes.values())
    if all_starts and all_ends:
        wall_clock_ms = max(all_ends) - min(all_starts)
        agg_throughput_gbps = total_bytes * 8 / wall_clock_ms / 1_000_000 if wall_clock_ms > 0 else 0
    else:
        wall_clock_ms = 0
        agg_throughput_gbps = 0

    # --- Summary stats ---
    all_latencies = [float(r["duration_ms"]) for r in rows if r.get("status") == "ok"]
    return {
        "test": "stampede",
        "instances": len(instances),
        "total_requests": len(rows),
        "errors": sum(1 for r in rows if r.get("status") == "error"),
        "latency_p50": statistics.median(all_latencies) if all_latencies else 0,
        "latency_p95": sorted(all_latencies)[int(len(all_latencies) * 0.95)] if all_latencies else 0,
        "latency_p99": sorted(all_latencies)[int(len(all_latencies) * 0.99)] if all_latencies else 0,
        "latency_mean": statistics.mean(all_latencies) if all_latencies else 0,
        "total_bytes": total_bytes,
        "wall_clock_seconds": wall_clock_ms / 1000,
        "aggregate_throughput_gbps": agg_throughput_gbps,
    }


def graph_ranges(results_dir):
    """Generate random range test graphs."""
    rows = load_csvs(results_dir, "range-results.csv")
    if not rows:
        print("No range results found.")
        return

    instances = sorted(set(r["_instance"] for r in rows))
    # Separate reads from overwrites
    read_rows = [r for r in rows if r.get("op", "read") == "read"]
    overwrite_rows = [r for r in rows if r.get("op") == "overwrite"]
    print(f"Ranges: {len(read_rows)} reads, {len(overwrite_rows)} overwrites from {len(instances)} instances")

    # --- Latency CDF (reads only) ---
    latencies = sorted([float(r["duration_ms"]) for r in read_rows if r.get("status") == "ok"])
    if not latencies:
        print("  No successful range requests.")
        return

    fig, ax = plt.subplots(figsize=(10, 6))
    cdf_y = [i / len(latencies) for i in range(len(latencies))]
    ax.plot(latencies, cdf_y, linewidth=1.5, color='#4C72B0')
    ax.set_xlabel("Latency (ms)")
    ax.set_ylabel("Cumulative Probability")
    ax.set_title(f"Range Reads: Latency CDF ({len(instances)} clients, {len(latencies)} reads, {len(overwrite_rows)} overwrites)")
    ax.set_xscale('log')
    ax.grid(True, alpha=0.3)
    ax.axhline(y=0.5, color='gray', linestyle='--', alpha=0.5, label='p50')
    ax.axhline(y=0.95, color='orange', linestyle='--', alpha=0.5, label='p95')
    ax.axhline(y=0.99, color='red', linestyle='--', alpha=0.5, label='p99')
    ax.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, "ranges_latency_cdf.png"), dpi=150)
    plt.close()
    print(f"  Saved ranges_latency_cdf.png")

    # --- Throughput time series per instance (reads only) ---
    fig, ax = plt.subplots(figsize=(14, 6))

    for inst in instances:
        inst_rows = [r for r in read_rows if r["_instance"] == inst and r.get("status") == "ok"]
        if not inst_rows:
            continue
        times = sorted([int(r["start_ms"]) for r in inst_rows])
        if not times:
            continue
        t0 = times[0]
        buckets = defaultdict(float)
        for r in inst_rows:
            sec = (int(r["start_ms"]) - t0) // 1000
            buckets[sec] += float(r.get("throughput_mbps", 0))

        secs = sorted(buckets.keys())
        throughputs = [buckets[s] for s in secs]
        ax.plot(secs, throughputs, alpha=0.4, linewidth=0.8, label=inst[-4:])

    ax.set_xlabel("Time (seconds)")
    ax.set_ylabel("Throughput (Mbps)")
    ax.set_title(f"Range Reads: Per-Client Throughput Over Time")
    ax.grid(True, alpha=0.3)
    if len(instances) <= 15:
        ax.legend(fontsize=7, ncol=3)
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, "ranges_throughput_timeseries.png"), dpi=150)
    plt.close()
    print(f"  Saved ranges_throughput_timeseries.png")

    # --- File access distribution (reads + overwrites stacked) ---
    read_counts = defaultdict(int)
    overwrite_counts = defaultdict(int)
    for r in read_rows:
        try:
            read_counts[int(r["file_number"])] += 1
        except (ValueError, KeyError):
            continue
    for r in overwrite_rows:
        try:
            overwrite_counts[int(r["file_number"])] += 1
        except (ValueError, KeyError):
            continue

    all_fnums = sorted(set(list(read_counts.keys()) + list(overwrite_counts.keys())))
    fig, ax = plt.subplots(figsize=(12, 5))
    reads = [read_counts.get(f, 0) for f in all_fnums]
    overwrites = [overwrite_counts.get(f, 0) for f in all_fnums]
    ax.bar(all_fnums, reads, color='#4C72B0', alpha=0.8, width=1.0, label='Reads')
    ax.bar(all_fnums, overwrites, bottom=reads, color='#C44E52', alpha=0.8, width=1.0, label='Overwrites')
    ax.set_xlabel("File Number")
    ax.set_ylabel("Request Count")
    ax.set_title("Range Reads + Overwrites: File Access Distribution (80/20 bias)")
    ax.legend()
    ax.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, "ranges_file_distribution.png"), dpi=150)
    plt.close()
    print(f"  Saved ranges_file_distribution.png")

    return {
        "test": "ranges",
        "instances": len(instances),
        "total_requests": len(rows),
        "reads": len(read_rows),
        "overwrites": len(overwrite_rows),
        "errors": sum(1 for r in rows if r.get("status") == "error"),
        "range_invalid": sum(1 for r in rows if r.get("status") == "range_invalid"),
        "latency_p50": statistics.median(latencies),
        "latency_p95": sorted(latencies)[int(len(latencies) * 0.95)],
        "latency_p99": sorted(latencies)[int(len(latencies) * 0.99)],
        "latency_mean": statistics.mean(latencies),
        "requests_per_second": len(latencies) / (max(latencies) / 1000) if latencies else 0,
    }


def write_summary(results_dir, stats_list):
    """Write summary.txt with aggregate statistics."""
    summary_path = os.path.join(results_dir, "summary.txt")
    with open(summary_path, "w") as f:
        f.write(f"Test Platform Results Summary\n")
        f.write(f"{'=' * 60}\n\n")

        for stats in stats_list:
            if stats is None:
                continue
            f.write(f"Test: {stats['test']}\n")
            f.write(f"  Instances: {stats['instances']}\n")
            f.write(f"  Total requests: {stats['total_requests']}\n")
            f.write(f"  Errors: {stats['errors']}\n")
            if stats.get('range_invalid'):
                f.write(f"  Range invalid (after overwrite): {stats['range_invalid']}\n")
            f.write(f"  Latency p50: {stats['latency_p50']:.1f} ms\n")
            f.write(f"  Latency p95: {stats['latency_p95']:.1f} ms\n")
            f.write(f"  Latency p99: {stats['latency_p99']:.1f} ms\n")
            f.write(f"  Latency mean: {stats['latency_mean']:.1f} ms\n")
            if "aggregate_throughput_gbps" in stats:
                f.write(f"  Total bytes: {stats.get('total_bytes', 0) / 1024 / 1024:.1f} MB\n")
                f.write(f"  Wall-clock time: {stats.get('wall_clock_seconds', 0):.1f} s\n")
                f.write(f"  Aggregate throughput: {stats['aggregate_throughput_gbps']:.2f} Gbps\n")
            if "requests_per_second" in stats:
                f.write(f"  Reads: {stats.get('reads', stats['total_requests'])}\n")
                f.write(f"  Overwrites: {stats.get('overwrites', 0)}\n")
                f.write(f"  Requests/second: {stats['requests_per_second']:.1f}\n")
            f.write(f"\n")

    print(f"  Saved summary.txt")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 graph.py <results_dir>")
        sys.exit(1)

    results_dir = sys.argv[1]
    if not os.path.isdir(results_dir):
        print(f"ERROR: {results_dir} is not a directory")
        sys.exit(1)

    print(f"Processing results in: {results_dir}\n")

    stats = []
    stats.append(graph_stampede(results_dir))
    stats.append(graph_ranges(results_dir))

    write_summary(results_dir, stats)
    print(f"\nDone. Charts and summary in: {results_dir}/")


if __name__ == "__main__":
    main()
