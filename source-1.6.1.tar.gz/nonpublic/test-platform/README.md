# S3 Proxy Test Platform

Orchestrated load testing for the S3 proxy using a fleet of EC2 instances.

## Architecture

```
Your laptop (orchestrator)
    │
    ├── SSM send-command ──► Test Fleet (10-50+ c7gn.large instances)
    │                            │
    │                            ├── /etc/hosts routes S3 → proxy private IPs
    │                            ├── Downloads go to /dev/null (no disk bottleneck)
    │                            └── Results uploaded to S3 results bucket
    │
    ├── Proxy Fleet (3x m6in.2xlarge, us-west-2b)
    │       │
    │       └── EFS shared cache
    │
    └── collect-results.sh ──► Download CSVs from S3 ──► graph.py
```

All instances in us-west-2b, same subnet and security group as proxies.

## Quick Start

```bash
nonpublic/test-platform/infra/launch-fleet.sh 10        # Launch 10 test clients
nonpublic/test-platform/infra/fleet-status.sh            # Verify all online
nonpublic/test-platform/workloads/setup-data.sh          # Generate + upload 100 test files
nonpublic/test-platform/orchestrator/run-test.sh stampede # Run concurrent download test
nonpublic/test-platform/orchestrator/run-test.sh ranges   # Run random range test (60s)
nonpublic/test-platform/orchestrator/collect-results.sh   # Download results
nonpublic/test-platform/orchestrator/graph.py             # Generate charts
nonpublic/test-platform/infra/teardown-fleet.sh           # Terminate instances
```

## Test Workloads

### Test 1: Stampede (concurrent cache miss)

All clients download all 100 files simultaneously, starting at the same wall-clock second.
Tests download coordination (coalescing) under maximum concurrent cache miss pressure.

Measures: per-file latency, per-file throughput, aggregate throughput, coalescing effectiveness.

### Test 2: Random Range Reads (cache efficiency)

Each client continuously downloads random 8MB ranges from random files for a configurable
duration (default 60s). File selection uses 80/20 bias (80% of requests target the bottom
20% of files by number) to drive cache efficiency.

Measures: per-request latency, throughput, cache hit rate over time.

## Results

Results are uploaded to `s3://s3-proxy-test-results/{run-id}/` by each client instance.
`collect-results.sh` downloads them locally, and `graph.py` produces:

- `stampede_latency.png` — per-file latency heatmap across all clients
- `stampede_throughput.png` — aggregate throughput over time
- `ranges_latency_cdf.png` — CDF of range request latencies
- `ranges_throughput_timeseries.png` — throughput over time per client
- `summary.txt` — p50/p95/p99 latency, aggregate stats, coalescing metrics

## Instance Types

- Test clients: `c7gn.large` (ARM, 2 vCPU, 25 Gbps network) — network-optimized, no disk I/O
- Proxy instances: `m6in.2xlarge` (existing fleet)

## Configuration

Edit `workloads/common.sh` to change:
- Test bucket name
- Proxy IPs
- File count/sizes
- Test duration
