#!/bin/bash
set -euo pipefail
# Delete test data from S3

SCRIPT_DIR="$(cd "$(dirname "$0")/../workloads" && pwd)"
source "$SCRIPT_DIR/common.sh"

echo "Deleting all objects from s3://$TEST_BUCKET/"
aws s3 rm "s3://$TEST_BUCKET/" --recursive \
    --region "$REGION" --endpoint-url "$DUALSTACK_ENDPOINT" --no-cli-pager

echo "Removing bucket s3://$TEST_BUCKET"
aws s3 rb "s3://$TEST_BUCKET" \
    --region "$REGION" --endpoint-url "$DUALSTACK_ENDPOINT" --no-cli-pager 2>/dev/null || echo "Bucket may not be empty or already deleted"

echo "Cleanup complete."
