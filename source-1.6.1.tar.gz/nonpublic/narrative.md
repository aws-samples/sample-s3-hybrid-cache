S3 Hybrid Cache – an AWS code sample (https://gitlab.aws.dev/egummett/S3-accelerator) 

The purpose of this doc is to ensure the S3 service team have no objections to this SA-developed solution being published open-source on the aws-samples or aws-solutions-library-samples GitHub repositories.
Problem
Customers love the durability, features, and scalability of Amazon S3, and in the cloud it is the default storage platform. However, those with hybrid or on-premises workloads such as healthcare, life sciences, quantitative trading, and autonomous driving face challenges with bandwidth constraints, and/or data transfer out (DTO) costs – especially for repeat-read and read-after-write workflows for their on-premises devices.

As one quantitative trading firm explained: "We consume and store a significant amount of market data. Depending on the researcher, a subset needs low latency and high throughput access. The volume is too large to store on-premises without high cost... S3 handles this scenario, however it assumes consumers are cloud-based, or that on-premises deployments accept repeated DTO costs when multiple researchers access the same data."

Most existing solutions in this space are intended for Content Distribution Networks. A January 2026 blog https://www.getautonoma.com/blog/how-we-reduced-s3-egress-costs-by-70 launched an open-source cache to address performance and DTO challenges, accelerating performance and making it cheaper to adopt S3 with hybrid workloads, but as with other solutions this requires the cache to handle all authentication to S3. 

There are no existing caching solutions that support transparent authentication, native S3 protocols and shared storage.

Proposed Solution
S3 Hybrid Cache provides an intelligent caching layer that accelerates performance while minimizing data transfer costs. It allows customers to retain S3's full capabilities while leveraging minimal, customer-defined on-premises resources, addressing existing cache limitations through transparent pass-through authentication and shared storage.

Using file storage as cache simplifies resilient deployment at scale. Customers can utilize existing hardware, allocate capacity from gigabytes to petabytes, and determine appropriate resilience, availability, and performance levels. 

The cache has no credentials of its own and reuses client request signatures, ensuring S3 policies and IAM configurations remain the sole authentication mechanism. By intelligently injecting conditional headers, the proxy can authenticate every request against S3 without transferring data, or service cache hits immediately, reducing latency.
Architecture
The solution consists of one or more stateless proxy servers between client applications and Amazon S3, deployable in high availability configurations with shared storage backends using customer’s existing on-prem file storage. Clients connect using standard S3 API calls to HTTP endpoints, while HTTPS requests tunnel directly to S3 (un-cached) so that they are not blocked.
    ┌─────────────────────┐              ┌─────────────────────┐
    │   S3 Client (HTTP)  │              │  S3 Client (HTTPS)  │
    │   - AWS CLI         │              │   - AWS CLI         │
    │   - S3 SDK          │              │   - S3 SDK          │
    └──────────┬──────────┘              └──────────┬──────────┘
               │                                    │
               ▼                                    ▼
┌──────────────────────────────────────────────────────────────────┐
│                       S3 Proxy (1..N)                            │
│  ┌───────────────────────────┐    ┌───────────────────────────┐  │
│  │   HTTP Handler (Port 80)  │    │  HTTPS Handler (Port 443) │  │
│  │   - Caching               │    │   - TCP Passthrough       │  │
│  │   - Range Merging         │    │   - No Caching            │  │
│  │   - Streaming             │    │   - Direct to S3          │  │
│  └─────────────┬─────────────┘    └─────────────┬─────────────┘  │
│                │                                │                │
│                ▼                                │                │
│  ┌───────────────────────────┐                  │                │
│  │        RAM Cache          │                  │                │
│  │   - Metadata + ranges     │                  │                │
│  │   - Compression           │                  │                │
│  │   - Eviction              │                  │                │
│  └─────────────┬─────────────┘                  │                │
└────────────────┼────────────────────────────────┼────────────────┘
                 │                                │
                 ▼                                │
┌───────────────────────────────┐                 │
│   Shared Disk Cache (NFS)     │                 │
│   - Metadata + ranges         │                 │
│   - Compression               │                 │
│   - LRU/TinyLFU-like eviction │                 │
│   - Fixed or elastic size     │                 │
│   - Journaled writes          │                 │
└───────────────┬───────────────┘                 │
                │                                 │
                └────────────────┬────────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │    Amazon S3 (HTTPS)    │
                    └─────────────────────────┘

Workflow
Deploy quickly by cloning the open-source code from GitHub and setting up a test environment within minutes on a laptop or VM, with a simple ‘hosts file’ edit.

Production deployments require multiple servers with shared storage, a DNS zone for client traffic, and consideration of capacity constraints and security implications.

Once deployed, clients issue S3 requests to the HTTP endpoint (automated with an environment variable). The proxy determines if it can accelerate responses from cache. Cached valid objects are served immediately; otherwise, the proxy retrieves from S3 (over HTTPS), caches for future requests, and returns to the client.

The cache validates objects against S3 using conditional headers, balancing immediate hits with data freshness. Multiple proxies share cached objects, ensuring data is pulled from S3 only once, eliminating redundant transfers.
Outcome
The solution enables customers to architect on-premises workloads using native S3, with in-cloud-like performance. GetObject and HeadObject responses are identical whether from served S3 or cache, but accelerated where possible. PutObject requests (and multipart uploads) are streamed to S3 and the data cached. All other requests (HeadBucket, List, GetObjectTagging, etc.) are passed through.

Benefits include reduced data transfer costs, lower latency for frequently accessed data, and maintained S3 security policies. It supports cloud journeys by making object storage practical for on-premises use cases, encouraging broader S3 adoption across hybrid environments.
Success will be measured through Git clones, repository stars, customer feedback, and potentially through a custom header injected into requests.
FAQs
Q1: What security concerns might customers have? A: 1/ Data stored on the filesystem is not encrypted by the proxy and must be secured from access (like Mountpoint for Amazon S3’s cache). Encryption at rest can be provided by the filesystem if desired. Not applying it at the proxy removes challenges around key management and filesystem data reduction techniques (e.g. deduplication). 2/ Unless the proxy is configured to authenticate every request, any client that can access the proxy over the network can read cached data, regardless of encryption at rest. Customers will need to take care to control network access to the proxy. 3/ HTTPS is supported only for passthrough – clients must use HTTP to benefit from the cache.

Q2: Will the lack of HTTPS support be a blocker? A: Potentially, for some customers – tbd based on customer feedback. However, the proxies will run inside a customer’s secure network, potentially within the network segment where the application runs, and therefore the need for encryption-in-transit may be unnecessary. To be clear, all communication between the proxy and S3 is encrypted.

Q3: Why not use HTTPS_PROXY? A: HTTPS_PROXY uses the HTTP CONNECT method to create a tunnel, and the client performs a TLS handshake with the destination (S3) through that tunnel. The proxy cannot present a trusted certificate for the S3 endpoint, so it cannot terminate TLS or inspect the traffic — only relay encrypted bytes. Caching would require TLS interception with dynamic certificate generation and a custom CA trusted by all clients. Additionally, HTTPS_PROXY routes through a single proxy address without multi-value DNS support, preventing load balancing and failover.

Q4: Why not use a database to track metadata and access, instead of a filesystem? A: There are performance advantages to using a database, but this would add complexity to both deployment and HA design – particularly as this is intended for on-prem deployment.

Q5: Why not have a leader node? A: This would simplify tracking, file locking, etc., but would introduce complexity around leader elections and failures, and therefore complicate implementation of high availability. i.e. what if nodes cannot communicate with each other briefly? Etcd was considered and rejected – it could be more valuable if wide scale-out proves useful, as it would require at least 3 nodes for HA.

Q6: Can the cache do things like preloading? A: As the cache is transparent and has no credentials of its own, it cannot request data from S3 without a request. Currently customers could simply request all of a dataset upfront to warm the cache.

Q7: Will this work with S3-compatible storage, or just Amazon S3? A: Nothing about this solution is specific to Amazon S3. Any origin that is compatible with Amazon S3 should work with it.

Q8: Is any IP from Membrain in this project? How does this compare? A: No. It was developed independently, prior to the author looking at Membrain. Other than the ‘transparent cache’ concept (which was not derived from Membrain) there is no direct relation. Membrain is for in-AWS use cases, within Kubernetes nodes (at least for now). It is not expected to be open-sourced, or a good fit for hybrid use cases. This project is deliberately targeted at different use cases.

Q9: What will customers be most disappointed with? A: That this isn’t designed to run inside AWS. It could but would require a shared filesystem (EFS or FSxZ) to be provisioned. Membrain is a much better solution for use within AWS.

Q10: Is this similar to Storage Gateway / File Gateway? A: No. Gateway is a primarily a protocol converter, that also has caching capabilities. 

Appendix A: 5CQ

1.	Listen: Who is the customer and what insights do we have about them?
Customers with large quantities of data being written or read by devices such as scientific equipment, FPGAs, or on-premises HPC clusters. These customers love the durability, features, and scalability of Amazon S3 and use (or intend to) for their in-cloud workloads, and may burst compute in the cloud, but are put off writing all data direct to Amazon S3 due to the DTO cost and bandwidth required to meet their performance requirements of their repeat-read or read-after-write workflows. As customers discover they can build efficiently on-premises with S3 storage, additional use cases will emerge.

2.	Define: What is the prevailing customer problem/opportunity? What data informed this?

In the cloud, customers architect for object storage first. On-premises, file storage dominates. By improving both the price and performance of using Amazon S3 on-premises, we can simplify and accelerate customers’ journeys to the cloud. This is unrelated to protocol conversion and filesystems backed by object storage.

Existing on-premises object storage solutions do not enable of that data with cloud-based compute, analytics or AI services, and do not have the economics or features of S3.

There is an opportunity to provide a caching layer that preserves per-user authentication, coordinates across multiple cache instances to fetch data only once, and reduces redundant DTO costs. A customer quote:
“GSA [quantitative trading firm] consumes and stores a significant amount of marketdata. Depending on the researcher, a subset of the data needs to be accessed with low latency and high throughput. The volume of data is additionally too large to store on-premises without high cost and as we infrequently access a lot of the data and it should be intelligently tiered to reduce cost in mass storage scenarios. S3 handles this scenario for us, however it makes the assumption that consumers will be based in the cloud, or that the on-premises deployment is happy to pay for repeated DTO cost in a scenario where multiple researchers may be interested in the same data. [our current] nginx caching gateway is configured with credentials of its own, and as such assumes that anonymous access to all data is allowed. In the marketdata case, this is acceptable, but reduces flexibility when we need to access different types of data which may be considered private or confidential.
In addition, clients have to implement mechanisms to decide which local cache to use, as we run this in a pair. This can result in the same dataset being pulled twice, rather than once and shared between cache servers… Cache servers should be able to intelligently share objects between each other such that the data is cached/pulled only once over the direct connect.”

3.	Invent: What is the solution? Why is it the right solution versus alternatives?
Caching accelerates performance while minimizing data transfer costs. It allows customers to retain the features and capabilities of S3, accelerated with minimal, customer-defined, on-premises resources. Existing cache solutions are built for web-browser use cases, and don’t support transparent (pass-thru) authentication or shared storage. Key differentiators from existing solutions:
•	Transparent authentication: No cache credentials – reuses client request signatures, maintaining S3 policies and IAM as the sole authentication mechanism. By intelligently injecting conditional headers, the proxy can authenticate every request against S3 without data transfer or serve cache hits immediately – configurable per use case.
•	Shared file storage for cached data: Multiple cache servers share data, eliminating redundant S3 pulls. Customers use existing hardware with flexible capacity (GBs to PBs) and customizable resilience, availability, and performance to meet their needs.
•	Stateless proxies: Simplify high availability configurations by mimicking the DNS resolution behaviour of the S3 front-end fleet (multi-value answers, S3 clients dynamically bypass failed servers).

4.	Refine: How would we describe the end-to-end customer experience? What is the most important customer benefit?
Customers deploy on one or more servers and configure DNS, then clients can issue requests as usual. If the cache can accelerate the response, then it will. 

•	Quick start: Clone the open-source code from GitHub, and deploy in minutes on a laptop or VM with a simple hosts file edit.
•	Production deployment: Multiple servers with shared storage, DNS for client routing, plus capacity and security planning. Clients specify HTTP S3 endpoints (the proxy lacks a trusted amazonaws.com certificate; HTTPS requests tunnel directly to S3 without proxying, so they are not blocked).
•	The experience: Clients issue S3 requests as usual. The cache transparently accelerates responses when possible.
•	Most important benefit: Responses are the same whether served by S3 or the cache, but accelerated where possible. The cache is invisible to clients. 
5.	Test & Iterate: How will we define and measure success?
1/ Git clones, stars, and customer feedback. 2/ GBs read from and written to S3 via the cache (if possible to track using Via header added to requests)

