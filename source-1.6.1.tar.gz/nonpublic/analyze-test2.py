import csv, os, glob, json

def load_test2(results_dir):
    files = glob.glob(os.path.join(results_dir, "**", "*.csv"), recursive=True)
    reads = []
    overwrites = []
    errors = 0
    range_invalid = 0
    for f in files:
        with open(f, encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                d = int(row.get("duration_ms", 0))
                op = row.get("op", "read")
                status = row.get("status", "ok")
                if status == "error":
                    errors += 1
                elif status == "range_invalid":
                    range_invalid += 1
                if op == "read" and status == "ok":
                    reads.append(d)
                elif op == "overwrite":
                    overwrites.append(d)
    return sorted(reads), sorted(overwrites), errors, range_invalid, len(files)

def histogram(durations, label):
    buckets = [
        (0, 50, "<50ms"),
        (50, 100, "50-100ms"),
        (100, 250, "100-250ms"),
        (250, 500, "250-500ms"),
        (500, 1000, "500ms-1s"),
        (1000, 2000, "1-2s"),
        (2000, 5000, "2-5s"),
        (5000, 99999, "5s+"),
    ]
    n = len(durations)
    if n == 0:
        print(f"  {label}: No data")
        return

    p50 = durations[n // 2]
    p90 = durations[int(n * 0.9)]
    p95 = durations[int(n * 0.95)]
    p99 = durations[int(n * 0.99)]
    avg = sum(durations) / n

    print(f"\n  {label} ({n:,} requests)")
    print(f"  Avg: {avg:.0f}ms  |  P50: {p50}ms  |  P90: {p90}ms  |  P95: {p95}ms  |  P99: {p99}ms  |  Max: {durations[-1]}ms")
    print(f"  {'Bucket':<12} {'Count':>8} {'Pct':>7}")
    print(f"  {'-'*12} {'-'*8} {'-'*7}")
    for lo, hi, name in buckets:
        count = sum(1 for d in durations if lo <= d < hi)
        pct = count / n * 100
        bar = '#' * int(pct / 2)
        if count > 0:
            print(f"  {name:<12} {count:>8} {pct:>6.1f}% {bar}")

def load_metrics_v2(label):
    metrics_dir = "nonpublic/test-platform/results/metrics"
    totals = {}
    for inst in ["i-0c2dc9618325b3ac8", "i-07e18a197171fc9ee", "i-0f441137c0c3d2a98"]:
        path = os.path.join(metrics_dir, f"{label}-{inst}.json")
        if not os.path.exists(path):
            continue
        try:
            data = json.loads(open(path, encoding="utf-8").read())
        except:
            continue
        ram = data.get("ram_cache", {})
        totals.setdefault("ram_hits", 0)
        totals["ram_hits"] += ram.get("hits", 0)
        totals.setdefault("ram_misses", 0)
        totals["ram_misses"] += ram.get("misses", 0)
        disk = data.get("disk_cache", {})
        totals.setdefault("disk_hits", 0)
        totals["disk_hits"] += disk.get("hits", 0)
        totals.setdefault("disk_misses", 0)
        totals["disk_misses"] += disk.get("misses", 0)
        overall = data.get("overall", {})
        totals.setdefault("total_requests", 0)
        totals["total_requests"] += overall.get("total_requests", 0)
        totals.setdefault("s3_saved_bytes", 0)
        totals["s3_saved_bytes"] += overall.get("s3_transfer_saved_bytes", 0)

    rh = totals.get("ram_hits", 0)
    rm = totals.get("ram_misses", 0)
    dh = totals.get("disk_hits", 0)
    dm = totals.get("disk_misses", 0)
    print(f"\n  Proxy Metrics (3 proxies):")
    print(f"    Total requests: {totals.get('total_requests', 0):,}")
    print(f"    RAM:  hits={rh:,}  misses={rm:,}  rate={rh/(rh+rm)*100 if (rh+rm)>0 else 0:.1f}%")
    print(f"    Disk: hits={dh:,}  misses={dm:,}  rate={dh/(dh+dm)*100 if (dh+dm)>0 else 0:.1f}%")
    print(f"    S3 transfer saved: {totals.get('s3_saved_bytes', 0)/1e9:.1f} GB")

print("=" * 70)
print("  TEST 2: Random 8MB Range Reads + Overwrites (FSxZ, 20 min)")
print("=" * 70)

reads, overwrites, errors, range_invalid, instances = load_test2("nonpublic/test-platform/results/ranges-fsxz-20260217-221500")
print(f"\n  Instances: {instances}  |  Errors: {errors}  |  Range invalid: {range_invalid}")
histogram(reads, "Range Reads")
histogram(overwrites, "Overwrite Uploads")
load_metrics_v2("test2-fsxz")

print("\n")
print("=" * 70)
print("  TEST 2: Random 8MB Range Reads + Overwrites (Direct S3, 20 min)")
print("=" * 70)

reads, overwrites, errors, range_invalid, instances = load_test2("nonpublic/test-platform/results/ranges-direct-20260217-225000")
print(f"\n  Instances: {instances}  |  Errors: {errors}  |  Range invalid: {range_invalid}")
histogram(reads, "Range Reads (Direct S3)")
histogram(overwrites, "Overwrite Uploads (Direct S3)")
